load_d2s.pl
	Copy C:\diablo2\Save\my_d.d2s to loaded.d2s to observe changes.
changes.pl
	Look at the changes in the code.
change.pl
	Make actual changes to the C:\diablo2\Save\my_d.d2s
	Revertable copy made to revert.d2s
	EG. "@37make00001111" #can now access nm and hell
revert.pl
	If changes fail you can call this to convert revert.d2s to
	C:\diablo2\Save\my_d.d2s
make perma.pl
	removes excess .d2s files here, all backups/reference-points gone.
	loaded.d2s from load_d2s.pl
	revert.d2s from change.pl
give all waypoints.pl
	a change.pl coding to give all waypoints for normal/nightmare/hell.
give full rejuvs.pl
	a change.pl coding to convert your stamina/antidote potions from
	  your belt/inventory into full rejuvs.
give stats.pl
	a change.pl coding to max str/dex/free-stat-pts.
get skill data.pl
	Gives skill data and location of its data from 
	  C:\diablo2\Save\my_d.d2s to paste into "change skill.html"
	"change skill.html" you can change your skills and uses change.pl
	  to make the changes to the current C:\diablo2\Save\my_d.d2s
d2_helper.exe
Form1.cs
	C# program to execute 'give full rejuvs.pl' with a button. & copies
	  the change.pl codes to Clipboard to paste into Powershell to
	  execute change.pl to give C:\diablo2\Save\my_d.d2s full rejuvs.
	This is only partial code.
stats.pl
	print out all stats information from C:\diablo2\Save\my_d.d2s
chksums.pl
	prints the checksum in the actual file and the calculated one of
	  C:\diablo2\Save\my_d.d2s
chksum.c
	#on Linux:
	gcc chksum.c && ./a.out
	#on Windows: Open developer prompt w/ Win+Q on Win8 &:
	cl chksum.c && .\chksum
chksum.cpp
	sudo apt-get install g++ && \
	  g++ chksum.cpp && ./a.out
	#on Windows: Open developer prompt w/ Win+Q on Win8 &:
	cl /EHsc chksum.cpp && .\chksum
chksum.cs
	sudo apt-get install mono-dmcs && \
	  mcs chksum.cs && mono chksum.exe
	#on Windows: Open developer prompt w/ Win+Q on Win8 &:
	csc chksum.cs && .\chksum
chksum.java
	sudo apt-get install openjdk-7-jdk && \
	  javac chksum.java && java chksum
	#On Win8 with Powershell 3.0:
	$env:Path += ";C:\Program Files\Java\jdk1.8.0_66\bin"
	javac chksum.java && java chksum
chksum.py
	#on linux:
	python3 chksum.py
	#on windows (after installing Python 3.*):
	python chksum.py
chksum.c
chksum.cpp
chksum.cs
chksum.java
chksum.py
	Calculates the checksum of C:\diablo2\Save\my_d.d2s and prints
	  it out.