use warnings;
use strict;
use feature 'say';

for my $i (643 .. 647, 667 .. 671, 691 .. 695){
  print "'\@${i}make11111111' ";
}
say '';