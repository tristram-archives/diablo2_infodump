#define UInt8	unsigned char
#define UInt16	unsigned short
#define SInt16	short
#define UInt32	unsigned long
#define SInt32	int
