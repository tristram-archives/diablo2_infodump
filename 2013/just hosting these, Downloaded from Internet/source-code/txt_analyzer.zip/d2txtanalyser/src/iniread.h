#ifndef _INIREAD_H_

#define _INIREAD_H_

int ini_find_keystring (UBYTE * ini, char * keystring, char ** value);
int ini_read           (char *);

#endif
