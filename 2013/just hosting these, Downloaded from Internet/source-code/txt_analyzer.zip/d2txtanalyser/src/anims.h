#ifndef _ANIMS_H_

#define _ANIMS_H_

#define COF_COMPOSIT_MAX         16
#define ANIMDATA_FRAME_TAG_MAX  144
#define MONLAYER_VARIANT_MAX     12

typedef enum{
   MDT=0, MNU, MWL, MGH, MA1, MA2, MBL, MSC, MS1, MS2, MS3, MS4, MDD, MKB, MSQ, MRN,
   MONMODE_MAX
} MONMODE_ENUM;

typedef enum{
   LHD=0, LTR, LLG, LRA, LLA, LRH, LLH, LSH, LS1, LS2, LS3, LS4, LS5, LS6, LS7, LS8,
   MONLAYER_MAX
} MONLAYER_ENUM;


// no spaces between data members for now
#pragma pack(1)

typedef struct
{
   UBYTE composit_idx;
   UBYTE shadow_a;
   UBYTE shadow_b;
   UBYTE trans_a;
   UBYTE trans_b;
   char  weapon_class[4]; // with zero termination
} COF_LAYER_S;

typedef struct
{
   UBYTE       nb_layers;
   UBYTE       nb_frames_per_dir;
   UBYTE       nb_directions;
   UBYTE       unknown_03;
   DWORD       unknown_04;
   DWORD       x1;
   DWORD       y1;
   DWORD       x2;
   DWORD       y2;
   UDWORD      anim_speed;
   COF_LAYER_S layer[COF_COMPOSIT_MAX];
} COF_S;

typedef struct
{
   DWORD unknown_00;
   DWORD unknown_04;
   DWORD cof_filesize;
   char  cof_name[8]; // lowercase with zero termination
   DWORD unknown_14;
   COF_S cof;
} D2_CMNCOF_HEADER_S;

typedef struct
{
   char   cof_name[8]; // uppercase with zero termination
   UDWORD nb_frames_per_dir;
   UDWORD anim_speed;
   UBYTE  frame_tag[ANIMDATA_FRAME_TAG_MAX];
} D2_ANIMDATA_HEADER_S;

typedef struct
{
   UBYTE  signature;         // 0x74
   UBYTE  version;           // 0x06
   UBYTE  nb_directions;     // 1, 4, 8, 16 or 32
   UDWORD nb_frames_per_dir; // from 0 to 256
} DCC_HEADER_S;

// back to normal
#pragma pack()

typedef struct
{
   int          active;
   int          directions;
   UBYTE        * cof_buffer;
   long         cof_length;
   char         cof_name[8];
   EXTRSRC_ENUM extraction;
} MONMODE_DATA_S;

typedef struct
{
   int  active;
   char variant[MONLAYER_VARIANT_MAX][4];
} MONLAYER_DATA_S;

typedef struct
{
   char            token[3];
   char            base_weap[4];
   MONMODE_DATA_S  mode[MONMODE_MAX];
   MONLAYER_DATA_S layer[MONLAYER_MAX];
} ANIM_MONDATA_S;

typedef struct
{
   char               * str;
   MONSTATS2_COL_ENUM active_col;
   MONSTATS2_COL_ENUM directions_col;
} MODE_TABLE_S;

typedef struct
{
   char               * str;
   MONSTATS2_COL_ENUM active_col;
   MONSTATS2_COL_ENUM variants_col;
} LAYER_TABLE_S;

extern MODE_TABLE_S   mode_table[MONMODE_MAX];
extern LAYER_TABLE_S  layer_table[MONLAYER_MAX];


// declaration of functions
int anims_dummy(void);

#endif
