#ifndef _ERROR_H_

#define _ERROR_H_

void d2txtanalyser_error (char * strtmp);

#endif
