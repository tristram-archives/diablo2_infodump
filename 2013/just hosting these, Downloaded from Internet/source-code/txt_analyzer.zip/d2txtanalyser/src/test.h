#ifndef _TEST_H_

#define _TEST_H_

int test_col_must_be_present    (TXT_ENUM txt_idx, int col_idx, int display_error);
int test_skills_nb_skills       (void);
int test_monstats_nextinclass   (void);
int test_levels_vis_warps       (void);
int test_levels_worldspace      (void);
int test_awm_norm_uber_ultra    (void);
int test_cubemain_inputs_number (void);
int test_properties             (void);
int test_brackets               (void);

#endif
