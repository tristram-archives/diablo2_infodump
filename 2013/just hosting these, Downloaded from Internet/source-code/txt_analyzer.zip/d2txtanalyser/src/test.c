#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "error.h"
#include "test.h"
#include "mpq\mpqtypes.h"
#include "anims.h"
#include "globals.h"


// ========================================================================================
// test the presence of a column in a .txt
// input :
//    txt_idx       = text file index
//    col_idx       = column index within that file
//    display_error = flag, TRUE or FALSE
// ouput :
//    0 if column is present, non-zero otherwise
// ========================================================================================
int test_col_must_be_present(TXT_ENUM txt_idx, int col_idx, int display_error)
{
   TXT_S * txt;


   if ((txt_idx <= NONE) || (txt_idx >= TXT_MAX))
      return -1;

   txt = & glb_datas.txt[txt_idx];
   if (txt->buffer == NULL)
      return -1;

   if (txt->col == NULL)
      return -1;

   if ((col_idx < 0) || (col_idx >= txt->nb_header))
      return -1;

   if ((txt->col[col_idx] == NULL) || (txt->col[col_idx][0] == NULL))
   {
      if (display_error == TRUE)
      {
         printf(
            "error : in %s, column %s should be present\n",
            txt->filename,
            txt->header[col_idx]
         );
      }
      return -1;
   }

   // end
   return 0;
}


// ========================================================================================
// players must have same # of skills
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int test_skills_nb_skills(void)
{
   TXT_S * txt;
   int   nb_skill[7], is_ok = TRUE, p, y, good_nb;
   char  * str,
         class_code[7][4] = {
            {"ama"}, {"sor"}, {"nec"}, {"pal"}, {"bar"}, {"dru"}, {"ass"}
         };


   txt = & glb_datas.txt[SKILLS];
   if (txt->buffer == NULL)
      return -1;

   if (test_col_must_be_present(SKILLS, SKILLS_CHARCLASS, TRUE))
      return -1;

   // for all player class
   for (p=0; p < 7; p++)
   {
      nb_skill[p] = 0;

      // count how many skills for that player class
      for (y=1; y < txt->nb_rows; y++)
      {
         str = txt->col[SKILLS_CHARCLASS][y];
         if (_stricmp(str, class_code[p]) == 0)
         {
            // this player class use this skill
            nb_skill[p]++;
         }
      }
   }

   good_nb = 0;
   for (p=0; p < 7; p++)
   {
      if (good_nb == 0)
         good_nb = nb_skill[p];
      else if (good_nb != nb_skill[p])
         is_ok = FALSE;
   }
   if (is_ok != TRUE)
   {
      printf("\nIn Skills.txt :\n");
      printf("   * ERROR : some player class have different number of skills\n");
      for (p=0; p < 7; p++)
         printf("   * charclass '%s' has %3i skills\n", class_code[p], nb_skill[p]);
      return -1;
   }

   // end
   return 0;
}


// ========================================================================================
// BaseID & NextInClass must make a chain of correctly linked monsters
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int test_monstats_nextinclass(void)
{
   TXT_S  * txt;
   int    nb_mon, size, y, is_ok = TRUE, nb_empty_nextinclass, chain_last_row,
          found, nb_chain_elem, r, n, in_error;
   char   * id, * baseid, * baseid2, * nextinclass;
   struct MONCHAIN_S
   {
      int chain_done;
      int prec;
      int next;
   } * monchain;


   txt = & glb_datas.txt[MONSTATS];

   if (test_col_must_be_present(MONSTATS, MONSTATS_ID, TRUE))
      return -1;

   if (test_col_must_be_present(MONSTATS, MONSTATS_BASEID, TRUE))
      return -1;

   if (test_col_must_be_present(MONSTATS, MONSTATS_NEXTINCLASS, TRUE))
      return -1;

   nb_mon = txt->nb_rows;
   if (nb_mon <= 0)
      return -1;

   size = sizeof(struct MONCHAIN_S) * nb_mon;
   monchain = (struct MONCHAIN_S *) malloc(size);
   if (monchain == NULL)
      return -1;
   memset(monchain, 0, size);

   // for all monsters
   in_error = FALSE;
   for (y=1; y < nb_mon; y++)
   {
      baseid = txt->col[MONSTATS_BASEID][y];
      if (monchain[y].chain_done == 1)
         continue;

      // analyse this chain
      nb_empty_nextinclass = 0;
      chain_last_row       = 0;
      nb_chain_elem        = 0;
      for (n=1; n < nb_mon; n++)
      {
         baseid2 = txt->col[MONSTATS_BASEID][n];
         if (glb_datas.str_cmp_func(baseid, baseid2) == 0)
         {
            in_error = FALSE;
            nb_chain_elem++;
            nextinclass = txt->col[MONSTATS_NEXTINCLASS][n];
            if (strlen(nextinclass) == 0)
            {
               nb_empty_nextinclass++;
               chain_last_row = n;
            }
            else
            {
               // search this ID
               found = FALSE;
               for (r = 1; r < nb_mon; r++)
               {
                  id = txt->col[MONSTATS_ID][r];
                  if (glb_datas.str_cmp_func(nextinclass, id) == 0)
                  {
                     monchain[n].next = r;
                     monchain[r].prec = n;
                     found = TRUE;
                     break;
                  }
               }
               if (found == FALSE)
               {
                  // error
                  if (is_ok == TRUE)
                  {
                     printf("\nIn %s :\n", txt->filename);
                     is_ok = FALSE;
                  }
                  printf("   * ERROR : '%s' (%s) at row %i wasn't found in '%s'\n",
                     txt->header[MONSTATS_NEXTINCLASS],
                     nextinclass,
                     n + 1,
                     txt->header[MONSTATS_ID]
                  );
                  in_error = TRUE;
               }
            }
         }
      }

      if (in_error == FALSE)
      {
         // only 1 empty NextInClass ?
         if (nb_empty_nextinclass != 1)
         {
            // error
            if (is_ok == TRUE)
            {
               printf("\nIn %s :\n", txt->filename);
               is_ok = FALSE;
            }
            printf("   * ERROR : chain of '%s' with \"%s\" have more than 1 empty '%s' (%i)\n",
               txt->header[MONSTATS_BASEID],
               baseid,
               txt->header[MONSTATS_NEXTINCLASS],
               nb_empty_nextinclass
            );
         }
         else
         {
            // follow the chain in reversed order and count how many elements in it
            n = 0;
            r = chain_last_row;
            while (r != 0)
            {
               n++;
               r = monchain[r].prec;
            }
            if (n != nb_chain_elem)
            {
               // error
               if (is_ok == TRUE)
               {
                  printf("\nIn %s :\n", txt->filename);
                  is_ok = FALSE;
               }
               printf(
                  "   * ERROR : chain of '%s' with \"%s\" is broken somehow (found %i elements, expected %i)\n",
                  txt->header[MONSTATS_BASEID],
                  baseid,
                  n,
                  nb_chain_elem
               );
            }
         }
      }

      // this chain is done
      for (n=1; n < nb_mon; n++)
      {
         baseid2 = txt->col[MONSTATS_BASEID][n];
         if (glb_datas.str_cmp_func(baseid, baseid2) == 0)
            monchain[n].chain_done = 1;
      }
   }

   // end
   free(monchain);
   return is_ok == TRUE ? 0 : -1;
}


// ========================================================================================
// Levels must be linked by at least 1 Vis, and each Vis should have a Warp
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int test_levels_vis_warps(void)
{
   TXT_S * txt, * txt_warp;
   int   vis_id[8] = {
            LEVELS_VIS0, LEVELS_VIS1, LEVELS_VIS2, LEVELS_VIS3,
            LEVELS_VIS4, LEVELS_VIS5, LEVELS_VIS6, LEVELS_VIS7
         },
         warp_id [8] = {
            LEVELS_WARP0, LEVELS_WARP1, LEVELS_WARP2, LEVELS_WARP3,
            LEVELS_WARP4, LEVELS_WARP5, LEVELS_WARP6, LEVELS_WARP7
         },
         y, r, n, id, vis, i, y2, n2, id2, vis2, warp, warp2,
         is_ok = TRUE, is_ok_warn = TRUE, found, valid_vis;
   char  * str;


   txt_warp = & glb_datas.txt[LVLWARP];
   txt      = & glb_datas.txt[LEVELS];
   for (i=0; i < 8; i++)
   {
      if (test_col_must_be_present(LEVELS, vis_id[i], TRUE))
         return -1;

      if (test_col_must_be_present(LEVELS, warp_id[i], TRUE))
         return -1;
   }
   if (test_col_must_be_present(LEVELS, LEVELS_NAME, TRUE))
      return -1;
   if (test_col_must_be_present(LVLWARP, LVLWARP_ID, TRUE))
      return -1;
   if (test_col_must_be_present(LVLWARP, LVLWARP_NAME, TRUE))
      return -1;

   // for all levels
   for (y = 2; y < txt->nb_rows; y++)
   {
      // get ID
      str = txt->col[LEVELS_ID][y];
      id  = atoi(str);

      // for all Vis
      for (n=0; n < 8; n++)
      {
         str = txt->col[ vis_id[n] ][y];
         vis = atoi(str);
         if (vis >= 1)
         {
            // is it the same ID as current ?
            if (vis == id)
            {
               // error
               if (is_ok == TRUE)
               {
                  printf("\nIn %s :\n", txt->filename);
                  is_ok = FALSE;
               }
               printf(
                  "   * ERROR : '%s' (%i) at row %i (%s) can't link use the Level ID where it is placed\n",
                  txt->header[ vis_id[n] ],
                  vis,
                  y + 1,
                  txt->col[LEVELS_NAME][y]
               );
            }
            else
            {
               // 1) test if it has a correct warp
               str  = txt->col[ warp_id[n] ][y];
               warp = atoi(str);
               if (warp < 0)
               {
                  // error
                  if (is_ok_warn == TRUE)
                  {
                     fprintf(glb_datas.std_warning, "\nIn %s :\n", txt->filename);
                     is_ok_warn = FALSE;
                  }
                  fprintf(
                     glb_datas.std_warning,
                     "   * WARNING : '%s' (%i) at row %i (%s) should use a Warp ID (not -1)\n",
                     txt->header[ warp_id[n] ],
                     warp,
                     y + 1,
                     txt->col[LEVELS_NAME][y]
                  );
               }
               else
               {
                  // is it a valid warp ID ?
                  found = FALSE;
                  for (r=1; r < txt_warp->nb_rows; r++)
                  {
                     str   = txt_warp->col[LVLWARP_ID][r];
                     warp2 = atoi(str);
                     if (warp == warp2)
                     {
                        found = TRUE;
                        break;
                     }
                  }
                  if (found == FALSE)
                  {
                     // error
                     if (is_ok == TRUE)
                     {
                        printf("\nIn %s :\n", txt->filename);
                        is_ok = FALSE;
                     }
                     printf(
                        "   * ERROR : '%s' (%i) at row %i (%s) use a warp ID which don't exists in LvlWarp.txt\n",
                        txt->header[ warp_id[n] ],
                        warp,
                        y + 1,
                        txt->col[LEVELS_NAME][y]
                     );
                  }
               }

               // 2) is the other level linked back to ourselves ?

               // 2A) for all levels
               valid_vis = FALSE;
               for (y2 = 2; y2 < txt->nb_rows; y2++)
               {
                  if (y == y2)
                     continue;
                  // get ID
                  str = txt->col[LEVELS_ID][y2];
                  id2 = atoi(str);
                  if (id2 == vis)
                  {
                     valid_vis = TRUE;

                     // for all Vis of this 2nd level
                     found = FALSE;
                     for (n2 = 0;  n2 < 8; n2++)
                     {
                        str  = txt->col[ vis_id[n2] ][y2];
                        vis2 = atoi(str);
                        if (vis2 == id)
                        {
                           found = TRUE;
                           break;
                        }
                     }
                     if (found == FALSE)
                     {
                        // error
                        if (is_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           is_ok = FALSE;
                           break;
                        }
                        printf(
                           "   * ERROR : Level %s %i (%s) at row %i "
                           "is not linked to Level %s %i (%s) at row %i\n",
                           txt->header[LEVELS_ID],
                           id2,
                           txt->col[LEVELS_NAME][y2],
                           y2 + 1,
                           txt->header[LEVELS_ID],
                           id,
                           txt->col[LEVELS_NAME][y],
                           y + 1
                        );
                     }
                     else
                        break;
                  }
               }

               // 2B)
               if (valid_vis == FALSE)
               {
                  // error
                  if (is_ok == TRUE)
                  {
                     printf("\nIn %s :\n", txt->filename);
                     is_ok = FALSE;
                  }
                  printf(
                     "   * ERROR : '%s' (%i) at row %i is an ID that is not in the Levels ID\n",
                     txt->header[ vis_id[n] ],
                     vis,
                     y + 1
                  );
               }
            }
         }
      }
   }

   // end
   if ((is_ok == TRUE) && (is_ok_warn == TRUE))
      return 0;
   return -1;
}


// ========================================================================================
// Levels should not overlap each other (within the same act of 1 difficulty)
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int test_levels_worldspace(void)
{
   TXT_S * txt;
   int   sizex_id[3] = {LEVELS_SIZEX, LEVELS_SIZEXN, LEVELS_SIZEXH},
         sizey_id[3] = {LEVELS_SIZEY, LEVELS_SIZEYN, LEVELS_SIZEYH};
   int   is_ok = TRUE, is_ok_warn = TRUE, d, a, y, y2,
         act, sizex, sizey,
         offsetx,  offsety,  bottomx,  bottomy,
         offsetx2, offsety2, bottomx2, bottomy2,
         * overlapped;


   txt = & glb_datas.txt[LEVELS];
   if (test_col_must_be_present(LEVELS, LEVELS_SIZEX, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_SIZEXN, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_SIZEXH, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_SIZEY, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_SIZEYN, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_SIZEYH, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_NAME, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_ACT, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_ID, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_OFFSETX, TRUE))
      return -1;
   if (test_col_must_be_present(LEVELS, LEVELS_OFFSETY, TRUE))
      return -1;

   y = sizeof(int) * txt->nb_rows;
   overlapped = (int *) malloc(y);
   if (overlapped == NULL)
      return -1;
   memset(overlapped, 0, y);

   // for all acts
   for (a=0; a < 5; a++)
   {
      // for all levels of this act
      for (y = 2; y < txt->nb_rows; y++)
      {
         if (overlapped[y] == 1)
            continue;
         if (atoi(txt->col[LEVELS_ID][y]) == 0)
            continue;

         act = atoi(txt->col[LEVELS_ACT][y]);
         if (act == a)
         {
            offsetx = atoi(txt->col[LEVELS_OFFSETX][y]);
            offsety = atoi(txt->col[LEVELS_OFFSETY][y]);
            if ((offsetx <= -1) || (offsety <= -1))
               continue;

            // for all difficulties
            for (d=0; d < 3; d++)
            {
               sizex   = atoi(txt->col[ sizex_id[d] ][y]);
               sizey   = atoi(txt->col[ sizey_id[d] ][y]);
               bottomx = offsetx + sizex - 1;
               bottomy = offsety + sizey - 1;

               // we have the coordinate of this level
               // check if it don't overlap with another of same act and difficulty
               for (y2 = 2; y2 < txt->nb_rows; y2++)
               {
                  if (y2 == y)
                     continue;
                  if (atoi(txt->col[LEVELS_ACT][y2]) != act)
                     continue;
                  if (atoi(txt->col[LEVELS_ID][y2]) == 0)
                     continue;

                  offsetx2 = atoi(txt->col[LEVELS_OFFSETX][y2]);
                  offsety2 = atoi(txt->col[LEVELS_OFFSETY][y2]);
                  if ((offsetx2 <= -1) || (offsety2 <= -1))
                     continue;

                  sizex    = atoi(txt->col[ sizex_id[d] ][y2]);
                  sizey    = atoi(txt->col[ sizey_id[d] ][y2]);
                  bottomx2 = offsetx2 + sizex - 1;
                  bottomy2 = offsety2 + sizey - 1;

                  // test overlaping
                  if ( ((offsety < offsety2) && (bottomy < offsety2)) ||
                       ((offsety > bottomy2) && (bottomy > bottomy2)) ||
                       ((offsetx < offsetx2) && (bottomx < offsetx2)) ||
                       ((offsetx > bottomx2) && (bottomx > bottomx2)))
                  {
                     // ok
                  }
                  else
                  {
                     // error
                     if (is_ok_warn == TRUE)
                     {
                        fprintf(glb_datas.std_warning, "\nIn %s :\n", txt->filename);
                        is_ok_warn = FALSE;
                     }
                     fprintf(
                        glb_datas.std_warning,
                        "   * WARNING : Level %s %i (%s) at row %i overlap\n"
                        "               level %s %i (%s) at row %i in %s difficulty\n\n",
                        txt->header[LEVELS_ID],
                        atoi(txt->col[LEVELS_ID][y]),
                        txt->col[LEVELS_NAME][y],
                        y + 1,
                        txt->header[LEVELS_ID],
                        atoi(txt->col[LEVELS_ID][y2]),
                        txt->col[LEVELS_NAME][y2],
                        y2 + 1,
                        d == 0 ? "Normal" : d == 1 ? "Nightmare" : "Hell"
                     );
                     overlapped[y2] = 1;
                  }
               }               
            }
         }
      }
   }

   // end
   free(overlapped);
   if ((is_ok == TRUE) && (is_ok_warn == TRUE))
      return 0;
   return -1;
}


// ========================================================================================
// Test Norm Uber and Ultra codes in Armor.txt and Weapons.txt
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int test_awm_norm_uber_ultra(void)
{
   TXT_S * txt;
   int   is_ok = TRUE, y, n, t;
   char  * code,  * norm,  * uber,  * ultra,
         * code2, * norm2, * uber2, * ultra2;


   // for Armor.txt, then Weapons.txt
   for (t=0; t < 2; t++)
   {
      if (t == 0)
      {
         txt = & glb_datas.txt[ARMOR];
         if (test_col_must_be_present(ARMOR, AWM_NAME, TRUE))
            return -1;
         if (test_col_must_be_present(ARMOR, AWM_CODE, TRUE))
            return -1;
         if (test_col_must_be_present(ARMOR, AWM_NORMCODE, TRUE))
            return -1;
         if (test_col_must_be_present(ARMOR, AWM_UBERCODE, TRUE))
            return -1;
         if (test_col_must_be_present(ARMOR, AWM_ULTRACODE, TRUE))
            return -1;
      }
      else
      {
         txt = & glb_datas.txt[WEAPONS];
         if (test_col_must_be_present(WEAPONS, AWM_NAME, TRUE))
            return -1;
         if (test_col_must_be_present(WEAPONS, AWM_CODE, TRUE))
            return -1;
         if (test_col_must_be_present(WEAPONS, AWM_NORMCODE, TRUE))
            return -1;
         if (test_col_must_be_present(WEAPONS, AWM_UBERCODE, TRUE))
            return -1;
         if (test_col_must_be_present(WEAPONS, AWM_ULTRACODE, TRUE))
            return -1;
      }
   
      is_ok = TRUE;

      // for all items 
      for (y=1; y < txt->nb_rows; y++)
      {
         code  = txt->col[AWM_CODE][y];
         norm  = txt->col[AWM_NORMCODE][y];
         uber  = txt->col[AWM_UBERCODE][y];
         ultra = txt->col[AWM_ULTRACODE][y];

         if (strlen(code) == 0)
            continue;

         // is the code in norm/uber/ultra ?
         if (strcmp(code, norm) != 0)
         {
            if (strcmp(code, uber) != 0)
            {
               if (strcmp(code, ultra) != 0)
               {
                  // error
                  if (is_ok == TRUE)
                  {
                     printf("\nIn %s :\n", txt->filename);
                     is_ok = FALSE;
                  }
                  printf(
                     "   * ERROR : '%s' (%s) at row %i (%s) is "
                     "not used in Norm/Uber/Ultra code columns\n",
                     txt->header[AWM_CODE],
                     code,
                     y + 1,
                     txt->col[AWM_NAME][y]
                  );
                  continue;
               }
            }
         }

         // check all items which use this Norm/Uber/Ultra codes
         for (n=1; n < txt->nb_rows; n++)
         {
            if (y == n)
               continue;

            code2 = txt->col[AWM_CODE][n];
            if (strlen(code2) == 0)
               continue;

            if ( (strcmp(code2, norm)  == 0) ||
                 (strcmp(code2, uber)  == 0) ||
                 (strcmp(code2, ultra) == 0)
               )
            {
               norm2  = txt->col[AWM_NORMCODE][n];
               uber2  = txt->col[AWM_UBERCODE][n];
               ultra2 = txt->col[AWM_ULTRACODE][n];

               // check if all same NormCode
               if (strcmp(norm2, norm) != 0)
               {
                  // error
                  if (is_ok == TRUE)
                  {
                     printf("\nIn %s :\n", txt->filename);
                     is_ok = FALSE;
                  }
                  printf(
                     "   * ERROR : Item '%s' (%s) at row %i (%s) "
                     "has '%s' (%s), expected (%s)\n",
                     txt->header[AWM_CODE],
                     code2,
                     n + 1,
                     txt->col[AWM_NAME][n],
                     txt->header[AWM_NORMCODE],
                     norm2,
                     norm
                  );
               }

               // check if all same UberCode
               if (strcmp(uber2, uber) != 0)
               {
                  // error
                  if (is_ok == TRUE)
                  {
                     printf("\nIn %s :\n", txt->filename);
                     is_ok = FALSE;
                  }
                  printf(
                     "   * ERROR : Item '%s' (%s) at row %i (%s) "
                     "has '%s' (%s), expected (%s)\n",
                     txt->header[AWM_CODE],
                     code2,
                     n + 1,
                     txt->col[AWM_NAME][n],
                     txt->header[AWM_UBERCODE],
                     uber2,
                     uber
                  );
               }

               // check if all same UltraCode
               if (strcmp(ultra2, ultra) != 0)
               {
                  // error
                  if (is_ok == TRUE)
                  {
                     printf("\nIn %s :\n", txt->filename);
                     is_ok = FALSE;
                  }
                  printf(
                     "   * ERROR : Item '%s' (%s) at row %i (%s) "
                     "has '%s' (%s), expected (%s)\n",
                     txt->header[AWM_CODE],
                     code2,
                     n + 1,
                     txt->col[AWM_NAME][n],
                     txt->header[AWM_ULTRACODE],
                     ultra2,
                     ultra
                  );
               }
            }
         }
      }
   }

   // end
   if (is_ok == TRUE)
      return 0;
   return -1;
}


// ========================================================================================
// Test numbers of inputs in CubeMain.txt
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int test_cubemain_inputs_number(void)
{
   TXT_S * txt;
   int   is_ok = TRUE, y, nb_input, i, sum, length, in_error, n,
         input_id[7] = {
            CUBEMAIN_INPUT1, CUBEMAIN_INPUT2, CUBEMAIN_INPUT3, CUBEMAIN_INPUT4,
            CUBEMAIN_INPUT5, CUBEMAIN_INPUT6, CUBEMAIN_INPUT7
         };
   char  * str, * qty_ptr, * buffer = glb_datas.strtmp, * desc;


   txt = & glb_datas.txt[CUBEMAIN];

   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_DESCRIPTION, TRUE))
      return -1;
   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_NUMINPUTS, TRUE))
      return -1;
   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_INPUT1, TRUE))
      return -1;
   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_INPUT2, TRUE))
      return -1;
   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_INPUT3, TRUE))
      return -1;
   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_INPUT4, TRUE))
      return -1;
   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_INPUT5, TRUE))
      return -1;
   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_INPUT6, TRUE))
      return -1;
   if (test_col_must_be_present(CUBEMAIN, CUBEMAIN_INPUT7, TRUE))
      return -1;

   // for all formulas
   for (y=1; y < txt->nb_rows; y++)
   {
      desc = txt->col[CUBEMAIN_DESCRIPTION][y];

      nb_input = atoi(txt->col[CUBEMAIN_NUMINPUTS][y]);
      if (nb_input < 1)
      {
         // error
         if (is_ok == TRUE)
         {
            printf("\nIn %s :\n", txt->filename);
            is_ok = FALSE;
         }
         printf(
            "   * ERROR : Formula at row %i should have '%s' >= 1\n"
            "             (%s)\n\n",
            y + 1,
            txt->header[CUBEMAIN_NUMINPUTS],
            desc
         );
      }

      // compute sum of inputs used
      sum = 0;
      in_error = FALSE;
      for (i=0; i < 7; i++)
      {
         str  = txt->col[ input_id[i] ][y];
         if (strlen(str) == 0)
            break;

         qty_ptr = strstr(str, "qty=");
         if (qty_ptr != NULL)
         {
            // get quantity
            strcpy(buffer, qty_ptr + 4);
            length = strlen(buffer);
            if (length == 0)
            {
               // error
               if (is_ok == TRUE)
               {
                  printf("\nIn %s :\n", txt->filename);
                  is_ok = FALSE;
               }
               printf(
                  "   * ERROR : '%s' (%s) at row %i use 'qty=' but there's no value\n"
                  "             (%s)\n\n",
                  txt->header[ input_id[i] ],
                  str,
                  y + 1,
                  desc
               );
               in_error = TRUE;
               continue; // next input column
            }
            for (n=0; n < length; n++)
            {
               if ((buffer[n] < '0') || (buffer[n] > '9'))
               {
                  buffer[n] = 0x00;
                  break;
               }
            }

            length = strlen(buffer);
            if (length == 0)
            {
               // error
               if (is_ok == TRUE)
               {
                  printf("\nIn %s :\n", txt->filename);
                  is_ok = FALSE;
               }
               printf(
                  "   * ERROR : '%s' (%s) at row %i use 'qty=' but there's no value\n"
                  "             (%s)\n\n",
                  txt->header[ input_id[i] ],
                  str,
                  y + 1,
                  desc
               );
               in_error = TRUE;
               continue; // next input column
            }

            n = atoi(buffer);
            if (n < 1)
            {
               // error
               if (is_ok == TRUE)
               {
                  printf("\nIn %s :\n", txt->filename);
                  is_ok = FALSE;
               }
               printf(
                  "   * ERROR : '%s' (%s) at row %i should have 'qty=' value >= 1\n"
                  "             (%s)\n\n",
                  txt->header[ input_id[i] ],
                  str,
                  y + 1,
                  desc
               );
               in_error = TRUE;
               continue; // next input column
            }
            sum += n;
         }
         else
         {
            // count as 1
            sum++;
         }
      }
      if (in_error == TRUE)
         continue;

      if (nb_input != sum)
      {
         // error
         if (is_ok == TRUE)
         {
            printf("\nIn %s :\n", txt->filename);
            is_ok = FALSE;
         }
         printf(
            "   * ERROR : Formula at row %i has invalid number of inputs\n"
            "             (%s)\n\n",
            y + 1,
            desc
         );
      }
   }

   // end
   if (is_ok == TRUE)
      return 0;
   return -1;
}


// ========================================================================================
// Test Properties, with Param, Min and Max columns
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int test_properties(void)
{
   static struct
   {
      TXT_ENUM txt;
      int      prop;
      int      param;
      int      min;
      int      max;
   } data[] = {
   // txt           prop                   param                   min                   max
   // ------------  ---------------------  ----------------------  --------------------  --------------------
     {AUTOMAGIC,    AUTOMAGIC_MOD1CODE,    AUTOMAGIC_MOD1PARAM,    AUTOMAGIC_MOD1MIN,    AUTOMAGIC_MOD1MAX},
     {AUTOMAGIC,    AUTOMAGIC_MOD2CODE,    AUTOMAGIC_MOD2PARAM,    AUTOMAGIC_MOD2MIN,    AUTOMAGIC_MOD2MAX},
     {AUTOMAGIC,    AUTOMAGIC_MOD3CODE,    AUTOMAGIC_MOD3PARAM,    AUTOMAGIC_MOD3MIN,    AUTOMAGIC_MOD3MAX},
     {CUBEMAIN,     CUBEMAIN_MOD1,         CUBEMAIN_MOD1PARAM,     CUBEMAIN_MOD1MIN,     CUBEMAIN_MOD1MAX},
     {CUBEMAIN,     CUBEMAIN_MOD2,         CUBEMAIN_MOD2PARAM,     CUBEMAIN_MOD2MIN,     CUBEMAIN_MOD2MAX},
     {CUBEMAIN,     CUBEMAIN_MOD3,         CUBEMAIN_MOD3PARAM,     CUBEMAIN_MOD3MIN,     CUBEMAIN_MOD3MAX},
     {CUBEMAIN,     CUBEMAIN_MOD4,         CUBEMAIN_MOD4PARAM,     CUBEMAIN_MOD4MIN,     CUBEMAIN_MOD4MAX},
     {CUBEMAIN,     CUBEMAIN_MOD5,         CUBEMAIN_MOD5PARAM,     CUBEMAIN_MOD5MIN,     CUBEMAIN_MOD5MAX},
     {CUBEMAIN,     CUBEMAIN_CMOD1,        CUBEMAIN_CMOD1PARAM,    CUBEMAIN_CMOD1MIN,    CUBEMAIN_CMOD1MAX},
     {CUBEMAIN,     CUBEMAIN_CMOD2,        CUBEMAIN_CMOD2PARAM,    CUBEMAIN_CMOD2MIN,    CUBEMAIN_CMOD2MAX},
     {CUBEMAIN,     CUBEMAIN_CMOD3,        CUBEMAIN_CMOD3PARAM,    CUBEMAIN_CMOD3MIN,    CUBEMAIN_CMOD3MAX},
     {CUBEMAIN,     CUBEMAIN_CMOD4,        CUBEMAIN_CMOD4PARAM,    CUBEMAIN_CMOD4MIN,    CUBEMAIN_CMOD4MAX},
     {CUBEMAIN,     CUBEMAIN_CMOD5,        CUBEMAIN_CMOD5PARAM,    CUBEMAIN_CMOD5MIN,    CUBEMAIN_CMOD5MAX},
     {CUBEMAIN,     CUBEMAIN_BMOD1,        CUBEMAIN_BMOD1PARAM,    CUBEMAIN_BMOD1MIN,    CUBEMAIN_BMOD1MAX},
     {CUBEMAIN,     CUBEMAIN_BMOD2,        CUBEMAIN_BMOD2PARAM,    CUBEMAIN_BMOD2MIN,    CUBEMAIN_BMOD2MAX},
     {CUBEMAIN,     CUBEMAIN_BMOD3,        CUBEMAIN_BMOD3PARAM,    CUBEMAIN_BMOD3MIN,    CUBEMAIN_BMOD3MAX},
     {CUBEMAIN,     CUBEMAIN_BMOD4,        CUBEMAIN_BMOD4PARAM,    CUBEMAIN_BMOD4MIN,    CUBEMAIN_BMOD4MAX},
     {CUBEMAIN,     CUBEMAIN_BMOD5,        CUBEMAIN_BMOD5PARAM,    CUBEMAIN_BMOD5MIN,    CUBEMAIN_BMOD5MAX},
     {GEMS,         GEMS_HELMMOD1CODE,     GEMS_HELMMOD1PARAM,     GEMS_HELMMOD1MIN,     GEMS_HELMMOD1MAX},
     {GEMS,         GEMS_HELMMOD2CODE,     GEMS_HELMMOD2PARAM,     GEMS_HELMMOD2MIN,     GEMS_HELMMOD2MAX},
     {GEMS,         GEMS_HELMMOD3CODE,     GEMS_HELMMOD3PARAM,     GEMS_HELMMOD3MIN,     GEMS_HELMMOD3MAX},
     {GEMS,         GEMS_SHIELDMOD1CODE,   GEMS_SHIELDMOD1PARAM,   GEMS_SHIELDMOD1MIN,   GEMS_SHIELDMOD1MAX},
     {GEMS,         GEMS_SHIELDMOD2CODE,   GEMS_SHIELDMOD2PARAM,   GEMS_SHIELDMOD2MIN,   GEMS_SHIELDMOD2MAX},
     {GEMS,         GEMS_SHIELDMOD3CODE,   GEMS_SHIELDMOD3PARAM,   GEMS_SHIELDMOD3MIN,   GEMS_SHIELDMOD3MAX},
     {GEMS,         GEMS_WEAPONMOD1CODE,   GEMS_WEAPONMOD1PARAM,   GEMS_WEAPONMOD1MIN,   GEMS_WEAPONMOD1MAX},
     {GEMS,         GEMS_WEAPONMOD2CODE,   GEMS_WEAPONMOD2PARAM,   GEMS_WEAPONMOD2MIN,   GEMS_WEAPONMOD2MAX},
     {GEMS,         GEMS_WEAPONMOD3CODE,   GEMS_WEAPONMOD3PARAM,   GEMS_WEAPONMOD3MIN,   GEMS_WEAPONMOD3MAX},
     {MAGICPREFIX,  MAGICAFFIX_MOD1CODE,   MAGICAFFIX_MOD1PARAM,   MAGICAFFIX_MOD1MIN,   MAGICAFFIX_MOD1MAX},
     {MAGICPREFIX,  MAGICAFFIX_MOD2CODE,   MAGICAFFIX_MOD2PARAM,   MAGICAFFIX_MOD2MIN,   MAGICAFFIX_MOD2MAX},
     {MAGICPREFIX,  MAGICAFFIX_MOD3CODE,   MAGICAFFIX_MOD3PARAM,   MAGICAFFIX_MOD3MIN,   MAGICAFFIX_MOD3MAX},
     {MAGICSUFFIX,  MAGICAFFIX_MOD1CODE,   MAGICAFFIX_MOD1PARAM,   MAGICAFFIX_MOD1MIN,   MAGICAFFIX_MOD1MAX},
     {MAGICSUFFIX,  MAGICAFFIX_MOD2CODE,   MAGICAFFIX_MOD2PARAM,   MAGICAFFIX_MOD2MIN,   MAGICAFFIX_MOD2MAX},
     {MAGICSUFFIX,  MAGICAFFIX_MOD3CODE,   MAGICAFFIX_MOD3PARAM,   MAGICAFFIX_MOD3MIN,   MAGICAFFIX_MOD3MAX},
     {MONPROP,      MONPROP_PROP1,         MONPROP_PAR1,           MONPROP_MIN1,         MONPROP_MAX1},
     {MONPROP,      MONPROP_PROP1H,        MONPROP_PAR1H,          MONPROP_MIN1H,        MONPROP_MAX1H},
     {MONPROP,      MONPROP_PROP1N,        MONPROP_PAR1N,          MONPROP_MIN1N,        MONPROP_MAX1N},
     {MONPROP,      MONPROP_PROP2,         MONPROP_PAR2,           MONPROP_MIN2,         MONPROP_MAX2},
     {MONPROP,      MONPROP_PROP2H,        MONPROP_PAR2H,          MONPROP_MIN2H,        MONPROP_MAX2H},
     {MONPROP,      MONPROP_PROP2N,        MONPROP_PAR2N,          MONPROP_MIN2N,        MONPROP_MAX2N},
     {MONPROP,      MONPROP_PROP3,         MONPROP_PAR3,           MONPROP_MIN3,         MONPROP_MAX3},
     {MONPROP,      MONPROP_PROP3H,        MONPROP_PAR3H,          MONPROP_MIN3H,        MONPROP_MAX3H},
     {MONPROP,      MONPROP_PROP3N,        MONPROP_PAR3N,          MONPROP_MIN3N,        MONPROP_MAX3N},
     {MONPROP,      MONPROP_PROP4,         MONPROP_PAR4,           MONPROP_MIN4,         MONPROP_MAX4},
     {MONPROP,      MONPROP_PROP4H,        MONPROP_PAR4H,          MONPROP_MIN4H,        MONPROP_MAX4H},
     {MONPROP,      MONPROP_PROP4N,        MONPROP_PAR4N,          MONPROP_MIN4N,        MONPROP_MAX4N},
     {MONPROP,      MONPROP_PROP5,         MONPROP_PAR5,           MONPROP_MIN5,         MONPROP_MAX5},
     {MONPROP,      MONPROP_PROP5H,        MONPROP_PAR5H,          MONPROP_MIN5H,        MONPROP_MAX5H},
     {MONPROP,      MONPROP_PROP5N,        MONPROP_PAR5N,          MONPROP_MIN5N,        MONPROP_MAX5N},
     {MONPROP,      MONPROP_PROP6,         MONPROP_PAR6,           MONPROP_MIN6,         MONPROP_MAX6},
     {MONPROP,      MONPROP_PROP6H,        MONPROP_PAR6H,          MONPROP_MIN6H,        MONPROP_MAX6H},
     {MONPROP,      MONPROP_PROP6N,        MONPROP_PAR6N,          MONPROP_MIN6N,        MONPROP_MAX6N},
     {QUALITYITEMS, QUALITYITEMS_MOD1CODE, QUALITYITEMS_MOD1PARAM, QUALITYITEMS_MOD1MIN, QUALITYITEMS_MOD1MAX},
     {QUALITYITEMS, QUALITYITEMS_MOD2CODE, QUALITYITEMS_MOD2PARAM, QUALITYITEMS_MOD2MIN, QUALITYITEMS_MOD2MAX},
     {RUNES,        RUNES_T1CODE1,         RUNES_T1PARAM1,         RUNES_T1MIN1,         RUNES_T1MAX1},
     {RUNES,        RUNES_T1CODE2,         RUNES_T1PARAM2,         RUNES_T1MIN2,         RUNES_T1MAX2},
     {RUNES,        RUNES_T1CODE3,         RUNES_T1PARAM3,         RUNES_T1MIN3,         RUNES_T1MAX3},
     {RUNES,        RUNES_T1CODE4,         RUNES_T1PARAM4,         RUNES_T1MIN4,         RUNES_T1MAX4},
     {RUNES,        RUNES_T1CODE5,         RUNES_T1PARAM5,         RUNES_T1MIN5,         RUNES_T1MAX5},
     {RUNES,        RUNES_T1CODE6,         RUNES_T1PARAM6,         RUNES_T1MIN6,         RUNES_T1MAX6},
     {RUNES,        RUNES_T1CODE7,         RUNES_T1PARAM7,         RUNES_T1MIN7,         RUNES_T1MAX7},
     {SETITEMS,     SETITEMS_APROP1A,      SETITEMS_APAR1A,        SETITEMS_AMIN1A,      SETITEMS_AMAX1A},
     {SETITEMS,     SETITEMS_APROP1B,      SETITEMS_APAR1B,        SETITEMS_AMIN1B,      SETITEMS_AMAX1B},
     {SETITEMS,     SETITEMS_APROP2A,      SETITEMS_APAR2A,        SETITEMS_AMIN2A,      SETITEMS_AMAX2A},
     {SETITEMS,     SETITEMS_APROP2B,      SETITEMS_APAR2B,        SETITEMS_AMIN2B,      SETITEMS_AMAX2B},
     {SETITEMS,     SETITEMS_APROP3A,      SETITEMS_APAR3A,        SETITEMS_AMIN3A,      SETITEMS_AMAX3A},
     {SETITEMS,     SETITEMS_APROP3B,      SETITEMS_APAR3B,        SETITEMS_AMIN3B,      SETITEMS_AMAX3B},
     {SETITEMS,     SETITEMS_APROP4A,      SETITEMS_APAR4A,        SETITEMS_AMIN4A,      SETITEMS_AMAX4A},
     {SETITEMS,     SETITEMS_APROP4B,      SETITEMS_APAR4B,        SETITEMS_AMIN4B,      SETITEMS_AMAX4B},
     {SETITEMS,     SETITEMS_APROP5A,      SETITEMS_APAR5A,        SETITEMS_AMIN5A,      SETITEMS_AMAX5A},
     {SETITEMS,     SETITEMS_APROP5B,      SETITEMS_APAR5B,        SETITEMS_AMIN5B,      SETITEMS_AMAX5B},
     {SETITEMS,     SETITEMS_PROP1,        SETITEMS_PAR1,          SETITEMS_MIN1,        SETITEMS_MAX1},
     {SETITEMS,     SETITEMS_PROP2,        SETITEMS_PAR2,          SETITEMS_MIN2,        SETITEMS_MAX2},
     {SETITEMS,     SETITEMS_PROP3,        SETITEMS_PAR3,          SETITEMS_MIN3,        SETITEMS_MAX3},
     {SETITEMS,     SETITEMS_PROP4,        SETITEMS_PAR4,          SETITEMS_MIN4,        SETITEMS_MAX4},
     {SETITEMS,     SETITEMS_PROP5,        SETITEMS_PAR5,          SETITEMS_MIN5,        SETITEMS_MAX5},
     {SETITEMS,     SETITEMS_PROP6,        SETITEMS_PAR6,          SETITEMS_MIN6,        SETITEMS_MAX6},
     {SETITEMS,     SETITEMS_PROP7,        SETITEMS_PAR7,          SETITEMS_MIN7,        SETITEMS_MAX7},
     {SETITEMS,     SETITEMS_PROP8,        SETITEMS_PAR8,          SETITEMS_MIN8,        SETITEMS_MAX8},
     {SETITEMS,     SETITEMS_PROP9,        SETITEMS_PAR9,          SETITEMS_MIN9,        SETITEMS_MAX9},
     {SETS,         SETS_FCODE1,           SETS_FPARAM1,           SETS_FMIN1,           SETS_FMAX1},
     {SETS,         SETS_FCODE2,           SETS_FPARAM2,           SETS_FMIN2,           SETS_FMAX2},
     {SETS,         SETS_FCODE3,           SETS_FPARAM3,           SETS_FMIN3,           SETS_FMAX3},
     {SETS,         SETS_FCODE4,           SETS_FPARAM4,           SETS_FMIN4,           SETS_FMAX4},
     {SETS,         SETS_FCODE5,           SETS_FPARAM5,           SETS_FMIN5,           SETS_FMAX5},
     {SETS,         SETS_FCODE6,           SETS_FPARAM6,           SETS_FMIN6,           SETS_FMAX6},
     {SETS,         SETS_FCODE7,           SETS_FPARAM7,           SETS_FMIN7,           SETS_FMAX7},
     {SETS,         SETS_FCODE8,           SETS_FPARAM8,           SETS_FMIN8,           SETS_FMAX8},
     {SETS,         SETS_PCODE2A,          SETS_PPARAM2A,          SETS_PMIN2A,          SETS_PMAX2A},
     {SETS,         SETS_PCODE2B,          SETS_PPARAM2B,          SETS_PMIN2B,          SETS_PMAX2B},
     {SETS,         SETS_PCODE3A,          SETS_PPARAM3A,          SETS_PMIN3A,          SETS_PMAX3A},
     {SETS,         SETS_PCODE3B,          SETS_PPARAM3B,          SETS_PMIN3B,          SETS_PMAX3B},
     {SETS,         SETS_PCODE4A,          SETS_PPARAM4A,          SETS_PMIN4A,          SETS_PMAX4A},
     {SETS,         SETS_PCODE4B,          SETS_PPARAM4B,          SETS_PMIN4B,          SETS_PMAX4B},
     {SETS,         SETS_PCODE5A,          SETS_PPARAM5A,          SETS_PMIN5A,          SETS_PMAX5A},
     {SETS,         SETS_PCODE5B,          SETS_PPARAM5B,          SETS_PMIN5B,          SETS_PMAX5B},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP1,     UNIQUEITEMS_PAR1,       UNIQUEITEMS_MIN1,     UNIQUEITEMS_MAX1},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP2,     UNIQUEITEMS_PAR2,       UNIQUEITEMS_MIN2,     UNIQUEITEMS_MAX2},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP3,     UNIQUEITEMS_PAR3,       UNIQUEITEMS_MIN3,     UNIQUEITEMS_MAX3},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP4,     UNIQUEITEMS_PAR4,       UNIQUEITEMS_MIN4,     UNIQUEITEMS_MAX4},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP5,     UNIQUEITEMS_PAR5,       UNIQUEITEMS_MIN5,     UNIQUEITEMS_MAX5},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP6,     UNIQUEITEMS_PAR6,       UNIQUEITEMS_MIN6,     UNIQUEITEMS_MAX6},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP7,     UNIQUEITEMS_PAR7,       UNIQUEITEMS_MIN7,     UNIQUEITEMS_MAX7},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP8,     UNIQUEITEMS_PAR8,       UNIQUEITEMS_MIN8,     UNIQUEITEMS_MAX8},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP9,     UNIQUEITEMS_PAR9,       UNIQUEITEMS_MIN9,     UNIQUEITEMS_MAX9},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP10,    UNIQUEITEMS_PAR10,      UNIQUEITEMS_MIN10,    UNIQUEITEMS_MAX10},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP11,    UNIQUEITEMS_PAR11,      UNIQUEITEMS_MIN11,    UNIQUEITEMS_MAX11},
     {UNIQUEITEMS,  UNIQUEITEMS_PROP12,    UNIQUEITEMS_PAR12,      UNIQUEITEMS_MIN12,    UNIQUEITEMS_MAX12},
     {NONE, 0, 0, 0, 0}
   };
   TXT_S * txt, * txt_table, * txt_prop, * txt_isc;
   int   i, y, r, txt_idx, prop, param, min, max, is_ok = TRUE, txt_ok = TRUE, old_txt,
         found, p, s, z,
         use_param, use_minmax;
   char  * str_prop, * str_param, * str_min, * str_max, * str;
   long  dw1, dw2, minmax_lo, minmax_hi;
   int   prop_stat_id[7] = {
            PROPERTIES_STAT1, PROPERTIES_STAT2, PROPERTIES_STAT3, PROPERTIES_STAT4,
            PROPERTIES_STAT5, PROPERTIES_STAT6, PROPERTIES_STAT7
         };


   txt_table = & glb_datas.txt[PROPPARMINMAX];
   for (i=0; i < PROPPARMINMAX_COL_MAX; i++)
   {
      if ((txt_table->col[i] == NULL) || (txt_table->col[i][0] == NULL))
      {
         printf("   * ERROR : Res\\Prop_Par_Min_Max.txt lack columns\n");
         return -1;
      }
   }

   txt_prop = & glb_datas.txt[PROPERTIES];
   if (test_col_must_be_present(PROPERTIES, PROPERTIES_CODE, TRUE))
      return -1;
   for (i=0; i < 7; i++)
   {
      if (test_col_must_be_present(PROPERTIES, prop_stat_id[i], TRUE))
         return -1;
   }

   txt_isc = & glb_datas.txt[ITEMSTATCOST];
   if (test_col_must_be_present(ITEMSTATCOST, ITEMSTATCOST_STAT, TRUE))
      return -1;
   if (test_col_must_be_present(ITEMSTATCOST, ITEMSTATCOST_SAVEBITS, TRUE))
      return -1;
   if (test_col_must_be_present(ITEMSTATCOST, ITEMSTATCOST_SAVEADD, TRUE))
      return -1;

   // check all possible propertie/param/min/max columns
   old_txt = -1;
   for (y=0;;y++)
   {
      txt_idx = data[y].txt;

      if (txt_idx == NONE)
      {
         // end
         return is_ok == TRUE ? 0 : -1;
      }

      if (txt_idx != old_txt)
      {
         txt_ok  = TRUE;
         old_txt = txt_idx;
      }

      if ((txt_idx < 0) || (txt_idx >= TXT_MAX))
         return -1;

      txt = & glb_datas.txt[txt_idx];

      prop  = data[y].prop;
      param = data[y].param;
      min   = data[y].min;
      max   = data[y].max;

      if (test_col_must_be_present(txt_idx, prop, FALSE))
         continue;
      if (test_col_must_be_present(txt_idx, param, FALSE))
         continue;
      if (test_col_must_be_present(txt_idx, min, FALSE))
         continue;
      if (test_col_must_be_present(txt_idx, max, FALSE))
         continue;

      // for all rows of that txt
      for (i=1; i < txt->nb_rows; i++)
      {
         // get row's datas
         str_prop = txt->col[prop][i];
         if (strlen(str_prop) == 0)
            continue;
         str_param = txt->col[param][i];
         str_min   = txt->col[min  ][i];
         str_max   = txt->col[max  ][i];

         // find the prop code in res\prop_par_min_max.txt
         found = FALSE;
         for (r=1; r < txt_table->nb_rows; r++)
         {
            str = txt_table->col[PROPPARMINMAX_PROPERTIE][r];

            if (strlen(str) == 0)
               continue;
            if (stricmp(str, "Expansion") == 0)
               continue;

            if (glb_datas.str_cmp_func(str, str_prop) == 0)
            {
               // found
               found = TRUE;

               // can be used ?
               str = txt_table->col[PROPPARMINMAX_CANBEUSED][r];
               if (strcmp(str, "1") != 0)
               {
                  // error
                  if (txt_ok == TRUE)
                  {
                     printf("\nIn %s :\n", txt->filename);
                     txt_ok = is_ok = FALSE;
                  }
                  printf(
                     "   * ERROR : Propertie in '%s' (%s) at row %i (%s) can't be used\n",
                     txt->header[prop],
                     str_prop,
                     i + 1,
                     txt->col[0][i]
                  );
               }

               // MinmaxElsePar ?
               use_param  = FALSE;
               use_minmax = FALSE;
               str = txt_table->col[PROPPARMINMAX_MINMAXELSEPAR][r];
               if (strcmp(str, "1") == 0)
               {
                  // try Min/Max
                  if ((strlen(str_min) == 0) && (strlen(str_max) == 0))
                  {
                     // try param
                     use_param = TRUE;
                     if (strlen(str_param) == 0)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) at row %i (%s) should use '%s' and '%s', or '%s'\n",
                           str_prop,
                           i + 1,
                           txt->col[0][i],
                           txt->header[min],
                           txt->header[max],
                           txt->header[param]
                        );
                     }
                  }
                  else
                  {
                     if ((strlen(str_min) == 0) || (strlen(str_max) == 0))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) at row %i (%s) should use Both '%s' and '%s' columns, or none\n",
                           str_prop,
                           i + 1,
                           txt->col[0][i],
                           txt->header[min],
                           txt->header[max]
                        );
                     }
                     else
                        use_minmax = TRUE;
                  }
               }
               else
               {
                  // par ?
                  str = txt_table->col[PROPPARMINMAX_PAR][r];
                  if (strcmp(str, "1") == 0)
                  {
                     use_param;
                     if (strlen(str_param) == 0)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' at row %i (%s) require a value\n",
                           str_prop,
                           txt->header[param],
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }

                  // min ?
                  str = txt_table->col[PROPPARMINMAX_MIN][r];
                  if (strcmp(str, "1") == 0)
                  {
                     use_minmax = TRUE;
                     if (strlen(str_min) == 0)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' at row %i (%s) require a value\n",
                           str_prop,
                           txt->header[min],
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }

                  // max ?
                  str = txt_table->col[PROPPARMINMAX_MAX][r];
                  if (strcmp(str, "1") == 0)
                  {
                     use_minmax = TRUE;
                     if (strlen(str_max) == 0)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' at row %i (%s) require a value\n",
                           str_prop,
                           txt->header[max],
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
               }


               // param low
               if (use_param)
               {
                  dw1 = atol(str_param);
                  str = txt_table->col[PROPPARMINMAX_PARLO][r];
                  if (strlen(str) != 0)
                  {
                     dw2 = atol(str);
                     if (dw1 < dw2)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be >= than %li\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           i + 1,
                           txt->col[0][i],
                           dw2
                        );
                     }
                  }

                  // param high
                  str = txt_table->col[PROPPARMINMAX_PARHI][r];
                  if (strlen(str) != 0)
                  {
                     dw2 = atol(str);
                     if (dw1 > dw2)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be <= than %li\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           i + 1,
                           txt->col[0][i],
                           dw2
                        );
                     }
                  }
               }

               // minmax auto
               if (use_minmax)
               {
                  minmax_lo = 0x80000000L;
                  minmax_hi = 0x7FFFFFFFL;
                  if ( (stricmp(txt_table->col[PROPPARMINMAX_MINLO][r], "auto") == 0) ||
                       (stricmp(txt_table->col[PROPPARMINMAX_MINHI][r], "auto") == 0) ||
                       (stricmp(txt_table->col[PROPPARMINMAX_MAXLO][r], "auto") == 0) ||
                       (stricmp(txt_table->col[PROPPARMINMAX_MAXHI][r], "auto") == 0)
                     )
                  {
                     // use ItemStatCost.txt

                     // find line in properties.txt
                     for (p=1; p < txt_prop->nb_rows; p++)
                     {
                        str = txt_prop->col[PROPERTIES_CODE][p];
                        if (strlen(str) == 0)
                           continue;
                        if (stricmp(str, "Expansion") == 0)
                           continue;
                        if (glb_datas.str_cmp_func(str, str_prop) == 0)
                        {
                           // found prop line, read all stats
                           for (s=0; s < 7; s++)
                           {
                              str = txt_prop->col[ prop_stat_id[s] ][p];
                              if (strlen(str) == 0)
                                 continue;
                              for (z=1; z < txt_isc->nb_rows; z++)
                              {
                                 if (glb_datas.str_cmp_func(
                                        str, txt_isc->col[ITEMSTATCOST_STAT][z]) == 0)
                                 {
                                    // found stat, read savebits & saveadd
                                    dw1 = atol(txt_isc->col[ITEMSTATCOST_SAVEADD][z]);
                                    dw1 = - dw1;
                                    if (dw1 < minmax_lo)
                                       minmax_lo = dw1;

                                    dw2 = atol(txt_isc->col[ITEMSTATCOST_SAVEBITS][z]);
                                    dw2 = (1 << dw2) + dw1 - 1;
                                    if (dw2 > minmax_hi)
                                       minmax_hi = dw2;
                                 }
                              }
                           }
                           break;
                        }
                     }
                  }

                  // min low
                  dw1 = atol(str_min);
                  str = txt_table->col[PROPPARMINMAX_MINLO][r];
                  if (stricmp(str, "auto") == 0)
                  {
                     if (dw1 < minmax_lo)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be >= than %li (check ItemStatCost.txt)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i],
                           minmax_lo
                        );
                     }
                  }
                  else if (strlen(str) != 0)
                  {
                     dw2 = atol(str);
                     if (dw1 < dw2)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be >= than %li (check Res\\Prop_Par_Min_Max.txt)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i],
                           dw2
                        );
                     }
                  }

                  // min high
                  str = txt_table->col[PROPPARMINMAX_MINHI][r];
                  if (stricmp(str, "auto") == 0)
                  {
                     if (dw1 > minmax_hi)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be <= than %li (check ItemStatCost.txt)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i],
                           minmax_hi
                        );
                     }
                  }
                  else if (strlen(str) != 0)
                  {
                     dw2 = atol(str);
                     if (dw1 > dw2)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be <= than %li (check Res\\Prop_Par_Min_Max.txt)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i],
                           dw2
                        );
                     }
                  }

                  // max low
                  dw1 = atol(str_max);
                  str = txt_table->col[PROPPARMINMAX_MAXLO][r];
                  if (stricmp(str, "auto") == 0)
                  {
                     if (dw1 < minmax_lo)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be >= than %li (check ItemStatCost.txt)\n",
                           str_prop,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i],
                           minmax_lo
                        );
                     }
                  }
                  else if (strlen(str) != 0)
                  {
                     dw2 = atol(str);
                     if (dw1 < dw2)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be >= than %li (check Res\\Prop_Par_Min_Max.txt)\n",
                           str_prop,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i],
                           dw2
                        );
                     }
                  }

                  // max high
                  str = txt_table->col[PROPPARMINMAX_MAXHI][r];
                  if (stricmp(str, "auto") == 0)
                  {
                     if (dw1 > minmax_hi)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be <= than %li (check ItemStatCost.txt)\n",
                           str_prop,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i],
                           minmax_hi
                        );
                     }
                  }
                  else if (strlen(str) != 0)
                  {
                     dw2 = atol(str);
                     if (dw1 > dw2)
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) at row %i (%s) should be <= than %li (check Res\\Prop_Par_Min_Max.txt)\n",
                           str_prop,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i],
                           dw2
                        );
                     }
                  }
               }

               // param vs min
               dw1 = atol(str_param);
               dw2 = atol(str_min);
               str = txt_table->col[PROPPARMINMAX_PARVSMIN][r];
               if (strlen(str) != 0)
               {
                  if (strcmp(str, "<") == 0)
                  {
                     if ( ! (dw1 < dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be < than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, "<=") == 0)
                  {
                     if ( ! (dw1 <= dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be <= than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if ((strcmp(str, "=") == 0) | (strcmp(str, "==") == 0))
                  {
                     if ( ! (dw1 == dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be equal to '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, ">=") == 0)
                  {
                     if ( ! (dw1 >= dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be >= than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, ">") == 0)
                  {
                     if ( ! (dw1 > dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be > than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if ((strcmp(str, "<>") == 0) | (strcmp(str, "!=") == 0))
                  {
                     if ( ! (dw1 != dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be different than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[min],
                           str_min,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else
                  {
                     // error
                  }
               }

               // param vs max
               dw2 = atol(str_max);
               str = txt_table->col[PROPPARMINMAX_PARVSMAX][r];
               if (strlen(str) != 0)
               {
                  if (strcmp(str, "<") == 0)
                  {
                     if ( ! (dw1 < dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be < than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, "<=") == 0)
                  {
                     if ( ! (dw1 <= dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be <= than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if ((strcmp(str, "=") == 0) | (strcmp(str, "==") == 0))
                  {
                     if ( ! (dw1 == dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be equal to '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, ">=") == 0)
                  {
                     if ( ! (dw1 >= dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be >= than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, ">") == 0)
                  {
                     if ( ! (dw1 > dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be > than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if ((strcmp(str, "<>") == 0) | (strcmp(str, "!=") == 0))
                  {
                     if ( ! (dw1 != dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be different than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[param],
                           str_param,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else
                  {
                     // error
                  }
               }

               // min vs max
               dw1 = atol(str_min);
               dw2 = atol(str_max);
               str = txt_table->col[PROPPARMINMAX_MINVSMAX][r];
               if (strlen(str) != 0)
               {
                  if (strcmp(str, "<") == 0)
                  {
                     if ( ! (dw1 < dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be < than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, "<=") == 0)
                  {
                     if ( ! (dw1 <= dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be <= than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if ((strcmp(str, "=") == 0) | (strcmp(str, "==") == 0))
                  {
                     if ( ! (dw1 == dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be equal to '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, ">=") == 0)
                  {
                     if ( ! (dw1 >= dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be >= than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if (strcmp(str, ">") == 0)
                  {
                     if ( ! (dw1 > dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be > than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else if ((strcmp(str, "<>") == 0) | (strcmp(str, "!=") == 0))
                  {
                     if ( ! (dw1 != dw2))
                     {
                        // error
                        if (txt_ok == TRUE)
                        {
                           printf("\nIn %s :\n", txt->filename);
                           txt_ok = is_ok = FALSE;
                        }
                        printf(
                           "   * ERROR : Propertie (%s) : '%s' (%s) should be different than '%s' (%s), row %i (%s)\n",
                           str_prop,
                           txt->header[min],
                           str_min,
                           txt->header[max],
                           str_max,
                           i + 1,
                           txt->col[0][i]
                        );
                     }
                  }
                  else
                  {
                     // error
                  }
               }
               break;
            }
         }
         if (found == FALSE)
         {
            // error
         }
      }
   }
}


// ========================================================================================
// Test matching pair of brackets in formulas coumns
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int test_brackets(void)
{
   static struct
   {
      TXT_ENUM txt;
      int      col;
   } data[] = {
   // txt           col
   // ------------  --------------------- 
     {ARMOR,        AWM_CALC1},
     {ARMOR,        AWM_CALC2},
     {ARMOR,        AWM_CALC3},
     {ARMOR,        AWM_LEN},
     {ARMOR,        AWM_SPELLDESCCALC},
     {AUTOMAGIC,    AUTOMAGIC_MOD1PARAM},
     {AUTOMAGIC,    AUTOMAGIC_MOD2PARAM},
     {AUTOMAGIC,    AUTOMAGIC_MOD3PARAM},
     {GEMS,         GEMS_HELMMOD1PARAM},
     {GEMS,         GEMS_HELMMOD2PARAM},
     {GEMS,         GEMS_HELMMOD3PARAM},
     {GEMS,         GEMS_SHIELDMOD1PARAM},
     {GEMS,         GEMS_SHIELDMOD2PARAM},
     {GEMS,         GEMS_SHIELDMOD3PARAM},
     {GEMS,         GEMS_WEAPONMOD1PARAM},
     {GEMS,         GEMS_WEAPONMOD2PARAM},
     {GEMS,         GEMS_WEAPONMOD3PARAM},
     {MAGICPREFIX,  MAGICAFFIX_MOD1PARAM},
     {MAGICPREFIX,  MAGICAFFIX_MOD2PARAM},
     {MAGICPREFIX,  MAGICAFFIX_MOD3PARAM},
     {MAGICSUFFIX,  MAGICAFFIX_MOD1PARAM},
     {MAGICSUFFIX,  MAGICAFFIX_MOD2PARAM},
     {MAGICSUFFIX,  MAGICAFFIX_MOD3PARAM},
     {MISC,         AWM_CALC1},
     {MISC,         AWM_CALC2},
     {MISC,         AWM_CALC3},
     {MISC,         AWM_LEN},
     {MISC,         AWM_SPELLDESCCALC},
     {MISSILES,     MISSILES_CHITCALC1},
     {MISSILES,     MISSILES_CLTCALC1},
     {MISSILES,     MISSILES_DMGCALC1},
     {MISSILES,     MISSILES_DMGSYMPERCALC},
     {MISSILES,     MISSILES_EDMGSYMPERCALC},
     {MISSILES,     MISSILES_SHITCALC1},
     {MISSILES,     MISSILES_SRVCALC1},
     {RUNES,        RUNES_T1PARAM1},
     {RUNES,        RUNES_T1PARAM2},
     {RUNES,        RUNES_T1PARAM3},
     {RUNES,        RUNES_T1PARAM4},
     {RUNES,        RUNES_T1PARAM5},
     {RUNES,        RUNES_T1PARAM6},
     {RUNES,        RUNES_T1PARAM7},
     {SETITEMS,     SETITEMS_APAR1A},
     {SETITEMS,     SETITEMS_APAR1B},
     {SETITEMS,     SETITEMS_APAR2A},
     {SETITEMS,     SETITEMS_APAR2B},
     {SETITEMS,     SETITEMS_APAR3A},
     {SETITEMS,     SETITEMS_APAR3B},
     {SETITEMS,     SETITEMS_APAR4A},
     {SETITEMS,     SETITEMS_APAR4B},
     {SETITEMS,     SETITEMS_APAR5A},
     {SETITEMS,     SETITEMS_APAR5B},
     {SETITEMS,     SETITEMS_PAR1},
     {SETITEMS,     SETITEMS_PAR2},
     {SETITEMS,     SETITEMS_PAR3},
     {SETITEMS,     SETITEMS_PAR4},
     {SETITEMS,     SETITEMS_PAR5},
     {SETITEMS,     SETITEMS_PAR6},
     {SETITEMS,     SETITEMS_PAR7},
     {SETITEMS,     SETITEMS_PAR8},
     {SETITEMS,     SETITEMS_PAR9},
     {SETS,         SETS_FPARAM1},
     {SETS,         SETS_FPARAM2},
     {SETS,         SETS_FPARAM3},
     {SETS,         SETS_FPARAM4},
     {SETS,         SETS_FPARAM5},
     {SETS,         SETS_FPARAM6},
     {SETS,         SETS_FPARAM7},
     {SETS,         SETS_FPARAM8},
     {SETS,         SETS_PPARAM2A},
     {SETS,         SETS_PPARAM2B},
     {SETS,         SETS_PPARAM3A},
     {SETS,         SETS_PPARAM3B},
     {SETS,         SETS_PPARAM4A},
     {SETS,         SETS_PPARAM4B},
     {SETS,         SETS_PPARAM5A},
     {SETS,         SETS_PPARAM5B},
     {SKILLDESC,    SKILLDESC_DDAMCALC1},
     {SKILLDESC,    SKILLDESC_DDAMCALC2},
     {SKILLDESC,    SKILLDESC_DESCCALCA1},
     {SKILLDESC,    SKILLDESC_DESCCALCA2},
     {SKILLDESC,    SKILLDESC_DESCCALCA3},
     {SKILLDESC,    SKILLDESC_DESCCALCA4},
     {SKILLDESC,    SKILLDESC_DESCCALCA5},
     {SKILLDESC,    SKILLDESC_DESCCALCA6},
     {SKILLDESC,    SKILLDESC_DESCCALCB1},
     {SKILLDESC,    SKILLDESC_DESCCALCB2},
     {SKILLDESC,    SKILLDESC_DESCCALCB3},
     {SKILLDESC,    SKILLDESC_DESCCALCB4},
     {SKILLDESC,    SKILLDESC_DESCCALCB5},
     {SKILLDESC,    SKILLDESC_DESCCALCB6},
     {SKILLDESC,    SKILLDESC_DSC2CALCA1},
     {SKILLDESC,    SKILLDESC_DSC2CALCA2},
     {SKILLDESC,    SKILLDESC_DSC2CALCA3},
     {SKILLDESC,    SKILLDESC_DSC2CALCA4},
     {SKILLDESC,    SKILLDESC_DSC2CALCB1},
     {SKILLDESC,    SKILLDESC_DSC2CALCB2},
     {SKILLDESC,    SKILLDESC_DSC2CALCB3},
     {SKILLDESC,    SKILLDESC_DSC2CALCB4},
     {SKILLDESC,    SKILLDESC_DSC3CALCA1},
     {SKILLDESC,    SKILLDESC_DSC3CALCA2},
     {SKILLDESC,    SKILLDESC_DSC3CALCA3},
     {SKILLDESC,    SKILLDESC_DSC3CALCA4},
     {SKILLDESC,    SKILLDESC_DSC3CALCA5},
     {SKILLDESC,    SKILLDESC_DSC3CALCA6},
     {SKILLDESC,    SKILLDESC_DSC3CALCA7},
     {SKILLDESC,    SKILLDESC_DSC3CALCB1},
     {SKILLDESC,    SKILLDESC_DSC3CALCB2},
     {SKILLDESC,    SKILLDESC_DSC3CALCB3},
     {SKILLDESC,    SKILLDESC_DSC3CALCB4},
     {SKILLDESC,    SKILLDESC_DSC3CALCB5},
     {SKILLDESC,    SKILLDESC_DSC3CALCB6},
     {SKILLDESC,    SKILLDESC_DSC3CALCB7},
     {SKILLDESC,    SKILLDESC_P1DMMAX},
     {SKILLDESC,    SKILLDESC_P1DMMIN},
     {SKILLDESC,    SKILLDESC_P2DMMAX},
     {SKILLDESC,    SKILLDESC_P2DMMIN},
     {SKILLDESC,    SKILLDESC_P3DMMAX},
     {SKILLDESC,    SKILLDESC_P3DMMIN},
     {SKILLS,       SKILLS_AURALENCALC},
     {SKILLS,       SKILLS_AURARANGECALC},
     {SKILLS,       SKILLS_AURASTATCALC1},
     {SKILLS,       SKILLS_AURASTATCALC2},
     {SKILLS,       SKILLS_AURASTATCALC3},
     {SKILLS,       SKILLS_AURASTATCALC4},
     {SKILLS,       SKILLS_AURASTATCALC5},
     {SKILLS,       SKILLS_AURASTATCALC6},
     {SKILLS,       SKILLS_CALC1},
     {SKILLS,       SKILLS_CALC2},
     {SKILLS,       SKILLS_CALC3},
     {SKILLS,       SKILLS_CALC4},
     {SKILLS,       SKILLS_CLTCALC1},
     {SKILLS,       SKILLS_CLTCALC2},
     {SKILLS,       SKILLS_CLTCALC3},
     {SKILLS,       SKILLS_DMGSYMPERCALC},
     {SKILLS,       SKILLS_EDMGSYMPERCALC},
     {SKILLS,       SKILLS_ELENSYMPERCALC},
     {SKILLS,       SKILLS_PASSIVECALC1},
     {SKILLS,       SKILLS_PASSIVECALC2},
     {SKILLS,       SKILLS_PASSIVECALC3},
     {SKILLS,       SKILLS_PASSIVECALC4},
     {SKILLS,       SKILLS_PASSIVECALC5},
     {SKILLS,       SKILLS_PERDELAY},
     {SKILLS,       SKILLS_PETMAX},
     {SKILLS,       SKILLS_PRGCALC1},
     {SKILLS,       SKILLS_PRGCALC2},
     {SKILLS,       SKILLS_PRGCALC3},
     {SKILLS,       SKILLS_SKPOINTS},
     {SKILLS,       SKILLS_SUMSK1CALC},
     {SKILLS,       SKILLS_SUMSK2CALC},
     {SKILLS,       SKILLS_SUMSK3CALC},
     {SKILLS,       SKILLS_SUMSK4CALC},
     {SKILLS,       SKILLS_SUMSK5CALC},
     {SKILLS,       SKILLS_TOHITCALC},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR1},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR10},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR11},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR12},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR2},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR3},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR4},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR5},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR6},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR7},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR8},
     {UNIQUEITEMS,  UNIQUEITEMS_PAR9},
     {WEAPONS,      AWM_CALC1},
     {WEAPONS,      AWM_CALC2},
     {WEAPONS,      AWM_CALC3},
     {WEAPONS,      AWM_LEN},
     {WEAPONS,      AWM_SPELLDESCCALC},
     {NONE, 0}
   };
   TXT_S * txt;
   int   old_txt, txt_idx, is_ok = TRUE, txt_ok = TRUE, col_idx, len, c;
   int   brackets_count;
   long  y, i;
   char  * str;


   // for all txt to check
   old_txt = -1;
   for (y=0;;y++)
   {
      txt_idx = data[y].txt;

      if (txt_idx == NONE)
      {
         // end
         return is_ok == TRUE ? 0 : -1;
      }

      if (txt_idx != old_txt)
      {
         txt_ok  = TRUE;
         old_txt = txt_idx;
      }

      if ((txt_idx < 0) || (txt_idx >= TXT_MAX))
         return -1;

      txt = & glb_datas.txt[txt_idx];
      if (txt == NULL)
         continue;


      col_idx = data[y].col;

      if (test_col_must_be_present(txt_idx, col_idx, FALSE))
         continue;

      // for all rows of that txt
      for (i=1; i < txt->nb_rows; i++)
      {
         // get string of the column to check
         str = txt->col[col_idx][i];
         len = strlen(str);
         if (len == 0)
            continue;

         // check matching brackets
         brackets_count = 0;
         for (c=0; c < len; c++)
         {
            if (str[c] == '(')
               brackets_count++;
            else if (str[c] == ')')
            {
               brackets_count--;
               if (brackets_count == -1)
               {
                  if (txt_ok == TRUE)
                  {
                     printf("\nIn %s :\n", txt->filename);
                     txt_ok = is_ok = FALSE;
                  }
                  printf(
                     "   * ERROR : at Row (%li), in column '%s' found a "
                     "closing bracket without matching opening bracket : %s\n",
                     i + 1,
                     txt->header[col_idx],
                     str
                  );
                  c = len; // stop the check
               }
            }
         }

         // if not all brackets are matching...
         if (brackets_count >= 1)
         {
            // ... it's an error
            if (txt_ok == TRUE)
            {
               printf("\nIn %s :\n", txt->filename);
               txt_ok = is_ok = FALSE;
            }
            printf(
               "   * ERROR : at Row (%li), in column '%s' brackets don't match "
               "(%i closing bracket%s missing) : %s\n",
               i + 1,
               txt->header[col_idx],
               brackets_count,
               brackets_count == 1 ? " is" : "s are",
               str
            );
         }
      }
   }
}
