#ifndef _TEST_KEYS_H_

#define _TEST_KEYS_H_

int test_unicity_in_all_txt (void);
int test_external_keys      (void);

#endif
