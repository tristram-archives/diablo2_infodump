#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "error.h"
#include "filmem.h"
#include "txtread.h"
#include "test.h"
#include "mpq\mpqtypes.h"
#include "anims.h"
#include "globals.h"


// tables
MODE_TABLE_S mode_table[MONMODE_MAX] = {
   {"DT", MONSTATS2_MDT, MONSTATS2_DDT},
   {"NU", MONSTATS2_MNU, MONSTATS2_DNU},
   {"WL", MONSTATS2_MWL, MONSTATS2_DWL},
   {"GH", MONSTATS2_MGH, MONSTATS2_DGH},
   {"A1", MONSTATS2_MA1, MONSTATS2_DA1},
   {"A2", MONSTATS2_MA2, MONSTATS2_DA2},
   {"BL", MONSTATS2_MBL, MONSTATS2_DBL},
   {"SC", MONSTATS2_MSC, MONSTATS2_DSC},
   {"S1", MONSTATS2_MS1, MONSTATS2_DS1},
   {"S2", MONSTATS2_MS2, MONSTATS2_DS2},
   {"S3", MONSTATS2_MS3, MONSTATS2_DS3},
   {"S4", MONSTATS2_MS4, MONSTATS2_DS4},
   {"DD", MONSTATS2_MDD, MONSTATS2_DDD},
   {"KB", MONSTATS2_MKB, MONSTATS2_DKB},
   {"SQ", MONSTATS2_MSQ, MONSTATS2_DSQ},
   {"RN", MONSTATS2_MRN, MONSTATS2_DRN}
};

LAYER_TABLE_S layer_table[MONLAYER_MAX] = {
   {"HD", MONSTATS2_HD, MONSTATS2_HDV},
   {"TR", MONSTATS2_TR, MONSTATS2_TRV},
   {"LG", MONSTATS2_LG, MONSTATS2_LGV},
   {"RA", MONSTATS2_RA, MONSTATS2_RAV},
   {"LA", MONSTATS2_LA, MONSTATS2_LAV},
   {"RH", MONSTATS2_RH, MONSTATS2_RHV},
   {"LH", MONSTATS2_LH, MONSTATS2_LHV},
   {"SH", MONSTATS2_SH, MONSTATS2_SHV},
   {"S1", MONSTATS2_S1, MONSTATS2_S1V},
   {"S2", MONSTATS2_S2, MONSTATS2_S2V},
   {"S3", MONSTATS2_S3, MONSTATS2_S3V},
   {"S4", MONSTATS2_S4, MONSTATS2_S4V},
   {"S5", MONSTATS2_S5, MONSTATS2_S5V},
   {"S6", MONSTATS2_S6, MONSTATS2_S6V},
   {"S7", MONSTATS2_S7, MONSTATS2_S7V},
   {"S8", MONSTATS2_S8, MONSTATS2_S8V}
};


// ========================================================================================
// compute the hash value of a cof name
// ========================================================================================
UBYTE anims_animdata_get_hash(char * cofname)
{
   UBYTE c;
   int   hash;
   char  strtmp[8];
   int   i;


   strncpy(strtmp, cofname, 7);
   strupr(strtmp);
   hash = 0;
   for (i=0; i < 7; i++)
      hash += strtmp[i];
   c = (UBYTE) hash;
   return c;
}


// ========================================================================================
// get a pointer to a AnimData.d2 record, given a cof name
// ========================================================================================
D2_ANIMDATA_HEADER_S * anims_animdata_get_record(char * cofname)
{
   D2_ANIMDATA_HEADER_S * cof_header;
   UBYTE                hash;
   long                 r;


   if (glb_datas.animdata.buffer == NULL)
   {
      printf("anims_animdata_get_record(), ERROR : AnimData.d2 not in memory\n");
      return NULL;
   }

   hash = anims_animdata_get_hash(cofname);
   cof_header = glb_datas.animdata_hash[hash];
   if (cof_header == NULL)
   {
      printf("anims_animdata_get_record(), ERROR : %s not present in AnimData.d2\n", cofname);
      return NULL;
   }
   for (r=0; r < glb_datas.animdata_nb_rec[hash]; r++)
   {
      if (stricmp(cof_header->cof_name, cofname) == 0)
         return cof_header;
      cof_header++;
   }

   // end
   printf("anims_animdata_get_record(), ERROR : %s not present in AnimData.d2\n", cofname);
   return NULL;
}


// ========================================================================================
// read AnimData.d2 and fill animdata_hash[]
// ========================================================================================
int anims_animdata_hash(void)
{
   UBYTE * buffer;
   long  * dw_ptr;
   long  cursor, size, nb_rec, r;
   int   i;


   buffer = glb_datas.animdata.buffer;
   if (buffer == NULL)
   {
      printf("anims_animdata_hash(), ERROR : AnimData.d2 not in memory\n");
      return -1;
   }
   size = glb_datas.animdata.length;

   cursor = 0;
   for (i=0; i < 256; i++)
   {
      if ((cursor + 4) <= size) // nb_rec require 4 bytes
      {
         // read nb records
         dw_ptr = (long *) (buffer + cursor);
         nb_rec = * dw_ptr;
         glb_datas.animdata_nb_rec[i] = nb_rec;
         cursor += 4;

         // save pointer to 1st record
         glb_datas.animdata_hash[i] = (D2_ANIMDATA_HEADER_S *) (buffer + cursor);

         // skip records
         for (r=0; r < nb_rec; r++)
         {
            // read a record
            if ((cursor + 160) <= size) // a record is 160 bytes
               cursor += 160;
         }
      }
   }

   // end
   return 0;
}


// ========================================================================================
// TXT, D2, COF and DCC must match each others
// we check in AnimData.d2, cmncof_a?.d2, chars_cof.d2, *.cof, *.dcc, monsters.txt 
// ouput :
//    0 if ok, non-zero if error
// ========================================================================================
int anims_dummy(void)
{
   D2_ANIMDATA_HEADER_S * cof_header;
   COF_S                * ptr_cof;
   TXT_S                * ptr_txt  = & glb_datas.txt[MONSTATS],
                        * ptr_txt2 = & glb_datas.txt[MONSTATS2],
                        * ptr_monmode = & glb_datas.txt[MONMODE];
   long                 size, r, r2;
   char                 * str, * str2, * vstr, buffer[60];
   int                  a, d, m, c, l, v, i, length;
   char                 strtmp[80],
                        * kb_token;
   long                 cof_dir, cof_fpd, animdata_fpd, mon_dir;


   // checks
   if (ptr_monmode == NULL)
   {
      printf("anims_dummy(), ERROR : MonMode.txt not in memory\n");
      return -1;
   }
   if (ptr_monmode->nb_rows < 17)
   {
      printf("anims_dummy(), ERROR : MonMode.txt has less than 17 rows\n");
      return -1;
   }
   kb_token = ptr_monmode->col[MONMODE_TOKEN][14]; // knockback

   if (ptr_txt == NULL)
   {
      printf("anims_dummy(), ERROR : MonStats.txt not in memory\n");
      return -1;
   }

   if (ptr_txt2 == NULL)
   {
      printf("anims_dummy(), ERROR : MonStats2.txt not in memory\n");
      return -1;
   }

   glb_datas.cof_not_loaded = fopen("cof_not_loaded.txt", "wt");
   if (glb_datas.cof_not_loaded == NULL)
   {
      printf("anims_dummy(), ERROR : can't create file cof_not_loaded.txt\n");
      return -1;
   }

   // malloc of monsters useable datas
   size = ptr_txt->nb_rows * sizeof(ANIM_MONDATA_S);
   glb_datas.ptr_mondata = (ANIM_MONDATA_S *) malloc(size);
   if (glb_datas.ptr_mondata == NULL)
   {
      printf(
         "anims_dummy(), ERROR : can't allocate %li bytes for glb_datas.ptr_mondata\n",
         size
      );
      return -1;
   }
   memset(glb_datas.ptr_mondata, 0, size);
   glb_datas.mondata_num = ptr_txt->nb_rows; 

   // for all monsters in MonStats.txt, get our useable datas
   for (r = 1; r < ptr_txt->nb_rows; r++)
   {
      // we're working on enabled monsters only
      printf("\nrow=%i", r+1);
      str = ptr_txt->col[MONSTATS_ENABLED][r];
      if (atoi(str) == 0)
      {
         // not enable, skip this monster
         printf("not enabled\n");
         continue;
      }

      // get token
      str = ptr_txt->col[MONSTATS_CODE][r];
      strncpy(glb_datas.ptr_mondata[r].token, str, 2);
      strupr(glb_datas.ptr_mondata[r].token); // token in uppercase
      printf(", token=<%s>", glb_datas.ptr_mondata[r].token);

      // search MonStats2 row
      str = ptr_txt->col[MONSTATS_MONSTATSEX][r];
      for (r2 = 1; r2 < ptr_txt2->nb_rows; r2++)
      {
         str2 = ptr_txt2->col[MONSTATS2_ID][r2];
         if (stricmp(str, str2) != 0)
            continue;

         // found row in MonStats2.txt

         // get Base Weapon
         strncpy(
            glb_datas.ptr_mondata[r].base_weap,
            ptr_txt2->col[MONSTATS2_BASEW][r2],
            3
         );
         strupr(glb_datas.ptr_mondata[r].base_weap); // Base Weapon in uppercase
         printf("\n   BaseW=<%s>\n", glb_datas.ptr_mondata[r].base_weap);

         // get modes activation state
         for (m = MDT; m < MONMODE_MAX; m++)
         {
            c = mode_table[m].active_col;
            a = atoi(ptr_txt2->col[c][r2]);
            glb_datas.ptr_mondata[r].mode[m].active = a;
            if (a == 0)
               continue;

            // mode is active, get directions
            c = mode_table[m].directions_col;
            d = atoi(ptr_txt2->col[c][r2]);
            glb_datas.ptr_mondata[r].mode[m].directions = d;
            if ((d == 1) || (d == 4) || (d == 8) || (d == 16) || (d == 32))
            {
               // ok
               printf(" %s=%2i", mode_table[m].str, d);
            }
            else
            {
               // error
               printf(
                  "\nanims_dummy(), ERROR : "
                  "in MonStats2.txt, row %i with '%s' = '%s' "
                  "have invalid direction (%s) at column '%s'\n",
                  r2 + 1,
                  ptr_txt->header[MONSTATS2_ID],
                  str,
                  ptr_txt2->col[c][r2],
                  ptr_txt->header[c]
               );
               return -1;
            }

            // build the cof filename in a mpq
            sprintf(
               strtmp,
               "%s\\%s\\Cof\\%s%s%s.cof",
               glb_datas.moncof_path_base,
               glb_datas.ptr_mondata[r].token,
               glb_datas.ptr_mondata[r].token,
               m == MKB ? kb_token : mode_table[m].str,
               glb_datas.ptr_mondata[r].base_weap
            );

            // if it is the token GM, FE or FK we load the HTH BaseWeap instead
            //    (only for the DT and DD Modes)
            if ((m == MDD) || (m == MDT))
            {
               if ( (stricmp(glb_datas.ptr_mondata[r].token, "GM") == 0) ||
                    (stricmp(glb_datas.ptr_mondata[r].token, "FE") == 0) ||
                    (stricmp(glb_datas.ptr_mondata[r].token, "FK") == 0)
                  )
               {
                  sprintf(
                     strtmp,
                     "%s\\%s\\Cof\\%s%s%s.cof",
                     glb_datas.moncof_path_base,
                     glb_datas.ptr_mondata[r].token,
                     glb_datas.ptr_mondata[r].token,
                     m == MKB ? kb_token : mode_table[m].str,
                     "HTH" // we force the use of the HTH BaseWeapon
                  );
               }
            }

            // load COF except if it is a sequence
            if (m != MSQ)
            {
               // save cof name
               length = strlen(strtmp);
               if (length >= 11)
               {
                  strncpy(
                     glb_datas.ptr_mondata[r].mode[m].cof_name,
                     strtmp + length - 11,
                     7
                  );
               }
               else
               {
                  strncpy(
                     glb_datas.ptr_mondata[r].mode[m].cof_name,
                     strtmp,
                     7
                  );
               }

               // load cof
               printf("\nCOF to load : %s\n", strtmp);
               glb_datas.ptr_mondata[r].mode[m].cof_buffer = d2file_extract(
                  strtmp,
                  & glb_datas.ptr_mondata[r].mode[m].cof_length,
                  & glb_datas.ptr_mondata[r].mode[m].extraction
               );
               if (glb_datas.ptr_mondata[r].mode[m].cof_buffer == NULL)
               {
                  fprintf(glb_datas.cof_not_loaded, "can't load %s\n", strtmp);
               }
            }
         }

         // get layers variants
         for (l = LHD; l < MONLAYER_MAX; l++)
         {
            c = layer_table[l].active_col;
            a = atoi(ptr_txt2->col[c][r2]);
            glb_datas.ptr_mondata[r].layer[l].active = a;
            if (a == 0)
               continue;

            // layer is active, get all variants for this layer

            // buffer will have the string without starting quote to analyse
            c = layer_table[l].variants_col;
            str2 = ptr_txt2->col[c][r2];
            memset(buffer, 0, sizeof(buffer));
            if (str2[0] == '\"')
            {
               if (strlen(str2) == 2)
               {
                  // string = "" --> empty cell, but layer active --> 'lit'
                  strcpy(buffer, "lit");
               }
               else
               {
                  // skip 1st quote char, then copy 12 tokens * 4 char max = 48 chars
                  strncpy(buffer, str2+1, 48); 
               }
            }
            else
            {
               if (strlen(str2) == 0)
               {
                  // empty cell, but layer active --> 'lit'
                  strcpy(buffer, "lit");
               }
               else
                  strncpy(buffer, str2, 48); // 12 tokens * 4 char max = 48
            }

            // analyse buffer and extract individual variants
            v = 0;
            vstr = strtok(buffer, ",\"");
            while ((vstr != NULL) && (v < 12))
            {
               // only if not "nil"
               if (stricmp(vstr, "nil") != 0)
               {
                  // save variant, but only if not already in list
                  for (i=0; i < v; i++)
                  {
                     if (stricmp(glb_datas.ptr_mondata[r].layer[l].variant[i], vstr) == 0)
                        break;
                  }
                  if (i >= v)
                  {
                     // wasn't already in list, add it
                     strncpy(glb_datas.ptr_mondata[r].layer[l].variant[v], vstr, 3);
                     v++;
                  }
               }

               // next variant in list
               vstr = strtok(NULL, ",\"");
            }
         }

         // display layers
         for (l = LHD; l < MONLAYER_MAX; l++)
         {
            if (glb_datas.ptr_mondata[r].layer[l].active == 1)
            {
               printf("   %s=", layer_table[l].str);
               for (v=0; v < 12; v++)
               {
                  if (glb_datas.ptr_mondata[r].layer[l].variant[v][0] != 0x00)
                     printf(" <%s>", glb_datas.ptr_mondata[r].layer[l].variant[v]);
               }
               printf("\n");
            }
         }
      
         // process next monster in MonStats.txt
         break;
      }

      // we have search in all MonStats2.txt rows, but couldn't find it
      if (r2 >= ptr_txt2->nb_rows)
         printf("\nanims_dummy(), ERROR : didn't found '%s' in MonStats2.Id\n", str);

      // next monster
      printf("\n");
      fflush(stdout);
   }

   // we now have all tokens, layers, variants, modes, WeaponClass of all monsters
   // we'll check directions and frames per directions with AnimData.d2 and cmncof_a?.d2

   // load animdata.d2
   glb_datas.animdata.buffer = d2file_extract(
      glb_datas.animdata.filename,
      & glb_datas.animdata.length,
      & glb_datas.animdata.extraction_source
   );
   if (glb_datas.animdata.buffer == NULL)
   {
      printf("\nanims_dummy(), ERROR : can't load %s\n", glb_datas.animdata.filename);
      return -1;
   }

   // load cmncof_a?.d2 files
   for (i=0; i < 5; i++)
   {
      glb_datas.cmncof[i].buffer = d2file_extract(
         glb_datas.cmncof[i].filename,
         & glb_datas.cmncof[i].length,
         & glb_datas.cmncof[i].extraction_source
      );
      if (glb_datas.cmncof[i].buffer == NULL)
      {
         printf("\nanims_dummy(), ERROR : can't load %s\n", glb_datas.cmncof[i].filename);
         return -1;
      }
   }
   // prepare future readings of AnimData.d2
   if (anims_animdata_hash() != 0)
      return -1;

   // for all monsters, compare all COF with AnimData.d2 datas
   for (r = 1; r < ptr_txt->nb_rows; r++)
   {
      // we're working on enabled monsters only
      str = ptr_txt->col[MONSTATS_ENABLED][r];
      if (atoi(str) == 0)
      {
         // not enable, skip this monster
         continue;
      }

      // for all modes
      for (m = MDT; m < MONMODE_MAX; m++)
      {
         if (m == MSQ)
            continue;
         if (glb_datas.ptr_mondata[r].mode[m].active == 0)
            continue;

         // get record in animdata
         str = glb_datas.ptr_mondata[r].mode[m].cof_name;
         if (str == NULL)
            continue;

         cof_header = anims_animdata_get_record(str);
         if (cof_header == NULL)
            continue;
         animdata_fpd = cof_header->nb_frames_per_dir;

         // nb frames per dir and directions in COF
         if (glb_datas.ptr_mondata[r].mode[m].cof_buffer == NULL)
            continue;
         ptr_cof = (COF_S *) glb_datas.ptr_mondata[r].mode[m].cof_buffer;
         cof_fpd = ptr_cof->nb_frames_per_dir;
         cof_dir = ptr_cof->nb_directions;

         // compare fpd
         if (cof_fpd != animdata_fpd)
         {
            printf(
               "anims_dummy(), ERROR :\n"
               "   Monster <%s> at row %li in MonStats.txt\n"
               "   use frames_per_dir = %li in COF <%s>, while it's %li in AnimData.d2\n",
               ptr_txt->col[MONSTATS_ID][r],
               r,
               cof_fpd,
               glb_datas.ptr_mondata[r].mode[m].cof_name,
               animdata_fpd
            );
            continue;
         }

         // compare directions
         mon_dir = glb_datas.ptr_mondata[r].mode[m].directions;
         if (cof_dir != mon_dir)
         {
            printf(
               "anims_dummy(), ERROR :\n"
               "   Monster <%s> at row %li in MonStats.txt\n"
               "   use directions = %li in COF <%s>, while it's %li in column %s in MonStats2.txt\n",
               ptr_txt->col[MONSTATS_ID][r],
               r,
               cof_dir,
               glb_datas.ptr_mondata[r].mode[m].cof_name,
               mon_dir,
               ptr_txt2->header[ mode_table[m].directions_col ]
            );
            continue;
         }
      }
   }

   // end
   return 0;
}
