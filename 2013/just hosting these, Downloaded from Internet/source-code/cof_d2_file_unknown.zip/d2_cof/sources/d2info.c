#include <stdio.h>
#include <stdlib.h>

#define UBYTE unsigned char

#define FALSE 0
#define TRUE -1

int pos_count[144][256];
int fpd=0;

void decode_block(FILE * in, long nb_record, int cur_block)
{
   UBYTE c, as1, as2, u1, u2;
   long  frames_per_dir;
   int   i, x, y, tag, pos;

   
   printf("\n\nblock %i : %li records\n", cur_block, nb_record);
   for (i=0; i<nb_record; i++)
   {

      printf("\n   record %li\n", i);
      
      // 8 bytes null-terminated string
      printf("      cof name         = ");
      for (x=0; x<8; x++)
      {
         c = fgetc(in);
         printf("%c", c>32 ? c : ' ');
      }
      printf("\n");

      // # frames per direction
      fread( & frames_per_dir, 4, 1, in);
      printf("      # frames / dir   = %li\n", frames_per_dir);
      if (frames_per_dir > fpd)
         fpd = frames_per_dir;

      // animation speed
      as1 = fgetc(in);
      as2 = fgetc(in);
      printf("      animation speed  = %3u %3u\n", as1, as2);

      // unknown
      u1 = fgetc(in);
      u2 = fgetc(in);
      printf("      unknown 2 bytes  = %3u %3u", u1, u2);
      printf("   %s %s\n", u1 ? "tag_u1" : "      ", u2 ? "tag_u2" : "      ");

      // unknown data
      printf("      unknown 144 datas (16 * 9) :\n");
      for (y=0; y<16; y++)
      {
         printf("         %2i =", y);
         tag = FALSE;
         pos = 0;
         for (x=0; x<9; x++)
         {
            c = fgetc(in);
            printf(" %02X", c);
            if (c)
            {
               tag = TRUE;
               pos = y*9 + x;
               pos_count[pos][c]++;
            }
         }
         if (tag)
            printf("  non-zero");
         if (pos)
         {
            printf("  pos=%i", pos+1);
            if (pos > frames_per_dir)
               printf("  (error)");
         }
            
         printf("\n");
      }
   }
}


void main(int argc, char ** argv)
{
   FILE * in;
   long nb_record, total_records = 0;
   int  cur_block = 0, i, sum, x, max_rec=0;


   if (argc != 2)
   {
      printf("syntaxe : d2info <file.d2>\n");
      exit(0);
   }
   in = fopen(argv[1], "rb");
   if (in == NULL)
   {
      printf("can't open %s\n", argv[1]);
      exit(1);
   }

   // init
   memset(& pos_count, 0, sizeof(pos_count));
   
   // read it
   printf("==============\n%s\n==============\n", argv[1]);
   while (fread( & nb_record, 1, 4, in) == 4)
   {
      if (nb_record > max_rec)
         max_rec = nb_record;
      decode_block(in, nb_record, cur_block);
      total_records += nb_record;
      cur_block++;
   }
      
   // end
   fclose(in);

   // stats
   printf("\ntotal block = %i\ntotal records = %i\n",
      cur_block, total_records);
   printf("\nmax_records = %i\n", max_rec);
   printf("\nmax frames per dir = %i\n", fpd);
   printf("\npos_count table :\n");
   for (i=0; i<144; i++)
   {
      sum = 0;
      for (x=0; x<256; x++)
         sum += pos_count[i][x];
         
      if (sum)
      {
         printf("pos_count[%3i] = %3i : ", i+1, sum);
         for (x=0; x<256; x++)
         {
            if (pos_count[i][x])
               printf(" %02X (%3i)", x, pos_count[i][x]);
         }
         printf("\n");
      }
   }
}

