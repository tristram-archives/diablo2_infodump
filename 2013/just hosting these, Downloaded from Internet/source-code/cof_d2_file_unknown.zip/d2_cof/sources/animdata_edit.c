#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_RECORDS 5000

unsigned char animdata[MAX_RECORDS][160];
unsigned char hash_value[MAX_RECORDS];


// ==========================================================================
void make_txt(void)
{
   FILE * in, * out;
   char txtname[] = "animdata.txt", d2name[] = "animdata.d2";
   long total_nb_records = 0, nb_rec;
   int  ret, i, x;
   unsigned char * ubyte;
   unsigned long * udword;

   // read d2 datas
   in = fopen(d2name, "rb");
   if (in == NULL)
   {
      freopen("error.txt", "wt", stdout);
      printf("can't open %s\n", d2name);
      exit(1);
   }
   ret = fread( &nb_rec, 4, 1, in);
   while (ret == 1)
   {
      if (nb_rec)
      {
         fread( & animdata[total_nb_records], 160, nb_rec, in);
         total_nb_records += nb_rec;
      }
      ret = fread( &nb_rec, 4, 1, in);
   }
   fclose(in);

   // write txt datas
   out = fopen(txtname, "wt");
   if (out == NULL)
   {
      freopen("error.txt", "wt", stdout);
      printf("can't open %s\n", txtname);
      exit(1);
   }
   fputs("CofName"
         "\tFramesPerDirection"
         "\tAnimationSpeed"
         "\tFrameData000",
         out);
   for (i=1; i <= 143; i++)
      fprintf(out, "\tFrameData%03i", i);
   fprintf(out, "\n");
   for (i=0; i<total_nb_records; i++)
   {
      fprintf(out, "%.7s", &animdata[i][0]);

      udword = (unsigned long *) &animdata[i][8];
      fprintf(out, "\t%li", * udword);

      udword = (unsigned long *) &animdata[i][12];
      fprintf(out, "\t%li", * udword);

      for (x=0; x < 144; x++)
      {
         ubyte = &animdata[i][16 + x];
         fprintf(out, "\t%i", * ubyte);
      }

      fprintf(out, "\n");
   }
   fclose(out);
}


// ==========================================================================
void make_d2(void)
{
   FILE * in, * out;
   char txtname[] = "animdata.txt", d2name[] = "animdata.d2";
   int  c, cur_record = 0, i, x;
   unsigned long udword, nb_rec;
   unsigned char ubyte;

   // read txt datas
   in = fopen(txtname, "rb");
   if (in == NULL)
   {
      freopen("error.txt", "wt", stdout);
      printf("can't open %s\n", txtname);
      exit(1);
   }

   // skip 1st line
   c = fgetc(in);
   while ((c != 0x0D) && (c != 0x0A))
      c = fgetc(in);
   while ((c == 0x0D) || (c == 0x0A))
      c = fgetc(in);

   // for all records
   while (c != EOF)
   {
      // cof name
      for (i=0; i<7; i++)
      {
         animdata[cur_record][i] = c;
         c = fgetc(in);
      }
      animdata[cur_record][7] = 0; // null string terminator


      // frame per dir
      fscanf(in, "%li", & udword);
      * (unsigned long *) & animdata[cur_record][8] = udword;

      // animation speed
      fscanf(in, "%li", & udword);
      * (unsigned long *) & animdata[cur_record][12] = udword;

      // frame datas
      for (i=0; i < 144; i++)
      {
         fscanf(in, "%i", & ubyte);
         * (unsigned char *) & animdata[cur_record][16 + i] = ubyte;
      }
      
      // next record
      cur_record++;
      if (cur_record > MAX_RECORDS)
      {
         freopen("error.txt", "wt", stdout);
         printf("too much records, maximum is %i\n", MAX_RECORDS);
         exit(1);
      }
      c = fgetc(in);
      while ((c == 0x0D) || (c == 0x0A))
         c = fgetc(in);
   }
   fclose(in);

   for(i=0; i<cur_record; i++)
   {
      hash_value[i] = 0;
      for (x=0; x<8; x++)
         hash_value[i] += toupper(animdata[i][x]);
   }

   out = fopen(d2name, "wb");
   if (out == NULL)
   {
      freopen("error.txt", "wt", stdout);
      printf("can't open %s\n", d2name);
      exit(1);
   }
   for(x=0; x<256; x++)
   {
      // # of records in this block
      nb_rec = 0;
      for (i=0; i<cur_record; i++)
         if (hash_value[i] == x)
            nb_rec++;
      fwrite(&nb_rec, 4, 1, out);
      
      // write records
      for (i=0; i<cur_record; i++)
         if (hash_value[i] == x)
            fwrite(animdata[i], 160, 1, out);
   }
   fclose(out);
}


// ==========================================================================
int main(int argc, char ** argv)
{
   if (argc != 2)
   {
      freopen("error.txt", "wt", stdout);
      printf("syntaxe : animdata_edit <file>\n"
             "   <file> is either animdata.d2 OR animdata.txt\n");
      exit(0);
   }
   
   memset(&animdata, 0, sizeof(animdata));
   
   if (stricmp(argv[1], "animdata.d2") == 0)
      make_txt();
   else if (stricmp(argv[1], "animdata.txt") == 0)
      make_d2();
   else
   {
      freopen("error.txt", "wt", stdout);
      printf("can't process %s : not animdata.d2 nor animdata.txt", argv[1]);
      exit(1);
   }
   return 0;
}

