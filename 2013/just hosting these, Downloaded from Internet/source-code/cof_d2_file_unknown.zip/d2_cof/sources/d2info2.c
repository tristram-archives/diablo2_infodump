#include <stdio.h>
#include <stdlib.h>

#define UBYTE unsigned char

#define FALSE 0
#define TRUE -1

char composit[16][3] = {
        {"HD"}, {"TR"}, {"LG"}, {"RA"}, {"LA"}, {"RH"}, {"LH"}, {"SH"},
        {"S1"}, {"S2"}, {"S3"}, {"S4"}, {"S5"}, {"S6"}, {"S7"}, {"S8"}
     };
     
         
int decode_record(FILE * in, int rec_num)
{
   long tag1, tag2, rec_size, tag3, unk_dword[4], file_start, file_end;
   int  nb, nb_layers, frames_per_dir, i, x, c, nb_dir, y, max;
   char cof_name[8];
   unsigned char u1, u2, unk[4], unk2[4];

   file_start = ftell(in);
   nb = fread( & tag1, 4, 1, in);
   if (nb != 1)
      return TRUE;
   
   fread( & tag2,     4, 1, in);
   
   fread( & rec_size, 4, 1, in);
   file_end = file_start + rec_size + 24;
   
   fread( & cof_name, 1, 8, in);
   fread( & tag3,     4, 1, in);
   nb_layers      = fgetc(in);
   frames_per_dir = fgetc(in);
   nb_dir         = fgetc(in);
   u2             = fgetc(in);
   fread(unk,       1, 4, in);
   fread(unk_dword, 4, 4, in);
   fread(unk2,      1, 4, in);

   printf("\nrecord %i...\n", rec_num);
   printf("tag1 & tag2      = %li %li\n", tag1, tag2);
   printf("record size - 24 = %li\n", rec_size);
   printf("cof name         = %s\n", cof_name);
   printf("tag3             = %li\n", tag3);
   printf("# layers         = %i\n", nb_layers);
   printf("# frames / dir   = %i\n", frames_per_dir);
   printf("# directions     = %i\n", nb_dir);
   printf("unknown 2        = %3u\n", u2);
   printf("unknown bytes    = %3u %3u %3u %3u\n",
      unk[0], unk[1], unk[2], unk[3]);
   printf("unknown dword    = %3li %3li %3li %3li\n",
      unk_dword[0], unk_dword[1], unk_dword[2], unk_dword[3]);
   printf("unknown bytes    = %3u %3u %3u %3u\n",
      unk2[0], unk2[1], unk2[2], unk2[3]);
   
   for (i=0; i<nb_layers; i++)
   {
      printf("   layer %3i : ", i);
      
      c = fgetc(in);
      printf("%s", composit[c]);
      
      for (x=0; x<4; x++)
      {
         c = fgetc(in);
         printf(" %02X", c);
      }

      printf(" ");
      for (x=0; x<3; x++)
      {
         c = fgetc(in);
         printf("%c", c);
      }
      
      c = fgetc(in);
      printf(" %02X ", c);
      
      printf("\n");
   }

   printf("\n(frames / dir) unknown data :");

   max = frames_per_dir;
   if ((nb_layers == 1) && (nb_dir == 1) && (frames_per_dir == 1) &&
       (rec_size == 42))
      max = 4;
      
   for (i=0; i < max; i++)
   {
      c = fgetc(in);
      printf(" %02X", c);
   }
   printf("\n");
   
   printf("\nlayers priority :\n");
for (y=0; y<nb_dir; y++)
{
   printf("\ndirection %i\n", y);
   for (i=0; i<frames_per_dir; i++)
   {
      printf("   frame %3i :", i);
      for (x=0; x<nb_layers; x++)
      {
         c = fgetc(in);
         printf(" %s", composit[c]);
      }
      printf("\n");
   }
}
   
   if (ftell(in) < file_end)
      printf("   ????? datas : ");
   while (ftell(in) < file_end)
   {
      c = fgetc(in);
      printf(" %02X", c);
   }
   
   return FALSE;
}


void main(int argc, char ** argv)
{
   FILE * in;
   int  done = FALSE, rec_num = 0;


   if (argc != 2)
   {
      printf("syntaxe : d2info2 <file.d2>\n");
      exit(0);
   }
   in = fopen(argv[1], "rb");
   if (in == NULL)
   {
      printf("can't open %s\n", argv[1]);
      exit(1);
   }

   printf("=============\n%s\n=============\n", argv[1]);
   // read it
   while ( ! done)
   {
      done = decode_record(in, rec_num);
      rec_num++;
   }

   fprintf(stderr, "#records = %i\n", rec_num - 1);
}

