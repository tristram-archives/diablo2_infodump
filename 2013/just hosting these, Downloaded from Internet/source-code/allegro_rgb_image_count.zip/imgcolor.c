#include <stdio.h>
#include <string.h>

#define USE_CONSOLE
#include <allegro.h>

int main(int argc, char ** argv)
{
   PALETTE       pal;
   BITMAP        * bmp;
   unsigned long color_count[256], temp;
   int           i, x, y, done, color_idx[256];


   if (argc != 2)
   {
      printf("syntaxe : imgcolor <file.ext>\n"
             "   <file.ext> is a 256 color image file of the folowing format:\n"
             "      BMP, LBM, PCX, TGA\n");
      exit(1);
   }

   // load image
   allegro_init();
   bmp = load_bitmap(argv[1], pal);
   if (bmp == NULL)
   {
      printf("can't open \"%s\"\n", argv[1]);
      exit(1);
   }

   for (i=0; i < 256; i++)
   {
      color_count[i] = 0L;
      color_idx[i]   = i;
   }

   // process the image
   for (y=0; y < bmp->h; y++)
   {
      for (x=0; x < bmp->w; x++)
      {
         color_count[bmp->line[y][x]]++;
      }
   }

   // sort the values
   done = FALSE;
   while ( ! done)
   {
      done = TRUE;
      for (i=0; i < 255; i++)
      {
         if (color_count[i] < color_count[i+1])
         {
            // swap count
            temp             = color_count[i];
            color_count[i]   = color_count[i+1];
            color_count[i+1] = temp;

            // swap idx
            x              = color_idx[i];
            color_idx[i]   = color_idx[i+1];
            color_idx[i+1] = x;

            done = FALSE;
         }
      }
   }

   // output the result
   printf("Count\tIdx\tR\tG\tB\n");
   for (i=0; i < 256; i++)
   {
      x = color_idx[i];
      printf("%lu\t%i\t%i\t%i\t%i\n",
         color_count[i],
         x,
         pal[x].r,
         pal[x].g,
         pal[x].b
      );
   }

   // end
   destroy_bitmap(bmp);
   return 0;
}
END_OF_MAIN();
