#ifndef __DLGBOX_MAIN_H__
#define __DLGBOX_MAIN_H__

#include "one_include_to_rule_them_all.h"

int  create_dlgbox_main  (HINSTANCE hInst, int iCmdShow);
void init_layer_controls (void);

#endif
