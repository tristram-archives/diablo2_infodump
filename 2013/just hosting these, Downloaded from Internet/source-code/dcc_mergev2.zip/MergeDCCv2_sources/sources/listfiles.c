#include "one_include_to_rule_them_all.h"

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "listfiles.h"
#include "misc.h"
#include "strings_define.h"
#include "d2_files.h"
#include "tools.h"
#include "mpq_handler.h"
#include "dialog_maker.h"
#include "dlgbox_cof_in_progress.h"


struct test_existence_list_PARAMS_S
{
   int  r;
   HWND hpbar;
   HWND hpnct;
   HWND hexists;
   long nb_files;
   long curr_pos;
   long curr_step;
   long curr_exists;
   long nb_tokens_players;
   long nb_tokens_monsters;
   long nb_tokens_objects;
   FILE * debug_exists_file;
};


static void               rtrim_row                       (char * row);
static ENUM_ROW_EXTENSION get_row_file_extension          (char * row);
static void               process_COF_row                 (char * row);
static ENUM_ANIMTYPE      get_root_path_type              (char * row);
static int                extract_COF_row_elements        (ENUM_ANIMTYPE r, char * row, STR_2_LETTERS * token, STR_3_LETTERS * weapon_class, STR_2_LETTERS * mode);
static int                validate_row                    (ENUM_ANIMTYPE r, char * row, char * format);
static int                qsort_helper_COF                (const void * a, const void * b);
static int                build_COF_existence_list        (int r);
static int                test_existence_list             (struct test_existence_list_PARAMS_S * params);
static int                prepare_COF_selection_listboxes (void);

static void               process_DCC_row                 (char * row);
static int                extract_DCC_row_elements        (ENUM_ANIMTYPE r, char * row, STR_2_LETTERS * token, STR_3_LETTERS * weapon_class, STR_2_LETTERS * mode, STR_2_LETTERS * layer, STR_3_LETTERS * variant);
static int                qsort_helper_DCC                (const void * a, const void * b);
static int                build_DCC_existence_list        (int r);


// ===========================================================================
// open listfiles, and analyse them
// ===========================================================================
int load_all_listfiles(void)
{
   ENUM_DLGBOX_ID       dialog_ID   = DLG_COF_IN_PROGRESS;
   DLGBOX_DATAS         * dd        = NULL;
   CREATE_DLGBOX        * dlg       = NULL;
   CREATE_DLGBOX_WINDOW * w         = NULL;
   FILE                 * in        = NULL;
   long                 length      = 0;
   char                 * buffer    = NULL;
   int                  m           = 0;
   int                  pbar_idx    = -1;
   int                  pnct_idx    = -1;
   int                  exists_idx  = -1;
   int                  i           = 0;
   WCHAR                filename[MAX_PATH] = TEXT("");
   int                  ret         = 0;
   struct test_existence_list_PARAMS_S params;


   MYASSERT_RETURN(((dialog_ID >= 0) && (dialog_ID < DLG_MAX)), 1, NULL);
   MYASSERT_RETURN(create_dlgbox_COF_in_progress() == 0, 1, NULL);
   dd  = & myglobals.dlgbox_datas[dialog_ID];
   dlg = & dd->dlg;
   w  = & dlg->window;

   if (dlg == NULL)
      return 1;

   memset( & params, 0, sizeof(params));

   // search which child index is the progress bar in d->pChild[]
   for (pbar_idx = 0; pbar_idx < dlg->nbChildren; pbar_idx++)
   {
      if (dlg->pChild[pbar_idx].iChildID == ID_DLGBOX_COF_IN_P_PBAR)
         break;
   }

   if (pbar_idx >= dlg->nbChildren)
      return 1;

   if (dlg->pChild[pbar_idx].handle == NULL)
      return 1;

   // search which child index is the "percentage" in d->pChild[], right of the progress bar
   for (pnct_idx = 0; pnct_idx < dlg->nbChildren; pnct_idx++)
   {
      if (dlg->pChild[pnct_idx].iChildID == ID_DLGBOX_COF_IN_P_NBFILES)
         break;
   }

   if (pnct_idx >= dlg->nbChildren)
      return 1;

   if (dlg->pChild[pnct_idx].handle == NULL)
      return 1;

   // search which child index in d->pChild[] display the number COF existing in MPQ
   for (exists_idx = 0; exists_idx < dlg->nbChildren; exists_idx++)
   {
      if (dlg->pChild[exists_idx].iChildID == ID_DLGBOX_COF_IN_P_EXISTS_R)
         break;
   }

   if (exists_idx >= dlg->nbChildren)
      return 1;

   if (dlg->pChild[exists_idx].handle == NULL)
      return 1;

   // load the application listfile

   MYASSERT((_wfopen_s( & in, myglobals.datas.path.listfile, TEXT("rb")) == 0), "can't open 'ressources\\listfiles.txt'");
   if (in == NULL)
      return 1;

   fseek(in, 0, SEEK_END);
   length = ftell(in);
   fseek(in, 0, SEEK_SET);

   buffer = (char *) calloc(1, length + 1);
   MYASSERT(buffer != NULL, NULL);
   if (buffer == NULL)
   {
      fclose(in);
      return 1;
   }

   fread(buffer, length, 1, in);
   fclose(in);

   analyse_listfile(buffer, length);
   free(buffer);
   buffer = NULL;
   length = 0;

   // load the listfiles of all opened MPQ
   for (m = 0; m < MPQ_MAX; m++)
   {
      if (load_mpq_listfile(m,  & buffer, & length) == 0)
      {
         analyse_listfile(buffer, length);
         free(buffer);
         buffer = NULL;
         length = 0;
      }
   }

   // prepare the search of existing files
   for (i = 0; i < AT_MAX; i++)
   {
      if (build_COF_existence_list(i) != 0)
         return 1;

      if (build_DCC_existence_list(i) != 0)
         return 1;
   }

   // search the total number of files that'll be tested
   params.nb_files = 0;
   for (i = 0; i < AT_MAX; i++)
   {
      params.nb_files += myglobals.listfile_datas.at[i].nb_cofs;
      params.nb_files += myglobals.listfile_datas.at[i].nb_dcc;
   }

   if (params.nb_files <= 0)
      return 1;

   // progress bar : set the range and position, and to be safe set the current state to normal
   SendMessage(dlg->pChild[pbar_idx].handle, PBM_SETSTATE,   (WPARAM) PBST_NORMAL, (LPARAM) 0);
   SendMessage(dlg->pChild[pbar_idx].handle, PBM_SETRANGE32, (WPARAM) 0,           (LPARAM) params.nb_files);
   SendMessage(dlg->pChild[pbar_idx].handle, PBM_SETPOS,     (WPARAM) 0,           (LPARAM) 0);

   // test the existence of files
   params.hpbar   = dlg->pChild[pbar_idx].handle;
   params.hpnct   = dlg->pChild[pnct_idx].handle;
   params.hexists = dlg->pChild[exists_idx].handle;
   for (i = 0; i < AT_MAX; i++)
   {
      swprintf(filename, sizeof(filename) / 2, TEXT("%s\\mpq_file_existence_%d.txt"),  myglobals.datas.path.debug, i);
      params.debug_exists_file = _wfopen(filename, TEXT("wt"));
      params.r                 = i;

      ret = test_existence_list( & params);

      if (params.debug_exists_file != NULL)
      {
         fclose(params.debug_exists_file);
         params.debug_exists_file = NULL;
      }

      if (ret != 0)
         return 1;
   }

   if (prepare_COF_selection_listboxes() != 0)
      return 1;

   return 0;
}


// ===========================================================================
// parse the entire listfile in memory, and process the desired types of row
// ===========================================================================
void analyse_listfile(char * cptr, long length)
{
   long i     = 0;
   char c     = 0;
   char * row = NULL;


   if ((cptr == NULL) || (length <= 0))
      return;

   // pre-format the entire text : EOL are replaced by 0, and unprintable characters by spaces
   for (i = 0; i < length; i++)
   {
      c = cptr[i];
      if ((c == 0x0D) || (c == 0x0A))
         cptr[i] = 0;
      else if ((c < 32) && (c != 0))
         cptr[i] = 32;
   }

   // for each row, get its extension, and call its corresponding processing function
   for (i = 0; i < length;)
   {
      row  = cptr + i;
      i   += (strlen(row) + 1);
      rtrim_row(row);
      if (row[0] == 0)
         continue;

      switch (get_row_file_extension(row))
      {
         case REXT_COF :
            process_COF_row(row);
            break;

         case REXT_DCC :
         case REXT_DC6 :
            process_DCC_row(row);
            break;
      }
   }
}


// ===========================================================================
// delete unprintable ending characters/spaces of the row
// ===========================================================================
void rtrim_row(char * row)
{
   long i = 0;


   if (row == NULL)
      return;

   i = strlen(row) - 1;
   if (i < 0)
      return;

   while ((i >= 0) && (row[i] <= 32))
   {
      row[i] = 0;
      i--;
   }
}


// ===========================================================================
// return the type of the row, given its file extension
// ===========================================================================
ENUM_ROW_EXTENSION get_row_file_extension(char * row)
{
   char * ext                = NULL;
   long i                    = 0;
   char * tab_ext [REXT_MAX] = {".cof", ".dcc", ".dc6"}; // must follow ENUM_ROW_EXTENSION


   if (row == NULL)
      return REXT_NULL;

   i = strlen(row) - 1;
   if (i < 2)
      return REXT_NULL; // there must be at least 3 characters

   while ((row[i] != '.') && (i > 0))
      i--;

   if (row[i] != '.') // the extension must start by a '.'
      return REXT_NULL;

   ext = row + i;
   for (i = 0; i < REXT_MAX; i++)
   {
      if (_stricmp(ext, tab_ext[i]) == 0)
         return (ENUM_ROW_EXTENSION) i;
   }

   return REXT_NULL;
}


// ===========================================================================
// extract the needed elements of a COF row, and save it for later in a structure
// ===========================================================================
void process_COF_row(char * row)
{
   ENUM_ANIMTYPE r     = AT_NULL;
   COF_ROW       * pcf = NULL;
   COF_ROW       cf;


   if (row == NULL)
      return;

   r = get_root_path_type(row);
   if (r == AT_NULL)
      return;

   memset ( & cf, 0, sizeof(cf));
   if (extract_COF_row_elements(r, row, & cf.token, & cf.weapon_class, & cf.mode) == 0)
   {
      pcf = (COF_ROW *) malloc(sizeof(cf));
      if (pcf == NULL)
         return;

      memcpy(pcf, & cf, sizeof(cf));
      pcf->next = myglobals.listfile_datas.at[r].first_COF;
      myglobals.listfile_datas.at[r].first_COF = pcf;
   }

   return;
}


// ===========================================================================
// from a COF row, extract token, weapon class and mode, in uppercase
// return 0 if success
// ===========================================================================
int extract_COF_row_elements(ENUM_ANIMTYPE r, char * row, STR_2_LETTERS * token, STR_3_LETTERS * weapon_class, STR_2_LETTERS * mode)
{
   int           n      = 0;
   char          * cptr = NULL;
   STR_2_LETTERS token2 = "";


   if (r == AT_NULL)
      return 1;

   if ((r < 0) || (r >= AT_MAX))
      return 1;

   if ((row == NULL) || (token == NULL) || (weapon_class == NULL) || (mode == NULL))
      return 1;

   if (validate_row(r, row, "$$\\cof\\$$$$$$$.cof") != 0)
      return 1;

   n = strlen(myglobals.datas.root_path[r]);

   cptr = (char *) token;
   cptr[0] = row[n];
   cptr[1] = row[n + 1];
   cptr[2] = 0;

   cptr = (char *) token2;
   cptr[0] = row[n + 7];
   cptr[1] = row[n + 8];
   cptr[2] = 0;

   cptr = (char *) mode;
   cptr[0] = row[n +  9];
   cptr[1] = row[n + 10];
   cptr[2] = 0;

   cptr = (char *) weapon_class;
   cptr[0] = row[n + 11];
   cptr[1] = row[n + 12];
   cptr[2] = row[n + 13];
   cptr[3] = 0;

   make_string_uppercase((char *) token);
   make_string_uppercase((char *) token2);
   make_string_uppercase((char *) mode);
   make_string_uppercase((char *) weapon_class);

   if (strcmp((char *) token, (char *) token2) != 0)
      return 1;

   return 0;
}


// ===========================================================================
// validate the row from a given format
// special format code : '\\' = must be '\\', '$' = any letter > 32 except '\\'
// other format code   : must be the same letter (case insensitive)
// return 0 if the row is of the expected format
// ===========================================================================
int validate_row(ENUM_ANIMTYPE r, char * row, char * format)
{
   int n  = 0;
   int x  = 0;
   int c  = 0;
   int cf = 0;


   if ((r < 0) || (r >= AT_MAX))
      return 1;

   if ((row == NULL) || (format == NULL))
      return 1;

   n = strlen(myglobals.datas.root_path[r]);
   if (row[n] == 0)
      return 1;

   for (x = 0; format[x] != 0; x++)
   {
      if (format[x] < 32)
         return 1;

      c = row[n + x];
      if (c == 0)
         return 1;

      if (format[x] == '$')
      {
         if ((c <= 32) || (c == '\\'))
            return 1;
      }
      else
      {
         cf = format[x];
         make_letter_uppercase( & c);
         make_letter_uppercase( & cf);
         if (c != cf)
            return 1;
      }
   }

   if (row[n + x] != 0)
      return 1;

   return 0;
}


// ===========================================================================
// return the type of the row, or AT_NULL if error
// ===========================================================================
ENUM_ANIMTYPE get_root_path_type(char * row)
{
   int  i      = 0;
   char * root = NULL;


   if (row == NULL)
      return AT_NULL;

   for (i = 0; i < AT_MAX; i++)
   {
      root = myglobals.datas.root_path[i];
      if (root == NULL)
         continue;

      if (_strnicmp(row, root, strlen(root)) == 0)
         return (ENUM_ANIMTYPE) i;
   }

   return AT_NULL;
}


// ===========================================================================
// destroy all the listfiles datas
// ===========================================================================
void destroy_listfiles(void)
{
   LISTFILE_ANIMTYPE * a  = NULL;
   TOKEN_DATAS       * td = NULL;
   WEAPCLASS_DATAS   * wd = NULL;
   COF_ROW           * f  = NULL;
   COF_ROW           * n  = NULL;
   int               r    = 0;
   long              t    = 0;
   long              w    = 0;
   long              c    = 0;


   for (r = 0; r < AT_MAX; r++)
   {
      a = & myglobals.listfile_datas.at[r];

      f = a->first_COF;
      while (f != NULL)
      {
         n = f->next;
         free(f);
         f = n;
      }

      a->first_COF = NULL;

      if (a->tab_COF != NULL)
      {
         for (c = 0; c < a->nb_cofs; c++)
         {
            if (a->tab_COF[c].layer_datas != NULL)
            {
               free(a->tab_COF[c].layer_datas);
               a->tab_COF[c].layer_datas = NULL;
               a->tab_COF[c].nb_layers   = 0;
            }

            if (a->tab_COF[c].priority != NULL)
            {
               free(a->tab_COF[c].priority);
               a->tab_COF[c].priority = NULL;
            }
         }

         free(a->tab_COF);
         a->tab_COF = NULL;
      }

      if (a->tab_token != NULL)
      {
         for (t = 0; t < a->nb_tokens; t++)
         {
            td = & a->tab_token[t];
            if (td->tab_weapon_class != NULL)
            {
               for (w = 0; w < td->nb_weapon_class; w++)
               {
                  wd = & td->tab_weapon_class[w]; 
                  if (wd->tab_mode_code != NULL)
                  {
                     free(wd->tab_mode_code);
                     wd->tab_mode_code = NULL;
                  }
               }

               free(td->tab_weapon_class);
               td->tab_weapon_class = NULL;
            }
         }

         free(a->tab_token);
         a->tab_token = NULL;
      }
   }
}


// ===========================================================================
// qsort helper function for comparing 2 COF rows (case insensitive)
// order : token, weapon class, mode
// ===========================================================================
int qsort_helper_COF(const void * a, const void * b)
{
   COF_ROW_EXISTS * ca = (COF_ROW_EXISTS *) a;
   COF_ROW_EXISTS * cb = (COF_ROW_EXISTS *) b;
   int            r    = 0;


   if ((a == NULL) || (b == NULL))
      return 0;

   r = stricmp(ca->token, cb->token);
   if (r == 0)
   {
      r = stricmp(ca->weapon_class, cb->weapon_class);
      if (r == 0)
         return stricmp(ca->mode, cb->mode);
      else
         return r;
   }
   else
      return r;
}
 

// ===========================================================================
// build the table of unique COF datas for this animation type
// return 0 on success
// ===========================================================================
int build_COF_existence_list(int r)
{
   LISTFILE_DATAS    * d        = NULL;
   LISTFILE_ANIMTYPE * at       = NULL;
   COF_ROW           * f        = NULL;
   long              nb_cofs    = 0;
   COF_ROW           * c        = NULL;
   COF_ROW           * n        = NULL;
   COF_ROW_EXISTS    * tab      = NULL;
   long              i          = 0;
   long              nb_uniques = 0;
   long              idx        = 0;


   d = & myglobals.listfile_datas;

   if ((r < 0) || (r >= AT_MAX))
      return 1;

   at = & d->at[r];
   f  = at->first_COF;

   // count number of COF found in the different listfiles (some are probably here multiple times)
   c = f;
   while (c != NULL)
   {
      nb_cofs++;
      c = c->next;
   }

   if (nb_cofs <= 1)
      return 1;

   // prepare a table to put them all
   tab = (COF_ROW_EXISTS *) calloc(nb_cofs, sizeof(COF_ROW_EXISTS));
   if (tab == NULL)
      return 1;

   // copy them
   c = f;
   for (i = 0; i < nb_cofs; i++)
   {
      if (c == NULL)
      {
         free(tab);
         return 1;
      }

      strncpy(tab[i].token,        c->token,        sizeof(STR_2_LETTERS));
      strncpy(tab[i].weapon_class, c->weapon_class, sizeof(STR_3_LETTERS));
      strncpy(tab[i].mode,         c->mode,         sizeof(STR_2_LETTERS));
      tab[i].exists          = FALSE;
      tab[i].already_decoded = FALSE;

      c = c->next;
   }

   if (c != NULL)
   {
      free(tab);
      return 1;
   }

   // no need for the COF linked list anymore
   c = f;
   while (c != NULL)
   {
      n = c->next;
      free(c);
      c = n;
   }
   at->first_COF = NULL;

   // sort the table
   qsort(tab, nb_cofs, sizeof(COF_ROW_EXISTS), qsort_helper_COF);

   // identify each first unique element, count them along the way
   tab[0].exists = 1;
   nb_uniques = 1;
   for (i = 1; i < nb_cofs; i++)
   {
      if (qsort_helper_COF((const void *) & tab[i - 1], (const void *) & tab[i]) != 0)
      {
         tab[i].exists = 1;
         nb_uniques++;
      }
   }

   // create the table of unique COF to check for existence in MPQ
   at->nb_cofs = nb_uniques;
   at->tab_COF = (COF_ROW_EXISTS *) calloc(nb_uniques, sizeof(COF_ROW_EXISTS));
   if (at->tab_COF == NULL)
      return 1;

   // fill it
   idx = 0;
   for (i = 0; i < nb_cofs; i++)
   {
      if (tab[i].exists == 1)
      {
         if (idx >= nb_uniques)
         {
            free(tab);
            free(at->tab_COF);
            at->tab_COF = NULL;
            return 1;
         }
         else
         {
            memcpy(at->tab_COF + idx, tab + i, sizeof(COF_ROW_EXISTS));
            at->tab_COF[idx].exists = FALSE;
            idx++;         
         }
      }
   }

   return 0;
}


// ===========================================================================
// check the existence of all COF and DCC for this animation type
// update the progress bar along the way when needed
// return 0 on success
// ===========================================================================
int test_existence_list(struct test_existence_list_PARAMS_S * params)
{
   LISTFILE_DATAS    * d                 = NULL;
   LISTFILE_ANIMTYPE * at                = NULL;
   long              i                   = 0;
   char              file    [MAX_PATH]  = "";
   WCHAR             wc_file [MAX_PATH]  = TEXT("");
   WCHAR             wc_path [MAX_PATH]  = TEXT("");
   DWORD             attr                = 0;
   int               m                   = 0;
   int               mpq_order [MPQ_MAX] = {MPQ_MOD_DIRECTORY, MPQ_D2DATA, MPQ_D2EXP, MPQ_D2CHAR, MPQ_PATCH_D2}; // prefered order, less total tests in MPQ that way
   long              tmp_step            = 0;
   WCHAR             wcString [300]      = TEXT("");
   int               found               = FALSE;


   if (params == NULL)
      return 1;

   d = & myglobals.listfile_datas;

   if ((params->r < 0) || (params->r >= AT_MAX) || (params->hpbar == NULL) || (params->hpnct == NULL))
      return 1;

   at = & d->at[params->r];

   // test all COF one by one
   for (i = 0; i < at->nb_cofs; i++)
   {
      sprintf(file, "%s%s\\cof\\%s%s%s.cof", myglobals.datas.root_path[params->r], at->tab_COF[i].token, at->tab_COF[i].token, at->tab_COF[i].mode, at->tab_COF[i].weapon_class);
      found = FALSE;
      for (m = 0; (m < MPQ_MAX) && (found == FALSE); m++)
      {
         if (mpq_order[m] == MPQ_MOD_DIRECTORY)
         {
            char_to_wide_char(file, wc_file, sizeof(wc_file));
            swprintf(wc_path, MAX_PATH, TEXT("%s%s"), myglobals.datas.mpq[MPQ_MOD_DIRECTORY].path, wc_file);
            attr = GetFileAttributes(wc_path);
            if ((attr != INVALID_FILE_ATTRIBUTES) && ((attr & FILE_ATTRIBUTE_DIRECTORY) == 0))
            {
               found = TRUE;
               break;
            }
         }
         else if (test_file_existence_from_mpq(mpq_order[m], file) == TRUE)
         {
            found = TRUE;
            break;
         }
      }

      // debug
      if (params->debug_exists_file != NULL)
      {
         fwprintf(params->debug_exists_file, TEXT("%s\t"), wc_file);
         if (found == FALSE)
            fwprintf(params->debug_exists_file, TEXT("NOT found\n"));
         else
         {
            switch(mpq_order[m])
            {
               case MPQ_MOD_DIRECTORY : fwprintf(params->debug_exists_file, TEXT("Mod directory\n")); break;
               case MPQ_D2DATA        : fwprintf(params->debug_exists_file, TEXT("d2data.mpq\n"));    break;
               case MPQ_D2EXP         : fwprintf(params->debug_exists_file, TEXT("d2exp.mpq\n"));     break;
               case MPQ_D2CHAR        : fwprintf(params->debug_exists_file, TEXT("d2char.mpq\n"));    break;
               case MPQ_PATCH_D2      : fwprintf(params->debug_exists_file, TEXT("patch_d2.mpq\n"));  break;
               default : fwprintf(params->debug_exists_file, TEXT("? (%d)\n"), m);  break;
            }
         }
      }

      // if found, keep a trace and update the existence counter
      if (found == TRUE)
      {
         at->tab_COF[i].exists = TRUE;
         params->curr_exists++;
         switch (params->r)
         {
            case AT_PLAYERS  : params->nb_tokens_players++;  break;
            case AT_MONSTERS : params->nb_tokens_monsters++; break;
            case AT_OBJECTS  : params->nb_tokens_objects++;  break;
         }
      }

      // update the progress bar, if needed
      params->curr_pos++;
      tmp_step = 100 * params->curr_pos / params->nb_files; // update the progress bar only 100 times
      if (tmp_step != params->curr_step)
      {
         params->curr_step = tmp_step;
         SendMessage(params->hpbar, PBM_SETPOS, (WPARAM) params->curr_pos + 1, (LPARAM) 0);
         SendMessage(params->hpbar, PBM_SETPOS, (WPARAM) params->curr_pos, (LPARAM) 0); // if you wonder why we do this, check http://stackoverflow.com/questions/1061715/how-do-i-make-tprogressbar-stop-lagging

         swprintf(wcString, sizeof(wcString) / 2, TEXT("%ld / %ld"), params->curr_pos, params->nb_files);
         SendMessage(params->hpnct, WM_SETTEXT, (WPARAM) 0, (LPARAM) wcString);

         swprintf(wcString, sizeof(wcString) / 2, TEXT("%ld\n%ld\n%ld\n%ld"), params->curr_exists, params->nb_tokens_players, params->nb_tokens_monsters, params->nb_tokens_objects);
         SendMessage(params->hexists, WM_SETTEXT, (WPARAM) 0, (LPARAM) wcString);
      }
   }

   // test all DCC one by one
   for (i = 0; i < at->nb_dcc; i++)
   {
      sprintf(
         file,
         "%s%s\\%s\\%s%s%s%s%s.dcc",
         myglobals.datas.root_path[params->r],
         at->tab_DCC[i].token,
         at->tab_DCC[i].layer,
         at->tab_DCC[i].token,
         at->tab_DCC[i].layer,
         at->tab_DCC[i].variant,
         at->tab_DCC[i].mode,
         at->tab_DCC[i].weapon_class
      );

      found = FALSE;
      for (m = 0; (m < MPQ_MAX) && (found == FALSE); m++)
      {
         if (mpq_order[m] == MPQ_MOD_DIRECTORY)
         {
            char_to_wide_char(file, wc_file, sizeof(wc_file));
            swprintf(wc_path, MAX_PATH, TEXT("%s%s"), myglobals.datas.mpq[MPQ_MOD_DIRECTORY].path, wc_file);
            attr = GetFileAttributes(wc_path);
            if ((attr != INVALID_FILE_ATTRIBUTES) && ((attr & FILE_ATTRIBUTE_DIRECTORY) == 0))
            {
               found = TRUE;
               break;
            }
         }
         else if (test_file_existence_from_mpq(mpq_order[m], file) == TRUE)
         {
            found = TRUE;
            break;
         }
      }

      // debug
      if (params->debug_exists_file != NULL)
      {
         fwprintf(params->debug_exists_file, TEXT("%s\t"), wc_file);
         if (found == FALSE)
            fwprintf(params->debug_exists_file, TEXT("NOT found\n"));
         else
         {
            switch(mpq_order[m])
            {
               case MPQ_MOD_DIRECTORY : fwprintf(params->debug_exists_file, TEXT("Mod directory\n")); break;
               case MPQ_D2DATA        : fwprintf(params->debug_exists_file, TEXT("d2data.mpq\n"));    break;
               case MPQ_D2EXP         : fwprintf(params->debug_exists_file, TEXT("d2exp.mpq\n"));     break;
               case MPQ_D2CHAR        : fwprintf(params->debug_exists_file, TEXT("d2char.mpq\n"));    break;
               case MPQ_PATCH_D2      : fwprintf(params->debug_exists_file, TEXT("patch_d2.mpq\n"));  break;
               default : fwprintf(params->debug_exists_file, TEXT("? (%d)\n"), m);  break;
            }
         }
      }

      // DC6
      if (found == FALSE)
      {
         m = strlen(file);
         if (m > 1)
         {
            file[m - 1] = '6';
            for (m = 0; (m < MPQ_MAX) && (found == FALSE); m++)
            {
               if (mpq_order[m] == MPQ_MOD_DIRECTORY)
               {
                  char_to_wide_char(file, wc_file, sizeof(wc_file));
                  swprintf(wc_path, MAX_PATH, TEXT("%s%s"), myglobals.datas.mpq[MPQ_MOD_DIRECTORY].path, wc_file);
                  attr = GetFileAttributes(wc_path);
                  if ((attr != INVALID_FILE_ATTRIBUTES) && ((attr & FILE_ATTRIBUTE_DIRECTORY) == 0))
                  {
                     found = TRUE;
                     break;
                  }
               }
               else if (test_file_existence_from_mpq(mpq_order[m], file) == TRUE)
               {
                  found = TRUE;
                  break;
               }
            }
         }

         // debug
         if (params->debug_exists_file != NULL) 
         {
            fwprintf(params->debug_exists_file, TEXT("%s\t"), wc_file);
            if (found == FALSE)
               fwprintf(params->debug_exists_file, TEXT("NOT found\n"));
            else
            {
               switch(mpq_order[m])
               {
                  case MPQ_MOD_DIRECTORY : fwprintf(params->debug_exists_file, TEXT("Mod directory\n")); break;
                  case MPQ_D2DATA        : fwprintf(params->debug_exists_file, TEXT("d2data.mpq\n"));    break;
                  case MPQ_D2EXP         : fwprintf(params->debug_exists_file, TEXT("d2exp.mpq\n"));     break;
                  case MPQ_D2CHAR        : fwprintf(params->debug_exists_file, TEXT("d2char.mpq\n"));    break;
                  case MPQ_PATCH_D2      : fwprintf(params->debug_exists_file, TEXT("patch_d2.mpq\n"));  break;
                  default : fwprintf(params->debug_exists_file, TEXT("? (%d)\n"), m);  break;
               }
            }
         }
      }

      // if found, keep a trace and update the existence counter
      if (found == TRUE)
      {
         at->tab_DCC[i].exists = TRUE;
         params->curr_exists++;
         switch (params->r)
         {
            case AT_PLAYERS  : params->nb_tokens_players++;  break;
            case AT_MONSTERS : params->nb_tokens_monsters++; break;
            case AT_OBJECTS  : params->nb_tokens_objects++;  break;
         }
      }

      // update the progress bar, if needed
      params->curr_pos++;
      tmp_step = 100 * params->curr_pos / params->nb_files; // update the progress bar only 100 times
      if (tmp_step != params->curr_step)
      {
         params->curr_step = tmp_step;
         SendMessage(params->hpbar, PBM_SETPOS, (WPARAM) params->curr_pos + 1, (LPARAM) 0);
         SendMessage(params->hpbar, PBM_SETPOS, (WPARAM) params->curr_pos, (LPARAM) 0); // if you wonder why we do this, check http://stackoverflow.com/questions/1061715/how-do-i-make-tprogressbar-stop-lagging

         swprintf(wcString, sizeof(wcString) / 2, TEXT("%ld / %ld"), params->curr_pos, params->nb_files);
         SendMessage(params->hpnct, WM_SETTEXT, (WPARAM) 0, (LPARAM) wcString);

         swprintf(wcString, sizeof(wcString) / 2, TEXT("%ld\n%ld\n%ld\n%ld"), params->curr_exists, params->nb_tokens_players, params->nb_tokens_monsters, params->nb_tokens_objects);
         SendMessage(params->hexists, WM_SETTEXT, (WPARAM) 0, (LPARAM) wcString);
      }
   }

   return 0;
}


// ===========================================================================
// scan all COF of all animation types, and prepare tokens + weapon classes +
//   modes structures for all the COF selection listboxes
// return 0 on success
// ===========================================================================
int prepare_COF_selection_listboxes(void)
{
   LISTFILE_ANIMTYPE * d      = NULL;
   COF_ROW_EXISTS    * r      = NULL;
   TOKEN_DATAS       * td     = NULL;
   WEAPCLASS_DATAS   * wd     = NULL;
   int               a        = 0;
   long              c        = 0;
   long              last_c   = 0;
   STR_3_LETTERS     old_code = "";
   long              idx      = 0;
   long              t        = 0;
   long              w        = 0;


   for (a = 0; a < AT_MAX; a++)
   {
      d = & myglobals.listfile_datas.at[a];

      // count number of tokens
      d->nb_tokens = 0;
      strcpy(old_code, "");
      for (c = 0; c < d->nb_cofs; c++)
      {
         r = & d->tab_COF[c];
         if (r->exists != TRUE)
            continue;

         if (_stricmp(old_code, r->token) != 0)
         {
            d->nb_tokens++;
            strcpy(old_code, r->token);
         }
      }

      if (d->nb_tokens <= 0)
         continue;

      // allocate memory for the tokens table
      d->tab_token = (TOKEN_DATAS *) calloc(d->nb_tokens, sizeof(TOKEN_DATAS));
      if (d->tab_token == NULL)
         return 1;

      // copy tokens
      strcpy(old_code, "");
      idx = 0;
      for (c = 0; c < d->nb_cofs; c++)
      {
         r = & d->tab_COF[c];
         if (r->exists != TRUE)
            continue;

         if (_stricmp(old_code, r->token) != 0)
         {
            if (idx >= d->nb_tokens)
               return 1;

            strcpy(old_code, r->token);
            strcpy(d->tab_token[idx].code, r->token);
            d->tab_token[idx].first_COF_idx = c;
            if (idx > 0)
               d->tab_token[idx - 1].nb_cofs_for_token = c - d->tab_token[idx - 1].first_COF_idx;
            idx++;
         }
      }

      if (idx > 0)
         d->tab_token[idx - 1].nb_cofs_for_token = c - d->tab_token[idx - 1].first_COF_idx;

      // for each token
      for (t = 0; t < d->nb_tokens; t++)
      {
         td = & d->tab_token[t];
         last_c = td->first_COF_idx + td->nb_cofs_for_token;
         td->nb_weapon_class = 0;
         strcpy(old_code, "");

         // count number of weapon classes
         for (c = td->first_COF_idx; c < last_c; c++)
         {
            r = & d->tab_COF[c];
            if (r->exists != TRUE)
               continue;

            if (_stricmp(old_code, r->weapon_class) != 0)
            {
               td->nb_weapon_class++;
               strcpy(old_code, r->weapon_class);
            }
         }

         if (td->nb_weapon_class <= 0)
            return 1;

         // allocate memory for the weapon classes table
         td->tab_weapon_class = (WEAPCLASS_DATAS *) calloc(td->nb_weapon_class, sizeof(WEAPCLASS_DATAS));
         if (td->tab_weapon_class == NULL)
            return 1;

         // copy weapon classes
         strcpy(old_code, "");
         idx = 0;
         for (c = td->first_COF_idx; c < last_c; c++)
         {
            r = & d->tab_COF[c];
            if (r->exists != TRUE)
               continue;

            if (_stricmp(old_code, r->weapon_class) != 0)
            {
               if (idx >= td->nb_weapon_class)
                  return 1;

               strcpy(old_code, r->weapon_class);
               strcpy(td->tab_weapon_class[idx].code, r->weapon_class);
               td->tab_weapon_class[idx].first_COF_idx = c;
               if (idx > 0)
                  td->tab_weapon_class[idx - 1].nb_cofs_for_weapon_class = c - td->tab_weapon_class[idx - 1].first_COF_idx;
               idx++;
            }
         }

         if (idx > 0)
            td->tab_weapon_class[idx - 1].nb_cofs_for_weapon_class = c - td->tab_weapon_class[idx - 1].first_COF_idx;

         // for each weapon class
         for (w = 0; w < td->nb_weapon_class; w++)
         {
            wd = & td->tab_weapon_class[w];
            last_c = wd->first_COF_idx + wd->nb_cofs_for_weapon_class;

            // allocate memory for the modes table
            wd->tab_mode_code = (STR_2_LETTERS *) calloc(wd->nb_cofs_for_weapon_class, sizeof(STR_2_LETTERS));
            if (wd->tab_mode_code == NULL)
               return 1;

            // copy modes
            idx = 0;
            for (c = wd->first_COF_idx; c < last_c; c++)
            {
               r = & d->tab_COF[c];
               if (r->exists != TRUE)
                  continue;

               if (idx >= wd->nb_cofs_for_weapon_class)
                  return 1;

               strcpy(wd->tab_mode_code[idx], r->mode);
               idx++;
            }

            wd->nb_modes = idx;
         }
      }
   }

   return 0;
}


// ===========================================================================
// extract the needed elements of a COF row, and save it for later in a structure
// ===========================================================================
void process_DCC_row(char * row)
{
   ENUM_ANIMTYPE r   = AT_NULL;
   DCC_ROW       * p = NULL;
   DCC_ROW       d;


   if (row == NULL)
      return;

   r = get_root_path_type(row);
   if (r == AT_NULL)
      return;

   memset ( & d, 0, sizeof(d));
   if (extract_DCC_row_elements(r, row, & d.token, & d.weapon_class, & d.mode, & d.layer, & d.variant) == 0)
   {
      p = (DCC_ROW *) malloc(sizeof(d));
      if (p == NULL)
         return;

      memcpy(p, & d, sizeof(d));
      p->next = myglobals.listfile_datas.at[r].first_DCC;
      myglobals.listfile_datas.at[r].first_DCC = p;
   }

   return;
}


// ===========================================================================
// from a DCC row, extract token, weapon class, mode, layer and variant, in uppercase
// return 0 if success
// ===========================================================================
int extract_DCC_row_elements(ENUM_ANIMTYPE r, char * row, STR_2_LETTERS * token, STR_3_LETTERS * weapon_class, STR_2_LETTERS * mode, STR_2_LETTERS * layer, STR_3_LETTERS * variant)
{
   int           n      = 0;
   char          * cptr = NULL;
   STR_2_LETTERS token2 = "";
   STR_2_LETTERS layer2 = "";


   if (r == AT_NULL)
      return 1;

   if ((r < 0) || (r >= AT_MAX))
      return 1;

   if ((row == NULL) || (token == NULL) || (weapon_class == NULL) || (mode == NULL) || (layer == NULL) || (variant == NULL))
      return 1;

   if (validate_row(r, row, "$$\\$$\\$$$$$$$$$$$$.dcc") != 0)
   {
      if (validate_row(r, row, "$$\\$$\\$$$$$$$$$$$$.dc6") != 0)
         return 1;
   }

   n = strlen(myglobals.datas.root_path[r]);

   cptr = (char *) token;
   cptr[0] = row[n];
   cptr[1] = row[n + 1];
   cptr[2] = 0;

   cptr = (char *) layer;
   cptr[0] = row[n + 3];
   cptr[1] = row[n + 4];
   cptr[2] = 0;

   cptr = (char *) token2;
   cptr[0] = row[n + 6];
   cptr[1] = row[n + 7];
   cptr[2] = 0;

   cptr = (char *) layer2;
   cptr[0] = row[n + 8];
   cptr[1] = row[n + 9];
   cptr[2] = 0;

   cptr = (char *) variant;
   cptr[0] = row[n + 10];
   cptr[1] = row[n + 11];
   cptr[2] = row[n + 12];
   cptr[3] = 0;

   cptr = (char *) mode;
   cptr[0] = row[n + 13];
   cptr[1] = row[n + 14];
   cptr[2] = 0;

   cptr = (char *) weapon_class;
   cptr[0] = row[n + 15];
   cptr[1] = row[n + 16];
   cptr[2] = row[n + 17];
   cptr[3] = 0;

   make_string_uppercase((char *) token);
   make_string_uppercase((char *) token2);
   make_string_uppercase((char *) layer);
   make_string_uppercase((char *) layer2);
   make_string_uppercase((char *) mode);
   make_string_uppercase((char *) weapon_class);
   make_string_uppercase((char *) variant);

   if (strcmp((char *) token, (char *) token2) != 0)
      return 1;

   if (strcmp((char *) layer, (char *) layer2) != 0)
      return 1;

   return 0;
}


// ===========================================================================
// qsort helper function for comparing 2 DCC rows (case insensitive)
// order : token, weapon class, mode, layer, variant
// ===========================================================================
int qsort_helper_DCC(const void * a, const void * b)
{
    DCC_ROW_EXISTS * ca = (DCC_ROW_EXISTS *) a;
    DCC_ROW_EXISTS * cb = (DCC_ROW_EXISTS *) b;
    int            r    = 0;


    if ((a == NULL) || (b == NULL))
        return 0;

    r = stricmp(ca->token, cb->token);
    if (r == 0)
    {
        r = stricmp(ca->weapon_class, cb->weapon_class);
        if (r == 0)
        {
            r = stricmp(ca->mode, cb->mode);
            if (r == 0)
            {
                r = stricmp(ca->layer, cb->layer);
                if (r == 0)
                    return stricmp(ca->variant, cb->variant);
                else
                    return r;
            }
            else
                return r;
        }
        else
            return r;
    }
    else
        return r;
}


// ===========================================================================
// build the table of unique DCC datas for this animation type
// return 0 on success
// ===========================================================================
int build_DCC_existence_list(int r)
{
   LISTFILE_DATAS    * d        = NULL;
   LISTFILE_ANIMTYPE * at       = NULL;
   DCC_ROW           * f        = NULL;
   long              nb_dcc     = 0;
   DCC_ROW           * c        = NULL;
   DCC_ROW           * n        = NULL;
   DCC_ROW_EXISTS    * tab      = NULL;
   long              i          = 0;
   long              nb_uniques = 0;
   long              idx        = 0;


   d = & myglobals.listfile_datas;

   if ((r < 0) || (r >= AT_MAX))
      return 1;

   at = & d->at[r];
   f  = at->first_DCC;

   // count number of DCC found in the different listfiles (some are probably here multiple times)
   c = f;
   while (c != NULL)
   {
      nb_dcc++;
      c = c->next;
   }

   if (nb_dcc <= 1)
      return 1;

   // prepare a table to put them all
   tab = (DCC_ROW_EXISTS *) calloc(nb_dcc, sizeof(DCC_ROW_EXISTS));
   if (tab == NULL)
      return 1;

   // copy them
   c = f;
   for (i = 0; i < nb_dcc; i++)
   {
      if (c == NULL)
      {
         free(tab);
         return 1;
      }

      strncpy(tab[i].token,        c->token,        sizeof(STR_2_LETTERS));
      strncpy(tab[i].weapon_class, c->weapon_class, sizeof(STR_3_LETTERS));
      strncpy(tab[i].mode,         c->mode,         sizeof(STR_2_LETTERS));
      strncpy(tab[i].layer,        c->layer,        sizeof(STR_2_LETTERS));
      strncpy(tab[i].variant,      c->variant,      sizeof(STR_3_LETTERS));
      tab[i].exists = FALSE;

      c = c->next;
   }

   if (c != NULL)
   {
      free(tab);
      return 1;
   }

   // no need for the DCC linked list anymore
   c = f;
   while (c != NULL)
   {
      n = c->next;
      free(c);
      c = n;
   }
   at->first_DCC = NULL;

   // sort the table
   qsort(tab, nb_dcc, sizeof(DCC_ROW_EXISTS), qsort_helper_DCC);

   // identify each first unique element, count them along the way
   tab[0].exists = 1;
   nb_uniques = 1;
   for (i = 1; i < nb_dcc; i++)
   {
      if (qsort_helper_DCC((const void *) & tab[i - 1], (const void *) & tab[i]) != 0)
      {
         tab[i].exists = 1;
         nb_uniques++;
      }
   }

   // create the table of unique DCC to check for existence in MPQ
   at->nb_dcc = nb_uniques;
   at->tab_DCC = (DCC_ROW_EXISTS *) calloc(nb_uniques, sizeof(DCC_ROW_EXISTS));
   if (at->tab_DCC == NULL)
      return 1;

   // fill it
   idx = 0;
   for (i = 0; i < nb_dcc; i++)
   {
      if (tab[i].exists == 1)
      {
         if (idx >= nb_uniques)
         {
            free(tab);
            free(at->tab_DCC);
            at->tab_DCC = NULL;
            return 1;
         }
         else
         {
            memcpy(at->tab_DCC + idx, tab + i, sizeof(DCC_ROW_EXISTS));
            at->tab_DCC[idx].exists = FALSE;
            idx++;         
         }
      }
   }

   return 0;
}
