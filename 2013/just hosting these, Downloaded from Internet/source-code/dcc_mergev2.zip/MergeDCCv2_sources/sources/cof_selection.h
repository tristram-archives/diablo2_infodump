#ifndef __COF_SELECTION_H__
#define __COF_SELECTION_H__

#include "one_include_to_rule_them_all.h"

#include "enums.h"

void cof_selection_listbox_clicked (ENUM_COFSELTYPE type, int * is_new_COF);

#endif
