#ifndef __DCCTYPES_H__
#define __DCCTYPES_H__

#include "one_include_to_rule_them_all.h"

// to avoid all mention of : warning C4142: benign redefinition of type
#pragma warning(disable:4142)

typedef unsigned char      UBYTE;
typedef short int          WORD;
typedef unsigned short int UWORD;
typedef unsigned long      UDWORD;

#endif
