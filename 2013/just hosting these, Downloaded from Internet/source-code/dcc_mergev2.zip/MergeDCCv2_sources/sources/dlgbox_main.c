#include "one_include_to_rule_them_all.h"

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include "dlgbox_main.h"
#include "misc.h"
#include "strings_define.h"
#include "tools.h"
#include "mpq_handler.h"
#include "d2_files.h"
#include "loaders.h"
#include "cof_selection.h"
#include "dlgbox_setup.h"
#include "dlgbox_export.h"
#include "dccjob.h"


#define  DLGBOX_MAIN_NB_CHILDREN      (14 + (17 * DLGBOX_MAIN_CTRL_PER_ROW))
#define  DLGBOX_MAIN_ACCELERATORS_NB  1


static LRESULT CALLBACK     callback_dlgbox_main        (HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
static int                  reload_all_listfiles        (void);
static HMENU                create_main_menu            (void);
static int                  init_dropdown_list          (ENUM_DLGBOX_ID dialog_ID, int iChildIdx, DWORD dwParam, LPVOID lpParam);
static void                 modify_special_effect_level (HWND h, ENUM_CTRL_IDENTIFIER id, int display, int selected_row);
static ENUM_CTRL_IDENTIFIER get_layer_control_id        (ENUM_CTRL_IDENTIFIER base, int index);


// ===========================================================================
// initialize a dropdownlist combobox (mainly : special effect level)
// dwParam = number of elements of 4 characters each
// ===========================================================================
int init_dropdown_list(ENUM_DLGBOX_ID dialog_ID, int iChildIdx, DWORD dwParam, LPVOID lpParam)
{
   HWND h = NULL;

   lpParam = lpParam; // just to avoid a warning
   h = myglobals.dlgbox_datas[dialog_ID].dlg.pChild[iChildIdx].handle;
   if (h != NULL)
   {
      SendMessage(h, CB_INITSTORAGE,   (WPARAM) dwParam, dwParam * sizeof(WCHAR) * 4);
      // SendMessage(h, CB_SETMINVISIBLE, (WPARAM) 20, 0);
   }

   return 0;
}


// ===========================================================================
// create the dialog box window (with its children) : Main
// return 0 on success
// ===========================================================================
int create_dlgbox_main(HINSTANCE hInst, int iCmdShow)
{
   ENUM_DLGBOX_ID       dialog_ID        = DLG_MAIN;
   int                  dwidth           = 1072;
   int                  dheight          = 688;
   WNDCLASSEX           cw;
   DLGBOX_DATAS         * dd             = NULL;
   CREATE_DLGBOX        * d              = NULL;
   int                  child_idx        = -1;
   HWND                 h                = NULL;
   WCHAR                title      [200] = TEXT("");
   char                 version    [200] = "";
   WCHAR                wc_version [200] = TEXT("");
   HMENU                hMenu            = NULL;
   int                  i                = 0;
   int                  n                = 0;
   int                  i_label          = 0;
   int                  i_base           = 0;
   int                  i_group          = 0;
   int                  x                = 0;
   int                  y                = 0;
   int                  dx               = 0;
   int                  dy               = 0;
   int                  r                = 0;
   int                  idx              = 0;
   CREATE_DLGBOX_CHILD  c [DLGBOX_MAIN_NB_CHILDREN] =
   {
      // iChildID                      lpClassName    left top  width height         dwStyle                                                                                                    dwExStyle          lpWindowName               iFontID              lpParam pFuncInitChild      dwFuncInitChildParam lpFuncInitChildParam handle
      // ----------------------------  -------------  ---- ---  ----- -------------- ---------------------------------------------------------------------------------------------------------  -----------------  ------------------------  --------------------  ------- ------------------- -------------------- -------------------- ------
      {ID_DLGBOX_MAIN_COFSEL_GROUP,    WC_BUTTON,     10,  10,  300,  310,           WS_CHILD | WS_VISIBLE | BS_GROUPBOX,                                                                       0,                 TEXT("COF selection"),    FONT_VERDANA_13,      NULL,   NULL,               0,                   NULL,                NULL},

      {ID_DLGBOX_MAIN_ANIMTYPE_LABEL,  WC_STATIC,     20,  34,  70,   30,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, STR_LABEL_ANIMATION_TYPE, FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_TOKEN_LABEL,     WC_STATIC,     100, 48,  60,   20,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, STR_LABEL_TOKEN,          FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_WEAPCLASS_LABEL, WC_STATIC,     170, 34,  60,   30,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, STR_LABEL_WEAPON_CLASS,   FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_MODES_LABEL,     WC_STATIC,     240, 48,  60,   20,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, STR_LABEL_MODE,           FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},

      {ID_DLGBOX_MAIN_ANIMTYPE_LIST,   WC_LISTBOX,    20,  70,  70,   70,            WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER | LBS_DISABLENOSCROLL | LBS_NOTIFY,                         0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_TOKEN_LIST,      WC_LISTBOX,    100, 70,  60,   250,           WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER | LBS_DISABLENOSCROLL | LBS_NOTIFY | WS_VSCROLL | LBS_SORT, 0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_WEAPCLASS_LIST,  WC_LISTBOX,    170, 70,  60,   250,           WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER | LBS_DISABLENOSCROLL | LBS_NOTIFY | WS_VSCROLL | LBS_SORT, 0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_MODES_LIST,      WC_LISTBOX,    240, 70,  60,   250,           WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER | LBS_DISABLENOSCROLL | LBS_NOTIFY | WS_VSCROLL | LBS_SORT, 0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},

      {ID_DLGBOX_MAIN_ANIMATION,       WC_STATIC,     10,  330, 300,  300,           WS_CHILD | WS_VISIBLE /* | SS_SUNKEN*/,                                                                    0,                 NULL,                     FONT_NONE,            NULL,   NULL,               0,                   NULL,                NULL},

      {ID_DLGBOX_MAIN_BUT_DIR_MINUS,   WC_BUTTON,     320, 500, 90,   HEIGHT_BUT_14, WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON | BS_CENTER | BS_VCENTER,                               0,                 TEXT("Direction -"),      FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_BUT_DIR_PLUS,    WC_BUTTON,     420, 500, 90,   HEIGHT_BUT_14, WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON | BS_CENTER | BS_VCENTER,                               0,                 TEXT("Direction +"),      FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_NB_ANIM_COLORS,  WC_STATIC,     320, 617, 330,  14,            WS_CHILD | WS_VISIBLE | SS_LEFT,                                                                           0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},

      {ID_DLGBOX_MAIN_LAYER_GROUP,     WC_BUTTON,     320, 10,  732,  469,           WS_CHILD | WS_VISIBLE | BS_GROUPBOX,                                                                       0,                 TEXT("Layers"),           FONT_VERDANA_13,      NULL,   NULL,               0,                   NULL,                NULL},

      {ID_DLGBOX_MAIN_CODE_LABEL,      WC_STATIC,     0,   -22, 120,  20,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, TEXT("Code"),             FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_VARIANT_LABEL,   WC_STATIC,     0,   -22, 70,   20,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, TEXT("Variant"),          FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_CMAPTYPE_LABEL,  WC_STATIC,     0,   -36, 80,   34,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, TEXT("Colormap Type"),    FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_CMAPFILE_LABEL,  WC_STATIC,     0,   -36, 90,   34,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, TEXT("Colormap File"),    FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_CMAPINDEX_LABEL, WC_STATIC,     0,   -36, 70,   34,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, TEXT("Colormap Index"),   FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_GFXTYPE_LABEL,   WC_STATIC,     0,   -36, 200,  34,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, TEXT("Special Effect"),   FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_GFXLEVEL_LABEL,  WC_STATIC,     0,   -36, 70,   34,            WS_CHILD | WS_VISIBLE | SS_CENTER,                                                                         WS_EX_TRANSPARENT, TEXT("Sp. Effect Level"), FONT_VERDANA_14_BOLD, NULL,   NULL,               0,                   NULL,                NULL},

      {ID_DLGBOX_MAIN_CODE_BASE,       WC_COMBOBOX,   0,   0,   120,  20,            WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST,                                                     0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_VARIANT_BASE,    WC_COMBOBOX,   0,   0,   70,   20,            WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | WS_VSCROLL,                                        0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_CMAPTYPE_BASE,   WC_COMBOBOX,   0,   0,   80,   20,            WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST,                                                     0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_CMAPFILE_BASE,   WC_COMBOBOX,   0,   0,   90,   20,            WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST,                                                     0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_CMAPINDEX_BASE,  WC_COMBOBOX,   0,   0,   70,   20,            WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST,                                                     0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_GFXTYPE_BASE,    WC_COMBOBOX,   0,   0,   200,  20,            WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST,                                                     0,                 NULL,                     FONT_VERDANA_14,      NULL,   NULL,               0,                   NULL,                NULL},
      {ID_DLGBOX_MAIN_GFXLEVEL_BASE,   WC_COMBOBOX,   0,   0,   70,   20,            WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWNLIST | WS_VSCROLL,                                        0,                 NULL,                     FONT_VERDANA_14,      NULL,   init_dropdown_list, 256,                 NULL,                NULL},

      // reserved : 15 * DLGBOX_MAIN_CTRL_PER_ROW rows
   };
   // keyboard accelerators
   ACCEL tab_accelerators [DLGBOX_MAIN_ACCELERATORS_NB] =
   {
      {FVIRTKEY | FCONTROL, 0x58, ID_MENU_MAIN_EXPORT_ACCEL} /* Ctrl + X = File / Export */
   };


   // dynamic initialisation of (the label row + 16) rows * DLGBOX_MAIN_CTRL_PER_ROW controls per row

   for (i = 0; i < DLGBOX_MAIN_NB_CHILDREN; i++)
   {
      if (c[i].iChildID == ID_DLGBOX_MAIN_CODE_LABEL)
         i_label = i;
      else if (c[i].iChildID == ID_DLGBOX_MAIN_CODE_BASE)
         i_base = i;
      else if (c[i].iChildID == ID_DLGBOX_MAIN_LAYER_GROUP)
         i_group = i;
   }

   x  = c[i_group].left + 10;
   y  = c[i_group].top  + 60;
   dx = 2;
   dy = 25;

   for (r = 0; r < DLGBOX_MAIN_CTRL_PER_ROW; r++)
   {
      idx = i_label + r;
      c[idx].left  = x;
      c[idx].top  += y;
      x += c[idx].width + dx;
   }

   for (n = 1; n < 16; n++)
      for (r = 0; r < DLGBOX_MAIN_CTRL_PER_ROW; r++)
         memcpy( & c[i_base + n*DLGBOX_MAIN_CTRL_PER_ROW + r], & c[i_base + r], sizeof(CREATE_DLGBOX_CHILD));

   for (n = 0; n < 16; n++)
   {
      x  = c[i_group].left + 10;
      for (r = 0; r < DLGBOX_MAIN_CTRL_PER_ROW; r++)
      {
         idx = i_base + (n * DLGBOX_MAIN_CTRL_PER_ROW) + r;
         c[idx].iChildID += (n * DLGBOX_MAIN_CTRL_PER_ROW);
         c[idx].left      = x;
         c[idx].top       = y + (n * dy);
         x += c[idx].width + dx;
      }
   }

   // dynamic initialisation finished

   dd = & myglobals.dlgbox_datas[dialog_ID];
   d  = & dd->dlg;

   if (dd->is_active == TRUE)
      return 1;

   dd->type_modal = DLGMT_MODLESS;

   // window class
   cw.cbSize        = sizeof(WNDCLASSEX);
   cw.style         = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
   cw.lpfnWndProc   = callback_dlgbox_main;
   cw.cbClsExtra    = 0;
   cw.cbWndExtra    = 0;
   cw.hInstance     = hInst;
   cw.hIcon         = NULL;
   cw.hCursor       = LoadCursor(NULL, IDC_ARROW);
   cw.hbrBackground = GetSysColorBrush(COLOR_BTNFACE); // (HBRUSH) GetStockObject(WHITE_BRUSH) // CreateSolidBrush(RGB(255, 0, 255))
   cw.lpszMenuName  = NULL;
   cw.lpszClassName = STR_DLGBOX_MAIN_CLASS;
   cw.hIconSm       = NULL;

   d->pWndClassEx = & cw;

   sprintf(version, "v. Alpha, %s, %s", __DATE__, __TIME__);
   char_to_wide_char(version, wc_version, sizeof(wc_version));
   swprintf(title, sizeof(title) / 2, TEXT("%s (%s)"), STR_DLGBOX_MAIN_WINDOW_NAME, wc_version);

   // menu
   hMenu = create_main_menu();
   MYASSERT_RETURN(hMenu != NULL, 1, "hMenu = create_main_menu()");

   // keyboard accelerators
   myglobals.datas.hAccel = CreateAcceleratorTable(tab_accelerators, DLGBOX_MAIN_ACCELERATORS_NB);
   MYASSERT_RETURN(myglobals.datas.hAccel != NULL, 1, "hAccel = CreateAcceleratorTable()");

   // window
   d->window.hWndParent            = NULL;
   d->window.left                  = 130; // get_x_to_center_into_screen(dwidth);
   d->window.top                   = 240; // get_y_to_center_into_screen(dheight);
   d->window.width                 = dwidth;
   d->window.height                = dheight;
   d->window.dwStyle               = WS_SYSMENU;
   d->window.dwExStyle             = 0;
   d->window.lpWindowName          = title;
   d->window.hMenu                 = hMenu;
   d->window.lpParam               = NULL;
   d->window.pFuncInitDialog       = NULL;
   d->window.dwFuncInitDialogParam = 0;
   d->window.lpFuncInitDialogParam = NULL;
   d->window.handle                = NULL;

   // children
   d->nbChildren = DLGBOX_MAIN_NB_CHILDREN;
   d->pChild = (CREATE_DLGBOX_CHILD *) calloc(d->nbChildren + 1, sizeof(CREATE_DLGBOX_CHILD));
   MYASSERT_RETURN(d->pChild != NULL, 1, "calloc() error");
   memcpy(d->pChild, c, sizeof(c));

   // create the dialog
   MYASSERT_RETURN(create_dialog(dialog_ID) == 0, 1, NULL);

   // init the listboxes

   if (get_dialog_child_index_from_ID(dialog_ID, ID_DLGBOX_MAIN_ANIMTYPE_LIST, & child_idx) == 0)
   {
      h = d->pChild[child_idx].handle;
      SendMessage(h, LB_INITSTORAGE, (WPARAM) AT_MAX, (LPARAM) 200);
      SendMessage(h, LB_ADDSTRING, (WPARAM) 0, (LPARAM) TEXT("Players"));
      SendMessage(h, LB_ADDSTRING, (WPARAM) 0, (LPARAM) TEXT("Monsters"));
      SendMessage(h, LB_ADDSTRING, (WPARAM) 0, (LPARAM) TEXT("Objects"));
   }

   if (get_dialog_child_index_from_ID(dialog_ID, ID_DLGBOX_MAIN_TOKEN_LIST, & child_idx) == 0)
      SendMessage(d->pChild[child_idx].handle, LB_INITSTORAGE, (WPARAM) 2000, (LPARAM) 2000 * sizeof(STR_2_LETTERS) * 2);

   if (get_dialog_child_index_from_ID(dialog_ID, ID_DLGBOX_MAIN_WEAPCLASS_LIST, & child_idx) == 0)
      SendMessage(d->pChild[child_idx].handle, LB_INITSTORAGE, (WPARAM) 50, (LPARAM) 50 * sizeof(STR_2_LETTERS) * 2);

   if (get_dialog_child_index_from_ID(dialog_ID, ID_DLGBOX_MAIN_MODES_LIST, & child_idx) == 0)
      SendMessage(d->pChild[child_idx].handle, LB_INITSTORAGE, (WPARAM) 50, (LPARAM) 50 * sizeof(STR_2_LETTERS) * 2);

   // load all listfiles, and update COF selection listboxes in consequence
   MYASSERT_RETURN(reload_all_listfiles() == 0, 1, NULL);

   // show and draw it
   ShowWindow(d->window.handle, iCmdShow); // SW_SHOWNORMAL
   UpdateWindow(d->window.handle);
   SetFocus(d->window.handle);

   return 0;
}


// ===========================================================================
// callback function for the dialog box : Main
// ===========================================================================
LRESULT CALLBACK callback_dlgbox_main(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
   int                  i                   = 0;
   int                  id                  = ID_NULL;
   int                  is_new_COF          = FALSE;
   ENUM_DLGBOX_ID       dialog_ID           = DLG_MAIN;
   int                  child_idx           = -1;
   CREATE_DLGBOX        * d                 = NULL;
   HWND                 h                   = NULL;
   int                  layer_idx           = -1;
   int                  COF_layer_idx       = -1;
   int                  ctrl_idx            = -1;
   DCC_ROW_EXISTS       * pDcc              = NULL;
   LAYER_DATAS          * pLayer            = NULL;
   int                  row                 = 0;
   ANIMATION_DCC        dcc;
   int                  update_cache        = FALSE;
   short int            mouse_x             = 0;
   short int            mouse_y             = 0;
   static int           animation_is_moving = FALSE;
   static MOVING_TYPE   moving_type         = MOVING_NULL;
   static int           start_x             = 0;
   static int           start_y             = 0;
   static int           anim_start_x        = 0;
   static int           anim_start_y        = 0;
   CREATE_DLGBOX_CHILD  * pChild            = NULL;
   ENUM_CTRL_IDENTIFIER id_sp_eff_lev       = ID_NULL;
   COF_ROW_EXISTS       * pCof              = NULL;


   switch(msg)
   {
      case WM_TIMER :
         if (myglobals.dlgbox_datas[DLG_EXPORT].is_active == TRUE)
            PostMessage(myglobals.dlgbox_datas[DLG_EXPORT].dlg.window.handle, WM_TIMER, wParam, lParam);
         break;

      case WM_MOUSEMOVE : // the mouse is moving -------------------------------------------------------------
         mouse_x = LOWORD (lParam);
         mouse_y = HIWORD (lParam);
         if (animation_is_moving == TRUE)
            set_anim_user_offsets(myglobals.animation, anim_start_x + (mouse_x - start_x), anim_start_y + (mouse_y - start_y), moving_type);
         return 0;

      case WM_LBUTTONDBLCLK : // mouse left button double click --------------------------------------------------
         if (animation_is_moving == TRUE)
            break;
         else
         {
            mouse_x = LOWORD (lParam);
            mouse_y = HIWORD (lParam);
            if (get_dialog_child_index_from_ID(DLG_MAIN, ID_DLGBOX_MAIN_ANIMATION, & child_idx) == 0)
            {
               pChild = & myglobals.dlgbox_datas[DLG_MAIN].dlg.pChild[child_idx];
               if ( (mouse_x >= pChild->left) && (mouse_x < (pChild->left + pChild->width )) && 
                    (mouse_y >= pChild->top)  && (mouse_y < (pChild->top  + pChild->height)) )
               {
                  // reset the offsets of the animation (or the pivot) to their original positions
                  set_anim_user_offsets(myglobals.animation, 0, 0, (wParam & MK_CONTROL) ? MOVING_PIVOT : MOVING_ANIMATION);
                  return 0;
               }
            }
         }
         break;

      case WM_LBUTTONDOWN : // mouse left button pushed down ---------------------------------------------------------------
         if (animation_is_moving == TRUE)
            break;
         else
         {
            mouse_x = LOWORD (lParam);
            mouse_y = HIWORD (lParam);
            if (get_dialog_child_index_from_ID(DLG_MAIN, ID_DLGBOX_MAIN_ANIMATION, & child_idx) == 0)
            {
               pChild = & myglobals.dlgbox_datas[DLG_MAIN].dlg.pChild[child_idx];
               if ( (mouse_x >= pChild->left) && (mouse_x < (pChild->left + pChild->width )) && 
                    (mouse_y >= pChild->top)  && (mouse_y < (pChild->top  + pChild->height)) )
               {
                  animation_is_moving = TRUE;

                  moving_type = MOVING_ANIMATION;
                  if (wParam & MK_CONTROL)
                     moving_type = MOVING_PIVOT;

                  start_x = mouse_x;
                  start_y = mouse_y;
                  SetCapture(myglobals.dlgbox_datas[DLG_MAIN].dlg.window.handle);
                  get_anim_user_offsets(myglobals.animation, & anim_start_x, & anim_start_y, moving_type);
               }
            }
            return 0;
         }
         break;

      case WM_LBUTTONUP : // mouse left button released --------------------------------------------------------------------
         if (animation_is_moving == FALSE)
            break;
         else
         {
            mouse_x = LOWORD (lParam);
            mouse_y = HIWORD (lParam);
            set_anim_user_offsets(myglobals.animation, anim_start_x + (mouse_x - start_x), anim_start_y + (mouse_y - start_y), moving_type);
            animation_is_moving = FALSE;
            moving_type = MOVING_NULL;
            ReleaseCapture();
            return 0;
         }
         break;

      case WM_APP_MPQ_PATHS_CHANGED : // Application private message ---------------------------------
         // MPQ paths have changed, reload all files  
         for (i = 0; i < MPQ_MAX; i++)
         {
            if (i == MPQ_MOD_DIRECTORY)
               continue;

            if (myglobals.datas.mpq[i].storm_handle != NULL)
               close_mpq((ENUM_MPQ) i);

            if (open_mpq((ENUM_MPQ) i) != 0)
               myglobals.datas.mpq[i].path[0] = 0;
         }

         // a mod Directory or an mpq path has changed, reload all Diablo II ressource files
         destroy_cache();
         reload_all_listfiles();
         if (load_d2_ressources() != 0)
            MessageBox(NULL, STR_ERROR_SETUP_MPQ_PATHS, TEXT("Diablo II Ressource file(s) not found"), MB_ICONWARNING | MB_OK);
         debug_cache();

         pCof = myglobals.cof_selection.current_cof;
         if (pCof != NULL)
         {
            get_anim_user_offsets(myglobals.animation, & pCof->user_anim_offset_x,  & pCof->user_anim_offset_y,  MOVING_ANIMATION);
            get_anim_user_offsets(myglobals.animation, & pCof->user_pivot_offset_x, & pCof->user_pivot_offset_y, MOVING_PIVOT);
         }

         load_current_cof();

         pCof = myglobals.cof_selection.current_cof;
         if (pCof != NULL)
         {
            set_anim_user_offsets(myglobals.animation, pCof->user_anim_offset_x,  pCof->user_anim_offset_y,  MOVING_ANIMATION);
            set_anim_user_offsets(myglobals.animation, pCof->user_pivot_offset_x, pCof->user_pivot_offset_y, MOVING_PIVOT);
         }
         break;

      case WM_APP_UPDATE_ANIMATION : // Application private message ---------------------------------
         // it's time to draw a new frame of the animation
         if (myglobals.animation != NULL)
         {
            if (myglobals.drawing_animation == FALSE)
            {
               myglobals.drawing_animation = TRUE;
               draw_current_animation_frame(myglobals.animation);
               myglobals.drawing_animation = FALSE;
            }
         }
         myglobals.update_animation_message_posted = FALSE;
         return 0;

      case WM_CTLCOLORSTATIC: // STATIC ------------------------------------------------------------
         id  = LOWORD(wParam);
         if ((id == ID_DLGBOX_MAIN_ANIMTYPE_LABEL) || (id == ID_DLGBOX_MAIN_TOKEN_LABEL) || (id == ID_DLGBOX_MAIN_WEAPCLASS_LABEL) || (id == ID_DLGBOX_MAIN_MODES_LABEL))
         {
            SetBkMode((HDC) wParam, TRANSPARENT);
            SetTextColor((HDC) wParam, GetSysColor(COLOR_WINDOWTEXT));
            //SetBkColor((HDC) wParam, GetSysColor(COLOR_BTNFACE));
            return (LRESULT) GetStockObject(HOLLOW_BRUSH);
         }
         else if (id == ID_DLGBOX_MAIN_NB_ANIM_COLORS)
         {
            SetBkMode((HDC) wParam, OPAQUE);
            SetBkColor((HDC) wParam, GetSysColor(COLOR_BTNFACE));
            SetTextColor((HDC) wParam, GetSysColor(COLOR_WINDOWTEXT));
            SetDCBrushColor((HDC) wParam, GetSysColor(COLOR_BTNFACE));
            return (LRESULT) GetStockObject(DC_BRUSH);
         }
         break;

      case WM_COMMAND : // BUTTON, LISTBOX, EDIT, COMBOBOX ----------------------------------------------------
         id  = LOWORD(wParam);
         if ((id >= ID_DLGBOX_MAIN_CODE_BASE) && (id < ID_RESERVED_01))
         {
            d             = & myglobals.dlgbox_datas[dialog_ID].dlg;
            layer_idx     = (id - ID_DLGBOX_MAIN_CODE_BASE) / DLGBOX_MAIN_CTRL_PER_ROW;
            ctrl_idx      = (id - ID_DLGBOX_MAIN_CODE_BASE) % DLGBOX_MAIN_CTRL_PER_ROW;
            COF_layer_idx = myglobals.application_datas.control_to_COF_layer_map[layer_idx];
            pLayer        = & myglobals.cof_selection.current_cof->layer_datas[COF_layer_idx];
            switch (ctrl_idx)
            {
               case 1 :
                  // variant
                  if (HIWORD(wParam) == CBN_SELCHANGE)
                  {
                     if (get_dialog_child_index_from_ID(dialog_ID, (ENUM_CTRL_IDENTIFIER) id, & child_idx) == 0)
                     {
                        h = d->pChild[child_idx].handle;
                        row = SendMessage(h, CB_GETCURSEL, 0, 0);
                        if (row != CB_ERR)
                        {
                           pDcc = (DCC_ROW_EXISTS *) SendMessage(h, CB_GETITEMDATA, row, 0);
                           if (pDcc == NULL)
                              strcpy(pLayer->variant, "");
                           else
                              strcpy(pLayer->variant, pDcc->variant);

                           // load new dcc
                           memset( & dcc, 0, sizeof(dcc));
                           dcc.layer_idx = pLayer->code_idx;
                           load_layer_DCC(COF_layer_idx, & dcc, & update_cache);
                           if (update_cache == TRUE)
                              debug_cache();

                           {
                              long job_ID = get_new_job_ID();

                              add_layer_to_animation_part1(myglobals.animation, & dcc, job_ID);
                              dccjob_wait_for_tasks(job_ID);
                              add_layer_to_animation_part2(myglobals.animation, & dcc);
                           }

                           if (dcc.file != NULL)
                           {
                              free(dcc.file);
                              dcc.file = NULL;
                           }

                           update_animation_nb_colors_control();
                        }
                     }

                  }
                  return 0;

               case 5 :
                  // special effect
                  if (HIWORD(wParam) == CBN_SELCHANGE)
                  {
                     if (get_dialog_child_index_from_ID(dialog_ID, (ENUM_CTRL_IDENTIFIER) id, & child_idx) == 0)
                     {
                        h = d->pChild[child_idx].handle;
                        row = SendMessage(h, CB_GETCURSEL, 0, 0);
                        if (row != CB_ERR)
                        {
                           switch(row)
                           {
                              case 0 : i = -1; break;
                              case 1 : i =  0; break;
                              case 2 : i =  1; break;
                              case 3 : i =  2; break;
                              case 4 : i =  3; break;
                              case 5 : i =  4; break;
                              case 6 : i =  6; break;
                              case 7 : i =  7; break;
                           }
                           set_layer_transparency_type_user(myglobals.animation, pLayer->code_idx, i);
                           pLayer->transparency_type_user = i;
                           id_sp_eff_lev = get_layer_control_id(ID_DLGBOX_MAIN_GFXLEVEL_BASE, layer_idx);
                           if (get_dialog_child_index_from_ID(dialog_ID, id_sp_eff_lev, & child_idx) == 0)
                           {
                              h = d->pChild[child_idx].handle;
                              modify_special_effect_level(h, id_sp_eff_lev, (row == 7) ? TRUE : FALSE, pLayer->special_effect_level);
                              set_layer_special_effect_level(myglobals.animation, pLayer->code_idx, pLayer->special_effect_level);
                           }

                        }
                     }
                  }
                  return 0;

               case 6 :
                  // special effect level
                  if (HIWORD(wParam) == CBN_SELCHANGE)
                  {
                     if (get_dialog_child_index_from_ID(dialog_ID, (ENUM_CTRL_IDENTIFIER) id, & child_idx) == 0)
                     {
                        h = d->pChild[child_idx].handle;
                        row = SendMessage(h, CB_GETCURSEL, 0, 0);
                        if (row != CB_ERR)
                        {
                           pLayer->special_effect_level = row;
                           set_layer_special_effect_level(myglobals.animation, pLayer->code_idx, row);
                        }
                     }
                  }
                  return 0;
            }
         }
         else
         {
            switch (id)
            {
               case ID_DLGBOX_MAIN_ANIMTYPE_LIST :
               case ID_DLGBOX_MAIN_TOKEN_LIST :
               case ID_DLGBOX_MAIN_WEAPCLASS_LIST :
               case ID_DLGBOX_MAIN_MODES_LIST :
                  // COF Selection
                  if (HIWORD(wParam) == LBN_SELCHANGE)
                  {
                     is_new_COF = FALSE;
                     cof_selection_listbox_clicked(get_cst_enum_from_id(id), & is_new_COF);
                     if (is_new_COF == TRUE)
                     {
                        pCof = myglobals.cof_selection.current_cof;
                        if (pCof != NULL)
                        {
                           get_anim_user_offsets(myglobals.animation, & pCof->user_anim_offset_x,  & pCof->user_anim_offset_y,  MOVING_ANIMATION);
                           get_anim_user_offsets(myglobals.animation, & pCof->user_pivot_offset_x, & pCof->user_pivot_offset_y, MOVING_PIVOT);
                        }

                        load_current_cof();

                        pCof = myglobals.cof_selection.current_cof;
                        if (pCof != NULL)
                        {
                           set_anim_user_offsets(myglobals.animation, pCof->user_anim_offset_x,  pCof->user_anim_offset_y,  MOVING_ANIMATION);
                           set_anim_user_offsets(myglobals.animation, pCof->user_pivot_offset_x, pCof->user_pivot_offset_y, MOVING_PIVOT);
                        }
                     }
                  }
                  return 0;

               case ID_MENU_MAIN_EXPORT :
               case ID_MENU_MAIN_EXPORT_ACCEL :
                  // open the export dialog
                  if (myglobals.dlgbox_datas[DLG_EXPORT].is_active == FALSE)
                  {
                     if ((HIWORD(wParam) == BN_CLICKED) || (HIWORD(wParam) == 1))
                        create_dlgbox_export();
                  }
                  return 0;

               case ID_MENU_MAIN_OPTIONS :
                  // open the setup dialog
                  if (HIWORD(wParam) == BN_CLICKED)
                     create_dlgbox_setup();
                  return 0;

               case ID_MENU_MAIN_EXIT :
                  // exit the application
                  PostQuitMessage(WM_QUIT);
                  return 0;

               case ID_DLGBOX_MAIN_BUT_DIR_MINUS :
                  // animation direction --
                  if (myglobals.animation != NULL)
                     animation_direction_minus(myglobals.animation);
                  return 0;

               case ID_DLGBOX_MAIN_BUT_DIR_PLUS :
                  // animation direction ++
                  if (myglobals.animation != NULL)
                     animation_direction_plus(myglobals.animation);
                  return 0;
            }
         }
         break;

      case WM_DESTROY: // exit the application -------------------------------------------------
         if (myglobals.datas.allegro_initialized == TRUE)
         {
            destroy_animation( & myglobals.animation);
            my_allegro_exit();
            myglobals.datas.allegro_initialized = FALSE;
         }
         PostQuitMessage(WM_QUIT);
         return 0;
   }

   return DefWindowProc(hwnd, msg, wParam, lParam);
}


// ===========================================================================
// reload all the listfiles, then update the COF selection listboxes
// return 0 on succees
// ===========================================================================
int reload_all_listfiles(void)
{
   WCHAR message [500] = TEXT("");
   int   ret           = 0;
   int   is_new_COF    = FALSE;


   destroy_listfiles();

   // load the application listfile and the MPQ internal listfiles, then build some lists
   ret = load_all_listfiles();
   modify_enable_state_by_child_ID(DLG_COF_IN_PROGRESS, ID_DLGBOX_COF_IN_P_OK, TRUE); // now the OK button must be clikable
   if (ret != 0)
   {
      swprintf(message, sizeof(message) / 2, TEXT("load_all_listfiles() != 0"));
      MessageBox(NULL, message, TEXT("Error"), MB_ICONERROR | MB_OK);
      return 1;
   }

   // initialize all the COF selection listboxes
   cof_selection_listbox_clicked(CST_NONE, & is_new_COF); // CST_NONE is special case for total reinitialisation

   return 0;
}


// ===========================================================================
// create the application main menu
// ===========================================================================
HMENU create_main_menu(void)
{
   HMENU hMenu   = NULL;
   HMENU hFile   = NULL;
   HMENU hEdit   = NULL;
   HMENU hWindow = NULL;
   HMENU hHelp   = NULL;


   MYASSERT_RETURN((hFile   = CreateMenu()) != NULL, NULL, NULL);
   MYASSERT_RETURN((hEdit   = CreateMenu()) != NULL, NULL, NULL);
   MYASSERT_RETURN((hWindow = CreateMenu()) != NULL, NULL, NULL);
   MYASSERT_RETURN((hHelp   = CreateMenu()) != NULL, NULL, NULL);
   MYASSERT_RETURN((hMenu   = CreateMenu()) != NULL, NULL, NULL);

   MYASSERT_RETURN(AppendMenu(hFile,   MF_ENABLED | MF_STRING | MF_UNCHECKED,            ID_MENU_MAIN_EXPORT,      TEXT("Export...\tCtrl+X")  ) != 0, NULL, NULL);
   MYASSERT_RETURN(AppendMenu(hFile,   MF_SEPARATOR,                                     0,                        NULL                       ) != 0, NULL, NULL);
   MYASSERT_RETURN(AppendMenu(hFile,   MF_ENABLED | MF_STRING | MF_UNCHECKED,            ID_MENU_MAIN_EXIT,        TEXT("Exit\tAlt+F4")       ) != 0, NULL, NULL);

   MYASSERT_RETURN(AppendMenu(hEdit,   MF_GRAYED  | MF_STRING | MF_UNCHECKED,            ID_MENU_MAIN_COPY,        TEXT("Copy")               ) != 0, NULL, NULL);
   MYASSERT_RETURN(AppendMenu(hEdit,   MF_SEPARATOR,                                     0,                        NULL                       ) != 0, NULL, NULL);
   MYASSERT_RETURN(AppendMenu(hEdit,   MF_ENABLED | MF_STRING | MF_UNCHECKED,            ID_MENU_MAIN_OPTIONS,     TEXT("Preferences...")     ) != 0, NULL, NULL);

   MYASSERT_RETURN(AppendMenu(hWindow, MF_GRAYED  | MF_STRING | MF_CHECKED,              ID_MENU_MAIN_WINDOWCACHE, TEXT("Cache Informations") ) != 0, NULL, NULL);

   MYASSERT_RETURN(AppendMenu(hHelp,   MF_GRAYED  | MF_STRING | MF_UNCHECKED,            ID_MENU_MAIN_ABOUT,       TEXT("About...")           ) != 0, NULL, NULL);

   MYASSERT_RETURN(AppendMenu(hMenu,   MF_ENABLED | MF_STRING | MF_UNCHECKED | MF_POPUP, (UINT_PTR) hFile,         TEXT("File")               ) != 0, NULL, NULL);
   MYASSERT_RETURN(AppendMenu(hMenu,   MF_ENABLED | MF_STRING | MF_UNCHECKED | MF_POPUP, (UINT_PTR) hEdit,         TEXT("Edit")               ) != 0, NULL, NULL);
   MYASSERT_RETURN(AppendMenu(hMenu,   MF_ENABLED | MF_STRING | MF_UNCHECKED | MF_POPUP, (UINT_PTR) hWindow,       TEXT("Window")             ) != 0, NULL, NULL);
   MYASSERT_RETURN(AppendMenu(hMenu,   MF_ENABLED | MF_STRING | MF_UNCHECKED | MF_POPUP, (UINT_PTR) hHelp,         TEXT("Help")               ) != 0, NULL, NULL);

   return hMenu;
}


// ===========================================================================
// helper for init_layer_controls()
// ===========================================================================
ENUM_CTRL_IDENTIFIER get_layer_control_id(ENUM_CTRL_IDENTIFIER base, int index)
{
   return (ENUM_CTRL_IDENTIFIER) (base + (index * DLGBOX_MAIN_CTRL_PER_ROW));
}


// ===========================================================================
// update layers control with current selected COF datas
// ===========================================================================
void init_layer_controls(void)
{
   ENUM_DLGBOX_ID       dialog_ID      = DLG_MAIN;
   DLGBOX_DATAS         * dd           = NULL;
   CREATE_DLGBOX        * d            = NULL;
   int                  child_idx      = -1;
   HWND                 h              = NULL;
   ENUM_CTRL_IDENTIFIER id             = ID_NULL;
   COF_ROW_EXISTS       * pCof         = myglobals.cof_selection.current_cof;
   DCC_ROW_EXISTS       * pDcc         = NULL;
   int                  i              = 0;
   int                  c              = 0;
   LAYER_DATAS          * pLayer       = NULL;
   WCHAR                str[100]       = TEXT("");
   int                  r              = 0;
   int                  n              = 0;
   int                  pos            = -1;
   int                  p              = -1;
   char                 str_char[100]  = "";
   int                  s              = 0;
   int                  s_default      = 0;
   WCHAR                * tag_default  = NULL;
   int                  display_levels = FALSE;


   dd = & myglobals.dlgbox_datas[dialog_ID];
   d  = & dd->dlg;

   // clear all dialogs, and disable the unused ones in the COF
   for (i = 0; i < 16; i++)
   {
      for (c = 0; c < 7; c++)
      {
         id = ID_NULL;
         switch (c)
         {
            case 0 : id = get_layer_control_id(ID_DLGBOX_MAIN_CODE_BASE,      i); break;
            case 1 : id = get_layer_control_id(ID_DLGBOX_MAIN_VARIANT_BASE,   i); break;
            case 2 : id = get_layer_control_id(ID_DLGBOX_MAIN_CMAPTYPE_BASE,  i); break;
            case 3 : id = get_layer_control_id(ID_DLGBOX_MAIN_CMAPFILE_BASE,  i); break;
            case 4 : id = get_layer_control_id(ID_DLGBOX_MAIN_CMAPINDEX_BASE, i); break;
            case 5 : id = get_layer_control_id(ID_DLGBOX_MAIN_GFXTYPE_BASE,   i); break;
            case 6 : id = get_layer_control_id(ID_DLGBOX_MAIN_GFXLEVEL_BASE,  i); break;
         }

         if (get_dialog_child_index_from_ID(dialog_ID, id, & child_idx) == 0)
         {
            h = d->pChild[child_idx].handle;
            SendMessage(h, CB_RESETCONTENT, 0, 0);
            if ( (pCof == NULL) || ((pCof != NULL) && (i >= pCof->nb_layers)) )
               modify_enable_state_by_child_ID(dialog_ID, id, FALSE);
            else
               modify_enable_state_by_child_ID(dialog_ID, id, TRUE);
         }
      }
   }


   for (i = 0; i < 16; i++)
      myglobals.application_datas.control_to_COF_layer_map[i] = -1;

   if (pCof == NULL)
      return;

   // display layer datas. In composit.txt order, not order of appereance in the COF

   r = 0;
   for (i = 0; i < 16; i++)
   {
      for (n = 0; n < pCof->nb_layers; n++)
      {
         pLayer = & pCof->layer_datas[n];
         if (pLayer->code_idx != i)
            continue;

         myglobals.application_datas.control_to_COF_layer_map[r] = n;

         // code
         id = get_layer_control_id(ID_DLGBOX_MAIN_CODE_BASE, r);
         if (get_dialog_child_index_from_ID(dialog_ID, id, & child_idx) == 0)
         {
            h = d->pChild[child_idx].handle;
            if ((pLayer->code_idx >= 0) && (pLayer->code_idx < myglobals.application_datas.nb_layers))
            {
               swprintf(str, sizeof(str) / 2, TEXT("%s, %s"), pLayer->code_wchar, myglobals.application_datas.tab_layer[pLayer->code_idx].name);
               SendMessage(h, CB_ADDSTRING, 0, (LPARAM) str);
               SendMessage(h, CB_SETCURSEL, 0, 0);
            }
            else
            {
               swprintf(str, sizeof(str) / 2, TEXT("0x%02X, invalid"), pLayer->code_idx);
               SendMessage(h, CB_ADDSTRING, 0, (LPARAM) str);
               SendMessage(h, CB_SETCURSEL, 0, 0);
            }
         }

         // variant
         id = get_layer_control_id(ID_DLGBOX_MAIN_VARIANT_BASE, r);
         if (get_dialog_child_index_from_ID(dialog_ID, id, & child_idx) == 0)
         {
            h = d->pChild[child_idx].handle;

            p = SendMessage(h, CB_ADDSTRING, 0, (LPARAM) STR_LAYER_VARIANT_NONE);
            SendMessage(h, CB_SETITEMDATA, (WPARAM) p, (LPARAM) NULL);

            pDcc = pLayer->first_variant;
            pos = -1;
            while (pDcc != NULL)
            {
               if ( (strcmp(pCof->token,                 pDcc->token       ) == 0) &&
                    (strcmp(pLayer->weapon_class_in_cof, pDcc->weapon_class) == 0) &&
                    (strcmp(pCof->mode,                  pDcc->mode        ) == 0) &&
                    (strcmp(pLayer->code_char,           pDcc->layer       ) == 0) )
               {
                  if (pDcc->exists == TRUE)
                  {
                     strcpy(str_char, pDcc->variant);
                     char_to_wide_char(str_char, str, sizeof(str));
                     if (strcmp(pDcc->variant, pLayer->variant) == 0)
                     {
                        pos = SendMessage(h, CB_ADDSTRING, 0, (LPARAM) str);
                        SendMessage(h, CB_SETITEMDATA, (WPARAM) pos, (LPARAM) pDcc);
                        SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0);
                     }
                     else
                     {
                        p = SendMessage(h, CB_ADDSTRING, 0, (LPARAM) str);
                        SendMessage(h, CB_SETITEMDATA, (WPARAM) p, (LPARAM) pDcc);
                     }
                  }
                  pDcc++;
               }
               else
                  pDcc = NULL;
            }

            if (pos == -1)
               SendMessage(h, CB_SETCURSEL, 0, 0);
         }

         // FIXME : colormap type / file / index

         // special effect
         display_levels = FALSE;
         id = get_layer_control_id(ID_DLGBOX_MAIN_GFXTYPE_BASE, r);
         if (get_dialog_child_index_from_ID(dialog_ID, id, & child_idx) == 0)
         {
            h = d->pChild[child_idx].handle;

            s_default = 0;
            if (pLayer->transparency != 0)
            {
               switch (pLayer->transparency_type)
               {
                  case 0 : s_default = 1; break;
                  case 1 : s_default = 2; break;
                  case 2 : s_default = 3; break;
                  case 3 : s_default = 4; break;
                  case 4 : s_default = 5; break;
                  case 6 : s_default = 6; break;
               }
            }

            for (s = 0; s < 8; s++)
            {
               tag_default = TEXT("");
               if (s == s_default)
                  tag_default = TEXT(" (*)");

               switch (s)
               {
                  case 0 : swprintf(str, sizeof(str) / 2, TEXT("(none)%s"),                  tag_default); break;
                  case 1 : swprintf(str, sizeof(str) / 2, TEXT("25%% translucency%s"),       tag_default); break;
                  case 2 : swprintf(str, sizeof(str) / 2, TEXT("50%% translucency%s"),       tag_default); break;
                  case 3 : swprintf(str, sizeof(str) / 2, TEXT("75%% translucency%s"),       tag_default); break;
                  case 4 : swprintf(str, sizeof(str) / 2, TEXT("alpha blending%s"),          tag_default); break;
                  case 5 : swprintf(str, sizeof(str) / 2, TEXT("luminance%s"),               tag_default); break;
                  case 6 : swprintf(str, sizeof(str) / 2, TEXT("spider web translucency%s"), tag_default); break;
                  case 7 : swprintf(str, sizeof(str) / 2, TEXT("[delete dark pixels]")); break;
               }

               pos = SendMessage(h, CB_ADDSTRING, 0, (LPARAM) str);
               switch (pLayer->transparency_type_user)
               {
                  case -1 : if (s == 0) SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0); break;
                  case 0  : if (s == 1) SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0); break;
                  case 1  : if (s == 2) SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0); break;
                  case 2  : if (s == 3) SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0); break;
                  case 3  : if (s == 4) SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0); break;
                  case 4  : if (s == 5) SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0); break;
                  case 6  : if (s == 6) SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0); break;
                  case 7  : if (s == 7) SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0); break;
               }

               if ((pLayer->transparency_type_user == 7) && (s == 7))
                  display_levels = TRUE;
            }
         }

         // special effect level
         id = get_layer_control_id(ID_DLGBOX_MAIN_GFXLEVEL_BASE, r);
         if (get_dialog_child_index_from_ID(dialog_ID, id, & child_idx) == 0)
         {
            h = d->pChild[child_idx].handle;
            modify_special_effect_level(h, id, display_levels, pLayer->special_effect_level);
         }

         // next layer row
         r++;
         break;
      }
   }
}


// ===========================================================================
// disable or enable a special effect level control
// display = TRUE / FALSE
// ===========================================================================
void modify_special_effect_level(HWND h, ENUM_CTRL_IDENTIFIER id, int display, int selected_row)
{
   int   i        = 0;
   int   pos      = 0;
   WCHAR str[100] = TEXT("");


   if (h == NULL)
      return;

   SendMessage(h, CB_RESETCONTENT, 0, 0);
   if (display == FALSE)
      modify_enable_state_by_child_ID(DLG_MAIN, id, FALSE);
   else
   {
      modify_enable_state_by_child_ID(DLG_MAIN, id, TRUE);
      for (i = 0; i < 256; i++)
      {
         swprintf(str, sizeof(str) / 2, TEXT("%d"), i);
         pos = SendMessage(h, CB_ADDSTRING, 0, (LPARAM) str);
         if (i == selected_row)
            SendMessage(h, CB_SETCURSEL, (WPARAM) pos, 0);
      }
   }
}
