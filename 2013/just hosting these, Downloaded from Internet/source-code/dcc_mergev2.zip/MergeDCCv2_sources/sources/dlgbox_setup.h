#ifndef __DLGBOX_SETUP_H__
#define __DLGBOX_SETUP_H__

#include "one_include_to_rule_them_all.h"

#include "enums.h"
#include "dialog_maker.h"

int create_dlgbox_setup (void);

#endif
