#ifndef __DLGBOX_COF_IN_PROGRESS_H__
#define __DLGBOX_COF_IN_PROGRESS_H__

#include "one_include_to_rule_them_all.h"

#include "enums.h"
#include "dialog_maker.h"

int create_dlgbox_COF_in_progress (void);

#endif
