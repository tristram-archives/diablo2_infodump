<?php
//if ( !defined('LOAD_INC') ) { header('Location: http://your.ladder.page/'); exit; }

function exp2level ($exp) {

  switch ($exp) {
    case ($exp < 500):
      return "1";
      break;
    case ($exp < 1500):
      return "2";
      break;
    case ($exp < 3750):
      return "3";
      break;
    case ($exp < 7875):
      return "4";
      break;
    case ($exp < 14175):
      return "5";
      break;
    case ($exp < 22680):
      return "6";
      break;
    case ($exp < 32886):
      return "7";
      break;
    case ($exp < 44396):
      return "8";
      break;
    case ($exp < 57715):
      return "9";
      break;
    case ($exp < 72144):
      return "10";
      break;
    case ($exp < 90180):
      return "11";
      break;
    case ($exp < 112725):
      return "12";
      break;
    case ($exp < 140906):
      return "13";
      break;
    case ($exp < 176132):
      return "14";
      break;
    case ($exp < 220165):
      return "15";
      break;
    case ($exp < 275207):
      return "16";
      break;
    case ($exp < 344008):
      return "17";
      break;
    case ($exp < 430010):
      return "18";
      break;
    case ($exp < 537513):
      return "19";
      break;
    case ($exp < 671891):
      return "20";
      break;
    case ($exp < 839864):
      return "21";
      break;
    case ($exp < 1049830):
      return "22";
      break;
    case ($exp < 1312287):
      return "23";
      break;
    case ($exp < 1640359):
      return "24";
      break;
    case ($exp < 2050449):
      return "25";
      break;
    case ($exp < 2563061):
      return "26";
      break;
    case ($exp < 3203826):
      return "27";
      break;
    case ($exp < 3902260):
      return "28";
      break;
    case ($exp < 4663553):
      return "29";
      break;
    case ($exp < 5493363):
      return "30";
      break;
    case ($exp < 6397855):
      return "31";
      break;
    case ($exp < 7383752):
      return "32";
      break;
    case ($exp < 8458379):
      return "33";
      break;
    case ($exp < 9629723):
      return "34";
      break;
    case ($exp < 10906488):
      return "35";
      break;
    case ($exp < 12298162):
      return "36";
      break;
    case ($exp < 13815086):
      return "37";
      break;
    case ($exp < 15468534):
      return "38";
      break;
    case ($exp < 17270791):
      return "39";
      break;
    case ($exp < 19235252):
      return "40";
      break;
    case ($exp < 21376515):
      return "41";
      break;
    case ($exp < 23710491):
      return "42";
      break;
    case ($exp < 26254525):
      return "43";
      break;
    case ($exp < 29027522):
      return "44";
      break;
    case ($exp < 32050088):
      return "45";
      break;
    case ($exp < 35344686):
      return "46";
      break;
    case ($exp < 38935798):
      return "47";
      break;
    case ($exp < 42850109):
      return "48";
      break;
    case ($exp < 47116709):
      return "49";
      break;
    case ($exp < 51767302):
      return "50";
      break;
    case ($exp < 56836449):
      return "51";
      break;
    case ($exp < 62361819):
      return "52";
      break;
    case ($exp < 68384473):
      return "53";
      break;
    case ($exp < 74949165):
      return "54";
      break;
    case ($exp < 82104680):
      return "55";
      break;
    case ($exp < 89904191):
      return "56";
      break;
    case ($exp < 98405658):
      return "57";
      break;
    case ($exp < 107672256):
      return "58";
      break;
    case ($exp < 117772849):
      return "59";
      break;
    case ($exp < 128782495):
      return "60";
      break;
    case ($exp < 140783010):
      return "61";
      break;
    case ($exp < 153863570):
      return "62";
      break;
    case ($exp < 168121381):
      return "63";
      break;
    case ($exp < 183662396):
      return "64";
      break;
    case ($exp < 200602101):
      return "65";
      break;
    case ($exp < 219066380):
      return "66";
      break;
    case ($exp < 239192444):
      return "67";
      break;
    case ($exp < 261129853):
      return "68";
      break;
    case ($exp < 285041630):
      return "69";
      break;
    case ($exp < 311105466):
      return "70";
      break;
    case ($exp < 339515048):
      return "71";
      break;
    case ($exp < 370481492):
      return "72";
      break;
    case ($exp < 404234916):
      return "73";
      break;
    case ($exp < 441026148):
      return "74";
      break;
    case ($exp < 481128591):
      return "75";
      break;
    case ($exp < 524840254):
      return "76";
      break;
    case ($exp < 572485967):
      return "77";
      break;
    case ($exp < 624419793):
      return "78";
      break;
    case ($exp < 681027665):
      return "79";
      break;
    case ($exp < 742730244):
      return "80";
      break;
    case ($exp < 809986056):
      return "81";
      break;
    case ($exp < 883294891):
      return "82";
      break;
    case ($exp < 963201521):
      return "83";
      break;
    case ($exp < 1050299747):
      return "84";
      break;
    case ($exp < 1145236814):
      return "85";
      break;
    case ($exp < 1248718217):
      return "86";
      break;
    case ($exp < 1361512946):
      return "87";
      break;
    case ($exp < 1484459201):
      return "88";
      break;
    case ($exp < 1618470619):
      return "89";
      break;
    case ($exp < 1764543065):
      return "90";
      break;
    case ($exp < 1923762030):
      return "91";
      break;
    case ($exp < 2097310703):
      return "92";
      break;
    case ($exp < 2286478756):
      return "93";
      break;
    case ($exp < 2492671933):
      return "94";
      break;
    case ($exp < 2717422497):
      return "95";
      break;
    case ($exp < 2962400612):
      return "96";
      break;
    case ($exp < 3229426756):
      return "97";
      break;
    case ($exp < 3520485254):
      return "98";
      break;
    default:
      return "99";
  }
}

?>
