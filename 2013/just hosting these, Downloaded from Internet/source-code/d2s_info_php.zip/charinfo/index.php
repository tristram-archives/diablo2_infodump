<?php
    define('LOAD_INC', true);
    $path = '/home/bnetd/bnetd/var/charsave/';

  // check for input and clean it up
  if (isset($_REQUEST["name"]) && $_REQUEST["name"] != "") {
    $character = preg_replace('~[^-a-z0-9\-_\[\]]+~', '', strtolower(substr($_REQUEST["name"], 0, 15)));
    $file = $path . $character;
    include_once('decode.php');
  } else {
//    $MAGIC=0;
//    header('Location: http://your.ladder.page/');
    exit;
  }

?>

<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body bgcolor=#000000 text=#dlc598 link=#d1c598 vlink=#d1c598 alink=#d1c598>
<?php


if ($MAGIC) {

  $options = "";
  if ($Hardcore) $options .= "Hardcore, ";
  if ($Ladder) $options .= "Ladder, ";
  if ($Expansion) $options .= "Expansion, ";
  if ($HasDied) $options .= "Has Died, ";
  if ($options != "") $options = substr($options, 0, -2);

  $Town = '';
  if ($Town1 != "") $Town = "Normal - $Town1";
  if ($Town2 != "") $Town = "Nightmare - $Town2";
  if ($Town3 != "") $Town = "Hell - $Town3";

  echo "$Title $Name - Level $Level $Class - $options<br />\n";
  if ($Town != "") echo "$Town<br />\n";
  if ($MercControl != 0 && $MercExp != 0) {
    echo "Hireling: $MercName from $MercDiff - Level $MercLevel - $MercType";
    if ($MercSkill != "") echo " - $MercSkill";
    if ($MercDead) echo " - Dead";
    echo "<br />\n";
  } else {
    echo "No Hireling<br />\n";
  }
  echo "<br />\n";
  echo "Strength $Strength<br />\n";
  echo "Dexterity $Dexterity<br />\n";
  echo "Vitality $Vitality<br />\n";
  echo "Energy $Energy<br />\n";
  echo "<br />\n";
  echo "Life $CurrentLife / $MaximumLife<br />\n";
  echo "Mana $CurrentMana / $MaximumMana<br />\n";
  echo "Stamina $CurrentStamina / $MaximumStamina<br />\n";
  echo "<br />\n";
  echo "Stat points left $StatPoints<br />\n";
  echo "Skill points left $SkillPoints<br />\n";
  echo "Experience ".number_format($Experience)."<br />\n";
  echo "Gold on Person ".number_format($PersonalGold)."<br />\n";
  echo "Gold in Stash ".number_format($StashGold)."<br />\n";

  echo "<br />\n";
  echo "Left Skill Weapon 1 " . $LeftSkillWeapon1 . "<br />\n";
  echo "Right Skill Weapon 1 " . $RightSkillWeapon1 . "<br />\n";
  echo "Left Skill Weapon 2 " . $LeftSkillWeapon2 . "<br />\n";
  echo "Right Skill Weapon 2 " . $RightSkillWeapon2 . "<br /><br />\n";

  for ($i=1;$i<=16;$i++) {
    if (${"SkillKey" . $i} != "") echo "Skill Hot Key $i " . ${"SkillKey" . $i} . "<br />\n";
  }
  echo "<br />\n";

  echo "Skills<br />\n";
  for ($i=1;$i<=30;$i++) {
    if ($skilllevels[$i] != 0) echo "Level $skilllevels[$i] $skillnames[$i]<br />\n";
  }
  echo "<br />\n";
  echo "Quests<br />\n";
  if ($normalimbue) echo "Normal Imbue not used<br />\n";
  if ($normalsocket) echo "Normal Socket not used<br />\n";
  if ($normalpersonalize) echo "Normal Personalize not used<br />\n";
  if ($normalcow) echo "Normal Cow Level not complete<br />\n";
  if ($nightmareimbue) echo "Nightmare Imbue not used<br />\n";
  if ($nightmaresocket) echo "Nightmare Socket not used<br />\n";
  if ($nightmarepersonalize) echo "Nightmare Personalize not used<br />\n";
  if ($nightmarecow) echo "Nightmare Cow Level not complete<br />\n";
  if ($hellimbue) echo "Hell Imbue not used<br />\n";
  if ($hellsocket) echo "Hell Socket not used<br />\n";
  if ($hellpersonalize) echo "Hell Personalize not used<br />\n";
  if ($hellcow) echo "Hell Cow Level not complete<br />\n";

  echo "<br />\n";
  echo "Waypoints<br />\n";
  echo "<table><tr>\n";
  $Difficulties = array('Normal', 'Nightmare', 'Hell');
  foreach($Difficulties as $list) {
    echo "<td valign=top align=left><b>$list</b><br />\n";
    for ($i=0;$i<39;$i++) {
      switch ($i) {
        case 0:
          echo "<b><u>Act I</u></b><br />\n";
          break;
        case 9:
          echo "<b><u>Act II</u></b><br />\n";
          break;
        case 18:
          echo "<b><u>Act III</u></b><br />\n";
          break;
        case 27:
          echo "<b><u>Act IV</u></b><br />\n";
          break;
        case 30:
          echo "<b><u>Act V</u></b><br />\n";
          break;
      }
      if (${$list . "Waypoints"}[$i]) {
        echo "$waypoints[$i]<br />\n";
      } else {
        echo "<i><font color=gray>$waypoints[$i]</font></i><br />\n";
      }
    }
    echo "</td>\n";
  }
  echo "</tr></table>\n";
  echo "<br />\n";

/*
  $BinaryItem = "";
  $itemstart = $skillsection+38;
  $itemend = strpos ($RawCharData, 'JM', $itemstart);
  for($i=$itemend-1;$i>=$itemstart;$i--) {
    $BinaryItem .= sprintf("%08b", hexdec(padhex($CharData[$i])));
  }
  $itemlength = strlen($BinaryItem);
  echo substr($BinaryItem, $itemlength-138, 46) . "<br />\n";
  echo substr($BinaryItem, $itemlength-95, 3) . "<br />\n";
  echo substr($BinaryItem, $itemlength-127, 32) . "<br />\n";
  echo substr($BinaryItem, $itemlength-138, 4) . "<br />\n";
  echo "<br /><br />\n";
*/

  if ($itemcount > 0) {
    $equipped = $belt = $moved = $inventory = $cube = $stash = array();
    for ($i=0;$i<$itemcount;$i++) {
      switch ($ItemList[$i]['location']) {
        case 0: // stored - see 'storedin'
          switch ($ItemList[$i]['storedin']) {
            case 1: // inventory
              array_push ($inventory, $ItemList[$i]);
              break;
            case 4: // cube
              array_push ($cube, $ItemList[$i]);
              break;
            case 5: //stash
              array_push ($stash, $ItemList[$i]);
              break;
            default:
              array_push ($moved, $ItemList[$i]);
          }
          break;
        case 1: // equipped
          $equipped[$ItemList[$i]['position']] = $ItemList[$i];
          break;
        case 2: // belt
          array_push ($belt, $ItemList[$i]);
          break;
        case 4: // moved - picked up by mouse
          array_push ($moved, $ItemList[$i]);
          break;
        case 6: // glued in a socket (should never happen)
          array_push ($moved, $ItemList[$i]);
          break;
        default:
          array_push ($moved, $ItemList[$i]);
      }
    }
  }

//print_r($equipped);
echo "<table>\n";
echo "<tr><td colspan=3>Items</td></tr>\n";
echo "<tr><td colspan=3><u>Equipped</u></td></tr>\n";
$count = 1;
for ($i=1;$i<=12;$i++) {
  if (isset($equipped[$i])) {
    echo "<tr><td>". $count ."</td><td colspan=2>". format_item_name_html($equipped[$i]) ."</td></tr>\n";
    if ($equipped[$i]['magiccount'] > 0) {
      for ($s=0;$s<$equipped[$i]['magiccount'];$s++) {
        echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td><b><font color=".$equipped[$i]['magiccolor'].">".$equipped[$i]["magicproperty".$s]."</font></b></td></tr>\n";
      }
    }
    if ($equipped[$i]['issocketed'] == 1) {
      for ($s=0;$s<$equipped[$i]['itemsinsockets'];$s++) {
        echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>".format_item_name_html($equipped[$i]["socket".$s])."</td></tr>\n";
        if ($equipped[$i]["socket".$s]['magiccount'] > 0) {
          for ($t=0;$t<$equipped[$i]["socket".$s]['magiccount'];$t++) {
            echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td><b><font color=".$equipped[$i]["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$equipped[$i]["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
          }
        }
      }
    }
    $count++;
  }
}

echo "<tr><td colspan=3><u>Inventory</u></td></tr>\n";
//$count = 1;
foreach ($inventory as $item) {
  echo "<tr><td>". $count ."</td><td colspan=2>". format_item_name_html($item) . "</td></tr>\n";
  if ($item['magiccount'] > 0) {
    for ($s=0;$s<$item['magiccount'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item['magiccolor'].">".$item["magicproperty".$s]."</font></b></td></tr>\n";
    }
  }
  if ($item['issocketed'] == 1) {
    for ($s=0;$s<$item['itemsinsockets'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td>".format_item_name_html($item["socket".$s])."</td></tr>\n";
      if ($item["socket".$s]['magiccount'] > 0) {
        for ($t=0;$t<$item["socket".$s]['magiccount'];$t++) {
          echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$item["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
        }
      }
    }
  }
  $count++;
}

echo "<tr><td colspan=3><u>Cube</u></td></tr>\n";
//$count = 1;
foreach ($cube as $item) {
  echo "<tr><td>". $count ."</td><td colspan=2>". format_item_name_html($item) . "</td></tr>\n";
  if ($item['magiccount'] > 0) {
    for ($s=0;$s<$item['magiccount'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item['magiccolor'].">".$item["magicproperty".$s]."</font></b></td></tr>\n";
    }
  }
  if ($item['issocketed'] == 1) {
    for ($s=0;$s<$item['itemsinsockets'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td>".format_item_name_html($item["socket".$s])."</td></tr>\n";
      if ($item["socket".$s]['magiccount'] > 0) {
        for ($t=0;$t<$item["socket".$s]['magiccount'];$t++) {
          echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$item["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
        }
      }
    }
  }
  $count++;
}

echo "<tr><td colspan=3><u>Stash</u></td></tr>\n";
//$count = 1;
foreach ($stash as $item) {
  echo "<tr><td>". $count ."</td><td colspan=2>". format_item_name_html($item) . "</td></tr>\n";
  if ($item['magiccount'] > 0) {
    for ($s=0;$s<$item['magiccount'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item['magiccolor'].">".$item["magicproperty".$s]."</font></b></td></tr>\n";
    }
  }
  if ($item['issocketed'] == 1) {
    for ($s=0;$s<$item['itemsinsockets'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td>".format_item_name_html($item["socket".$s])."</td></tr>\n";
      if ($item["socket".$s]['magiccount'] > 0) {
        for ($t=0;$t<$item["socket".$s]['magiccount'];$t++) {
          echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$item["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
        }
      }
    }
  }
  $count++;
}

echo "<tr><td colspan=3><u>Belt</u></td></tr>\n";
//$count = 1;
foreach ($belt as $item) {
  echo "<tr><td>". $count ."</td><td colspan=2>". format_item_name_html($item) . "</td></tr>\n";
  if ($item['magiccount'] > 0) {
    for ($s=0;$s<$item['magiccount'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item['magiccolor'].">&nbsp;&nbsp;".$item["magicproperty".$s]."</font></b></td></tr>\n";
    }
  }
  if ($item['issocketed'] == 1) {
    for ($s=0;$s<$item['itemsinsockets'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td>".format_item_name_html($item["socket".$s])."</td></tr>\n";
      if ($item["socket".$s]['magiccount'] > 0) {
        for ($t=0;$t<$item["socket".$s]['magiccount'];$t++) {
          echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$item["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
        }
      }
    }
  }
  $count++;
}

if ($corpseitemcount > 0) {
  echo "<tr><td colspan=3><u>Items on Corpse</u></td></tr>\n";
//  $count = 1;
  foreach ($CorpseItemList as $item) {
    echo "<tr><td>". $count ."</td><td colspan=2>". format_item_name_html($item) . "</td></tr>\n";
    if ($item['magiccount'] > 0) {
      for ($s=0;$s<$item['magiccount'];$s++) {
        echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item['magiccolor'].">&nbsp;&nbsp;".$item["magicproperty".$s]."</font></b></td></tr>\n";
      }
    }
    if ($item['issocketed'] == 1) {
      for ($s=0;$s<$item['itemsinsockets'];$s++) {
        echo "<tr><td colspan=2>&nbsp;</td><td>".format_item_name_html($item["socket".$s])."</td></tr>\n";
        if ($item["socket".$s]['magiccount'] > 0) {
          for ($t=0;$t<$item["socket".$s]['magiccount'];$t++) {
            echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$item["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
          }
        }
      }
    }
    $count++;
  }
}

if (count($moved) > 0) {
  echo "<tr><td colspan=3><u>Being Moved / Other</u></td></tr>\n";
//  $count = 1;
  foreach ($moved as $item) {
    echo "<tr><td>". $count ."</td><td colspan=2>". format_item_name_html($item) . "</td></tr>\n";
    if ($item['magiccount'] > 0) {
      for ($s=0;$s<$item['magiccount'];$s++) {
        echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item['magiccolor'].">".$item["magicproperty".$s]."</font></b></td></tr>\n";
      }
    }
    if ($item['issocketed'] == 1) {
      for ($s=0;$s<$item['itemsinsockets'];$s++) {
        echo "<tr><td colspan=2>&nbsp;</td><td>".format_item_name_html($item["socket".$s])."</td></tr>\n";
        if ($item["socket".$s]['magiccount'] > 0) {
          for ($t=0;$t<$item["socket".$s]['magiccount'];$t++) {
            echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$item["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$item["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
          }
        }
      }
    }
    $count++;
  }
}

if ($hasirongolem) {
  echo "<tr><td colspan=3>&nbsp;</td><tr>\n";
  echo "<tr><td colspan=3><u>Irom Golem</u></td></tr>\n";
  echo "<tr><td>1</td><td colspan=2>";
  echo format_item_name_html($GolemItem) . "</td></tr>\n";
  if ($GolemItem['magiccount'] > 0) {
    for ($s=0;$s<$GolemItem['magiccount'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$GolemItem['magiccolor'].">".$GolemItem["magicproperty".$s]."</font></b></td></tr>\n";
    }
  }
  if ($GolemItem['issocketed'] == 1) {
    for ($s=0;$s<$GolemItem['itemsinsockets'];$s++) {
      echo "<tr><td colspan=2>&nbsp;</td><td>".format_item_name_html($GolemItem["socket".$s])."</td></tr>\n";
      if ($GolemItem["socket".$s]['magiccount'] > 0) {
        for ($t=0;$t<$GolemItem["socket".$s]['magiccount'];$t++) {
          echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$GolemItem["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$GolemItem["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
        }
      }

    }
  }
  $count++;
}

echo "<tr><td colspan=3>&nbsp;</td><tr>\n";
echo "<tr><td colspan=3><u>Mercenary</u></td></tr>\n";
  if ($mercitemcount >0) {
//    echo "Mercenary item count: $mercitemcount<br />\n";
//    echo "<table>\n";
//    echo "<tr><td>#</td><td>type</td></tr>\n";

    $stop = count($MercItemList);
    for ($i=0;$i<$stop;$i++) {
//      echo "<tr><td>".($i+1)."</td><td>".$MercItemList[$i]['type']."</td></tr>\n";
      echo "<tr><td>".($i+1)."</td><td colspan=2>".format_item_name_html($MercItemList[$i])."</td></tr>\n";

      if ($MercItemList[$i]['magiccount'] > 0) {
        for ($s=0;$s<$MercItemList[$i]['magiccount'];$s++) {
          echo "<tr><td colspan=2>&nbsp;</td><td><b><font color=".$MercItemList[$i]['magiccolor'].">".$MercItemList[$i]["magicproperty".$s]."</font></b></td></tr>\n";
        }
      }

      for ($s=0;$s<$MercItemList[$i]['itemsinsockets'];$s++) {
//        echo "<tr><td>&nbsp;</td><td>".$MercItemList[$i]["socket".$s]['type']."</td></tr>\n";
        echo "<tr><td colspan=2>&nbsp;</td><td>".format_item_name_html($MercItemList[$i]["socket".$s])."</td></tr>\n";
        if ($MercItemList[$i]["socket".$s]['magiccount'] > 0) {
          for ($t=0;$t<$MercItemList[$i]["socket".$s]['magiccount'];$t++) {
            echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td><b><font color=".$MercItemList[$i]["socket".$s]['magiccolor'].">&nbsp;&nbsp;".$MercItemList[$i]["socket".$s]["magicproperty".$t]."</font></b></td></tr>\n";
          }
        }
      }
    }
//  echo "</table>\n";
  echo "<br />\n";
  }

echo "</table><br />\n";


/*
  echo "<br /><br />\n";
  echo "<table>\n";
  echo "<tr><td colspan=2 align=center>location</td><td>&nbsp;</td><td colspan=3 align=center>value</td></tr>\n";
  echo "<tr><td>dec</td><td>hex</td><td>&nbsp;&nbsp;</td><td>bin</td><td>dec</td><td>hex</td></tr>\n";


  $length = sizeof($CharData);
//  for($i=0;$i<$length;$i++) {
//  for($i=765;$i<900;$i++) {
//  for($i=0;$i<100;$i++) {
//  for($i=714;$i<764;$i++) {
//  for($i=455;$i<538;$i++) {
//  for($i=$skillsection;$i<$skillsection+32;$i++) {
//  for($i=$skillsection+32;$i<$length;$i++) {
  for($i=$mercitemend;$i<$length;$i++) {
    echo "<tr><td>" . $i . "</td><td>" . dechex($i) . "</td><td>&nbsp;</td><td>" . $RawCharData[$i] . "</td><td>" . $CharData[$i] . "</td><td>" . padhex($CharData[$i]) . "</td></tr>\n";
  }
  echo "</table>\n";
*/

} else {
  echo "Invalid file.<br />\n";
}

?>
</body>
</html>
