states_txt_pl2 v1.00
by paul Siramy, April 27 2007
Freeware


Diablo II moding tool.


This little tool help you to choose the 'colorshift' value
to put in the states.txt. Simply make a sample image (.bmp,
.lbm .pcx or .tga) in 8bpp (256 colors), then feed the tool
with this image (using a .bat or dragging the image icon
into the tool executable), and you'll get a new image, named
after your sample image, showing you all the entire 128
possible colorshifts.

Note that the colorshift 0 (zero) is a "neutral" colorshift, as
it won't change any pixel at all.

You can also replace the "act1.pl2" by any other .pl2 of the
game, that way if you're going to use a monster in a particular
act only, it'd be better to chose the colorshift of that act
palette (which is in the begening of any .pl2 files).


Credits :
   * BLIZZARD ENTERTAINMENT / BLIZZARD NORTH
   * the Allegro communauty
   * the Phrozen Keep

Enjoy
