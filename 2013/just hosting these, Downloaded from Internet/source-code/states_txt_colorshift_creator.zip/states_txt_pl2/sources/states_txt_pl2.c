#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <allegro.h>

#define FINAL_IDX_PL2_BASE   1328
#define FINAL_IDX_PCX_BASE      0
#define FINAL_NX                8
#define FINAL_NY               16

//#define _DEBUG_ME_

typedef unsigned char UBYTE;

char program_fullpath [513] = "";
char temp_fullpath    [513] = "";

int main(int argc, char ** argv)
{
   static PALETTE pal;
   BITMAP         * sample    = NULL;
   BITMAP         * final     = NULL;
   UBYTE          * curr_cmap = NULL;
   UBYTE          * pl2       = NULL;
   FILE           * in        = NULL;
   long           size        = 0;
   int            fw, fh, i, x, y, w, h, x_txt, bx, by, c, c_black;
   static char    strerror[1024];


   allegro_init();
   set_window_title("states_txt_pl2 v1.00");

#ifdef _DEBUG_ME_
   allegro_message("start");
#endif

   get_executable_name(program_fullpath, sizeof(program_fullpath));
  
   if (argc != 2)
   {
      sprintf(
         strerror,
         "ERROR\n\n"
         "This program needs a parameter via the command-line\n"
         "Syntaxe is : states_txt_pl2.exe \"<file>\"\n"
         "\n"
         "Tip : you can also drag'n drop an image file on the program icon"
      );
      allegro_message(strerror);
      exit(1);
   }

#ifdef _DEBUG_ME_
   allegro_message("about to set_gfx_mode()");
#endif

   set_color_depth(8);
   set_gfx_mode(GFX_SAFE, 0, 0, 0, 0);

#ifdef _DEBUG_ME_
   allegro_message("about to load_bitmap()");
#endif

   sample = load_bitmap(argv[1], pal);
   if (sample == NULL)
   {
      sprintf(strerror, "ERROR\n\nCan't load image : \"%s\"\n", argv[1]);
      allegro_message(strerror);
      exit(1);
   }

#ifdef _DEBUG_ME_
   allegro_message("about to create_bitmap()");
#endif

   fw  = FINAL_NX * (sample->w + 8) + 1;
   fh  = FINAL_NY * (sample->h + 8 + 10) + 1;
   final = create_bitmap(fw, fh);
   if (final == NULL)
   {
      destroy_bitmap(sample);
      sprintf(strerror, "ERROR\n\nCan't create final bitmap of %i * %i pixels\n", fw, fh);
      allegro_message(strerror);
      exit(1);
   }
   clear(final);

   strcpy(temp_fullpath, program_fullpath);
   replace_filename(temp_fullpath, temp_fullpath, "act1.pl2", sizeof(temp_fullpath));

#ifdef _DEBUG_ME_
   allegro_message("about to open act1.pl2");
#endif

   in = fopen(temp_fullpath, "rb");
   if (in == NULL)
   {
      destroy_bitmap(sample);
      destroy_bitmap(final);
      sprintf(strerror, "ERROR\n\nCan't open \"%s\"\n", temp_fullpath);
      allegro_message(strerror);
      exit(1);
   }
   fseek(in, 0, SEEK_END);
   size = ftell(in);
   fseek(in, 0, SEEK_SET);
   pl2 = malloc(size);
   if (pl2 == NULL)
   {
      fclose(in);
      destroy_bitmap(sample);
      destroy_bitmap(final);
      sprintf(strerror, "ERROR\n\nCan't allocate %li bytes for the \"act1.pl2\" ressource\n", size);
      allegro_message(strerror);
      exit(1);
   }
   fread(pl2, size, 1, in);
   fclose(in);

#ifdef _DEBUG_ME_
   allegro_message("about to make the final bitmap");
#endif

   pal[0].r = pal[0].g = pal[0].b = 32;
   for (i=1; i < 256; i++)
   {
      pal[i].r = pl2[i*4]   >> 2;
      pal[i].g = pl2[i*4+1] >> 2;
      pal[i].b = pl2[i*4+2] >> 2;
   }
   c_black = makecol(0, 0, 0);
   for (i=0; i <= FINAL_NX; i++)
      vline(final, i * (sample->w + 8), 0, fh, 255);
   for (i=0; i <= FINAL_NY; i++)
      hline(final, 0, i * (sample->h + 8 + 10), fw, 255);
   text_mode(-1);
   for (h=0; h < FINAL_NY; h++)
   {
      for (w=0; w < FINAL_NX; w++)
      {
         x = w * (sample->w + 8) + 4;
         y = h * (sample->h + 8 + 10) + 4;
         x_txt = x + (sample->w / 2) - 22;
         textprintf(final, font, x_txt, y+sample->h + 4, 255, "%5i",
            FINAL_IDX_PCX_BASE + h*FINAL_NX+w
         );

         curr_cmap = & pl2[ (4*256) + 256 * (FINAL_IDX_PL2_BASE + h*FINAL_NX + w) ];
         for (by=0; by < sample->h; by++)
         {
            for (bx=0; bx < sample->w; bx++)
            {
               c = getpixel(sample, bx,by);
               if (c)
                  putpixel(final, x+bx, y+by, curr_cmap[c] ? curr_cmap[c] : c_black);
            }
         }
      }
   }

#ifdef _DEBUG_ME_
   allegro_message("about to save the final bitmap");
#endif

   strcpy(temp_fullpath, argv[1]);
   strcat(temp_fullpath, ".states_colorshifts.pcx");

   save_pcx(temp_fullpath, final, pal);

   sprintf(
      strerror,
      "INFORMATION\n\n"
      "Image read :\n\"%s\"\n\n"
      "Image created :\n\"%s\"",
      argv[1],
      temp_fullpath
   );
   allegro_message(strerror);

   free(pl2);
   destroy_bitmap(sample);
   destroy_bitmap(final);
   return 0;
}
END_OF_MAIN()
