#ifndef _ERROR_H_

#define _ERROR_H_

void ds1edit_error (const char * text);

#endif
