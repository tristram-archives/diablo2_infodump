#ifndef _TYPES_H_

#define _TYPES_H_

typedef unsigned char      UBYTE;
typedef short int          WORD;
typedef unsigned short int UWORD;
typedef unsigned long      UDWORD;

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE -1
#endif
                                    
// Disable warning message "unreferenced inline function has been removed"
#pragma warning( disable : 4514 )

#endif
