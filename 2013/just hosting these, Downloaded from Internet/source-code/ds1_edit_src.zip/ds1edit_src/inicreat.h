#ifndef _INICREAT_H_

#define _INICREAT_H_

void ini_create (char * ininame);

#endif
