#ifndef _INTERFAC_H_

#define _INTERFAC_H_

void interfac_user_handler (int start_ds1_idx);

#endif
