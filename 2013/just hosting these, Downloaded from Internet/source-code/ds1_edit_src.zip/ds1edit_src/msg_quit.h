#ifndef _MSG_QUIT_H_

#define _MSG_QUIT_H_

int msg_quit_main(void);

#endif
