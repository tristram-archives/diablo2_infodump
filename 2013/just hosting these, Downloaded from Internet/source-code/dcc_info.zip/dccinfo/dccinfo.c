#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dccinfo.h"

FRAME_INFO_S frame_info [DCC_MAX_DIR] [DCC_MAX_FRAME];
DIR_INFO_S   dir_info   [DCC_MAX_DIR];
DCC_INFO_S   dcc_info;

UBYTE  * dcc_mem;        // copy of the dcc in mem
UDWORD dcc_mem_size;     // size of the dcc in mem
UDWORD dcc_mem_cur_byte; // byte cursor in dcc_mem buffer
UBYTE  dcc_mem_cur_bit;  // bit cursor in the byte of current byte cursor
                         //    (from 0 to 7 : lowest bit to highest bit)

int bits_width_table[16] =
   {0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24, 26, 28, 30, 32};


// ==========================================================================
// copy 'bytes_number' bytes into 'dest' from the current byte position
void dcc_read_bytes(void * dest, int bytes_number)
{
   int i;

   if (dcc_mem_cur_bit != 0)
   {
      printf("dcc_read_bytes() : want to read UNALIGNED bytes\n");
      exit(1);
   }
   
   for (i=0; i<bytes_number; i++)
   {
      if (dcc_mem_cur_byte >= dcc_mem_size)
      {
         printf("dcc_read_bytes() : want to read behind the end\n");
         exit(1);
      }
      * (((UBYTE *) dest) + i) = dcc_mem[dcc_mem_cur_byte];
      dcc_mem_cur_byte ++;
   }
}


// ==========================================================================
// copy 'bits_number' bits into 'dest' from the current byte & bit position
//    is_signed = TRUE / FALSE
//    the dest variable MUST BE 32 bits width
void dcc_read_bits(UDWORD * dest, int bits_number, int is_signed)
{
   int b, dest_bit = 0, dest_byte = 0;


   // init to zero
   * dest = 0;
   
   // no bits to read
   if (bits_number == 0)
      return;
      
   // in case
   if (bits_number < 0)
   {
      printf("dcc_read_bits() : can't read %i bits\n", bits_number);
      exit(1);
   }

   if (is_signed && bits_number == 1)
      is_signed = FALSE; // 1 bit can't be signed, so it's a positive value

   if (is_signed && bits_number <= 1)
   {
      printf("dcc_read_bits() : can't read %i SIGNED bits\n", bits_number);
      exit(1);
   }

   if (bits_number > 32)
   {
      printf("dcc_read_bits() : can't read more than 32 bits at once\n");
      exit(1);
   }

   // copy all necessary bits
   for (b=0; b<bits_number; b++)
   {
      if (dcc_mem_cur_byte >= dcc_mem_size)
      {
         printf("dcc_read_bits() : want to read behind the end\n");
         exit(1);
      }

      // copy 1 bit
      if ( dcc_mem[dcc_mem_cur_byte] & (1 << dcc_mem_cur_bit) )
         * (((UBYTE *) dest) + dest_byte) |= (1 << dest_bit);

      // prepare next bit to read
      dest_bit++;
      if (dest_bit >= 8)
      {
         dest_bit = 0;
         dest_byte++;
      }
      dcc_mem_cur_bit++;
      if (dcc_mem_cur_bit >= 8)
      {
         dcc_mem_cur_bit = 0;
         dcc_mem_cur_byte++;
      }
   }

   // signed value handle
   if (is_signed == FALSE)
      return;
      
   if ((* dest) & (1 << (bits_number-1)) )
   {
      // negative : sign extend
      (* dest) |= ~ ((1 << bits_number) - 1);
   }
}


// ==========================================================================
// read 1 frame bitstream
void dcc_frame_header_bitstream(int d, int f)
{
   dcc_read_bits( & frame_info[d][f].variable0,      bits_width_table[dir_info[d].variable0_bits],     FALSE);
   dcc_read_bits( & frame_info[d][f].width,          bits_width_table[dir_info[d].width_bits],         FALSE);
   dcc_read_bits( & frame_info[d][f].height,         bits_width_table[dir_info[d].height_bits],        FALSE);
   dcc_read_bits( & frame_info[d][f].xoffset,        bits_width_table[dir_info[d].xoffset_bits],       TRUE);
   dcc_read_bits( & frame_info[d][f].yoffset,        bits_width_table[dir_info[d].yoffset_bits],       TRUE);
   dcc_read_bits( & frame_info[d][f].optional_data,  bits_width_table[dir_info[d].optional_data_bits], FALSE);
   dcc_read_bits( & frame_info[d][f].coded_bytes,    bits_width_table[dir_info[d].coded_bytes_bits],   FALSE);
   dcc_read_bits( & frame_info[d][f].frame_top_down, 1, FALSE);

   // frame box
   frame_info[d][f].box.xmin = frame_info[d][f].xoffset;
   frame_info[d][f].box.xmax =
      frame_info[d][f].box.xmin + frame_info[d][f].width - 1;

   frame_info[d][f].box.ymax = frame_info[d][f].yoffset;
   frame_info[d][f].box.ymin =
      frame_info[d][f].box.ymax - frame_info[d][f].height + 1;
}


// ==========================================================================
// read 1 direction bitstream
void dcc_dir_bitstream(int d)
{
   int f;
   
   dcc_mem_cur_bit  = 0;
   dcc_mem_cur_byte = dcc_info.dir_offset[d];
   
   dcc_read_bits( & dir_info[d].outsize_coded,     32, FALSE);
   dcc_read_bits( & dir_info[d].compression_flag,   2, FALSE);
   dcc_read_bits( & dir_info[d].variable0_bits,     4, FALSE);
   dcc_read_bits( & dir_info[d].width_bits,         4, FALSE);
   dcc_read_bits( & dir_info[d].height_bits,        4, FALSE);
   dcc_read_bits( & dir_info[d].xoffset_bits,       4, FALSE);
   dcc_read_bits( & dir_info[d].yoffset_bits,       4, FALSE);
   dcc_read_bits( & dir_info[d].optional_data_bits, 4, FALSE);
   dcc_read_bits( & dir_info[d].coded_bytes_bits,   4, FALSE);

   // init direction box min & max (NOT ZERO !)
   //    (some boxes are all in negative area, so max can't be init with 0)
   dir_info[d].box.xmin = 32000;
   dir_info[d].box.xmax = -32000;
   dir_info[d].box.ymin = 32000;
   dir_info[d].box.ymax = -32000;
   
   for (f=0; f<dcc_info.frames_per_dir; f++)
   {
      dcc_frame_header_bitstream(d, f);

      // direction box
      if (frame_info[d][f].box.xmin < dir_info[d].box.xmin)
         dir_info[d].box.xmin = frame_info[d][f].box.xmin;

      if (frame_info[d][f].box.ymin < dir_info[d].box.ymin)
         dir_info[d].box.ymin = frame_info[d][f].box.ymin;

      if (frame_info[d][f].box.xmax > dir_info[d].box.xmax)
         dir_info[d].box.xmax = frame_info[d][f].box.xmax;

      if (frame_info[d][f].box.ymax > dir_info[d].box.ymax)
         dir_info[d].box.ymax = frame_info[d][f].box.ymax;
   }
}


// ==========================================================================
// read dcc file header
void dcc_file_header(void)
{
   int i;
   
   dcc_read_bytes( & dcc_info.file_signature, 1);
   dcc_read_bytes( & dcc_info.version,        1);
   dcc_read_bytes( & dcc_info.directions,     1);
   dcc_read_bytes( & dcc_info.frames_per_dir, 4);
   dcc_read_bytes( & dcc_info.tag,            4);
   dcc_read_bytes( & dcc_info.unknown_size,   4);
   for (i=0; i<dcc_info.directions; i++)
      dcc_read_bytes( & dcc_info.dir_offset[i], 4);
}


// ==========================================================================
// read a dcc and decode it
//    note : this prog is far from complete about this
void dcc_decode(void)
{
   int i;
   
   dcc_file_header();
   for (i=0; i<dcc_info.directions; i++)
      dcc_dir_bitstream(i);
}


// ==========================================================================
// output the dcc datas in a more usable form
void dcc_debug(void)
{
   int d, f;
  
   printf("file_signature = %i\n",  dcc_info.file_signature);
   printf("version        = %i\n",  dcc_info.version);
   printf("directions     = %i\n",  dcc_info.directions);
   printf("frames_per_dir = %li\n", dcc_info.frames_per_dir);
   printf("tag            = %li\n", dcc_info.tag);
   printf("unknown_size   = %li\n", dcc_info.unknown_size);

   for (d=0; d<dcc_info.directions; d++)
   {
      printf("\ndirection %2i\n", d);
      printf("   outsize_coded      = %li\n", dir_info[d].outsize_coded);
      printf("   compression_flag   = %li\n", dir_info[d].compression_flag);
      printf("   variable0_bits     = %2lu  (%2i bits)\n", dir_info[d].variable0_bits,     bits_width_table[dir_info[d].variable0_bits]);
      printf("   width_bits         = %2lu  (%2i bits)\n", dir_info[d].width_bits,         bits_width_table[dir_info[d].width_bits]);
      printf("   height_bits        = %2lu  (%2i bits)\n", dir_info[d].height_bits,        bits_width_table[dir_info[d].height_bits]);
      printf("   xoffset_bits       = %2lu  (%2i bits)\n", dir_info[d].xoffset_bits,       bits_width_table[dir_info[d].xoffset_bits]);
      printf("   yoffset_bits       = %2lu  (%2i bits)\n", dir_info[d].yoffset_bits,       bits_width_table[dir_info[d].yoffset_bits]);
      printf("   optional_data_bits = %2lu  (%2i bits)\n", dir_info[d].optional_data_bits, bits_width_table[dir_info[d].optional_data_bits]);
      printf("   coded_bytes_bits   = %2lu  (%2i bits)\n", dir_info[d].coded_bytes_bits,   bits_width_table[dir_info[d].coded_bytes_bits]);
      printf("   box                = (%li, %li)  --->  (%li, %li)\n",
         dir_info[d].box.xmin,
         dir_info[d].box.ymin,
         dir_info[d].box.xmax,
         dir_info[d].box.ymax
      );
      printf("   box width, height  = %li, %li\n",
         dir_info[d].box.xmax - dir_info[d].box.xmin + 1,
         dir_info[d].box.ymax - dir_info[d].box.ymin + 1
      );
      printf("   CVDCC.DLL offsets  = %li, %li\n",
         dir_info[d].box.xmin,
         dir_info[d].box.ymax
      );


      for (f=0; f<dcc_info.frames_per_dir; f++)
      {
         printf("\n   frame %3i\n", f);

         if (dir_info[d].variable0_bits)
            printf("      variable0      = %lu\n", frame_info[d][f].variable0);

         if (dir_info[d].width_bits)
            printf("      width          = %lu\n", frame_info[d][f].width);

         if (dir_info[d].height_bits)
            printf("      height         = %lu\n", frame_info[d][f].height);

         if (dir_info[d].xoffset_bits)
            printf("      xoffset        = %li\n", frame_info[d][f].xoffset);

         if (dir_info[d].yoffset_bits)
            printf("      yoffset        = %li\n", frame_info[d][f].yoffset);

         if (dir_info[d].optional_data_bits)
            printf("      optional_data  = %lu\n", frame_info[d][f].optional_data);

         if (dir_info[d].coded_bytes_bits)
            printf("      coded_bytes    = %lu\n", frame_info[d][f].coded_bytes);

         printf("      frame_top_down = %li\n", frame_info[d][f].frame_top_down);
         printf("      box            = (%li, %li)  --->  (%li, %li)\n",
            frame_info[d][f].box.xmin,
            frame_info[d][f].box.ymin,
            frame_info[d][f].box.xmax,
            frame_info[d][f].box.ymax
         );
      }
   }
}


// ==========================================================================
// at start of prog
void dcc_my_init(void)
{
   memset( & dcc_info,   0, sizeof(dcc_info));
   memset( & dir_info,   0, sizeof(dir_info));
   memset( & frame_info, 0, sizeof(frame_info));
   dcc_mem          = NULL;
   dcc_mem_size     = 0;
   dcc_mem_cur_byte = 0;
   dcc_mem_cur_bit  = 0;
}


// ==========================================================================
// copy the file from disk into mem
void dcc_get_in_mem(char * dcc_name)
{
   FILE * in;
   int  c;
   long i;

   in = fopen(dcc_name, "rb");
   if (in == NULL)
   {
      printf("can't open %s\n", dcc_name);
      exit(1);
   }

   // get size
   fseek(in, 0, SEEK_END);
   dcc_mem_size = ftell(in);
   fseek(in, 0, SEEK_SET);

   // buffer
   dcc_mem = (UBYTE *) malloc(dcc_mem_size);
   if (dcc_mem == NULL)
   {
      fclose(in);
      printf("dcc_get_in_mem() : can't allocate %li bytes\n", dcc_mem_size);
      exit(1);
   }
   
   // fill buffer
   c = fgetc(in);
   i = 0;
   while (c != EOF)
   {
      dcc_mem[i] = c;
      i++;
      c = fgetc(in);
   }
   fclose(in);
}


// ==========================================================================
// automatically free memory at end of prog
void dcc_my_exit(void)
{
   if (dcc_mem != NULL)
   {
      free(dcc_mem);
      dcc_mem = NULL;
   }
}


// ==========================================================================
// entry point
int main(int argc, char ** argv)
{
   if (argc != 2)
   {
      printf("syntaxe : dccinfo <file.dcc> > <file.txt>\n");
      return 0;
   }
   dcc_my_init();
   atexit(dcc_my_exit);

   printf("====================\n");
   printf("%s\n", argv[1]);
   printf("====================\n");
   
   dcc_get_in_mem(argv[1]);
   dcc_decode();
   dcc_debug();
}

