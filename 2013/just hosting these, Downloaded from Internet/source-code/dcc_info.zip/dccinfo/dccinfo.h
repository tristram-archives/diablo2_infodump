#ifndef _DCC_INFO_H_

#define _DCC_INFO_H_

#define FALSE  0
#define TRUE  -1

#define DCC_MAX_DIR    32
#define DCC_MAX_FRAME 256

#define UBYTE  unsigned char
#define WORD   short int
#define UWORD  unsigned WORD
#define UDWORD unsigned long

typedef struct
{
   long xmin;
   long ymin;
   long xmax;
   long ymax;
} BOX_S;

typedef struct
{
   UDWORD variable0;
   UDWORD width;
   UDWORD height;
   long   xoffset;
   long   yoffset;
   UDWORD optional_data;
   UDWORD coded_bytes;

   // next var : UBYTE should be enough
   //    but my bitstream reading function need a 32 bits wide variable
   UDWORD frame_top_down;

   // not in file, for my own purpose
   BOX_S  box;
} FRAME_INFO_S;

typedef struct
{
   UDWORD outsize_coded;
   UDWORD compression_flag;

   // next var : UBYTE should be enough
   //    but my bitstream reading function need a 32 bits wide variable
   UDWORD variable0_bits;
   UDWORD width_bits;
   UDWORD height_bits;
   UDWORD xoffset_bits;
   UDWORD yoffset_bits;
   UDWORD optional_data_bits;
   UDWORD coded_bytes_bits;

   // not in file, for my own purpose
   BOX_S  box;
} DIR_INFO_S;

typedef struct
{
   UBYTE file_signature;
   UBYTE version;
   UBYTE directions;
   long  frames_per_dir;
   long  tag;
   long  unknown_size;
   long  dir_offset [DCC_MAX_DIR];
} DCC_INFO_S;


void dcc_read_bytes             (void * dest, int bytes_number);
void dcc_read_bits              (UDWORD * dest, int bits_number, int is_signed);
void dcc_frame_header_bitstream (int d, int f);
void dcc_dir_bitstream          (int d);
void dcc_file_header            (void);
void dcc_decode                 (void);
void dcc_debug                  (void);
void dcc_my_init                (void);
void dcc_get_in_mem             (char * dcc_name);
void dcc_my_exit                (void);

#endif

