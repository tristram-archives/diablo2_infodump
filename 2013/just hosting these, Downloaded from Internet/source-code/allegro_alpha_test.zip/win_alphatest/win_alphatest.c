#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define USE_CONSOLE
#include <allegro.h>

#define MAX_FRAME 19


volatile int draw_now = TRUE; // 'volatile' is VERY important


// ==========================================================================
void my_counter(void)
{
   draw_now = TRUE;
}
END_OF_FUNCTION(my_counter);


// ==========================================================================
void main(void)
{
   PALETTE   mypal;
   BITMAP    * anim[MAX_FRAME], * back, * tmpbmp;
   int       i, bpp = 16, c, a, r, g, b, x, y, w, h, done;
   char      tmp[255];
   
   allegro_init();
   install_keyboard();
   install_timer();

   // go into 16bpp or 15bpp mode
   // (just a test to be different than 32bpp, but 32bpp is better of course)
   set_color_depth(bpp);
   if (set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0) < 0)
   {
      bpp = 15;
      set_color_depth(bpp);
      if (set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0) < 0)
      {
         printf("error : %s\n", allegro_error);
         return;
      }
   }
   text_mode(-1);
   
   // load frames
   set_color_depth(32); // makes frames in RGBA for using ALPHA channel

   for (i=0; i < MAX_FRAME; i++)
   {
      sprintf(tmp, "d00-f%03i.pcx", i);
      anim[i] = load_pcx(tmp, mypal);
   }

   // editing the alpha channel of frames
   for (i=0; i < MAX_FRAME; i++)
   {
      for (y=0; y<anim[i]->h; y++)
      {
         for (x=0; x<anim[i]->w; x++)
         {
            c = getpixel(anim[i], x, y);
            r = getr(c);
            g = getg(c);
            b = getb(c);
            a = (g*151 + r*77 + b*29) / 257; // alpha = now luminance
            putpixel(anim[i], x, y, makeacol32(r, g, b, a));
         }
      }
   }

   set_color_depth(bpp); // back into the screen bpp
   
   // chess board
   for (y=0; y < 480; y += 32)
   {
      for (x=0; x < 640; x += 32)
      {
         rectfill(screen, x,    y,    x+32, y+32, makecol(128, 128, 128));
         rectfill(screen, x,    y+16, x+16, y+32, makecol(64, 64, 64));
         rectfill(screen, x+16, y,    x+32, y+16, makecol(64, 64, 64));
      }
   }
   
   // enable special drawing modes
   set_trans_blender(0, 0, 0, 0); // enable truecolor blender routines
   set_alpha_blender();           // enable use of alpha channel
                                  //    we can also use our 32bpp sprite onto
                                  //    the 16bpp screen this way

   for (i=0; i < MAX_FRAME; i++)
   {
      draw_trans_sprite(screen, anim[i], i*30, i*20);
      draw_trans_sprite(screen, anim[i], 400, 70);
   }
      
   textprintf(screen, font, 205, 35, makecol(0, 0, 0), "press SPACE to QUIT");
   textprintf(screen, font, 204, 34, makecol(255, 255, 255), "press SPACE to QUIT");

   // prepare animation
   w = anim[0]->w;
   h = anim[0]->h;
   x = 50;
   y = 250;
   tmpbmp = create_bitmap(w, h);
   back   = create_bitmap(w, h);
   LOCK_VARIABLE(draw_now);
   LOCK_FUNCTION(my_counter);
   if (install_int(my_counter, 1000 / 25) < 0) // 25 fps
   {
      for (i=0; i < MAX_FRAME; i++)
         destroy_bitmap(anim[i]);
      destroy_bitmap(back);
      destroy_bitmap(tmpbmp);
      printf("allegro_error = %s\n", allegro_error);
      return;
   }
   blit(screen, back, x, y, 0, 0, w, h);
   done = FALSE;
   i    = 0;

   // animate
   while ( ! done)
   {
      blit(back, tmpbmp, 0, 0, 0, 0, w, h);     // back  --> tmp
      draw_trans_sprite(tmpbmp, anim[i], 0, 0); // frame --> tmp
      i++;
      if (i >= MAX_FRAME)
         i = 0;
      while ((draw_now == FALSE) && ( ! key[KEY_SPACE]))
         ;
      vsync();
      blit(tmpbmp, screen, 0, 0, x, y, w, h);   // tmp   --> screen
      draw_now = FALSE;
      if (key[KEY_SPACE])
         done = TRUE;
   }

   // end
   for (i=0; i < MAX_FRAME; i++)
      destroy_bitmap(anim[i]);
   destroy_bitmap(back);
   destroy_bitmap(tmpbmp);
}
END_OF_MAIN();

