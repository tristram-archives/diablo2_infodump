#include <stdio.h>
#include <stdlib.h>

#include "defs.h"

GIF_ANIM_S * load_gif(char * gif_name);

// ==========================================================================
void main(int argc, char **argv)
{
   GIF_ANIM_S * gif_anim;
   
   if (argc == 2)
   {
      gif_anim = load_gif(argv[1]);
      destroy_gif(gif_anim);
   }
}
END_OF_MAIN();

