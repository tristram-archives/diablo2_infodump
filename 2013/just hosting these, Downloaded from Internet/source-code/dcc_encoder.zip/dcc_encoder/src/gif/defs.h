#define UBYTE  unsigned char
#define WORD   short int
#define UWORD  unsigned WORD
#define UDWORD unsigned long

#define USE_CONSOLE
#include <allegro.h>
