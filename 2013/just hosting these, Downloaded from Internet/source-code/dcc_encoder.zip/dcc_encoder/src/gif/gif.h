#ifndef _GIF_H_

#define _GIF_H_

// RGB value of 1 color (0 to 255)
typedef struct
{
   UBYTE r, g, b;
} GIF_RGB_S;

// palette, can have 2 4 8 16 32 64 128 or 256 colors
typedef GIF_RGB_S GIF_PALETTE_S [256];

// GIF header
typedef struct
{
   char sig[3]; // signature "GIF"
   char ver[3]; // version "87a" or "89a"

   // Logical Screen Descriptor Block
   UWORD screen_w; // logical screen width
   UWORD screen_h; // logical screen height

   UBYTE resolution_flag; // bitfield = PCCCSBBB :
                          //    Palette / Color depth / Sort flag /
                          //    Bits per pixels
      UBYTE have_global_palette; // (resolution_flag  & 0x80) >> 7
      UBYTE color_depth;         // ((resolution_flag & 0x70) >> 4) + 1
      UBYTE sort_flag;           // (resolution_flag  & 0x08) >> 3
      UBYTE bits_per_pixel;      // (resolution_flag  & 0x07) + 1
         UWORD num_color;        // 1 << bits_per_pixel
   
   UBYTE background_color;   // meaningless if no global palette
   UBYTE pixel_aspect_ratio; // meaningfull only if NOT zero

   // Global Color Map (optional)
   GIF_PALETTE_S glb_palette; // max 256 * 3 colors

} GIF_HEADER_S;

// GIF Graphic Control Extension
typedef struct
{
   UBYTE disposal_method;
   UBYTE user_input;
   UBYTE transparent_color_flag;
   UWORD delay_time;
   int   transparent_color;
} GIF_GFX_CTRL_S;

// GIF Image Descriptor
typedef struct
{
   UWORD left_position;
   UWORD top_position;
   UWORD width;
   UWORD height;
   UBYTE local_palette_flag;
   UBYTE interlace;
   UBYTE sort_flag;
   UBYTE palette_size;
} GIF_ID_S;

// a simple struct to handle 1 frame of a GIF animation
//    can be a small area of the main animation
typedef struct
{
   UWORD  left_position;
   UWORD  top_position;
   UWORD  width;
   UWORD  height;
   int    palette_idx; // can be -1 if no global & no local palettes
   int    trans_idx;   // transparent color index, -1 if no transparency
   UWORD  delay;       // in # of 1/100 of a second
   BITMAP * bmp;
} GIF_FRAME_S;

// a simple struct to handle the GIF animation
typedef struct
{
   int           num_frames;    // can be zero if no frames at all
   int           num_palettes;  // can be 0 if no global & no local palettes
   int           width, height; // all frames fit within
   GIF_FRAME_S   * frame;
   GIF_PALETTE_S * palette;
} GIF_ANIM_S;

// declaration of functions
GIF_ANIM_S * load_gif    (char * gif_name);
void         destroy_gif (GIF_ANIM_S * g);

#endif
