#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defs.h"
#include "gif.h"

// Disable warning messages
// "unreferenced inline function has been removed"
#pragma warning( disable : 4514)


// ==========================================================================
void gif_read_header(FILE * file, GIF_HEADER_S * g)
{
   int i;

   fread(g->sig, 1, 3, file);
   fread(g->ver, 1, 3, file);
   fread( & g->screen_w, 2, 1, file);
   fread( & g->screen_h, 2, 1, file);

   g->resolution_flag = fgetc(file);
      g->have_global_palette = (g->resolution_flag  & 0x80) >> 7;
      g->color_depth         = ((g->resolution_flag & 0x70) >> 4) + 1;
      g->sort_flag           = (g->resolution_flag  & 0x08) >> 3;
      g->bits_per_pixel      = (g->resolution_flag  & 0x07) + 1;
         g->num_color        = 1 << g->bits_per_pixel;

   g->background_color   = fgetc(file);
   g->pixel_aspect_ratio = fgetc(file);

   memset(g->glb_palette, 0, sizeof(GIF_PALETTE_S));
   if (g->have_global_palette)
   {
      for (i=0; i<g->num_color; i++)
      {
         g->glb_palette[i].r = fgetc(file);
         g->glb_palette[i].g = fgetc(file);
         g->glb_palette[i].b = fgetc(file);
      }
   }
}


// ==========================================================================
// interlace   = TRUE / FALSE
// trans_color = -1 for no transparency in this frame
void gif_decode_lzw(FILE * in, int code_depth_init, BITMAP * bmp,
                    int interlace, int trans_color)
{
   UBYTE block[255];
   int   block_size;
   int   curr_code_depth       = code_depth_init + 1;
   int   clear_code            = 1 << code_depth_init;
   int   end_code              = clear_code + 1;
   int   string_code_start     = end_code + 1;
   int   curr_free_string_code = string_code_start;
   int   string_code_max       = 1 << curr_code_depth;
   int   code, old_code=0, first_code=0, c;
   int   byte_pos=0, bit_pos=0;
   int   i, x, y, pass;
   int   * true_y;
   int   interlace_start[4] = {0, 4, 2, 1};
   int   interlace_jump[4]  = {8, 8, 4, 2};
   UBYTE pixel_buff[4096];
   int   pix_idx = 0;
   struct
   {
      int character;
      int prev_char_code;
   } string[4096];


   // init
   memset(string, 0, sizeof(string));
   true_y = (int *) malloc(sizeof(int) * bmp->h);
   if (true_y == NULL)
      return;
   if (interlace == FALSE)
   {
      for (i=0; i < bmp->h; i ++)
         true_y[i] = i;
   }
   else
   {
      i = 0;
      for (pass=0; pass<4; pass++)
         for (y=interlace_start[pass]; y < bmp->h; y += interlace_jump[pass])
            true_y[i++] = y;
   }
   x = y = 0;

   // read 1st block
   block_size = fgetc(in);
   fread(block, 1, block_size, in);

   // MAIN loop
   for(;;) // end-code will break it
//   while (TRUE)
   {
      // get code
      code = 0;
      for (i=0; i<curr_code_depth; i++)
      {
         if (block[byte_pos] & (1 << bit_pos))
            code |= 1 << i;
         bit_pos++;
         if (bit_pos >= 8)
         {
            bit_pos = 0;
            byte_pos++;
            if (byte_pos >= block_size)
            {
               byte_pos = 0;
               block_size = fgetc(in);
               fread(block, 1, block_size, in);
            }
         }
      }
      if (code == end_code)
      {
         // end
         break;
      }
      else if (code == clear_code)
      {
         // reset table
         curr_code_depth       = code_depth_init + 1;
         curr_free_string_code = string_code_start;
         string_code_max       = 1 << curr_code_depth;
         while (code == clear_code)
         {
            // get code
            code = 0;
            for (i=0; i<curr_code_depth; i++)
            {
               if (block[byte_pos] & (1 << bit_pos))
                  code |= 1 << i;
               bit_pos++;
               if (bit_pos >= 8)
               {
                  bit_pos = 0;
                  byte_pos++;
                  if (byte_pos >= block_size)
                  {
                     byte_pos = 0;
                     block_size = fgetc(in);
                     fread(block, 1, block_size, in);
                  }
               }
            }
         }
         if (code == end_code)
         {
            // end
            break;
         }
			else if (code >= curr_free_string_code)
         {
            // shouldn't happen
            code = 0;
         }

         // 1st pixel after a clear-code
         old_code = first_code = code;
         pixel_buff[pix_idx++] = code;
      }
      else
      {
         // was not a clear-code, nor a end-code, so decode strings
         c = code;
         if (c >= curr_free_string_code)
         {
            c = old_code;
            pixel_buff[pix_idx++] = first_code;
         }
         while (c >= string_code_start)
         {
            pixel_buff[pix_idx++] = string[c].character;
            c = string[c].prev_char_code;
         }
         pixel_buff[pix_idx++] = c;
         if (curr_free_string_code < string_code_max)
         {
            string[curr_free_string_code].character = first_code = c;
            string[curr_free_string_code++].prev_char_code = old_code;
            old_code = code;
         }
         if (curr_free_string_code >= string_code_max)
         {
            if (curr_code_depth < 12)
            {
               string_code_max <<= 1;
               curr_code_depth++;
            }
         }

         // draw each "characters" of the "string" in reverse order (unstack)
         while (pix_idx)
         {
            pix_idx--;
            if (pixel_buff[pix_idx] != trans_color)
               putpixel(bmp, x, true_y[y], pixel_buff[pix_idx]);
            x++;
            if (x >= bmp->w)
            {
               x = 0;
               y++;
            }
         }
         pix_idx = 0;
      }
   }
   free(true_y);
}


// ==========================================================================
int gif_read_all_frames(FILE * in, GIF_HEADER_S * g, GIF_ANIM_S * anim)
{
   GIF_GFX_CTRL_S gif_gfx_ctrl;
   GIF_ID_S       gif_id;
   BITMAP         * main_bmp, * sub_bmp, * tmp_bmp;
   int            c, size, type;
   int            i, code_bit_width, pal_idx = 0, frame_idx = 0;


   // inits
   memset( & gif_gfx_ctrl, 0, sizeof(GIF_GFX_CTRL_S));
   tmp_bmp = NULL;

   // in case
   if ((in == NULL) || (g == NULL) || (anim == NULL))
      return 1;
      
   // global palette
   if (g->have_global_palette)
   {
      for (i=0; i<256; i++)
      {
         anim->palette[0][i].r = g->glb_palette[i].r;
         anim->palette[0][i].g = g->glb_palette[i].g;
         anim->palette[0][i].b = g->glb_palette[i].b;
      }
      pal_idx++;
   }
   
   // main bitmap, where all the frames can modify any areas
   main_bmp = create_bitmap(g->screen_w, g->screen_h);
   if (main_bmp == NULL)
      return 1;
   if (g->have_global_palette)
      clear_to_color(main_bmp, g->background_color);
   else
      clear(main_bmp); // set all pixels to zero


   // read blocks
   c = fgetc(in);
   while (c != EOF)
   {
      if (c == 0x3B)
         break; // trailer
      switch (c)
      {
         case 0x21 :
            type = fgetc(in);
            if (type == 0xF9)
            {
               // Graphic Control extension
               memset( & gif_gfx_ctrl, 0, sizeof(GIF_GFX_CTRL_S));
               fgetc(in); // skip size
               c = fgetc(in);
                  gif_gfx_ctrl.disposal_method        = (c & 0x1C) >> 2;
                  gif_gfx_ctrl.user_input             = (c & 0x02) >> 1;
                  gif_gfx_ctrl.transparent_color_flag = c & 0x01;
               fread( & gif_gfx_ctrl.delay_time, 2, 1, in);
               gif_gfx_ctrl.transparent_color = fgetc(in);
               if ( ! gif_gfx_ctrl.transparent_color_flag)
                  gif_gfx_ctrl.transparent_color = -1;
            }
            else
            {
               // skip block data
               size = fgetc(in);
               fseek(in, size, SEEK_CUR);
            }
            
            // skip sub-blocks data
            c = fgetc(in);
            while (c)
            {
               fseek(in, c, SEEK_CUR);
               c = fgetc(in);
            }
            break;


         case 0x2C :
            fread(&gif_id.left_position, 2, 1, in);
            fread(&gif_id.top_position,  2, 1, in);
            fread(&gif_id.width,         2, 1, in);
            fread(&gif_id.height,        2, 1, in);
            c = fgetc(in);
               gif_id.local_palette_flag = (c & 0x80) >> 7;
               gif_id.interlace          = (c & 0x40) >> 6;
               gif_id.sort_flag          = (c & 0x20) >> 5;
               gif_id.palette_size       = 1 << ((c & 0x7) + 1);

            anim->frame[frame_idx].palette_idx = -1;
            if (g->have_global_palette)
               anim->frame[frame_idx].palette_idx = 0;
            if (gif_id.local_palette_flag)
            {
               for (i=0; i<gif_id.palette_size; i++)
               {
                  anim->palette[pal_idx][i].r = fgetc(in);
                  anim->palette[pal_idx][i].g = fgetc(in);
                  anim->palette[pal_idx][i].b = fgetc(in);
               }
               anim->frame[frame_idx].palette_idx = pal_idx;
               pal_idx++;
            }
            
            anim->frame[frame_idx].left_position = gif_id.left_position;
            anim->frame[frame_idx].top_position  = gif_id.top_position;
            anim->frame[frame_idx].width         = gif_id.width;
            anim->frame[frame_idx].height        = gif_id.height;

            anim->frame[frame_idx].trans_idx = gif_gfx_ctrl.transparent_color;
            anim->frame[frame_idx].delay     = gif_gfx_ctrl.delay_time;
            
            code_bit_width = fgetc(in);
            sub_bmp = create_sub_bitmap(
               main_bmp,
               gif_id.left_position,
               gif_id.top_position,
               gif_id.width,
               gif_id.height
            );
            if (sub_bmp == NULL)
            {
               destroy_bitmap(main_bmp);
               return 1;
            }
            if (gif_gfx_ctrl.disposal_method == 3)
            {
               // save background before decoding this frame
               tmp_bmp = create_bitmap(gif_id.width, gif_id.height);
               if (tmp_bmp == NULL)
               {
                  destroy_bitmap(sub_bmp);
                  destroy_bitmap(main_bmp);
                  return 1;
               }
               blit(sub_bmp, tmp_bmp, 0, 0, 0, 0, gif_id.width, gif_id.height);
            }

            // decode sub-blocks LZW data
            gif_decode_lzw(in, code_bit_width, sub_bmp, gif_id.interlace,
               gif_gfx_ctrl.transparent_color);

            // save frame
            anim->frame[frame_idx].bmp = create_bitmap(gif_id.width,
                                                       gif_id.height);
            if (anim->frame[frame_idx].bmp == NULL)
            {
               if (gif_gfx_ctrl.disposal_method == 3)
                  destroy_bitmap(tmp_bmp);
               destroy_bitmap(sub_bmp);
               destroy_bitmap(main_bmp);
               return 1;
            }
            blit(sub_bmp, anim->frame[frame_idx].bmp,
                 0, 0, 0, 0, gif_id.width, gif_id.height);

            // disposal method handle
            if (gif_gfx_ctrl.disposal_method == 2)
            {
               // restore background color
               if (g->have_global_palette)
                  clear_to_color(sub_bmp, g->background_color);
               else
                  clear(sub_bmp);
            }
            else if (gif_gfx_ctrl.disposal_method == 3)
            {
               // restore previous background
               blit(tmp_bmp, sub_bmp, 0, 0, 0, 0, gif_id.width, gif_id.height);
               destroy_bitmap(tmp_bmp);
            }

            destroy_bitmap(sub_bmp);

            // the graphicx control was only valid for this frame
            memset( & gif_gfx_ctrl, 0, sizeof(GIF_GFX_CTRL_S));
            gif_gfx_ctrl.transparent_color = -1;
            frame_idx++;
            break;
      }
      c = fgetc(in); // next block
   }
   destroy_bitmap(main_bmp);
   return 0;
}


// ==========================================================================
// count # of frames & # of palettes
// restore the original file position after the count
void gif_count_frames(FILE * in, int * num_f, int * num_p)
{
   long old_pos = ftell(in);
   int  c, size;

   c = fgetc(in);
   while (c != EOF)
   {
      if (c == 0x3B) // trailer
         break;
         
      // skip block
      switch (c)
      {
         case 0x21 : // extension introducer
            fgetc(in); // skip label
            size = fgetc(in);
            fseek(in, size, SEEK_CUR);
            break;

         case 0x2C : // image descriptor
            (* num_f)++;
            fseek(in, 8, SEEK_CUR);
            c = fgetc(in);
            if (c & 0x80)
            {
               (* num_p)++;
               fseek(in, 3 * (1 << ((c & 0x7) + 1)), SEEK_CUR);
            }
            fgetc(in); // skip lzw minimum code depth
            break;
      }

      // skip sub-blocks data
      c = fgetc(in);
      while (c && (c != EOF))
      {
         fseek(in, c, SEEK_CUR);
         c = fgetc(in);
      }

      // next block
      c = fgetc(in);
   }
   fseek(in, old_pos, SEEK_SET);
}


// ==========================================================================
void destroy_gif_frame(GIF_FRAME_S * f)
{
   if (f == NULL)
      return;
   if (f->bmp != NULL)
      destroy_bitmap(f->bmp);
}


// ==========================================================================
void destroy_gif(GIF_ANIM_S * g)
{
   int i;
   
   if (g == NULL)
      return;
   if (g->frame != NULL)
   {
      for (i=0; i<g->num_frames; i++)
         destroy_gif_frame( & g->frame[i]);
      free(g->frame);
   }
   if (g->palette != NULL)
      free(g->palette);
   free(g);
}


// ==========================================================================
GIF_ANIM_S * load_gif(char * gif_name)
{
   GIF_HEADER_S gif_header;
   GIF_ANIM_S   * gif_anim;
   FILE         * in;
   int          size, num_frames = 0, num_palettes = 0;

PALETTE pal;
char    pcx_name[80];
int     i, p, c;


   allegro_init();
   
   // open file
   in = fopen(gif_name, "rb");
   if (in == NULL)
      return NULL;

   // header
   gif_read_header(in, & gif_header);
   if (gif_header.have_global_palette);
      num_palettes++;

   // count frames & palettes
   gif_count_frames(in, & num_frames, & num_palettes);

   // main animation malloc()
   size = sizeof(GIF_ANIM_S);
   gif_anim = (GIF_ANIM_S *) malloc(size);
   if (gif_anim == NULL)
   {
      fclose(in);
      return NULL;
   }
   memset(gif_anim, 0, size);

   // main animation infos
   gif_anim->num_frames   = num_frames;
   gif_anim->num_palettes = num_palettes;
   gif_anim->width        = gif_header.screen_w;
   gif_anim->height       = gif_header.screen_h;
   
   // frames malloc()
   if (num_frames)
   {
      size = num_frames * sizeof(GIF_FRAME_S);
      gif_anim->frame = (GIF_FRAME_S *) malloc(size);
      if (gif_anim->frame == NULL)
      {
         fclose(in);
         destroy_gif(gif_anim);
         return NULL;
      }
      memset(gif_anim->frame, 0, size);
   }
   
   // palettes malloc()
   if (num_palettes)
   {
      size = num_palettes * sizeof(GIF_PALETTE_S);
      gif_anim->palette = (GIF_PALETTE_S *) malloc(size);
      if (gif_anim->palette == NULL)
      {
         fclose(in);
         destroy_gif(gif_anim);
         return NULL;
      }
      memset(gif_anim->palette, 0, size);
   }
   
// debug infos
printf("num_frames   = %i\n", num_frames);
printf("num_palettes = %i\n", num_palettes);
printf("total size   = %i + %i + %i = %i\n",
   sizeof(GIF_ANIM_S),
   num_frames * sizeof(GIF_FRAME_S),
   num_palettes * sizeof(GIF_PALETTE_S),
      sizeof(GIF_ANIM_S) +
      num_frames * sizeof(GIF_FRAME_S) +
      num_palettes * sizeof(GIF_PALETTE_S)
);
fflush(stdout);
   
   // decode frames and put them in the animation struct
   if (gif_read_all_frames(in, & gif_header, gif_anim))
   {
      fclose(in);
      destroy_gif(gif_anim);
      return NULL;
   }

   // debug
   for (i=0; i < gif_anim->num_frames; i++)
   {
      printf("\nframe %3i\n", i);
      printf("   .pos   = %3i, %3i\n",
         gif_anim->frame[i].left_position,
         gif_anim->frame[i].top_position);
      printf("   .w, h  = %3i, %3i\n",
         gif_anim->frame[i].width,
         gif_anim->frame[i].height);
      printf("   .pal   = %i\n", gif_anim->frame[i].palette_idx);
      printf("   .trans = %i\n", gif_anim->frame[i].trans_idx);
      printf("   .delay = %i\n", gif_anim->frame[i].delay);
      printf("   .bmp   = 0x%p\n", gif_anim->frame[i].bmp);
         
      sprintf(pcx_name, "frame%03i.pcx", i);
      p = gif_anim->frame[i].palette_idx;
      for (c=0; c<256; c++)
      {
         pal[c].r = gif_anim->palette[p][c].r >> 2;
         pal[c].g = gif_anim->palette[p][c].g >> 2;
         pal[c].b = gif_anim->palette[p][c].b >> 2;
      }
//      save_pcx(pcx_name, gif_anim->frame[i].bmp, pal);
   }
   
   // end
   fclose(in);
   return gif_anim;
}

