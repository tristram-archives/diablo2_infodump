#ifndef _PSTYPES_H_

#define _PSTYPES_H_


/// 8 bits
typedef signed char        BYTE;
typedef unsigned char      UBYTE;

// 16 bits
typedef signed short int   WORD;
typedef unsigned short int UWORD;

// 32 bits
typedef signed long        DWORD;
typedef unsigned long      UDWORD;

// BOOLEAN
#define FALSE  0
#define TRUE  -1


#endif
