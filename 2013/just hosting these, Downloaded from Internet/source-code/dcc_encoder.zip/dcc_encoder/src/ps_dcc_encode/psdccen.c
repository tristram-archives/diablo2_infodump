#include <stdlib.h>
#include <string.h>

#include "..\pstypes.h"
#include "psdccen.h"

#include <stdio.h>


/* ===========================================================================
   psdccen_init_box()

   init a box to default values

   input :
      - pointer to a box

   output :
      if error : -1
      if ok    : 0
============================================================================== */
WORD psdccen_init_box(PSDCCENBOX_S * box)
{
   if (box == NULL)
      return -1;

   box->x1 = 0x7FFFFFFFL; // greatest DWORD :  2147483647
   box->y1 = 0x7FFFFFFFL; // greatest DWORD :  2147483647
   box->x2 = 0x80000000L; // lowest   DWORD : -2147483648
   box->y2 = 0x80000000L; // lowest   DWORD : -2147483648
   box->w  = 0;
   box->h  = 0;

   // end
   return 0;
}


/* ===========================================================================
   psdccen_init_distrgb()

   init the lookup tables for speeding up nearest color matching formulas

   input :
      - pointer to an anim

   output :
      if error : -1
      if ok    : 0
============================================================================== */
WORD psdccen_init_distrgb(PSDCCENANIM_S * anim)
{
   WORD i, n, d;


   if (anim == NULL)
      return -1;

   // for all possible values of color componants in the original palette
   for (i=0; i < 256; i++)
   {
      anim->dist.r[i][i] = 0;
      anim->dist.g[i][i] = 0;
      anim->dist.b[i][i] = 0;

      // for all possible values of color componants in the dcc palette
      for (n = (WORD) (i + 1); n < 256; n++)
      {
         d = (WORD) (n - i);
         anim->dist.r[i][n] = anim->dist.r[n][i] = d * d *  76;
         anim->dist.g[i][n] = anim->dist.g[n][i] = d * d * 150;
         anim->dist.b[i][n] = anim->dist.b[n][i] = d * d *  28;
      }
   }

   // end
   return 0;
}


/* ===========================================================================
   psdccen_smallest_img()

   find the smallest image within the frame, this means to don't take the
   transparency color (anim->bg_idx) into account.

   input :
      - pointer to a frame

   output :
      if error : -1
      if ok    : 0
============================================================================== */
WORD psdccen_smallest_img(PSDCCENANIM_S * anim, PSDCCENFRM_S * frm)
{
   UDWORD x, y;
   WORD   done;


   if (frm == NULL)
      return -1;

   if ((frm->width == 0) || (frm->height == 0))
   {
      // completly empty image
      psdccen_init_box( & frm->imgbox); // set w & h to zero
      return 0;
   }

   if ((frm->width == (UDWORD) -1) || (frm->height == (UDWORD) -1))
      return -1;

   if (frm->line == NULL)
      return -1;

   // search for upper pixel
   x = 0;
   y = 0;
   done = FALSE;
   while ( ! done)
   {
      if (frm->line[y][x] != anim->bg_idx)
      {
         frm->imgbox.y1 = y;
         done = TRUE;
      }
      else
      {
         x++;
         if (x >= frm->width)
         {
            x = 0;
            y++;
            if (y >= frm->height)
               done = TRUE;
         }
      }
   }
   if (y >= frm->height)
   {
      // completly empty image
      psdccen_init_box( & frm->imgbox); // set w & h to zero
      return 0;
   }

   // search for lower pixel
   x = 0;
   y = frm->height - 1;
   done = FALSE;
   while ( ! done)
   {
      if (frm->line[y][x] != anim->bg_idx)
      {
         frm->imgbox.y2 = y;
         done = TRUE;
      }
      else
      {
         x++;
         if (x >= frm->width)
         {
            x = 0;
            y--;
            if (y == (UDWORD) -1)
               done = TRUE;
         }
      }
   }

   // search for left pixel
   x = 0;
   y = 0;
   done = FALSE;
   while ( ! done)
   {
      if (frm->line[y][x] != anim->bg_idx)
      {
         frm->imgbox.x1 = x;
         done = TRUE;
      }
      else
      {
         y++;
         if (y >= frm->height)
         {
            y = 0;
            x++;
            if (x >= frm->width)
               done = TRUE;
         }
      }
   }

   // search for right pixel
   x = frm->width - 1;
   y = 0;
   done = FALSE;
   while ( ! done)
   {
      if (frm->line[y][x] != anim->bg_idx)
      {
         frm->imgbox.x2 = x;
         done = TRUE;
      }
      else
      {
         y++;
         if (y >= frm->height)
         {
            y = 0;
            x--;
            if (x == (UDWORD) -1)
               done = TRUE;
         }
      }
   }

   // update w & h
   frm->imgbox.w = frm->imgbox.x2 - frm->imgbox.x1 + 1;
   frm->imgbox.h = frm->imgbox.y2 - frm->imgbox.y1 + 1;

   // end
   return 0;
}


/* ===========================================================================
   psdccen_find_boxes()

   fill all boxes of frame/direction/animation

   input :
      - pointer to an animation

   output :
      if error : -1
      if ok    : 0
============================================================================== */
WORD psdccen_find_boxes(PSDCCENANIM_S * anim)
{
   PSDCCENDIR_S * dir;
   PSDCCENFRM_S * frm;
   UDWORD       d, f, nb_good_dir, nb_good_img;
   DWORD        coord;


   if (anim == NULL)
      return -1;

   if (anim->nb_dir == ((UDWORD) -1)) // reserved value
      return -1;

   if (anim->nb_frm_per_dir == ((UDWORD) -1)) // reserved value
      return -1;

   if (anim->direction == NULL)
      return -1;

   // init animation box
   if (psdccen_init_box( & anim->animbox) != 0)
      return -1;

   // for all directions
   nb_good_dir = 0;
   for (d=0; d < anim->nb_dir; d++)
   {
      // get direction pointer
      dir = & anim->direction[d];
      if (dir == NULL)
         return -1;

      // init direction box
      if (psdccen_init_box( & dir->dirbox) != 0)
         return -1;

      if (dir->frame == NULL)
         return -1;

      // for all frames of this direction
      nb_good_img = 0;
      for (f=0; f < anim->nb_frm_per_dir; f++)
      {
         // get frame pointer
         frm = & dir->frame[f];
         if (frm == NULL)
            return -1;

         // compute entire frame upper/left position in space
         frm->frmbox.x1 = frm->offset_x;
         frm->frmbox.y1 = frm->offset_y;

         // compute entire frame dimensions
         frm->frmbox.w = frm->width;
         frm->frmbox.h = frm->height;

         // compute entire frame lower/right position in space
         if ((frm->width != 0) && (frm->height != 0))
         {
            frm->frmbox.x2 = frm->offset_x + frm->width  - 1;
            frm->frmbox.y2 = frm->offset_y + frm->height - 1;
         }
         else
         {
            frm->frmbox.x2 = frm->offset_x;
            frm->frmbox.y2 = frm->offset_y;
         }

         // search smallest img within the frame
         if (psdccen_smallest_img(anim, frm) != 0)
            return -1;

         // update direction box
         // use not entire but smallest img
         if ((frm->imgbox.w != 0) && (frm->imgbox.h != 0)) // if at least 1 pixel
         {
            nb_good_img++; // one more good image for this direction

            coord = frm->frmbox.x1 + frm->imgbox.x1;
            if (coord < dir->dirbox.x1)
               dir->dirbox.x1 = coord;

            coord = frm->frmbox.y1 + frm->imgbox.y1;
            if (coord < dir->dirbox.y1)
               dir->dirbox.y1 = coord;

            coord = frm->frmbox.x1 + frm->imgbox.x2;
            if (coord > dir->dirbox.x2)
               dir->dirbox.x2 = coord;

            coord = frm->frmbox.y1 + frm->imgbox.y2;
            if (coord > dir->dirbox.y2)
               dir->dirbox.y2 = coord;
         }
         else
         {
            frm->imgbox.x1 = 0;
            frm->imgbox.y1 = 0;
            frm->imgbox.x2 = 0;
            frm->imgbox.y2 = 0;
         }
      }

      // end the update of the direction box
      if (nb_good_img != 0)
      {
         nb_good_dir++; // one more good direction

         dir->dirbox.w = dir->dirbox.x2 - dir->dirbox.x1 + 1;
         dir->dirbox.h = dir->dirbox.y2 - dir->dirbox.y1 + 1;
      }
      // else nothing, as dirbox.w & h will stay to zero

      // update animation box
      if (dir->dirbox.x1 < anim->animbox.x1)
         anim->animbox.x1 = dir->dirbox.x1;

      if (dir->dirbox.y1 < anim->animbox.y1)
         anim->animbox.y1 = dir->dirbox.y1;

      if (dir->dirbox.x2 > anim->animbox.x2)
         anim->animbox.x2 = dir->dirbox.x2;

      if (dir->dirbox.y2 > anim->animbox.y2)
         anim->animbox.y2 = dir->dirbox.y2;
   }

   // end the update of the animation box
   if (nb_good_dir != 0)
   {
      anim->animbox.w = anim->animbox.x2 - anim->animbox.x1 + 1;
      anim->animbox.h = anim->animbox.y2 - anim->animbox.y1 + 1;
   }
   // else nothing, as animbox.w & h will stay to zero

   // end
   return 0;
}


/* ===========================================================================
   psdccen_map_img2dcc()

   prepare lookup tables for speed up comparison between original pixel color
   and dcc color after dithering/remaping.

   * fill the anim->img2dccdist[][] table

   * fill the anim->img2dccerrratio[][] table

   * fill the anim->img2dcc_cmap[] table that is used to know
     how to map each image palette colors into a dcc palette color

   * fill the anim->dist.r[][], anim->dist.g[][] and anim->dist.b[][] tables


   input :
      - pointer to an animation

   output :
      if error : -1
      if ok    : 0
============================================================================== */
WORD psdccen_map_img2dcc(PSDCCENANIM_S * anim)
{
   WORD   i, c;
   UBYTE  curr_col;
   UDWORD r, g, b, r2, g2, b2, min_dist, dist, error_ratio;


   if (anim == NULL)
      return -1;

   if (psdccen_init_distrgb(anim) != 0)
      return -1;

   // for all image colors
   for (i=0; i < 256; i++)
   {
      if (i == anim->bg_idx)
      {
         // remap to dcc transparent color
         anim->img2dcc_cmap[i] = 0;

         // fill distance & error ratio lookup tables, for transparency
         for (c=0; c < 256; c++)
         {
            anim->img2dccdist[i][c]     = 0x7FFFFFFFLU;
            anim->img2dccdist[c][0]     = 0x7FFFFFFFLU;
            anim->img2dccerrratio[i][c] = 0x0000FFFFLU;
            anim->img2dccerrratio[c][0] = 0x0000FFFFLU;
         }
         anim->img2dccdist[i][0]     = 0;
         anim->img2dccerrratio[i][0] = 0;
      }
      else
      {         
         // search the nearest color
         r = anim->img_palette[i].r;
         g = anim->img_palette[i].g;
         b = anim->img_palette[i].b;
         min_dist = 0x7FFFFFFFLU;
         curr_col = 0;
         for (c=1; c < 256; c++)
         {
            if (anim->color_to_use[c] != 0)
            {
               // this color can be used
               dist = anim->dist.r[r][ anim->dcc_palette[c].r ] +
                      anim->dist.g[g][ anim->dcc_palette[c].g ] +
                      anim->dist.b[b][ anim->dcc_palette[c].b ];

               // update distance lookup table
               anim->img2dccdist[i][c] = dist;

               // update error ratio lookup table
               r2 = anim->dcc_palette[c].r;
               g2 = anim->dcc_palette[c].g;
               b2 = anim->dcc_palette[c].b;
               error_ratio  =  76 * (r2 > r ? r2 - r : r - r2); // init error ratio
               error_ratio += 150 * (g2 > g ? g2 - g : g - g2);
               error_ratio +=  28 * (b2 > b ? b2 - b : b - b2);
               anim->img2dccerrratio[i][c] = error_ratio;

               // is it a nearest color ?
               if (dist < min_dist)
               {
                  // yep, keep trace of it
                  min_dist = dist;
                  curr_col = (UBYTE) c;
               }
            }
         }

         // update nearest color from img to dcc palette lookup table
         anim->img2dcc_cmap[i] = curr_col;
      }
   }

   // end
   return 0;
}


/* ===========================================================================
   psdccen_sort_ubyte_table()

   sort a (small) table of UBYTE

   input :
      - pointer to the 1st element of the table
      - number of elements in the table
============================================================================== */
void psdccen_sort_ubyte_table(UBYTE * elm, UWORD nb_elm)
{
   WORD  done, i;
   UBYTE tmp;

   if (nb_elm <= 1)
      return;
   do
   {
      done = TRUE;
      for (i=1; i < nb_elm; i++)
      {
         if (elm[i] < elm[i - 1])
         {
            tmp        = elm[i - 1];
            elm[i - 1] = elm[i];
            elm[i]     = tmp;
            done       = FALSE;
         }
      }
   } while (done == FALSE);
}


/* ===========================================================================
   psdccen_cell_avg_colors()

   scan all pixels of the cell (max 25), isolate R G and B componants, then
   try to make 'nb_div' final dcc colors

   input :
      - pointer to the temporary datas of that cell
      - number of divisions (expected final number of colors)

   output :
      if error : -1
      if ok    : number of colors found (1 ~ 4)
                 (these colors are placed into tmpcell->color[])
============================================================================== */
WORD psdccen_cell_avg_colors(PSDCCENTMPCELL_S * tmpcell, int nb_div)
{
   UBYTE          r[25], g[25], b[25], curr_col;
   int            avg_r[25], avg_g[25], avg_b[25], c, i, start, end;
   WORD           has_transparency, curr_idx, used, nb_val;
   DWORD          x, y;
   UDWORD         r1, g1, b1, min_dist, dist;


   if (tmpcell == NULL)
      return -1;

   if ((nb_div < 1) || (nb_div > 25))
      return -1;

   if (tmpcell->anim == NULL)
      return -1;

   if (tmpcell->dir == NULL)
      return -1;

   if (tmpcell->frm == NULL)
      return -1;

   if ((tmpcell->w > 5) || (tmpcell->h > 5))
      return -1;

   if (tmpcell->line == NULL)
      return -1;

   // inits
   tmpcell->nb_colors = 0;
   tmpcell->color[0]  = 0;
   tmpcell->color[1]  = 0;
   tmpcell->color[2]  = 0;
   tmpcell->color[3]  = 0;

   // get R G and B componants of all pixels
   has_transparency = FALSE;
   curr_idx = 0;
   for (y=0; y < tmpcell->h; y++)
   {
      for (x=0; x < tmpcell->w; x++)
      {
         c = tmpcell->line[y][x];
         if (c != tmpcell->anim->bg_idx)
         {
            r[curr_idx] = tmpcell->anim->img_palette[c].r;
            g[curr_idx] = tmpcell->anim->img_palette[c].g;
            b[curr_idx] = tmpcell->anim->img_palette[c].b;
            curr_idx++;
         }
         else
            has_transparency = TRUE;
      }
   }

   // get number of values saved in the r g and b tables
   // (it's also number of non-transparent pixels in that cell)
   nb_val = curr_idx;

   // sort R G and B componants
   if (nb_val > 1)
   {
      psdccen_sort_ubyte_table(r, nb_val);
      psdccen_sort_ubyte_table(g, nb_val);
      psdccen_sort_ubyte_table(b, nb_val);
   }

   // if more asked division than colors saved, adjust it
   if (nb_div > nb_val)
      nb_div = nb_val;

   // compute average R G and B of all divisions
   for (i=0; i < nb_div; i++)
   {
      avg_r[i] = 0;
      avg_g[i] = 0;
      avg_b[i] = 0;

      start = (nb_val * i) / nb_div;
      end   = (nb_val * (i+1)) / nb_div;

      for (x = start; x < end; x++)
      {
         avg_r[i] += r[x];
         avg_g[i] += g[x];
         avg_b[i] += b[x];
      }
      c = end - start;
      avg_r[i] /= c;
      avg_g[i] /= c;
      avg_b[i] /= c;
   }

   // get the 1 ~ 4 final colors

   // for all the non-transparent colors of the cell, find
   // the nearest color in the dcc palette
   curr_idx           = 0;
   tmpcell->nb_colors = 0;
   if (has_transparency == TRUE)
   {
      // first slot is reserved for the transparency color
      curr_idx  = 1;
   }
   for (i=0; i < nb_div; i++)
   {
      // search the nearest color
      r1 = avg_r[i];
      g1 = avg_g[i];
      b1 = avg_b[i];
      min_dist = 0x7FFFFFFFLU;
      curr_col = 0;
      for (c=1; c < 256; c++)
      {
         if (tmpcell->anim->color_to_use[c] != 0)
         {
            // this color can be used
            dist = tmpcell->anim->dist.r[r1][ tmpcell->anim->dcc_palette[c].r ] +
                   tmpcell->anim->dist.g[g1][ tmpcell->anim->dcc_palette[c].g ] +
                   tmpcell->anim->dist.b[b1][ tmpcell->anim->dcc_palette[c].b ];

            // is it a nearest color ?
            if (dist < min_dist)
            {
               // yep, so keep trace of it
               min_dist = dist;
               curr_col = (UBYTE) c;
            }
         }
      }

      // does this color is already used in the 4 cell colors ?
      used = FALSE;
      for (c=0; (c < curr_idx) && (used == FALSE); c++)
      {
         if ((tmpcell->color[c] == curr_col) && (tmpcell->color[c] != 0))
         {
            // yes. don't place it again
            used = TRUE;
         }
      }
      if (used == FALSE)
      {
         // add this color into the cell color
         if (curr_idx >= 4)
         {
            tmpcell->nb_colors = 4;
            return -1;
         }
         tmpcell->color[curr_idx] = curr_col;
         curr_idx++;
      }
   }

   // end
   tmpcell->nb_colors = curr_idx;
   return curr_idx;
}


/* ===========================================================================
   psdccen_remap_cell()

   remap all pixels of this cell to 1 of the available in that cell (4 max)

   input :
      - pointer to the temporary datas of that cell

   output :
      if error : -1
      if ok    : 0
============================================================================== */
WORD psdccen_remap_cell(PSDCCENTMPCELL_S * tmpcell)
{
   WORD   i, c, x, y, n;
   UBYTE  curr_col;
   UDWORD min_dist, dist;


   if (tmpcell == NULL)
      return -1;

   // for all cell pixels
   for (y=0; y < tmpcell->h; y++)
   {
      for (x=0; x < tmpcell->w; x++)
      {
         i = tmpcell->line[y][x];

         if (i == tmpcell->anim->bg_idx)
         {
            // remap to dcc transparent color
            tmpcell->line[y][x] = 0;

            // color 0 is used
            tmpcell->dir->cells_color_used[0] = TRUE;
         }
         else
         {         
            // search the nearest color
            min_dist = 0x7FFFFFFFLU;
            curr_col = 0;
            for (n=0; n < tmpcell->nb_colors; n++)
            {
               c = tmpcell->color[n];
               if (c == tmpcell->anim->bg_idx)
                  continue;
               dist = tmpcell->anim->img2dccdist[i][c];
               if (dist < min_dist)
               {
                  min_dist = dist;
                  curr_col = (UBYTE) c;
               }
            }

            // apply it
            tmpcell->line[y][x] = curr_col;

            // this color is used
            tmpcell->dir->cells_color_used[curr_col] = TRUE;
         }
      }
   }

   // end
   return 0;
}


/* ===========================================================================
   psdccen_cell_error_ratio()

   compute an error ratio for a cell, due to the dithering and color remaping
   (higher number means more errors)

   input :
      - pointer to the temporary datas of that cell

   output :
      if error : (UDWORD) -1
      if ok    : cell error ratio
============================================================================== */
UDWORD psdccen_cell_error_ratio(PSDCCENTMPCELL_S * tmpcell)
{
   DWORD  x, y;
   WORD   n;
   UBYTE  c1, c2, c;
   UDWORD  dist, min_dist, error_ratio = 0;


   if (tmpcell == NULL)
      return (UDWORD) -1;

   // for all pixels of that cell
   for (y=0; y < tmpcell->h; y++)
   {
      for (x=0; x < tmpcell->w; x++)
      {
         // original color
         c1 = tmpcell->line[y][x];

         // transparent pixels don't makes errors
         if (c1 != tmpcell->anim->bg_idx)
         {
            // dcc color RGB
            // (search the nearest color)
            min_dist = 0x7FFFFFFFLU;
            c2 = 0;
            for (n=0; n < tmpcell->nb_colors; n++)
            {
               c  = tmpcell->color[n];
               if (c == tmpcell->anim->bg_idx)
                  continue;
               dist = tmpcell->anim->img2dccdist[c1][c];
               if (dist < min_dist)
               {
                  min_dist = dist;
                  c2 = c;
               }
            }

            // we know the color that is used, update error ratio
            error_ratio += tmpcell->anim->img2dccerrratio[c1][c2];
         }
      }
   }

   // end
   return error_ratio;
}


/* ===========================================================================
   psdccen_dither_direction()

   dither all cells of all frames of 1 direction to have at most 4 colors

   input :
      - pointer to an animation
      - direction index

   output :
      if error : -1
      if ok    : 0
============================================================================== */
WORD psdccen_dither_direction(PSDCCENANIM_S * anim, UDWORD dir_num)
{
   PSDCCENBOX_S     * dbox, * fbox, * ibox;
   UDWORD           cx, cy, f;
   DWORD            cfx, cfy;
   WORD             done, n, i, min;
   DWORD            x, y;
   PSDCCENTMPCELL_S tmpcell;
   UBYTE            color_present[256], cell_color_saved[4] = {0, 0, 0, 0},
                    nb_saved;
   UDWORD           curr_err_ratio, min_err_ratio;


   if (anim == NULL)
      return -1;

   if (anim->direction == NULL)
      return -1;

   if (anim->nb_dir == (UDWORD) -1) // reserved value
      return -1;

   if (anim->nb_frm_per_dir == (UDWORD) -1) // reserved value
      return -1;

   if (dir_num >= anim->nb_dir)
      return -1;

   tmpcell.anim = anim;

   // get direction pointer
   tmpcell.dir = & anim->direction[dir_num];

   // get direction box
   dbox = & tmpcell.dir->dirbox;

   if (tmpcell.dir->frame == NULL)
      return -1;

   // for all frames
fprintf(stderr, "\nAnimation is %i frames\n", anim->nb_frm_per_dir);
fflush(stderr);
   for (f=0; f < anim->nb_frm_per_dir; f++)
   {
fprintf(stderr, "dithering frame %3i / %3i\n", f+1, anim->nb_frm_per_dir);
fflush(stderr);

      // get frame pointer
      tmpcell.frm = & tmpcell.dir->frame[f];

      // get frame boxes
      fbox = & tmpcell.frm->frmbox;
      ibox = & tmpcell.frm->imgbox;

      // search image position in the first direction-cell
      cx = (fbox->x1 + ibox->x1 - dbox->x1) % 4;
      cy = (fbox->y1 + ibox->y1 - dbox->y1) % 4;

      // search this first direction-cell width and height
      tmpcell.w = (WORD) (4 - cx > ibox->w ? ibox->w : 4 - cx);
      tmpcell.h = (WORD) (4 - cy > ibox->h ? ibox->h : 4 - cy);

      // current cell position in frame
      cfx = ibox->x1;
      cfy = ibox->y1;

      // for now, no colors are used in the final dcc
      for (i=0; i < 256; i++)
         tmpcell.dir->cells_color_used[i] = FALSE;

      // for all cells
      done = FALSE;
      do
      {
         // modify cell width if needed (no last cell of 1 pixel width)
         if ((cfx + tmpcell.w) == ibox->x2)
            tmpcell.w++;

         // modify cell height if needed (no last cell of 1 pixel height)
         if ((cfy + tmpcell.h) == ibox->y2)
            tmpcell.h++;

         // get temporary new line pointer
         for (y=0; y < tmpcell.h; y++)
            tmpcell.line[y] = tmpcell.frm->line[cfy + y] + cfx;

         // count how many different dcc colors are in the cell
         for (i=0; i < 256; i++)
            color_present[i] = 0;
         for (y=0; y < tmpcell.h; y++)
         {
            for (x=0; x < tmpcell.w; x++)
            {
               n = tmpcell.line[y][x];
               color_present[ anim->img2dcc_cmap[n] ] = 1;
            }
         }
         n = 0;
         for (i=0; i < 256; i++)
         {
            if (color_present[i] != 0)
               n++;
         }

         // do the most appropriate cell processing, according to number of colors
         if (n <= 4)
         {
            // these 'n' colors are used
            for (i=0; i < 256; i++)
            {
               if (color_present[i] != 0)
                  tmpcell.dir->cells_color_used[i] = TRUE;
            }

            // quick and simple remaping of the cell pixels
            for (y=0; y < tmpcell.h; y++)
            {
               for (x=0; x < tmpcell.w; x++)
               {
                  n = tmpcell.line[y][x];
                  tmpcell.line[y][x] = anim->img2dcc_cmap[n];
               }
            }
         }
         else
         {
            // let's go for the average method

            // try to make maximum final colors

            if (color_present[0] == 0)
            {
               // this cell don't use transparency, max 4 free slots
               min = (WORD) (n < 4 ? n : 4);
            }
            else
            {
               // this cell use transparent pixel(s), only 3 free slots max
               min = (WORD) (n < 3 ? n : 3);
            }

            min_err_ratio = (UDWORD) -1;
            n             = (WORD) (tmpcell.w * tmpcell.h);
            nb_saved      = 0;

            cell_color_saved[0] = 0;
            cell_color_saved[1] = 0;
            cell_color_saved[2] = 0;
            cell_color_saved[3] = 0;

            // we'll do all possible divisions of the colors, and
            // keep the best resulting cell colors
            for (i = min; i < n; i++)
            {
               tmpcell.color[0] = 0;
               tmpcell.color[1] = 0;
               tmpcell.color[2] = 0;
               tmpcell.color[3] = 0;

               // divide these R G B componants tables into 'i' colors
               // and get how many final dcc color they represent
               y = psdccen_cell_avg_colors( & tmpcell, i);

               // according to that number of dcc colors...
               if (y == -1)
               {
                  // error, stop the loop
                  i = n;
               }
               else
               {
                  // compute a cell error ratio, due to color replacment
                  curr_err_ratio = psdccen_cell_error_ratio( & tmpcell);

                  // if that cell has a lower error ratio with these colors, keep them
                  if (curr_err_ratio < min_err_ratio)
                  {
                     min_err_ratio = curr_err_ratio;
                     for (x=0; x < y; x++)
                     {
                        cell_color_saved[x] = tmpcell.color[x];
                     }
                     nb_saved = (UBYTE) y;
                  }
               }
            }

            // restore the best colors found
            for (x=0; x < 4; x++)
            {
               tmpcell.color[x] = cell_color_saved[x];
            }
            tmpcell.nb_colors = nb_saved;

            // remap all cell pixels
            psdccen_remap_cell( & tmpcell);
         }

         // next cell
         // first, go into next cell column
         cfx += tmpcell.w;
         if (cfx > ibox->x2)
         {
            // start of next cell row
            cfx = ibox->x1;
            cfy += tmpcell.h;
            if (cfy > ibox->y2)
               done = TRUE; // all cells of that frame have been processed
            else
            {
               if (ibox->y2 + 1 - cfy >= 4)
                  tmpcell.h = 4;
               else
                  tmpcell.h = ibox->y2 + 1 - cfy;
            }
         }
         if (ibox->x2 + 1 - cfx >= 4)
            tmpcell.w = 4;
         else
            tmpcell.w = ibox->x2 + 1 - cfx;
      } while ( ! done);

      // remap pixels that are out of the smallest img (if any) to dcc transparency
      if (ibox->x1 || ibox->y1 || (ibox->x2 != fbox->x2) || (ibox->y2 != fbox->y2))
      {
         for (y=0; y < ibox->y1; y++)
         {
            for (x=0; x < (DWORD) tmpcell.frm->width; x++)
               tmpcell.frm->line[y][x] = 0;
         }
         for (y = ibox->y2 + 1; y < (DWORD) tmpcell.frm->height; y++)
         {
            for (x=0; x < (DWORD) tmpcell.frm->width; x++)
               tmpcell.frm->line[y][x] = 0;
         }
         for (y = ibox->y1; y <= ibox->y2; y++)
         {
            for (x=0; x < ibox->x1; x++)
               tmpcell.frm->line[y][x] = 0;
            for (x = ibox->x2 + 1; x < (DWORD) tmpcell.frm->width; x++)
               tmpcell.frm->line[y][x] = 0;
         }
      }
   }

printf("\nColors used in direction :");
for (i=0; i < 256; i++)
{
   if ((i % 16) == 0)
      printf("\n   ");
   if (tmpcell.dir->cells_color_used[i] != FALSE)
      printf(" %03i", i);
   else
      printf(" ...");
}
printf("\n");

   //end
   return 0;
}
