#ifndef _PSDCCEN_H_

#define _PSDCCEN_H_


// global defines
// ==============
#define PSDCCEN_DIR_MAX          32
#define PSDCCEN_FRM_PER_DIR_MAX 256



// dcc encoding structures
// =======================

// position of upper/left and lower/right corners of a rectangle,
// and its dimensions, all in pixels
// --------------------------------------------------------------
typedef struct
{
   DWORD  x1, y1; // upper/left  corner
   DWORD  x2, y2; // lower/right corner
   UDWORD w, h;   // w = x2 - x1 + 1, h = y2 - y1 + 1
} PSDCCENBOX_S;


// datas for 1 frame
// -----------------
typedef struct
{
   // required by the dcc encoder
   UDWORD width, height;      // dimensions in pixels
   UBYTE  ** line;            // pointer to a table of pointer to the start of each line
   DWORD  offset_x, offset_y; // image offset to place it from the sprite pivot

   // filled by the dcc encoder
   PSDCCENBOX_S frmbox; // entire frame space position / dimensions
   PSDCCENBOX_S imgbox; // image within the frame, without borders
} PSDCCENFRM_S;


// datas for 1 direction
// ---------------------
typedef struct
{
   // required by the dcc encoder
   PSDCCENFRM_S * frame; // pointer to a table of frame

   // filled by the dcc encoder
   PSDCCENBOX_S dirbox;                // space position / dimensions of all smallest direction images
   BYTE         cells_color_used[256]; // to know which colors are used in that direction
                                       // (boolean FALSE / TRUE)
} PSDCCENDIR_S;


// 1 palette entry (1 color componants)
// all componants are expected to range from 0 to 255
// --------------------------------------------------
typedef struct
{
   UBYTE r; // red
   UBYTE g; // green
   UBYTE b; // blue
} PSDCCENCOLOR_S;


// palette (256 colors)
// --------------------
typedef PSDCCENCOLOR_S  PSDCCPALETTE_S[256];


// lookup tables for speeding up nearest color matching formulas
// -------------------------------------------------------------
typedef UDWORD          PSDCCDISTLINE_S[256];
typedef PSDCCDISTLINE_S PSDCCDIST_S[256];
typedef struct
{
   PSDCCDIST_S r;
   PSDCCDIST_S g;
   PSDCCDIST_S b;
} PSDCCDISTRGB_S;


// datas for 1 animation
// ---------------------
typedef struct
{
   // required by the dcc encoder
   UDWORD         nb_dir;            // nb directions
   UDWORD         nb_frm_per_dir;    // nb frames per direction
   PSDCCENDIR_S   * direction;       // pointer to a table of direction

   PSDCCPALETTE_S img_palette;       // original image palette
   WORD           bg_idx;            // palette index that is the original background

   PSDCCPALETTE_S dcc_palette;       // palette the final dcc must use
   UBYTE          color_to_use[256]; // which color index are really to use ?
                                     // (0 = don't use, non-zero = can be used)

   // filled by the dcc encoder
   PSDCCENBOX_S   animbox;                   // space position / dimensions of all smallest animation images
   PSDCCDISTRGB_S dist;                      // lookup tables for speeding up AVG formulas
   UDWORD         img2dccdist[256][256];     // lookup tables for speeding up NEAR 4 COLOR formulas
   UDWORD         img2dccerrratio[256][256]; // lookup tables for speeding up NEAR 4 COLOR formulas
   UBYTE          img2dcc_cmap[256];         // how to map all image colors to dcc colors
} PSDCCENANIM_S;


// temporary datas of 1 frame-cell, during dithering processing
// ------------------------------------------------------------
typedef struct
{
   PSDCCENANIM_S * anim;
   PSDCCENDIR_S  * dir;
   PSDCCENFRM_S  * frm;
   DWORD         w, h;
   UBYTE         * line[5];
   UBYTE         color[4];
   WORD          nb_colors;
} PSDCCENTMPCELL_S;




// dcc encoding functions prototypes
// =================================

WORD psdccen_init_box         (PSDCCENBOX_S * box);
WORD psdccen_smallest_img     (PSDCCENANIM_S * anim, PSDCCENFRM_S * frm);
WORD psdccen_find_boxes       (PSDCCENANIM_S * anim);
WORD psdccen_dither_direction (PSDCCENANIM_S * anim, UDWORD dir_num);
WORD psdccen_map_img2dcc      (PSDCCENANIM_S * anim);



#endif
