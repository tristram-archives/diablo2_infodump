#include <stdio.h>
#include <string.h>

#include "pstypes.h"
#include "ps_bitstream\psbitstr.h"
#include "ps_dcc_encode\psdccen.h"

#define USE_CONSOLE
#include <allegro.h>

#include "gif\defs.h"
#include "gif\gif.h"

// Disable warning message "unreferenced inline function has been removed"
#pragma warning(disable : 4514)


GIF_ANIM_S * load_gif    (char * gif_name);
void         destroy_gif (GIF_ANIM_S * g);

PSDCCENANIM_S anim;

   
volatile UDWORD counter = 0;
void my_timer_handler(void)
{
   counter++;
}
END_OF_FUNCTION(my_timer_handler)


// =======================================================================
// entry point of the program
// =======================================================================
void main(int argc, char ** argv)
{
   PSBITSTR_S        * bitstr_ptr;
   char              string[] = "<Test string>";
   int               length, ret = 0, do_timing = TRUE;
   int               v[4] = {2, 4, 1, 30}, i, c, nb;
   UDWORD            bs_length, my_counter;
   UBYTE             f0bmp[6][4] =
                     {
                        {0, 0, 0, 0},
                        {0, 1, 0, 0},
                        {0, 1, 0, 0},
                        {0, 2, 2, 0},
                        {0, 0, 0, 0},
                        {0, 0, 0, 0}
                     },
                     f2bmp[5][3] =
                     {
                        {0, 5, 0},
                        {5, 5, 5},
                        {0, 5, 0},
                        {0, 5, 0},
                        {0, 5, 0}
                     },
                     f3bmp[2][2] =
                     {
                        {  0, 0},
                        {254, 0}
                     },
                     * f0lineptr[6],
                     * f2lineptr[5],
                     * f3lineptr[2];
   PSDCCENDIR_S  dir[1];
   PSDCCENFRM_S  frm[13];

   BITMAP     * bmp;
   PALETTE    pal, paldcc;

   GIF_ANIM_S * gif_anim;
   char       strtmp[50];


   printf("sizeof(PSDCCENANIM_S) = %i bytes = %i KB = %i MB\n",
           sizeof(PSDCCENANIM_S),
           sizeof(PSDCCENANIM_S) / 1024,
           sizeof(PSDCCENANIM_S) / 1024 / 1024
   );
   fflush(stdout);

   // ----------------------------
   // test : bitstreams
   // ----------------------------
   bitstr_ptr = psbitstrm_new(PSBITSTR_GRANULARITY_MIN);
   if (bitstr_ptr == NULL)
   {
      printf("can't create a new bitstream buffer\n");
      fflush(stdout);
   }
   else
   {
      // creation was ok
      printf("creation of a new bitstream buffer : sucess\n");
      fflush(stdout);

      // write some chars
      length = strlen(string);

      ret = psbitstrm_write(bitstr_ptr, length*8, string);
      if (ret != 0)
      {
         printf("couldn't write %i bits\n", length*8);
         fflush(stdout);
      }

      // write 3 variable bits values
      ret = psbitstrm_write(bitstr_ptr, 2, & v[0]);
      if (ret != 0)
      {
         printf("couldn't write %i bits\n", 2);
         fflush(stdout);
      }

      ret = psbitstrm_write(bitstr_ptr, 3, & v[1]);
      if (ret != 0)
      {
         printf("couldn't write %i bits\n", 3);
         fflush(stdout);
      }

      ret = psbitstrm_write(bitstr_ptr, 2, & v[2]);
      if (ret != 0)
      {
         printf("couldn't write %i bits\n", 2);
         fflush(stdout);
      }

      ret = psbitstrm_write(bitstr_ptr, 5, & v[3]);
      if (ret != 0)
      {
         printf("couldn't write %i bits\n", 5);
         fflush(stdout);
      }

      for (i=0; i < length + 2; i++)
      {
         printf("   %2i : 0x%02X ('%c')\n",
            i,
            bitstr_ptr->first_elm->buffer[i],
            bitstr_ptr->first_elm->buffer[i]
         );
         fflush(stdout);
      }

      // read the bits
      printf("\nNow using the read functions\n");
      fflush(stdout);

      bs_length = psbitstrm_size(bitstr_ptr);
      if (bs_length == -1)
      {
         printf("error while trying to get the bitstream size\n");
         fflush(stdout);
      }
      else
      {
         printf("length of bitstream = %lu bits (%lu bytes and %lu bits = %lu bytes)\n\n",
            bs_length,
            bs_length / 8,
            bs_length % 8,
            bs_length % 8 ? bs_length / 8 + 1 : bs_length / 8
         );

         // get the characters
         for (i=0; i < length; i++)
         {
            if (psbitstrm_read(bitstr_ptr, 8, & c, sizeof(c)) != 0)
            {
               printf("   can't read 8 bits\n");
               fflush(stdout);
            }
            else
            {
               printf("   %i bits : 0x%02X ('%c')\n", 8, c, c);
               fflush(stdout);
            }
         }

         // get X bits
         nb = 0;
         for (i=0; i < 4; i++)
         {
            switch (i)
            {
               case 0 : nb = 2; break;
               case 1 : nb = 3; break;
               case 2 : nb = 2; break;
               case 3 : nb = 5; break;
            }

            if (psbitstrm_read(bitstr_ptr, nb, & c, sizeof(c)) != 0)
            {
               printf("   can't read %i bits\n", nb);
               fflush(stdout);
            }
            else
            {
               printf("   %i bits : 0x%02X (%3i)\n", nb, c, c);
               fflush(stdout);
            }
         }
      }

      // delete bitstream from mem
      printf("removing bitstream from memory...");
      fflush(stdout);

      if (psbitstrm_delete(bitstr_ptr) != 0)
         printf("error\n");
      else
         printf("ok\n");

      // ----------------------------
      // new test : dithering
      // ----------------------------
      memset( & anim, 0, sizeof(PSDCCENANIM_S));
      memset( & dir,  0, sizeof(PSDCCENDIR_S));
      memset( & frm,  0, sizeof(PSDCCENFRM_S));

      f0lineptr[0] = f0bmp[0];
      f0lineptr[1] = f0bmp[1];
      f0lineptr[2] = f0bmp[2];
      f0lineptr[3] = f0bmp[3];
      f0lineptr[4] = f0bmp[4];
      f0lineptr[5] = f0bmp[5];

      f2lineptr[0] = f2bmp[0];
      f2lineptr[1] = f2bmp[1];
      f2lineptr[2] = f2bmp[2];
      f2lineptr[3] = f2bmp[3];
      f2lineptr[4] = f2bmp[4];

      f3lineptr[0] = f3bmp[0];
      f3lineptr[1] = f3bmp[1];

      anim.nb_dir         = 1;
      anim.nb_frm_per_dir = 4;
      anim.direction      = dir;

      dir[0].frame = frm;

      frm[0].width    = 4;
      frm[0].height   = 6;
      frm[0].line     = f0lineptr;
      frm[0].offset_x = -3;
      frm[0].offset_y = -9;

      frm[1].width    = 0;
      frm[1].height   = 0;
      frm[1].line     = NULL;
      frm[1].offset_x = 0;
      frm[1].offset_y = 0;

      frm[2].width    = 3;
      frm[2].height   = 5;
      frm[2].line     = f2lineptr;
      frm[2].offset_x = -1;
      frm[2].offset_y = -6;

      frm[3].width    = 2;
      frm[3].height   = 2;
      frm[3].line     = f3lineptr;
      frm[3].offset_x = 3;
      frm[3].offset_y = 2;

      printf("\ntrying to process an animation...");
      fflush(stdout);

      if (psdccen_find_boxes( & anim) != 0)
         printf("error\n");
      else
         printf("ok\n");

      for (i=0; i < 4; i++)
      {
         printf("\nframe[%i] :\n", i);
         printf("   * frmbox.x1 = %li\n", anim.direction[0].frame[i].frmbox.x1);
         printf("   * frmbox.y1 = %li\n", anim.direction[0].frame[i].frmbox.y1);
         printf("   * frmbox.x2 = %li\n", anim.direction[0].frame[i].frmbox.x2);
         printf("   * frmbox.y2 = %li\n", anim.direction[0].frame[i].frmbox.y2);
         printf("   * frmbox.w  = %lu\n", anim.direction[0].frame[i].frmbox.w);
         printf("   * frmbox.h  = %lu\n", anim.direction[0].frame[i].frmbox.h);
         printf("\n");
         printf("   * imgbox.x1 = %li\n", anim.direction[0].frame[i].imgbox.x1);
         printf("   * imgbox.y1 = %li\n", anim.direction[0].frame[i].imgbox.y1);
         printf("   * imgbox.x2 = %li\n", anim.direction[0].frame[i].imgbox.x2);
         printf("   * imgbox.y2 = %li\n", anim.direction[0].frame[i].imgbox.y2);
         printf("   * imgbox.w  = %lu\n", anim.direction[0].frame[i].imgbox.w);
         printf("   * imgbox.h  = %lu\n", anim.direction[0].frame[i].imgbox.h);
      }
      printf("\ndirection:\n", i);
      printf("   * dirbox.x1 = %li\n", anim.direction[0].dirbox.x1);
      printf("   * dirbox.y1 = %li\n", anim.direction[0].dirbox.y1);
      printf("   * dirbox.x2 = %li\n", anim.direction[0].dirbox.x2);
      printf("   * dirbox.y2 = %li\n", anim.direction[0].dirbox.y2);
      printf("   * dirbox.w  = %lu\n", anim.direction[0].dirbox.w);
      printf("   * dirbox.h  = %lu\n", anim.direction[0].dirbox.h);
      printf("\nanimation:\n", i);
      printf("   * animbox.x1 = %li\n", anim.animbox.x1);
      printf("   * animbox.y1 = %li\n", anim.animbox.y1);
      printf("   * animbox.x2 = %li\n", anim.animbox.x2);
      printf("   * animbox.y2 = %li\n", anim.animbox.y2);
      printf("   * animbox.w  = %lu\n", anim.animbox.w);
      printf("   * animbox.h  = %lu\n", anim.animbox.h);

      // test with img
      // =============
      allegro_init();
      install_timer();
      LOCK_VARIABLE(counter);
      LOCK_FUNCTION(my_timer_handler);
      if (install_int(my_timer_handler, 10) < 0)
      {
         printf("warning : installation of timer failed, timing disable\n");
         do_timing = FALSE;
      }

      bmp = load_pcx("pal.pcx", paldcc);
      if (bmp == NULL)
      {
         printf("can't load \"pal.pcx\"\n");
            return;
      }
      destroy_bitmap(bmp);

      bmp = load_pcx("testimg.pcx", pal);
      if (bmp == NULL)
      {
         printf("can't load \"testimg.pcx\"\n");
            return;
      }

      memset( & anim, 0, sizeof(anim));

      anim.nb_dir = 1;
      anim.nb_frm_per_dir = 1;
      anim.direction = dir;
      for (i=0; i < 256; i++)
      {
         anim.img_palette[i].r = pal[i].r << 2;
         anim.img_palette[i].g = pal[i].g << 2;
         anim.img_palette[i].b = pal[i].b << 2;

         anim.dcc_palette[i].r = paldcc[i].r << 2;
         anim.dcc_palette[i].g = paldcc[i].g << 2;
         anim.dcc_palette[i].b = paldcc[i].b << 2;
      }

      anim.bg_idx = -1;
      if (argc == 2)
         anim.bg_idx = atoi(argv[1]);

      dir[0].frame = frm;

      frm[0].width    = bmp->w;
      frm[0].height   = bmp->h;
      frm[0].line     = bmp->line;
      frm[0].offset_x = 0;
      frm[0].offset_y = 0;

      for (i=0; i < 256; i++)
         anim.color_to_use[i] = 1;
      // no act-dependant colors
      for (i=225; i <= 254; i++)
         anim.color_to_use[i] = 0;

      if (psdccen_find_boxes( & anim) != 0)
      {
         destroy_bitmap(bmp);
         printf("error in psdccen_find_boxes()\n");
         return;
      }

      if (psdccen_map_img2dcc( & anim) != 0)
      {
         destroy_bitmap(bmp);
         printf("error in psdccen_map_img2dcc()\n");
         return;
      }

      counter = 0;
      if (psdccen_dither_direction( & anim, 0) != 0)
      {
         destroy_bitmap(bmp);
         printf("error in psdccen_dither_direction()\n");
         return;
      }
      if (do_timing == TRUE)
      {
         my_counter = counter;
         printf("timing of dithering = %lu 1/100th of a second = %lu seconds\n",
            my_counter,
            my_counter / 100LU
         );
         fprintf(stderr, "timing of dithering = %lu 1/100th of a second = %lu seconds\n",
            my_counter,
            my_counter / 100LU
         );
      }

      save_pcx("dcc_dithering.pcx", bmp, paldcc);

      destroy_bitmap(bmp);

      // test with gif
      // =============
      gif_anim = load_gif("red_drg.gif");
      if (gif_anim == NULL)
         return;
      else
         printf("dcc dithering the gif\n");
      fflush(stdout);
      fflush(stderr);

      anim.nb_dir = 1;
      anim.nb_frm_per_dir = gif_anim->num_frames;
      anim.direction = dir;
      for (i=0; i < 256; i++)
      {
         anim.img_palette[i].r = gif_anim->palette[0][i].r << 2;
         anim.img_palette[i].g = gif_anim->palette[0][i].g << 2;
         anim.img_palette[i].b = gif_anim->palette[0][i].b << 2;

         anim.dcc_palette[i].r = paldcc[i].r << 2;
         anim.dcc_palette[i].g = paldcc[i].g << 2;
         anim.dcc_palette[i].b = paldcc[i].b << 2;
      }

      anim.bg_idx = 251;

      dir[0].frame = frm;
      for (i=0; i < 13; i++)
      {
         frm[i].width    = gif_anim->frame[i].bmp->w;
         frm[i].height   = gif_anim->frame[i].bmp->h;
         frm[i].line     = gif_anim->frame[i].bmp->line;
         frm[i].offset_x = 0;
         frm[i].offset_y = 0;
      }


      for (i=0; i < 256; i++)
         anim.color_to_use[i] = 1;

      // no act-dependant colors
      for (i=225; i <= 254; i++)
         anim.color_to_use[i] = 0;

      if (psdccen_find_boxes( & anim) != 0)
      {
         printf("error in psdccen_find_boxes()\n");
         return;
      }

      for (c=0; c<256; c++)
      {
         anim.img_palette[c].r = gif_anim->palette[0][c].r;
         anim.img_palette[c].g = gif_anim->palette[0][c].g;
         anim.img_palette[c].b = gif_anim->palette[0][c].b;
      }

      if (psdccen_map_img2dcc( & anim) != 0)
      {
         printf("error in psdccen_map_img2dcc()\n");
         return;
      }

      counter = 0;
      if (psdccen_dither_direction( & anim, 0) != 0)
      {
         printf("error in psdccen_dither_direction()\n");
         return;
      }
      my_counter = counter;
      if (do_timing == TRUE)
      {
         printf("timing of dithering = %lu 1/100th of a second = %lu seconds\n",
            my_counter,
            my_counter / 100LU
         );
         fprintf(stderr, "timing of dithering = %lu 1/100th of a second = %lu seconds\n",
            my_counter,
            my_counter / 100LU
         );
      }
      for (i=0; i < 13; i++)
      {
         sprintf(strtmp, "gif_dithered_frame%02i.pcx", i);
         save_pcx(strtmp, gif_anim->frame[i].bmp, paldcc);
      }

      destroy_gif(gif_anim);

      // end
      fflush(stdout);
   }
}
END_OF_MAIN();
