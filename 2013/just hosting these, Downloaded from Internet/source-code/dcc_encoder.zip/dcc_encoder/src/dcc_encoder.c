#include <stdio.h>
#include <string.h>

#include "pstypes.h"
#include "ps_bitstream\psbitstr.h"
#include "ps_dcc_encode\psdccen.h"

#define USE_CONSOLE
#include <allegro.h>

#include "gif\defs.h"
#include "gif\gif.h"


// Disable warning message "unreferenced inline function has been removed"
#pragma warning(disable : 4514)


// global datas
PSDCCENANIM_S   anim;
volatile UDWORD counter = 0;


// just for timing dithering time
void my_timer_handler(void)
{
   counter++;
}
END_OF_FUNCTION(my_timer_handler)


// =======================================================================
// entry point of the program
// =======================================================================
void main(int argc, char ** argv)
{
   int    i, c;
   UDWORD my_counter;
   PSDCCENDIR_S  dir[1];
   PSDCCENFRM_S  * frm;

   BITMAP     * bmp;
   PALETTE    paldcc;

   GIF_ANIM_S * gif_anim;
   char       strtmp[80];

   if (argc < 2)
   {
      printf("syntaxe : dcc_encoder.exe <file.gif>\n");
      return;
   }

   allegro_init();
   install_timer();
   LOCK_VARIABLE(counter);
   LOCK_FUNCTION(my_timer_handler);
   install_int(my_timer_handler, 10);

   bmp = load_pcx("pal.pcx", paldcc);
   if (bmp == NULL)
   {
      printf("can't load \"pal.pcx\"\n");
         return;
   }
   destroy_bitmap(bmp);

   gif_anim = load_gif(argv[1]);
   if (gif_anim == NULL)
      return;
   else
      printf("\ndcc dithering the gif <%s>\n", argv[1]);
   fflush(stdout);
   fflush(stderr);

   anim.nb_dir = 1;
   anim.nb_frm_per_dir = gif_anim->num_frames;
   anim.direction = dir;
   for (i=0; i < 256; i++)
   {
      anim.img_palette[i].r = gif_anim->palette[0][i].r << 2;
      anim.img_palette[i].g = gif_anim->palette[0][i].g << 2;
      anim.img_palette[i].b = gif_anim->palette[0][i].b << 2;

      anim.dcc_palette[i].r = paldcc[i].r << 2;
      anim.dcc_palette[i].g = paldcc[i].g << 2;
      anim.dcc_palette[i].b = paldcc[i].b << 2;
   }

   if (argc == 3)
      anim.bg_idx = atoi(argv[2]);
   else
      anim.bg_idx = -1;

   frm = (PSDCCENFRM_S *) malloc(sizeof(PSDCCENFRM_S) * gif_anim->num_frames);
   if (frm == NULL)
   {
      printf("can't allocate enough memory for %i frames\n", gif_anim->num_frames);
      return;
   }
   dir[0].frame = frm;
   for (i=0; i < gif_anim->num_frames; i++)
   {
      frm[i].width    = gif_anim->frame[i].bmp->w;
      frm[i].height   = gif_anim->frame[i].bmp->h;
      frm[i].line     = gif_anim->frame[i].bmp->line;
      frm[i].offset_x = 0;
      frm[i].offset_y = 0;
   }


   for (i=0; i < 256; i++)
      anim.color_to_use[i] = 1;

   // no act-dependant color
   for (i=225; i <= 254; i++)
      anim.color_to_use[i] = 0;

   if (psdccen_find_boxes( & anim) != 0)
   {
      free(frm);
      printf("error in psdccen_find_boxes()\n");
      return;
   }

   for (c=0; c<256; c++)
   {
      anim.img_palette[c].r = gif_anim->palette[0][c].r;
      anim.img_palette[c].g = gif_anim->palette[0][c].g;
      anim.img_palette[c].b = gif_anim->palette[0][c].b;
   }

   if (psdccen_map_img2dcc( & anim) != 0)
   {
      free(frm);
      printf("error in psdccen_map_img2dcc()\n");
      return;
   }

   counter = 0;
   if (psdccen_dither_direction( & anim, 0) != 0)
   {
      free(frm);
      printf("error in psdccen_dither_direction()\n");
      return;
   }
   my_counter = counter;
   printf("timing of dithering = %lu 1/100th of a second = %lu seconds\n",
      my_counter,
      my_counter / 100LU
   );
   fprintf(stderr, "timing of dithering = %lu 1/100th of a second = %lu seconds\n",
      my_counter,
      my_counter / 100LU
   );
   for (i=0; i < gif_anim->num_frames; i++)
   {
      sprintf(strtmp, "gif_frame%03i.pcx", i);
      save_pcx(strtmp, gif_anim->frame[i].bmp, paldcc);
   }

   destroy_gif(gif_anim);

   // end
   free(frm);
   fflush(stdout);
}
END_OF_MAIN();
