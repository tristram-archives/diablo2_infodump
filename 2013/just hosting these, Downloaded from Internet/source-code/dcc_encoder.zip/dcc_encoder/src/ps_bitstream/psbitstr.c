
#include <stdlib.h>
#include <string.h>

#include "..\pstypes.h"
#include "psbitstr.h"


/* ===========================================================================
   psbitstrm_size()

   tell which is the size of the bitstream datas, in number of BITS

   input :
      - pointer to a bitstream

   output :
      if error : (UDWORD) -1
      if ok    : number of (filled) bits
============================================================================== */
UDWORD psbitstrm_size(PSBITSTR_S * bitstr_ptr)
{
   PSBITSTR_ELM_S * elm;
   UDWORD         size, temp_new_size;


   size = 0;
   elm  = bitstr_ptr->first_elm;
   while (elm != NULL)
   {
      if (elm->filled_bits != 0)
      {
         temp_new_size = size + elm->filled_bits;
         if (temp_new_size <= size) // overflow detected
            return (UDWORD) -1;
         else if (temp_new_size == (UDWORD) -1) // reserved value
            return (UDWORD) -1;
         else
            size = temp_new_size; // ok
      }
      elm = elm->next;
   }

   return size;
}
      

/* ===========================================================================
   psbitstrm_tell()

   tell which is the BIT position of a bitstream cursor

   input :
      - pointer to a bitstream
      - cursor type (READ or WRITE)

   output :
      if error : (UDWORD) -1
      if ok    : bit position of the bitstream cursor
============================================================================== */
UDWORD psbitstrm_tell(PSBITSTR_S * bitstr_ptr, PS_BCT_E cursor_type)
{
   PSBITSTR_CURSOR_S * cursor = NULL;
   PSBITSTR_ELM_S    * elm;
   UDWORD            pos, temp_new_pos;


   switch(cursor_type)
   {
      case READ :
         cursor = & bitstr_ptr->cursor_read;
         break;

      case WRITE :
         cursor = & bitstr_ptr->cursor_write;
         break;
   }

   if (cursor == NULL)
      return (UDWORD) -1;

   pos = 0;
   elm = bitstr_ptr->first_elm;
   while (elm != cursor->elm)
   {
      if (elm->filled_bits != 0)
      {
         temp_new_pos = pos + elm->filled_bits;
         if (temp_new_pos <= pos) // overflow detected
            return (UDWORD) -1;
         else if (temp_new_pos == (UDWORD) -1) // reserved value
            return (UDWORD) -1;
         else
            pos = temp_new_pos; // ok
      }
      elm = elm->next;
   }

   if ((cursor->curr_byte != 0) && (cursor->curr_bit != 0))
   {
      temp_new_pos = pos + cursor->curr_byte * 8 + cursor->curr_bit;
      if (temp_new_pos <= pos) // overflow detected
         return (UDWORD) -1;
      else if (temp_new_pos == (UDWORD) -1) // reserved value
         return (UDWORD) -1;
      else
         pos = temp_new_pos; // ok
   }

   return pos;
}


/* ===========================================================================
   psbitstrm_seek()

   set a bitstream cursor position to a specified BIT position
   (from the start)

   input :
      - pointer to a bitstream
      - cursor type (READ or WRITE)
      - desired bit position (within the entire bitstream)

   output :
      0        = ok
      non-zero = error
============================================================================== */
WORD psbitstrm_seek(PSBITSTR_S * bitstr_ptr, PS_BCT_E cursor_type, UDWORD wanted_pos)
{
   PSBITSTR_CURSOR_S * cursor = NULL;
   PSBITSTR_ELM_S    * elm;
   UDWORD            pos, temp_new_pos = 0, i;
   WORD              done = FALSE;


   if (wanted_pos == (UDWORD) -1)
      return -1;

   switch(cursor_type)
   {
      case READ :
         cursor = & bitstr_ptr->cursor_read;
         break;

      case WRITE :
         cursor = & bitstr_ptr->cursor_write;
         break;
   }

   if (cursor == NULL)
      return -1;

   pos = 0;
   elm = bitstr_ptr->first_elm;
   while ( ! done)
   {
      if (elm == NULL)
         return -1;
      else
      {
         if (elm->filled_bits != 0)
         {
            temp_new_pos = pos + elm->filled_bits;
            if (temp_new_pos <= pos) // overflow detected
               return -1;
            else if (temp_new_pos == (UDWORD) -1) // reserved value
               return -1;
         }

         if (temp_new_pos < wanted_pos)
         {
            pos = temp_new_pos;
            elm = elm->next;
         }
         else
         {
            cursor->elm       = elm;
            i                 = wanted_pos - pos;
            cursor->curr_byte = i / 8;
            cursor->curr_bit  = (WORD) (i % 8);
            done = TRUE;
         }
      }
   }

   // end
   return 0;
}


/* ===========================================================================
   psbitstrm_write()

   write bits to a bitstream
   yes, it's NOT optimized, but it's simple and it works

   input :
      - pointer to a bitstream
      - number of bits to write
      - pointer to the data from where to take the bits values

   output :
      0        = ok
      non-zero = error
============================================================================== */
WORD psbitstrm_write(PSBITSTR_S * bitstr_ptr, UDWORD nb_bit, void * data)
{
   PSBITSTR_ELM_S    * new_elm;
   PSBITSTR_CURSOR_S * cursor;
   UBYTE             * src_byte_ptr, * dst_byte_ptr;
   WORD              size, data_bit = 0;
   UDWORD            i, nb_filled_bits;


   if (nb_bit == 0) // nothing to do
      return 0;

   if (bitstr_ptr == NULL)
      return -1;

   if (nb_bit == (UDWORD) -1) // reserved value
      return -1;

   cursor = & bitstr_ptr->cursor_write;

   if (cursor->elm == NULL)
      return -1;

   if (cursor->elm->buffer == NULL)
      return -1;

   src_byte_ptr = (UBYTE *) data;
   dst_byte_ptr = cursor->elm->buffer + cursor->curr_byte;

   // for all bits, one by one
   for (i=0; i < nb_bit; i++)
   {
      // do we need to jump to another buffer ?
      if (cursor->curr_byte >= cursor->elm->length_byte)
      {
         // yes, but now do we need to *create* a new buffer ?
         if (cursor->elm->next == NULL)
         {
            // yes, create a new buffer
            size    = sizeof(PSBITSTR_ELM_S);
            new_elm = (PSBITSTR_ELM_S *) malloc(size);
            if (new_elm == NULL)
               return -1;
            memset(new_elm, 0, size);

            // allocate the BUFFER of this bitstream element
            new_elm->buffer = (UBYTE *) malloc(bitstr_ptr->granularity);
            if (new_elm->buffer == NULL)
            {
               free(new_elm);
               return -1;
            }
            memset(new_elm->buffer, 0, size);

            // adjust datas
            cursor->elm->next    = new_elm;
            new_elm->length_byte = bitstr_ptr->granularity;
         }

         // adjust the cursor
         cursor->elm       = cursor->elm->next;
         cursor->curr_byte = 0;
         cursor->curr_bit  = 0;

         // adjust destination BYTE pointer
         dst_byte_ptr = cursor->elm->buffer;
      }

      // put the bit
      if ((* src_byte_ptr) & (1 << data_bit))
      {
         // put a 1
         (* dst_byte_ptr) |= (1 << cursor->curr_bit);
      }
      else
      {
         // put a 0
         (* dst_byte_ptr) &= ( ~ (1 << cursor->curr_bit) );
      }

      // adjust the cursor
      cursor->curr_bit++;
      if (cursor->curr_bit == 8)
      {
         cursor->curr_bit = 0;
         cursor->curr_byte++;
         dst_byte_ptr++;
      }

      // adjust the src bit position
      data_bit++;
      if (data_bit == 8)
      {
         data_bit = 0;
         src_byte_ptr++;
      }

      // adjust number of filled bits for this buffer
      nb_filled_bits = cursor->curr_bit + cursor->curr_byte * 8;
      if (nb_filled_bits > cursor->elm->filled_bits)
         cursor->elm->filled_bits = nb_filled_bits;
   }

   // end
   return 0;
}


/* ===========================================================================
   psbitstrm_read()

   read bits from a bitstream
   yes, it's NOT optimized, but it's simple and it works

   input :
      - pointer to a bitstream
      - nb bits to read
      - pointer to the data that will receive the bits
      - length in number of BYTES of the data

   output :
      0        = ok
      non-zero = error
============================================================================== */
WORD psbitstrm_read(PSBITSTR_S * bitstr_ptr, UDWORD nb_bit, void * data,
                   DWORD data_bytes_length)
{
   PSBITSTR_CURSOR_S * cursor;
   UBYTE             * src_byte_ptr, * dst_byte_ptr;
   WORD              data_bit = 0;
   UDWORD            i;
   DWORD             data_bytes_used = 0;

   
   if (nb_bit == 0) // nothing to do
      return 0;

   if (bitstr_ptr == NULL)
      return -1;

   if (nb_bit == (UDWORD) -1) // reserved value, avoid possible overflow error
      return -1;

   if (data_bytes_length < 1)
      return -1;

   // init all bits of the destination buffer to zero
   memset(data, 0, data_bytes_length);

   // some inits
   cursor = & bitstr_ptr->cursor_read;

   if (cursor->elm == NULL)
      return -1;

   if (cursor->elm->buffer == NULL)
      return -1;

   src_byte_ptr = cursor->elm->buffer + cursor->curr_byte;
   dst_byte_ptr = (UBYTE *) data;

   // for all bits, one by one
   for (i=0; i < nb_bit; i++)
   {
      // do we need to jump to another buffer ?
      if (cursor->curr_byte >= cursor->elm->length_byte)
      {
         // yes
         
         // adjust the cursor
         cursor->elm = cursor->elm->next;
         if (cursor->elm == NULL)
            return -1;

         cursor->curr_byte = 0;
         cursor->curr_bit  = 0;

         // adjust source BYTE pointer
         src_byte_ptr = cursor->elm->buffer;
         if (src_byte_ptr == NULL)
            return -1;
      }

      // put the bit
      if ((* src_byte_ptr) & (1 << cursor->curr_bit))
      {
         // put a 1
         (* dst_byte_ptr) |= (1 << data_bit);
      }
      else
      {
         // nothing to do since the destination buffer was memset() to zero
      }

      // adjust the cursor
      cursor->curr_bit++;
      if (cursor->curr_bit == 8)
      {
         cursor->curr_bit = 0;
         cursor->curr_byte++;
         src_byte_ptr++;
      }

      // adjust the dst bit position
      data_bit++;
      if (data_bit == 8)
      {
         data_bit = 0;
         dst_byte_ptr++;
         data_bytes_used++;
         if ((data_bytes_used >= data_bytes_length) && ((i + 1) < nb_bit))
            return -1;
      }
   }

   // end
   return 0;
}

   
/* ===========================================================================
   psbitstrm_delete()

   remove a bitstream from memory

   input :
      pointer to a bitstream

   output :
      0        = ok
      non-zero = error
============================================================================== */
WORD psbitstrm_delete(PSBITSTR_S * bitstr_ptr)
{
   PSBITSTR_ELM_S * elm, * next;

   
   if (bitstr_ptr == NULL)
      return -1;

   // remove all bitstream elements and their buffer
   elm = bitstr_ptr->first_elm;
   while (elm != NULL)
   {
      if (elm->buffer != NULL)
         free(elm->buffer);
      next = elm->next;
      free(elm);
      elm = next;
   }

   // remove the bitstream
   memset(bitstr_ptr, 0, sizeof(PSBITSTR_S));
   free(bitstr_ptr);

   // end
   return 0;
}


/* ===========================================================================
   psbitstrm_new()

   create a new bitstream

   input :
      granularity = number of BYTES of 1 buffer

   output :
      if ok    : pointer to a bitstream
                 (It's up to you to use psbitstrm_delete() to free the memory
                 it's using)

      if error : NULL
============================================================================== */
PSBITSTR_S * psbitstrm_new(UDWORD granularity)
{
   PSBITSTR_S     * bitstr_ptr;
   PSBITSTR_ELM_S * elm_ptr;
   WORD           size;


   // don't know why, but it crash during free() with VC6 if I use a granularity <= 8
   // for safety, let's use a higher minimum
   if (granularity < PSBITSTR_GRANULARITY_MIN)
      return NULL;

   // allocate a new main BITSTREAM structure
   size       = sizeof(PSBITSTR_S);
   bitstr_ptr = (PSBITSTR_S *) malloc(size);
   if (bitstr_ptr == NULL)
      return NULL;
   memset(bitstr_ptr, 0, size);

   // allocate the first BITSTREAM ELEMENT structure
   size    = sizeof(PSBITSTR_ELM_S);
   elm_ptr = (PSBITSTR_ELM_S *) malloc(size);
   if (elm_ptr == NULL)
   {
      free(bitstr_ptr);
      return NULL;
   }
   memset(elm_ptr, 0, size);

   // allocate the BUFFER of this bitstream element
   elm_ptr->buffer = (UBYTE *) malloc(granularity);
   if (elm_ptr->buffer == NULL)
   {
      free(elm_ptr);
      free(bitstr_ptr);
      return NULL;
   }
   memset(elm_ptr->buffer, 0, size);

   // init datas
   bitstr_ptr->first_elm        = elm_ptr;
   bitstr_ptr->granularity      = granularity;
   bitstr_ptr->cursor_read.elm  = elm_ptr;
   bitstr_ptr->cursor_write.elm = elm_ptr;

   elm_ptr->length_byte         = granularity;   

   // end
   return bitstr_ptr;
}
