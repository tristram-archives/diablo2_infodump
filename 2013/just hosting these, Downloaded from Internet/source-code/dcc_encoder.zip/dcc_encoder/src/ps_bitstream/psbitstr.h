#ifndef _PSBITSTR_H_

#define _PSBITSTR_H_


// global defines
// ==============
#define PSBITSTR_GRANULARITY_MIN 4096




// bitstreams structures
// =====================


// bitstream element
// -----------------
typedef struct PSBITSTR_ELM_S
{
   UBYTE                 * buffer;
   UDWORD                length_byte; // size of the buffer, in # of BYTE
   UDWORD                filled_bits; // actual # of BITS used in the buffer
   struct PSBITSTR_ELM_S * next;
} PSBITSTR_ELM_S;


// bitstream read/write cursor
// ---------------------------
typedef struct
{
   PSBITSTR_ELM_S * elm;
   UDWORD         curr_byte;
   WORD           curr_bit;
} PSBITSTR_CURSOR_S;


// bitstream
// ---------
typedef struct
{
   PSBITSTR_ELM_S    * first_elm;
   UDWORD            granularity; // size of each buffer allocated, in # of BYTES
   PSBITSTR_CURSOR_S cursor_read;
   PSBITSTR_CURSOR_S cursor_write;
} PSBITSTR_S;


// cursor types
// ------------
typedef enum {READ, WRITE} PS_BCT_E; // Bitstream Cursor Types Enumeration




// bitstream functions prototypes
// ==============================

UDWORD       psbitstrm_size   (PSBITSTR_S * bitstr_ptr);
UDWORD       psbitstrm_tell   (PSBITSTR_S * bitstr_ptr, PS_BCT_E cursor_type);
WORD         psbitstrm_seek   (PSBITSTR_S * bitstr_ptr, PS_BCT_E cursor_type, UDWORD wanted_pos);
WORD         psbitstrm_write  (PSBITSTR_S * bitstr_ptr, UDWORD nb_bit, void * data);
WORD         psbitstrm_read   (PSBITSTR_S * bitstr_ptr, UDWORD nb_bit, void * data, DWORD data_bytes_length);
WORD         psbitstrm_delete (PSBITSTR_S * bitstr_ptr);
PSBITSTR_S * psbitstrm_new    (UDWORD granularity);

#endif
