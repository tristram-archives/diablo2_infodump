#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define USE_CONSOLE
#include "allegro.h"

#define TILES_NUM_W      100
#define TILES_NUM_H      100
#define TILES_FLOORS_NUM   8
#define TILES_WALLS_NUM    6

#define SCR_W   640
#define SCR_H   480
#define SCR_BPP   8

volatile int glb_old_fps = 0, glb_fps = 0;

// 2 layers : 1 Floor & 1 Wall
char glb_tilemap [TILES_NUM_H] [TILES_NUM_W] [2];


// ==========================================================================
// 1 tick each second, to have a Frames Per Second count
void my_fps_counter(void)
{
   glb_old_fps = glb_fps;
   glb_fps = 0;
}
END_OF_FUNCTION(my_fps_counter);


// ==========================================================================
// ax & ay : absolute mouse coordinates
void mouse_to_tile(int * tx, int * ty, int ax, int ay, int tw, int th,
                   BITMAP * masks)
{
   int bx, by, cx, cy;

   // negative tile coordinates adjustment
   if (ax < 0) ax -= (tw - 1);
   if (ay < 0) ay -= (th - 1);

   // search the major tile's coordinates
   bx = ax / tw;
   by = ay / th;
   * tx = bx  + by;
   * ty = -bx + by;

   // fine adjustements
   cx = ax % tw;
   cy = ay % th;
   if (ax < 0) cx = (tw - 1) + cx;
   if (ay < 0) cy = (th - 1) + cy;
   
   switch (getpixel(masks, cx, cy))
   {
      case -1 : break; // shouldn't happen
      case  0 : break;
      case  1 : (* tx) --; break;
      case  2 : (* ty) --; break;
      case  3 : (* ty) ++; break;
      case  4 : (* tx) ++; break;
   }
}



// =========================================================================
void draw_screen(BITMAP * buffer,
                 BITMAP ** floors, BITMAP ** walls,
                 BITMAP * masks,
                 int pos_x, int pos_y, int tw, int th)
{
   int x, y, base_x, base_y, sx, sy, idx, tx, ty,
       htw = tw/2, hth = th/2, // half sizes of 1 tile
       dx, dy, x1, x2, x3, x4, y1, y2, y3;

   // clear the buffer
   clear(buffer);

   // draw tiles
   for (y=0; y<TILES_NUM_H; y++)
   {
      // screen coordinates of 1st tile of the current row
      base_x = y * -htw - pos_x;
      base_y = y * hth  - pos_y;
      
      // for each tiles of this row
      for (x=0; x<TILES_NUM_W; x++)
      {
         sx = base_x + x * htw;
         if ((sx >= - tw) && (sx < SCR_W))
         {
            // floor
            sy = base_y + x * hth;
            if ((sy >= - th) && (sy < SCR_H))
               draw_sprite(buffer, floors[glb_tilemap[y][x][0]], sx, sy);

            // wall
            idx = glb_tilemap[y][x][1];
            if (idx != -1)
            {
               sy = (base_y + x * hth) - walls[idx]->h + th;
               if ((sy >= - walls[idx]->h) && (sy < SCR_H))
                  draw_sprite(buffer, walls[idx], sx, sy);
            }
         }
      }
   }

   // mouse --> tile
   mouse_to_tile(& tx, & ty, mouse_x + pos_x, mouse_y + pos_y, tw, th, masks);
   
   // mouse TILE cursor
   dx = (ty * -htw) + (tx * htw);
   dy = (ty *  hth) + (tx * hth);

   x1 = dx - pos_x;
   x2 = x1 + htw - 1;
   x3 = x1 + htw;
   x4 = x1 + tw - 1;

   y1 = dy - pos_y;
   y2 = y1 + hth - 1;
   y3 = y1 + th - 2;
   
   line(buffer, x1, y2, x2, y1, 255);
   line(buffer, x3, y1, x4, y2, 255);
   line(buffer, x3, y3, x4, y2, 255);
   line(buffer, x1, y2, x2, y3, 255);

   // infos
   textprintf(buffer, font,   0, 0, 15, "fps = %i", glb_old_fps);
   textprintf(buffer, font, 100, 0, 15, "Tile = %i, %i", tx, ty);

   // draw screen
   vsync();
   show_mouse(NULL);
   blit(buffer, screen, 0, 0, 0, 0, SCR_W, SCR_H);
   show_mouse(screen);

   // update fps
   glb_fps++;
}


// =========================================================================
int main(void)
{
   BITMAP  * tmp, * masks,
           * floors[TILES_FLOORS_NUM], * walls[TILES_WALLS_NUM],
           * buffer;
   PALETTE my_pal;
   int     x, y, tiles_w, tiles_h, done = FALSE, i, j,
           pos_x = 0, pos_y = 0, // absolute position of upper/left corner of
                                 // the screen in virtual space
                                 // changing these values make us scroll
           mx, my; // mouse x & y
   char    * floors_name = "lame_floors.pcx",
           * walls_name  = "lame_walls.pcx",
           * masks_name  = "masks.pcx";

   // init allegro stuffs
   allegro_init();
   set_color_depth(SCR_BPP);
   install_keyboard();
   install_mouse();

   // install fps counter
   install_timer();
   LOCK_VARIABLE(glb_old_fps);
   LOCK_VARIABLE(glb_fps);
   LOCK_FUNCTION(my_fps_counter);
   
   // load masks
   masks = load_pcx(masks_name, my_pal); // we won't use this palette
   if (masks == NULL)
   {
      freopen("stderr.txt", "wb", stderr);
      fprintf(stderr, "can't open %s\n", masks_name);
      return 1;
   }

   // deduce width & height of 1 tile
   tiles_w = masks->w;
   tiles_h = masks->h;

   // load floors
   tmp = load_pcx(floors_name, my_pal);
   if (tmp == NULL)
   {
      destroy_bitmap(masks);
      freopen("stderr.txt", "wb", stderr);
      fprintf(stderr, "can't open %s\n", floors_name);
      return 1;
   }
   for (i=0; i<TILES_FLOORS_NUM; i++)
   {
      floors[i] = create_bitmap(tiles_w, tiles_h);
      if (floors[i] == NULL)
      {
         destroy_bitmap(masks);
         for (j=0; j<i; j++)
            destroy_bitmap(floors[j]);
         freopen("stderr.txt", "wb", stderr);
         fprintf(stderr, "can't make BITMAP of floor %i\n", i);
         return 1;
      }
      blit(tmp, floors[i], tiles_w * i, 0, 0, 0, tiles_w, tiles_h);
   }
   destroy_bitmap(tmp);

   // load walls
   tmp = load_pcx(walls_name, my_pal);
   if (tmp == NULL)
   {
      destroy_bitmap(masks);
      freopen("stderr.txt", "wb", stderr);
      fprintf(stderr, "can't open %s\n", walls_name);
      return 1;
   }
   for (i=0; i<TILES_WALLS_NUM; i++)
   {
      walls[i] = create_bitmap(tiles_w, tmp->h);
      if (walls[i] == NULL)
      {
         destroy_bitmap(masks);
         for (j=0; j<TILES_FLOORS_NUM; j++)
            destroy_bitmap(floors[j]);
         for (j=0; j<i; j++)
            destroy_bitmap(walls[j]);
         freopen("stderr.txt", "wb", stderr);
         fprintf(stderr, "can't make BITMAP of wall %i\n", i);
         return 1;
      }
      blit(tmp, walls[i], tiles_w * i, 0, 0, 0, tiles_w, tmp->h);
   }
   destroy_bitmap(tmp);

   // make a random map
   srand(time(NULL));
   for (y=0; y<TILES_NUM_H; y++)
   {
      for (x=0; x<TILES_NUM_W; x++)
      {
         glb_tilemap[y][x][0] = rand() % TILES_FLOORS_NUM;
         glb_tilemap[y][x][1] = -1;
         if ( ! (rand() % 4))
            glb_tilemap[y][x][1] = rand() % TILES_WALLS_NUM;
      }
   }

   // screen buffer
   buffer = create_bitmap(SCR_W, SCR_H);
   if (buffer == NULL)
   {
      destroy_bitmap(masks);
      for (i=0; i<TILES_FLOORS_NUM; i++)
         destroy_bitmap(floors[i]);
      for (i=0; i<TILES_WALLS_NUM; i++)
         destroy_bitmap(walls[i]);
      freopen("stderr.txt", "wb", stderr);
      fprintf(stderr, "can't make screen buffer (%i * %i pixels)\n",
         SCR_W, SCR_H);
      return 1;
   }
   clear(buffer);

   // init screen
   if (set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, SCR_W, SCR_H, 0, 0) < 0)
   {
      destroy_bitmap(masks);
      for (i=0; i<TILES_FLOORS_NUM; i++)
         destroy_bitmap(floors[i]);
      for (i=0; i<TILES_WALLS_NUM; i++)
         destroy_bitmap(walls[i]);
      freopen("stderr.txt", "wb", stderr);
      fprintf(stderr, "can't init a screen of %i * %i pixels, %i bpp\n",
         SCR_W, SCR_H, SCR_BPP);
      return 1;
   }
   set_palette(my_pal);

   // mouse
   show_mouse(screen);
   
   // start fps counter
   install_int(my_fps_counter, 1000);
   
   // main loop
   while ( ! done)
   {
      if (key[KEY_ESC])
         done = TRUE;

      mx = mouse_x;
      my = mouse_y;
      if ((key[KEY_LEFT])  || (mx == 0))         pos_x -= tiles_w / 4;
      if ((key[KEY_RIGHT]) || (mx == SCR_W - 1)) pos_x += tiles_w / 4;
      if ((key[KEY_UP])    || (my == 0))         pos_y -= tiles_h / 4;
      if ((key[KEY_DOWN])  || (my == SCR_H - 1)) pos_y += tiles_h / 4;
         
      draw_screen(buffer, floors, walls, masks, pos_x, pos_y, tiles_w, tiles_h);
   }

   // end
   destroy_bitmap(masks);
   for (i=0; i<TILES_FLOORS_NUM; i++)
      destroy_bitmap(floors[i]);
   for (i=0; i<TILES_WALLS_NUM; i++)
      destroy_bitmap(walls[i]);
   return 0;
}
END_OF_MAIN();

