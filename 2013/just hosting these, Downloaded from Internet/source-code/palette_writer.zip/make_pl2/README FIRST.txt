MAKE_PL2 freware Paul SIRAMY 10/02/2002
=======================================

Extract data\global\palette\<whichever directory you want>\pal.pl2
in this directory before atempting to run the program.

This program use the SAMPLE.PCX image and make new PAL.DAT and PAL.PL2.
They'll use the palette there's in the pcx. It's better if you don't use
it for palettes that are used during the game (act 1 thru 5), because
there's some shadows problems in your inventory. So it's better if you
use it only for loading screen or title screen.

The sample.pcx image * MUST * be in 256 colors mode, but you can use
a 800*600 bitmap if you want, that's the palette in the pcx which is
important, not the pixels.