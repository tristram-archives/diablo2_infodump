#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct
{
   unsigned char r, g, b;
} palette[256];

unsigned char colormap[32][256];


// ==========================================================================
// make shadows color map of 1 light level
void make_one_cmap(int level, unsigned char * cmap)
{
   int  i, j, r1, g1, b1, r2, g2, b2, tmp, cur_i;
   long dist, min_dist;

   for (i=0; i<256; i++)
   {
      // source color
      r1 = palette[i].r;
      g1 = palette[i].g;
      b1 = palette[i].b;

      // final color
      tmp = r1 * level;
      r2 = tmp / 31;
      if ((tmp % 31) >= 15)
         r2++;
      
      tmp = g1 * level;
      g2 = tmp / 31;
      if ((tmp % 31) >= 15)
         g2++;
      
      tmp = b1 * level;
      b2 = tmp / 31;
      if ((tmp % 31) >= 15)
         b2++;

      // found the best aproximation of the final color in the palette
      min_dist = 0x7FFFFFFF;
      cur_i    = -1;
      for (j=0; j<256; j++)
      {
         // which 'distance' from best color to current color
         // green count for 3, red for 2, blue for 1 (human eye)
         tmp   = 2 * (palette[j].r - r2);
         dist  = tmp * tmp;

         tmp   = 3 * (palette[j].g - g2);
         dist += tmp * tmp;

         tmp   = palette[j].b - b2;
         dist += tmp * tmp;

         // better choice ?
         if (dist < min_dist)
         {
            min_dist = dist;
            cur_i    = j;
         }
      }

      // color map result
      cmap[i] = cur_i;
   }
}


// ==========================================================================
// make all shadows color maps
void make_colormaps(void)
{
   int i;

   printf("making shadow levels : ");
   for (i=0; i<32; i++)
   {
      printf(".");
      fflush(stdout);
      make_one_cmap(i, & colormap[i][0]);
   }
   printf("ok\n");
}


// ==========================================================================
int open_pal_pl2(FILE ** pl2)
{
   char * name = "pal.pl2";

   * pl2 = fopen(name, "rb+");
   if (* pl2 == NULL)
   {
      freopen("stderr.txt", "wb", stderr);
      fprintf(stderr, "can't open %s\n", name);
      return 1;
   }
   return 0;
}


// ==========================================================================
int load_sample_palette(void)
{
   FILE * in;
   int  i;
   char * name = "sample.pcx";

   in = fopen(name, "rb");
   if (in == NULL)
   {
      freopen("stderr.txt", "wb", stderr);
      fprintf(stderr, "can't open %s\n", name);
      return 1;
   }
   fseek(in, -768, SEEK_END);
   for (i=0; i<256; i++)
   {
      palette[i].r = fgetc(in);
      palette[i].g = fgetc(in);
      palette[i].b = fgetc(in);
   }
   fclose(in);
   return 0;
}


// ==========================================================================
void pl2_write_palette(FILE * pl2)
{
   int i;
   
   fseek(pl2, 0, SEEK_SET);
   for (i=0; i<256; i++)
   {
      fputc(palette[i].r, pl2);
      fputc(palette[i].g, pl2);
      fputc(palette[i].b, pl2);
      fputc(0, pl2);
   }
}


// ==========================================================================
void pl2_write_cmaps(FILE * pl2)
{
   fseek(pl2, 1024, SEEK_SET);
   fwrite(colormap, 256, 32, pl2);
}


// ==========================================================================
int write_pal_dat(void)
{
   FILE * out;
   int  i;
   char * name = "pal.dat";

   out = fopen("pal.dat", "wb");
   if (out == NULL)
   {
      freopen("stderr.txt", "wb", stderr);
      fprintf(stderr, "can't write %s\n", name);
      return 1;
   }
   for (i=0; i<256; i++)
   {
      fputc(palette[i].b, out);
      fputc(palette[i].g, out);
      fputc(palette[i].r, out);
   }
   fclose(out);
   return 0;
}


// ==========================================================================
int main(void)
{
   FILE * pl2;
   
   if (load_sample_palette())
      return 1;
   make_colormaps();
   if (open_pal_pl2(& pl2))
      return 1;
   pl2_write_palette(pl2);
   pl2_write_cmaps(pl2);
   fclose(pl2);
   if (write_pal_dat())
      return 1;
   return 0;
}

