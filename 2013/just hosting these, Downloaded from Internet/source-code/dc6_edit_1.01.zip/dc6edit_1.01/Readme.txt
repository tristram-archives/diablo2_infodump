DC6EDIT  Simple animated dc6 converter
=======  Freeware, 02 June 2002, Paul SIRAMY


This prog was designed to extract all the frames
of Mephisto in his Dc6, and to made new ones. As
good news, it allows easy creation of animation
on the char selection screen (like nenu3.dc6)

4 Bat files and 2 Dc6 are provided for tests and
understanding of the syntaxe.

The pcx are named after the dc6 file, with 2
additionla numbers : first one is number of
directions and 2nd is the number of frames per
directions. Of course, these numbers vary from a
dc6 to another one.

There's a "debug" pcx when extracting : it's all
the frames past over each others, for allowing
a quick debug of animations in just a glance.

I don't think this prog can handle large static
pcx, like title screen of 800*600, so just use
your regular Dc6con or Dc6maker in this case.

In each pcx, there must have 2 white dots : they
indicate where is the origin of the sprite (it
is the middle of the body, at the feet level for
Mephisto, but not exactly for the Necromancer
animation during char selection screen). When
extracting pcx from dc6, these dots are
automatically placed on additionals row & line,
and they're at the same place from frame to frame.
You can change these dots, but it's not advise.
All frames MUST have these dots. They are needed
for internal offsets of dc6 format (like dcc).

Enjoy.
