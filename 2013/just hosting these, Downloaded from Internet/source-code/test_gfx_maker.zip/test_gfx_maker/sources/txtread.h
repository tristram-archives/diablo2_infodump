#ifndef _TXTREAD_H_

#define _TXTREAD_H_
                        
char  * txt_gets               (char * bptr, int * nb_char, int * is_new_line, int del_char);
char  * txt_read_header        (char * cur_col, TXT_S * txt);
int   txt_check_type_and_size  (char * cur_col, TXT_S * txt);
int   txt_fill_data            (char * cur_col, TXT_S * txt);
TXT_S * txt_destroy            (TXT_S * txt);
TXT_S * txt_load               (char * mem, char ** required_col, char * filename);
void  * txt_read_in_mem        (char * txtname);
void  txt_convert_slash        (char * str);
int   read_lvltypes_txt        (int ds1_idx, int type);
int   read_lvlprest_txt        (int ds1_idx, int def);
int   read_obj_txt             (int ds1_idx);
int   read_objects_txt         (void);

int   txt_read_set_items       (void);
int   txt_read_unique_items    (void);
int   txt_read_misc            (void);
int   txt_read_weapons         (void);
int   txt_read_armor           (void);
int   txt_read_itemtypes       (void);

#endif
