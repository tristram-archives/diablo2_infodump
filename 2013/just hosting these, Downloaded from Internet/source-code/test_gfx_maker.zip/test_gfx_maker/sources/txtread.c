#include <stdio.h>
#include <string.h>

#include "structs.h"
#include "mpq\\MpqView.h"
#include "misc.h"

#define TXT_MEM_DEBUG


// ==========================================================================
// prepare the reading of a col value
// give del_char TRUE to replace the TAB and CR/LF chars by 0
//
// function set nb_char to # of characters there's in that value
// function set is_new_line if after col was a LF of CR/LF
// function return NULL if after col is EOF, else pointer on next col / line
// note : handle both LF and CR/LF line type
char * txt_gets(char * bptr, int * nb_char, int * is_new_line, int del_char)
{
   * is_new_line = FALSE;
   * nb_char = 0;
   while (1)
   {
      if (bptr[* nb_char] == 0)
      {
         // end of file
         return NULL;
      }
      else if (bptr[* nb_char] == '\t')
      {
         // tab
         if (del_char == TRUE)
            bptr[* nb_char] = 0;
         return bptr + (* nb_char) + 1;
      }
      else if (bptr[* nb_char] == 0x0A)
      {
         // end of LF line
         * is_new_line = TRUE;
         if (del_char == TRUE)
            bptr[* nb_char] = 0;
         return bptr + (* nb_char) + 1;
      }
      else if (bptr[* nb_char] == 0x0D)
      {
         // end of CR / LF line
         * is_new_line = TRUE;
         if (del_char == TRUE)
            bptr[* nb_char] = 0;
         return bptr + (* nb_char) + 2;
      }
      else
         (* nb_char)++;
   }
}


// ==========================================================================
char * txt_read_header(char * cur_col, TXT_S * txt)
{
   int  nb_char, i, col_pos = 0, is_new_line;
   char * next_col;
   
   while (cur_col != NULL)
   {
      next_col = txt_gets(cur_col, & nb_char, & is_new_line, TRUE);
      if (nb_char)
      {
         // search if that col header is one of the required
         for (i=0; i < txt->col_num; i++)
         {
            if (stricmp(cur_col, txt->col[i].name) == 0)
            {
               // equal
               txt->col[i].pos = col_pos;
            }
         }
      }
      // this col done
      col_pos++;

      // next col
      if (is_new_line)
         return next_col;
      else
         cur_col = next_col;
   }
   return NULL;
}


// ==========================================================================
int txt_check_type_and_size(char * cur_col, TXT_S * txt)
{
   int  nb_char, i, col_pos = 0, is_new_line = FALSE, x;
   char * next_col;
   
   if (cur_col == NULL)
      return 1;
      
   // for all lines, check the string size of the interesting columns
   txt->line_num = 0;
   col_pos = 0;
   while (cur_col != NULL)
   {
      // read this col
      next_col = txt_gets(cur_col, & nb_char, & is_new_line, FALSE);
      
      if (nb_char)
      {
         // does this col is one of the required ?
         for (i=0; i < txt->col_num; i++)
         {
            if (col_pos == txt->col[i].pos)
            {
               // check its size
               if (nb_char > txt->col[i].size)
                  txt->col[i].size = nb_char;

               // check its type
               if (txt->col[i].type == CT_NULL)
                  txt->col[i].type = CT_NUM;
               for (x=0; x < nb_char; x++)
               {
                  if ( ((cur_col[x] < '0') || (cur_col[x] > '9'))
                       &&
                       cur_col[x] != '-')
                  {
                     txt->col[i].type = CT_STR;
                     x = nb_char;
                  }
               }
            }
         }
      }
      
      // this col done
      col_pos++;

      // next col
      if (is_new_line)
      {
         txt->line_num++;
         col_pos = 0;
      }
      cur_col = next_col;
   }
   return 0;
}


// ==========================================================================
int txt_fill_data(char * cur_col, TXT_S * txt)
{
   int  nb_char, i, col_pos = 0, is_new_line, cur_line = 0;
   char * next_col, * data_ptr, * sptr;
   long * lptr;
   
   if ((cur_col == NULL) || (txt->data == NULL))
      return 1;
      
   // for all lines, read the data
   col_pos = 0;
   data_ptr = txt->data;
   while (cur_col != NULL)
   {
      // read this col
      next_col = txt_gets(cur_col, & nb_char, & is_new_line, TRUE);
      
      if (nb_char)
      {
         // does this col is one of the required ?
         for (i=0; i < txt->col_num; i++)
         {
            if (col_pos == txt->col[i].pos)
            {
               // copy it
               sptr = data_ptr + txt->col[i].offset;
               if (txt->col[i].type == CT_STR)
                  strcpy(sptr, cur_col);
               else if (txt->col[i].type == CT_NUM)
               {
                  lptr = (long *) sptr;
                  * lptr = atol(cur_col);
               }
            }
         }
      }
      
      // this col done
      col_pos++;

      // next col
      if (is_new_line)
      {
         cur_line++;
         if (cur_line > txt->line_num)
            return 1;
         else
         {
            data_ptr += txt->line_size;
            col_pos = 0;
         }
      }
      cur_col = next_col;
   }
   return 0;
}


// ==========================================================================
TXT_S * txt_destroy(TXT_S * txt)
{
   if (txt == NULL)
      return NULL;
   if (txt->data != NULL)
      free(txt->data);
   if (txt->col != NULL)
      free(txt->col);
   free(txt);
   return NULL;
}


// ==========================================================================
// note : the mem buffer MUST end by a 0
TXT_S * txt_load(char * mem, char ** required_col, char * filename)
{
   TXT_S * txt;
   int   i=0, size, all_col_ok = TRUE;
   char  * first_line;

   printf("txt_load() : loading %s\n", filename);
   fflush(stdout);
   
   size = sizeof(TXT_S);
   txt = (TXT_S *) malloc(size);
   if (txt == NULL)
   {
      printf("txt_load() : can't allocate %i bytes", size);
      exit(1);
   }
   memset(txt, 0, size);

   while (required_col[i] != NULL)
      i++;
   txt->col_num = i;

   size = i * sizeof(TXT_COL_S);
   txt->col = (TXT_COL_S *) malloc(size);
   if (txt->col == NULL)
   {
      txt = txt_destroy(txt);
      printf("txt_load() : can't allocate %i bytes for txt->col", size);
      exit(1);
   }
   memset(txt->col, 0, size);

   // init the cols
   for (i=0; i < txt->col_num; i++)
   {
      txt->col[i].pos  = -1;
      strncpy(txt->col[i].name, required_col[i], TXT_COL_NAME_LENGTH);
   }

   // stage 1, process header
   first_line = txt_read_header(mem, txt);
   for (i=0; i < txt->col_num; i++)
   {
      if (txt->col[i].pos == -1)
      {
         printf("txt_load() : didn't found required column %i (%s)\n",
            i, txt->col[i].name);
         fflush(stdout);
         all_col_ok = FALSE;
      }
   }
   if (all_col_ok != TRUE)
   {
      txt = txt_destroy(txt);
      printf("txt_load() : not all columns have been found");
      exit(1);
   }

   // stage 2, search max size of all string columns except header
   if (txt_check_type_and_size(first_line, txt))
   {
      txt = txt_destroy(txt);
      printf("txt_load() : stage 2, error shouldn't have happen");
      exit(1);
   }

   // stage 3, make the struct
   size = 0;
   for (i=0; i < txt->col_num; i++)
   {
      txt->col[i].offset = size;
      if (txt->col[i].type == CT_NUM)
         size += sizeof(long);
      else if (txt->col[i].type == CT_STR)
         size += (txt->col[i].size + 1);
   }
   txt->line_size = size;
   size *= txt->line_num;
   txt->data = malloc(size);
   if (txt->data == NULL)
   {
      txt = txt_destroy(txt);
      printf("txt_load() : can't allocate %i bytes for txt->data", size);
      exit(1);
   }
   memset(txt->data, 0, size);
   
   // stage 4, load the txt into the struct
   if (txt_fill_data(first_line, txt))
   {
      txt = txt_destroy(txt);
      printf("txt_load() : stage 4, error shouldn't have happen");
      exit(1);
   }

   return txt;
}


// ==========================================================================
// load a .txt from a mpq (or mod dir) into mem
void * txt_read_in_mem(char * txtname)
{
   void * buff = NULL, * new_buff;
   int  entry;
   long len;

   entry = misc_load_mpq_file(txtname, & buff, & len, FALSE);
   if ((entry == -1) || (buff == NULL))
   {
      printf("error, read_txt_in_mem() : file %s not found", txtname);
      exit(1);
   }

   len++;
   new_buff = realloc(buff, len);
   if (new_buff == NULL)
   {
      printf("error, read_txt_in_mem() : can't reallocate %i bytes for %s",
         len, txtname);
      if (buff != NULL)
         free(buff);
      exit(1);
   }

   if (new_buff != buff)
      memcpy(new_buff, buff, len - 1);
   
   * (((char *) new_buff) + len - 1) = 0;

   return buff;
}


// ==========================================================================
void txt_convert_slash(char * str)
{
   int i, s = strlen(str);

   for (i=0; i < s; i++)
      if (str[i] == '/')
         str[i] = '\\';
}


// ==========================================================================
// load the setitems.txt into mem
int txt_read_set_items(void)
{
   FILE  * out;
   TXT_S * txt;
   char  * buff, * filename = "Data\\Global\\Excel\\SetItems.txt";
   int   i;

   // load the file in mem
   if (glb_ds1edit.setitems_buff == NULL)
   {
      buff = txt_read_in_mem(filename);
      if (buff == NULL)
         return -1;

      // load the .txt in a more handy struct
      txt = txt_load(buff, txt_req_ptr[RQ_SETITEMS], filename);
      glb_ds1edit.setitems_buff = txt;
      free(buff);
      if (txt == NULL)
         return -1;
   }
   else
      txt = glb_ds1edit.setitems_buff;

#ifdef TXT_MEM_DEBUG
   out = fopen("setitems.mem", "wb");
   if (out != NULL)
   {
      fwrite(txt->data, txt->line_size, txt->line_num, out);
      fclose(out);
   }
   out = fopen("setitems.def", "wt");
   if (out != NULL)
   {
      fprintf(out, "col header name          pos type size offset\n");
      fprintf(out, "--- -------------------- --- ---- ---- ------\n");
      for (i=0; i < txt->col_num; i++)
      {
         fprintf(out, "%3i %-20s %3i %s %4i %6i\n",
            i,
            txt->col[i].name,
            txt->col[i].pos,
            txt->col[i].type == CT_NUM ? "NUM " : "STR ",
            txt->col[i].size,
            txt->col[i].offset
         );
      }
      fclose(out);
   }
#endif

   return 0;
}


// ==========================================================================
// load the uniqueitems.txt into mem
int txt_read_unique_items(void)
{
   FILE  * out;
   TXT_S * txt;
   char  * buff, * filename = "Data\\Global\\Excel\\UniqueItems.txt";
   int   i;

   // load the file in mem
   if (glb_ds1edit.uniqueitems_buff == NULL)
   {
      buff = txt_read_in_mem(filename);
      if (buff == NULL)
         return -1;

      // load the .txt in a more handy struct
      txt = txt_load(buff, txt_req_ptr[RQ_UNIQUEITEMS], filename);
      glb_ds1edit.uniqueitems_buff = txt;
      free(buff);
      if (txt == NULL)
         return -1;
   }
   else
      txt = glb_ds1edit.uniqueitems_buff;

#ifdef TXT_MEM_DEBUG
   out = fopen("uniqueitems.mem", "wb");
   if (out != NULL)
   {
      fwrite(txt->data, txt->line_size, txt->line_num, out);
      fclose(out);
   }
   out = fopen("uniqueitems.def", "wt");
   if (out != NULL)
   {
      fprintf(out, "col header name          pos type size offset\n");
      fprintf(out, "--- -------------------- --- ---- ---- ------\n");
      for (i=0; i < txt->col_num; i++)
      {
         fprintf(out, "%3i %-20s %3i %s %4i %6i\n",
            i,
            txt->col[i].name,
            txt->col[i].pos,
            txt->col[i].type == CT_NUM ? "NUM " : "STR ",
            txt->col[i].size,
            txt->col[i].offset
         );
      }
      fclose(out);
   }
#endif

   return 0;
}


// ==========================================================================
// load the misc.txt into mem
int txt_read_misc(void)
{
   FILE  * out;
   TXT_S * txt;
   char  * buff, * filename = "Data\\Global\\Excel\\Misc.txt";
   int   i;

   // load the file in mem
   if (glb_ds1edit.misc_buff == NULL)
   {
      buff = txt_read_in_mem(filename);
      if (buff == NULL)
         return -1;

      // load the .txt in a more handy struct
      txt = txt_load(buff, txt_req_ptr[RQ_MISC], filename);
      glb_ds1edit.misc_buff = txt;
      free(buff);
      if (txt == NULL)
         return -1;
   }
   else
      txt = glb_ds1edit.misc_buff;

#ifdef TXT_MEM_DEBUG
   out = fopen("misc.mem", "wb");
   if (out != NULL)
   {
      fwrite(txt->data, txt->line_size, txt->line_num, out);
      fclose(out);
   }
   out = fopen("misc.def", "wt");
   if (out != NULL)
   {
      fprintf(out, "col header name          pos type size offset\n");
      fprintf(out, "--- -------------------- --- ---- ---- ------\n");
      for (i=0; i < txt->col_num; i++)
      {
         fprintf(out, "%3i %-20s %3i %s %4i %6i\n",
            i,
            txt->col[i].name,
            txt->col[i].pos,
            txt->col[i].type == CT_NUM ? "NUM " : "STR ",
            txt->col[i].size,
            txt->col[i].offset
         );
      }
      fclose(out);
   }
#endif

   return 0;
}


// ==========================================================================
// load the weapons.txt into mem
int txt_read_weapons(void)
{
   FILE  * out;
   TXT_S * txt;
   char  * buff, * filename = "Data\\Global\\Excel\\Weapons.txt";
   int   i;

   // load the file in mem
   if (glb_ds1edit.weapons_buff == NULL)
   {
      buff = txt_read_in_mem(filename);
      if (buff == NULL)
         return -1;

      // load the .txt in a more handy struct
      txt = txt_load(buff, txt_req_ptr[RQ_WEAPONS], filename);
      glb_ds1edit.weapons_buff = txt;
      free(buff);
      if (txt == NULL)
         return -1;
   }
   else
      txt = glb_ds1edit.weapons_buff;

#ifdef TXT_MEM_DEBUG
   out = fopen("weapons.mem", "wb");
   if (out != NULL)
   {
      fwrite(txt->data, txt->line_size, txt->line_num, out);
      fclose(out);
   }
   out = fopen("weapons.def", "wt");
   if (out != NULL)
   {
      fprintf(out, "col header name          pos type size offset\n");
      fprintf(out, "--- -------------------- --- ---- ---- ------\n");
      for (i=0; i < txt->col_num; i++)
      {
         fprintf(out, "%3i %-20s %3i %s %4i %6i\n",
            i,
            txt->col[i].name,
            txt->col[i].pos,
            txt->col[i].type == CT_NUM ? "NUM " : "STR ",
            txt->col[i].size,
            txt->col[i].offset
         );
      }
      fclose(out);
   }
#endif

   return 0;
}


// ==========================================================================
// load the armor.txt into mem
int txt_read_armor(void)
{
   FILE  * out;
   TXT_S * txt;
   char  * buff, * filename = "Data\\Global\\Excel\\Armor.txt";
   int   i;

   // load the file in mem
   if (glb_ds1edit.armor_buff == NULL)
   {
      buff = txt_read_in_mem(filename);
      if (buff == NULL)
         return -1;

      // load the .txt in a more handy struct
      txt = txt_load(buff, txt_req_ptr[RQ_ARMOR], filename);
      glb_ds1edit.armor_buff = txt;
      free(buff);
      if (txt == NULL)
         return -1;
   }
   else
      txt = glb_ds1edit.armor_buff;

#ifdef TXT_MEM_DEBUG
   out = fopen("armor.mem", "wb");
   if (out != NULL)
   {
      fwrite(txt->data, txt->line_size, txt->line_num, out);
      fclose(out);
   }
   out = fopen("armor.def", "wt");
   if (out != NULL)
   {
      fprintf(out, "col header name          pos type size offset\n");
      fprintf(out, "--- -------------------- --- ---- ---- ------\n");
      for (i=0; i < txt->col_num; i++)
      {
         fprintf(out, "%3i %-20s %3i %s %4i %6i\n",
            i,
            txt->col[i].name,
            txt->col[i].pos,
            txt->col[i].type == CT_NUM ? "NUM " : "STR ",
            txt->col[i].size,
            txt->col[i].offset
         );
      }
      fclose(out);
   }
#endif

   return 0;
}


// ==========================================================================
// load the itemtypes.txt into mem
int txt_read_itemtypes(void)
{
   FILE  * out;
   TXT_S * txt;
   char  * buff, * filename = "Data\\Global\\Excel\\ItemTypes.txt";
   int   i;

   // load the file in mem
   if (glb_ds1edit.itemtypes_buff == NULL)
   {
      buff = txt_read_in_mem(filename);
      if (buff == NULL)
         return -1;

      // load the .txt in a more handy struct
      txt = txt_load(buff, txt_req_ptr[RQ_ITEMTYPES], filename);
      glb_ds1edit.itemtypes_buff = txt;
      free(buff);
      if (txt == NULL)
         return -1;
   }
   else
      txt = glb_ds1edit.itemtypes_buff;

#ifdef TXT_MEM_DEBUG
   out = fopen("itemtypes.mem", "wb");
   if (out != NULL)
   {
      fwrite(txt->data, txt->line_size, txt->line_num, out);
      fclose(out);
   }
   out = fopen("itemtypes.def", "wt");
   if (out != NULL)
   {
      fprintf(out, "col header name          pos type size offset\n");
      fprintf(out, "--- -------------------- --- ---- ---- ------\n");
      for (i=0; i < txt->col_num; i++)
      {
         fprintf(out, "%3i %-20s %3i %s %4i %6i\n",
            i,
            txt->col[i].name,
            txt->col[i].pos,
            txt->col[i].type == CT_NUM ? "NUM " : "STR ",
            txt->col[i].size,
            txt->col[i].offset
         );
      }
      fclose(out);
   }
#endif

   return 0;
}
