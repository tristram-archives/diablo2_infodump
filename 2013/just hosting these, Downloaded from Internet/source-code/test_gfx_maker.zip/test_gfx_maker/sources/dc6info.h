#ifndef _DC6_INFO_H_

#define _DC6_INFO_H_

BITMAP * anim_load_dc6(char * name, UBYTE * cmap);

#endif

