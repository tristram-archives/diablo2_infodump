#include <stdio.h>
#include <string.h>

#include "structs.h"
#include "misc.h"
#include "dc6info.h"


// ==========================================================================
// change a item name, ready for internet
// valid characters are 'a' to 'z' and '0' to '9', any other will be replaced by '_'
void make_items_update_name(char * name)
{
   int i, max = strlen(name), c;

   for (i=0; i < max; i++)
   {
      c = tolower(name[i]);
      if ( ((c >= 'a') && (c <= 'z')) || ((c >= '0') && (c <= '9')) )
      {
         // ok, no further change
         name[i] = c;
      }
      else
      {
         // replace it by a '_'
         name[i] = '_';
      }
   }
}


// ==========================================================================
// process all unique items
int make_items_uniques(void)
{
   TXT_S   * txt  = glb_ds1edit.uniqueitems_buff,
           * txt2;
   int     i, i2, done, page;
   char    * sptr, name[256], code[32], page_invfile[256], page_type[32],
           dc6file[256], gfxfile[256];
   long    completed, transform, invtransform, transformcolor,
           page_transform, page_invtrans, varinvgfx, nb;
   BITMAP  * bmp;
   PALETTE pal;


   // in case
   if (txt == NULL)
   {
      log_printf("error, make_items_uniques() : uniqueitems.txt isn't ready\n");
      exit(1);
   }

   // for all items in uniqueitems.txt
   for (i=0; i < txt->line_num; i++)
   {
      // name
      sptr = txt->data + (i * txt->line_size) +
             txt->col[misc_get_txt_column_num(RQ_UNIQUEITEMS, "Name")].offset;
      strcpy(name, sptr);
      make_items_update_name(name);

      // code
      sptr = txt->data + (i * txt->line_size) +
             txt->col[misc_get_txt_column_num(RQ_UNIQUEITEMS, "Code")].offset;
      strcpy(code, sptr);

      // completed
      sptr = txt->data + (i * txt->line_size) +
             txt->col[misc_get_txt_column_num(RQ_UNIQUEITEMS, "completed")].offset;
      completed = * ((long *) sptr);

      // transform
      sptr = txt->data + (i * txt->line_size) +
             txt->col[misc_get_txt_column_num(RQ_UNIQUEITEMS, "transform")].offset;
      transform = * ((long *) sptr);

      // invtransform
      sptr = txt->data + (i * txt->line_size) +
             txt->col[misc_get_txt_column_num(RQ_UNIQUEITEMS, "invtransform")].offset;
      invtransform = * ((long *) sptr);

      // transformcolor
      sptr = txt->data + (i * txt->line_size) +
             txt->col[misc_get_txt_column_num(RQ_UNIQUEITEMS, "transformcolor")].offset;
      transformcolor = * ((long *) sptr);

      // search the item in all pages (misc, weapons, armor)
      done = FALSE;
      strcpy(page_invfile, "");
      strcpy(page_type, "");
      page_transform = -1;
      page_invtrans  = -1;
      page           = -1;

      // weapons.txt
      txt2 = glb_ds1edit.weapons_buff;
      for (i2=0; (i2 < txt2->line_num) && (done == FALSE); i2++)
      {
         sptr = txt2->data + (i2 * txt2->line_size) +
                txt2->col[misc_get_txt_column_num(RQ_WEAPONS, "code")].offset;
         if (strcmp(sptr, code) == 0)
         {
            done = TRUE;
            page = RQ_WEAPONS;

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_WEAPONS, "Transform")].offset;
            page_transform = * ((long *) sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_WEAPONS, "InvTrans")].offset;
            page_invtrans = * ((long *) sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_WEAPONS, "invfile")].offset;
            strcpy(page_invfile, sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_WEAPONS, "uniqueinvfile")].offset;
            if (strlen(sptr))
               strcpy(page_invfile, sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_WEAPONS, "type")].offset;
            strcpy(page_type, sptr);
         }
      }

      // armor.txt
      txt2 = glb_ds1edit.armor_buff;
      for (i2=0; (i2 < txt2->line_num) && (done == FALSE); i2++)
      {
         sptr = txt2->data + (i2 * txt2->line_size) +
                txt2->col[misc_get_txt_column_num(RQ_ARMOR, "code")].offset;
         if (strcmp(sptr, code) == 0)
         {
            done = TRUE;
            page = RQ_ARMOR;

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_ARMOR, "Transform")].offset;
            page_transform = * ((long *) sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_ARMOR, "InvTrans")].offset;
            page_invtrans = * ((long *) sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_ARMOR, "invfile")].offset;
            strcpy(page_invfile, sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_ARMOR, "uniqueinvfile")].offset;
            if (strlen(sptr))
               strcpy(page_invfile, sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_ARMOR, "type")].offset;
            strcpy(page_type, sptr);
         }
      }

      // misc.txt
      txt2 = glb_ds1edit.misc_buff;
      for (i2=0; (i2 < txt2->line_num) && (done == FALSE); i2++)
      {
         sptr = txt2->data + (i2 * txt2->line_size) +
                txt2->col[misc_get_txt_column_num(RQ_MISC, "code")].offset;
         if (strcmp(sptr, code) == 0)
         {
            done = TRUE;
            page = RQ_MISC;

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_MISC, "Transform")].offset;
            page_transform = * ((long *) sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_MISC, "InvTrans")].offset;
            page_invtrans = * ((long *) sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_MISC, "invfile")].offset;
            strcpy(page_invfile, sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_MISC, "uniqueinvfile")].offset;
            if (strlen(sptr))
               strcpy(page_invfile, sptr);

            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_MISC, "type")].offset;
            strcpy(page_type, sptr);
         }
      }

      // random alternate gfx, for rings, amulets, jewels...
      if (page != -1)
      {
         txt2 = glb_ds1edit.itemtypes_buff;
         done = FALSE;
         for (i2=0; (i2 < txt2->line_num) && (done == FALSE); i2++)
         {
            sptr = txt2->data + (i2 * txt2->line_size) +
                   txt2->col[misc_get_txt_column_num(RQ_ITEMTYPES, "Code")].offset;
            if (strcmp(page_type, sptr) == 0)
            {
               sptr = txt2->data + (i2 * txt2->line_size) +
                      txt2->col[misc_get_txt_column_num(RQ_ITEMTYPES, "VarInvGfx")].offset;
               varinvgfx = * ((long *) sptr);
               if (varinvgfx)
               {
                  nb = rand() % varinvgfx;
                  switch (nb)
                  {

                     case 0 :
                        sptr = txt2->data + (i2 * txt2->line_size) +
                               txt2->col[misc_get_txt_column_num(RQ_ITEMTYPES, "InvGfx1")].offset;
                        break;

                     case 1 :
                        sptr = txt2->data + (i2 * txt2->line_size) +
                               txt2->col[misc_get_txt_column_num(RQ_ITEMTYPES, "InvGfx2")].offset;
                        break;

                     case 2 :
                        sptr = txt2->data + (i2 * txt2->line_size) +
                               txt2->col[misc_get_txt_column_num(RQ_ITEMTYPES, "InvGfx3")].offset;
                        break;

                     case 3 :
                        sptr = txt2->data + (i2 * txt2->line_size) +
                               txt2->col[misc_get_txt_column_num(RQ_ITEMTYPES, "InvGfx4")].offset;
                        break;

                     case 4 :
                        sptr = txt2->data + (i2 * txt2->line_size) +
                               txt2->col[misc_get_txt_column_num(RQ_ITEMTYPES, "InvGfx5")].offset;
                        break;

                     case 5 :
                        sptr = txt2->data + (i2 * txt2->line_size) +
                               txt2->col[misc_get_txt_column_num(RQ_ITEMTYPES, "InvGfx6")].offset;
                        break;
                  }
                  if (strlen(sptr) == 0)
                  {
                     printf("error, make_items_uniques() : "
                        "InvGfx%li of itemtype %s should have a file\n",
                        nb + 1, page_type);
                     log_printf("");
                     exit(1);
                  }
                  strcpy(page_invfile, sptr);
               }
            }
         }
      }

      // debug
      if (completed)
      {
         if (strlen(page_invfile) == 0)
         {
            printf("error, make_items_unique() : %s not found in misc/weapons/armor.txt\n", name);
            log_printf("");
         }
         else
         {
            printf("%-32s ", name);

            // load a dc6, and apply a colormap on it
            sprintf(dc6file, "%s\\%s.dc6", "Data\\Global\\Items", page_invfile);
            if (transform && invtransform)
            {
               if (page_invtrans == 0)
                  bmp = anim_load_dc6(dc6file, NULL);
               else
                  bmp = anim_load_dc6(
                     dc6file,
                     & glb_ds1edit.cmap[page_invtrans]->data[transformcolor][0]
                  );
            }
            else
               bmp = anim_load_dc6(dc6file, NULL);
            if (bmp == NULL)
            {
               printf("ERROR while reading %s\n", dc6file);
               log_printf("");
               exit(1);
            }
            else
            {
               for (i2=0; i2 < 256; i2++)
               {
                  pal[i2].r = glb_ds1edit.d2_pal[i2 * 4]     >> 2;
                  pal[i2].g = glb_ds1edit.d2_pal[i2 * 4 + 1] >> 2;
                  pal[i2].b = glb_ds1edit.d2_pal[i2 * 4 + 2] >> 2;
               }
               sprintf(gfxfile, "%s\\%s.%s", "uniques", name, "pcx");
               set_palette(pal);
               misc_pal_d2_2_vga(pal);
               save_pcx(gfxfile, bmp, pal);
               destroy_bitmap(bmp);
            }
         }
      }
   }

   // end
   return 0;
}
