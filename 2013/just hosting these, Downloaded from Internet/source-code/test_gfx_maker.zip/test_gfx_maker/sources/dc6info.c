#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "structs.h"
#include "misc.h"


// ==========================================================================
// decompress a dc6 frame onto the BITMAP, using a colormap
// cmap must point to a table of 256 bytes, or NULL if no colormap
void dc6_decomp_cmap(void * src, BITMAP * dst, long size, int x0, int y0,
                     UBYTE * cmap)
{
   UBYTE * ptr = (UBYTE *) src;
   long  i;
   int   i2, x=x0, y=y0, c, c2;
   

   if (cmap == NULL)
   {
      for (i=0; i<size; i++)
      {
         c = * (ptr ++);

         if (c == 0x80)
         {
            x = x0;
            y--;
         }
         else if (c & 0x80)
            x += c & 0x7F;
         else
         {
            for (i2=0; i2<c; i2++)
            {
               c2 = * (ptr ++);
               i++;
               putpixel(dst, x, y, c2);
               x++;
            }
         }
      }
   }
   else
   {
      for (i=0; i<size; i++)
      {
         c = * (ptr ++);

         if (c == 0x80)
         {
            x = x0;
            y--;
         }
         else if (c & 0x80)
            x += c & 0x7F;
         else
         {
            for (i2=0; i2<c; i2++)
            {
               c2 = * (ptr ++);
               i++;
               putpixel(dst, x, y, cmap[c2]);
               x++;
            }
         }
      }
   }
}


// ==========================================================================
BITMAP * anim_load_dc6(char * name, UBYTE * cmap)
{
   int         entry, len;
   char       * buff;
   long       * lptr, offset;
   long       dc6_ver, dc6_unk1, dc6_unk2, dc6_dir, dc6_fpd, * dc6_fptr,
              f_w, f_h, f_len;
   BITMAP     * bmp;
   UBYTE      * f_data;

   // load dc6 file
   log_printf("load dc6 : ");
   printf("%s", name);
   log_printf("\n");
   entry = misc_load_mpq_file(name, & buff, & len, FALSE);
   if (entry == -1)
      return NULL;

   // decode dc6 header datas
   lptr     = (long *) buff;
   dc6_ver  = lptr[0];
   dc6_unk1 = lptr[1];
   dc6_unk2 = lptr[2];
   dc6_dir  = lptr[4];
   dc6_fpd  = lptr[5];
   dc6_fptr = & lptr[6];
   if ((dc6_ver != 6) || (dc6_unk1 != 1) || (dc6_unk2 != 0))
   {
      log_printf("wrong dc6 version\n");
      free(buff);
      return NULL;
   }

   // get pointer to frame header
   offset = dc6_fptr[0]; // frame 0
   if (offset >= len)
   {
      log_printf("offset >= len\n");
      free(buff);
      return NULL;
   }
   lptr = (long *) (buff + offset);

   // get frame datas
   f_w    = lptr[1];
   f_h    = lptr[2];
   f_len  = lptr[7];
   f_data = (UBYTE *) (& lptr[8]);

   // make a BITMAP
   bmp = create_bitmap(f_w, f_h);
   if (bmp == NULL)
   {
      log_printf("can't create a bitmap\n");
      free(buff);
      return NULL;
   }
   clear(bmp);

   // decode dc6 datas
   dc6_decomp_cmap(
      f_data,   // src
      bmp,      // dst
      f_len,    // length
      0,        // x0
      f_h - 1,  // y0
      cmap     // cmap
   );

   // end
   free(buff);
   return bmp;
}
