#ifndef _MAKE_ITEMS_H_

#define _MAKE_ITEMS_H_

int make_items_uniques(void);

#endif
