#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define USE_CONSOLE
#include <allegro.h>

#include "structs.h"
#include "mpq\\mpqview.h"
#include "txtread.h"
#include "misc.h"
#include "make_items.h"


char           ** txt_req_ptr[RQ_MAX] = {NULL, NULL, NULL, NULL, NULL, NULL,};
GLB_DS1EDIT_S  glb_ds1edit;                  // global datas of the program
GLB_MPQ_S      glb_mpq_struct[MAX_MPQ_FILE]; // global data of 1 mpq


GAMMA_S gamma_str[GC_MAX] = // gamma correction string table
        {
           {"0.60", GC_060}, {"0.62", GC_062}, {"0.64", GC_064},
           {"0.66", GC_066}, {"0.68", GC_068}, {"0.70", GC_070},
           {"0.72", GC_072}, {"0.74", GC_074}, {"0.76", GC_076},
           {"0.78", GC_078}, {"0.80", GC_080}, {"0.82", GC_082},
           {"0.84", GC_084}, {"0.86", GC_086}, {"0.88", GC_088},
           {"0.90", GC_090}, {"0.92", GC_092}, {"0.94", GC_094},
           {"0.96", GC_096}, {"0.98", GC_098}, {"1.00", GC_100},
           {"1.10", GC_110}, {"1.20", GC_120}, {"1.30", GC_130},
           {"1.40", GC_140}, {"1.50", GC_150}, {"1.60", GC_160},
           {"1.70", GC_170}, {"1.80", GC_180}, {"1.90", GC_190},
           {"2.00", GC_200}, {"2.10", GC_210}, {"2.20", GC_220},
           {"2.30", GC_230}, {"2.40", GC_240}, {"2.50", GC_250},
           {"2.60", GC_260}, {"2.70", GC_270}, {"2.80", GC_280},
           {"2.90", GC_290}, {"3.00", GC_300}
        };

char * txt_def_setitems_req[] = {
         // number
         {"NumItems"},
         {"Transform"},
         {"Transformcolor"},

         // text
         {"Name"},
         {"Item1"},
         {"Item1 Suffix"},
         {"Item2"},
         {"Item2 Suffix"},
         {"Item3"},
         {"Item3 Suffix"},
         {"Item4"},
         {"Item4 Suffix"},
         {"Item5"},
         {"Item5 Suffix"},
         {"Item6"},
         {"Item6 Suffix"},

         NULL // DO NOT REMOVE !
       };

char * txt_def_uniqueitems_req[] = {
         // number
         {"completed"},
         {"transform"},
         {"invtransform"},
         {"transformcolor"},

         // text
         {"Name"},
         {"Code"},

         NULL // DO NOT REMOVE !
       };

char * txt_def_misc_req[] = {
         // number
         {"Transform"},
         {"InvTrans"},

         // text
         {"code"},
         {"type"},
         {"invfile"},
         {"uniqueinvfile"},

         NULL // DO NOT REMOVE !
       };

char * txt_def_weapons_req[] = {
         // number
         {"Transform"},
         {"InvTrans"},

         // text
         {"code"},
         {"type"},
         {"invfile"},
         {"setinvfile"},
         {"uniqueinvfile"},

         NULL // DO NOT REMOVE !
       };

char * txt_def_armor_req[] = {
         // number
         {"Transform"},
         {"InvTrans"},

         // text
         {"code"},
         {"type"},
         {"invfile"},
         {"setinvfile"},
         {"uniqueinvfile"},

         NULL // DO NOT REMOVE !
       };

char * txt_def_itemtypes_req[] = {
         // number
         {"VarInvGfx"},

         // text
         {"Code"},
         {"InvGfx1"},
         {"InvGfx2"},
         {"InvGfx3"},
         {"InvGfx4"},
         {"InvGfx5"},
         {"InvGfx6"},

         NULL // DO NOT REMOVE !
       };


// ==================================================================================
void delete_all_directory_content(int level)
{
    struct al_ffblk info;
    int             i;

    if ((level <= 0) || (level >= 10))
    {
        printf("error, delete_all_directory_content() : level=%i\n", level);
        exit(1);
    }

    if (al_findfirst("*.*", & info, -1) == 0)
    {
        while (al_findnext( & info) == 0)
        {
            if (info.name[0] != '.')
            {
                if (info.attrib & FA_DIREC)
                {
                    for (i=0; i < level; i++)
                        printf("   ");
                    printf("entering %s\n", info.name);
                    chdir(info.name);

                    delete_all_directory_content(level + 1);
                    
                    for (i=0; i < level; i++)
                        printf("   ");
                    printf("exiting %s\n", info.name);
                    chdir("..");

                    for (i=0; i < level; i++)
                        printf("   ");
                    printf("deleting directory %s\n", info.name);
                    rmdir(info.name);
                }
                for (i=0; i < level; i++)
                    printf("   ");
                printf("deleting %s\n", info.name);
                remove(info.name);
            }
        }
    }
    al_findclose( & info);
}


// ==================================================================================
void my_init(void)
{
   int i;

   // mpq
   log_printf("\ninit mpq\n");
   memset(&glb_ds1edit, 0, sizeof(glb_ds1edit));
   for (i=0; i < MAX_MPQ_FILE; i++)
   {
      memset( & glb_mpq_struct[i], 0, sizeof(GLB_MPQ_S));
      glb_mpq_struct[i].is_open = FALSE;
   }

   // txt
   log_printf("\ninit txt\n");
   txt_req_ptr[RQ_SETITEMS]    = txt_def_setitems_req;
   txt_req_ptr[RQ_UNIQUEITEMS] = txt_def_uniqueitems_req;
   txt_req_ptr[RQ_MISC]        = txt_def_misc_req;
   txt_req_ptr[RQ_WEAPONS]     = txt_def_weapons_req;
   txt_req_ptr[RQ_ARMOR]       = txt_def_armor_req;
   txt_req_ptr[RQ_ITEMTYPES]   = txt_def_itemtypes_req;

   // random
   log_printf("\ninit random\n");
   srand(time(NULL));

   // remove old uniques
   log_printf("\ninit uniques\n");
   if (file_exists("uniques\\.", -1, NULL))
   {
       printf("processing 'uniques' directory...\n");
       chdir("uniques");
       delete_all_directory_content(1);
       chdir("..");
   }
   else
       mkdir("uniques");

   // remove old sets
   log_printf("\ninit sets\n");
   if (file_exists("sets\\.", -1, NULL))
   {
       printf("processing 'sets' directory...\n");
       chdir("sets");
       delete_all_directory_content(1);
       chdir("..");
   }
   else
       mkdir("sets");

   // default gamma correction value
   log_printf("\ninit gamma correction\n");
   glb_ds1edit.gamma = GC_100;
}


// ====================================================================================
void my_exit(void)
{
   int i;

   // close all mpq
   log_printf("\nexit close mpq\n");
   for (i=0; i < MAX_MPQ_FILE; i++)
   {
      if (glb_mpq_struct[i].is_open != FALSE)
      {
         glb_mpq = & glb_mpq_struct[i];
         mpq_batch_close();
         memset( & glb_mpq_struct[i], 0, sizeof(GLB_MPQ_S));
         glb_mpq_struct[i].is_open = FALSE;
      }
   }

   // .txt buffers
   log_printf("\nexit close txt\n");
   if (glb_ds1edit.setitems_buff != NULL)
      txt_destroy(glb_ds1edit.setitems_buff);
   if (glb_ds1edit.uniqueitems_buff != NULL)
      txt_destroy(glb_ds1edit.uniqueitems_buff);
   if (glb_ds1edit.misc_buff != NULL)
      txt_destroy(glb_ds1edit.misc_buff);
   if (glb_ds1edit.weapons_buff != NULL)
      txt_destroy(glb_ds1edit.weapons_buff);
   if (glb_ds1edit.armor_buff != NULL)
      txt_destroy(glb_ds1edit.armor_buff);

   // palette
   log_printf("\nexit close palette\n");
   if (glb_ds1edit.d2_pal)
      free(glb_ds1edit.d2_pal);

   // item colormaps
   log_printf("\nexit close colormaps\n");
   for (i=0; i < ITEM_CMAP_MAX; i++)
   {
      if (glb_ds1edit.cmap[i] != NULL)
         free(glb_ds1edit.cmap[i]);
   }
}


// ==========================================================================
// load palette of act 1
void load_palette(void)
{
   int  entry;
   char * palname = "Data\\Global\\Palette\\Act1\\pal.pl2";
   
   entry = misc_load_mpq_file(
              palname,
              & glb_ds1edit.d2_pal,
              & glb_ds1edit.pal_size,
              FALSE
           );
   if (entry == -1)
   {
      printf("error, load_palette() : couldn't load %s", palname);
      exit(1);
   }
}


// ==========================================================================
// load items colormaps
void load_colormaps(void)
{
   int  entry, i;
   char * cmap[ITEM_CMAP_MAX] = {
            NULL,
            {"Data\\Global\\Items\\Palette\\grey.dat"},
            {"Data\\Global\\Items\\Palette\\grey2.dat"},
            NULL,
            NULL,
            {"Data\\Global\\Items\\Palette\\greybrown.dat"},
            {"Data\\Global\\Items\\Palette\\invgrey.dat"},
            {"Data\\Global\\Items\\Palette\\invgrey2.dat"},
            {"Data\\Global\\Items\\Palette\\invgreybrown.dat"}
         };

   for (i=0; i < ITEM_CMAP_MAX; i++)
   {
      if (cmap[i] != NULL)
      {
         entry = misc_load_mpq_file(
                    cmap[i],
                    & glb_ds1edit.cmap[i],
                    & glb_ds1edit.cmap_size[i],
                    FALSE
                 );
         if (entry == -1)
         {
            printf("error, load_colormaps() : couldn't load %s\n", cmap[i]);
            exit(1);
         }
      }
   }
}


// ====================================================================================
int main(void)
{
   const char * str_gfx_format, * strtmp;
   char       ** background_color, dirbuff[256];
   enum       {GF_BMP, GF_PCX} gfx_format = GF_BMP;
   int        i, argc;


   // inits
   log_printf("\ninitialisation\n");
   allegro_init();
   install_keyboard();
   my_init();
   atexit(my_exit);

   // load .ini
   log_printf("\ngfxmaker.ini\n");
   set_config_file("gfxmaker.ini");
   glb_ds1edit.mod_dir[0]  = get_config_string(NULL, "mod_dir",    NULL);
   glb_ds1edit.mpq_file[0] = get_config_string(NULL, "patch_d2",   NULL);
   glb_ds1edit.mpq_file[1] = get_config_string(NULL, "d2exp",      NULL);
   glb_ds1edit.mpq_file[2] = get_config_string(NULL, "d2data",     NULL);
   str_gfx_format     = get_config_string(NULL, "gfx_format", NULL);
   if (str_gfx_format)
   {
      if (stricmp(str_gfx_format, "pcx") == 0)
         gfx_format = GF_PCX;
      else
      {
         printf("error, main() : gfx_format in gfxmaker.ini must be set to bmp or pcx\n");
         return 1;
      }
   }

   // gamma correction
   log_printf("\ngamma correction\n");
   strtmp = get_config_string(NULL, "gamma_correction", NULL);
   for (i=0; i < GC_MAX; i++)
   {
      if ( stricmp(gamma_str[i].str, strtmp) == 0)
         glb_ds1edit.gamma = gamma_str[i].val;
   }
   misc_read_gamma();

   // background color
   log_printf("\nbackground color\n");
   background_color = get_config_argv(NULL, "background_color", & argc);
   if (argc == 3)
   {
      glb_ds1edit.bg.r = atoi(background_color[0]);
      glb_ds1edit.bg.g = atoi(background_color[1]);
      glb_ds1edit.bg.b = atoi(background_color[2]);
   }

   // checking mod directory
   if ((glb_ds1edit.mod_dir[0] != NULL) && strlen(glb_ds1edit.mod_dir[0]))
   {
      printf("\nchecking Mod directory \"%s\" : ", glb_ds1edit.mod_dir[0]);
      log_printf("");
      sprintf(dirbuff, "%s\\.", glb_ds1edit.mod_dir[0]);
      if (file_exists(dirbuff, -1, NULL))
         log_printf("ok\n");
      else
         log_printf("error, don't exists\n");
   }

   // open all mpq   
   log_printf("\nopen all mpq\n");
   for (i=0; i < MAX_MPQ_FILE; i++)
   {
      if (glb_ds1edit.mpq_file[i])
      {
         printf("opening %s\n", glb_ds1edit.mpq_file[i]);
         log_printf("");
         glb_mpq = & glb_mpq_struct[i];
         mpq_batch_open((char *) glb_ds1edit.mpq_file[i]);
      }
   }

   // load .txt
   log_printf("\nload .txt\n");
   if (txt_read_set_items())
      return 1;
   if (txt_read_unique_items())
      return 1;
   if (txt_read_misc())
      return 1;
   if (txt_read_weapons())
      return 1;
   if (txt_read_armor())
      return 1;
   if (txt_read_itemtypes())
      return 1;

   // load palette used by the game (pal.pl2, not pal.dat)
   log_printf("\nload palette\n");
   load_palette();
   glb_ds1edit.d2_pal[0] = glb_ds1edit.bg.r;
   glb_ds1edit.d2_pal[1] = glb_ds1edit.bg.g;
   glb_ds1edit.d2_pal[2] = glb_ds1edit.bg.b;

   // load item colormaps
   log_printf("\nload colormaps\n");
   load_colormaps();

   // make gfx
   log_printf("\nmake uniques\n");
   make_items_uniques();

   // end
   log_printf("\nend\n");
   return 0;
}
END_OF_MAIN();
