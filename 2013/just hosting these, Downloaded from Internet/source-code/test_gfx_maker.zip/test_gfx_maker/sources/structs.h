#ifndef _STRUCTS_H_

#define _STRUCTS_H_

#define USE_CONSOLE // for allegro with VC6, in console version

#define MAX_MPQ_FILE           4
#define MAX_MOD_DIR            1
#define TXT_COL_NAME_LENGTH   30
#define ITEM_CMAP_MAX          9

/*
#define DT1_IN_DS1_MAX        33
#define DS1_MAX               10
#define DT1_MAX              300
#define ACT_MAX                5
#define FLOOR_MAX_LAYER        2
#define SHADOW_MAX_LAYER       1
#define TAG_MAX_LAYER          1
#define WALL_MAX_LAYER         4
#define OBJ_MAX              500
#define PATH_MAX             100

#define FLG_SELECTED      1
#define FLG_HIDE          2
#define FLG_TMP_SELECT    4
#define FLG_COPY_INFO     8
#define FLG_COPY_STATE   16

// these ones are only for the Edit Objects mode
#define FLG_MOUSE_OVER   32
#define FLG_MOVING       64
#define FLG_ACTIVATED   128

#define IS_SELECTED(x)    ((x) & FLG_SELECTED)
#define IS_HIDE(x)        ((x) & FLG_HIDE)
#define IS_TMP_SELECT(x)  ((x) & FLG_TMP_SELECT)
#define IS_COPY_INFO(x)   ((x) & FLG_COPY_INFO)
#define IS_COPY_STATE(x)  ((x) & FLG_COPY_STATE)
#define IS_MOUSE_OVER(x)  ((x) & FLG_MOUSE_OVER)
#define IS_MOVING(x)      ((x) & FLG_MOVING)
#define IS_ACTIVATED(x)   ((x) & FLG_ACTIVATED)

#define SET_SELECTED(x)   ((x) |= FLG_SELECTED)
#define SET_HIDE(x)       ((x) |= FLG_HIDE)
#define SET_TMP_SELECT(x) ((x) |= FLG_TMP_SELECT)
#define SET_COPY_INFO(x)  ((x) |= FLG_COPY_INFO)
#define SET_COPY_STATE(x) ((x) |= FLG_COPY_STATE)
#define SET_MOUSE_OVER(x) ((x) |= FLG_MOUSE_OVER)
#define SET_MOVING(x)     ((x) |= FLG_MOVING)
#define SET_ACTIVATED(x)  ((x) |= FLG_ACTIVATED)

#define DEL_SELECTED(x)   ((x) &= ~FLG_SELECTED)
#define DEL_HIDE(x)       ((x) &= ~FLG_HIDE)
#define DEL_TMP_SELECT(x) ((x) &= ~FLG_TMP_SELECT)
#define DEL_COPY_INFO(x)  ((x) &= ~FLG_COPY_INFO)
#define DEL_COPY_STATE(x) ((x) &= ~FLG_COPY_STATE)
#define DEL_MOUSE_OVER(x) ((x) &= ~FLG_MOUSE_OVER)
#define DEL_MOVING(x)     ((x) &= ~FLG_MOVING)
#define DEL_ACTIVATED(x)  ((x) &= ~FLG_ACTIVATED)

// Data Flags for undo, tells whiwh data are to be saved (for 1 layer)
#define DF_P1  1
#define DF_P2  2
#define DF_P3  4
#define DF_P4  8
#define DF_OR 16
#define DF_BT 32
#define DF_FL 64
*/

#include "types.h"
#include <stdio.h>
#include <allegro.h>

#include "mpq\\mpqtypes.h"

/*
extern char tiles_path[30];
extern char ds1edit_data_dir[80];
extern char ds1edit_tmp_dir[80];
*/
extern GLB_MPQ_S glb_mpq_struct[MAX_MPQ_FILE];

/*
typedef struct
{
   WORD width;
   WORD height;
   WORD depth;
} SCREEN_S;

typedef struct
{
   WORD x;
   WORD y;
} XY_S;

typedef struct
{
   XY_S keyb;
   XY_S mouse;
   XY_S edit;
   WORD obj_edit;
} SCROLL_S;
*/

typedef enum {GC_060, GC_062, GC_064, GC_066, GC_068,
              GC_070, GC_072, GC_074, GC_076, GC_078,
              GC_080, GC_082, GC_084, GC_086, GC_088,
              GC_090, GC_092, GC_094, GC_096, GC_098,
              GC_100,
              GC_110, GC_120, GC_130, GC_140, GC_150,
              GC_160, GC_170, GC_180, GC_190, GC_200,
              GC_210, GC_220, GC_230, GC_240, GC_250,
              GC_260, GC_270, GC_280, GC_290, GC_300,
              GC_MAX} GC_ENUM;

typedef struct
{
   char    str[5];
   GC_ENUM val;
} GAMMA_S;

extern GAMMA_S gamma_str[GC_MAX];

/*
typedef struct
{
   int        fullscreen;
   SCREEN_S   screen;
   SCROLL_S   scroll;
   GC_ENUM    gamma;
   XY_S       mouse_speed;
   int        normal_type2;
   int        make_max_layers;
} CONFIG_S;

extern CONFIG_S config;

typedef struct
{
   int x0;
   int y0;
   int w;
   int h;
} WIN_PREVIEW_S;

typedef enum {BS_OFF, BS_ON} BUT_STATE_E; // button state

typedef struct
{
   int         x0, y0;
   int         w, h;
   int         active;
   int         tab_have_tiles;
   BUT_STATE_E state;
   int         mouse_over;  // TRUE / FALSE
   int         need_redraw; // TRUE / FALSE
   BITMAP      * bmp[2];    // [0]=OFF, [1]=ON
} BUTTON_S;


typedef struct
{
   // border (outside)
   int        b_x0, b_y0; // upper-left corner, in the screen
   RLE_SPRITE * border;

   // inside
   int        i_x0, i_y0; // upper-left corner, in the screen
   BITMAP     * inside;
} WIN_ELEMENT_S;


typedef struct
{
   int bt_idx_tab;
   int x1;
   int y1;
   int x2;
   int y2;
   int is_draw;
} SUB_ELM_S;

typedef struct
{
   SUB_ELM_S * sub_elm;
   int       bt_idx_num;   // # of elements in * bt_idx_tab
   int       max_height;   // max height (in pixels) for this line
} MAIN_LINE_S;

typedef struct
{
   BUTTON_S      button [BU_MAX];
   BUTTON_S      tab    [BT_MAX];
   WIN_ELEMENT_S w_preview;
   WIN_ELEMENT_S w_tiles;
   MAIN_LINE_S   * main_line_tab[BT_MAX];
   int           main_line_num[BT_MAX];
   BITMAP        * tmp_edit;
} WIN_EDIT_S;

typedef enum {ZM_11, ZM_12, ZM_14, ZM_18, ZM_116, ZM_MAX} ZOOM_E;

// color map type
typedef enum {CM_SELECT, CM_TRANS, CM_SHADOW, CM_MAX} CMAP_E;

typedef enum {COL_FLOOR    =  29, // dark  grey,   selected without mouse
              COL_FLOOR_M  =  32, // light grey,   selected with mouse
              COL_WALL     = 151, // dark  blue,   selected without mouse
              COL_WALL_M   = 162, // light blue,   selected with mouse
              COL_MOUSE    = 255, // white,        not selected, with mouse
              COL_TMPSEL   =  92, // orange,       left-click selection, without mouse
              COL_TMPSEL_M = 108, // orange,       left-click selection, with mouse
              COL_PASTE_OK = 132, // green,        no conflicts when pasting
              COL_PASTE_KO =  98, // red,          conflicts when pasting
              COL_SHADOW   = 168  // yellow        shadow easy to view
              } COL_E; // tile's color index in color map

typedef enum {MOD_T, // Edit Tiles
              MOD_O, // Edit Objects
              MOD_P, // Edit Paths
              MOD_L, // Preview with Lights
              MOD_MAX} MODE_E;
              
// cof & dcc
#define COMPOSIT_NB 16

typedef struct
{
   UBYTE  trans_a;
   UBYTE  trans_b;
   char   wclass[4];

   // editor only
   int    bmp_num;
   BITMAP ** bmp;
   int    off_x;
   int    off_y;
   int    last_good_frame;
} LAY_INF_S;

typedef struct
{
   UBYTE     lay;
   UBYTE     fpd;
   UBYTE     dir;
   long      xoffset;
   long      yoffset;
   LAY_INF_S lay_inf[COMPOSIT_NB];
   UBYTE     * priority;
   long      cur_frame;
   int       cur_dir;
   long      spd_mul;
   long      spd_div;
   long      spd_mod; // = is (mul % div), for extra precision
} COF_S;

typedef struct
{
   int   act;
   int   type;
   int   id;
   char  * desc;
   COF_S * cof;
   int   objects_line;
   int   monstats_line;
   int   usage_count;
} OBJ_DESC_S;

// struct for convenience, for undo
// if bit is set, indicate that this data of this layer is to be save
typedef struct
{
   UBYTE f[FLOOR_MAX_LAYER];
   UBYTE s[SHADOW_MAX_LAYER];
   UBYTE w[WALL_MAX_LAYER];
} UNDO_DAT_FLG_S;

typedef struct
{
   FILE           * fptr;
   long           buf_num;
   long           cur_buf_num;
   char           name[150];
   char           tag[4];
   int            in_seg;
   long           seg_offset;
   UBYTE          seg_num;
   long           cell_offset;
   UBYTE          cell_num;
   UBYTE          old_x, old_y;
   UNDO_DAT_FLG_S dat_flg;
} UNDO_S;

*/
typedef enum {CT_NULL, CT_STR, CT_NUM} COL_TYPE_NM;

typedef struct
{
   // for loading function
   char        name[TXT_COL_NAME_LENGTH]; // column header

   // fill by loading function
   int         pos;      // column index in the original file
   COL_TYPE_NM type;     // string or num
   int         size;     // strlen()+1 or sizeof(long)
   int         offset;   // offset in a line to get the data
} TXT_COL_S;

typedef struct
{
   char      * data;     // buffer having all lines
   int       line_num;   // number of lines
   int       line_size;  // size of 1 line (in bytes)
   int       col_num;    // number of columns
   TXT_COL_S * col;      // pointer on a table of TXT_COL_S
} TXT_S;

typedef struct
{
   UBYTE data[21][256];
} ITEM_CMAP_S;

typedef struct
{
   const char    * mpq_file[MAX_MPQ_FILE];
   const char    * mod_dir[MAX_MOD_DIR];
   UBYTE         * d2_pal;
   int           pal_size;
   ITEM_CMAP_S   * cmap[ITEM_CMAP_MAX];
   int           cmap_size[ITEM_CMAP_MAX];
   GC_ENUM       gamma;
   UBYTE         gamma_table[GC_MAX][256];
   RGB           bg;
/*
   PALETTE       vga_pal  [ACT_MAX];
   PALETTE       dummy_pal;
   int           pal_loaded[ACT_MAX];
   BITMAP        * mouse_cursor[MOD_MAX];
   WIN_PREVIEW_S win_preview;
   WIN_EDIT_S    win_edit;
   BITMAP        * big_screen_buff, * screen_buff;
   GC_ENUM       cur_gamma;
   volatile int  old_fps;
   volatile int  fps;
   volatile int  ticks_elapsed;
   int           screenshot_num;
   COLOR_MAP     cmap[CM_MAX][ACT_MAX];
   OBJ_DESC_S    * obj_desc;
   int           obj_desc_num; // # of objects's description
   MODE_E        mode;
   RLE_SPRITE    * subtile_flag[9][ZM_MAX][25];
   RLE_SPRITE    * subtile_nowalk[ZM_MAX][25];
   RLE_SPRITE    * subtile_nojump[ZM_MAX][25];
   BITMAP        * subtile_help;
   int           night_mode;
*/
   TXT_S         * setitems_buff;
   TXT_S         * uniqueitems_buff;
   TXT_S         * misc_buff;
   TXT_S         * weapons_buff;
   TXT_S         * armor_buff;
   TXT_S         * itemtypes_buff;
/*
   int           new_dir1[1],
                 new_dir4[4],
                 new_dir8[8],
                 new_dir16[16],
                 new_dir32[32];
   int           obj_order_ds1_idx;
   int           obj_sub_tile_order[5][5];
   char          version[15];
   int           current_refresh_rate;
   int           col_obj_id;
   int           col_objects_id;
   int           col_frame_delta[8];
*/
} GLB_DS1EDIT_S;

extern GLB_DS1EDIT_S glb_ds1edit;

/*
typedef struct
{
   // key
   int       dt1_idx;
   long      main_index;
   long      orientation;
   long      sub_index;

   // datas
   long      rarity;
   int       block_idx;
   BLK_TYP_E type;
   int       zero_line;
   int       roof_y;

   // conflicts managment
   char      conflict;
   char      used_by_game;   // True / False
   char      used_by_editor; // True / False
} BLOCK_TABLE_S;

typedef struct
{
   int x;
   int y;
   int action;
} PATH_S;

typedef struct
{
   int rx, ry; // upper/left corner of the label, relative to the sub-cell
               // (in pixels, at zoom of 1:1)
   int w, h;   // width & height (pixels)
   int x0, y0; // pixels position on screen
   int flags;
   
   // for moving
   int old_rx;
   int old_ry;
       
} OBJ_LABEL_S;

typedef struct
{
   long        type;
   long        id;
   long        x;     // sub-cell X
   long        y;     // sub-cell Y
   long        ds1_flags;
   PATH_S      path[PATH_MAX];
   long        path_num;
   int         desc_idx;
   int         flags;
   OBJ_LABEL_S label;

   // for moving
   int         old_x;
   int         old_y;

   // for sorting
   int         tx; // tile X
   int         ty; // tile Y
   int         sx; // sub-tile X
   int         sy; // sub-tile Y
} OBJ_S;

typedef struct
{
   int x1, y1, x2, y2;
} BOX_S;

typedef struct
{
   BOX_S box;
   XY_S  txt;
   char  name[10];
   int   flags;
} EDT_BUT_S;

typedef enum {EB_OK, EB_CANCEL, EB_TYPE1, EB_TYPE2,
              EB_ACT1, EB_ACT2, EB_ACT3, EB_ACT4, EB_ACT5,
              EB_MAX} EDT_BUT_E; // edit obj buttons
              
typedef struct
{
   // window itself
   int x0, y0;
   int w, h;
   int obj_idx;
   int cur_type;
   int start_act;
   int cur_act;

   // buttons
   EDT_BUT_S button[EB_MAX]; // OK, Cancel, Type1, Type2, ACT1, 2, 3, 4, 5

   // text
   int num;        // number of row to display
   int start;      // index of the win's 1st row
   int cur;        // current index, pointed by the mouse

   int desc_char;  // max chars of description
   int desc_start; // starting index in glb_ds1edit.obj_desc[]
   int desc_num;   // number of description for this act
   int desc_end;   // ending index
   int desc_cur;   // curent selected index (the object's one before editing)
} WIN_EDT_OBJ_S;

typedef struct
{
   UBYTE prop1;
   UBYTE prop2;
   UBYTE prop3;
   UBYTE prop4;
   UBYTE orientation;
   int   bt_idx;
   UBYTE flags;
} CELL_W_S;

typedef struct
{
   UBYTE prop1;
   UBYTE prop2;
   UBYTE prop3;
   UBYTE prop4;
   int   bt_idx;
   UBYTE flags;
} CELL_F_S;

typedef struct // exactly the same struct for shadow as for the floor
{
   UBYTE prop1;
   UBYTE prop2;
   UBYTE prop3;
   UBYTE prop4;
   int   bt_idx;
   UBYTE flags;
} CELL_S_S;

typedef struct
{
   // assume the data is 1 dword, and not 4 different bytes
   UDWORD num;
} CELL_T_S;

typedef struct
{
   UDWORD tile_x;
   UDWORD tile_y;
   UDWORD width;
   UDWORD height;
   UDWORD unk;
} GROUP_S;

typedef struct
{
   char          dt1_idx[DT1_IN_DS1_MAX];
   UBYTE         dt1_mask[DT1_IN_DS1_MAX];
   int           txt_act;
   BLOCK_TABLE_S * block_table;
   int           bt_num;
   UBYTE         wall_layer_mask[WALL_MAX_LAYER];
   UBYTE         floor_layer_mask[FLOOR_MAX_LAYER];
   char          shadow_layer_mask[SHADOW_MAX_LAYER];
   UBYTE         objects_layer_mask; // 0 = no info, 1 = Type-Id, 2 = desc from obj.tx
   UBYTE         paths_layer_mask;
   UBYTE         walkable_layer_mask;
   UBYTE         animations_layer_mask;
   UBYTE         special_layer_mask;
   int           subtile_help_display;
   char          name[256];
   UNDO_S        undo;

   // from file
   long          version;
   long          tag_type;
   long          width;  // from file, +1
   long          height; // from file, +1
   long          act;

   // files in the ds1 (not used by the game)
   long          file_num;
   char          * file_buff;
   int           file_len;
   
   // floors
   CELL_F_S      * floor_buff,   // buffer for all floor layers
                 * floor_buff2;  // 2nd buffer, for copy/paste
   int           floor_buff_len; // sizeof the floor buffer (in bytes)
   int           floor_num;      // # of layers in floor buffer
   int           floor_line;     // width * floor_num
   int           floor_len;      // floor_line * height
   
   // shadow
   CELL_S_S      * shadow_buff,   // buffer for all shadow layers
                 * shadow_buff2;  // 2nd buffer, for copy/paste
   int           shadow_buff_len; // sizeof the shadow buffer (in bytes)
   int           shadow_num;      // # of layers in shadow buffer
   int           shadow_line;     // width * shadow_num
   int           shadow_len;      // shadow_line * height
   
   // walls
   CELL_W_S      * wall_buff,    // buffer for all wall layers
                 * wall_buff2;   // 2nd buffer, for copy/paste
   int           wall_buff_len;  // sizeof the wall buffer (in bytes)
   int           wall_num;       // # of layers in wall buffer
   int           wall_line;      // width * wall_num
   int           wall_len;       // wall_line * height

   // tag
   CELL_T_S      * tag_buff,   // buffer for all unk layers
                 * tag_buff2;  // 2nd buffer, for copy/paste
   int           tag_buff_len; // sizeof the unk buffer (in bytes)
   int           tag_num;      // # of layers in unk buffer
   int           tag_line;     // width * unk_num
   int           tag_len;      // unk_line * height

   // groups for tag layer
   long          group_num;
   int           group_size;
   GROUP_S       * group;

   // internal
   ZOOM_E        cur_zoom;
   int           tile_w;
   int           tile_h;
   int           height_mul;
   int           height_div;
   SCROLL_S      cur_scroll;

   // screen position and size for this ds1
   WIN_PREVIEW_S own_wpreview;
   
   // objects and npc paths (paths are in obj struct)
   int           drawing_order[OBJ_MAX];
   OBJ_S         obj[OBJ_MAX];
   OBJ_S         obj_undo[OBJ_MAX];
   long          obj_num;
   long          obj_num_undo;
   int           can_undo_obj;
   int           draw_edit_obj; // edit Type-Id of objects, FALSE / TRUE
   WIN_EDT_OBJ_S win_edt_obj;
   
} DS1_S;

extern DS1_S ds1[DS1_MAX];

typedef struct
{
   long       direction;
   WORD       roof_y;
   UBYTE      sound;
   UBYTE      animated;
   long       size_y;
   long       size_x;
   // long       zeros1;
   long       orientation;
   long       main_index;
   long       sub_index;
   long       rarity;
   UBYTE      sub_tiles_flags[25];
   // int        zeros2[7];
   long       tiles_ptr;
   long       tiles_length;
   long       tiles_number;
   // int        zeros3[12];
} BLOCK_S;

typedef struct
{
   int        ds1_usage; // current number of ds1 using this dt1
   char       name[80];
   void       * buffer;
   long       buff_len;
   long       x1; // signature (7)
   long       x2; // signature (6)
   long       block_num;
   long       bh_start;
   
   // block headers : block_num structs of BLOCK_S
   void       * bh_buffer;
   int        bh_buff_len;

   // all blocks in differents zoom format
   BITMAP     ** block_zoom[ZM_MAX]; // ZM_MAX tables of table of pointers
                                     //   to BITMAP
   int        bz_size[ZM_MAX];
} DT1_S;

extern DT1_S dt1[DT1_MAX];

typedef struct
{
   WORD  x_pos;
   WORD  y_pos;
   //   WORD  unknown1;
   int   x_grid;
   int   y_grid;
   WORD  format;
   long  length;
   //   WORD  unknown2;
   long  data_offset;
} SUB_TILE_S;

typedef struct
{
   int idx;
   int height;
} ORDER_DATA_S;

typedef struct
{
   enum {TMP_NULL, TMP_NEW, TMP_ADD, TMP_DEL, TMP_HIDE} type;
   int start;
   int x1, y1, x2, y2, old_x2, old_y2;
} TMP_SEL_S;

typedef struct
{
   int src_ds1_idx;
   int start;
   int start_x, start_y, old_x, old_y, old_ds1_idx;
} PASTE_POS_S;

typedef enum {IT_NULL, IT_NEW, IT_ADD, IT_DEL} IT_ENUM; // Identical Type
*/

// txt required cols
typedef enum {
   RQ_SETITEMS,
   RQ_UNIQUEITEMS,
   RQ_MISC, RQ_WEAPONS, RQ_ARMOR,
   RQ_ITEMTYPES,
   RQ_MAX
} RQ_ENUM;

extern char ** txt_req_ptr[RQ_MAX];

#endif
