#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FALSE 0
#define TRUE -1

typedef unsigned char      UBYTE;
typedef short int          WORD;
typedef unsigned short int UWORD;
typedef unsigned long      UDWORD;

#define USE_CONSOLE
#include <allegro.h>

#pragma pack(1)

   typedef struct
   {
      long  version;        // 6
      long  unknown1;       // 1 normally, but 5 for SGDirect3D truecolor images
      long  unknown2;       // 0
      UBYTE termination[4]; // 0xEEEEEEEE or 0xCDCDCDCD
      long  directions;
      long  frames_per_dir;
   } DC6_HEADER_S;

   typedef struct
   {
      long flip;
      long width;
      long height;
      long offset_x;
      long offset_y;        // from bottom border, not up
      long unknown2;
      long next_block;
      long length;
   } DC6_FRAME_HEADER_S;

#pragma pack()

BITMAP   * my_truecolor_bmp = NULL;
PALETTE  my_pal;
char     strtmp[512];
typedef  enum {FM_RGB, FM_BGR, FM_RGBZ, FM_BGRZ, FM_ZRGB, FM_ZBGR} FORMAT_E;
FORMAT_E format = FM_BGR;
void     * dc6buffer = NULL;
struct
{
   int w;
   int h;
   int start_frm;
} page[256];
int dir_nb_pag[256];
int pages_max = 0;
int option_page = FALSE;

#pragma pack(1)

   typedef struct
   {
      UBYTE r;
      UBYTE g;
      UBYTE b;
      UBYTE z;
   } RGB_S;

   typedef struct
   {
      UBYTE b;
      UBYTE g;
      UBYTE r;
      UBYTE z;
   } BGR_S;

#pragma pack()

typedef union
{
   RGB_S rgb;
   long  dw;
} RGB_DW_U;
RGB_DW_U trans;



// ==========================================================================
void * load_dc6_in_mem(char * dc6_name)
{
   FILE * in;
   void * ptr;
   long size;

   in = fopen(dc6_name, "rb");
   if (in == NULL)
   {
      printf("can't open dc6 file \"%s\"\n", dc6_name);
      exit(1);
   }
   fseek(in, 0, SEEK_END);
   size = ftell(in);
   fseek(in, 0, SEEK_SET);
   ptr = (void *) malloc(size);
   if (ptr == NULL)
   {
      printf("not enough mem (%li) for loading \"%s\" in mem", size, dc6_name);
      fclose(in);
      exit(1);
   }
   fread(ptr, size, 1, in);
   
   // ok
   fclose(in);
   return ptr;
}


// ==========================================================================
void decompress_dc6_frame(void * src, long size, int x0, int y0)
{
   UBYTE * ptr = (UBYTE *) src;
   long  i;
   int   i2, x, y, c, c2;
   int   r, g, b;


   x = x0;
   y = y0;
   for (i=0; i < size; i++)
   {
      c = * ptr; ptr++;

      if (c == 0x80)
      {
         x = x0;
         y--;
      }
      else if (c & 0x80)
         x += c & 0x7F;
      else
      {
         for (i2=0; i2 < c; i2++)
         {
            switch(format)
            {
               case FM_RGB :
                  r = * ptr; ptr++;
                  g = * ptr; ptr++;
                  b = * ptr; ptr++;
                  i += 3;
                  break;

               case FM_BGR :
                  b = * ptr; ptr++;
                  g = * ptr; ptr++;
                  r = * ptr; ptr++;
                  i += 3;
                  break;

               case FM_RGBZ :
                  r = * ptr; ptr++;
                  g = * ptr; ptr++;
                  b = * ptr; ptr += 2;
                  i += 4;
                  break;

               case FM_BGRZ :
                  b = * ptr; ptr++;
                  g = * ptr; ptr++;
                  r = * ptr; ptr += 2;
                  i += 4;
                  break;

               case FM_ZRGB :
                  ptr++;
                  r = * ptr; ptr++;
                  g = * ptr; ptr++;
                  b = * ptr; ptr++;
                  i += 4;
                  break;

               case FM_ZBGR :
                  ptr++;
                  b = * ptr; ptr++;
                  g = * ptr; ptr++;
                  r = * ptr; ptr++;
                  i += 4;
                  break;
            }
            c2 = makecol(r, g, b);
            putpixel(my_truecolor_bmp, x, y, c2);
            x++;
         }
      }
   }
}


// ==========================================================================
void search_direction_pages(int d)
{
   DC6_HEADER_S       * head = (DC6_HEADER_S *) dc6buffer;
   DC6_FRAME_HEADER_S * frm = NULL;
   UBYTE              * bptr;
   long               * offset;
   int                f;
   int                page_w, page_h, line_w, line_h;
   int                same_page, same_line;
   int                p_idx = 0;


   // inits
   if (head == NULL)
      exit(1);

   bptr    = (UBYTE *) head;
   bptr   += sizeof(DC6_HEADER_S);
   offset  = (long *) bptr;
   offset += d * head->frames_per_dir;

   memset(page, 0, sizeof(page));

   f     = 0;
   bptr  = (UBYTE *) head;
   bptr += offset[f];
   frm   = (DC6_FRAME_HEADER_S *) bptr;

   while (f < head->frames_per_dir)
   {
      // new page
      page[p_idx].start_frm = (d * head->frames_per_dir) + f;
      page_w = 0;
      page_h = 0;
      same_page = TRUE;
      while (same_page)
      {
         // new line
         line_w = 0;
         line_h = 0;
         same_line = TRUE;
         while (same_line)
         {
            if (line_h == 0)
            {
               // 1st frame of this line
               line_w = frm->width;
               line_h = frm->height;
            }
            else
            {
               // >= 2nd frame of this line
               if (frm->height == line_h)
               {
                  // this frame is part of this line
                  line_w += frm->width;
               }
               else
               {
                  // this frame is in another line / page
                  same_line = FALSE;
               }
            }

            // is it the last frame of this line ?
            if (frm->width != 256)
            {
               // this frame end the line
               same_line = FALSE;
            }

            // next frame ?
            if (same_line)
            {
               f++;
               if (f < head->frames_per_dir)
               {
                  bptr  = (UBYTE *) head;
                  bptr += offset[f];
                  frm   = (DC6_FRAME_HEADER_S *) bptr;
               }
               else
                  same_line = FALSE;
            }
         }
         // this line has ended, compare it with the precedent line
         if (page_h == 0)
         {
            // 1st line of page
            page_w = line_w;
            page_h = line_h;
         }
         else
         {
            // >= 2nd line of this page
            if (line_w == page_w)
            {
               // this line is part of this page
              page_h += line_h;
            }
            else
            {
               // this line was in a new page
               same_page = FALSE;
            }
         }

         // is it the last line of this page ?
         if (line_h != 256)
         {
            // this line end the page
            same_page = FALSE;
         }

         // next frame
         f++;
         if (f < head->frames_per_dir)
         {
            bptr  = (UBYTE *) head;
            bptr += offset[f];
            frm   = (DC6_FRAME_HEADER_S *) bptr;
         }
         else
            same_page = FALSE;

         // end of page ?
         if (same_page == FALSE)
         {
            // this page has ended,
            if (p_idx >= 256)
            {
               printf("unexpected error : dc6 should have at most 256 pages\n");
               exit(1);
            }
            page[p_idx].w = page_w;
            page[p_idx].h = page_h;
            p_idx++;
         }
      }
   }

   // end
   pages_max = p_idx;
}


// ==========================================================================
void make_pcx(void)
{
   DC6_HEADER_S       * head = (DC6_HEADER_S *) dc6buffer;
   DC6_FRAME_HEADER_S * frm = NULL;
   int                nb_frm, i, width, found_width, found_height,
                      curr_f, x, y;
   long               * offset, size;
   UBYTE              * bptr;


   // inits
   if (head == NULL)
      exit(1);

   printf("   version        = %li\n", head->version);
   printf("   unknown1       = %li\n", head->unknown1);
   printf("   unknown2       = %li\n", head->unknown2);
   printf("   termination    = 0x%02X 0x%02X 0x%02X 0x%02X\n",
      head->termination[0],
      head->termination[1],
      head->termination[2],
      head->termination[3]
   );
   printf("   directions     = %li\n", head->directions);
   printf("   frames per dir = %li\n", head->frames_per_dir);
   if ((head->version != 6) || (head->unknown1 != 5) || (head->unknown2 != 0) ||
       (head->directions != 1))
   {
      printf("not an expected dc6 :\n");
      exit(1);
   }
   nb_frm  = head->directions * head->frames_per_dir;
   bptr    = (UBYTE *) head;
   bptr   += sizeof(DC6_HEADER_S);
   offset  = (long *) bptr;

   // search width and height
   found_width  = -1;
   found_height = 0;
   width        = 0;
   for (i=0; i < nb_frm; i++)
   {
      bptr  = (UBYTE *) head;
      bptr += offset[i];
      frm   = (DC6_FRAME_HEADER_S *) bptr;

      printf("\nframe %3i :\n", i);
      printf("   flip       = %li\n", frm->flip);
      printf("   width      = %li\n", frm->width);
      printf("   height     = %li\n", frm->height);
      printf("   offset_x   = %li\n", frm->offset_x);
      printf("   offset_y   = %li\n", frm->offset_y);
      printf("   unknown2   = %li\n", frm->unknown2);
      printf("   next_block = %li\n", frm->next_block);
      printf("   length     = %li\n", frm->length);

      if (frm->width == 256)
         width += 256;
      else
      {
         width += frm->width;
         if (found_width != -1)
         {
            if (width != found_width)
            {
               printf("error, can't find width of the image\n");
               exit(1);
            }
            width = 0;
         }
         else
         {
            found_width   = width;
            width         = 0;
         }
         found_height += frm->height;
      }
   }
   printf("   image to create : %i * %i pixels\n", found_width, found_height);

   // create bmp
   my_truecolor_bmp = create_bitmap(found_width, found_height);
   if (my_truecolor_bmp == NULL)
   {
      printf("can't create internal truecolor image\n");
      exit(1);
   }
   clear_to_color(
      my_truecolor_bmp,
      makecol(trans.rgb.r, trans.rgb.g, trans.rgb.b)
   );

   // make truecolor image
   curr_f = 0;
   for (y=0; y < found_height; y += 256)
   {
      for (x=0; x < found_width; x += 256)
      {
         // get frame header
         bptr  = (UBYTE *) head;
         bptr += offset[curr_f];
         frm   = (DC6_FRAME_HEADER_S *) bptr;

         size  = frm->length;
         bptr += sizeof(DC6_FRAME_HEADER_S);

         decompress_dc6_frame(bptr, size, x, y + frm->height - 1);

         curr_f++;
      }
   }
}


// ==========================================================================
void make_pcx_page(char * filename)
{
   DC6_HEADER_S       * head = (DC6_HEADER_S *) dc6buffer;
   DC6_FRAME_HEADER_S * frm = NULL;
   int                curr_f, x, y;
   long               * offset, size, d, p;
   UBYTE              * bptr;
   char               buff[30];


   // inits
   if (head == NULL)
      exit(1);

   printf("   version        = %li\n", head->version);
   printf("   unknown1       = %li\n", head->unknown1);
   printf("   unknown2       = %li\n", head->unknown2);
   printf("   termination    = 0x%02X 0x%02X 0x%02X 0x%02X\n",
      head->termination[0],
      head->termination[1],
      head->termination[2],
      head->termination[3]
   );
   printf("   directions     = %li\n", head->directions);
   printf("   frames per dir = %li\n", head->frames_per_dir);
   if ((head->version != 6) || (head->unknown1 != 5) || (head->unknown2 != 0) ||
       (head->directions != 1))
   {
      printf("not an expected dc6 :\n");
      exit(1);
   }

   bptr    = (UBYTE *) head;
   bptr   += sizeof(DC6_HEADER_S);
   offset  = (long *) bptr;

   for (d=0; d < head->directions; d++)
   {
      search_direction_pages(d);
      for (p=0; p < pages_max; p++)
      {
         printf("   image to create : %i * %i pixels\n", page[p].w, page[p].h);

         // create bmp
         my_truecolor_bmp = create_bitmap(page[p].w, page[p].h);
         if (my_truecolor_bmp == NULL)
         {
            printf("can't create internal truecolor image\n");
            exit(1);
         }
         clear_to_color(
            my_truecolor_bmp,
            makecol(trans.rgb.r, trans.rgb.g, trans.rgb.b)
         );

         // make truecolor image
         curr_f = page[p].start_frm;
         for (y=0; y < page[p].h; y += 256)
         {
            for (x=0; x < page[p].w; x += 256)
            {
               // get frame header
               bptr  = (UBYTE *) head;
               bptr += offset[curr_f];
               frm   = (DC6_FRAME_HEADER_S *) bptr;

               size  = frm->length;
               bptr += sizeof(DC6_FRAME_HEADER_S);

               decompress_dc6_frame(bptr, size, x, y + frm->height - 1);

               curr_f++;
            }
         }

         // save page pcx
         strcpy(strtmp, filename);
         strtmp[strlen(filename) - 4] = 0x00;
         sprintf(buff, "_dir%03i_page%03i_NEW.pcx", d+1, p+1);
         strcat(strtmp, buff);
         save_pcx(strtmp, my_truecolor_bmp, NULL);
      }
   }
}


// ============================================================================
void my_truecolor_init(void)
{
   allegro_init();
   set_color_depth(32);
   if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0) < 0)
   {
      set_color_depth(24);
      if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0) < 0)
      {
         set_color_depth(32);
         if (set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, 640, 480, 0, 0) < 0)
         {
            set_color_depth(24);
            if (set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, 640, 480, 0, 0) < 0)
            {
               printf("error : can't init a 640*480 video mode of 32 or 24 bpp\n");
               exit(1);
            }
         }
      }
   }
}


// ============================================================================
void my_load_image(char * filename)
{
   BITMAP * bmp;


   bmp = load_bitmap(filename, my_pal);
   if (bmp == NULL)
   {
      printf("can't load %s\n", filename);
      exit(1);
   }
   my_truecolor_bmp = create_bitmap(bmp->w, bmp->h);
   if (my_truecolor_bmp == NULL)
   {
      printf("can't create internal truecolor image\n");
      exit(1);
   }
   if (bitmap_color_depth(bmp) == 8)
   {
      // there's a palette
      set_palette(my_pal);
   }

   // convert any kind of loaded image into the truecolor image
   blit(bmp, my_truecolor_bmp, 0, 0, 0, 0, bmp->w, bmp->h);

   // end
   destroy_bitmap(bmp);
}


// ============================================================================
void my_exit(void)
{
   if (my_truecolor_bmp != NULL)
      destroy_bitmap(my_truecolor_bmp);

   if (dc6buffer != NULL)
      free(dc6buffer);
}


// ============================================================================
int make_dc6_frame(FILE * out, BITMAP * src, int x0, int y0, int w, int h)
{
   BITMAP   * sub;
   int      done, n, i, x, y;
   long     pix;
   RGB_DW_U color;


   sub = create_sub_bitmap(src, x0, y0, w, h);
   if (sub == NULL)
      return -1;

   // inits
   color.dw = 0; // all members set to 0
   x        = 0;
   y        = h - 1;
   done     = FALSE;

   // loop
   while (! done)
   {
      // End Of Line ?
      n           = 0;
      pix         = getpixel(sub, x+n, y);
      color.rgb.r = getr(pix);
      color.rgb.g = getg(pix);
      color.rgb.b = getb(pix);
      while ((color.dw == trans.dw) && (x+n < w))
      {
         n++;
         pix         = getpixel(sub, x+n, y);
         color.rgb.r = getr(pix);
         color.rgb.g = getg(pix);
         color.rgb.b = getb(pix);
      }
      if (x+n >= w)
      {
         // EOL
         fputc(0x80, out);
         x = 0;
         y--;
         if (y < 0)
            done = TRUE;
      }
      else
      {
         if (n)
         {
            // JUMPS
            while (n >= 0x7F)
            {
               fputc(0xFF, out);
               n -= 0x7F;
               x += 0x7F;
            }
            if (n)
               fputc(0x80 | n, out);
         }

         // PIXELS
         x           += n;
         n            = 0;
         pix          = getpixel(sub, x+n, y);
         color.rgb.r  = getr(pix);
         color.rgb.g  = getg(pix);
         color.rgb.b  = getb(pix);
         while ((color.dw != trans.dw) && (x+n < w))
         {
            n++;
            pix         = getpixel(sub, x+n, y);
            color.rgb.r = getr(pix);
            color.rgb.g = getg(pix);
            color.rgb.b = getb(pix);
         }
         if (n)
         {
            while (n >= 0x7F)
            {
               fputc(0x7F, out);
               for (i=0; i < 0x7F; i++)
               {
                  pix          = getpixel(sub, x+i, y);
                  color.rgb.r  = getr(pix);
                  color.rgb.g  = getg(pix);
                  color.rgb.b  = getb(pix);
                  switch(format)
                  {
                     case FM_RGB :
                        fputc(color.rgb.r, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.b, out);
                        break;

                     case FM_BGR :
                        fputc(color.rgb.b, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.r, out);
                        break;

                     case FM_RGBZ :
                        fputc(color.rgb.r, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.b, out);
                        fputc(0, out);
                        break;

                     case FM_BGRZ :
                        fputc(color.rgb.b, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.r, out);
                        fputc(0, out);
                        break;

                     case FM_ZRGB :
                        fputc(0, out);
                        fputc(color.rgb.r, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.b, out);
                        break;

                     case FM_ZBGR :
                        fputc(0, out);
                        fputc(color.rgb.b, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.r, out);
                        break;
                  }
               }
               n -= 0x7F;
               x += 0x7F;
            }
            if (n)
            {
               fputc(n, out);
               for (i=0; i < n; i++)
               {
                  pix          = getpixel(sub, x+i, y);
                  color.rgb.r  = getr(pix);
                  color.rgb.g  = getg(pix);
                  color.rgb.b  = getb(pix);
                  switch(format)
                  {
                     case FM_RGB :
                        fputc(color.rgb.r, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.b, out);
                        break;

                     case FM_BGR :
                        fputc(color.rgb.b, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.r, out);
                        break;

                     case FM_RGBZ :
                        fputc(color.rgb.r, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.b, out);
                        fputc(0, out);
                        break;

                     case FM_BGRZ :
                        fputc(color.rgb.b, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.r, out);
                        fputc(0, out);
                        break;

                     case FM_ZRGB :
                        fputc(0, out);
                        fputc(color.rgb.r, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.b, out);
                        break;

                     case FM_ZBGR :
                        fputc(0, out);
                        fputc(color.rgb.b, out);
                        fputc(color.rgb.g, out);
                        fputc(color.rgb.r, out);
                        break;
                  }
               }
               x += n;
               n = 0;
            }
         }
      }
   }
   
   // termination bytes
   for (i=0; i < 3; i++)
      fputc(0xEE, out);
   
   destroy_bitmap(sub);
   return 0;
}


// ============================================================================
void my_make_dc6 (char * filename)
{
   DC6_HEADER_S       header;
   DC6_FRAME_HEADER_S frame;
   FILE               * out;
   int                size, curr_block, x, y;
   long               * block_ptr, block_start, datas_start, datas_end;
   

   strcpy(strtmp, filename);
   strtmp[strlen(filename) - 4] = 0x00;
   strcat(strtmp, ".dc6");

   out = fopen(strtmp, "wb");
   if (out == NULL)
   {
      printf("can't create %s\n", strtmp);
      exit(1);
   }
      
   // make & write dc6 header
   header.version        = 0x00000006L;
   header.unknown1       = 0x00000005L; // SGDirect3D truecolor variation
   header.unknown2       = 0x00000000L;
   header.termination[0] = 0xEE;
   header.termination[1] = 0xEE;
   header.termination[2] = 0xEE;
   header.termination[3] = 0xEE;
   header.directions     = 1;

   // compute how many dc6 blocks
   header.frames_per_dir =
      (1 + (my_truecolor_bmp->w / 256)) * (1 + (my_truecolor_bmp->h / 256));

   size = sizeof(long) * header.frames_per_dir;
   block_ptr = (long *) malloc(size);
   if (block_ptr == NULL)
   {
      printf("can't allocate %li block pointer%s (%i bytes)\n",
         header.frames_per_dir,
         header.frames_per_dir > 1L ? "s" : "",
         size
      );
      fclose(out);
      exit(1);
   }
   memset(block_ptr, 0, size);

   // write dc6 header
   fwrite(& header, sizeof(DC6_HEADER_S), 1, out);
   fflush(out);

   // block pointers (unknown values for now)
   block_start = ftell(out);
   fwrite(block_ptr, 4, header.frames_per_dir, out);
   fflush(out);

   curr_block = 0;

   memset( & frame, 0, sizeof(DC6_FRAME_HEADER_S));

   // for all blocks of at most 256*256 pixels of the image
   for (y=0; y < my_truecolor_bmp->h; y += 256)
   {
      for (x=0; x < my_truecolor_bmp->w; x += 256)
      {
         frame.width = my_truecolor_bmp->w - x;
         if (frame.width > 256)
            frame.width = 256;

         frame.height = my_truecolor_bmp->h - y;
         if (frame.height > 256)
            frame.height = 256;

         // incomplete frame header
         block_ptr[curr_block] = ftell(out);
         fwrite(& frame, sizeof(DC6_FRAME_HEADER_S), 1, out);
         fflush(out);

         // block encoded pixels
         datas_start = ftell(out);
         if (make_dc6_frame(out, my_truecolor_bmp, x, y, frame.width, frame.height))
         {
            printf("couldn't save block %i\n", curr_block);
            fclose(out);
            free(block_ptr);
            exit(1);
         }
         fflush(out);

         // frame header
         datas_end        = ftell(out);
         frame.length     = datas_end - datas_start - 3;
         frame.next_block = datas_end;
         fseek(out, block_ptr[curr_block], SEEK_SET);
         fwrite(& frame, sizeof(DC6_FRAME_HEADER_S), 1, out);
         fflush(out);
         fseek(out, datas_end, SEEK_SET);

         // next block
         curr_block++;
      }
   }

   // update frame header pointers
   fflush(out);
   fseek(out, block_start, SEEK_SET);
   fwrite(block_ptr, 4, header.frames_per_dir, out);
   fflush(out);

   // end
   fclose(out);
   free(block_ptr);
   printf(
      "%s :\n"
      "   image of %i * %i pixels has been dc6-encoded into %i * %i frames\n",
      filename,
      my_truecolor_bmp->w,
      my_truecolor_bmp->h,
      1 + (my_truecolor_bmp->w / 256),
      1 + (my_truecolor_bmp->h / 256)
   );
}


// ============================================================================
void my_make_dc6_page (char * filename)
{
   DC6_HEADER_S       header;
   DC6_FRAME_HEADER_S frame;
   FILE               * out;
   int                size, curr_block, x, y, d, p;
   long               * block_ptr, block_start, datas_start, datas_end;
   char               buff[30];
   BITMAP             * bmp;
   long               nb_dir;


   

   // count how many dir & page
   header.frames_per_dir = 0;
   for (d=0; d < 256; d++)
   {
      for (p=0; p < 256; p++)
      {
         strcpy(strtmp, filename);
         strtmp[strlen(filename) - 4] = 0x00;
         sprintf(buff, "_dir%03i_page%03i.pcx", d+1, p+1);
         strcat(strtmp, buff);
         bmp = load_bitmap(strtmp, my_pal);
         if (bmp == NULL)
         {
            dir_nb_pag[d] = p;
            if (p == 0)
            {
               nb_dir = d;
               d = 256;
            }
            p = 256;
         }
         else
         {
            header.frames_per_dir += (1 + (bmp->w / 256)) * (1 + (bmp->h / 256));
         }
      }
   }

   strcpy(strtmp, filename);
   strtmp[strlen(filename) - 4] = 0x00;
   strcat(strtmp, ".dc6");

   out = fopen(strtmp, "wb");
   if (out == NULL)
   {
      printf("can't create %s\n", strtmp);
      exit(1);
   }
      
   // make & write dc6 header
   header.version        = 0x00000006L;
   header.unknown1       = 0x00000005L; // SGDirect3D truecolor variation
   header.unknown2       = 0x00000000L;
   header.termination[0] = 0xEE;
   header.termination[1] = 0xEE;
   header.termination[2] = 0xEE;
   header.termination[3] = 0xEE;
   header.directions     = nb_dir;

   // frames pointers buffer
   size = sizeof(long) * header.directions * header.frames_per_dir;
   block_ptr = (long *) malloc(size);
   if (block_ptr == NULL)
   {
      printf("can't allocate %li block pointer%s (%i bytes)\n",
         header.frames_per_dir,
         header.frames_per_dir > 1L ? "s" : "",
         size
      );
      fclose(out);
      exit(1);
   }
   memset(block_ptr, 0, size);

   // write dc6 header
   fwrite(& header, sizeof(DC6_HEADER_S), 1, out);
   fflush(out);

   // block pointers (unknown values for now)
   block_start = ftell(out);
   fwrite(block_ptr, 4, size, out);
   fflush(out);

   curr_block = 0;
 
   // for all pcx
   for (d = 0; d < nb_dir; d++)
   {


      for (p = 0; p < dir_nb_pag[d]; p++)
      {
         strcpy(strtmp, filename);
         strtmp[strlen(filename) - 4] = 0x00;
         sprintf(buff, "_dir%03i_page%03i.pcx", d+1, p+1);
         strcat(strtmp, buff);
         my_load_image(strtmp);

         // encode this pcx into the dc6

         memset( & frame, 0, sizeof(DC6_FRAME_HEADER_S));

         // for all blocks of at most 256*256 pixels of the image
         for (y=0; y < my_truecolor_bmp->h; y += 256)
         {
            for (x=0; x < my_truecolor_bmp->w; x += 256)
            {
               frame.width = my_truecolor_bmp->w - x;
               if (frame.width > 256)
                  frame.width = 256;

               frame.height = my_truecolor_bmp->h - y;
               if (frame.height > 256)
                  frame.height = 256;

               // incomplete frame header
               block_ptr[curr_block] = ftell(out);
               fwrite(& frame, sizeof(DC6_FRAME_HEADER_S), 1, out);
               fflush(out);

               // block encoded pixels
               datas_start = ftell(out);
               if (make_dc6_frame(out, my_truecolor_bmp, x, y, frame.width, frame.height))
               {
                  printf("couldn't save block %i\n", curr_block);
                  fclose(out);
                  free(block_ptr);
                  exit(1);
               }
               fflush(out);

               // frame header
               datas_end        = ftell(out);
               frame.length     = datas_end - datas_start - 3;
               frame.next_block = datas_end;
               fseek(out, block_ptr[curr_block], SEEK_SET);
               fwrite(& frame, sizeof(DC6_FRAME_HEADER_S), 1, out);
               fflush(out);
               fseek(out, datas_end, SEEK_SET);

               // next block
               curr_block++;
            }
         }
         printf(
            "%s :\n"
            "   image of %i * %i pixels has been dc6-encoded into %i * %i frames\n",
            strtmp,
            my_truecolor_bmp->w,
            my_truecolor_bmp->h,
            1 + (my_truecolor_bmp->w / 256),
            1 + (my_truecolor_bmp->h / 256)
         );

         // delete image
         destroy_bitmap(my_truecolor_bmp);
         my_truecolor_bmp = NULL;

      }
   }

   // update frame header pointers
   fflush(out);
   fseek(out, block_start, SEEK_SET);
   fwrite(block_ptr, 4, header.frames_per_dir, out);
   fflush(out);

   // end
   fclose(out);
   free(block_ptr);
}


// ============================================================================
void parse_options(int argc, char ** argv)
{
   BGR_S bgr;
   int   i;


   for (i=2; i < argc; i++)
   {
      if (stricmp(argv[i], "-trans") == 0)
      {
         if (i + 1 < argc)
         {
            sscanf(argv[i + 1], "%06LX", & bgr);
            trans.rgb.r = bgr.r;
            trans.rgb.g = bgr.g;
            trans.rgb.b = bgr.b;
            printf("transparency color code = #%06LX (RGB = %i %i %i)\n",
               bgr,
               trans.rgb.r,
               trans.rgb.g,
               trans.rgb.b
            );
         }
         else
         {
            printf("error : -trans must be followed by a html color\n");
            exit(1);
         }
      }
      else if (stricmp(argv[i], "-format") == 0)
      {
         if (i + 1 < argc)
         {
            if (stricmp(argv[i + 1], "RGB") == 0) format = FM_RGB;
            else if (stricmp(argv[i + 1], "BGR")  == 0) format = FM_BGR;
            else if (stricmp(argv[i + 1], "RGBZ") == 0) format = FM_RGBZ;
            else if (stricmp(argv[i + 1], "BGRZ") == 0) format = FM_BGRZ;
            else if (stricmp(argv[i + 1], "ZRGB") == 0) format = FM_ZRGB;
            else if (stricmp(argv[i + 1], "ZBGR") == 0) format = FM_ZBGR;
            else
            {
               printf("error : -format use unknown code\n");
               exit(1);
            }

            switch(format)
            {
               case FM_RGB  : printf("format = RGB\n"); break;
               case FM_BGR  : printf("format = BGR\n"); break;
               case FM_RGBZ : printf("format = RGBZ\n"); break;
               case FM_BGRZ : printf("format = BGRZ\n"); break;
               case FM_ZRGB : printf("format = ZRGB\n"); break;
               case FM_ZBGR : printf("format = ZBGR\n"); break;
            }
         }
         else
         {
            printf("error : -format must be followed by a code\n");
            exit(1);
         }
      }
      else if (stricmp(argv[i], "-page") == 0)
      {
         option_page = TRUE;
      }
   }
}


// ============================================================================
int main(int argc, char ** argv)
{
   char * filename;
   int  i;


   printf(
      "\n"
      "rgb_dc6con v 1.00\n"
      "=================\n"
   );
   // init transparency color to pink
   trans.rgb.r = 255;
   trans.rgb.g = 0;
   trans.rgb.b = 255;
   trans.rgb.z = 0;

   // syntaxe
   if (argc < 2)
   {
      printf("syntaxe : rgb_dc6con <file> [-trans <code>] [-format <format>] [-page]\n"
             "\n"
             "    <file>   can be a DC6 or an image (BMP, LBM, TGA, PCX)\n"
             "    <code>   background color (RRGGBB in hexa), default pink (FF00FF)\n"
             "    <format> can be RGB, BGR, RGBZ, BGRZ, ZRGB or ZBGR (default BGR)\n"
             "    -page is for dc6 with pages"
       );
       exit(1);
   }

   // search options
   parse_options(argc, argv);

   // search extension
   filename = argv[1];
   i = strlen(filename) - 4;
   if (i < 0)
      i = 0;
   if (filename[i] != '.')
   {
      printf("error : invalid filename extension (%s)\n", filename + i);
      exit(1);
   }

   // init allegro (needed for loading truecolor images)
   my_truecolor_init();
   atexit(my_exit);

   if (option_page)
   {
      // is extension dc6 ?
      if (stricmp(filename + i, ".dc6") == 0)
      {
         // yes : load dc6 and makes pcx
         dc6buffer = load_dc6_in_mem(argv[1]);
         printf("%s :\n", argv[1]);
         make_pcx_page(argv[1]);
      }
      else
      {
         // no : load image and makes dc6
         my_make_dc6_page(filename);
      }
   }
   else
   {
      // is extension dc6 ?
      if (stricmp(filename + i, ".dc6") == 0)
      {
         // yes : load dc6 and makes pcx
         dc6buffer = load_dc6_in_mem(argv[1]);
         printf("%s :\n", argv[1]);
         make_pcx();
         strcpy(strtmp, filename);
         strtmp[strlen(filename) - 4] = 0x00;
         strcat(strtmp, "_NEW.pcx");
         save_pcx(strtmp, my_truecolor_bmp, NULL);
      }
      else
      {
         // no : load image and makes dc6
         my_load_image(filename);
         my_make_dc6(filename);
      }

   }

   return 0;
}
END_OF_MAIN();
