========================
| coftxt.exe            |
| freeware              |
| by Paul SIRAMY        |
|                       |
| v1 : 17 February 2005 |
| v2 : 06 April 2005    |
========================


This program scan a directory and its sub-directories in order to
extract the datas contained in the COF files needed for AnimData.d2


Edit the file "go.bat" and change the directory to scan. For instance
if your Mod directory has this structure :

   C:\Program Files\Diablo II\My mod\data\global\excel

You'll edit the .bat like this :

   @echo off
   coftxt "C:\Program Files\Diablo II\My mod\data" > log.txt
   pause

==> Notice the lack of '\' before the last quote !

You then save the .bat and launch it. 2 files will be created, "log.txt"
and "cof_datas_for_animdata.txt".

"log.txt" is a sort of debuging info file, while
"cof_datas_for_animdata.txt" is the interesting file. Now, in Ms-Excel
you open both "AnimData.txt" (provided by another program, AnimData_edit)
and "cof_datas_for_animdata.txt", and you can then copy/paste entire rows
from "cof_datas_for_animdata.txt" into "AnimData.txt".

As long as the COFs are correctly made (especially the Animation Speed
and the Frame Tag values), this tool will avoid you to create new rows
in AnimData.txt by hand, and you'll be sure that the datas in AnimData.txt
will be the exact copy of what is in your new COF files.


Note : the version 2 of coftxt introduced an option. You can now specify
       the name of the created file as the 2nd argument on the command line.

          @echo off
          coftxt "C:\Program Files\Diablo II\My mod\data" "my_file.txt" > log.txt
          pause

       will create the file "my_file.txt" instead of "cof_datas_for_animdata.txt"
