#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define USE_CONSOLE
#include <allegro.h>

// Disable warning message "unreferenced inline function has been removed"
#pragma warning( disable : 4514 )

// global data
FILE * out;
char strtmp[512];


// ======================================================================================
void write_infos(char * name)
{
   FILE * in;
   int  i, c, fpd, lay;
   long speed;


   in = fopen(name, "rb");
   if (in == NULL)
   {
      printf("CAN'T OPEN %s\n", name);

      fprintf(stderr, "CAN'T OPEN %s\n", name);
      fflush(stderr);

      return;
   }
   else
   {
      printf("reading %s\n", name);

      fprintf(stderr, "reading %s\n", name);
      fflush(stderr);
   }

   // CofName
   strcpy(strtmp, name);
   c = strlen(strtmp);
   for (i=0; i < c; i++)
      strtmp[i] = toupper(strtmp[i]);
   fprintf(out, "%s", strtmp);

   // Layers
   lay = fgetc(in);

   // FramesPerDirection
   fpd = fgetc(in);
   fprintf(out, "\t%i", fpd);

   // skip unknown and selection bounding box datas
   fread(strtmp, 22, 1, in);

   // AnimationSpeed
   fread(& speed, 4, 1, in);
   fprintf(out, "\t%li", speed);

   // skip layers datas
   fread(strtmp, 9, lay, in);

   // FrameDataXXX
   for (i=0; i < 144; i++)
   {
      if (i < fpd)
      {
         c = fgetc(in);
         fprintf(out, "\t%i", c);
      }
      else
         fprintf(out, "\t0");
   }

   // EOL
   fprintf(out, "\n");
   fflush(out);

   // end
   fclose(in);
}


// ======================================================================================
void check_all_files(void)
{
   struct al_ffblk f;
   int    fil_attr = FA_RDONLY | FA_HIDDEN | FA_SYSTEM | FA_ARCH,
          dir_attr = fil_attr | FA_DIREC;


   // 1st : COF files only, not directories
   if (al_findfirst("*.cof", & f, fil_attr) == 0)
   {
      do
      {
         write_infos(f.name);
      } while (al_findnext(& f) == 0);
   }
   al_findclose(& f);

   // 2nd : directories only
   if (al_findfirst("*.*", & f, dir_attr) == 0)
   {
      do
      {
         if (f.attrib & FA_DIREC)
         {
            if (f.name[0] != '.')
            {
               printf("entering \"%s\\\"\n", f.name);
               fprintf(stderr, "entering \"%s\\\"\n", f.name);
               fflush(stderr);
               chdir(f.name);

               check_all_files();

               printf("exiting  \"%s\\\"\n", f.name);
               fprintf(stderr, "exiting  \"%s\\\"\n", f.name);
               fflush(stderr);
               chdir("..");
            }
         }
      } while (al_findnext(& f) == 0);
   }
   al_findclose(& f);
}


// ======================================================================================
int main(int argc, char ** argv)
{
   char * txtname = "cof_datas_for_animdata.txt";
   int  i;


   printf("coftxt v2\n\n");

   if ((argc < 2) || (argc > 3))
   {
      printf("syntaxe : coftxt.exe <directory to scan> [<output file name>]\n");
      return -1;
   }

   // write txt datas
   if (argc != 2)
      txtname = argv[2];
   out = fopen(txtname, "wt");
   if (out == NULL)
   {
      printf("can't open \"%s\" for writing\n", txtname);
      return -1;
   }
   fputs("CofName"
         "\tFramesPerDirection"
         "\tAnimationSpeed",
         out
   );
   for (i=0; i <= 143; i++)
      fprintf(out, "\tFrameData%03i", i);
   fprintf(out, "\n");

   // changing directory
   if (_chdir(argv[1]) != 0)
   {
      fclose(out);
      printf("error, can't go to directory \"%s\"\n", argv[1]);
      return -1;
   }
   else
   {
      printf("entering directory \"%s\"\n", argv[1]);
      fprintf(stderr, "entering directory \"%s\"\n", argv[1]);
      fflush(stderr);
   }

   // init allegro
   // we just need functions al_findfirst(), al_findnext() and al_findclose()
   allegro_init();

   // for all COFs
   check_all_files();

   // end
   fclose(out);
   printf("done\n");
   fprintf(stderr, "done\n");
   fflush(stderr);
   return 0;
}
