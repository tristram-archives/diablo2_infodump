#include <stdio.h>
#include <stdlib.h>

// Disable warning message : warning C4996: 'sprintf': This function or variable may be unsafe. Consider using sprintf_s instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details.
#pragma warning(disable : 4996)

#define USE_CONSOLE
#include <allegro.h>

#include "dcc_decoder.h"


// ==========================================================================
int decode_this_dcc(char * filename)
{
   DCC_S * dcc_ptr   = NULL;
   int   ret         = 0;
   FILE  * out       = NULL;
   char  buffer[200] = "";


   dcc_ptr = dcc_disk_load(filename);
   if (dcc_ptr == NULL)
   {
      printf("Fatal error while loading %s :\n%s", filename, dcc_error);
      return 1;
   }
   printf("sucesfully loaded in memory %s\n", filename);

   sprintf(buffer, "%s_log.txt", filename);
   out = fopen(buffer, "wt");
   if (out == NULL)
   {
      printf("Fatal error while trying to create %s\n", buffer);
      dcc_destroy(dcc_ptr);
      return 1;
   }
   printf("creating %s\n", buffer);

   strcpy(dcc_ptr->filename, filename);
   ret = dcc_decode(dcc_ptr, -1);
   if (ret != 0)
   {
      printf("Fatal error while decoding %s :\n%s\n", filename, dcc_error);
      dcc_debug(out, dcc_ptr);
      fclose(out);
      dcc_destroy(dcc_ptr);
      return 1;
   }

   dcc_debug(out, dcc_ptr);
   fclose(out);
   dcc_destroy(dcc_ptr);
   return 0;
}


// ==========================================================================
void scan_this_directory()
{
   struct al_ffblk info;


   if (al_findfirst("*.dcc", & info, FA_ALL) == 0)
   {
      do
      {
         if ( ! (info.attrib & FA_DIREC))
         {
            printf("decoding %s\n", info.name);
            if (decode_this_dcc(info.name) != 0)
            {
               al_findclose( & info);
               return;
            }
         }
	     } while (al_findnext( & info) == 0);
      al_findclose( & info);
   }

   if (al_findfirst("*", & info, FA_DIREC) == 0)
   {
      do
      {
         if (info.name[0] != '.')
         {
            printf("entering %s\n", info.name);
            chdir(info.name);
            scan_this_directory();
            printf("exiting %s\n", info.name);
            chdir("..");
         }
	     } while (al_findnext( & info) == 0);
      al_findclose( & info);
   }
}


// ==========================================================================
int main(int argc, char **argv)
{
   int  i, r=60, g=60, b=60, a=1, recursive=0;
   char * filename = NULL;


   for (i=1; i < argc; i++)
   {
      if (strcmp(argv[i], "-bg") == 0)
      {
         i++; if (i < argc) r = atoi(argv[i]);
         i++; if (i < argc) g = atoi(argv[i]);
         i++; if (i < argc) b = atoi(argv[i]);
      }
      else if (strcmp(argv[i], "-act1") == 0)
         a = 1;
      else if (strcmp(argv[i], "-act2") == 0)
         a = 2;
      else if (strcmp(argv[i], "-act3") == 0)
         a = 3;
      else if (strcmp(argv[i], "-act4") == 0)
         a = 4;
      else if (strcmp(argv[i], "-act5") == 0)
         a = 5;
      else if (strcmp(argv[i], "-r") == 0)
         recursive = 1;
      else
         filename = argv[i];
   }

   allegro_init();
   init_htod();
   set_bg_color(r, g, b);
   load_d2pal(a - 1);

   if (recursive == 1)
   {
      scan_this_directory();
      return 0;
   }
   else if (filename != NULL)
      return decode_this_dcc(filename);

   printf("syntaxe : dcc_extract <options...>\n");
   printf("\n");
   printf("options :\n");
   printf("   -bg <r> <g> <b> : background color, r g and b from 0 to 255\n");
   printf("   -act1           : palette act 1\n");
   printf("   -act2           : palette act 2\n");
   printf("   -act3           : palette act 3\n");
   printf("   -act4           : palette act 4\n");
   printf("   -act5           : palette act 5\n");
   printf("   -r              : recursive mode\n");
   printf("   <file.dcc>      : a file to extract\n");
   printf("\n");
   printf("if -r is used the program enter in recursive mode, else <file.dcc> is required.\n");
   return 0;
}
END_OF_MAIN();
