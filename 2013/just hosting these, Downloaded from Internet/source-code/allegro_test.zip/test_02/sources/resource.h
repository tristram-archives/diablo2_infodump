#define IDS_APP_NAME                    1

#define IDR_MAIN_MENU                   101
#define IDR_POPUP                       102

#define IDM_FILE_EXIT                   40001

#define IDM_BACKGROUND_BLACK            41001
#define IDM_BACKGROUND_DARKGREY         41002
#define IDM_BACKGROUND_GREY             41003
#define IDM_BACKGROUND_LIGHTGREY        41004
#define IDM_BACKGROUND_WHITE            41005

#define IDM_SMALL                       40002
#define IDM_MEDIUM                      40003
#define IDM_LARGE                       40004
#define IDM_JUMBO                       40005
#define IDM_HELP_ABOUT                  40006
