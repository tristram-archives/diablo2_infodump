#define ALLEGRO_NO_MAGIC_MAIN
#include "allegro.h"
#include "winalleg.h"
#include <stdio.h>
#include "resource.h"


// ===============================================================
// defines
// ===============================================================
#define MYSHOWERROR(expression) {myShowError(expression, __FILE__, __FUNCTION__, __LINE__);}
#define MYASSERT(expression)    {if ( ! (expression)) {MYSHOWERROR(#expression); PostQuitMessage(0);}}
#define IDT_TIMER1              1001 // 50 times per second : this timer event is not from allegro, but from windows. allegro is accurate, but windows is needed to put a WM_PAINT message.
                                     // the WM_PAINT messages will in fact be ignored if it's less than 1/25th of a second that the window has been redraw last time.


// ===============================================================
// global variables
// ===============================================================
LPCWSTR       GLOBAL_szClassName         = TEXT("My test_02 Class");
HINSTANCE     GLOBAL_hInstance           = NULL;
HMENU         GLOBAL_hMenu               = NULL; // Handle to a menu. This will be used with the context-sensitive menu
HMENU         GLOBAL_hSysMenu            = NULL; // Handle to the system menu
HMENU         GLOBAL_hMenuTrackPopup     = NULL; // Handle to the context menu that will be created
int           GLOBAL_col_red             = 0;
int           GLOBAL_col_green           = 0;
int           GLOBAL_col_dark            = 0;
int           GLOBAL_col_darkgrey        = 0;
int           GLOBAL_col_grey            = 0;
int           GLOBAL_col_lightgrey       = 0;
int           GLOBAL_col_white           = 0;
int           GLOBAL_allegro_ok          = FALSE;
long          GLOBAL_counter             = 0;
int           GLOBAL_bg_color            = 0;
volatile long GLOBAL_ticks               = 0;
volatile long GLOBAL_old_fps             = 0;
volatile long GLOBAL_fps                 = 0;
int           GLOBAL_win_width           = 320;
int           GLOBAL_win_height          = 200;
BITMAP        * GLOBAL_screen_backbuffer = NULL;
int           GLOBAL_desktop_width       = 0;
int           GLOBAL_desktop_height      = 0;


// ===============================================================
// function declarations
// ===============================================================
LRESULT CALLBACK MyWndProc (HWND, UINT, WPARAM, LPARAM);


// ===============================================================
// pop up a useful debug window, use mainly by my MYASSERT() macro
// ===============================================================
void myShowError(char * expression, char * file, char * function, long line)
{
   char buffer[2000] = "";

   sprintf_s(buffer, sizeof(buffer), "FILE : %s\nFUNCTION : %s()\nLINE : %ld\nEXPRESSION : %s", file, function, line, expression);
   MessageBoxA(NULL, buffer, "Error", MB_OK);
}


// ===============================================================
// timer called 25 times per second
// ===============================================================
void myAllegroTimerTicksProc(void)
{
   GLOBAL_ticks++;
   GLOBAL_fps++;
}
END_OF_FUNCTION(myAllegroTimerTicksProc)


// ===============================================================
// timer called 1 time per second
// ===============================================================
void myAllegroTimerFpsProc(void)
{
   GLOBAL_old_fps = GLOBAL_fps;
   GLOBAL_fps     = 0;
}
END_OF_FUNCTION(myAllegroTimerFpsProc)


// ===============================================================
// start of the program
// ===============================================================
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance, LPSTR szCmdLine, int iCmdShow)
{
   WNDCLASS wnd;
   MSG      msg;
   HWND     hwnd     = NULL;
   long     nb_ticks = 0;


   GLOBAL_hInstance = hInst;

   wnd.style         = CS_HREDRAW | CS_VREDRAW; //we will explain this later
   wnd.lpfnWndProc   = MyWndProc;
   wnd.cbClsExtra    = 0;
   wnd.cbWndExtra    = 0;
   wnd.hInstance     = GLOBAL_hInstance;
   wnd.hIcon         = LoadIcon(NULL, IDI_APPLICATION); //default icon
   wnd.hCursor       = LoadCursor(NULL, IDC_ARROW); //default arrow mouse cursor
   wnd.hbrBackground = (HBRUSH)(COLOR_BACKGROUND+1);
   wnd.lpszMenuName  = MAKEINTRESOURCE(IDR_MAIN_MENU); // NULL for no menu
   wnd.lpszClassName = GLOBAL_szClassName;

   // MessageBoxA(), with the A suffixe, for Ascii strings. MessageBoxW() for Unicode. symbol UNICODE defines MessageBox() to one of those two, accordingly.
   // macro TEXT("string litteral") whould be used every time : it check UNICODE symbol, and transform or not your string to Ascii or Unicode.
   // MessageBoxA(NULL, "Ascii text\n2nd line", "Ascii Title", MB_OK);

   // prefered syntax :
   // MessageBox(NULL, TEXT("Undefined text\n2nd line"), TEXT("Undefined Title"), MB_OK);

   if( ! RegisterClass(&wnd)) //register the WNDCLASS
   {
      MYSHOWERROR("RegisterClass");
      return 1;
   }

   hwnd = CreateWindow(GLOBAL_szClassName,   // lpClassName
                       TEXT("Window Title"), // lpWindowName
                       WS_OVERLAPPEDWINDOW,  // dwStyle      : basic window style
                       CW_USEDEFAULT,        // x
                       CW_USEDEFAULT,        // y            : set starting point to default value
                       GLOBAL_win_width,     // nWidth
                       GLOBAL_win_height,    // nHeight      : set all the dimensions to default value
                       NULL,                 // hWndParent   : no parent window
                       NULL,                 // hMenu        : no menu
                       GLOBAL_hInstance,     // hInstance
                       NULL);                // lpParam      : no parameters to pass

   MYASSERT(hwnd != NULL);
   ShowWindow(hwnd, iCmdShow); // display the window on the screen
   UpdateWindow(hwnd);         // make sure the window is updated correctly

   SetTimer(hwnd, IDT_TIMER1, 20, (TIMERPROC) NULL);

   // allegro stuff

   win_set_window(hwnd);
   MYASSERT(allegro_init() == 0);

   set_window_title("My Allegro window title"); 
   set_color_depth(desktop_color_depth());
   MYASSERT(get_desktop_resolution( & GLOBAL_desktop_width, & GLOBAL_desktop_height) == 0);
   MYASSERT(set_gfx_mode(GFX_AUTODETECT_WINDOWED, GLOBAL_desktop_width, GLOBAL_desktop_height, 0, 0) == 0);
   MYASSERT((GLOBAL_screen_backbuffer = create_bitmap(GLOBAL_desktop_width, GLOBAL_desktop_height)) != NULL);

   GLOBAL_col_red       = makecol_depth(desktop_color_depth(), 255,   0,   0);
   GLOBAL_col_green     = makecol_depth(desktop_color_depth(),   0, 255,   0);
   GLOBAL_col_dark      = makecol_depth(desktop_color_depth(),   0,   0,   0);
   GLOBAL_col_darkgrey  = makecol_depth(desktop_color_depth(),  64,  64,  64);
   GLOBAL_col_grey      = makecol_depth(desktop_color_depth(), 128, 128, 128);
   GLOBAL_col_lightgrey = makecol_depth(desktop_color_depth(), 192, 192, 192);
   GLOBAL_col_white     = makecol_depth(desktop_color_depth(), 255, 255, 255);

   // timers
   LOCK_VARIABLE(GLOBAL_ticks);
   LOCK_VARIABLE(GLOBAL_old_fps);
   LOCK_VARIABLE(GLOBAL_fps);
   LOCK_FUNCTION(myAllegroTimerTicksProc);
   LOCK_FUNCTION(myAllegroTimerFpsProc);
   MYASSERT(install_timer() == 0);
   MYASSERT(install_int_ex(myAllegroTimerTicksProc, BPS_TO_TIMER(25)) == 0);
   MYASSERT(install_int_ex(myAllegroTimerFpsProc,   BPS_TO_TIMER(1))  == 0);
   GLOBAL_bg_color = GLOBAL_col_darkgrey;

   // mouse
   //MYASSERT(install_mouse() >= 0);
   //show_mouse(screen);

   // keyboard
   //MYASSERT(install_keyboard() == 0);

   GLOBAL_allegro_ok = TRUE;

   // main loop
   for (;;)
   {
      if (GLOBAL_ticks != 0)
      {
         nb_ticks     = GLOBAL_ticks;
         GLOBAL_ticks = 0;
         while (nb_ticks)
         {
            // update here the internal logic of the program (in a game : move units, etc...)
            nb_ticks--;
         }

         // prepare the entire allegro 'screen' to draw
		       clear_to_color(GLOBAL_screen_backbuffer, GLOBAL_bg_color);
         line(GLOBAL_screen_backbuffer, GLOBAL_counter % GLOBAL_win_width, 0, GLOBAL_win_width + GLOBAL_counter % GLOBAL_win_width, GLOBAL_win_height, GLOBAL_col_red);
         line(GLOBAL_screen_backbuffer, - GLOBAL_win_width + GLOBAL_counter % GLOBAL_win_width, 0, GLOBAL_counter % GLOBAL_win_width, GLOBAL_win_height, GLOBAL_col_red);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,   0, GLOBAL_col_green, -1, "GLOBAL_counter    = %d", GLOBAL_counter);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  10, GLOBAL_col_green, -1, "GLOBAL_ticks      = %d", nb_ticks);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  20, GLOBAL_col_green, -1, "GLOBAL_old_fps    = %d", GLOBAL_old_fps);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  30, GLOBAL_col_green, -1, "GLOBAL_fps        = %d", GLOBAL_fps);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  40, GLOBAL_col_green, -1, "screen->w         = %d", screen->w);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  50, GLOBAL_col_green, -1, "screen->h         = %d", screen->h);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  60, GLOBAL_col_green, -1, "mouse_x           = %d", mouse_x);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  70, GLOBAL_col_green, -1, "mouse_y           = %d", mouse_y);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  80, GLOBAL_col_green, -1, "mouse_z           = %d", mouse_z);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0,  90, GLOBAL_col_green, -1, "GLOBAL_win_width  = %d", GLOBAL_win_width);
         textprintf_ex(GLOBAL_screen_backbuffer, font, 0, 100, GLOBAL_col_green, -1, "GLOBAL_win_height = %d", GLOBAL_win_height);

         // draw the image into the window
         blit(GLOBAL_screen_backbuffer, screen, 0, 0, 0, 0, GLOBAL_screen_backbuffer->w, GLOBAL_screen_backbuffer->h);
         GLOBAL_counter++;
      }

      if (GetMessage(&msg, NULL, 0, 0)) //message loop
      {
         TranslateMessage(&msg);
         DispatchMessage(&msg);
      }
      else
         break;
   }
   destroy_bitmap(GLOBAL_screen_backbuffer);
   KillTimer(hwnd, IDT_TIMER1);
   return msg.wParam;
}


// ===============================================================
// callback function called on each window's message
// ===============================================================
LRESULT CALLBACK MyWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
   switch(msg)
   {
      case WM_DESTROY:
         if (GLOBAL_allegro_ok == TRUE)
         {
            set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
            allegro_exit();
            GLOBAL_allegro_ok = FALSE;
         }
         PostQuitMessage(0);
         return 0;

      case WM_CREATE:
         GLOBAL_hSysMenu = GetSystemMenu(hwnd, FALSE);                             // To modify the system menu, first get a handle to it
         InsertMenu(GLOBAL_hSysMenu, 2, MF_SEPARATOR, 0, TEXT("-"));               // This is how to add a separator to a menu
         AppendMenu(GLOBAL_hSysMenu, MF_STRING, 1, TEXT("Practical Techniques"));  // This is how to add a menu item using a string
         AppendMenu(GLOBAL_hSysMenu, MF_STRING, IDM_HELP_ABOUT, TEXT("About...")); // This is how to add a menu item using a defined identifier
         return 0;

      case WM_COMMAND:
         switch(LOWORD(wParam))
         {
            case IDM_BACKGROUND_BLACK     : GLOBAL_bg_color = GLOBAL_col_dark;      break;
            case IDM_BACKGROUND_DARKGREY  : GLOBAL_bg_color = GLOBAL_col_darkgrey;  break;
            case IDM_BACKGROUND_GREY      : GLOBAL_bg_color = GLOBAL_col_grey;      break;
            case IDM_BACKGROUND_LIGHTGREY : GLOBAL_bg_color = GLOBAL_col_lightgrey; break;
            case IDM_BACKGROUND_WHITE     : GLOBAL_bg_color = GLOBAL_col_white;     break;

            case IDM_LARGE:
               MessageBox(hwnd, TEXT("Menu Item Selected = Large"), TEXT("Message"), MB_OK);
               break;

            case IDM_FILE_EXIT:
               PostQuitMessage(WM_QUIT);
               break;
         }
         return 0;

      case WM_CONTEXTMENU:
         // Get a handle to the popup menu using its resource
         if( (GLOBAL_hMenu = LoadMenu(GLOBAL_hInstance, MAKEINTRESOURCE(IDR_POPUP))) == NULL )
            return 0; 
 
         // Get a handle to the first shortcut menu
         GLOBAL_hMenuTrackPopup = GetSubMenu(GLOBAL_hMenu, 0); 

         // Display the popup menu when the user right-clicks
         TrackPopupMenu(
            GLOBAL_hMenuTrackPopup,
            TPM_LEFTALIGN | TPM_RIGHTBUTTON,
            LOWORD(lParam),
            HIWORD(lParam), 
            0,
            hwnd,
            NULL
         );
         break;

      case WM_SIZE :
         GLOBAL_win_width  = LOWORD(lParam);
         GLOBAL_win_height = HIWORD(lParam);
         break;
   }
   return DefWindowProc(hwnd, msg, wParam, lParam);
}
