#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define USE_CONSOLE
#include <allegro.h>


typedef unsigned char      UBYTE;
typedef short int          WORD;
typedef unsigned short int UWORD;
typedef unsigned long      UDWORD;

// no spaces between struct members
#pragma pack(1)

typedef struct
{
   long   version;
   long   sub_version;
   char   zero[260];
   long   tiles_num;
   UDWORD tile_header_offset;
} DT1_HEADER_S;

typedef struct
{
   long   direction;
   WORD   roof_height;
   UBYTE  sound_index;
   UBYTE  animated;
   long   height;
   long   width;
   UDWORD zero_1;
   long   orientation;
   long   main_index;
   long   sub_index;
   long   rarity_frame;
   UBYTE  unk[4];
   UBYTE  sub_flags[25];
   UBYTE  zero_2[7];
   UDWORD block_headers_offset;
   long   block_datas_length;
   long   blocks_num;
   UBYTE  zero_3[12];
} TILE_HEADER_S;

typedef struct
{
   WORD  x0;
   WORD  y0;
   WORD  zero_1;
   UBYTE grid_x;
   UBYTE grid_y;
   WORD  format;
   long  length;
   WORD  zero_2;
   long  offset;
} BLOCK_HEADER_S;

#pragma pack()


// global
char   glb_dir_name[25][80];
FILE   * dt1_out, * dt1_act_problem;
UDWORD pixel_count[256];


// ==========================================================================
// draw a 3d-isometric sub-tile
void count_sub_tile_isometric (UBYTE * data, int length)
{
   UBYTE * ptr = data;
   int   x, y=0, n,
         xjump[15] = {14, 12, 10, 8, 6, 4, 2, 0, 2, 4, 6, 8, 10, 12, 14},
         nbpix[15] = {4, 8, 12, 16, 20, 24, 28, 32, 28, 24, 20, 16, 12, 8, 4};


   // 3d-isometric subtile is 256 bytes, no more, no less
   if (length != 256)
      return;

   // draw
   while (length > 0)
   {
      x = xjump[y];
      n = nbpix[y];
      length -= n;
      while (n)
      {
         pixel_count[*ptr]++;
         ptr++;
         x++;
         n--;
      }
      y++;
   }
}


// ==========================================================================
// draw a normal sub-tile (can be transparent, so there are "jump" coded)
void count_sub_tile_normal (UBYTE * data, int length)
{
   UBYTE * ptr = data, b1, b2;
   int   x=0, y=0;


   // draw
   while (length > 0)
   {
      b1 = * ptr;
      b2 = * (ptr + 1);
      ptr += 2;
      length -= 2;
      if (b1 || b2)
      {
         x += b1;
         length -= b2;
         while (b2)
         {
            pixel_count[*ptr]++;
            ptr++;
            x++;
            b2--;
         }
      }
      else
      {
         x = 0;
         y++;
      }
   }
}


// ====================================================================================
void check_curr_tile(TILE_HEADER_S * tile, int level, char * name,
                     UBYTE * file_base)
{
   BLOCK_HEADER_S * pblock;
   int            s, length, format;
   UBYTE          * data;


   // anti-bug (for empty tile)
   if ((tile->width == 0) || (tile->height == 0))
      return;

   pblock = (BLOCK_HEADER_S *) (file_base + tile->block_headers_offset);

   // draw sub-tiles in this bitmap
   for (s=0; s < tile->blocks_num; s++) // for each sub-tiles
   {
      // get infos
      data   = (UBYTE *) ((UBYTE *) pblock + pblock[s].offset);
      length = pblock[s].length;
      format = pblock[s].format;

      // draw the sub-tile
      if (format == 0x0001)
         count_sub_tile_isometric(data, length);
      else
         count_sub_tile_normal(data, length);
   }
}

// ====================================================================================
void check_curr_dt1(int level, char * name)
{
   char          * buffer;
   DT1_HEADER_S  * head;
   TILE_HEADER_S * tile_head;
   FILE          * in;
   int           i, use_act_col;
   long          length;


   for (i=0; i <= level; i++)
      fprintf(stderr, "%s\\", glb_dir_name[i]);
   name[0] = toupper(name[0]);
   fprintf(stderr, "%s\n", name);

   for (i=0; i <= level; i++)
      fprintf(dt1_out, "%s\\", glb_dir_name[i]);
   fprintf(dt1_out, "%s", name);

   in = fopen(name, "rb");
   if (in == NULL)
   {
      fprintf(dt1_out, "\tERROR, can't open the DT1 file\n");
      return;
   }

   fseek(in, 0, SEEK_END);
   length = ftell(in);
   fseek(in, 0, SEEK_SET);
   buffer = (char *) malloc(length);
   if (buffer == NULL)
   {
      fclose(in);
      fprintf(dt1_out, "\tERROR, can't allocate %li bytes\n", length);
   }
   fread(buffer, length, 1, in);
   fclose(in);

   head = (DT1_HEADER_S *) buffer;

   if ((head->version == 7) && (head->sub_version == 6))
   {
      // reset pixel count
      for (i=0; i < 256; i++)
         pixel_count[i] = 0;

      // tile header
      tile_head = (TILE_HEADER_S *) & buffer[head->tile_header_offset];
      for (i=0; i < head->tiles_num; i++)
      {
         check_curr_tile(& tile_head[i], level, name, (UBYTE *) buffer);
      }

      // write stats
      for (i=1; i < 256; i++)
         fprintf(dt1_out, "\t%lu", pixel_count[i]);

      // act color problem
      use_act_col = 0;
      for (i=225; i <= 254; i++)
      {
         if (pixel_count[i] != 0)
            use_act_col++;
      }
      if (use_act_col)
      {
         for (i=0; i <= level; i++)
            fprintf(dt1_act_problem, "%s\\", glb_dir_name[i]);
         fprintf(dt1_act_problem, "%s", name);
         fprintf(dt1_act_problem, " \t%i\n", use_act_col);
      }
   }

   // end
   free(buffer);
}


// ====================================================================================
void check_curr_dir(int level, char * name)
{
   struct al_ffblk info;


   if (level >= 25)
      return;

   strcpy(glb_dir_name[level], name);
   glb_dir_name[level][0] = toupper(glb_dir_name[level][0]);

   // check all dt1 in this directory
   if (al_findfirst("*.dt1", & info, -1) == 0)
   {
      do
      {
         check_curr_dt1(level, info.name);
         fprintf(dt1_out, "\n");
      } while (al_findnext(& info) == 0);
   }
   al_findclose( & info);

   // check in all other sub-directory
   if (al_findfirst("*.*", & info, -1) == 0)
   {
      do
      {
         if ((info.attrib & FA_DIREC) && (info.name[0] != '.'))
         {
            _chdir(info.name);
            check_curr_dir(level + 1, info.name);
            _chdir("..");
         }
      } while (al_findnext(& info) == 0);
   }
   al_findclose( & info);

}


// ====================================================================================
int main(int argc, char ** argv)
{
   char * dt1_out_name         = "dt1_pixels_count.txt",
        * dt1_act_problem_name = "dt1_act_problem.txt";
   int  i;


   allegro_init();

   dt1_out = fopen(dt1_out_name, "wt");
   if (dt1_out == NULL)
   {
      printf("can't create \"%s\"\n", dt1_out_name);
      exit(1);
   }

   
   dt1_act_problem = fopen(dt1_act_problem_name, "wt");
   if (dt1_act_problem == NULL)
   {
      printf("can't create \"%s\"\n", dt1_act_problem_name);
      exit(1);
   }

   fprintf(dt1_out, "Dt1File");
   for (i=1; i < 256; i++)
      fprintf(dt1_out, "\t%i", i);
   fprintf(dt1_out, "\n");

   fprintf(dt1_act_problem, "Dt1File\tnb_colors\n");
   fprintf(dt1_act_problem, "\nThese DT1 are using act-dependant colors (225 to 254) :\n\n");
   
   if (_chdir("data"))
   {
      printf("unable to locate the 'data' directory\n");
      exit(1);
   }

   check_curr_dir(0, "data");

   fclose(dt1_out);
   fclose(dt1_act_problem);

   printf("done\n");
   return 0;
}
