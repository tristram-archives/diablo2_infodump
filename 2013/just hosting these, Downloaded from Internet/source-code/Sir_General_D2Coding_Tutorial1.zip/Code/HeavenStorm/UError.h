#ifndef U_ERROR_H
#define U_ERROR_H
//==================================================================================
//
//		File: UError.h
//		Version: 1.00
//		
//		Provides error throwing and handling functions.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include "MainDefinitions.h"

//==================================================================================
//		TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//Name: UERR_ERROR
//Function: Provides a unique code for each error
typedef enum{
	UERR_ERROR_OK,
	UERR_ERROR_LOAD_LIBRARY,
	UERR_ERROR_OUT_OF_MEMORY,
	UERR_ERROR_PROTECT_MODE,
	UERR_ERROR_LOAD_DC6
}UERR_ERROR;
#define UERR_ERROR_COUNT	5

//Name: UERR_ERROR_HANDLER
//Function: Prototype for an error handler function
typedef BOOL (* UERR_ERROR_HANDLER)(UERR_ERROR ueCode);

//==================================================================================
//		CLASSES
//==================================================================================

//==================================================================================
//		ADDITIONAL TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//Name: UErrThrowError
//Function: Throws an error to be handled by the error handler
void UErrThrowError(LPSTR szFile, LPSTR szFunc, LPSTR szDesc, UERR_ERROR ueCode);

//Name: UErrAddHandler
//Function: Adds an error handler for the specified code
void UErrAddHandler(UERR_ERROR_HANDLER lpfn, UERR_ERROR ueCode);

//Name: UErrLogInit
//Function: Initializes an error/debugging log
void UErrLogInit(LPSTR szFile);

//Name: UErrLogWrite
//Function: Writes a line to the error/debugging log
void UErrLogWrite(LPSTR szMessage);

//Name: UErrLogWritef
//Function: Writes a line to the error/debugging log, printf format
void __cdecl UErrLogWritef(LPSTR szFormat, ...);

//Name: UErrGetFile
//Function: Gets the file of the current/last thrown error
LPSTR UErrGetFile();

//Name: UErrGetFunction
//Function: Gets the function of the current/last thrown error
LPSTR UErrGetFunction();

//Name: UErrGetDescription
//Function: Gets the description of the current/last thrown error
LPSTR UErrGetDescription();

//Name: UErrGetCode
//Function: Gets the code of the current/last thrown error
UERR_ERROR UErrGetCode();

//==================================================================================
//		TRAILING HEADERS
//==================================================================================

//==================================================================================
#endif