//==================================================================================
//
//		File: UError.cpp
//		Version: 1.00
//		
//		Provides error throwing and handling functions.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include "MainDefinitions.h"
#include "UError.h"

//==================================================================================
//		PRIVATE VARIABLES
//==================================================================================

static CHAR szErrorDesc[1024] = ""; //Provides storage for error description
static CHAR szErrorFunc[256] = ""; //Provides storage for function causing error
static CHAR szErrorFile[256] = ""; //Provides storage for file causing error
static UERR_ERROR ueErrCode = UERR_ERROR_OK; //Current error code

static CHAR szLogFile[MAX_PATH] = "";
static BOOL bLogInit = FALSE;

static UERR_ERROR_HANDLER ueHandlers[UERR_ERROR_COUNT]; //Array of error handlers

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

//==================================================================================
//		PRIVATE FUNCTIONS
//==================================================================================

//Name: UErrExit
//Function: Exits the program under error circumstances
static void UErrExit(UERR_ERROR ueCode){

	//Log this exit
	UErrLogWrite("Performing emergency shutdown under error conditions.");

	exit(ueCode);

}

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//Name: UErrThrowError
//Function: Throws an error to be handled by the error handler
void UErrThrowError(LPSTR szFile, LPSTR szFunc, LPSTR szDesc, UERR_ERROR ueCode){

	strcpy(szErrorFile, szFile);
	strcpy(szErrorFunc, szFunc);
	strcpy(szErrorDesc, szDesc);
	ueErrCode = ueCode;

	//Log the error
	UErrLogWrite("==============================================================");
	UErrLogWritef("\tError Code: %u", ueCode);
	UErrLogWritef("\tFile: %s", szErrorFile);
	UErrLogWritef("\tFunction: %s", szErrorFunc);
	UErrLogWritef("\tDescription: %s", szErrorDesc);
	UErrLogWrite("==============================================================");

	//Try and pass this to an error handler
	BOOL bHandled = FALSE;
	if(IsBadCodePtr((FARPROC)ueHandlers[ueErrCode]) == 0){
		bHandled = ueHandlers[ueErrCode](ueErrCode);
	}

	if(!bHandled){
		UErrExit(ueErrCode);
	}

}

//Name: UErrAddHandler
//Function: Adds an error handler for the specified code
void UErrAddHandler(UERR_ERROR_HANDLER lpfn, UERR_ERROR ueCode){

	ueHandlers[ueCode] = lpfn;

}

//Name: UErrLogInit
//Function: Initializes an error/debugging log
void UErrLogInit(LPSTR szFile){

	strcpy(szLogFile, szFile);

	FILE *fLog = fopen(szLogFile, "w");
	if(fLog == NULL){
		return;
	}
	fclose(fLog);

	bLogInit = TRUE;

}

//Name: UErrLogWrite
//Function: Writes a line to the error/debugging log
void UErrLogWrite(LPSTR szMessage){

	if(!bLogInit){
		return;
	}

	FILE *fDebug = fopen(szLogFile, "a+");
	if(fDebug == NULL){
		bLogInit = FALSE;
		return;
	}
	fprintf(fDebug, szMessage);
	fprintf(fDebug, "\n");
	fclose(fDebug);

}

//Name: UErrLogWritef
//Function: Writes a line to the error/debugging log, printf format
void __cdecl UErrLogWritef(LPSTR szFormat, ...){

	if(!bLogInit){
		bLogInit = FALSE;
		return;
	}

	va_list vaArgs;
	va_start(vaArgs, szFormat);

	FILE *fDebug = fopen(szLogFile, "a+");
	if(fDebug == NULL){
		return;
	}
	vfprintf(fDebug, szFormat, vaArgs);
	fprintf(fDebug, "\n");
	fclose(fDebug);

	va_end(vaArgs);

}

//Name: UErrGetFile
//Function: Gets the file of the current/last thrown error
LPSTR UErrGetFile(){

	return szErrorFile;

}

//Name: UErrGetFunction
//Function: Gets the function of the current/last thrown error
LPSTR UErrGetFunction(){

	return szErrorFunc;

}

//Name: UErrGetDescription
//Function: Gets the description of the current/last thrown error
LPSTR UErrGetDescription(){

	return szErrorDesc;

}

//Name: UErrGetCode
//Function: Gets the code of the current/last thrown error
UERR_ERROR UErrGetCode(){

	return ueErrCode;

}
	
//==================================================================================
//		CLASS FUNCTIONS
//==================================================================================