//==================================================================================
//
//		File: MainHeavenStorm.cpp
//		Version: 1.00
//		
//		DLL entry point, initialization and main program functions all contained 
//		here.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include <stdio.h>
#include <direct.h>
#include <memory.h>

#include "MainDefinitions.h"
#include "UError.h"

#include "GUITitleScreen.h"

//==================================================================================
//		PRIVATE VARIABLES
//==================================================================================

static LPSTR szFile = "Heaven Storm\\Main\\MainHeavenStorm.cpp";

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

HANDLE hDLLModule = NULL; //Handle to the DLL module
CHAR szAppPath[MAX_PATH] = ""; //The current working directory
LPD2FUNCTIONTABLE lpd2Functions = NULL; //Pointer to function table

//==================================================================================
//		PRIVATE FUNCTIONS
//==================================================================================

//Name: MainGetAppPath
//Function: Gets the application's working directory
static void MainGetAppPath(){

	_getcwd(szAppPath, MAX_PATH);

	if(szAppPath[strlen(szAppPath)] != '\\'){
		szAppPath[strlen(szAppPath) + 1] = 0;
		szAppPath[strlen(szAppPath)] = '\\';
	}

}

//Name: MainWriteFunctions
//Function: Writes all necessary function pointers to the DLLs
static void MainWriteFunctions(){

	DWORD dw = 0;

	//Start by getting write access to all necessary DLLs
	if(!VirtualProtect((LPVOID)0x6FA11000, 0x1E000, PAGE_EXECUTE_READWRITE, &dw)){
		UErrThrowError(szFile, "MainWriteFunctions", "Failed to change protection mode for D2Launch.dll", UERR_ERROR_PROTECT_MODE);
	}

	if(!VirtualProtect((LPVOID)0x6FD41000, 0x7C000, PAGE_EXECUTE_READWRITE, &dw)){
		UErrThrowError(szFile, "MainWriteFunctions", "Failed to change protection mode for D2Common.dll", UERR_ERROR_PROTECT_MODE);
	}

	if(!VirtualProtect((LPVOID)0x6FC31000, 0xCF000, PAGE_EXECUTE_READWRITE, &dw)){
		UErrThrowError(szFile, "MainWriteFunctions", "Failed to change protection mode for D2Game.dll", UERR_ERROR_PROTECT_MODE);
	}

	if(!VirtualProtect((LPVOID)0x6FAA1000, 0xCB000, PAGE_EXECUTE_READWRITE, &dw)){
		UErrThrowError(szFile, "MainWriteFunctions", "Failed to change protection mode for D2Client.dll", UERR_ERROR_PROTECT_MODE);
	}

	//GUI Functions
	*((LPINT)0x6FA1D118) = (INT)&GUITrademarkScreenInit;
	*((LPINT)0x6FA17C38) = (INT)&GUITitleScreenInit;

}

//Name: MainInit
//Function: Initializes all necessary resources and the like
static void MainInit(){

	MainGetAppPath();	

	//Initialize logging
	CHAR szLogFile[1024] = "";
	sprintf(szLogFile, "%sDebugLog.txt", szAppPath);
	UErrLogInit(szLogFile);
	UErrLogWrite("Starting Diablo II Heaven Storm " APP_VERSION);

	//Load necessary DLLs
	if(!LoadLibrary("D2Launch.dll")){
		UErrThrowError(szFile, "MainInit", "Failed to load library D2Launch.dll", UERR_ERROR_LOAD_LIBRARY);
	}

	if(!LoadLibrary("D2Common.dll")){
		UErrThrowError(szFile, "MainInit", "Failed to load library D2Common.dll", UERR_ERROR_LOAD_LIBRARY);
	}

	if(!LoadLibrary("D2Game.dll")){
		UErrThrowError(szFile, "MainInit", "Failed to load library D2Game.dll", UERR_ERROR_LOAD_LIBRARY);
	}

	if(!LoadLibrary("D2Client.dll")){
		UErrThrowError(szFile, "MainInit", "Failed to load library D2Client.dll", UERR_ERROR_LOAD_LIBRARY);
	}

	//Write function changes
	MainWriteFunctions();

	//Get function table
	lpd2Functions = D2Init109b();

	//Temp load window resources
	GUITitleScreenLoad();

}

//Name: MainRelease
//Function: Frees memory, releases resources, etc.
static void MainRelease(){

	UErrLogWrite("Closing Diablo II Heaven Storm");

}

//Name: DllMain
//Function: Entry point for the DLL
BOOL WINAPI DllMain(HANDLE hModule, DWORD dwReason, LPVOID lpReserved){

	switch(dwReason){
		case DLL_PROCESS_ATTACH: //First time loading
			hDLLModule = hModule;
			MainInit();
			break;
		case DLL_PROCESS_DETACH: //Final time leaving
			MainRelease();
			break;
	}

	return TRUE;

}

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//==================================================================================
//		CLASS FUNCTIONS
//==================================================================================