#ifndef D2_FUNCTIONS_H
#define D2_FUNCTIONS_H
//==================================================================================
//
//		File: D2Functions.h
//		Version: 1.00 - Diablo II v1.09x
//		
//		Provides definitions for Diablo II functions.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include "MainDefinitions.h"
#include "D2Types.h"

//==================================================================================
//		TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//Name: D2FUNC_CREATE_WINDOW
//Function: Creates a window on the screen
//Param - lpWinInfo: Pointer to a D2WINDOWINFO structure for this window
//Returns: Handle to the newly created window
//Module: D2Win
//Ordinal: 10017
//Location: v1.09b - 6F8AEE30
typedef D2_WINDOW_HANDLE (STDCALL * D2FUNC_CREATE_WINDOW)(LPD2WINDOWINFO lpWinInfo);

//Name: D2FUNC_DESTROY_WINDOW
//Function: Destroys a created window
//Param - lpd2hWnd: Pointer to window handle as obtained from D2FUNC_CREATE_WINDOW
//Module: D2Win
//Ordinal: 10018
//Location: v1.09b - 6F8AF000
typedef ULONG (STDCALL * D2FUNC_DESTROY_WINDOW)(LPD2_WINDOW_HANDLE lpd2hWnd);

//Name: D2FUNC_CLEAR_WINDOWS
//Function: Destroys all currently created windows
//Module: N/A
//Ordinal: N/A
//Location: Local Code
typedef void (STDCALL * D2FUNC_CLEAR_WINDOWS)();

//Name: D2FUNC_LOAD_DC6_RESOURCE
//Function: Loads a DC6 file and returns a pointer to it
//Param - szDC6Name: String that contains the path to the DC6 w/o ".dc6" on the end
//Param - ulZero: Appears to always be 0
//Returns: A handle to the DC6 file
//Module: D2Win
//Ordinal: 10039
//Location: v1.09b - 6F8A76C0
typedef D2_DC6_HANDLE (FASTCALL * D2FUNC_LOAD_DC6_RESOURCE)(LPSTR szDC6Name, ULONG ulZero);

//Name: D2FUNC_FREE_DC6_RESOURCE
//Function: Frees a DC6 file loaded by D2FUNC_LOAD_DC6_RESOURCE
//Param - d2DC6: Handle to the DC6 file as obtained from D2FUNC_LOAD_DC6_RESOURCE
//Module: D2Win
//Ordinal: 10041
//Location: v1.09b - 6F8A7810
typedef void (FASTCALL * D2FUNC_FREE_DC6_RESOURCE)(D2_DC6_HANDLE d2DC6);

//Name: D2FUNC_ADD_WINDOW
//Function: Adds a window to the window collection
//Param - d2hWnd: Handle to the window as obtained from D2FUNC_CREATE_WINDOW
//Module: N/A
//Ordinal: N/A
//Location: Local Code
typedef void (STDCALL * D2FUNC_ADD_WINDOW)(D2_WINDOW_HANDLE d2hWnd);

//Name: D2FUNCTIONTABLE
//Function: Table of function pointer to Diablo II functions
typedef struct{
	D2FUNC_CREATE_WINDOW		lpfnCreateWindow;
	D2FUNC_DESTROY_WINDOW		lpfnDestroyWindow;
	D2FUNC_CLEAR_WINDOWS		lpfnClearWindows;
	D2FUNC_LOAD_DC6_RESOURCE	lpfnLoadDC6Resource;
	D2FUNC_FREE_DC6_RESOURCE	lpfnFreeDC6Resource;
	D2FUNC_ADD_WINDOW			lpfnAddWindow;
}D2FUNCTIONTABLE, *LPD2FUNCTIONTABLE;

//==================================================================================
//		CLASSES
//==================================================================================

//==================================================================================
//		ADDITIONAL TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//Name: D2Init109b
//Function: Returns a D2FUNCTIONTABLE filled out with v1.09b function information
LPD2FUNCTIONTABLE D2Init109b();

//==================================================================================
//		TRAILING HEADERS
//==================================================================================

//==================================================================================
#endif