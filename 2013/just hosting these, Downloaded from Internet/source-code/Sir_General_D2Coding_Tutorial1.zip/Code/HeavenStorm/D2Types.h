#ifndef D2_TYPES_H
#define D2_TYPES_H
//==================================================================================
//
//		File: D2Types.h
//		Version: 1.00 - Diablo II v1.09x
//		
//		Provides definitions for Diablo II units, types, constants, etc.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include "MainDefinitions.h"

//==================================================================================
//		TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//Window types
typedef LPVOID D2_WINDOW_HANDLE;
typedef D2_WINDOW_HANDLE* LPD2_WINDOW_HANDLE;
#define D2_WINDOW_IMAGE			2
#define D2_WINDOW_ANIMATION		3
#define D2_WINDOW_BUTTON		6
#define D2_WINDOW_TIMER			8

//Unit types
#define D2_UNIT_PLAYER		0
#define D2_UNIT_NPC			1
#define D2_UNIT_MISSILE		3
#define D2_UNIT_ITEM		4

//Difficulties
#define D2_DIFFICULTY_NORMAL		0
#define D2_DIFFICULTY_NIGHTMARE		1
#define D2_DIFFICULTY_HELL			2

//Misc
typedef LPVOID D2_DC6_HANDLE;
#define D2_UNIT_SIZE	0x011C //In bytes, includes 4 for pointer to extra data

//Name: D2FUNC_WINDOW_CLICK
//Function: Prototype for the D2WINDOWINFO click function
//Param - d2hWnd: Handle to window calling the function
//Returns: Not sure, but I think 1 if successful, 0 otherwise
typedef ULONG (STDCALL * D2FUNC_WINDOW_CLICK)(D2_WINDOW_HANDLE d2hWnd);

//Name: D2WINDOWINFO
//Function: Contains information for creating a window
typedef struct{
	ULONG		ulType; //Window type, see definitions above
	ULONG		ulX; //The X position of the window, also timer time
	ULONG		ulY; //The Y position of the window's bottom
	ULONG		ulWidth; //Width of the window
	ULONG		ulHeight; //The height of the window
	ULONG		ulUnknown1;
	ULONG		ulUnknown2;
	LPVOID		lpImageDC6; //Pointer to a pointer to a DC6 for images
	LPVOID		lpfnOnClick; //Pointer to a click function, also timer fire func
	LPVOID		lpAnimDC6; //Pointer to an animation info structure
	ULONG		ulUnknown3;
	ULONG		ulUnknown4;
}D2WINDOWINFO, *LPD2WINDOWINFO;

//Name: D2WINDOWANIMSET
//Function: Contains information about a particular animated state
typedef struct{
	LPVOID		lpBaseDC6; //Pointer to a pointer that has the animation DC6
	LPVOID		lpSurroundDC6; //Pointer to a pointer that has an extra, semi-transparent DC6
	ULONG		ulBrightness; //Brightness level, display stuff?
	ULONG		ulAnimated; //0 - no, 1 - yes
}D2WINDOWANIMSET, *LPD2WINDOWANIMSET;

//Name: D2WINDOWANIMINFO
//Function: Contains information for an animated window image
typedef struct{
	D2WINDOWANIMSET		d2NormalAnim; //Animation info for normal state
	D2WINDOWANIMSET		d2OverAnim; //Animation info for mouse over state
	D2WINDOWANIMSET		d2UnknownAnim[3]; //Use unknown
}D2WINDOWANIMINFO, *LPD2WINDOWANIMINFO;

//==================================================================================
//		CLASSES
//==================================================================================

//==================================================================================
//		ADDITIONAL TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//==================================================================================
//		TRAILING HEADERS
//==================================================================================

//==================================================================================
#endif