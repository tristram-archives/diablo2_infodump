//==================================================================================
//
//		File: D2Functions.cpp
//		Version: 1.00
//		
//		Provides definitions for Diablo II functions.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include "MainDefinitions.h"
#include "D2Functions.h"

//==================================================================================
//		PRIVATE VARIABLES
//==================================================================================

static D2FUNCTIONTABLE d2FuncTable; //The function table

static INT iWindowCount = 0; //Window count, used by Add window
static D2_WINDOW_HANDLE d2hWindows[64]; //Window handles

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

//==================================================================================
//		PRIVATE FUNCTIONS
//==================================================================================

//Name: D2AddWindow
//Function: Adds a window to the internal collection
static void D2AddWindow(D2_WINDOW_HANDLE d2hWnd){

	d2hWindows[iWindowCount] = d2hWnd;
	iWindowCount++;

}

//Name: D2ClearWindows
//Function: Clears all windows that have been added using D2AddWindow
static void D2ClearWindows(){

	for(int i = 0; i < iWindowCount; i++){
		lpd2Functions->lpfnDestroyWindow(&d2hWindows[i]);
	}
	iWindowCount = 0;

}

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//Name: D2Init109b
//Function: Returns a D2FUNCTIONTABLE filled out with v1.09b function information
LPD2FUNCTIONTABLE D2Init109b(){

	d2FuncTable.lpfnCreateWindow = (D2FUNC_CREATE_WINDOW)0x6F8AEE30;
	d2FuncTable.lpfnDestroyWindow = (D2FUNC_DESTROY_WINDOW)0x6F8AF000;
	d2FuncTable.lpfnClearWindows = (D2FUNC_CLEAR_WINDOWS)&D2ClearWindows;
	d2FuncTable.lpfnLoadDC6Resource = (D2FUNC_LOAD_DC6_RESOURCE)0x6F8A76C0;
	d2FuncTable.lpfnFreeDC6Resource = (D2FUNC_FREE_DC6_RESOURCE)0x6F8A7810;
	d2FuncTable.lpfnAddWindow = (D2FUNC_ADD_WINDOW)&D2AddWindow;

	return &d2FuncTable;

}

//==================================================================================
//		CLASS FUNCTIONS
//==================================================================================