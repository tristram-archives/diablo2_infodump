//==================================================================================
//
//		File: UMemory.cpp
//		Version: 1.00
//		
//		Provides memory allocation and freeing.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include <stdlib.h>
#include <malloc.h>

#include "MainDefinitions.h"
#include "UError.h"

//==================================================================================
//		PRIVATE VARIABLES
//==================================================================================

static LPSTR szFile = "Heaven Storm\\Utilities\\UMemory.cpp";

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

//==================================================================================
//		PRIVATE FUNCTIONS
//==================================================================================

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//Name: UMemAlloc
//Function: Allocates a block of memory and returns a pointer
LPVOID UMemAlloc(INT iSize){

	LPVOID lpMemory = malloc(iSize);
	if(lpMemory == NULL){
		UErrThrowError(szFile, "UMemAlloc", "Unable to allocate the requested memory", UERR_ERROR_OUT_OF_MEMORY);
		return NULL;
	}

	return lpMemory;

}

//Name: UMemRealloc
//Function: Reallocates a block of memory with a new size
LPVOID UMemRealloc(LPVOID lpMem, INT iSize){

	LPVOID lpMemory = realloc(lpMem, iSize);
	if(lpMemory == NULL){
		UErrThrowError(szFile, "UMemRealloc", "Unable to reallocate the requested memory", UERR_ERROR_OUT_OF_MEMORY);
		return NULL;
	}

	return lpMemory;

}

//Name: UMemFree
//Function: Frees an allocated block of memory
void UMemFree(LPVOID lpMem){

	free(lpMem);

}

//==================================================================================
//		CLASS FUNCTIONS
//==================================================================================