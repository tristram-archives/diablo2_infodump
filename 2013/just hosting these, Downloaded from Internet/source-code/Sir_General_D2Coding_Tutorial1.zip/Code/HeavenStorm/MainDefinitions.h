#ifndef MAIN_DEFINITIONS_H
#define MAIN_DEFINITIONS_H
//==================================================================================
//
//		File: MainDefinitions.h
//		Version: 1.00
//		
//		Contains definitions and types used by the entire program, as well as any 
//		necessary header files, variables, etc.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include <windows.h>

//==================================================================================
//		TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//Calling conventions
#define STDCALL		__stdcall
#define FASTCALL	__fastcall

//Type definitions
#define SCHAR	signed char
#define UBYTE	unsigned char
#define SBYTE	signed char
#define SSHORT	signed short
#define SWORD	signed short
#define SLONG	signed long
#define UDWORD	unsigned long
#define SDWORD	signed long
#define SINT	signed int

//Misc definitions
#define APP_VERSION "v1.00"

//==================================================================================
//		CLASSES
//==================================================================================

//==================================================================================
//		ADDITIONAL TYPEDEFS / ENUMERATIONS / DEFINES / HEADERS
//==================================================================================

#include "D2Functions.h"

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

extern HANDLE hDLLModule; //Handle to the DLL module
extern CHAR szAppPath[MAX_PATH]; //The current working directory
extern LPD2FUNCTIONTABLE lpd2Functions; //Pointer to function table

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//==================================================================================
//		TRAILING HEADERS
//==================================================================================

//==================================================================================
#endif