#ifndef GUI_TITLE_SCREEN_H
#define GUI_TITLE_SCREEN_H
//==================================================================================
//
//		File: GUITitleScreen.h
//		Version: 1.00
//		
//		Handles the drawing and events for the title screen/trademark screen.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include "MainDefinitions.h"

//==================================================================================
//		TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//DC6 Resources
#define GUI_TM_COPYRIGHTDC6		"HeavenStorm\\Data\\Global\\UI\\TitleScreen\\Copyright"
#define GUI_TS_TITLEDC6			"HeavenStorm\\Data\\Global\\UI\\TitleScreen\\HSTitle"

//==================================================================================
//		CLASSES
//==================================================================================

//==================================================================================
//		ADDITIONAL TYPEDEFS / ENUMERATIONS / DEFINES
//==================================================================================

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//Name: GUITrademarkScreenInit
//Function: Creates all windows for the trademark screen
void GUITrademarkScreenInit();

//Name: GUITitleScreenLoad
//Function: Loads all resources required for the title screen
void GUITitleScreenLoad();

//Name: GUITitleScreenFree
//Function: Frees all resources used by the title screen
void GUITitleScreenFree();

//Name: GUITitleScreenInit
//Function: Creates all the windows necessary for the title screen
void GUITitleScreenInit();

//==================================================================================
//		TRAILING HEADERS
//==================================================================================

//==================================================================================
#endif