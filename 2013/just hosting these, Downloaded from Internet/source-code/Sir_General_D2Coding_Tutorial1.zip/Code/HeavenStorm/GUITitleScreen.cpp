//==================================================================================
//
//		File: GUITitleScreen.cpp
//		Version: 1.00
//		
//		Handles the drawing and events for the title screen/trademark screen.
//
//		Copyright(c) 2002 - Sir_General
//
//==================================================================================
//		REQUIRED HEADER FILES
//==================================================================================

#include "MainDefinitions.h"
#include "UError.h"
#include "GUITitleScreen.h"

//==================================================================================
//		PRIVATE VARIABLES
//==================================================================================

static LPSTR szFile = "Heaven Storm\\GUI\\GUITitleScreen.cpp";
//Trademark screen resources
static D2_DC6_HANDLE dc6TSCopyright = NULL;
//Title screen resources
static D2_DC6_HANDLE dc6TSTitle = NULL;

//==================================================================================
//		PUBLIC VARIABLES
//==================================================================================

//==================================================================================
//		PRIVATE FUNCTIONS
//==================================================================================

//Name: GUITrademarkScreenClose
//Function: Closes the trademark screen and loads the title screen
static ULONG GUITrademarkScreenClose(D2_WINDOW_HANDLE d2hWnd){

	//Close trademark screen windows
	lpd2Functions->lpfnClearWindows();

	GUITitleScreenInit();
	return 1;

}

//==================================================================================
//		PUBLIC FUNCTIONS
//==================================================================================

//Name: GUITrademarkScreenInit
//Function: Creates all windows for the trademark screen
void GUITrademarkScreenInit(){

	D2_WINDOW_HANDLE d2hWnd = NULL;
	D2WINDOWINFO d2WinInfo;
	ZeroMemory(&d2WinInfo, sizeof(D2WINDOWINFO));

	//Create the title
	d2WinInfo.ulType = D2_WINDOW_IMAGE;
	d2WinInfo.ulY = 140;
	d2WinInfo.ulX = 16;
	d2WinInfo.ulWidth = 768;
	d2WinInfo.ulHeight = 150;
	d2WinInfo.lpImageDC6 = &dc6TSTitle;
	d2WinInfo.lpfnOnClick = (LPVOID)&GUITrademarkScreenClose;
	d2hWnd = lpd2Functions->lpfnCreateWindow(&d2WinInfo);
	lpd2Functions->lpfnAddWindow(d2hWnd);

	//Create the copyright
	ZeroMemory(&d2WinInfo, sizeof(D2WINDOWINFO));
	d2WinInfo.ulType = D2_WINDOW_IMAGE;
	d2WinInfo.ulY = 599;
	d2WinInfo.ulX = 0;
	d2WinInfo.ulWidth = 585;
	d2WinInfo.ulHeight = 113;
	d2WinInfo.lpImageDC6 = &dc6TSCopyright;
	d2WinInfo.lpfnOnClick = (LPVOID)&GUITrademarkScreenClose;
	d2hWnd = lpd2Functions->lpfnCreateWindow(&d2WinInfo);
	lpd2Functions->lpfnAddWindow(d2hWnd);

	//Create a timer to go title screen after 9 seconds
	ZeroMemory(&d2WinInfo, sizeof(D2WINDOWINFO));
	d2WinInfo.ulType = D2_WINDOW_TIMER;
	d2WinInfo.ulX = 9;
	d2WinInfo.lpfnOnClick = (LPVOID)&GUITrademarkScreenClose;
	d2hWnd = lpd2Functions->lpfnCreateWindow(&d2WinInfo);
	lpd2Functions->lpfnAddWindow(d2hWnd);

}

//Name: GUITitleScreenLoad
//Function: Loads all resources required for the title screen
void GUITitleScreenLoad(){

	//Load DC6 resources
	dc6TSCopyright = lpd2Functions->lpfnLoadDC6Resource(GUI_TM_COPYRIGHTDC6, 0);
	if(dc6TSCopyright == NULL){
		UErrThrowError(szFile, "GUITrademarkScreenLoad", "Failed to load Copyright.dc6", UERR_ERROR_LOAD_DC6);
	}

	dc6TSTitle = lpd2Functions->lpfnLoadDC6Resource(GUI_TS_TITLEDC6, 0);
	if(dc6TSTitle == NULL){
		UErrThrowError(szFile, "GUITitleScreenLoad", "Failed to load HSTitle.dc6", UERR_ERROR_LOAD_DC6);
	}

}

//Name: GUITitleScreenFree
//Function: Frees all resources used by the title screen
void GUITitleScreenFree(){

	if(dc6TSCopyright != NULL){
		lpd2Functions->lpfnFreeDC6Resource(dc6TSCopyright);
		dc6TSCopyright = NULL;
	}

	if(dc6TSTitle != NULL){
		lpd2Functions->lpfnFreeDC6Resource(dc6TSTitle);
		dc6TSTitle = NULL;
	}

}

//Name: GUITitleScreenInit
//Function: Creates all the windows necessary for the title screen
void GUITitleScreenInit(){

	D2_WINDOW_HANDLE d2hWnd = NULL;
	D2WINDOWINFO d2WinInfo;
	ZeroMemory(&d2WinInfo, sizeof(D2WINDOWINFO));

	//Create the title
	d2WinInfo.ulType = D2_WINDOW_IMAGE;
	d2WinInfo.ulY = 140;
	d2WinInfo.ulX = 16;
	d2WinInfo.ulWidth = 768;
	d2WinInfo.ulHeight = 150;
	d2WinInfo.lpImageDC6 = &dc6TSTitle;
	d2hWnd = lpd2Functions->lpfnCreateWindow(&d2WinInfo);
	lpd2Functions->lpfnAddWindow(d2hWnd);

}

//==================================================================================
//		CLASS FUNCTIONS
//==================================================================================