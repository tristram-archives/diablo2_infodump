//==================================================================================
//
//		File: KillCounter.cpp
//		Version: 1.02
//		
//		This file is the single C/C++ source file necessary for building the kill 
//		counter.  I've decided to just squeeze it all into this single file because 
//		things seem to work better like that.
//
//		Copyright(c) 2003 - Sir_General
//
//==================================================================================

//REQUIRED HEADER FILES

#include <windows.h>
#include <malloc.h>
#include <wchar.h>


//TYPEDEFS, STRUCTS, DEFINES, ETC.

#define FASTCALL	__fastcall
#define STDCALL		__stdcall
#define ASM			__asm
#define NAKED		__declspec(naked)

#define D2_UNIT_SIZE 0x11C	//Size of a ptUnit

//Name: D2UNIT
//Function: Basic Diablo II unit structure
typedef struct{
	ULONG	ulType; //Unit Type
	ULONG	ulTypeID; //Provides ID based on type
	ULONG	ulUnitID; //Unique ID for the unit
	ULONG	ulUnitData[67]; //Data, varies for each unit
	LPVOID	lpCustomData; //Pointer to our custom data
}D2UNIT, *LPD2UNIT;

//Name: D2NETCLIENT
//Function: Used when sending data to clients
typedef LPVOID D2NETCLIENT;

//Name: D2FUNC_GET_MINION_OWNER
//Function: Gets the owner of a minion
//Param - ptMinion: This is the minion to get the owner for
//Returns: The owner of the given minion
//Location - v1.09b: D2Game.6FCBC350
typedef LPD2UNIT (FASTCALL * D2FUNC_GET_MINION_OWNER)(LPD2UNIT ptMinion);

//Name: D2FUNC_IS_MONSTER_UNDEAD
//Function: Checks to see if a monster is undead
//Param - ptMonster: This is the monster to check
//Returns: 0 if NOT undead, otherwise non-zero
//Location - v1.09b: D2Common.6FD989E0
typedef ULONG (STDCALL * D2FUNC_IS_MONSTER_UNDEAD)(LPD2UNIT ptMonster);

//Name: D2FUNC_IS_MONSTER_DEMON
//Function: Checks to see if a monster is a demon
//Param - ptMonster: This is the monster to check
//Returns: 0 if NOT a demon, otherwise non-zero
//Location - v1.09b: D2Common.6FD989B0
typedef ULONG (STDCALL * D2FUNC_IS_MONSTER_DEMON)(LPD2UNIT ptMonster);

//Name: D2FUNC_SEND_PACKET_TO_CLIENT
//Function: Sends the specified data to the client
//Param - ptNetClient: Network client to send the data to
//Param - lpData: Pointer to the data to send
//Param - ulSize: Size of the data to send
//Returns: The amount of data sent
//Location - v1.09b: D2Game.6FC3C380
typedef ULONG (FASTCALL * D2FUNC_SEND_PACKET_TO_CLIENT)(D2NETCLIENT ptNetClient, LPVOID lpData, ULONG ulSize);

//Name: D2FUNC_GET_NET_CLIENT
//Function: Gets the network client of a player ptUnit
//Param - ptUnit: Unit to get network client for
//Param - lpszErrFile: Used in error handling by D2, file calling the function
//Param - ulErrLine: Used in error handling by D2, line # of code calling function
//Returns: D2NETCLIENT for the given ptUnit
//Location - v1.09b: D2Game.6FCAC2C0
typedef D2NETCLIENT (FASTCALL * D2FUNC_GET_NET_CLIENT)(LPD2UNIT ptUnit, LPSTR lpszErrFile, ULONG ulErrLine);

//Name: D2FUNC_CLIENT_GET_PLAYER
//Function: Gets the client side ptUnit that represents their player
//Returns: ptUnit that represents player
//Location - v1.09b: D2Client.6FB2DC40
typedef LPD2UNIT (STDCALL * D2FUNC_CLIENT_GET_PLAYER)();

//Name: D2FUNC_PRINT_TEXT
//Function: Prints a *UNICODE* string to the screen
//Param - lpwszText: Text to print
//Param - ulLeft: X location of the left most pixel
//Param - ulTop: Y location of the top most pixel
//Param - ulColor: The color of the text
//Param - ulZero: Usually just zero
//Location - v1.09b: D2Win.6F8ACBF0
typedef void (FASTCALL * D2FUNC_PRINT_TEXT)(LPWSTR lpwszText, ULONG ulLeft, ULONG ulTop, ULONG ulColor, ULONG ulZero);

#define D2FONT_NORMAL	1 //Normal sized font
#define D2FONT_SMALL	0 //A smaller sized font
#define D2FONT_TINY		6 //The smallest font there is

//Name: D2FUNC_SET_TEXT_FONT
//Function: Sets the font used by D2FUNC_PRINT_TEXT
//Param - ulFont: The font number to use
//Location - v1.09b: D2Win.6F8ABE50
typedef void (FASTCALL * D2FUNC_SET_TEXT_FONT)(ULONG ulFont);

//Name: D2FUNC_GET_TEXT_WIDTH
//Function: Gets the width of text in pixels for the current font
//Param - lpwszText: Text to get width of
//Returns: Width of text in pixels
//Location - v1.09b: D2Win.6F8AC100
typedef ULONG (FASTCALL * D2FUNC_GET_TEXT_WIDTH)(LPWSTR lpwszText);

#define KC_TOTAL_KILLS		0	//Array index for total kills
#define KC_UNDEAD_KILLS		1	//Array index for undead kills
#define KC_DEMON_KILLS		2	//Array index for demon kills

//Name: KCCUSTOMDATA
//Function: Kill counter custom data
typedef struct{
	ULONG	ulData[3]; //Total kills
}KCCUSTOMDATA, *LPKCCUSTOMDATA;

//Name: KCCUSTOMDATAPACKET
//Function: Packet to be sent to clients to update their data
typedef struct{
	UCHAR	ucType; //The packet type (used by D2), ours is 0x9D
	UCHAR	ucFunc; //Specifies a more specific function, ours is 0x18
	UCHAR	ucSize; //Size of the packet
	ULONG	ulReserved; //Used with items (we won't be using it though)
	UCHAR	ucZero; //This always appears to be zero
	ULONG	ulPlayerID; //This would be ptUnit + 08h
	ULONG	ulData[3]; //This will contain the kill information
}KCCUSTOMDATAPACKET, *LPKCCUSTOMDATAPACKET;


//VARIABLES

D2FUNC_GET_MINION_OWNER lpfnGetMinionOwner = (D2FUNC_GET_MINION_OWNER)0x6FCBC350;
D2FUNC_IS_MONSTER_UNDEAD lpfnIsMonsterUndead = (D2FUNC_IS_MONSTER_UNDEAD)0x6FD989E0;
D2FUNC_IS_MONSTER_DEMON lpfnIsMonsterDemon = (D2FUNC_IS_MONSTER_DEMON)0x6FD989B0;
D2FUNC_SEND_PACKET_TO_CLIENT lpfnSendPacketToClient = (D2FUNC_SEND_PACKET_TO_CLIENT)0x6FC3C380;
D2FUNC_GET_NET_CLIENT lpfnGetNetClient = (D2FUNC_GET_NET_CLIENT)0x6FCAC2C0;
D2FUNC_CLIENT_GET_PLAYER lpfnClientGetPlayer = (D2FUNC_CLIENT_GET_PLAYER)0x6FB2DC40;
D2FUNC_PRINT_TEXT lpfnPrintText = (D2FUNC_PRINT_TEXT)0x6F8ACBF0;
D2FUNC_SET_TEXT_FONT lpfnSetTextFont = (D2FUNC_SET_TEXT_FONT)0x6F8ABE50;
D2FUNC_GET_TEXT_WIDTH lpfnGetTextWidth = (D2FUNC_GET_TEXT_WIDTH)0x6F8AC100;


//FUNCTIONS

//Name: GetScreenWidth
//Function: Gets the screen width
NAKED ULONG GetScreenWidth(){

	ASM{
		MOV EAX, DWORD PTR DS:[0x6FB750E4];
		RETN;
	};

}

//Name: GetScreenHeight
//Function: Gets the screen height
NAKED ULONG GetScreenHeight(){

	ASM{
		MOV EAX, DWORD PTR DS:[0x6FB750E8];
		RETN;
	}

}

//Name: CheckPointer
//Function: Performs a read/write check on a pointer
BOOL CheckPointer(LPVOID lpPointer, INT iSize){

	if(IsBadReadPtr(lpPointer, iSize) != 0){
		return FALSE;
	}

	return (IsBadWritePtr(lpPointer, iSize) == 0);

}

//Name: AllocCustomData
//Function: Allocates the custom data and puts in place for the given unit
LPKCCUSTOMDATA AllocCustomData(LPD2UNIT ptUnit){

	//Check to make sure ptUnit is valid
	if(!CheckPointer(ptUnit, D2_UNIT_SIZE)){
		return NULL;
	}

	//Allocate custom data
	LPKCCUSTOMDATA lpCustomData = (LPKCCUSTOMDATA)malloc(sizeof(KCCUSTOMDATA));
	//Check to see if it succeeded
	if(lpCustomData == NULL){
		return NULL;
	}
	ZeroMemory(lpCustomData, sizeof(KCCUSTOMDATA));

	//Now, set it in ptUnit
	ptUnit->lpCustomData = lpCustomData;

	return lpCustomData;

}

//Name: ReadCustomData
//Function: Reads the specified value from the custom data
ULONG ReadCustomData(LPD2UNIT ptUnit, INT iIndex){

	//Start by checking the unit
	if(!CheckPointer(ptUnit, D2_UNIT_SIZE)){
		return 0;
	}

	//Now check the custom data
	if(!CheckPointer(ptUnit->lpCustomData, sizeof(KCCUSTOMDATA))){
		return 0;
	}

	//Check the index
	if( (iIndex < 0) || (iIndex > 2) ){
		return 0;
	}

	//Now get the data
	return ((LPKCCUSTOMDATA)ptUnit->lpCustomData)->ulData[iIndex];

}

//Name: WriteCustomData
//Function: Writes a value to the custom data
void WriteCustomData(LPD2UNIT ptUnit, INT iIndex, ULONG ulValue){

	//Start with a check on ptUnit
	if(!CheckPointer(ptUnit, D2_UNIT_SIZE)){
		return;
	}

	//Now set the initial data
	LPKCCUSTOMDATA lpCustomData = (LPKCCUSTOMDATA)ptUnit->lpCustomData;

	//Check validaty on the custom data
	if(!CheckPointer(lpCustomData, sizeof(KCCUSTOMDATA))){
		//It failed, but we can allocate memory to write to
		lpCustomData = AllocCustomData(ptUnit);
		//Check to make sure that didn't fail
		if(lpCustomData == NULL){
			return;
		}
	}

	//Now check the index
	if( (iIndex < 0) || (iIndex > 2) ){
		return;
	}

	//Set the value we want
	lpCustomData->ulData[iIndex] = ulValue;

}

//Name: ChangeCustomData
//Function: Changes the value in custom data by the specified amount
void ChangeCustomData(LPD2UNIT ptUnit, INT iIndex, ULONG ulValue){

	//Start with a check on ptUnit
	if(!CheckPointer(ptUnit, D2_UNIT_SIZE)){
		return;
	}

	//Now set the initial data
	LPKCCUSTOMDATA lpCustomData = (LPKCCUSTOMDATA)ptUnit->lpCustomData;

	//Check validaty on the custom data
	if(!CheckPointer(lpCustomData, sizeof(KCCUSTOMDATA))){
		//It failed, but we can allocate memory to write to
		lpCustomData = AllocCustomData(ptUnit);
		//Check to make sure that didn't fail
		if(lpCustomData == NULL){
			return;
		}
	}

	//Now check the index
	if( (iIndex < 0) || (iIndex > 2) ){
		return;
	}

	//Change the value we want
	lpCustomData->ulData[iIndex] += ulValue;

}

//Name: SaveCustomData
//Function: Saves custom data to the save file
ULONG SaveCustomData(LPD2UNIT ptUnit, UCHAR ucData[], ULONG ulCurrSize){

	//Check the unit pointer
	if(!CheckPointer(ptUnit, D2_UNIT_SIZE)){
		return ulCurrSize;
	}

	//The result we return
	ULONG ulResult = ulCurrSize;

	//First we'll write in a header that will help us when loading
	*((DWORD *)&ucData[ulResult]) = 0xABCDEF12;
	ulResult += 4;

	//Now we need to write in our custom data
	for(INT i = 0; i < 3; i++){
		*((DWORD *)&ucData[ulResult]) = ReadCustomData(ptUnit, i);
		ulResult += 4;
	}

	//And return the new size of the data
	return ulResult;

}

//Name: LoadCustomData
//Function: Loads custom data from a save file
ULONG LoadCustomData(LPD2UNIT ptUnit, UCHAR ucData[], ULONG ulCurrPos){

	//Start by checking the pointer
	if(!CheckPointer(ptUnit, D2_UNIT_SIZE)){
		return ulCurrPos;
	}

	ULONG ulResult = ulCurrPos;

	//Now we look for the header to make sure we should be loading
	if( (*((DWORD *)&ucData[ulResult])) != 0xABCDEF12 ){
		return ulCurrPos;
	}
	ulResult += 4;

	//Now read in our data
	for(INT i = 0; i < 3; i++){
		WriteCustomData(ptUnit, i, (*((DWORD *)&ucData[ulResult])));
		ulResult += 4;
	}

	return ulResult;

}

//Name: UpdateClientData
//Function: Updates the kill information for the client
void UpdateClientData(LPD2UNIT ptClient){

	//Start by checking the pointer
	if(!CheckPointer(ptClient, D2_UNIT_SIZE)){
		return;
	}

	//Next make sure this is a player unit - trying to send packets 
	//to a non-player unit will crash the program
	if(ptClient->ulType != 0){
		return;
	}

	//Now get the network client
	D2NETCLIENT d2Net = lpfnGetNetClient(ptClient, "Error String", 0);
	
	//Setup the packet information
	KCCUSTOMDATAPACKET kcPacket;
	ZeroMemory(&kcPacket, sizeof(KCCUSTOMDATAPACKET));

	kcPacket.ucType = 0x9D;
	kcPacket.ucFunc = 0x18;
	kcPacket.ucSize = sizeof(KCCUSTOMDATAPACKET);
	kcPacket.ulPlayerID = ptClient->ulUnitID;
	
	for(INT i = 0; i < 3; i++){
		kcPacket.ulData[i] = ReadCustomData(ptClient, i);
	}

	//Now that the packet is set, we send it to the client
	lpfnSendPacketToClient(d2Net, &kcPacket, sizeof(KCCUSTOMDATAPACKET));

}

//Name: IncrementKills
//Function: Increments the kill counter
void IncrementKills(LPD2UNIT ptKiller, LPD2UNIT ptKilled){

	//Start by checking the killer/killed pointers
	if(!CheckPointer(ptKiller, D2_UNIT_SIZE)){
		return;
	}
	if(!CheckPointer(ptKilled, D2_UNIT_SIZE)){
		return;
	}

	//Now, we need to figure who actually gets the kill
	LPD2UNIT ptReceiver = ptKiller;

	//Check if we have a non-player killer
	if(ptReceiver->ulType != 0){

		//If it's not a monster/minion, leave
		if(ptReceiver->ulType != 1){
			return;
		}

		//Get the monster/minion owner
		ptReceiver = lpfnGetMinionOwner(ptReceiver);

		//Validate receiver pointer
		if(!CheckPointer(ptReceiver, D2_UNIT_SIZE)){
			return;
		}

		//Check to see if we have a player now, if not leave
		if(ptReceiver->ulType != 0){
			return;
		}

	}

	//At this pointer, we should have the player who gets the kill
	//so all we do is increment it by one
	ChangeCustomData(ptReceiver, KC_TOTAL_KILLS, 1);

	//Now, we check for an undead kill
	if(lpfnIsMonsterUndead(ptKilled) != 0){
		ChangeCustomData(ptReceiver, KC_UNDEAD_KILLS, 1);
	}

	//And finally a demon kill
	if(lpfnIsMonsterDemon(ptKilled) != 0){
		ChangeCustomData(ptReceiver, KC_DEMON_KILLS, 1);
	}

	//Lastly, we send the update to the client
	UpdateClientData(ptReceiver);

}

//Name: HandleClientUpdate
//Function: Handles a client update packet
void HandleClientUpdate(LPKCCUSTOMDATAPACKET lpPacket){

	//Start by checking to make sure the packet's func is 18h (our function)
	if(lpPacket->ucFunc != 0x18){
		return;
	}

	//Get the client's player
	LPD2UNIT ptPlayer = lpfnClientGetPlayer();

	//Now we just write the data to the client's player from the packet
	for(INT i = 0; i < 3; i++){
		WriteCustomData(ptPlayer, i, lpPacket->ulData[i]);
	}

}

//Name: DrawKillCounter
//Function: Prints out all the kill counter text
void DrawKillCounter(){

	//We can start by getting the client's player
	LPD2UNIT ptPlayer = lpfnClientGetPlayer();

	//Now we set up a few strings (in unicode)
	LPWSTR lpwszUndead = L"Undead";
	LPWSTR lpwszDemon = L"Demon";
	LPWSTR lpwszKills = L"Kills";

	//Now we need to set up the X/Y locations to print the text at
	ULONG ulX = 11 + ((GetScreenWidth() - 640) / 2);
	ULONG ulY = 280 + ((GetScreenHeight() - 480) / 2);
	ULONG ulXAdd = 0; //We'll use this to center the text
	ULONG ulWidth = 0; //Text width

	//Set the text font before printing
	lpfnSetTextFont(D2FONT_TINY);

	//Print the text "Kills"
	lpfnPrintText(lpwszKills, ulX + 8, ulY + 4, 0, 0);
	//Print the text "Demon Kills"
	lpfnPrintText(lpwszDemon, ulX + 6, ulY + 34, 0, 0);
	lpfnPrintText(lpwszKills, ulX + 8, ulY + 42, 0, 0);
	//Print the text "Undead Kills"
	lpfnPrintText(lpwszUndead, ulX + 4, ulY + 68, 0, 0);
	lpfnPrintText(lpwszKills, ulX + 8, ulY + 76, 0, 0);

	//This holds the kill count as a string
	WCHAR wszCount[32] = L"";

	//Set the text font before printing
	lpfnSetTextFont(D2FONT_NORMAL);
	//And update the X position
	ulX += 47;

	//Start with total kills
	//First get the count as a string
	swprintf(wszCount, L"%u", ReadCustomData(ptPlayer, KC_TOTAL_KILLS));
	//Next we get the width of the string
	ulWidth = lpfnGetTextWidth(wszCount);
	//And center this in the display box
	ulXAdd = ((90 - ulWidth) / 2);
	//Finally, we print it
	lpfnPrintText(wszCount, ulX + ulXAdd, ulY + 4, 0, 0);

	//Now we do the demon kills
	swprintf(wszCount, L"%u", ReadCustomData(ptPlayer, KC_DEMON_KILLS));
	ulWidth = lpfnGetTextWidth(wszCount);
	ulXAdd = ((90 - ulWidth) / 2);
	lpfnPrintText(wszCount, ulX + ulXAdd, ulY + 38, 0, 0);

	//And lastly the undead kills
	swprintf(wszCount, L"%u", ReadCustomData(ptPlayer, KC_UNDEAD_KILLS));
	ulWidth = lpfnGetTextWidth(wszCount);
	ulXAdd = ((90 - ulWidth) / 2);
	lpfnPrintText(wszCount, ulX + ulXAdd, ulY + 72, 0, 0);
	
}

//Name: WriteDLLChanges
//Function: Writes in the necessary DLL changes
void WriteDLLChanges(){

	DWORD dw = 0;

	//Change D2Game.dll
	VirtualProtect((LPVOID)0x6FC31000, 0xCF000, PAGE_EXECUTE_READWRITE, &dw);
	//Change D2Client.dll
	VirtualProtect((LPVOID)0x6FAA1000, 0xCB000, PAGE_EXECUTE_READWRITE, &dw);

	*((LPINT)0x6FCB0CCC) = (INT)&IncrementKills;
	*((LPINT)0x6FB6BFA0) = (INT)&HandleClientUpdate;
	*((LPINT)0x6FB6BF30) = (INT)&DrawKillCounter;
	*((LPINT)0x6FCFFFD0) = (INT)&SaveCustomData;
	*((LPINT)0x6FCFFFA0) = (INT)&LoadCustomData;
	*((LPINT)0x6FCFFEF0) = (INT)&UpdateClientData;

}

//Name: DllMain
//Function: Entry point for the DLL
BOOL WINAPI DllMain(HANDLE hModule, DWORD dwReason, LPVOID lpReserved){

	switch(dwReason){
		case DLL_PROCESS_ATTACH: //First time loading
			LoadLibrary("D2Game.dll");
			LoadLibrary("D2Client.dll");
			WriteDLLChanges();
			break;
		case DLL_PROCESS_DETACH: //Final time leaving

			break;
	}

	return TRUE;

}