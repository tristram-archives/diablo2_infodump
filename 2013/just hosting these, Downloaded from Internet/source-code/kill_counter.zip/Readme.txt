Kill Counter Plugin v1.02 by Sir_General

This plugin will create a kill counter that will keep track your total kills, 
your demon kills, and your undead kills in Diablo II: Lord of Destruction v1.09b.  
It's very important that you see the v1.09b.  This will more than likely crash and burn 
in any other version of Diablo II.

To use, just put the included D2Win.dll, D2Game.dll, D2Client.dll, and Kill COunter.dll 
files in your Diablo II directory.  It also comes with a new character screen, 
which is InvChar6.dc6.  Place this in the Data\Global\UI\Panel directory of 
either Patch_D2.mpq or Diablo II.  It works with existing characters and new characters.  
It will also work with any mod that does NOT use DLL swapping.

Also included is the source for the Kill Counter.dll file as well as an depth tutorial 
on creating the kill counter.

If you find bugs or have comments, please send the to sir_general@planetdiablo.com.  Enjoy.


v1.02 Changes
======================================================
-Fixed a crash that could occur when enemies were killed by a non-player unit.

v1.01 Changes
======================================================
-Fixed a crash that occurred when creating new characters.
-Included a new character screen so things look semi-normal.