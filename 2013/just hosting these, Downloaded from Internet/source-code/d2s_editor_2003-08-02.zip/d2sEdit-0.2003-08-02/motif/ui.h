/* Declarations common to all modules.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Intrinsic.h>
#include <Xm/Xm.h>
#include <Mrm/MrmAppl.h>
#include "callbacks.h"
#ifdef __cplusplus
#include "d2sData.h"
#include "d2sItem.h"
#endif /* C++ */
#include "define.h"
#include "functions.h"
#include "util.h"
#include "options.h"
#include "paths.h"

#if 0
/* DEBUG: intercept the pixmap cache */
#define XmDestroyPixmap(screen,pixmap) {		\
	fprintf (stderr, "DEBUG: Pixmap %p destroyed at %s:%d\n",	\
		 (void *) pixmap, __FILE__, __LINE__);	\
	(XmDestroyPixmap) (screen, pixmap);		}

#define XmGetPixmap(screen,name,fg,bg) ({		\
	Pixmap _pixmap;					\
	_pixmap = (XmGetPixmap) (screen, name, fg, bg);	\
	fprintf (stderr, "DEBUG: Pixmap %p created   at %s:%d\n",	\
		 (void *) _pixmap, __FILE__, __LINE__);	\
	_pixmap;					})
#define load_item_picture(screen,item) ({		\
	Pixmap _pixmap;					\
	_pixmap = (load_item_picture) (screen, item);	\
	fprintf (stderr, "DEBUG: Pixmap %p cached    at %s:%d\n",	\
		 (void *) _pixmap, __FILE__, __LINE__);	\
	_pixmap;					})
#define load_item_mask(screen,item) ({			\
	Pixmap _pixmap;					\
	_pixmap = (load_item_mask) (screen, item);	\
	fprintf (stderr, "DEBUG: Pixmap %p cached    at %s:%d\n",	\
		 (void *) _pixmap, __FILE__, __LINE__);	\
	_pixmap;					})
#endif

/* The name of the program as called */
extern const char *progname;
/* UI element associated with messages, or NULL */
extern void *stdui;

/* The application context */
extern XtAppContext app_context;
/* The top-level application widget */
extern Widget toplevel;
/* Document shell widgets (additional topLevelShell's) */
extern Widget *doc_shell_list;
extern Widget *item_doc_shell_list;
extern Widget *library_shell_list;
/* The number of document windows open */
extern int doc_shell_count;
extern int item_doc_shell_count;
extern int library_shell_count;
/* The Mrm hierarchy, used when we need to dynamically create another
   copy of a widget tree (e.g., another character file or item editor) */
extern MrmHierarchy mrm_hierarchy;
extern MrmHierarchy item_mrm_hierarchy;

#ifdef __cplusplus
/* Character icons; shared by open.cc and char_window.cc */
extern Pixmap class_icons[NUM_CHAR_CLASSES + MAX_NUM_ACTS];
/* Gem socket icon; shared by item_popup.cc and item_editor.cc,
   storage courtesy of char_window.cc */
extern Pixmap gem_socket_icon;

extern "C" {
#endif
/* Functions that interface the GUI with the internal data */

  /* Initialize the screens with constant data (labels): */
  void ui_init_display (void);

  /* Initialize the item editor */
  int ie_init (void);

  /* Clear out the text fields in the top-level window
     (called by ui_init_display and used when closing a file). */
  void ui_clear_d2sdata (Widget);

  /* Create (or destroy) fixed drop sites in a character window */
  void register_drop_sites (Widget window);
  /* Same for drop sites in an item editor window */
  void register_item_drop_sites (Widget window);

  /* Variation of XtNameToWidget, guaranteed to
     return successfully or not at all. */
  Widget XxNameToWidget (Widget, const char *);

  /* Manage the child of a widget that has already been displayed */
  void XxManageChild (Widget);

  /* Xm-like function that gets the index number of
     the currently selected item in an option menu. */
  short XmOptionMenuGetSelection (Widget);

  /* Xm-like function that sets the currently selected
     item in an option menu by its index number. */
  void XmOptionMenuSetSelection (Widget, short);

  /* Xm-like function that properly sets a radio button
     without calling any of the toggle callbacks. */
  void XmRadioButtonSetOn (Widget);

  /* Xm-like function that gets the full path from a
     file selection dialog, if a file name is valid. */
  char *XxFileSelectionBoxGetFullPath (Widget dialog, Boolean file_required,
				       XmFileSelectionBoxCallbackStruct *);

  /* Create a blank document window (to be filled in) */
  Widget create_document_window (void);
#ifdef __cplusplus
}

/* Fill in the blanks (and change certain labels) from a saved game: */
void display_d2sData (Widget, d2sData *);

/* Open the item editor */
Widget open_item_editor_window (d2sItem *item);
/* Place an item in a new editor window */
void place_item_in_window (Widget, d2sItem *);

/* Update the sensitivity of all or part of a character window */
void init_character_window_insensitive (Widget window);
void update_character_window_sensitive (d2sData *);
void update_character_form_sensitive (d2sData *, const char *form);

  /* Update the sensitivity of an item window */
void update_item_popup_sensitive (d2sItem *);
void update_item_editor_sensitive (d2sItem *);
void update_item_form_sensitive (d2sItem *, const char *form);

/* Function shared by windows that display item pictures: */
Pixmap (load_item_picture) (Screen *, d2sItem *);
Pixmap (load_item_mask) (Screen *screen, d2sItem *item);

/* Update an item in the character's inventory.
   The item's owner and location are stored in the item itself. */
void remove_item_from_inventory (d2sItem *);
void update_item_in_inventory (d2sItem *);

/* Update an item in its popup window. */
void update_item_popup (d2sItem *);

/* Update parts of the item editor window */
void update_item_window_title (Widget form, d2sItem *);
void update_basic_item_description (Widget form, d2sItem *);
void update_socketed_item (d2sDurableItem *);

void install_names_in_dropdown_list (Widget combo_box, StringList names);

#endif /* C++ */
