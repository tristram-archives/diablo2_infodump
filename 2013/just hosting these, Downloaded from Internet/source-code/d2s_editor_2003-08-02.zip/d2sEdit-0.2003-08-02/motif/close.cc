/* Close a document window or exit the application.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <errno.h>
#include <limits.h>
#include <unistd.h>
#include <Xm/Xm.h>
#include <Xm/FileSB.h>
#include <Xm/TextF.h>
#include "ui.h"
#include "util.h"
#include <dmalloc.h>

/* Declarations */
static void close_all_items (d2sItem *);

/* Go through the character's list of items, and see whether any of
   them have an item window open.  Close the ones that do. */
static void
close_all_items (d2sItem *item)
{
  for ( ; item != NULL; item = item->next)
    if (item->GetUI() != NULL) {
      /* Is this window an popup or item editor? */
      if (strcmp (XtName ((Widget) item->GetUI()), "form_item_popup") == 0)
	{
	  /* Disassociate the item from the window before destroying it. */
	  XtVaSetValues ((Widget) item->GetUI(), XmNuserData, NULL, NULL);
	  XtDestroyWidget (XtParent ((Widget) item->GetUI()));
	  item->SetUI (NULL);
	}
      else
	ui_item_window_close ((Widget) item->GetUI(), item->GetUI(), NULL);
    }
}

void
ui_file_close (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData *gamePtr;
  Widget window, docshell;
  int i;

  window = (Widget) client_data;
  docshell = XtParent (window);
  stdui = window;

  XtVaGetValues (window, XmNuserData, &gamePtr, NULL);
  if (gamePtr == NULL)
    {
      fprintf (stderr, "%s: Internal error: window %p's Close action\n"
	       " was active without an open document\n", progname, window);
      /* Behave as with a window close */
      ui_window_close (w, client_data, call_data);
      return;
    }

  if (gamePtr->needs_saving ())
    {
      int answer;

      if (gamePtr->SourceFileName () == NULL)
	/* This should probably be a 3-way question;
	   Save, Throw Away, or Cancel */
	answer = display_question
	  (1, 3, "Cancel", "Save As...", "Discard",
	   "Do you wish to save your character?");
      else
	/* This should probably be a 4-way question:
	   Save, Save As, Throw Away, or Cancel */
	answer = display_question
	  (1, 4, "Cancel", "Save", "Save As...", "Discard",
	   "%s has been modified.  Do you wish to save it?",
	   gamePtr->SourceFileName ());
      if (!answer)
	/* Cancelled */
	return;
      if ((gamePtr->SourceFileName () != NULL) && (answer == 1))
	{
	  ui_file_save (w, client_data, call_data);
	  /* We should find out whether "Save" succeeded
	     or was cancelled before proceeding to close the window. */
	  if (gamePtr->needs_saving ())
	    return;
	}
      if ((gamePtr->SourceFileName () != NULL)
	  ? (answer == 2) : (answer == 1))
	{
	  ui_file_save_as (w, client_data, call_data);
	  /* We should find out whether "Save As" succeeded
	     or was cancelled before proceeding to close the window. */
	  if (gamePtr->needs_saving ())
	    return;
	}
    }

  /* Close any windows associated with this character's items */
  close_all_items (gamePtr->GetFirstItem());
  close_all_items (gamePtr->GetFirstCorpseItem());
  close_all_items (gamePtr->GetFirstHirelingItem());

  /* Free the game object */
  XtVaSetValues (window, XmNuserData, NULL, NULL);
  gamePtr->SetUI (NULL);
  delete gamePtr;

  if (doc_shell_count > 1)
    {
      /* Find this shell in our document shell list, and remove it */
      for (i = 0; i < doc_shell_count; i++)
	{
	  if (docshell == doc_shell_list[i])
	    {
	      if (i + 1 < doc_shell_count)
		memmove (&doc_shell_list[i], &doc_shell_list[i + 1],
			 (doc_shell_count - (i + 1)) * sizeof (Widget));
	      doc_shell_count--;
	      break;
	    }
	}
    XtDestroyWidget (docshell);
    stdui = NULL;
  } else
    ui_clear_d2sdata (docshell);
}

void
ui_window_close (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData	*gamePtr;
  Widget	window, docshell;
  int		i;
  static int	recursive = 0;

  /* Prevent recursive calls (i.e., exiting while the user should be
     confirming file saves for a previous exit request). */
  if (recursive++)
    {
      recursive--;
      return;
    }

  window = (Widget) client_data;
  docshell = XtParent (window);
  stdui = window;

  /* If a file is open in this window, close it. */
  XtVaGetValues (window, XmNuserData, &gamePtr, NULL);
  if (gamePtr != NULL)
    {
      ui_file_close (w, client_data, call_data);
      recursive--;
      return;
    }
  /* If not, and we have no other documents open, exit the application. */
  else if ((doc_shell_count == 1) && (docshell == doc_shell_list[0]))
    {
      ui_file_exit (w, client_data, call_data);
      recursive--;
      return;
    }

  /* Find this shell in our document shell list, and remove it */
  for (i = 0; i < doc_shell_count; i++)
    {
      if (docshell == doc_shell_list[i])
	{
	  if (i + 1 < doc_shell_count)
	    memmove (&doc_shell_list[i], &doc_shell_list[i + 1],
		     doc_shell_count - (i + 1));
	  doc_shell_count--;
	  break;
	}
    }

  /* Destroy the window */
  XtDestroyWidget (docshell);
  stdui = NULL;
  recursive--;
}

void
ui_file_exit (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget window;
  int old_count;
  d2sData *first_game = NULL;

  /* If we have any files open, close them first.
     Staring with any item editor windows. */
#if 0
  /* The library isn't implemented yet */
  while (library_shell_count)
    {
      old_count = library_shell_count;
      ui_item_window_close (w, XxNameToWidget
			    (library_shell_list[library_shell_count - 1],
			     "form_library"), call_data);
      if (library_shell_count >= old_count)
	/* The user has probably cancelled the operation. */
	return;
    }
#endif /* TO-DO */
  while (item_doc_shell_count)
    {
      old_count = item_doc_shell_count;
      ui_item_window_close (w, XxNameToWidget
			    (item_doc_shell_list[item_doc_shell_count - 1],
			     "form_item"), call_data);
      if (item_doc_shell_count >= old_count)
	/* The user has probably cancelled the operation. */
	return;
    }
  if (doc_shell_count) {
    window = XxNameToWidget (doc_shell_list[0], "form_char");
    XtVaGetValues (window, XmNuserData, &first_game, NULL);
  }
  while (first_game != NULL)
    {
      old_count = doc_shell_count;
      ui_window_close (w, XxNameToWidget (doc_shell_list[doc_shell_count - 1],
					  "form_char"), call_data);
      if (doc_shell_count >= old_count)
	{
	  if (doc_shell_count > 1)
	    /* The user has probably cancelled the operation. */
	    return;
	  XtVaGetValues (window, XmNuserData, &first_game, NULL);
	  if (first_game != NULL)
	    return;
	}
    }

  XtAppSetExitFlag (app_context);
  /* No need to clear the recursion flag; we won't be coming back. */
}
