/* Miscellaneous utility functions for the user interface.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>
#include "ui.h"
#include <X11/CoreP.h>
#include <Xm/CascadeB.h>
#include <Xm/FileSB.h>
#include <Xm/ToggleB.h>
#include <dmalloc.h>

static void XxPrintAncestry (Widget);

/* Convenience function: if we can't find a widget,
   print an error message and abort. */
Widget
XxNameToWidget (Widget ancestor, const char *descendant)
{
  Widget child;
  char substr[40];
  int i;

  child = XtNameToWidget (ancestor, descendant);
  if (child != NULL)
    return child;

  fprintf (stderr, "%s: Can't find %s as a child widget of %s\n",
	   progname, descendant, XtName (ancestor));

  /* Try to help out the developer (me) */
  XxPrintAncestry (ancestor);
  putchar ('\n');
  substr[0] = '*';
  substr[39] = 0;
  descendant += strspn (descendant, ".*");
  i = strcspn (descendant, ".*");
  while (i) {
    memcpy (&substr[1], descendant, (i < 39) ? i : 38);
    substr[1 + ((i < 39) ? i : 38)] = '\0';
    child = XtNameToWidget (toplevel, substr);
    if (child == NULL)
      fprintf (stderr, "\"%s\" does not exist in the widget heirarchy.\n",
	       &substr[1]);
    else {
      XxPrintAncestry (child);
      putchar ('\n');
    }
    descendant += i + strspn (&descendant[i], ".*");
    i = strcspn (descendant, ".*");
  }
  if (debug)
    /* Break into the debugger */
    i = i / 0;
  exit (1);
}

/* Show a widget's parent, grandparent, etc. */
static void
XxPrintAncestry (Widget child)
{
  if ((child != toplevel) && (XtParent (child) != NULL))
    {
      XxPrintAncestry (XtParent (child));
      putchar ('.');
    }
  printf ("%s", XtName (child));
}

/* Show a widget's descendants */
void
XxPrintDescendants (Widget parent, int level)
{
  WidgetList	children = NULL;
  Cardinal	num_children = 0;
  Widget	sub_menu = NULL;
  int		i;

  for (i = 0; i < level; i++)
    putchar ('\t');
  printf ("%p: %s\n", parent, XtName (parent));

  if (XtIsComposite (parent))
    {
      XtVaGetValues (parent,
		     XtNchildren, &children,
		     XtNnumChildren, &num_children,
		     NULL);
      for (i = 0; i < num_children; i++)
	XxPrintDescendants (children[i], level + 1);
    }
  if (XmIsCascadeButton (parent))
    {
      XtVaGetValues (parent,
		     XmNsubMenuId, &sub_menu,
		     NULL);
      if (sub_menu != NULL)
	{
	  for (i = 0; i <= level; i++)
	    putchar ('\t');
	  printf ("Sub-menu: %s (%p)\n", XtName (sub_menu), sub_menu);
	}
    }
  if (parent->core.num_popups && (parent->core.popup_list != NULL))
    {
      for (i = 0; i <= level; i++)
	putchar ('\t');
      printf ("Popup List:\n");
      for (i = 0; i < parent->core.num_popups; i++)
	XxPrintDescendants (parent->core.popup_list[i], level + 1);
    }
}

/* Workaround for the problem of adding widgets to an already
   displayed window.  The standard XtManageChild function will
   not size forms properly. */
void
XxManageChild (Widget child)
{
  Widget parent;
  Dimension width, height;

  if (XtIsManaged (child))
    return;
  parent = XtParent (child);
  if ( ! XtIsRealized (child) && XtIsComposite (child)
       && parent && XtIsRealized (parent))
    {
      /* Explicitly realize a composite widget before managing it.
	 Also set its geometry to zero.
	 This prevents it from overriding the preferred geometry. */
      child->core.height = 0;
      child->core.width = 0;
      XtRealizeWidget (child);
      /* If the parent is also a composite, it could still squash
	 the child's preferred geometry.  So after managing the
	 child, we request a size change. */
      XtVaGetValues (child, XmNwidth, &width, XmNheight, &height, NULL);
      XtManageChild (child);
      XtVaSetValues (child, XmNwidth, width, XmNheight, height, NULL);
    }
  else
    XtManageChild (child);
}

/* Convenience function: get the index of an
   option menu's current selection. */
short
XmOptionMenuGetSelection (Widget opt_menu)
{
  Widget selected_child;
  short index;

  XtVaGetValues (opt_menu,
		 XmNmenuHistory, &selected_child,
		 NULL);
  XtVaGetValues (selected_child,
		 XmNpositionIndex, &index,
		 NULL);
  return index;
}

/* Convenience function: set an option menu's
   current selection by its index number. */
void
XmOptionMenuSetSelection (Widget opt_menu, short index)
{
  WidgetList children;
  Widget pulldown;
  Cardinal num_children;

  XtVaGetValues (opt_menu,
		 XmNsubMenuId, &pulldown,
		 NULL);
  XtVaGetValues (pulldown,
		 XmNchildren, &children,
		 XmNnumChildren, &num_children,
		 NULL);
  if ((unsigned) index >= (unsigned) num_children)
    index = 0;
  XtVaSetValues (opt_menu,
		 XmNmenuHistory, children[index],
		 NULL);
}

/* Convenience function: set a radio toggle button
   and clear whichever toggle was previously set,
   without calling any of either toggles' callbacks. */
void
XmRadioButtonSetOn (Widget button)
{
  Widget radio_box = XtParent (button);
  Widget current_selection;

  XtVaGetValues (radio_box, XmNmenuHistory, &current_selection, NULL);
  if (current_selection != button) {
    if (current_selection != NULL)
      XmToggleButtonSetState (current_selection, False, False);
    XtVaSetValues (radio_box, XmNmenuHistory, button, NULL);
  }
  if (!XmToggleButtonGetState (button))
    XmToggleButtonSetState (button, True, False);
}

/* Convenience function: when the "OK" button in a file selection is
   pressed, check whether a directory is selected, and if so update
   the dialog.  If a regular file is selected (or a non-existent
   filename is selected and file_required is False), return the full
   path to the file. */
char *
XxFileSelectionBoxGetFullPath (Widget svdialog, Boolean file_required,
			       XmFileSelectionBoxCallbackStruct *selection)
{
  char		*filename, *fullpath, *tstr;
  struct stat	stbuf;
  XmString	xmnewpath;

  stdui = svdialog;

  if (!XmStringGetLtoR (selection->value, XmFONTLIST_DEFAULT_TAG, &filename)) {
    /* Internal error? */
    fprintf (stderr, "%s %s:%d: XmStringGetLtoR() failed.\n",
	     progname, __FILE__, __LINE__);
    return NULL;
  }

  if (!filename[0]) {
    display_error ("No file selected");
    XtFree (filename);
    return NULL;
  }

  /* If a relative path was given, prepend the filter directory */
  if (filename[0] != '/') {
    if (!XmStringGetLtoR (selection->dir, XmFONTLIST_DEFAULT_TAG, &tstr)) {
      fprintf (stderr, "%s %s:%d: XmStringGetLtoR() failed.\n",
	       progname, __FILE__, __LINE__);
      XtFree (filename);
      return NULL;
    }
    fullpath = XtMalloc (strlen (tstr) + strlen (filename) + 1);
    sprintf (fullpath, "%s%s", tstr, filename);
    XtFree (tstr);
  } else {
    fullpath = XtMalloc (strlen (filename) + 1);
    strcpy (fullpath, filename);
  }

  if (file_required)
    {
      /* Make sure the file exists */
      if (access (fullpath, R_OK)) {
	display_error ("Cannot open %s; %s.",
		       filename, strerror (errno));
	XtFree (fullpath);
	XtFree (filename);
	return NULL;
      }
    }

  /* Check whether the file exists and is really a directory */
  if (stat (fullpath, &stbuf) >= 0) {
    if (S_ISDIR (stbuf.st_mode)) {
      if (!XmStringGetLtoR (selection->pattern,
			    XmFONTLIST_DEFAULT_TAG, &tstr)) {
	fprintf (stderr, "%s %s:%d: XmStringGetLtoR() failed.\n",
		 progname, __FILE__, __LINE__);
	XtFree (fullpath);
	XtFree (filename);
	return NULL;
      }
      /* Append the selection pattern to the full path
	 to get the new filter */
      fullpath = XtRealloc (fullpath,
			    strlen (fullpath) + 1 + strlen (tstr) + 1);
      if (fullpath[strlen (fullpath) - 1] != '/')
	strcat (fullpath, "/");
      strcat (fullpath, tstr);
      XtFree (tstr);

      /* Get a new list of files from the selected directory */
      xmnewpath = XmStringCreateLocalized (fullpath);
      XmFileSelectionDoSearch (svdialog, xmnewpath);
      XmStringFree (xmnewpath);
      XtFree (fullpath);
      XtFree (filename);
      return NULL;
    } /* directory */

    else if (!S_ISREG (stbuf.st_mode)) {
      display_error ("%s is not a regular file.", filename);
      XtFree (fullpath);
      XtFree (filename);
      return NULL;
    }
  }
  else if (errno != ENOENT) {
    display_error ("%s: %s.", fullpath);
    XtFree (fullpath);
    XtFree (filename);
    return NULL;
  }

  XtFree (filename);
  return fullpath;
}
