/* showuid.c --
 * Program to show the interface defined in a UID file.
 *
 * The example programs are written by Dan Heller and Paula Ferguson
 * for the Motif Programming Manual, Copyright (C) 1994 O'Reilly &
 * Associates, Inc.  Permission to use, copy, and modify these
 * programs without restriction is hereby granted, as long as this
 * copyright notice appears in each copy of the program source code.
 *
 * See The Definitive Guides to the X Window System, Volume Six A:
 * Motif Programming Manual for OSF/Motif Release 1.2,
 * Preface - Copyright (p. xxxix) and
 * Chapter 24 section 1 - Viewing UIL Examples (p. 800).
 */

#include <stdio.h>
#include <stdlib.h>
#include <Mrm/MrmAppl.h>
#include <dmalloc.h>

void quit();
void print();

static MrmRegisterArg callback_list[] = {
  { "quit", (XtPointer) quit },
};

typedef struct {
  String root_widget_name;
} app_data_t;

static app_data_t app_data;

static XtResource resources[] = {
  { "root", "Root", XmRString, sizeof (String),
    XtOffsetOf (app_data_t, root_widget_name),
    XmRString, (XtPointer) "root" },
};

static XrmOptionDescRec options[] = {
  { "-root", "root", XrmoptionSepArg, NULL },
};

void
quit (Widget w, XtPointer client_data, XtPointer call_data)
{
  exit (0);
}

main (int argc, char **argv)
{
  XtAppContext	app_context;
  Widget	toplevel;
  Widget	root_widget;
  Cardinal	status;
  MrmHierarchy	hierarchy;
  MrmType	class_code;

  XtSetLanguageProc (NULL, NULL, NULL);

  MrmInitialize ();

  toplevel = XtVaAppInitialize (&app_context, "ShowUID",
				options, XtNumber (options),
				&argc, argv, NULL, NULL);

  XtGetApplicationResources (toplevel, &app_data,
			     resources, XtNumber (resources), NULL, 0);

  /* Check number of args after Xt and App have removed their options. */
  if (argc < 2) {
    fprintf (stderr, "usage: %s [Xt options] [-root name] uidfiles ...\n",
	     argv[0]);
    exit (1);
  }

  /* Use argc and argv to obtain UID file names from the command line.
     (Most applications use an internal static array of names.) */
  status = MrmOpenHierarchyPerDisplay (XtDisplay (toplevel), argc - 1,
				       argv + 1, NULL, &hierarchy);

  if (status != MrmSUCCESS) {
    XtAppError (app_context, "MrmOpenHierarchyPerDisplay failed");
    exit (1);
  }

  status = MrmRegisterNames (callback_list, XtNumber (callback_list));

  if (status != MrmSUCCESS) {
    XtAppError (app_context, "MrmRegisterNames failed");
    exit (1);
  }

  status = MrmFetchWidget (hierarchy, app_data.root_widget_name,
			   toplevel, &root_widget, &class_code);

  if (status != MrmSUCCESS) {
    XtAppError (app_context, "MrmFetchWidget failed");
    exit (1);
  }

  MrmCloseHierarchy (hierarchy);

  XtManageChild (root_widget);
  XtRealizeWidget (toplevel);

  XtAppMainLoop (app_context);

  /* NOT REACHED */
}
