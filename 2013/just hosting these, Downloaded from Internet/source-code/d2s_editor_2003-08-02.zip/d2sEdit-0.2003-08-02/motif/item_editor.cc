/* UI function for managing the item editor window.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include "ui.h"
#include <Xm/ArrowB.h>
#include <Xm/AtomMgr.h>
#include <Xm/ComboBox.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/List.h>
#include <Xm/Protocols.h>
#include <Xm/PushB.h>
#include <Xm/Separator.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include "d2sMagic.h"
#include <dmalloc.h>

/* These variables should be global to all item editor functions, but
   not necessarily available anywhere else.  If we split this file,
   delete the word 'static' and make sure the names are globally unique. */

/* Maximum number of sockets supported by the UIL interface */
#define MAX_DISPLAYED_SOCKETS 8

/* List of all open item editor windows */
Widget *item_doc_shell_list = NULL;
int item_doc_shell_count = 0;

/* List of all open item library windows */
/* FIX ME: move this to a separate module; the library probably
   won't use any of the same code that's in the item editor. */
Widget *library_shell_list = NULL;
int library_shell_count = 0;

/* Mrm resources for the item editor.  *NOT* shared with the character
   editor (there may be widget name overlap, which would be bad.) */
MrmHierarchy item_mrm_hierarchy;
static String uid_file_list[] = {
  "editor", "edit-place",
  "edit-potion", "edit-gem", "edit-rune", "edit-picture",
  "edit-extended", "edit-sockets", "edit-quality", "edit-magic",
  "new_item"
};


/* Forward declarations of local functions: */
static void update_item_header (Widget form, d2sItem *);
static int add_selection_box (Widget form, const char *box_name,
			      void *cast_item);
static void configure_item_window (Widget form, d2sItem *);
static Widget configure_extended_item_box (Widget parent, d2sItem *);
static Widget configure_socketed_item_box (Widget parent, d2sItem *);
static void update_socketed_item_box (Widget socket_form, d2sDurableItem *);
static void update_max_number_of_sockets (d2sDurableItem *);
static Widget configure_item_quality_box (Widget parent, d2sItem *);
static void update_item_quality_box (Widget quality_form, d2sExtendedItem *);
static int compare_ints (const void *p1, const void *p2);
static void update_named_combo_box (Widget combo, int value,
				    const char *alt_text);
static void update_magic_xfix_line (Widget line_form, const char *widgets_name,
				    int xfix_id, const char *xfix_table);
static void update_set_name (Widget set_form, d2sQPartOfASet *);
static void update_rare_name (Widget combo_box, int name_id);
static void update_unique_name (Widget unique_form, int unique_id);
static Widget configure_magic_property_box (Widget parent, d2sItem *);
static void remove_all_children (Widget composite);
static void update_magic_property_box (Widget magic_form, d2sExtendedItem *);
static Widget insert_magic_property_row (Widget parent,
				       d2sMagicProperty *, int row);
static void ui_add_magic_property (Widget, XtPointer, XtPointer);
static void ui_move_magic_property (Widget, XtPointer, XtPointer);
static void ui_item_window_destroyed (Widget, XtPointer, XtPointer);


/* Initialize the item editor.  Called once at program startup.
   We don't open any windows at this time. */
int
ie_init (void)
{
  int		i;
  Cardinal	status;
  char		*full_path;

  /* Find the User Interface Definition files */
  for (i = 0; i < (int) XtNumber (uid_file_list); i++) {
    full_path = xfindfile (NULL, uid_file_list[i], ".uid", path_to_uid);
    if (full_path == NULL) {
      fprintf (stderr, "%s: Unable to locate %s UID file.\n",
	      progname, uid_file_list[i]);
      exit (1);
    }
    /* Replace the short name with the long one */
    uid_file_list[i] = full_path;
  }

  /* Open up the User Interface Definition files */
  status = MrmOpenHierarchyPerDisplay
    (XtDisplay (toplevel), XtNumber (uid_file_list),
     uid_file_list, NULL, &item_mrm_hierarchy);
  if (status != MrmSUCCESS) {
    fprintf (stderr, "%s: Unable to open UID files for the item editor.\n",
	     progname);
    exit (1);
  }
  /* That's all we do here! */
  return 0;
}

/* Open a new item editor window.  If an item is passed, the window
   will configure itself according to the item type before it's displayed.
   Otherwise, the window will default to no extra forms, suitable as a
   message box container for opening a file or creating a new item. */
Widget
open_item_editor_window (d2sItem *item)
{
  Widget	docshell, formitem, w;
  MrmType	class_code;
  Cardinal	status;

  if ((item == NULL) && item_doc_shell_count)
    {
      /* Do we already have a blank editor window open?
	 If so, use it instead of making another blank window. */
      for (status = 0; (int) status < item_doc_shell_count; status++)
	{
	  formitem = XxNameToWidget (item_doc_shell_list[status],
				     "form_item");
	  XtVaGetValues (formitem, XmNuserData, &w, NULL);
	  if (w == NULL)
	    return formitem;
	}
    }

  docshell = XtVaAppCreateShell
    /* I think the name needs to be the same throughout the application */
    ("d2sedit", "d2sEdit",
     topLevelShellWidgetClass, XtDisplay (toplevel),
     NULL);

  /* Get a copy of the item editor window (basic) layout */
  status = MrmFetchWidget (item_mrm_hierarchy, "form_item", docshell,
			   &formitem, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create interface form_item"
	       " from UID file\n", progname);
      XtDestroyWidget (docshell);
      return NULL;
    }

  /* Change the callback for the item window's close button
     so that instead of destroying the window outright
     it closes the window properly.  Also tell the shell
     to pay attention to geometry requests from its children. */
  XtVaSetValues (docshell,
		 XmNallowShellResize, True,
		 XmNdeleteResponse, XmDO_NOTHING,
		 NULL);
  XmAddWMProtocolCallback
    (docshell,
     XmInternAtom (XtDisplay (formitem), "WM_DELETE_WINDOW", False),
     ui_item_window_close, formitem);
  XtAddCallback (docshell, XmNdestroyCallback,
		 ui_item_window_destroyed, formitem);

  /* Add this document to our document shell list */
  item_doc_shell_list = (Widget *)
    XtRealloc ((char *) item_doc_shell_list,
	       (item_doc_shell_count + 1) * sizeof (Widget));
  item_doc_shell_list[item_doc_shell_count++] = docshell;
  stdui = formitem;

  if (item != NULL)
    {
      /* Set the user data of the top-level form to the game object,
	 and vice-versa */
      item->SetUI (formitem);
      update_item_window_title (formitem, item);
    }

  /* Clear the editor's resources to their default settings. */
  w = XxNameToWidget (formitem, "*menubar_item");
  /* Note: the Save menu item is handled automatically by the File menu */
  XtVaSetValues (XxNameToWidget (w, "*menuitem_save_as"),
		 /* This is enabled iff we have an item */
		 XmNsensitive, (item != NULL),
		 NULL);
  XtVaSetValues (XxNameToWidget (w, "*menuitem_copy"),
		 XmNsensitive, (item != NULL),
		 NULL);
  XtVaSetValues (XxNameToWidget (w, "*menuitem_duplicate"),
		 XmNsensitive, (item != NULL),
		 NULL);
  update_item_header (formitem, item);
  XmTextSetString (XxNameToWidget (formitem, "*game_data"), "");

  if (item != NULL)
    {
      configure_item_window (formitem, item);
      /* Set the editability of the widgets */
      update_item_editor_sensitive (item);
    }

  /* Now that the window has been created, display it. */
  XtManageChild (formitem);
  XtRealizeWidget (docshell);

  return formitem;
}

void
ui_edit_item_editor (Widget w, XtPointer client_data, XtPointer call_data)
{
  stdui = client_data;
  /* TO-DO: If an item is selected, open it. */
  /* If no item is selected, open a blank item editor window. */
  open_item_editor_window (NULL);
}

/* Place an item in a new editor window.
   The window has already been displayed,
   but it MUST NOT be configured for another item! */
void
place_item_in_window (Widget formitem, d2sItem *item)
{
  Widget	w;

  /* Set the user data of the top-level form to the game object,
     and vice-versa */
  item->SetUI (formitem);
  update_item_window_title (formitem, item);

  /* Initialize the editor resources to their default settings */
  w = XxNameToWidget (formitem, "*menubar_item");
  /* Note: the Save menu item is handled automatically by the File menu */
  XtVaSetValues (XxNameToWidget (w, "*menuitem_save_as"),
		 XmNsensitive, True,
		 NULL);
  XtVaSetValues (XxNameToWidget (w, "*menuitem_copy"),
		 XmNsensitive, True,
		 NULL);
  XtVaSetValues (XxNameToWidget (w, "*menuitem_duplicate"),
		 XmNsensitive, True,
		 NULL);
  update_item_header (formitem, item);

  /* Add item specifics */
  configure_item_window (formitem, item);

  /* Set the editability of the widgets */
  update_item_editor_sensitive (item);
}

static void
configure_item_window (Widget formitem, d2sItem *item)
{
  Widget	fistop, fis;
  Widget	extended_frame;
  Widget	socketed_frame = NULL;
  Widget	quality_frame = NULL;
  Widget	magic_frame = NULL;
  int		quality_on_bottom;

  /* If the item is a potion, gem, or rune, add a simple selection box */
  if (item->is_of_type ("poti")) {
    add_selection_box (formitem, "frame_change_potion",
		       (d2sPotionItem *) item);
    return;
  }
  else if (item->is_of_type ("gem")) {
    add_selection_box (formitem, "frame_change_gem",
		       (d2sGemItem *) ((d2sAttachItem *) *item));
    return;
  }
  else if (item->is_of_type ("rune")) {
    add_selection_box (formitem, "frame_change_rune",
		       (d2sRuneItem *) ((d2sAttachItem *) *item));
    return;
  }

  /* If this is an extended item, create the extended item box
	 and optional quality box, gem box, and magic properties box. */
  else if (item->Type() >= UNKNOWN_EXTENDED_ITEM) {
    fistop = XxNameToWidget (formitem, "*form_item_specifics_top");
    fis = XxNameToWidget (formitem, "*form_item_specifics");
    XtManageChild (fistop);

    extended_frame = configure_extended_item_box (fistop, item);
    if (extended_frame == NULL)
      /* Error!  Skip the item-specific section. */
      return;

    if (((item->Type() == ARMOR_ITEM) || (item->Type() == WEAPON_ITEM))
	&& (((d2sDurableItem *) *item)->MaximumNumberOfSockets() > 0))
      socketed_frame = configure_socketed_item_box (fistop, item);

    if (GetEntryIntegerField (item->TypeTableEntry(), "Normal") == 0)
      {
	/* The quality frame ought to go below the extended item
	   frame if there is a sockets frame or the extended
	   item frame is short (i.e., no subform) */
	quality_on_bottom = (socketed_frame != NULL);
	if ((item->Type() != ARMOR_ITEM) && (item->Type() != WEAPON_ITEM)
	    && (item->Type() != STACKED_WEAPON_ITEM))
	  quality_on_bottom = True;
	quality_frame = configure_item_quality_box
	  (quality_on_bottom ? fis : fistop, item);

	/* The magic properties frame goes on the bottom, and to the
	   right of the quality frame if the quality frame is also on
	   the bottom. */
	magic_frame = configure_magic_property_box (fis, item);
      }

    /* Arrange the boxes.  Because some of the boxes are optional,
       there are several different possible configurations. */
    XtVaSetValues (extended_frame, XmNtopAttachment, XmATTACH_FORM,
		   XmNbottomAttachment, XmATTACH_FORM,
		   XmNleftAttachment, XmATTACH_FORM,
		   XmNrightAttachment, (((socketed_frame == NULL)
					 && ((quality_frame == NULL)
					     || quality_on_bottom))
					? XmATTACH_FORM : XmATTACH_NONE),
		   NULL);

    if (((quality_frame != NULL) && quality_on_bottom)
	|| (magic_frame != NULL))
      XtVaSetValues (fistop,
		     XmNbottomAttachment, XmATTACH_NONE,
		     NULL);

    if (quality_frame != NULL)
      XtVaSetValues
	(quality_frame,
	 XmNtopAttachment, (quality_on_bottom
			    ? XmATTACH_WIDGET : XmATTACH_FORM),
	 XmNtopWidget, (quality_on_bottom ? fistop : NULL),
	 XmNbottomAttachment, XmATTACH_FORM,
	 XmNleftAttachment, (quality_on_bottom
			     ? XmATTACH_FORM : XmATTACH_WIDGET),
	 XmNleftWidget, (quality_on_bottom ? NULL : extended_frame),
	 XmNrightAttachment, ((quality_on_bottom && (magic_frame != NULL))
			      ? XmATTACH_NONE : XmATTACH_FORM),
	 NULL);

    if (socketed_frame != NULL)
      XtVaSetValues (socketed_frame, XmNtopAttachment, XmATTACH_FORM,
		     XmNbottomAttachment, XmATTACH_FORM,
		     XmNleftAttachment, XmATTACH_WIDGET,
		     XmNleftWidget, extended_frame,
		     XmNrightAttachment, XmATTACH_FORM,
		     NULL);

    if (magic_frame != NULL)
      XtVaSetValues
	(magic_frame, XmNtopAttachment, XmATTACH_WIDGET,
	 XmNtopWidget, fistop,
	 XmNbottomAttachment, XmATTACH_FORM,
	 XmNleftAttachment, ((quality_on_bottom && (quality_frame != NULL))
			     ? XmATTACH_WIDGET : XmATTACH_FORM),
	 XmNleftWidget, ((quality_on_bottom && (quality_frame != NULL))
			 ? quality_frame : NULL),
	 XmNrightAttachment, XmATTACH_FORM,
	 NULL);

    XxManageChild (extended_frame);
    if (socketed_frame != NULL)
      XxManageChild (socketed_frame);
    if (quality_frame != NULL)
      XxManageChild (quality_frame);
    if (magic_frame != NULL)
      XxManageChild (magic_frame);

    /* Lastly, update / register drop sites */
    register_item_drop_sites (formitem);
  }
}

/* Update the window title when an item is loaded. */
void
update_item_window_title (Widget formitem, d2sItem *item)
{
  char *	window_title;
  XmString	xmwindow_title;

  if (item->Owner() != NULL)
    {
      window_title = XtMalloc
	(sizeof ("Edit Item - %s's %s") + strlen (item->Name())
	 + strlen (item->Owner()->GetCharacterName()));
      sprintf (window_title, "Edit Item - %s's %s",
	       item->Owner()->GetCharacterName(), item->Name());
    }
  else if (item->SourceFileName() != NULL)
    {
      window_title = XtMalloc
	(sizeof ("Edit Item - %s") + strlen (item->SourceFileName()) + 1);
      sprintf (window_title, "Edit Item - %s", item->SourceFileName());
    }
  else
    {
      window_title = XtMalloc (sizeof ("Edit Item - %s")
			       + strlen (item->Name()) + 1);
      sprintf (window_title, "Edit Item - %s", item->Name());
    }
  xmwindow_title = XmStringCreateLocalized (window_title);
  XtVaSetValues (formitem,
		 XmNdialogTitle, xmwindow_title,
		 XmNuserData, item,
		 NULL);
  XmStringFree (xmwindow_title);
  XtFree (window_title);

  /* Set the editability of the Edit menu items */
  if (item->GetUI() != NULL)
    update_item_form_sensitive (item, "*menubar_item");
}

/* Update the fields in the item description section of the item
   editor window.  If item is NULL, the fields are cleared. */
static void
update_item_header (Widget formitem, d2sItem *item)
{
  Widget	w, t;
  Pixmap	item_picture, old_picture;
  char		strbuf[16];
  const char *	type_str;
  table_entry_t subtype_entry;
  int		version;

  w = XxNameToWidget (formitem, "*form_item_description");
  /* Get the currently loaded item picture.  See below. */
  XtVaGetValues (XxNameToWidget (w, "*picture_item"),
		 XmNlabelPixmap, &old_picture,
		 NULL);
  item_picture = XmUNSPECIFIED_PIXMAP;
  if (item == NULL)
    {
      /* When an item has no picture, we display the text
	 "no image available".  But when no item is loaded,
	 the picture frame is blank. */
      XtVaSetValues (XxNameToWidget (w, "*picture_item"),
		     XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		     XmNlabelType, XmPIXMAP,
		     XmNuserData, NULL,
		     NULL);
      XmTextFieldSetString (XxNameToWidget (w, "*field_item_base_name"), "");
      XmTextFieldSetString (XxNameToWidget (w, "*field_item_type"), "");
      XmTextFieldSetString (XxNameToWidget (w, "*field_item_req_level"), "");
      XtSetSensitive (XxNameToWidget (w, "*label_item_req_level"), False);
      XmToggleButtonSetState (XxNameToWidget (w, "*toggle_quest_item"),
			      False, False);
      XtSetSensitive (XxNameToWidget (w, "*label_quest_item"), False);
      XmToggleButtonSetState (XxNameToWidget (w, "*toggle_expansion_item"),
			      False, False);
      XtSetSensitive (XxNameToWidget (w, "*label_expansion_item"), False);
      XtUnmanageChild (XxNameToWidget (formitem, "*item_description_sw"));
      XtManageChild (XxNameToWidget (formitem, "*item_description_empty"));
    }

  else
    {
      item_picture = load_item_picture (XtScreen (w), item);
      t = XxNameToWidget (w, "*picture_item");
      if (item_picture != old_picture)
	XtVaSetValues (t, XmNlabelPixmap, item_picture, NULL);
      /* If the picture was not found, show text instead */
      XtVaSetValues (t,
		     XmNlabelType, ((item_picture == XmUNSPECIFIED_PIXMAP)
				    ? XmSTRING : XmPIXMAP),
		     /* This is used for drag operations */
		     XmNuserData, item,
		     NULL);
      t = XxNameToWidget (w, "*field_item_base_name");
      XmTextFieldSetString (t, (char *) item->Name());
      XmTextFieldInsert (t, XmTextFieldGetLastPosition (t), " (");
      XmTextFieldInsert (t, XmTextFieldGetLastPosition (t),
			 (char *) item->Code());
      XmTextFieldInsert (t, XmTextFieldGetLastPosition (t), ")");
      if (item->Type() >= ARMOR_ITEM) {
	if (strcmp (item->Code(), GetEntryStringField
		    (item->ItemTableEntry(), "ubercode")) == 0)
	  XmTextFieldInsert (t, XmTextFieldGetLastPosition (t),
			     " {Exceptional}");
	else if (strcmp (item->Code(), GetEntryStringField
			 (item->ItemTableEntry(), "ultracode")) == 0)
	  XmTextFieldInsert (t, XmTextFieldGetLastPosition (t),
			     " [Elite]");
      }
      /* We have to pull the item type from the type table */
      type_str = GetEntryStringField (item->TypeTableEntry(), "ItemType");
      t = XxNameToWidget (w, "*field_item_type");
      XmTextFieldSetString (t, (char *) type_str);
      /* Some item types are too specific (i.e., gems).
	 So they should be taken up to the next higher type class.
	 But how do we tell whether to do this? */
      type_str = GetEntryStringField (item->TypeTableEntry(), "Equiv1");
      while (type_str[0]) {
	subtype_entry = LookupTableEntry ("itemtypes", "Code", type_str);
	XmTextFieldInsert (t, XmTextFieldGetLastPosition (t), ", ");
	XmTextFieldInsert (t, XmTextFieldGetLastPosition (t),
			   (char *) GetEntryStringField (subtype_entry,
							 "ItemType"));
	type_str = GetEntryStringField (subtype_entry, "Equiv1");
      }
      if (item->BaseRequiredLevel() > 1)
	sprintf (strbuf, "%d", item->BaseRequiredLevel());
      else
	strbuf[0] = '\0';
      XmTextFieldSetString (XxNameToWidget (w, "*field_item_req_level"),
			    strbuf);
      XtSetSensitive (XxNameToWidget (w, "*label_item_req_level"),
		      (item->BaseRequiredLevel() > 1));
      XmToggleButtonSetState (XxNameToWidget (w, "*toggle_quest_item"),
			      item->is_quest_item() ? XmSET : XmUNSET, False);
      XtSetSensitive (XxNameToWidget (w, "*label_quest_item"),
		      item->is_quest_item());
      /* The function d2sItem::is_expansion_item() returns
	 the current state of the item, including modifiers.
	 We want the base state instead for this toggle. */
      version = GetEntryIntegerField (item->TypeTableEntry(), "version");
      XmToggleButtonSetState (XxNameToWidget (w, "*toggle_expansion_item"),
			      (version >= 100) ? XmSET : XmUNSET,
			      False);
      XtSetSensitive (XxNameToWidget (w, "*label_expansion_item"),
		      (version >= 100));

      /* If this can be an enhanced item,
	 show the item's full description. */
      w = XxNameToWidget (formitem, "*item_description_sw");
      if (GetEntryIntegerField (item->TypeTableEntry(), "Normal")
	  && ! item->is_of_type ("gem") && ! item->is_of_type ("rune")) {
	if (XtIsManaged (w)) {
	  XtUnmanageChild (w);
	  XtManageChild (XxNameToWidget (formitem,
					 "*item_description_empty"));
	}
      } else {
	/* Show the full description instead of the blank spacer */
	if ( ! XtIsManaged (w)) {
	  Widget	clip_window;
	  Pixel		bg_color;

	  XtUnmanageChild (XxNameToWidget (formitem,
					   "*item_description_empty"));
	  XtManageChild (w);

	  /* Set the background of the clipping window
	     to match that of the item description. */
	  XtVaGetValues (XxNameToWidget (formitem, "*item_full_description"),
			 XmNbackground, &bg_color,
			 NULL);
	  XtVaGetValues (w, XmNclipWindow, &clip_window, NULL);
	  XtVaSetValues (clip_window, XmNbackground, bg_color, NULL);
	}

	/* Post the item's full description */
	update_basic_item_description (formitem, item);
      }
    }

  /* Release the old picture.
     Try to keep memory leaks to a minimum. */
  if (old_picture != XmUNSPECIFIED_PIXMAP)
    XmDestroyPixmap (XtScreen (formitem), old_picture);
}

/* Update just the item description box (called when an item's
   properties have changed, but not the item type or picture) */
void
update_basic_item_description (Widget formitem, d2sItem *item)
{
  Widget	description_widget;
  char *	description_text;
  XmString	xmstr;

  description_text = item->FullDescription();
  xmstr = XmStringCreateLocalized (description_text);
  description_widget = XxNameToWidget (formitem, "*item_full_description");
  XtVaSetValues (description_widget, XmNlabelString, xmstr, NULL);
}

/* Add a selection box for transforming an item to another item of the
   same type.  The box is inserted in the form in the area reserved
   for item specific forms.  The document shell's resources are not
   modified, which is fine if the window hasn't been displayed yet; but
   if it has already been displayed, the shell will need to be resized. */
static int
add_selection_box (Widget form, const char *box_name, void *cast_item)
{
  Widget	selection_box;
  Cardinal	status;
  MrmType	class_code;

  status = MrmFetchWidget (item_mrm_hierarchy, (char *) box_name,
			   XxNameToWidget (form, "*form_item_specifics"),
			   &selection_box, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create selection box for item editor"
	       " from UID file\n", progname);
      /* This is not a fatal error.  Just prevents functionality. */
      return -1;
    }

  /* Set the frame's userData resource to the item type-specific pointer */
  XtVaSetValues (selection_box, XmNuserData, cast_item, NULL);
  /* Make sure the frame is displayed! */
  XxManageChild (selection_box);
  return 0;
}

/* This is only for use by the following function */
static void configure_durable_part_of_extended_item_box
	    (Widget, d2sDurableItem *);

/* Configure the form for extended items.  The form is set according
   to the item type.  The form will be added as a child of the
   item-specifics form, but not yet managed; the caller is expected to
   arrange the placement of this form before managing it. */
static Widget
configure_extended_item_box (Widget parent, d2sItem *item)
{
  Widget	ext_form, last_added, w;
  Cardinal	status;
  MrmType	class_code;
  d2sExtendedItem *eitem;
  d2sDurableItem *ditem;
  d2sStackItem *sitem = NULL;
  char		strbuf[24];
  XmString	xmstr;

  /* Fetch the extended item form
     (this includes all subforms, which are unmanaged) */
  status = MrmFetchWidget (item_mrm_hierarchy, "frame_extended_item",
			   parent, &ext_form, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create extended item form"
	       " for item editor from UID file\n", progname);
      /* This is not a fatal error.  Just prevents functionality. */
      return NULL;
    }

  /* As all extended items have a fingerprint, set that field now. */
  if (item != NULL)
    {
      eitem = (d2sExtendedItem *) *item;
      /* Save a pointer to the d2sExtendedItem object */
      XtVaSetValues (ext_form, XmNuserData, eitem, NULL);
      sprintf (strbuf, "%#.8lx", eitem->UniqueID());
      XmTextFieldSetString (XxNameToWidget (ext_form, "*field_fingerprint"),
			    strbuf);
      sprintf (strbuf, "%d", eitem->Level());
      XmTextFieldSetString (XxNameToWidget (ext_form, "*field_item_level"),
			    strbuf);
    }
  else
    {
      XtVaSetValues (ext_form, XmNuserData, NULL, NULL);
      XmTextFieldSetString (XxNameToWidget (ext_form, "*field_fingerprint"),
			    (char *) "");
      XmTextFieldSetString (XxNameToWidget (ext_form, "*field_item_level"),
			    (char *) "");
    }

  /* Go to the item type-specific configuration */
  switch ((item == NULL) ? 0 : (int) item->Type())
    {
    default:
      xmstr = XmStringCreateLocalized ("Extended Item");
      XtVaSetValues (XxNameToWidget (ext_form, "flabel_extended_item"),
		     XmNlabelString, xmstr,
		     NULL);
      XmStringFree (xmstr);

      /* Plain extended items (e.g., the Cube), rings et al, and
	 unknowns do not show any fields other than the fingerprint. */
      w = XxNameToWidget (ext_form, "*field_fingerprint");
      XtVaSetValues (w, XmNtopAttachment, XmATTACH_FORM,
		     XmNleftPosition, 8,
		     NULL);
      break;

    case STACK_ITEM:
      sitem = (d2sStackItem *) *item;

      xmstr = XmStringCreateLocalized ("Stack");
      XtVaSetValues (XxNameToWidget (ext_form, "flabel_extended_item"),
		     XmNlabelString, xmstr,
		     NULL);
      XmStringFree (xmstr);

      /* Manage the quantity form */
      last_added = XxNameToWidget (ext_form, "*form_stacked_item");
      XtVaSetValues (last_added,
		     XmNtopAttachment, XmATTACH_FORM,
		     /* The stack pointer goes here */
		     XmNuserData, sitem,
		     NULL);
      /* Fill in the quantity */
      sprintf (strbuf, "%d", sitem->Quantity());
      w = XxNameToWidget (last_added, "*field_item_quantity");
      XtVaSetValues (w, XmNleftPosition, 8);
      XmTextFieldSetString (w, strbuf);
      /* Fill in the maximum quantity */
      sprintf (strbuf, "%d", sitem->MaxQuantity());
      w = XxNameToWidget (last_added, "*field_item_max_quantity");
      XmTextFieldSetString (w, strbuf);
      XtManageChild (last_added);

      /* The fingerprint goes right underneath */
      XtVaSetValues (XxNameToWidget (ext_form, "*field_fingerprint"),
		     XmNtopAttachment, XmATTACH_WIDGET,
		     XmNtopWidget, last_added,
		     XmNleftPosition, 8,
		     NULL);
      break;

    case ARMOR_ITEM:
      ditem = (d2sDurableItem *) *item;

      xmstr = XmStringCreateLocalized ("Armor");
      XtVaSetValues (XxNameToWidget (ext_form, "flabel_extended_item"),
		     XmNlabelString, xmstr,
		     NULL);
      XmStringFree (xmstr);

      /* Start with the durable item form */
      last_added = XxNameToWidget (ext_form, "*form_durable_item");
      configure_durable_part_of_extended_item_box (last_added, ditem);

      /* Add the armor's defense section */
      last_added = XxNameToWidget (ext_form, "*form_armor_defense");
      /* The armor pointer goes here */
      XtVaSetValues (last_added, XmNuserData, (d2sArmorItem *) ditem, NULL);
      snprintf (strbuf, sizeof (strbuf), "%3d to %-3d",
		/* The standard defense is defined as a range. */
		GetEntryIntegerField (item->ItemTableEntry(), "minac"),
		GetEntryIntegerField (item->ItemTableEntry(), "maxac"));
      w = XxNameToWidget (last_added, "*field_defense_range");
      XmTextFieldSetString (w, strbuf);
      /* Fill in the defense */
      sprintf (strbuf, "%d", ((d2sArmorItem *) ditem)->BaseDefense());
      w = XxNameToWidget (last_added, "*field_armor_defense");
      XmTextFieldSetString (w, strbuf);
      XtManageChild (last_added);

      /* If this is a shield, add the shield section */
      if (item->is_of_type ("shld")) {
	last_added = XxNameToWidget (ext_form, "*form_armor_shield");
	sprintf (strbuf, "%d%%",
		 ((d2sArmorItem *) ditem)->BaseChanceToBlock());
	w = XxNameToWidget (last_added, "*field_chance_to_block");
	XmTextFieldSetString (w, strbuf);
	/* There are some class-specific shields (i.e., voodoo heads)
	   that can't be used by Paladins, so it makes no sense
	   to show smite damage for them. */
	if (ditem->is_class_restricted()
	    && (ditem->ClassRestriction() != PALADIN_CLASS)) {
	  XtVaSetValues (w, XmNbottomAttachment, XmATTACH_FORM, NULL);
	  XtUnmanageChild (XxNameToWidget (last_added, "*label_smite_damage"));
	  XtUnmanageChild (XxNameToWidget (last_added, "*field_smite_damage"));
	  XtUnmanageChild (XxNameToWidget
			   (last_added, "*label_smite_paladin_only"));
	} else {
	  snprintf (strbuf, sizeof (strbuf), "%3d to %-3d",
		    /* Smite damage is stored in the item tables */
		    GetEntryIntegerField (item->ItemTableEntry(), "mindam"),
		    GetEntryIntegerField (item->ItemTableEntry(), "maxdam"));
	  w = XxNameToWidget (last_added, "*field_smite_damage");
	  XmTextFieldSetString (w, strbuf);
	}
	XtManageChild (last_added);
      }

      /* If this is a belt, add the belt section */
      if (item->is_of_type ("belt")) {
	last_added = XxNameToWidget (ext_form, "*form_armor_belt");
	sprintf (strbuf, "%d",
		 ((d2sArmorItem *) ditem)->NumberOfBoxesInBelt());
	w = XxNameToWidget (last_added, "*field_belt_boxes");
	XmTextFieldSetString (w, strbuf);
	XtManageChild (last_added);
      }

      /* The fingerprint goes last */
      XtVaSetValues (XxNameToWidget (ext_form, "*field_fingerprint"),
		     XmNtopAttachment, XmATTACH_WIDGET,
		     XmNtopWidget, last_added,
		     XmNleftPosition, 6,
		     NULL);
      break;

    case STACKED_WEAPON_ITEM:
      sitem = (d2sStackItem *) *item;
      /* Change the label "Two-hand Damge:" to "Throw Damage:" */
      xmstr = XmStringCreateLocalized ("Throw Damage:");
      w = XxNameToWidget (ext_form, "*label_2hw_damage");
      XtVaSetValues (w, XmNlabelString, xmstr, NULL);
      XmStringFree (xmstr);
      /* FALLTHROUGH */

    case WEAPON_ITEM:
      /* For normal weapons, SITEM was set to NULL
	 in the declaration section. */
      ditem = (d2sDurableItem *) *item;

      xmstr = XmStringCreateLocalized ("Weapon");
      XtVaSetValues (XxNameToWidget (ext_form, "flabel_extended_item"),
		     XmNlabelString, xmstr,
		     NULL);
      XmStringFree (xmstr);

      /* Start with the durable item form */
      last_added = XxNameToWidget (ext_form, "*form_durable_item");
      configure_durable_part_of_extended_item_box (last_added, ditem);

      /* If this is a stacked weapon, the quantity comes next. */
      if (sitem != NULL) {
	w = XxNameToWidget (ext_form, "*form_stacked_item");
	XtVaSetValues (w, XmNtopAttachment, XmATTACH_WIDGET,
		       XmNtopWidget, last_added,
		       /* The stack pointer goes here */
		       XmNuserData, sitem,
		       NULL);
	last_added = w;
	/* Fill in the quantity */
	sprintf (strbuf, "%d", sitem->Quantity());
	w = XxNameToWidget (last_added, "*field_item_quantity");
	XtVaSetValues (w, XmNleftPosition, 8);
	XmTextFieldSetString (w, strbuf);
	/* Fill in the maximum quantity */
	sprintf (strbuf, "%d", sitem->MaxQuantity());
	w = XxNameToWidget (last_added, "*field_item_max_quantity");
	XmTextFieldSetString (w, strbuf);
	XtManageChild (last_added);
      }

      /* One-hand damage, optional */
      if (((d2sWeaponItem *) ditem)->is_one_handed()) {
	w = XxNameToWidget (ext_form, "*form_weapon_1hd");
	XtVaSetValues (w, XmNtopAttachment, XmATTACH_WIDGET,
		       XmNtopWidget, last_added,
		       NULL);
	last_added = w;
	snprintf (strbuf, sizeof (strbuf), "%3d to %-3d",
		  ((d2sWeaponItem *) ditem)->GetDamage
		  (ONE_HAND_DAMAGE, BASE_DAMAGE, MINIMUM_DAMAGE),
		  ((d2sWeaponItem *) ditem)->GetDamage
		  (ONE_HAND_DAMAGE, BASE_DAMAGE, MAXIMUM_DAMAGE));
	w = XxNameToWidget (last_added, "*field_1hw_damage");
	XmTextFieldSetString (w, strbuf);
	XtManageChild (last_added);
      }

      /* Two-hand (or throw) damage, optional */
      if (((d2sWeaponItem *) ditem)->is_two_handed()
	  || ((d2sWeaponItem *) ditem)->is_throwable()) {
	w = XxNameToWidget (ext_form, "*form_weapon_2hd");
	XtVaSetValues (w, XmNtopAttachment, XmATTACH_WIDGET,
		       XmNtopWidget, last_added,
		       /* If this section follows one-hand damage,
			  bump the fields up a couple of notches. */
		       XmNtopOffset, ((d2sWeaponItem *)
				      ditem)->is_one_handed() ? -2 : 0,
		       NULL);
	last_added = w;
	snprintf (strbuf, sizeof (strbuf), "%3d to %-3d",
		  ((d2sWeaponItem *) ditem)->GetDamage
		  (TWO_HAND_DAMAGE, BASE_DAMAGE, MINIMUM_DAMAGE),
		  ((d2sWeaponItem *) ditem)->GetDamage
		  (TWO_HAND_DAMAGE, BASE_DAMAGE, MAXIMUM_DAMAGE));
	w = XxNameToWidget (last_added, "*field_2hw_damage");
	XmTextFieldSetString (w, strbuf);
	XtManageChild (last_added);
      }

      /* The weapon speed comes next */ {
	int speed;

	w = XxNameToWidget (ext_form, "*form_weapon_speed");
	XtVaSetValues (w, XmNtopAttachment, XmATTACH_WIDGET,
		       XmNtopWidget, last_added,
		       /* The weapon pointer goes here */
		       XmNuserData, (d2sWeaponItem *) ditem,
		       NULL);
	last_added = w;
	/* Get the weapon speed from the weapon table.
	   There is no interface to get this from a d2sWeaponItem object,
	   because the value is not clearly defined. */
	speed = GetEntryIntegerField (item->ItemTableEntry(), "speed");
	sprintf (strbuf, speed ? "%+2d" : "%3d", speed);
	w = XxNameToWidget (last_added, "*field_weapon_speed_number");
	XmTextFieldSetString (w, strbuf);
	w = XxNameToWidget (last_added, "*field_weapon_speed_text");
	/* This is assumed.  May be right; may be wrong. */
	if (speed < -5) {
	  if (speed >= -15)
	    XmTextFieldSetString (w, (char *) "(Fast)");
	  else {
	    if (speed >= -25)
	      XmTextFieldSetString (w, (char *) "(Very Fast)");
	    else
	      XmTextFieldSetString (w, (char *) "(Fastest)");
	  }
	}
	else if (speed >= 5) {
	  if (speed >= 25)
	    XmTextFieldSetString (w, (char *) "(Slowest)");
	  else if (speed >= 15)
	    XmTextFieldSetString (w, (char *) "(Very Slow)");
	  else
	    XmTextFieldSetString (w, (char *) "(Slow)");
	}
	else
	  XmTextFieldSetString (w, (char *) "(Normal)");
	XtManageChild (last_added);
      }

      /* Blunt weapons get to add the following label */
      if (item->is_of_type ("blun")) {
	last_added = XxNameToWidget (ext_form, "*label_weapon_dtund");
	XtManageChild (last_added);
      }

      /* The fingerprint goes last */
      XtVaSetValues (XxNameToWidget (ext_form, "*field_fingerprint"),
		     XmNtopAttachment, XmATTACH_WIDGET,
		     XmNtopWidget, last_added,
		     XmNleftPosition, 6,
		     NULL);
      break;
    }
  /* NOTREACHED */
  return ext_form;
}

/* Common part of the above function for durable items (armor and weapons) */
static void
configure_durable_part_of_extended_item_box (Widget durable_form,
					     d2sDurableItem *ditem)
{
  Widget	w;
  char		strbuf[24];

  /* Set the userData resource to the durable item pointer */
  XtVaSetValues (durable_form, XmNuserData, ditem, NULL);

  /* Set the boolean fields */
  w = XxNameToWidget (durable_form, "*toggle_newbie_item");
  XmToggleButtonSetState (w, ditem->is_newbie() ? XmSET : XmUNSET, False);
  w = XxNameToWidget (durable_form, "*toggle_ethereal_item");
  XmToggleButtonSetState (w, ditem->is_ethereal() ? XmSET : XmUNSET,
			  False);

  /* Fill in the required dexterity and strength */
  if (ditem->RequiredDexterity())
    sprintf (strbuf, "%2d", ditem->RequiredDexterity());
  else
    strbuf[0] = '\0';
  w = XxNameToWidget (durable_form, "*field_item_req_dexterity");
  XmTextFieldSetString (w, strbuf);
  XtSetSensitive (XxNameToWidget (durable_form, "*label_item_req_dexterity"),
		  ditem->RequiredDexterity() > 0);
  if (ditem->RequiredStrength())
    sprintf (strbuf, "%2d", ditem->RequiredStrength());
  else
    strbuf[0] = '\0';
  w = XxNameToWidget (durable_form, "*field_item_req_strength");
  XmTextFieldSetString (w, strbuf);
  XtSetSensitive (XxNameToWidget (durable_form, "*label_item_req_strength"),
		  ditem->RequiredStrength() > 0);

  if (ditem->is_class_restricted()) {
    /* We need to insert the class restriction between the
       required strength and the durability lines. */
    snprintf (strbuf, sizeof (strbuf), "(%s Only)",
	      GetCharacterClassName (ditem->ClassRestriction()));
    w = XxNameToWidget (durable_form, "*field_item_class_restriction");
    XmTextFieldSetString (w, strbuf);
    XtVaSetValues (XxNameToWidget (durable_form,
				   "*field_current_durability"),
		   XmNtopWidget, w,
		   NULL);
    XtManageChild (w);
    XtManageChild (XxNameToWidget (durable_form,
				   "*label_item_class_restriction"));
  }

  /* Fill in the current durability */
  sprintf (strbuf, "%d", ditem->Durability());
  w = XxNameToWidget (durable_form, "*field_current_durability");
  XmTextFieldSetString (w, strbuf);
  /* Fill in the base durability stored in the item */
  sprintf (strbuf, "%d", ditem->BaseDurability());
  w = XxNameToWidget (durable_form, "*field_base_durability");
  XmTextFieldSetString (w, strbuf);
  sprintf (strbuf, "%2d",
	   /* The standard durability is not stored in the item. */
	   GetEntryIntegerField (ditem->ItemTableEntry(), "durability"));
  w = XxNameToWidget (durable_form, "*field_standard_durability");
  XmTextFieldSetString (w, strbuf);
  XtManageChild (durable_form);
}

/* Configure the form for socketed items.  As many sockets are shown
   as the *maximum* number of sockets allowed by the item type.
   The form will be added as a child of the item-specifics form, but
   not yet managed; the caller is expected to arrange the placement of
   this form before managing it. */
static Widget
configure_socketed_item_box (Widget parent, d2sItem *item)
{
  Widget	socket_frame, socket_row;
  Cardinal	status;
  MrmType	class_code;
  d2sDurableItem *ditem;
  char		make_name[32];
  int		i, socket_num, max;

  /* Verify that we have a socketable item.
     If not, we won't create a sockets box at all. */
  if ((item == NULL)
      /* Stacked weapons can't have sockets */
      || ((item->Type() != ARMOR_ITEM) && (item->Type() != WEAPON_ITEM)))
    return NULL;
  ditem = (d2sDurableItem *) *item;
  max = ditem->MaximumNumberOfSockets();
  if (max <= 0)
    return NULL;
  i = ditem->ModNumberOfSockets();
  if (i > max)
    max = i;

  /* Fetch the socketed item form
     (this includes subforms for each socket) */
  status = MrmFetchWidget (item_mrm_hierarchy, "frame_socketed_item",
			   parent, &socket_frame, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create socketed item form"
	       " for item editor from UID file\n", progname);
      /* This is not a fatal error.  Just prevents functionality. */
      return NULL;
    }

  /* Assign the durable item's pointer to the socket frame. */
  XtVaSetValues (socket_frame, XmNuserData, ditem, NULL);

  /* For each socket in the list, manage the row if the item *can*
     have a socket there, unmanage it if it can't. */
  strcpy (make_name, "*form_socket1");
  for (socket_num = 0; socket_num < MAX_DISPLAYED_SOCKETS; socket_num++)
    {
      sprintf (&make_name[12], "%d", socket_num + 1);
      socket_row = XxNameToWidget (socket_frame, make_name);
      if (socket_num < max)
	XtManageChild (socket_row);
      else
	XtUnmanageChild (socket_row);
    }

  /* Set the bottom of the form against the last managed row */
  i = max;
  if (i > MAX_DISPLAYED_SOCKETS)
    i = MAX_DISPLAYED_SOCKETS;
  sprintf (&make_name[12], "%d", i);
  XtVaSetValues (XxNameToWidget (socket_frame, "*spacer_socket_list"),
		 XmNtopWidget, XxNameToWidget (socket_frame, make_name),
		 NULL);

  /* Fill in the sockets */
  update_socketed_item_box (socket_frame, ditem);
  return socket_frame;
}

/* Update the sockets in the socketed item frame.
   This takes care of whether sockets were added or removed,
   as well as changing gem pictures and names and showing
   or hiding the gem movement buttons. */
static void
update_socketed_item_box (Widget socket_form, d2sDurableItem *ditem)
{
  Widget	socket_row, w, t;
  d2sItem	*item;
  d2sAttachItem *gem;
  char		make_name[32];
  int		socket_num, num_rows, max;
  Pixmap	gem_picture, old_picture;

  max = ditem->MaximumNumberOfSockets();
  num_rows = ditem->ModNumberOfSockets();
  if (num_rows > max)
    max = num_rows;
  else
    num_rows = max;
  if (num_rows > MAX_DISPLAYED_SOCKETS)
    num_rows = MAX_DISPLAYED_SOCKETS;
  for (socket_num = 0; socket_num < num_rows; socket_num++)
    {
      sprintf (make_name, "*form_socket%d", socket_num + 1);
      socket_row = XxNameToWidget (socket_form, make_name);
      /* Is there a gem on this row? */
      if (socket_num < ditem->NumberOfGems()) {
	/* What gem was last on this row? */
	sprintf (make_name, "*button_socket%d", socket_num + 1);
	w = XxNameToWidget (socket_row, make_name);
	XtVaGetValues (w, XmNuserData, &item, NULL);
	gem = (item == NULL) ? NULL : (d2sAttachItem *) *item;

	/* If the gem has been changed, update the row.
	   If it hasn't, no update is required. */
	if ((gem != ditem->Gem(socket_num)) || gem->needs_saving()) {
	  gem = ditem->Gem(socket_num);
	  XtVaSetValues (w, XmNuserData, (d2sItem *) gem, NULL);
	  /* Update the gem icon first */
	  XtVaGetValues (w, XmNlabelPixmap, &old_picture, NULL);
	  gem_picture = load_item_picture (XtScreen (w), gem);
	  if (gem_picture != old_picture)
	    XtVaSetValues (w, XmNlabelPixmap, gem_picture, NULL);
	  /* Release the old picture to prevent memory leaks. */
	  if ((old_picture != XmUNSPECIFIED_PIXMAP)
	      && (old_picture != gem_socket_icon))
	    XmDestroyPixmap (XtScreen (w), old_picture);

	  /* Update the gem description */
	  sprintf (make_name, "*field_socketed_gem%d_name", socket_num + 1);
	  w = XxNameToWidget (socket_row, make_name);
	  XmTextFieldSetString (w, (char *) gem->Name());
	  sprintf (make_name, "*field_socketed_gem%d_level", socket_num + 1);
	  w = XxNameToWidget (socket_row, make_name);
	  if (gem->RequiredLevel() > 1)
	    sprintf (make_name, "%2d", gem->RequiredLevel());
	  else
	    make_name[0] = '\0';
	  XmTextFieldSetString (w, make_name);
	}
      }

      else {
	sprintf (make_name, "*button_socket%d", socket_num + 1);
	w = XxNameToWidget (socket_row, make_name);
	XtVaGetValues (w, XmNlabelPixmap, &old_picture,
		       XmNuserData, &item,
		       NULL);
	XtVaSetValues (w, XmNuserData, NULL, NULL);
	gem = (item == NULL) ? NULL : (d2sAttachItem *) *item;

	/* Replace any existing gem icon with an empty socket
	   or with a black icon if there is no socket here. */
	if (socket_num < ditem->ModNumberOfSockets()) {
	  if (old_picture != gem_socket_icon)
	    XtVaSetValues (w, XmNlabelPixmap, gem_socket_icon, NULL);
	} else {
	  if (old_picture != XmUNSPECIFIED_PIXMAP)
	    XtVaSetValues (w, XmNlabelPixmap, XmUNSPECIFIED_PIXMAP, NULL);
	}
	if ((old_picture != XmUNSPECIFIED_PIXMAP)
	    && (old_picture != gem_socket_icon))
	  XmDestroyPixmap (XtScreen (w), old_picture);

	/* The text fields are managed if there is a socket here;
	   unmanaged if there is no socket, except the top row
	   (to give the form its width). */
	sprintf (make_name, "*field_socketed_gem%d_name", socket_num + 1);
	t = XxNameToWidget (socket_row, make_name);
	if (socket_num) {
	  if (gem != NULL)
	    /* Clear the gem description */
	    XmTextFieldSetString (t, (char *) "(empty)");
	} else {
	  if (ditem->NumberOfSockets())
	    XmTextFieldSetString (t, (char *) "(empty)");
	  else
	    XmTextFieldSetString (t, (char *) "(no sockets)");
	}

	sprintf (make_name, "*field_socketed_gem%d_level", socket_num + 1);
	w = XxNameToWidget (socket_row, make_name);
	if (gem != NULL)
	  XmTextFieldSetString (w, (char *) "");

	if (socket_num) {
	  if (socket_num < ditem->ModNumberOfSockets()) {
	    /* In order to prevent the form from trying to resize the
	       name field without a level field, manage the level
	       field first, and unmanage the name field first. */
	    if ( ! XtIsManaged (w))
	      XtManageChild (w);
	    if ( ! XtIsManaged (t))
	      XtManageChild (t);
	  } else {
	    if (XtIsManaged (t))
	      XtUnmanageChild (t);
	    if (XtIsManaged (w))
	      XtUnmanageChild (w);
	  }
	}
      }
    }

  /* Update the sensitivity of the buttons in the socket frame */
  update_item_form_sensitive (ditem, "*frame_socketed_item");
}

/* Change the number of possible sockets. */
static void
update_max_number_of_sockets (d2sDurableItem *ditem)
{
  int		n, max;
  Widget	subform, row;
  char		strbuf[20];

  subform = XxNameToWidget ((Widget) ditem->GetUI(),
			    "*frame_socketed_item");
  XtUnmanageChild (XxNameToWidget (subform, "*spacer_socket_list"));
  max = ditem->MaximumNumberOfSockets();
  n = ditem->ModNumberOfSockets();
  if (n > max)
    max = n;
  for (n = 0; n < MAX_DISPLAYED_SOCKETS; n++) {
    sprintf (strbuf, "*form_socket%d", n + 1);
    row = XxNameToWidget (subform, strbuf);
    if (n < max) {
      if (!XtIsManaged (row))
	XtManageChild (row);
    } else {
      if (XtIsManaged (row))
	XtUnmanageChild (row);
    }
  }

  /* Set the bottom of the form against the last managed row */
  if (max > MAX_DISPLAYED_SOCKETS)
    max = MAX_DISPLAYED_SOCKETS;
  sprintf (strbuf, "*form_socket%d", max);
  row = XxNameToWidget (subform, "*spacer_socket_list");
  XtVaSetValues (row,
		 XmNtopWidget, XxNameToWidget (subform, strbuf),
		 NULL);
  XtManageChild (row);

  /* Update the sensitivity of the rows and buttons. */
  update_socketed_item_box (subform, ditem);

  /* Update the item description, in case the
     actual number of sockets has changed. */
  update_basic_item_description ((Widget) ditem->GetUI(), ditem);
}

/* Configure the form for item quality.  The form contains a section
   which depends on the current quality setting.  The quality form
   will be added as a child of the item-specifics form, but not yet
   managed; the caller is expected to arrange the placement of this
   form before managing it. */
static Widget
configure_item_quality_box (Widget parent, d2sItem *item)
{
  Widget	quality_frame, picture_frame, w;
  Cardinal	status;
  MrmType	class_code;
  d2sExtendedItem *eitem;
  int		i, n;
  char		make_name[32];
  const char	*cstr;

  /* Verify that we have an extended item. */
  if ((item == NULL) || (item->Type() < UNKNOWN_EXTENDED_ITEM))
    return NULL;
  eitem = (d2sExtendedItem *) *item;

  /* Fetch the item quality form */
  status = MrmFetchWidget (item_mrm_hierarchy, "frame_item_quality",
			   parent, &quality_frame, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create item quality form"
	       " for item editor from UID file\n", progname);
      /* This is not a fatal error.  Just prevents functionality. */
      return NULL;
    }

  /* Assign the extended item's pointer to the quality frame. */
  XtVaSetValues (quality_frame, XmNuserData, eitem, NULL);

  /* If this item includes a picture, add the picture selection form */
  picture_frame = NULL;
  if (eitem->Quality()->has_a_picture())
    {
      picture_frame = XxNameToWidget (quality_frame, "*frame_change_picture");
      /* Set the frame's userData resource to a d2sCharmItem * */
      if ((item->Type() == CHARM_ITEM) || (item->Type() == JEWEL_ITEM))
	XtVaSetValues (picture_frame,
		       XmNuserData, (d2sCharmItem *) *item,
		       NULL);
      /* Load an image for each possible picture. */
      n = GetEntryIntegerField (eitem->TypeTableEntry(), "VarInvGfx");
      for (i = 0; i < n; i++)
	{
	  Pixmap	picture;
	  char	*str;

	  sprintf (make_name, "InvGfx%d", i + 1);
	  cstr = GetEntryStringField (eitem->TypeTableEntry(), make_name);
	  if ((cstr[0] == 'i') && (cstr[1] == 'n') && (cstr[2] == 'v'))
	    cstr += 3;
	  str = xfindfile ("items", cstr, ".xpm", path_to_images);
	  if (str == NULL)
	    picture = XmUNSPECIFIED_PIXMAP;
	  else
	    {
	      picture = XmGetPixmap
		(XtScreen (picture_frame), str,
		 WhitePixelOfScreen (XtScreen (picture_frame)),
		 BlackPixelOfScreen (XtScreen (picture_frame)));
	      free (str);
	    }
	  sprintf (make_name, "*box_picture_%d", i);
	  XtVaSetValues (XxNameToWidget (picture_frame, make_name),
			 XmNlabelPixmap, picture,
			 XmNlabelType, ((picture == XmUNSPECIFIED_PIXMAP)
					? XmSTRING : XmPIXMAP),
			 XmNheight, eitem->Size().y * 29 + 3,
			 NULL);
	}
      /* Remove the extra buttons. */
      for ( ; i < 8; i++)
	{
	  sprintf (make_name, "*box_picture_%d", i);
	  w = XtNameToWidget (picture_frame, make_name);
	  if (w == NULL)
	    break;
	  XtUnmanageChild (w);
	}
      /* Since we know how many pictures there are, we know the
	 approixmate width of the frame.  Try to center it. */
      XtVaSetValues (picture_frame,
		     XmNleftOffset, -(33 * n / 2),
		     NULL);
      /* Insert the picture frame after the quality-specific form */
      XtManageChild (picture_frame);
      XtVaSetValues (XxNameToWidget (quality_frame,
				     "*form_quality_specific"),
		     XmNbottomAttachment, XmATTACH_WIDGET,
		     XmNbottomWidget, picture_frame,
		     NULL);
    }

  /* Set the identified toggle */
  XmToggleButtonSetState (XxNameToWidget (quality_frame, "*toggle_identified"),
			  eitem->is_identified(), False);

  /* If the item is nameable, show the personalization field. */
  i = GetEntryIntegerField (item->ItemTableEntry(), "nameable");
  w = XxNameToWidget (quality_frame, "*form_item_owner");
  if (i) {
    XtManageChild (XxNameToWidget (w, "*label_item_owner"));
    XtManageChild (XxNameToWidget (w, "*label_s"));
    w = XxNameToWidget (w, "*field_item_owner");
    XtManageChild (w);
    if (eitem->is_personalized())
      XmTextFieldSetString (w, (char *) eitem->PersonalizedName());
  } else {
    XtUnmanageChild (XxNameToWidget (w, "*label_item_owner"));
    XtUnmanageChild (XxNameToWidget (w, "*field_item_owner"));
    XtUnmanageChild (XxNameToWidget (w, "*label_s"));
  }

  if (picture_frame != NULL)
    {
      /* Remove color fields for items with variable pictures */
      w = XxNameToWidget (quality_frame, "*form_quality_magic");
      XtVaSetValues (XxNameToWidget (w, "*label_magic_level"),
		     XmNrightAttachment, XmATTACH_FORM,
		     NULL);
      XtVaSetValues (XxNameToWidget (w, "*field_magic_prefix_level"),
		     XmNrightAttachment, XmATTACH_FORM,
		     NULL);
      XtVaSetValues (XxNameToWidget (w, "*field_magic_suffix_level"),
		     XmNrightAttachment, XmATTACH_FORM,
		     NULL);
      XtUnmanageChild (XxNameToWidget (w, "*label_magic_color"));
      XtUnmanageChild (XxNameToWidget (w, "*field_magic_prefix_color"));
      XtUnmanageChild (XxNameToWidget (w, "*field_magic_suffix_color"));

      w = XxNameToWidget (quality_frame, "*form_quality_set");
      XtUnmanageChild (XxNameToWidget (w, "*label_set_color"));
      XtUnmanageChild (XxNameToWidget (w, "*field_set_color"));

      w = XxNameToWidget (quality_frame, "*form_quality_rare");
      XtVaSetValues (XxNameToWidget (w, "*label_rare_level"),
		     XmNrightAttachment, XmATTACH_FORM,
		     NULL);
      XtUnmanageChild (XxNameToWidget (w, "*label_rare_color"));
      for (n = 0; n < 6; n++)
	{
	  Widget w2;
	  sprintf (make_name, "*field_rare_hidden%d_level", n + 1);
	  w2 = XxNameToWidget (w, make_name);
	  XtVaSetValues (w2, XmNrightAttachment, XmATTACH_FORM, NULL);
	  sprintf (make_name, "*field_rare_hidden%d_color", n + 1);
	  w2 = XxNameToWidget (w, make_name);
	  XtUnmanageChild (w2);
	}

      w = XxNameToWidget (quality_frame, "*form_quality_unique");
      XtUnmanageChild (XxNameToWidget (w, "*label_unique_color"));
      XtUnmanageChild (XxNameToWidget (w, "*field_unique_color"));
      XtVaSetValues (XxNameToWidget (w, "*field_unique_level"),
		     XmNrightPosition, 20,
		     NULL);
      XtVaSetValues (XxNameToWidget (w, "*combo_unique_name"),
		     XmNrightPosition, 32,
		     NULL);
    }

  /* Before setting the current quality values, call the sensitivity
     update function which has the side effect of installing the
     lists of magic names possible for this item. */
  update_item_form_sensitive (eitem, "*frame_item_quality");

  /* Enable and fill out the quality-specific form */
  update_item_quality_box (quality_frame, eitem);

  /* Lastly, update the unknown field */
  w = XxNameToWidget (quality_frame, "*field_quality_unknown_field");
  if (eitem->Quality()->has_an_11_bit_field())
    sprintf (make_name, "%d", eitem->Quality()->Unknown11());
  else
    make_name[0] = '\0';
  XmTextFieldSetString (w, make_name);

  return quality_frame;
}

/* Forms for each quality setting */
static const char * const quality_form_names[16] = {
  "*form_quality_specific", "*form_quality_low_high",
  NULL /* there is no form for normal quality */, "*form_quality_low_high",
  "*form_quality_magic", "*form_quality_set",
  "*form_quality_rare", "*form_quality_unique",
  "*form_quality_rare" /* For now, until we know the differences */,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL
};

/* Update the item quality */
static void
update_item_quality_box (Widget quality_form, d2sExtendedItem *eitem)
{
  Widget	qtform, w;
  char		make_name[32];
  int		i, n;

  w = XxNameToWidget (quality_form, "*optionmenu_quality");
  XmOptionMenuSetSelection (w, eitem->Quality()->QualityClass() - 1);

  /* Unmanage all quality-specific forms not in use. */
  for (i = (int) LOW_QUALITY; i <= (int) UNIQUE_QUALITY; i++)
    {
      if (quality_form_names[i] != NULL)
	{
	  qtform = XxNameToWidget (quality_form, quality_form_names[i]);
	  if ((i != eitem->Quality()->QualityClass())
	      && XtIsManaged (qtform))
	    XtUnmanageChild (qtform);
	}
    }
  /* Manage the quality-specific form we need */
  i = (int) eitem->Quality()->QualityClass();
  if (quality_form_names[i] == NULL)
    return;
  qtform = XxNameToWidget (quality_form, quality_form_names[i]);
  if (!XtIsManaged (qtform))
    XtManageChild (qtform);

  switch (i)
    {
    case LOW_QUALITY:
      sprintf (make_name, "%d",
	       ((d2sLowQuality *) eitem->Quality())->Grade());
      w = XxNameToWidget (qtform, "*field_grade_number");
      XmTextFieldSetString (w, make_name);
      w = XxNameToWidget (qtform, "*field_grade_name");
      XmTextFieldSetString (w, (char *) ((d2sLowQuality *)
					 eitem->Quality())->GradeName());
      break;

    case HIGH_QUALITY:
      sprintf (make_name, "%d",
	       ((d2sHighQuality *) eitem->Quality())->Grade());
      w = XxNameToWidget (qtform, "*field_grade_number");
      XmTextFieldSetString (w, make_name);
      w = XxNameToWidget (qtform, "*field_grade_name");
      XmTextFieldSetString (w, (char *) ((d2sHighQuality *)
					 eitem->Quality())->GradeName());
      break;

    case MAGIC_QUALITY:
      /* Set the current prefix and suffix */
      i = ((d2sMagicalQuality *) eitem->Quality())->PrefixID();
      w = XxNameToWidget (qtform, "*form_magic_prefix");
      update_magic_xfix_line (w, "magic_prefix", i, "magicprefix");
      i = ((d2sMagicalQuality *) eitem->Quality())->SuffixID();
      w = XxNameToWidget (qtform, "*form_magic_suffix");
      update_magic_xfix_line (w, "magic_suffix", i, "magicsuffix");
      break;

    case PART_OF_A_SET:
      update_set_name (qtform, (d2sQPartOfASet *) eitem->Quality());
      break;

    case RARE_QUALITY:
    case CRAFTED_QUALITY:
      /* Set the current rare name */
      w = XxNameToWidget (qtform, "*combo_rare_first_name");
      update_rare_name (w, ((d2sRareQuality *) eitem->Quality())->TitleID1());
      w = XxNameToWidget (qtform, "*combo_rare_last_name");
      update_rare_name (w, ((d2sRareQuality *) eitem->Quality())->TitleID2());

      for (n = 0; n < 6; n++)
	{
	  i = ((d2sRareQuality *) eitem->Quality())->HiddenFieldID(n);
	  sprintf (make_name, "*form_rare_hidden%d", n + 1);
	  w = XxNameToWidget (qtform, make_name);
	  update_magic_xfix_line (w, &make_name[6], i,
				  (n & 1) ? "magicsuffix" : "magicprefix");
	}
      break;

    case UNIQUE_QUALITY:
      update_unique_name (qtform, ((d2sUniqueQuality *) eitem->Quality()
				   )->UniqueID());
      break;
    }
}

/* Search a StringList for a given ID */
static int
compare_ints (const void *p1, const void *p2)
{
  return (*((int *) p1) - ((_StringListEntry *) p2)->value);
}

/* Set the selected item in a drop-down list to the one
   matching a StringList entry's value.  If no entry in
   the StringList matches the value, provide alternate text. */
static void
update_named_combo_box (Widget combo, int value, const char *alt_text)
{
  StringList	name_list = NULL;
  _StringListEntry *pair = NULL;
  int		position;

  XtVaGetValues (combo, XmNuserData, &name_list, NULL);
  if (name_list == NULL)
    fprintf (stderr, "%s: Internal error: drop-down list %s is not"
	     " initialized\n", progname, XtName (combo));
  else
    pair = (_StringListEntry *) bsearch
      (&value, &name_list->string[0], name_list->count,
       sizeof (_StringListEntry), compare_ints);

  if (pair == NULL)
    {
      /* Set the position index to 0 to indicate we're not using the list */
      XtVaSetValues (combo, XmNselectedPosition, 0, NULL);
      /* Set the name manually */
      XmTextFieldSetString (XxNameToWidget (combo, "*Text"),
			    (char *) alt_text);
    }
  else
    {
      /* Set the position index to match the name in the drop-down list */
      position = 1 + (pair - &name_list->string[0]);
      XtVaSetValues (combo, XmNselectedPosition, position, NULL);
      XmComboBoxUpdate (combo);
    }
}

static void
update_magic_xfix_line (Widget line_form, const char *widgets_name,
			int xfix_id, const char *xfix_table)
{
  Widget	combo_box;
  table_entry_t entry = NULL;
  const char	*cstr;
  char		make_name[32], strbuf[12];
  int		req_level;

  snprintf (make_name, sizeof (make_name), "*combo_%s", widgets_name);
  combo_box = XxNameToWidget (line_form, make_name);
  if (xfix_id) {
    entry = LookupIndexedTableEntry (xfix_table, xfix_id);
    cstr = GetEntryStringField (entry, "Name");
    if (cstr[0])
      cstr = TranslateString (cstr);
    else
      {
	cstr = &strbuf[0];
	sprintf (strbuf, "%d", xfix_id);
      }
  } else {
    cstr = "";
  }
  update_named_combo_box (combo_box, xfix_id, cstr);

  /* Update the required level */
  req_level = GetEntryIntegerField (entry, "levelreq");
  if (req_level > 1)
    sprintf (strbuf, "%d", req_level);
  else
    strbuf[0] = '\0';
  snprintf (make_name, sizeof (make_name), "*field_%s_level", widgets_name);
  XmTextFieldSetString (XxNameToWidget (line_form, make_name), strbuf);

  /* Update the color */
  cstr = GetEntryStringField (entry, "transformcolor");
  if (cstr[0])
    cstr = GetEntryStringField (LookupTableEntry ("colors", "Code", cstr),
				"Transform Color");
  snprintf (make_name,  sizeof (make_name), "*field_%s_color", widgets_name);
  XmTextFieldSetString (XxNameToWidget (line_form, make_name), (char *) cstr);
}

static void
update_set_name (Widget set_form, d2sQPartOfASet *set_quality)
{
  Widget	combo_box, w;
  table_entry_t entry = NULL;
  const char	*cstr;
  char		strbuf[12];
  int		set_count;

  combo_box = XxNameToWidget (set_form, "*combo_set_sets");
  entry = LookupIndexedTableEntry ("setitems", set_quality->SetID());
  cstr = set_quality->SetName();
  if ((cstr == NULL) || (cstr[0] == 0)) {
    cstr = &strbuf[0];
    sprintf (strbuf, "%d", set_quality->SetID());
  } else
    cstr = TranslateString (cstr);
  update_named_combo_box (combo_box, set_quality->SetID(), cstr);

  /* Update the color */
  if (set_quality->is_colored())
    {
      cstr = set_quality->Color();
      cstr = GetEntryStringField
	(LookupTableEntry ("colors", "Code", cstr), "Transform Color");
    }
  else
    cstr = "";
  w = XxNameToWidget (set_form, "*field_set_color");
  XmTextFieldSetString (w, (char *) cstr);

  /* Update the item name */
  w = XxNameToWidget (set_form, "*field_set_item_name");
  XmTextFieldSetString (w, (char *) set_quality->GetMemberName());

  /* Update the required level */
  if (set_quality->RequiredLevel() > 1)
    sprintf (strbuf, "%d", set_quality->RequiredLevel());
  else
    strbuf[0] = '\0';
  w = XxNameToWidget (set_form, "*field_set_item_level");
  XmTextFieldSetString (w, strbuf);

  /* Update the property list count */
  set_count = set_quality->GetSetCount();
  if (set_count <= 3) {
    if (set_count < 1)
      set_count = 1;
    else if (set_count == 1)
      set_count = 2;
    else
      set_count = 3;
  } else {
    if (set_count <= 7)
      set_count = 4;
    else if (set_count <= 15)
      set_count = 5;
    else
      set_count = 6;
  }
  sprintf (strbuf, "%d", set_count);
  w = XxNameToWidget (set_form, "*field_set_property_count");
  XmTextFieldSetString (w, strbuf);
}

static void
update_rare_name (Widget combo_box, int name_id)
{
  const char	*cstr;
  char		strbuf[12];

  if (name_id) {
    cstr = GetRareTitleWord (name_id);
    if ((cstr == NULL) || (cstr[0] == 0))
      {
	cstr = &strbuf[0];
	sprintf (strbuf, "%d", name_id);
      }
  }
  else
    cstr = "";
  update_named_combo_box (combo_box, name_id, cstr);
}

static void
update_unique_name (Widget unique_form, int unique_id)
{
  Widget	combo_box, w;
  table_entry_t entry = NULL;
  const char	*cstr;
  char		strbuf[12];
  int		req_level, color_index;

  entry = LookupIndexedTableEntry ("uniqueitems", unique_id);
  combo_box = XxNameToWidget (unique_form, "*combo_unique_name");
  if (unique_id != 0xfff) {
    cstr = GetEntryStringField (entry, "name");
    if (cstr[0])
      cstr = TranslateString (cstr);
    else
      {
	cstr = &strbuf[0];
	sprintf (strbuf, "%d", unique_id);
      }
  }
  else
    cstr = "";
  update_named_combo_box (combo_box, unique_id, cstr);

  /* Update the required level */
  req_level = GetEntryIntegerField (entry, "LevelReq");
  if (req_level > 1)
    sprintf (strbuf, "%d", req_level);
  else
    strbuf[0] = '\0';
  w = XxNameToWidget (unique_form, "*field_unique_level");
  XmTextFieldSetString (w, strbuf);

  /* Update the color */
  if (GetEntryIntegerField (entry, "invtransform"))
    {
      color_index = GetEntryIntegerField (entry, "transformcolor");
      cstr = GetEntryStringField
	(LookupIndexedTableEntry ("colors", color_index), "Transform Color");
    }
  else
    cstr = "";
  w = XxNameToWidget (unique_form, "*field_unique_color");
  XmTextFieldSetString (w, (char *) cstr);
}

/* Configure the form for magic properties.  The form contains a line
   for each property, which is added programatically.  The property
   form will be added as a child of the item-specifics form, but
   not yet managed; the caller is expected to arrange the placement
   of this form before managing it. */
static Widget
configure_magic_property_box (Widget parent, d2sItem *item)
{
  Widget	magic_frame;
  Cardinal	status;
  MrmType	class_code;
  d2sExtendedItem *eitem;

  /* Verify that we have an extended item. */
  if ((item == NULL) || (item->Type() < UNKNOWN_EXTENDED_ITEM))
    return NULL;
  eitem = (d2sExtendedItem *) *item;
  if (eitem->Properties() == NULL)
    return NULL;

  /* Careful: there are two or three quest items that are extended,
     but cannot have any magic properties.
     If a quest item has a normal quality, skip this frame. */
  if (item->is_quest_item()
      && (eitem->Quality()->QualityClass() == NORMAL_QUALITY))
    return NULL;

  /* Fetch the magic property form */
  status = MrmFetchWidget (item_mrm_hierarchy, "frame_item_magic",
			   parent, &magic_frame, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create magic property form"
	       " for item editor from UID file\n", progname);
      /* This is not a fatal error.  Just prevents functionality. */
      return NULL;
    }

  /* Assign the extended item's pointer to the magic property frame. */
  XtVaSetValues (magic_frame, XmNuserData, eitem, NULL);

  /* Add rows for the magic properties */
  update_magic_property_box (magic_frame, eitem);

  /* Set the preferred height of the scroll box according to
     the number of magic properties.  Not much to go on, but
     it helps when setting the initial window size. */
  XtVaSetValues (XxNameToWidget (magic_frame, "*item_magic_sw"),
		 XmNheight, ((eitem->Properties()->NumberOfProperties() + 1)
			     * 27 + 20),
		 NULL);

  return magic_frame;
}

/* Remove the existing magic properties from the property form */
static void
remove_all_children (Widget table)
{
  WidgetList	children;
  Cardinal	num_children;
  int		i;

  /* Get the list of children */
  XtVaGetValues (table,
		 XmNchildren, &children,
		 XmNnumChildren, &num_children,
		 NULL);
  /* Destroy each child in turn */
  for (i = num_children - 1; i >= 0; i--)
    {
      XtUnmanageChild (children[i]);
      XtDestroyWidget (children[i]);
    }
}

/* Update the magic properties.  Since everything in the property list
   may change, this function discards all existing property rows
   and installs a new set.  Use when quality changes affect the
   magic properties. */
static void
update_magic_property_box (Widget magic_frame, d2sExtendedItem *eitem)
{
  static Arg	add_form_arg[] = {
    { XmNpositionIndex, (XtArgVal) XmLAST_POSITION },
  };
  Arg		add_button_args[] = {
    { XmNalignment, (XtArgVal) XmALIGNMENT_CENTER },
    /* The label string needs to be created by XmStringCreate... */
#define POS_ABA_LS 1
    { XmNlabelString, (XtArgVal) 0 },
    { XmNnavigationType, (XtArgVal) XmTAB_GROUP },
    { XmNmarginWidth, (XtArgVal) 4 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftOffset, (XtArgVal) 24 },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		combo_property_args[] = {
    { XmNarrowSize, (XtArgVal) 17 },
    { XmNcomboBoxType, (XtArgVal) XmDROP_DOWN_LIST },
    { XmNhighlightThickness, (XtArgVal) 1 },
    { XmNmarginHeight, (XtArgVal) 2 },
    { XmNpositionMode, (XtArgVal) XmONE_BASED },
    { XmNshadowThickness, (XtArgVal) 1 },
    { XmNuserData, (XtArgVal) 0 },
    { XmNvisibleItemCount, (XtArgVal) 10 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_WIDGET },
#define POS_CPA_LW 11
    { XmNleftWidget, (XtArgVal) 0 /* to be filled in */ },
    { XmNleftOffset, (XtArgVal) 6 },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Widget	table, last_row = NULL, w;
  XmString	xmstr;
  d2sMagic	*plist;
  int		row, nrows, expansion;
  const char	*cstr;
  StringList	new_prop_list;

  table = XxNameToWidget (magic_frame, "*table_item_magic");
  plist = eitem->Properties();

  /* Remove any existing children */
  remove_all_children (table);

  /* Assign the magic property list's pointer to the table form. */
  XtVaSetValues (table, XmNuserData, plist, NULL);

  /* Add a line for each magic property the item has,
     except the last end-of-list marker. */
  nrows = plist->NumberOfProperties();
  for (row = 0; row < nrows; row++)
    last_row = insert_magic_property_row (table, plist->Property(row), row);
  /* Disable the down arrow on the last row */
  if (last_row != NULL)
    XtUnmanageChild (XxNameToWidget (last_row, "*arrow_property_down"));

  /* Add one final line to give the user a button
     for adding more properties */
  last_row = XmCreateForm (table, "form_property_add",
			   add_form_arg, XtNumber (add_form_arg));
  xmstr = XmStringCreateLocalized ("Add New Property");
  XtSetArg (add_button_args[POS_ABA_LS], XmNlabelString, xmstr);
  w = XmCreatePushButton (last_row, "button_property_add",
			  add_button_args, XtNumber (add_button_args));
  XmStringFree (xmstr);
  XtAddCallback (w, XmNactivateCallback, ui_add_magic_property, magic_frame);
  XtManageChild (w);

  XtSetArg (combo_property_args[POS_CPA_LW], XmNleftWidget, w);
  
  w = XmCreateComboBox (last_row, "combo_new_properties",
			combo_property_args, XtNumber (combo_property_args));
  expansion = (options.item.link.item_expansion
	       || (eitem->Owner() == NULL)
	       || (eitem->Owner()->is_expansion()));
  cstr = (options.character.link.freeform ? ""
	  : GetEntryStringField (eitem->TypeTableEntry(), "Class"));
  new_prop_list = GetMagicPropertyNamesExcept (plist, expansion, cstr);
  install_names_in_dropdown_list (w, new_prop_list);
  XtAddCallback (w, XmNdestroyCallback, ui_remove_names_from_dropdown, NULL);
  if (new_prop_list->count <= 1)
    XtSetSensitive (w, False);
  XtManageChild (w);

  if (options.item.edit.magic_property_list)
    XtManageChild (last_row);
}

/* Insert a magic property in the properties table. */
static Widget
insert_magic_property_row (Widget parent, d2sMagicProperty *prop, int row)
{
  /* Arguments for the various pieces of the line */
  Arg		form_property_args[] = {
#define POS_FPA_PI 0
    { XmNpositionIndex, (XtArgVal) 0 /* to be filled in */ },
#define POS_FPA_UD 1
    { XmNuserData, (XtArgVal) 0 /* to be filled in */ },
  };
  Arg		arrow_up_args[] = {
    { XmNarrowDirection, (XtArgVal) XmARROW_UP },
    { XmNmultiClick, (XtArgVal) XmMULTICLICK_DISCARD },
    { XmNnavigationType, (XtArgVal) XmTAB_GROUP },
    { XmNwidth, (XtArgVal) 24 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		arrow_down_args[] = {
    { XmNarrowDirection, (XtArgVal) XmARROW_DOWN },
    { XmNmultiClick, (XtArgVal) XmMULTICLICK_DISCARD },
    { XmNnavigationType, (XtArgVal) XmTAB_GROUP },
    { XmNwidth, (XtArgVal) 24 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftOffset, (XtArgVal) 24 },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg	button_delete_args[] = {
    { XmNalignment, (XtArgVal) XmALIGNMENT_CENTER },
    /* The label string needs to be created by XmStringCreate... */
#define POS_BDA_LS 1
    { XmNlabelString, (XtArgVal) 0 },
    { XmNnavigationType, (XtArgVal) XmTAB_GROUP },
    { XmNmarginWidth, (XtArgVal) 4 },
#define POS_BDA_S 4
    { XmNsensitive, (XtArgVal) True },
#define POS_BDA_UD 5
    { XmNuserData, (XtArgVal) 0 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftOffset, (XtArgVal) 48 },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		label_description_args[] = {
    { XmNalignment, (XtArgVal) XmALIGNMENT_BEGINNING },
    /* The label string needs to be created by XmStringCreate... */
#define POS_LDA_LS 1
    { XmNlabelString, (XtArgVal) 0 },
    { XmNmarginWidth, (XtArgVal) 4 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_WIDGET },
#define POS_LDA_LW 6
    { XmNleftWidget, (XtArgVal) 0 /* to be filled in */ },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		separator_args[] = {
    { XmNorientation, (XtArgVal) XmHORIZONTAL },
    { XmNseparatorType, (XtArgVal) XmSHADOW_ETCHED_OUT },
    { XmNwidth, (XtArgVal) 100 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_WIDGET },
#define POS_SA_LW 6
    { XmNleftWidget, (XtArgVal) 0 /* to be filled in */ },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		frame_field_args[] = {
    { XmNshadowThickness, (XtArgVal) 1 },
    { XmNshadowType, (XtArgVal) XmSHADOW_IN },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_WIDGET },
#define POS_FrFA_LW 5
    { XmNleftWidget, (XtArgVal) 0 /* to be filled in */ },
    { XmNleftOffset, (XtArgVal) 4 },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		form_field_args[] = {
    { XmNallowOverlap, (XtArgVal) False },
    { XmNmarginHeight, (XtArgVal) 0 },
    { XmNmarginWidth, (XtArgVal) 0 },
#define POS_FoFA_UD 3
    { XmNuserData, (XtArgVal) 0 /* to be filled in */ },
  };
  Arg		label_field_args[] = {
    /* The label string needs to be created by XmStringCreate... */
#define POS_LFA_LS 0
    { XmNlabelString, (XtArgVal) 0 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		field_field_args[] = {
#define POS_FFA_C 0
    { XmNcolumns, (XtArgVal) 2 /* to be filled in */ },
    { XmNcursorPositionVisible, (XtArgVal) False },
    { XmNeditable, (XtArgVal) True },
    { XmNhighlightThickness, (XtArgVal) 1 },
#define POS_FFA_ML 4
    { XmNmaxLength, (XtArgVal) 3 /* to be filled in */ },
    { XmNnavigationType, (XtArgVal) XmTAB_GROUP },
    { XmNshadowThickness, (XtArgVal) 0 },
    { XmNtraversalOn, (XtArgVal) True },
#define POS_FFA_UD 8
    { XmNuserData, (XtArgVal) 0 /* to be filled in */ },
#define POS_FFA_V 9
    { XmNvalue, (XtArgVal) "" /* to be filled in */ },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_WIDGET },
#define POS_FFA_LW 13
    { XmNleftWidget, (XtArgVal) 0 /* to be filled in */ },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		combo_field_args[] = {
    { XmNarrowSize, (XtArgVal) 17 },
    { XmNcomboBoxType, (XtArgVal) XmDROP_DOWN_LIST },
    { XmNhighlightThickness, (XtArgVal) 1 },
    { XmNmarginHeight, (XtArgVal) 2 },
    { XmNpositionMode, (XtArgVal) XmONE_BASED },
    { XmNshadowThickness, (XtArgVal) 1 },
    { XmNuserData, (XtArgVal) 0 },
    { XmNvisibleItemCount, (XtArgVal) 10 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_WIDGET },
#define POS_CFA_LW 11
    { XmNleftWidget, (XtArgVal) 0 /* to be filled in */ },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		label_suffix_args[] = {
    /* The label string needs to be created by XmStringCreate... */
#define POS_LSA_LS 0
    { XmNlabelString, (XtArgVal) 0 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_WIDGET },
#define POS_LSA_LW 4
    { XmNleftWidget, (XtArgVal) 0 /* to be filled in */ },
    { XmNrightAttachment, (XtArgVal) XmATTACH_FORM },
  };
  Arg		spacer_args[] = {
    /* The label string needs to be created by XmStringCreate... */
#define POS_SLA_LS 0
    { XmNlabelString, (XtArgVal) 0 },
    { XmNmarginWidth, (XtArgVal) 0 },
    { XmNrecomputeSize, (XtArgVal) False },
    { XmNwidth, (XtArgVal) 0 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftAttachment, (XtArgVal) XmATTACH_WIDGET },
#define POS_SLA_LW 7
    { XmNleftWidget, (XtArgVal) 0 /* to be filled in */ },
    { XmNrightAttachment, (XtArgVal) XmATTACH_FORM },
  };

  /* Other local variables */
  Widget	row_widget, last_widget, w;
  Widget	frame_field, form_field;
  Widget	label_field, data_field, field_suffix;
  XmString	xmstr;
  char		make_name[32];
  int		field_num, i;
  const char	*cstr;
  char		*field_value;
  StringList	skill_list;

  /* Create a new row as a child of the table;
     Assign a pointer to the magic property we're describing */
  XtSetArg (form_property_args[POS_FPA_PI], XmNpositionIndex, row);
  XtSetArg (form_property_args[POS_FPA_UD], XmNuserData, prop);
  row_widget = XmCreateForm (parent, "form_property", form_property_args, 2);

  /* Create arrow buttons for repositioning the property */
  w = XmCreateArrowButton (row_widget, "arrow_property_up",
			   arrow_up_args, XtNumber (arrow_up_args));
  XtAddCallback (w, XmNactivateCallback, ui_move_magic_property, row_widget);
  /* Don't display the up arrow on the first row */
  if (row)
    XtManageChild (w);

  w = XmCreateArrowButton (row_widget, "arrow_property_down",
			   arrow_down_args, XtNumber (arrow_down_args));
  XtAddCallback (w, XmNactivateCallback, ui_move_magic_property, row_widget);
  /* Don't display the down arrow on the last row */
  if (row < prop->ParentList()->NumberOfProperties() - 1)
    XtManageChild (w);

  /* Create a delete button for removing the property;
     Need to create a label */
  xmstr = XmStringCreateLocalized ("Delete");
  XtSetArg (button_delete_args[POS_BDA_LS], XmNlabelString, xmstr);
  /* Make the button inactive if this is a list separator */
  if (prop->ID() == END_OF_LIST_MARKER)
    XtSetArg (button_delete_args[POS_BDA_S], XmNsensitive, True);
  /* Duplicate the parent's userData, for convenience */
  XtSetArg (button_delete_args[POS_BDA_UD], XmNuserData, prop);
  w = XmCreatePushButton (row_widget, "button_property_delete",
			  button_delete_args, XtNumber (button_delete_args));
  XmStringFree (xmstr);
  if (prop->ID() != END_OF_LIST_MARKER)
    XtAddCallback (w, XmNactivateCallback,
		   ui_delete_magic_property, row_widget);
  XtManageChild (w);
  last_widget = w;

  /* Create a label for the property description */
  if (prop->ID() == END_OF_LIST_MARKER)
    {
      XtSetArg (separator_args[POS_SA_LW], XmNleftWidget, last_widget);
      w = XmCreateSeparator (row_widget, "separator_property",
			     separator_args, XtNumber (separator_args));
    }
  else
    {
      cstr = prop->Description();
      xmstr = XmStringCreateLocalized ((char *) cstr);
      XtSetArg (label_description_args[POS_LDA_LS], XmNlabelString, xmstr);
      XtSetArg (label_description_args[POS_LDA_LW],
		XmNleftWidget, last_widget);
      w = XmCreateLabel (row_widget, "label_property_desc",
			 label_description_args,
			 XtNumber (label_description_args));
      XmStringFree (xmstr);
    }
  XtManageChild (w);
  last_widget = w;

  /* Create forms for each of the property's fields */
  for (field_num = 0; field_num < prop->NumberOfFields(); field_num++)
    {
      /* Skip boolean fields */
      if (!prop->FieldType(field_num) || (prop->FieldType(field_num) == 'b'))
	continue;

      /* Create a frame and form for the field */
      sprintf (make_name, "frame_property_field%d", field_num);
      XtSetArg (frame_field_args[POS_FrFA_LW], XmNleftWidget, last_widget);
      frame_field = XmCreateFrame (row_widget, make_name,
				   frame_field_args,
				   XtNumber (frame_field_args));
      last_widget = frame_field;

      sprintf (make_name, "form_property_field%d", field_num);
      XtSetArg (form_field_args[POS_FoFA_UD], XmNuserData, field_num);
      form_field = XmCreateForm (frame_field, make_name,
				 form_field_args,
				 XtNumber (form_field_args));

      /* Create a label for the field */
      sprintf (make_name, "label_property_field%d", field_num);
      cstr = prop->FieldDescription (field_num);
      if (strcmp (cstr, prop->Description()) == 0)
	/* Reduce redundant redundancies */
	cstr = "";
      xmstr = XmStringCreateLocalized ((char *) cstr);
      XtSetArg (label_field_args[POS_LFA_LS], XmNlabelString, xmstr);
      label_field = XmCreateLabel (form_field, make_name,
				   label_field_args,
				   XtNumber (label_field_args));
      XmStringFree (xmstr);
      XtManageChild (label_field);

      /* Create a text field for numeric data,
	 or a combo box for string selection. */
      field_value = prop->FieldValue (field_num);
      if (prop->FieldType (field_num) == 's') {
	sprintf (make_name, "combo_property_field%d", field_num);
	XtSetArg (combo_field_args[POS_CFA_LW], XmNleftWidget, label_field);
	data_field = XmCreateComboBox (form_field, make_name,
				       combo_field_args,
				       XtNumber (combo_field_args));
	/* Fill in the combo box */
	/* TO-DO: this should be moved to options.cc */
	skill_list = prop->FieldStringList (field_num);
	install_names_in_dropdown_list (data_field, skill_list);
	/* Set the displayed skill */
	update_named_combo_box (data_field, prop->FieldData (field_num),
				field_value);
	XtAddCallback (data_field, XmNselectionCallback,
		       ui_select_property_value, row_widget);
	XtAddCallback (w, XmNdestroyCallback,
		       ui_remove_names_from_dropdown, NULL);
      } else {
	sprintf (make_name, "field_property_field%d", field_num);
	/* Figure out the width of the text field dynamically */
	if (prop->FieldType (field_num) == 'd') {
	  /* Default to the width of a %g printf format;
	     we don't care how many digits there are after the decimal */
	  XtSetArg (field_field_args[POS_FFA_C], XmNcolumns, 6);
	  XtSetArg (field_field_args[POS_FFA_ML], XmNmaxLength, 36);
	} else {
	  i = prop->FieldBits (field_num);
	  /* The number of digits ~= log10(2^bits) = bits*ln(2)/ln(10) */
	  i = (i * 1000 + 3320) / 3322;
	  XtSetArg (field_field_args[POS_FFA_C], XmNcolumns, i);
	  /* If the number may be negative, add one character for the '-' */
	  if (prop->Bias())
	    i++;
	  XtSetArg (field_field_args[POS_FFA_ML], XmNmaxLength, i);
	}
	XtSetArg (field_field_args[POS_FFA_UD], XmNuserData, prop);
	/* Fill in the field value */
	XtSetArg (field_field_args[POS_FFA_V], XmNvalue, field_value);
	XtSetArg (field_field_args[POS_FFA_LW], XmNleftWidget, label_field);
	data_field = XmCreateTextField (form_field, make_name,
					field_field_args,
					XtNumber (field_field_args));
	/* Add callbacks for text editing */
	XtAddCallback (data_field, XmNfocusCallback,
		       ui_enable_cursor, NULL);
	XtAddCallback (data_field, XmNlosingFocusCallback,
		       ui_disable_cursor, NULL);
	/* The modification callback depends on both the data type
	   and, if integer, whether the data can be negative. */
	XtAddCallback (data_field, XmNmodifyVerifyCallback,
		       ((prop->FieldType (field_num) == 'd')
			? ui_fpnumeric_verify
			: (prop->Bias()
			   ? ui_snumeric_verify : ui_numeric_verify)),
		       NULL);
	XtAddCallback (data_field, XmNactivateCallback,
		       ui_change_property_value, row_widget);
	XtAddCallback (data_field, XmNlosingFocusCallback,
		       ui_change_property_value, row_widget);
      }
      free (field_value);
      XtManageChild (data_field);

      /* Create a label for the field suffix */
      sprintf (make_name, "label_property_suffix%d", field_num);
      cstr = prop->FieldUnits (field_num);
      xmstr = XmStringCreateLocalized ((char *) cstr);
      XtSetArg (label_suffix_args[POS_LSA_LS], XmNlabelString, xmstr);
      XtSetArg (label_suffix_args[POS_LSA_LW], XmNleftWidget, data_field);
      field_suffix = XmCreateLabel (form_field, make_name,
				    label_suffix_args,
				    XtNumber (label_suffix_args));
      XmStringFree (xmstr);
      XtManageChild (field_suffix);

      XtManageChild (form_field);
      XtManageChild (frame_field);
    }

  /* Add a spacer widget to fill in the end of the row */
  xmstr = XmStringCreateLocalized ("");
  XtSetArg (spacer_args[POS_SLA_LS], XmNlabelString, xmstr);
  XtSetArg (spacer_args[POS_SLA_LW], XmNleftWidget, last_widget);
  w = XmCreateLabel (row_widget, "spacer_property",
		     spacer_args, XtNumber (spacer_args));
  XmStringFree (xmstr);
  XtManageChild (w);

  /* Finally, manage the row. */
  XxManageChild (row_widget);
  return row_widget;
}


/* Transform an item from one type to another. */
void
ui_change_potion (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	change_frame = (Widget) client_data;
  d2sPotionItem *potion;
  int		type, grade;

  /* Get the potion pointer from the potion selection frame */
  XtVaGetValues (change_frame, XmNuserData, &potion, NULL);
  if (potion == NULL)
    return;

  stdui = potion->GetUI();

  /* Get the new potion type and grade from the widget */
  XtVaGetValues (w, XmNuserData, &grade, NULL);
  type = grade / 10;
  grade = grade % 10;

  /* Attempt to change the potion type */
  if (potion->TransformInto (type, grade) < 0)
    {
      /* Failed. */
      display_error ("Cannot change the %s; %s",
		     potion->Name(), potion->GetErrorMessage());
      return;
    }

  /* On a successful change, we need to update the item description. */
  update_item_header ((Widget) potion->GetUI(), potion);
  /* Also update the window title to reflect the new name. */
  update_item_window_title ((Widget) potion->GetUI(), potion);
  /* Also update the potion's picture in the character inventory. */
  update_item_in_inventory (potion);
}

void
ui_change_gem (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	change_frame = (Widget) client_data;
  d2sGemItem *	gem;
  int		type, grade;

  /* Get the gem pointer from the gem selection frame */
  XtVaGetValues (change_frame, XmNuserData, &gem, NULL);
  if (gem == NULL)
    return;

  stdui = gem->GetUI();

  /* Get the new gem type and grade from the widget */
  XtVaGetValues (w, XmNuserData, &grade, NULL);
  type = grade % 10;
  grade = grade / 10;

  /* Attempt to change the gem type */
  if (gem->TransformInto (type, grade) < 0)
    {
      /* Failed. */
      display_error ("Cannot change the %s; %s",
		     gem->Name(), gem->GetErrorMessage());
      return;
    }

  /* On a successful change, we need to update the item description. */
  update_item_header ((Widget) gem->GetUI(), gem);
  /* Also update the window title to reflect the new name. */
  update_item_window_title ((Widget) gem->GetUI(), gem);
  /* Also update the gem's picture in the character inventory. */
  update_item_in_inventory (gem);
  /* If the gem is attached to an item, we need to update
     that item too, because of color shifting. */
  if (gem->AttachedTo() != NULL)
    update_socketed_item (gem->AttachedTo());
}

void
ui_change_rune (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	change_frame = (Widget) client_data;
  d2sRuneItem *	rune;
  int		rune_number;

  /* Get the rune pointer from the rune selection frame */
  XtVaGetValues (change_frame, XmNuserData, &rune, NULL);
  if (rune == NULL)
    return;

  stdui = rune->GetUI();

  /* Get the new rune number from the widget */
  XtVaGetValues (w, XmNuserData, &rune_number, NULL);

  /* Attempt to change the rune */
  if (rune->TransformInto (rune_number) < 0)
    {
      /* Failed. */
      display_error ("Cannot change the %s; %s",
		     rune->Name(), rune->GetErrorMessage());
      return;
    }

  /* On a successful change, we need to update the item description. */
  update_item_header ((Widget) rune->GetUI(), rune);
  /* Also update the window title to reflect the new name. */
  update_item_window_title ((Widget) rune->GetUI(), rune);
  /* Also update the rune's picture in the character inventory. */
  update_item_in_inventory (rune);
  /* If the gem is attached to an item, and that item is displayed
     in another window, we need to update that item too, because
     the full description will have changed. */
  if (rune->AttachedTo() != NULL)
    update_socketed_item (rune->AttachedTo());
}


/* Callbacks for changing various item data */
void
ui_item_change_fingerprint (Widget w, XtPointer client_data,
			    XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  d2sExtendedItem *eitem;
  char		*strval, strbuf[16];
  unsigned long new_fingerprint;

  XtVaGetValues (subform, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = eitem->GetUI();

  strval = XmTextFieldGetString (w);
  if (!strval[0])
    {
      /* The user has apparently deleted the number.  Put it back. */
      sprintf (strbuf, "%#.8lx", eitem->UniqueID());
      XmTextFieldSetString (w, strbuf);
      XtFree (strval);
      return;
    }

  new_fingerprint = strtoul (strval, NULL, 0);
  XtFree (strval);
  if (new_fingerprint == eitem->UniqueID())
    /* The value hasn't actually changed; don't bother the item. */
    return;

  if (eitem->SetUniqueID (new_fingerprint) < 0)
    {
      /* Error!  Restore the original fingerprint */
      sprintf (strbuf, "%#.8lx", eitem->UniqueID());
      XmTextFieldSetString (w, strbuf);
      display_error (eitem->GetErrorMessage());
      return;
    }
}

void
ui_item_change_level (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  d2sExtendedItem *eitem;
  char		*strval, strbuf[20];
  int		new_level;

  XtVaGetValues (subform, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = eitem->GetUI();

  strval = XmTextFieldGetString (w);
  if (!strval[0])
    {
      /* The user has apparently deleted the number.  Put it back. */
      sprintf (strbuf, "%d", eitem->Level());
      XmTextFieldSetString (w, strbuf);
      XtFree (strval);
      return;
    }

  new_level = atoi (strval);
  XtFree (strval);
  if (new_level == eitem->Level())
    /* The value hasn't actually changed; don't bother the item. */
    return;

  if (eitem->SetLevel (new_level) < 0)
    {
      /* Error!  Restore the previous value */
      sprintf (strbuf, "%d", eitem->Level());
      XmTextFieldSetString (w, strbuf);
      display_error (eitem->GetErrorMessage());
      return;
    }

  /* Update the available magic names */
  update_item_form_sensitive (eitem, "*frame_item_quality");

  /* If this is a socketed item, we may need to
     update the number of possible sockets. */
  if ((eitem->Type() == ARMOR_ITEM) || (eitem->Type() == WEAPON_ITEM)) {
    d2sDurableItem *ditem = (d2sDurableItem *) *((d2sItem *) eitem);
    if (ditem->MaximumNumberOfSockets())
      update_max_number_of_sockets (ditem);
  }
}

void
ui_item_toggle_newbie (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  XmToggleButtonCallbackStruct *cbs
    = (XmToggleButtonCallbackStruct *) call_data;
  d2sDurableItem *ditem;

  XtVaGetValues (subform, XmNuserData, &ditem, NULL);
  if (ditem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = ditem->GetUI();

  if (ditem->SetNewbie (cbs->set) < 0)
    {
      /* Error!  Restore the toggle state. */
      XmToggleButtonSetState (w, ditem->is_newbie() ? XmSET : XmUNSET, False);
      display_error (ditem->GetErrorMessage());
      return;
    }
  /* Nothing extra needs to be done for this toggle.  I think. */
}

void
ui_item_toggle_ethereal (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  XmToggleButtonCallbackStruct *cbs
    = (XmToggleButtonCallbackStruct *) call_data;
  d2sDurableItem *ditem;

  XtVaGetValues (subform, XmNuserData, &ditem, NULL);
  if (ditem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = ditem->GetUI();

  if (ditem->SetEthereal (cbs->set) < 0)
    {
      /* Error!  Restore the toggle state. */
      XmToggleButtonSetState (w, ditem->is_ethereal() ? XmSET : XmUNSET,
			      False);
      display_error (ditem->GetErrorMessage());
      return;
    }

  /* Update the item description box */
  update_basic_item_description ((Widget) ditem->GetUI(), ditem);
}

void
ui_item_change_durability (Widget w, XtPointer client_data,
			   XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  d2sDurableItem *ditem;
  char		*strval, strbuf[16];
  int		new_durability;

  XtVaGetValues (subform, XmNuserData, &ditem, NULL);
  if (ditem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = ditem->GetUI();

  strval = XmTextFieldGetString (w);
  if (!strval[0])
    {
      /* The user has apparently deleted the number.  Put it back. */
      sprintf (strbuf, "%d", ditem->Durability());
      XmTextFieldSetString (w, strbuf);
      XtFree (strval);
      return;
    }

  new_durability = atoi (strval);
  if (new_durability == ditem->Durability())
    {
      /* The value hasn't actually changed; don't bother the item. */
      XtFree (strval);
      return;
    }

  if (ditem->SetDurability (new_durability) < 0)
    {
      /* Error!  Restore the original value. */
      sprintf (strbuf, "%d", ditem->Durability());
      XmTextFieldSetString (w, strbuf);
      display_error (ditem->GetErrorMessage());
      XtFree (strval);
      return;
    }

  /* Update the item description box */
  update_basic_item_description ((Widget) ditem->GetUI(), ditem);
  XtFree (strval);
  return;
}

void
ui_item_change_base_durability (Widget w, XtPointer client_data,
				XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  d2sDurableItem *ditem;
  char		*strval, strbuf[16];
  int		new_durability;

  XtVaGetValues (subform, XmNuserData, &ditem, NULL);
  if (ditem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = ditem->GetUI();

  strval = XmTextFieldGetString (w);
  if (!strval[0])
    {
      /* The user has apparently deleted the number.  Put it back. */
      sprintf (strbuf, "%d", ditem->BaseDurability());
      XmTextFieldSetString (w, strbuf);
      XtFree (strval);
      return;
    }

  new_durability = atoi (strval);
  if (new_durability == ditem->BaseDurability())
    {
      /* The value hasn't actually changed; don't bother the item. */
      XtFree (strval);
      return;
    }

  if (ditem->SetBaseDurability (new_durability) < 0)
    {
      /* Error!  Restore the original value. */
      sprintf (strbuf, "%d", ditem->BaseDurability());
      XmTextFieldSetString (w, strbuf);
      display_error (ditem->GetErrorMessage());
      XtFree (strval);
      return;
    }

  /* In some cases, changing the base durability will also change
     the current durability to match.  Update the current durability. */
  sprintf (strbuf, "%d", ditem->Durability());
  XmTextFieldSetString (XxNameToWidget (subform, "*field_current_durability"),
			strbuf);

  /* Update the item description box */
  update_basic_item_description ((Widget) ditem->GetUI(), ditem);
  XtFree (strval);
  return;
}

void
ui_item_change_defense (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  d2sArmorItem *armor;
  char		*strval, strbuf[16];
  int		new_defense;

  XtVaGetValues (subform, XmNuserData, &armor, NULL);
  if (armor == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = armor->GetUI();

  strval = XmTextFieldGetString (w);
  if (!strval[0])
    {
      /* The user has apparently deleted the number.  Put it back. */
      sprintf (strbuf, "%d", armor->BaseDefense());
      XmTextFieldSetString (w, strbuf);
      XtFree (strval);
      return;
    }

  new_defense = atoi (strval);
  if (new_defense == armor->BaseDefense())
    {
      /* The value hasn't actually changed; don't bother the item. */
      XtFree (strval);
      return;
    }

  if (armor->SetDefense (new_defense) < 0)
    {
      /* Error!  Restore the original value. */
      sprintf (strbuf, "%d", armor->BaseDefense());
      XmTextFieldSetString (w, strbuf);
      display_error (armor->GetErrorMessage());
      XtFree (strval);
      return;
    }

  /* Update the item description box */
  update_basic_item_description ((Widget) armor->GetUI(), armor);
  XtFree (strval);
  return;
}

void
ui_item_change_quantity (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  d2sStackItem *stack;
  char		*strval, strbuf[16];
  int		new_quantity;

  XtVaGetValues (subform, XmNuserData, &stack, NULL);
  if (stack == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = stack->GetUI();

  strval = XmTextFieldGetString (w);
  if (!strval[0])
    {
      /* The user has apparently deleted the number.  Put it back. */
      sprintf (strbuf, "%d", stack->Quantity());
      XmTextFieldSetString (w, strbuf);
      XtFree (strval);
      return;
    }

  new_quantity = atoi (strval);
  if (new_quantity == stack->Quantity())
    {
      /* The value hasn't actually changed; don't bother the item. */
      XtFree (strval);
      return;
    }

  if (stack->SetQuantity (new_quantity) < 0)
    {
      /* Error!  Restore the original value. */
      sprintf (strbuf, "%d", stack->Quantity());
      XmTextFieldSetString (w, strbuf);
      display_error (stack->GetErrorMessage());
      XtFree (strval);
      return;
    }

  /* Update the item description box */
  update_basic_item_description ((Widget) stack->GetUI(), stack);
  XtFree (strval);
  return;
}

void
ui_item_toggle_identified (Widget w, XtPointer client_data,
			   XtPointer call_data)
{
  Widget	subform = (Widget) client_data;
  XmToggleButtonCallbackStruct *cbs
    = (XmToggleButtonCallbackStruct *) call_data;
  d2sExtendedItem *eitem;

  XtVaGetValues (subform, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (subform));
    return;
  }

  stdui = eitem->GetUI();

  if (eitem->SetIdentified (cbs->set) < 0)
    {
      /* Error!  Restore the toggle state. */
      XmToggleButtonSetState (w, eitem->is_identified() ? XmSET : XmUNSET,
			      False);
      display_error (eitem->GetErrorMessage());
      return;
    }

  /* Update the item description box */
  update_basic_item_description ((Widget) eitem->GetUI(), eitem);
}

void
ui_item_change_owner (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	quality_form = (Widget) client_data;
  d2sExtendedItem *eitem;
  char		*new_name;

  XtVaGetValues (quality_form, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (quality_form));
    return;
  }

  stdui = eitem->GetUI();

  new_name = XmTextFieldGetString (w);
  if (strcmp (new_name, eitem->PersonalizedName()) == 0)
    {
      /* Nothing has changed */
      XtFree (new_name);
      return;
    }

  if (eitem->Personalize (new_name) < 0)
    {
      /* Error!  Restore the original value. */
      XmTextFieldSetString (w, (char *) eitem->PersonalizedName());
      display_error (eitem->GetErrorMessage());
      XtFree (new_name);
      return;
    }

  /* Update the item description box */
  update_basic_item_description ((Widget) eitem->GetUI(), eitem);
  XtFree (new_name);
  /* Update the item tooltip on the character's inventory */
  update_item_in_inventory (eitem);
  return;
}

void
ui_change_item_quality (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	quality_form = (Widget) client_data;
  d2sExtendedItem *eitem;
  short		position;
  int		status;

  XtVaGetValues (quality_form, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (quality_form));
    return;
  }
  XtVaGetValues (w, XmNpositionIndex, &position, NULL);
  if (position == eitem->Quality()->QualityClass())
    /* No change required */
    return;
  stdui = eitem->GetUI();

  /* Try changing the quality */
  status = eitem->ChangeQuality (position);
  if (status < 0)
    {
      XmOptionMenuSetSelection
	(XxNameToWidget (quality_form, "*optionmenu_quality"),
	 eitem->Quality()->QualityClass() - 1);
      display_error (eitem->GetErrorMessage());
      return;
    }

  /* Success!  Update the quality box */
  update_item_quality_box (quality_form, eitem);
  if (options.item.link.quality_magic)
    {
      /* Update the magic properties */
      update_magic_property_box
	(XxNameToWidget ((Widget) eitem->GetUI(), "*frame_item_magic"), eitem);

      /* If this item is a jewel, and it is attached to another item,
	 the other item's description also needs to be updated. */
      if (eitem->Type() == JEWEL_ITEM)
	{
	  d2sJewelItem *jewel = (d2sJewelItem *) *((d2sItem *) eitem);
	  update_socketed_item (jewel->AttachedTo());
	}
    }
  /* Update the item description and picture (in case of color changes). */
  update_item_header ((Widget) eitem->GetUI(), eitem);
  update_item_in_inventory (eitem);
  /* Update the gem box if we have one */
  if ((eitem->Type() == ARMOR_ITEM) || (eitem->Type() == WEAPON_ITEM))
    {
      d2sDurableItem *ditem = (d2sDurableItem *) *((d2sItem *) eitem);
      if (ditem->MaximumNumberOfSockets())
	update_max_number_of_sockets (ditem);
    }
}

/* Combine ui_change_magic_prefix and ui_change_magic_suffix */
static void
change_magic_xfix (Widget w, Widget quality_form,
		   XmComboBoxCallbackStruct *cbs,
		   int (d2sMagicalQuality::*XfixID)(void) const,
		   int (d2sMagicalQuality::*ChangeXfix)(int),
		   const char *widgets_name, const char *xfix_table)
{
  StringList	xfix_list = NULL;
  d2sExtendedItem *eitem;
  d2sMagicalQuality *mq;
  int		value, was_colored;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  XtVaGetValues (quality_form, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (quality_form));
    return;
  }
  XtVaGetValues (w, XmNuserData, &xfix_list, NULL);

  stdui = eitem->GetUI();
  mq = (d2sMagicalQuality *) eitem->Quality();
  was_colored = eitem->is_colored();

  /* Figure out the prefix or suffix ID according to
     the new selected item in the drop-down list. */
  if (!cbs->item_position || (xfix_list == NULL)
      || (cbs->item_position > xfix_list->count))
    {
      if (debug)
	{
	  fprintf (stderr, "%s: Internal error: %s's %s\n combo box",
		   progname, eitem->Name(), widgets_name);
	  if (!cbs->item_position)
	    fprintf (stderr, " has an item position of 0\n");
	  else if (xfix_list == NULL)
	    fprintf (stderr, " does not have a name list installed\n");
	  else
	    fprintf (stderr, " has an invalid item position"
		     " (%d, out of %d names)\n",
		     cbs->item_position, xfix_list->count);
	}
      update_magic_xfix_line (XtParent (w), widgets_name,
			      (mq->*XfixID)(), xfix_table);
      return;
    }

  value = xfix_list->string[cbs->item_position - 1].value;
  if (value == (mq->*XfixID)())
    /* No change required */
    return;

  if ((mq->*ChangeXfix) (value) < 0)
    {
      /* Error!  Restore the combo box. */
      update_magic_xfix_line (XtParent (w), widgets_name,
			      (mq->*XfixID)(), xfix_table);
      display_error (mq->GetErrorMessage());
      return;
    }

  /* Update the item description.
     Update the picture too if the item is or was colored. */
  if (was_colored || eitem->is_colored())
    update_item_header ((Widget) eitem->GetUI(), eitem);
  else
    update_basic_item_description ((Widget) eitem->GetUI(), eitem);
  /* We need to update the inventory not just for the item color but
     also to get the side effect of updating the button's tooltip string. */
  update_item_in_inventory (eitem);
  /* Update the rest of this prefix line (level and color) */
  update_magic_xfix_line (XtParent (w), widgets_name,
			  (mq->*XfixID)(), xfix_table);
  /* If the quality is linked to the magic properties,
     update the magic properties frame. */
  if (options.item.link.quality_magic)
    {
      Widget magic_frame = XtNameToWidget
	((Widget) eitem->GetUI(), "*frame_item_magic");
      if (magic_frame != NULL)
	update_magic_property_box (magic_frame, eitem);

      /* If this item is a jewel, and it is attached to another item,
	 the other item's description also needs to be updated. */
      if (eitem->Type() == JEWEL_ITEM)
	{
	  d2sJewelItem *jewel = (d2sJewelItem *) *((d2sItem *) eitem);
	  update_socketed_item (jewel->AttachedTo());
	}
    }
  /* Update the gem box if we have one */
  if ((eitem->Type() == ARMOR_ITEM) || (eitem->Type() == WEAPON_ITEM))
    {
      d2sDurableItem *ditem = (d2sDurableItem *) *((d2sItem *) eitem);
      if (ditem->MaximumNumberOfSockets())
	update_max_number_of_sockets (ditem);
    }
}

void
ui_change_magic_prefix (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_magic_xfix (w, (Widget) client_data,
		     (XmComboBoxCallbackStruct *) call_data,
		     &d2sMagicalQuality::PrefixID,
		     &d2sMagicalQuality::ChangePrefix,
		     "magic_prefix", "magicprefix");
}

void
ui_change_magic_suffix (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_magic_xfix (w, (Widget) client_data,
		     (XmComboBoxCallbackStruct *) call_data,
		     &d2sMagicalQuality::SuffixID,
		     &d2sMagicalQuality::ChangeSuffix,
		     "magic_suffix", "magicsuffix");
}

/* Change a set item to an item from another set */
void
ui_change_set_item (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget quality_form = (Widget) client_data;
  XmComboBoxCallbackStruct *cbs = (XmComboBoxCallbackStruct *) call_data;
  StringList	name_list = NULL;
  d2sExtendedItem *eitem;
  d2sQPartOfASet *sq;
  int		value, was_colored;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  XtVaGetValues (quality_form, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (quality_form));
    return;
  }
  XtVaGetValues (w, XmNuserData, &name_list, NULL);

  stdui = eitem->GetUI();
  sq = (d2sQPartOfASet *) eitem->Quality();
  was_colored = eitem->is_colored();

  /* Figure out the set ID according to the new selected item
     in the drop-down list. */
  if (!cbs->item_position || (name_list == NULL)
      || (cbs->item_position > name_list->count))
    {
      if (debug)
	{
	  fprintf (stderr, "%s: Internal error: %s's set\n combo box",
		   progname, eitem->Name());
	  if (!cbs->item_position)
	    fprintf (stderr, " has an item position of 0\n");
	  else if (name_list == NULL)
	    fprintf (stderr, " does not have a name list installed\n");
	  else
	    fprintf (stderr, " has an invalid item position"
		     " (%d, out of %d names)\n",
		     cbs->item_position, name_list->count);
	}
      /* Restore the combo box */
      update_set_name
	(XxNameToWidget (quality_form, "*form_quality_set"), sq);
      return;
    }

  value = name_list->string[cbs->item_position - 1].value >> 3;
  if (value == sq->SetID())
    /* No change required */
    return;

  /* Create a new quality for the set item */
  sq = new d2sQPartOfASet (value, eitem->ItemTableEntry());
  if (sq->GetErrorMessage() != NULL)
    {
      /* Error!  Restore the combo box. */
      update_set_name
	(XxNameToWidget (quality_form, "*form_quality_set"),
	 (d2sQPartOfASet *) eitem->Quality());
      display_error (sq->GetErrorMessage());
      return;
    }
  /* Try the update */
  if (eitem->ChangeQuality (sq) < 0)
    {
      /* Error!  Restore the combo box. */
      delete sq;
      update_set_name
	(XxNameToWidget (quality_form, "*form_quality_set"),
	 (d2sQPartOfASet *) eitem->Quality());
      display_error (eitem->GetErrorMessage());
      return;
    }

  /* Update the set member name and level requirement */
  update_set_name (XxNameToWidget (quality_form, "*form_quality_set"), sq);
  /* Update the item description.
     Update the picture too if the item is or was colored. */
  if (was_colored || eitem->is_colored()) {
    update_item_header ((Widget) eitem->GetUI(), eitem);
    update_item_in_inventory (eitem);
  } else
    update_basic_item_description ((Widget) eitem->GetUI(), eitem);
  /* If the quality is linked to the magic properties,
     update the magic properties frame. */
  if (options.item.link.quality_magic)
    {
      Widget magic_frame = XtNameToWidget
	((Widget) eitem->GetUI(), "*frame_item_magic");
      if (magic_frame != NULL)
	update_magic_property_box (magic_frame, eitem);
    }
}

/* Combine ui_change_rare_name1 and ui_change_rare_name2 */
static void
change_rare_nameX (Widget w, Widget quality_form,
		   XmComboBoxCallbackStruct *cbs,
		   int (d2sRareQuality::*TitleIDX)(void) const,
		   int (d2sRareQuality::*ChangeTitleX)(int))
{
  StringList	name_list = NULL;
  d2sExtendedItem *eitem;
  d2sRareQuality *rq;
  int		value;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  XtVaGetValues (quality_form, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (quality_form));
    return;
  }
  XtVaGetValues (w, XmNuserData, &name_list, NULL);

  stdui = eitem->GetUI();
  rq = (d2sRareQuality *) eitem->Quality();

  /* Figure out the rare name according to the new selected item
     in the drop-down list.  If no item is selected, try reading
     the text field. */
  if (!cbs->item_position || (name_list == NULL)
      || (cbs->item_position > name_list->count))
    {
      if (debug)
	{
	  fprintf (stderr, "%s: Internal error: %s's %s\n combo box",
		   progname, eitem->Name(), XtName (w));
	  if (!cbs->item_position)
	    fprintf (stderr, " has an item position of 0\n");
	  else if (name_list == NULL)
	    fprintf (stderr, " does not have a name list installed\n");
	  else
	    fprintf (stderr, " has an invalid item position"
		     " (%d, out of %d names)\n",
		     cbs->item_position, name_list->count);
	}
      update_rare_name (w, (rq->*TitleIDX)());
      return;
    }

  value = name_list->string[cbs->item_position - 1].value;
  if (value == (rq->*TitleIDX)())
    /* No change required */
    return;

  if ((rq->*ChangeTitleX) (value) < 0)
    {
      /* Error!  Restore the combo box. */
      update_rare_name (w, (rq->*TitleIDX)());
      display_error (rq->GetErrorMessage());
      return;
    }

  /* Update the item description. */
  update_basic_item_description ((Widget) eitem->GetUI(), eitem);
  /* We need to update the inventory to get the side effect
     of updating the button's tooltip string. */
  update_item_in_inventory (eitem);
}

void
ui_change_rare_name1 (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_rare_nameX (w, (Widget) client_data,
		     (XmComboBoxCallbackStruct *) call_data,
		     &d2sRareQuality::TitleID1,
		     &d2sRareQuality::ChangeTitle1);
}

void
ui_change_rare_name2 (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_rare_nameX (w, (Widget) client_data,
		     (XmComboBoxCallbackStruct *) call_data,
		     &d2sRareQuality::TitleID2,
		     &d2sRareQuality::ChangeTitle2);
}

/* Combine ui_change_rare_hidden1 through ui_change_rare_hidden6 */
static void
change_rare_hiddenX (Widget w, Widget quality_form,
		   XmComboBoxCallbackStruct *cbs, int field,
		   const char *widgets_name, const char *xfix_table)
{
  StringList	xfix_list = NULL;
  d2sExtendedItem *eitem;
  d2sRareQuality *rq;
  int		value, was_colored;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  XtVaGetValues (quality_form, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (quality_form));
    return;
  }
  XtVaGetValues (w, XmNuserData, &xfix_list, NULL);

  stdui = eitem->GetUI();
  rq = (d2sRareQuality *) eitem->Quality();
  was_colored = eitem->is_colored();

  /* Figure out the prefix or suffix ID according to
     the new selected item in the drop-down list.
     If no item is selected, try reading the text field. */
  if (!cbs->item_position || (xfix_list == NULL)
      || (cbs->item_position > xfix_list->count))
    {
      if (debug)
	{
	  fprintf (stderr, "%s: Internal error: %s's %s\n combo box",
		   progname, eitem->Name(), widgets_name);
	  if (!cbs->item_position)
	    fprintf (stderr, " has an item position of 0\n");
	  else if (xfix_list == NULL)
	    fprintf (stderr, " does not have a name list installed\n");
	  else
	    fprintf (stderr, " has an invalid item position"
		     " (%d, out of %d names)\n",
		     cbs->item_position, xfix_list->count);
	}
      update_magic_xfix_line (XtParent (w), widgets_name,
			      rq->HiddenFieldID(field), xfix_table);
      return;
    }

  value = xfix_list->string[cbs->item_position - 1].value;
  if (value == rq->HiddenFieldID(field))
    /* No change required */
    return;

  if (rq->ChangeHiddenField (field, value) < 0)
    {
      /* Error!  Restore the combo box. */
      update_magic_xfix_line (XtParent (w), widgets_name,
			      rq->HiddenFieldID(field), xfix_table);
      display_error (rq->GetErrorMessage());
      return;
    }

  /* Update the item description.
     Update the picture too if the item is or was colored. */
  if (was_colored || eitem->is_colored())
    update_item_header ((Widget) eitem->GetUI(), eitem);
  else
    update_basic_item_description ((Widget) eitem->GetUI(), eitem);
  /* We need to update the inventory not just for the item color but
     also to get the side effect of updating the button's tooltip string. */
  update_item_in_inventory (eitem);
  /* Update the rest of this prefix/suffix line (level and color) */
  update_magic_xfix_line (XtParent (w), widgets_name,
			  rq->HiddenFieldID(field), xfix_table);
  /* If the quality is linked to the magic properties,
     update the magic properties frame. */
  if (options.item.link.quality_magic)
    {
      Widget magic_frame = XtNameToWidget
	((Widget) eitem->GetUI(), "*frame_item_magic");
      if (magic_frame != NULL)
	update_magic_property_box (magic_frame, eitem);

      /* If this item is a jewel, and it is attached to another item,
	 the other item's description also needs to be updated. */
      if (eitem->Type() == JEWEL_ITEM)
	{
	  d2sJewelItem *jewel = (d2sJewelItem *) *((d2sItem *) eitem);
	  update_socketed_item (jewel->AttachedTo());
	}
    }
}

void
ui_change_rare_hidden1 (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_rare_hiddenX (w, (Widget) client_data,
		       (XmComboBoxCallbackStruct *) call_data, 0,
		       "rare_hidden1", "magicprefix");
}

void
ui_change_rare_hidden2 (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_rare_hiddenX (w, (Widget) client_data,
		       (XmComboBoxCallbackStruct *) call_data, 1,
		       "rare_hidden2", "magicsuffix");
}

void
ui_change_rare_hidden3 (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_rare_hiddenX (w, (Widget) client_data,
		       (XmComboBoxCallbackStruct *) call_data, 2,
		       "rare_hidden3", "magicprefix");
}

void
ui_change_rare_hidden4 (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_rare_hiddenX (w, (Widget) client_data,
		       (XmComboBoxCallbackStruct *) call_data, 3,
		       "rare_hidden4", "magicsuffix");
}

void
ui_change_rare_hidden5 (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_rare_hiddenX (w, (Widget) client_data,
		       (XmComboBoxCallbackStruct *) call_data, 4,
		       "rare_hidden5", "magicprefix");
}

void
ui_change_rare_hidden6 (Widget w, XtPointer client_data, XtPointer call_data)
{
  change_rare_hiddenX (w, (Widget) client_data,
		       (XmComboBoxCallbackStruct *) call_data, 5,
		       "rare_hidden6", "magicsuffix");
}

/* Change a unique item to another unique item */
void
ui_change_unique_item (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget quality_form = (Widget) client_data;
  XmComboBoxCallbackStruct *cbs = (XmComboBoxCallbackStruct *) call_data;
  StringList	name_list = NULL;
  d2sExtendedItem *eitem;
  d2sUniqueQuality *uq;
  int		value, was_colored;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  XtVaGetValues (quality_form, XmNuserData, &eitem, NULL);
  if (eitem == NULL) {
    /* No item?!  This is bad. */
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (quality_form));
    return;
  }
  XtVaGetValues (w, XmNuserData, &name_list, NULL);

  stdui = eitem->GetUI();
  uq = (d2sUniqueQuality *) eitem->Quality();
  was_colored = eitem->is_colored();

  /* Figure out the set ID according to the new selected item
     in the drop-down list. */
  if (!cbs->item_position || (name_list == NULL)
      || (cbs->item_position > name_list->count))
    {
      if (debug)
	{
	  fprintf (stderr, "%s: Internal error: %s's unique\n combo box",
		   progname, eitem->Name());
	  if (!cbs->item_position)
	    fprintf (stderr, " has an item position of 0\n");
	  else if (name_list == NULL)
	    fprintf (stderr, " does not have a name list installed\n");
	  else
	    fprintf (stderr, " has an invalid item position"
		     " (%d, out of %d names)\n",
		     cbs->item_position, name_list->count);
	}
      /* Restore the combo box */
      update_unique_name
	(XxNameToWidget (quality_form, "*form_quality_unique"),
	 uq->UniqueID());
      return;
    }

  value = name_list->string[cbs->item_position - 1].value;
  if (value == uq->UniqueID())
    /* No change required */
    return;

  /* Create a new quality for the unique item */
  uq = new d2sUniqueQuality (value, eitem->ItemTableEntry());
  if (uq->GetErrorMessage() != NULL)
    {
      /* Error!  Restore the combo box. */
      update_unique_name
	(XxNameToWidget (quality_form, "*form_quality_unique"),
	 ((d2sUniqueQuality *) eitem->Quality())->UniqueID());
      display_error (uq->GetErrorMessage());
      return;
    }
  if (eitem->ChangeQuality (uq) < 0)
    {
      /* Error!  Restore the combo box. */
      update_unique_name
	(XxNameToWidget (quality_form, "*form_quality_unique"),
	 ((d2sUniqueQuality *) eitem->Quality())->UniqueID());
      display_error (eitem->GetErrorMessage());
      return;
    }

  /* Update the level requirement */
  update_unique_name (XxNameToWidget (quality_form, "*form_quality_unique"),
		      uq->UniqueID());
  /* Update the item description.
     Update the picture too if the item is or was colored. */
  if (was_colored || eitem->is_colored())
    update_item_header ((Widget) eitem->GetUI(), eitem);
  else
    update_basic_item_description ((Widget) eitem->GetUI(), eitem);
  update_item_in_inventory (eitem);
  /* If the quality is linked to the magic properties,
     update the magic properties frame. */
  if (options.item.link.quality_magic)
    {
      Widget magic_frame = XtNameToWidget
	((Widget) eitem->GetUI(), "*frame_item_magic");
      if (magic_frame != NULL)
	update_magic_property_box (magic_frame, eitem);
    }
}

/* Change the picture associated with an item such as a ring or amulet */
void
ui_change_picture (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	quality_form = (Widget) client_data;
  d2sCharmItem *citem;
  int		picture_index;

  XtVaGetValues (quality_form, XmNuserData, &citem, NULL);
  if (citem == NULL) {
    fprintf (stderr, "%s: Internal error: form %s does not have\n"
		     " a pointer to the item it describes.\n",
	     progname, XtName (quality_form));
    return;
  }

  stdui = citem->GetUI();
  XtVaGetValues (w, XmNuserData, &picture_index, NULL);
  if (citem->Quality()->ChangePicture (picture_index) < 0)
    {
      display_error (citem->Quality()->GetErrorMessage());
      return;
    }

  /* Update the item's picture */
  update_item_header ((Widget) citem->GetUI(), citem);
  update_item_in_inventory (citem);

  /* If the item is a jewel which is attached to another item,
     its picture may be displayed in the other item's item editor
     in the sockets section.  We need to update that too. */
  if (citem->Type() == JEWEL_ITEM) {
    d2sJewelItem *jewel;
    d2sDurableItem *ditem;
    Widget	attached_window, socket_frame;

    jewel = (d2sJewelItem *) *((d2sItem *) citem);
    ditem = jewel->AttachedTo();
    if ((ditem != NULL) && (ditem->GetUI() != NULL)) {
      attached_window = (Widget) ditem->GetUI();
      if (strcmp (XtName (attached_window), "form_item_popup") == 0)
	update_item_popup (ditem);
      else
	{
	  socket_frame = XxNameToWidget (attached_window,
					 "*frame_socketed_item");
	  update_socketed_item_box (socket_frame, ditem);
	}
    }
  }
}

/* Open an attached gem directly into an item editor window */
void
ui_edit_gem (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sItem	*item;

  XtVaGetValues (w, XmNuserData, &item, NULL);
  if (item == NULL)
    /* No gem here; ignore the button */
    return;

  if (item->GetUI() == NULL)
    open_item_editor_window (item);
  else
    /* The item is already open; raise the window
       so that the user knows it's there */
    XMapRaised (XtDisplay (w), XtWindow (XtParent (item->GetUI())));
}

/* Move a gem through the item's sockets */
void
ui_move_gem_up (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	socket_form = (Widget) client_data;
  d2sDurableItem *ditem;
  d2sAttachItem *gem;
  int		index;

  /* Find the gem */
  XtVaGetValues (socket_form, XmNuserData, &ditem, NULL);
  if (ditem == NULL)
    {
      /* No item?!  This is bad. */
      fprintf (stderr, "%s: Internal error: form %s does not have\n"
	       " a pointer to the item it describes.\n",
	       progname, XtName (socket_form));
      XtSetSensitive (socket_form, False);
      return;
    }
  stdui = ditem->GetUI();
  XtVaGetValues (w, XmNuserData, &index, NULL);
  if (index < 1)
    {
      fprintf (stderr, "%s: Internal error: up arrow on the first row"
	       " was active.\n", progname);
      XtUnmanageChild (w);
      return;
    }
  gem = ditem->Gem(index);
  if (gem == NULL)
    {
      /* No gem at this location?!  This button shouldn't be here. */
      fprintf (stderr, "%s: Internal error: up arrow #%d active"
	       " when no gem is there.\n", progname, index + 1);
      return;
    }

  /* Attempt to move the gem */
  if (ditem->RemoveGem (index) < 0)
    {
      display_error (ditem->GetErrorMessage());
      return;
    }
  if ((ditem->AddGem (gem, index - 1) < 0)
      /* Oops!  This is bad.  Try to put it back... */
      && (ditem->AddGem (gem, index) < 0) && (ditem->AddGem (gem) < 0))
    {
      fprintf (stderr, "%s: Internal error: %s was removed from\n"
	       " socket %d of %s, but can't be put back.\n"
	       " The gem object has been leaked at %p.\n",
	       progname, gem->Name(), index + 1, ditem->Name(), gem);
    }

  /* We need to update the gem box.  If this became the first gem,
     we also need to update the item description (for color). */
  update_socketed_item (ditem);
}

void
ui_move_gem_down (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	socket_form = (Widget) client_data;
  d2sDurableItem *ditem;
  d2sAttachItem *gem;
  int		index;

  /* Find the gem */
  XtVaGetValues (socket_form, XmNuserData, &ditem, NULL);
  if (ditem == NULL)
    {
      /* No item?!  This is bad. */
      fprintf (stderr, "%s: Internal error: form %s does not have\n"
	       " a pointer to the item it describes.\n",
	       progname, XtName (socket_form));
      XtSetSensitive (socket_form, False);
      return;
    }
  stdui = ditem->GetUI();
  XtVaGetValues (w, XmNuserData, &index, NULL);
  if (index >= ditem->ModNumberOfSockets() - 1)
    {
      fprintf (stderr, "%s: Internal error: down arrow on the last row"
	       " was active.\n", progname);
      XtUnmanageChild (w);
      return;
    }
  gem = ditem->Gem(index);
  if (gem == NULL)
    {
      /* No gem at this location?!  This button shouldn't be here. */
      fprintf (stderr, "%s: Internal error: down arrow #%d active"
	       " when no gem is there.\n", progname, index + 1);
      return;
    }

  /* Attempt to move the gem */
  if (ditem->RemoveGem (index) < 0)
    {
      display_error (ditem->GetErrorMessage());
      return;
    }
  if ((ditem->AddGem (gem, index + 1) < 0)
      /* Oops!  This is bad.  Try to put it back... */
      && (ditem->AddGem (gem, index) < 0) && (ditem->AddGem (gem) < 0))
    {
      fprintf (stderr, "%s: Internal error: %s was removed from\n"
	       " socket %d of %s, but can't be put back.\n"
	       " The gem object has been leaked at %p.\n",
	       progname, gem->Name(), index + 1, ditem->Name(), gem);
    }

  /* We need to update the gem box.  If this was the first gem,
     we also need to update the item description (for color). */
  update_socketed_item (ditem);
}

/* Update an item when gems are added to or removed from it. */
void
update_socketed_item (d2sDurableItem *item)
{
  Widget	item_window, gem_box;
  Cardinal	num_children;

  if (item == NULL)
    return;
  if (item->Owner() != NULL)
    update_item_in_inventory (item);
  item_window = (Widget) item->GetUI();
  if (item_window != NULL)
    {
      if (strcmp (XtName (item_window), "form_item_popup") == 0)
	update_item_popup (item);
      else
	{
	  update_item_header (item_window, item);
	  /* Update the gem box */
	  gem_box = XxNameToWidget (item_window, "*frame_socketed_item");
	  update_socketed_item_box (gem_box, item);

	  /* Rune Words can affect an item's magic properties,
	     so update the properties box as well. */
	  gem_box = XxNameToWidget (item_window, "*frame_item_magic");
	  XtVaGetValues (XxNameToWidget (gem_box, "*table_item_magic"),
			 XmNnumChildren, &num_children,
			 NULL);
	  if ((int) num_children - 1
	      != item->Properties()->NumberOfProperties())
	    update_magic_property_box (gem_box, item);
	}
    }
}

/* Change the number of sockets in an item */
void
ui_item_add_socket (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	socket_form = (Widget) client_data;
  d2sDurableItem *ditem;

  XtVaGetValues (socket_form, XmNuserData, &ditem, NULL);
  if (ditem == NULL)
    {
      /* No item?!  This is bad. */
      fprintf (stderr, "%s: Internal error: form %s does not have\n"
	       " a pointer to the item it describes.\n",
	       progname, XtName (socket_form));
      XtSetSensitive (socket_form, False);
      return;
    }

  stdui = ditem->GetUI();

  /* Attempt to add a socket */
  if (ditem->SetNumberOfSockets (ditem->NumberOfSockets() + 1) < 0)
    {
      display_error (ditem->GetErrorMessage());
      return;
    }

  /* Update the gem box and the item description */
  update_socketed_item (ditem);
}

void
ui_item_remove_socket (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	socket_form = (Widget) client_data;
  d2sDurableItem *ditem;
  d2sAttachItem *gem;

  XtVaGetValues (socket_form, XmNuserData, &ditem, NULL);
  if (ditem == NULL)
    {
      /* No item?!  This is bad. */
      fprintf (stderr, "%s: Internal error: form %s does not have\n"
	       " a pointer to the item it describes.\n",
	       progname, XtName (socket_form));
      XtSetSensitive (socket_form, False);
      return;
    }

  stdui = ditem->GetUI();

  /* Is this going to remove an existing gem?  If so, it may leave
     the gem dangling outside of the character's inventory.  In
     that case, we should preserve the gem in an item window. */
  gem = ditem->Gem (ditem->ModNumberOfSockets() - 1);

  /* Attempt to remove the last socket */
  if (ditem->SetNumberOfSockets (ditem->NumberOfSockets() - 1) < 0)
    {
      display_error (ditem->GetErrorMessage());
      return;
    }
  if ((gem != NULL) && (gem->AttachedTo() == NULL) && (gem->GetUI() == NULL))
    /* Show the stray gem */
    open_item_editor_window (gem);

  /* Update the gem box and the item description */
  update_socketed_item (ditem);
}

void
ui_change_property_value (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	parent = XtParent (w);
  d2sExtendedItem *eitem;
  d2sMagicProperty *prop;
  int		field;
  char		*value, *old_value;

  /* The property pointer is stored
     in the userData field of the widget's row */
  XtVaGetValues ((Widget) client_data, XmNuserData, &prop, NULL);
  if (prop == NULL)
    return;
  /* The field number is conveniently stored
     in the userData field of the parent form */
  XtVaGetValues (parent, XmNuserData, &field, NULL);
  /* The item is referenced through the property list */
  eitem = (d2sExtendedItem *) *(prop->ParentList()->Item());
  /* That in turn gives us the item editor window */
  stdui = eitem->GetUI();

  /* Read the requested field value */
  value = XmTextFieldGetString (w);

  old_value = prop->FieldValue (field);
  if (!value[0])
    {
      /* The user has apparently deleted the value.  Put it back. */
      XmTextFieldSetString (w, old_value);
      XtFree (old_value);
      XtFree (value);
      return;
    }

  /* Avoid unnecessary updates if the value has not changed */
  if (strcmp (value, old_value) == 0)
    {
      XtFree (old_value);
      XtFree (value);
      return;
    }


  /* Attempt to change the property */
  if (prop->SetFieldValue (field, value) < 0)
    {
      /* Error!  Restore the original value. */
      XtFree (value);
      value = prop->FieldValue (field);
      XmTextFieldSetString (w, value);
      display_error (prop->GetErrorMessage());
      XtFree (value);
      return;
    }

  /* Update the item description box */
  update_basic_item_description ((Widget) eitem->GetUI(), eitem);

  /* If this item is a jewel, and it is attached to another item,
     the other item's description also needs to be updated. */
  if (eitem->Type() == JEWEL_ITEM)
    {
      d2sJewelItem *jewel = (d2sJewelItem *) *((d2sItem *) eitem);
      update_socketed_item (jewel->AttachedTo());
    }

  /* If this property is "sock", update the gem box */
  if (*prop == "sock" && ((eitem->Type() == ARMOR_ITEM)
			  || (eitem->Type() == WEAPON_ITEM)))
    {
      d2sDurableItem *ditem = (d2sDurableItem *) *((d2sItem *) eitem);
      if (ditem->MaximumNumberOfSockets())
	update_max_number_of_sockets (ditem);
    }

  XtFree (value);
  return;
}

void
ui_select_property_value (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	parent = XtParent (w);
  XmComboBoxCallbackStruct *cbs = (XmComboBoxCallbackStruct *) call_data;
  d2sExtendedItem *eitem;
  d2sMagicProperty *prop;
  int		field, new_data;
  char		*field_value;
  StringList	name_list;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  /* The property pointer is stored
     in the userData field of the widget's row */
  XtVaGetValues ((Widget) client_data, XmNuserData, &prop, NULL);
  if (prop == NULL)
    return;
  /* The field number is conveniently stored
     in the userData field of the parent form */
  XtVaGetValues (parent, XmNuserData, &field, NULL);
  /* The item is referenced through the property list */
  eitem = (d2sExtendedItem *) *(prop->ParentList()->Item());
  /* That in turn gives us the item editor window */
  stdui = eitem->GetUI();

  /* Get the requested value from the drop-down's string list */
  XtVaGetValues (w, XmNuserData, &name_list, NULL);
  if (!cbs->item_position || (name_list == NULL)
      || (cbs->item_position > name_list->count))
    {
      if (debug)
	{
	  fprintf (stderr, "%s: Internal error: %s's %s\n combo box",
		   progname, eitem->Name(), prop->Description());
	  if (!cbs->item_position)
	    fprintf (stderr, " has an item position of 0\n");
	  else if (name_list == NULL)
	    fprintf (stderr, " does not have a name list installed\n");
	  else
	    fprintf (stderr, " has an invalid item position"
		     " (%d, out of %d names)\n",
		     cbs->item_position, name_list->count);
	}
      /* Restore the combo box' position */
      field_value = prop->FieldValue (field);
      update_named_combo_box (w, prop->FieldData (field), field_value);
      free (field_value);
      return;
    }

  new_data = name_list->string[cbs->item_position - 1].value;
  if (new_data == prop->FieldData (field))
    /* No change required */
    return;

  if (prop->SetFieldData (field, new_data) < 0)
    {
      /* Error!  Restore the combo box. */
      field_value = prop->FieldValue (field);
      update_named_combo_box (w, prop->FieldData (field), field_value);
      free (field_value);
      display_error (prop->GetErrorMessage());
      return;
    }

  /* Update the item description. */
  update_basic_item_description ((Widget) eitem->GetUI(), eitem);
}

void
ui_delete_magic_property (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sExtendedItem *eitem;
  d2sMagic	*list;
  d2sMagicProperty *prop;
  Widget	table, combo;
  WidgetList	children;
  Cardinal	num_children;
  int		expansion, was_sock;
  const char	*cstr;
  StringList	new_prop_list;

  /* The property pointer is conveniently stored
     in the userData field of the calling widget */
  XtVaGetValues (w, XmNuserData, &prop, NULL);
  if (prop == NULL)
    return;
  /* The item is referenced through the property list */
  list = prop->ParentList();
  eitem = (d2sExtendedItem *) *(list->Item());
  /* That in turn gives us the item editor window */
  stdui = eitem->GetUI();

  was_sock = (*prop == "sock");

  /* Attempt to remove the property */
  if (list->RemoveProperty (prop) < 0)
    {
      /* Error! */
      display_error (list->GetErrorMessage());
      return;
    }

  /* Remove this property's row from the table */
  table = XtParent (XtParent (w));
  XtVaGetValues (table,
		 XmNchildren, &children,
		 XmNnumChildren, &num_children,
		 NULL);
  XtUnmanageChild (XtParent (w));
  if (num_children > 2) {
    /* If we are deleting the first row,
       disable the up arrow on the next row. */
    if (XtParent (w) == children[0])
      XtUnmanageChild (XxNameToWidget (children[1], "*arrow_property_up"));
    /* If we are deleting the last row,
       disable the down arrow on the previous row. */
    if (XtParent (w) == children[num_children - 2])
      XtUnmanageChild (XxNameToWidget (children[num_children - 3],
				       "*arrow_property_down"));
  }
  XtDestroyWidget (XtParent (w));

  /* Update the list of properties available for adding */
  combo = XxNameToWidget (table, "*combo_new_properties");
  expansion = (options.item.link.item_expansion
	       || (eitem->Owner() == NULL)
	       || (eitem->Owner()->is_expansion()));
  cstr = (options.character.link.freeform ? ""
	  : GetEntryStringField (eitem->TypeTableEntry(), "Class"));
  new_prop_list = GetMagicPropertyNamesExcept (list, expansion, cstr);
  install_names_in_dropdown_list (combo, new_prop_list);

  /* Update the item description */
  update_basic_item_description ((Widget) eitem->GetUI(), eitem);

  /* If this item is a jewel, and it is attached to another item,
     the other item's description also needs to be updated. */
  if (eitem->Type() == JEWEL_ITEM)
    {
      d2sJewelItem *jewel = (d2sJewelItem *) *((d2sItem *) eitem);
      update_socketed_item (jewel->AttachedTo());
    }

  /* If this property was "sock", update the gem box */
  if (was_sock && ((eitem->Type() == ARMOR_ITEM)
		   || (eitem->Type() == WEAPON_ITEM)))
    {
      d2sDurableItem *ditem = (d2sDurableItem *) *((d2sItem *) eitem);
      if (ditem->MaximumNumberOfSockets())
	update_max_number_of_sockets (ditem);
    }
}

static void
ui_add_magic_property (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	magic_frame = (Widget) client_data;
  Widget	combo_box;
  d2sExtendedItem *eitem;
  d2sMagicProperty *property;
  Widget	table;
  WidgetList	children;
  Cardinal	num_children;
  int		index, id, expansion;
  const char	*cstr;
  StringList	names;

  XtVaGetValues (magic_frame, XmNuserData, &eitem, NULL);
  stdui = eitem->GetUI();

  /* Get the currently selected magic property */
  combo_box = XxNameToWidget (XtParent (w), "*combo_new_properties");
  XtVaGetValues (combo_box,
		 XmNselectedPosition, &index,
		 XmNuserData, &names,
		 NULL);
  if (index < 1)
    /* Nothing is selected; ignore the action */
    return;
  if ((names == NULL) || (index > names->count))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: selected position of %s (%d)"
		 " is out of range (%d names)\n",
		 progname, XtName (combo_box), index, names->count);
      return;
    }
  id = names->string[index - 1].value;

  /* Create the new property */
  property = new d2sMagicProperty (id);
  if (property->GetErrorMessage() != NULL)
    {
      display_error (property->GetErrorMessage());
      delete property;
      return;
    }

  /* Add the property to the list */
  if (eitem->Properties()->AddProperty (property) < 0)
    {
      display_error (eitem->Properties()->GetErrorMessage());
      delete property;
      return;
    }

  /* Append a new row to the properties table */
  table = XtParent (XtParent (w));
  XtVaGetValues (table,
		 XmNchildren, &children,
		 XmNnumChildren, &num_children,
		 NULL);
  /* Don't count the last row ("Add Property") */
  num_children--;
  /* Enable the down arrow on the previously last item */
  if (num_children)
    XtManageChild (XxNameToWidget (children[num_children - 1],
				   "*arrow_property_down"));
  insert_magic_property_row (table, property, num_children);

  /* Update the list of remaining properties */
  expansion = (options.item.link.item_expansion
	       || (eitem->Owner() == NULL)
	       || (eitem->Owner()->is_expansion()));
  cstr = (options.character.link.freeform ? ""
	  : GetEntryStringField (eitem->TypeTableEntry(), "Class"));
  names = GetMagicPropertyNamesExcept
    (eitem->Properties(), expansion, cstr);
  install_names_in_dropdown_list (combo_box, names);

  /* Update the item description */
  update_basic_item_description ((Widget) eitem->GetUI(), eitem);

  /* If this item is a jewel, and it is attached to another item,
     the other item's description also needs to be updated. */
  if (eitem->Type() == JEWEL_ITEM)
    {
      d2sJewelItem *jewel = (d2sJewelItem *) *((d2sItem *) eitem);
      update_socketed_item (jewel->AttachedTo());
    }

  /* If this property is "sock", update the gem box */
  if ((*property == "sock") && ((eitem->Type() == ARMOR_ITEM)
				|| (eitem->Type() == WEAPON_ITEM)))
    {
      d2sDurableItem *ditem = (d2sDurableItem *) *((d2sItem *) eitem);
      if (ditem->MaximumNumberOfSockets())
	update_max_number_of_sockets (ditem);
    }
}

static void
ui_move_magic_property (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sExtendedItem *eitem;
  d2sMagic	*list;
  d2sMagicProperty *property;
  short		index, new_index;
  unsigned char direction;
  Widget	table;
  WidgetList	children;
  Cardinal	num_children;

  /* Get the direction of the move */
  XtVaGetValues (w, XmNarrowDirection, &direction, NULL);
  /* The property pointer and index is stored in the parent form */
  XtVaGetValues (XtParent (w),
		 XmNpositionIndex, &index,
		 XmNuserData, &property,
		 NULL);
  new_index = (direction == XmARROW_UP) ? (index - 1) : (index + 1);
  /* The item is referenced through the property list */
  list = property->ParentList();
  eitem = (d2sExtendedItem *) *(list->Item());
  /* That in turn gives us the item editor window */
  stdui = eitem->GetUI();

  /* Attempt to move the property */
  if (list->MoveProperty (property, new_index) < 0)
    {
      /* Error! */
      display_error (list->GetErrorMessage());
      return;
    }

  /* Update the list of properties */
  XtVaSetValues (XtParent (w), XmNpositionIndex, new_index, NULL);
  table = XtParent (XtParent (w));
  XtVaGetValues (table,
		 XmNchildren, &children,
		 XmNnumChildren, &num_children,
		 NULL);
  /* Don't count the last row ("Add Property") */
  num_children--;

  if (!index) {
    /* Enable the up arrow */
    XtManageChild (XxNameToWidget (XtParent (w), "*arrow_property_up"));
    /* Disable the up arrow on the row that was swapped up */
    XtUnmanageChild (XxNameToWidget (children[index], "*arrow_property_up"));
  }
  else if (!new_index) {
    /* Disable the up arrow */
    XtUnmanageChild (XxNameToWidget (XtParent (w), "*arrow_property_up"));
    /* Enable the up arrow on the row that was swapped down */
    XtManageChild (XxNameToWidget (children[index], "*arrow_property_up"));
  }

  if (index == (int) num_children - 1) {
    /* Enable the down arrow */
    XtManageChild (XxNameToWidget (XtParent (w), "*arrow_property_down"));
    /* Disable the up arrow on the row that was swapped up */
    XtUnmanageChild (XxNameToWidget (children[index], "*arrow_property_down"));
  }
  else if (new_index == (int) num_children - 1) {
    /* Disable the down arrow */
    XtUnmanageChild (XxNameToWidget (XtParent (w), "*arrow_property_down"));
    /* Enable the up arrow on the row that was swapped up */
    XtManageChild (XxNameToWidget (children[index], "*arrow_property_down"));
  }
}


void
ui_item_duplicate (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  d2sItem *	item, *duped_item;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      /* No item in this window.  This menu option shouldn't be enabled. */
      XtSetSensitive (w, False);
      return;
    }

  /* Duplicate the item */
  duped_item = item->Copy();
  if (duped_item == NULL)
    {
      display_error (item->GetErrorMessage());
      return;
    }

  /* Open a new editor window for the duplicate item */
  if (open_item_editor_window (duped_item) == NULL)
    {
      display_error ("I can't open an editor window for the duplicate %s",
		     duped_item->Name());
      delete duped_item;
      return;
    }
}


void
ui_item_close (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	window = (Widget) client_data;
  d2sItem *	item;

  stdui = window;

  XtVaGetValues (window, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      /* Behave as with a window close */
      ui_window_close (w, client_data, call_data);
      return;
    }

  /* If the item belongs to a character, we won't bother
     asking whether to save it.  But if it's a stand-alone,
     check whether it needs to be saved. */
  if ((item->Owner() == NULL) && item->needs_saving ())
    {
      int answer;

      if (item->SourceFileName () == NULL)
	/* This should probably be a 3-way question;
	   Save, Throw Away, or Cancel */
	answer = display_question
	  (1, 3, "Cancel", "Save As...", "Discard",
	   "Do you wish to save your %s?", item->Name());
      else
	/* This should probably be a 4-way question:
	   Save, Save As, Throw Away, or Cancel */
	answer = display_question
	  (1, 4, "Cancel", "Save", "Save As...", "Discard",
	   "%s has been modified.  Do you wish to save it?",
	   item->SourceFileName ());
      if (!answer)
	/* Cancelled */
	return;
      if ((item->SourceFileName () != NULL) && (answer == 1))
	{
	  ui_item_save (w, client_data, call_data);
	  /* We should find out whether "Save" succeeded
	     or was cancelled before proceeding to close the window. */
	  if (item->needs_saving ())
	    return;
	}
      if ((item->SourceFileName () != NULL)
	  ? (answer == 2) : (answer == 1))
	{
	  ui_item_save_as (w, client_data, call_data);
	  /* We should find out whether "Save As" succeeded
	     or was cancelled before proceeding to close the window. */
	  if (item->needs_saving ())
	    return;
	}
    }

  XtVaSetValues (window, XmNuserData, NULL, NULL);
  item->SetUI (NULL);
  /* Free the item object IFF it doesn't belong to anyone */
  if (item->Owner() == NULL)
    delete item;

  /* Now that the item is closed, close the item window */
  ui_item_window_close (w, client_data, call_data);
}

/* Close an item window when we're done with it. */
void
ui_item_window_close (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	window = (Widget) client_data;
  Widget	docshell = XtParent (window);
  d2sItem	*item;
  int		i;
  static int	recursive = 0;

  /* Prevent recursive calls (i.e., exiting while the user should be
     confirming file saves for a previous exit request). */
  if (recursive++)
    {
      recursive--;
      return;
    }

  /* If a file is open in this window, close it. */
  XtVaGetValues (window, XmNuserData, &item, NULL);
  if (item != NULL)
    {
      ui_item_close (w, client_data, call_data);
      /* FALLTHROUGH: ui_item_close calls us, but since that's a
	 recursive call, we don't allow it.  Instead, when that
	 function returns, we'll continue from here.  Before
	 proceeding, make sure the item has been closed. */
      XtVaGetValues (window, XmNuserData, &item, NULL);
      if (item != NULL)
	{
	  recursive--;
	  return;
	}
    }

  /* Find this shell in our document shell list, and remove it. */
  for (i = 0; i < item_doc_shell_count; i++)
    {
      if (docshell == item_doc_shell_list[i])
	{
	  if (i + 1 < item_doc_shell_count)
	    memmove (&item_doc_shell_list[i], &item_doc_shell_list[i + 1],
		     (item_doc_shell_count - (i + 1)) * sizeof (Widget));
	  item_doc_shell_count--;
	  break;
	}
    }

  /* Destroy the window */
  XtDestroyWidget (XtParent (window));
  stdui = NULL;
  recursive--;
}

/* This function is called after the fact -- when windows are being
   closed systematically by closing a character. */
static void
ui_item_window_destroyed (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	window = (Widget) client_data;
  Pixmap	old_picture;
  Widget	picture_frame;
  int		i;
  char		make_name[64];

  /* Be sure to tidy up after ourself. */
  XtVaGetValues (XxNameToWidget (window, "*picture_item"),
		 XmNlabelPixmap, &old_picture,
		 NULL);
  /* This decrements the reference count to the item's
     picture in Motif's Pixmap cache.  The pixmap is
     destroyed when no more widgets are using it. */
  if (old_picture != XmUNSPECIFIED_PIXMAP)
    XmDestroyPixmap (XtScreen (window), old_picture);

  /* Also release pictures of any attached gems */
  picture_frame = XtNameToWidget (window, "*frame_socketed_item");
  if (picture_frame != NULL)
    for (i = 1; i <= MAX_DISPLAYED_SOCKETS; i++)
      {
	sprintf (make_name, "*form_socket%d*button_socket%d", i, i);
	XtVaGetValues (XxNameToWidget (picture_frame, make_name),
		       XmNlabelPixmap, &old_picture,
		       NULL);
	if ((old_picture != XmUNSPECIFIED_PIXMAP)
	    && (old_picture != gem_socket_icon))
	  XmDestroyPixmap (XtScreen (picture_frame), old_picture);
      }
}
