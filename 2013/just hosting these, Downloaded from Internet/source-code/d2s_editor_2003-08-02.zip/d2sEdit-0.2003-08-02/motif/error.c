/* error.c -- display an error message using the interface.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <Xm/MessageB.h>
#include <Xm/PushB.h>
#include <Xm/Text.h>
#include "ui.h"
#include "util.h"
#include <dmalloc.h>

/* Forward references */
static void answer_callback (Widget, XtPointer, XtPointer);
static void format_message (Widget, const char *fmt, va_list args);

/* Display a non-fatal error, warning, or information and return.
   Don't interrupt the program flow. */
void
print_message (const char *fmt, ...)
{
  va_list ap;
  int total_length;
  char *message;
  Widget message_box = NULL;
  XmTextPosition cursor;

  /* Get the size of the message */
  va_start (ap, fmt);
  total_length = vsnprintf (NULL, 0, fmt, ap);
  va_end (ap);

  /* For non-standard libraries, assume a default length limit. */
  if (total_length <= 1)
    total_length = 2048;
  message = XtMalloc (total_length + 2);

  /* Format the message */
  va_start (ap, fmt);
  total_length = vsnprintf (message, total_length + 1, fmt, ap);
  /* Make sure the line ends with NL */
  while (isspace (message[total_length - 1]))
    --total_length;
  message[total_length++] = '\n';
  message[total_length] = '\0';

  /* Append the message to the end of the message box, if we have one.
     If not, write the message to stderr, with an appropriate header. */
  if (stdui != NULL)
    message_box = XtNameToWidget ((Widget) stdui, "*game_data");
  if (message_box == NULL) {
    /* For messages, we don't default to the top-level window, because
       (presumably) the message is document-specific.  It would be
       confusing to display it in the window of a different document. */
    fprintf (stderr, "%s: ", progname);
    if (stdui != NULL) {
      XmString xm_title = NULL;
      char *title = NULL;
      XtVaGetValues ((Widget) stdui, XmNdialogTitle, &xm_title, NULL);
      if (xm_title != NULL) {
	if (XmStringGetLtoR (xm_title, XmSTRING_DEFAULT_CHARSET, &title)) {
	  fprintf (stderr, "(%s) ", XtName ((Widget) stdui));
	  XtFree (title);
	}
	XmStringFree (xm_title);
      }
    }
    fputs (message, stderr);
    return;
  }

  /* Make sure the end of the last message is visible,
     then append the new message. */
  cursor = XmTextGetLastPosition (message_box);
  XmTextShowPosition (message_box, cursor);
  XmTextInsert (message_box, cursor, message);
}

/* Display a non-fatal error message and
   wait for the user before returning */
void
display_error (const char *fmt, ...)
{
  va_list ap;
  int response;
  Widget dialog, ui_window = (Widget) stdui;
  XmString title;
  Arg args[6];
  static int recursive_error = 0;

  if (recursive_error)
    return;

  if (ui_window == NULL) {
    ui_window = toplevel;
    if (ui_window == NULL) {
      /* There is no window open yet!  Write the error to stderr. */
      va_start (ap, fmt);
      vfprintf (stderr, fmt, ap);
      va_end (ap);
      /* Pause */
      fputs ("\n(Press <Enter> to continue)", stderr);
      fflush (stdout);
      do { response = getchar(); } while (response != '\n');
      return;
    }
  }

  /* Create the error dialog box */
  XtSetArg (args[0], XmNautoUnmanage, False);
  XtSetArg (args[1], XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL);
  title = XmStringCreateLocalized ("Error!");
  XtSetArg (args[2], XmNdialogTitle, title);
  XtSetArg (args[3], XmNmessageAlignment, XmALIGNMENT_BEGINNING);
  XtSetArg (args[4], XmNnoResize, True);
  dialog = XmCreateErrorDialog (ui_window, "Error", args, 5);
  XmStringFree (title);
  XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON));
  XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));
  /* Add a callback for the button. */
  XtAddCallback (dialog, XmNokCallback, answer_callback, &response);

  /* Print the error message to the message box */
  va_start (ap, fmt);
  format_message (dialog, fmt, ap);
  va_end (ap);

  /* Pop up the box */
  XtManageChild (dialog);
  XtPopup (XtParent (dialog), XtGrabNone);

  /* Don't return to the caller until the user acknowledges the error.
     Simulate the AppMainLoop by processing one event at a time
     until we receive an answer. */
  response = -1;
  recursive_error++;
  while (response < 0)
    XtAppProcessEvent (app_context, XtIMAll);
  --recursive_error;

  /* Remove the error box */
  XtPopdown (XtParent (dialog));
  XtDestroyWidget (XtParent (dialog));
  XmUpdateDisplay (ui_window);
}

/* Display a question and wait for the user's response.
   Return the index of the answer.
   You should set the first answer (0) to "No"/"Cancel"
   and the second (1) to "Yes"/"OK". */
int
display_question (int default_answer, int num_answers, ...)
{
  va_list ap;
  const char *fmt;
  char *message;
  char button_name[16];
  Widget dialog, button, ui_window = (Widget) stdui;
  int i, button_num, answer = -1;
  Arg args[8];
  XmString title, ok_xmstr, cancel_xmstr;

  if (ui_window == NULL)
    ui_window = toplevel;

  /* Create the question dialog box */
  XtSetArg (args[0], XmNautoUnmanage, False);
  XtSetArg (args[1], XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL);
  title = XmStringCreateLocalized ("Question:");
  XtSetArg (args[2], XmNdialogTitle, title);
  XtSetArg (args[3], XmNmessageAlignment, XmALIGNMENT_BEGINNING);
  XtSetArg (args[4], XmNnoResize, True);
  i = 5;
  /* Customize the buttons */
  va_start (ap, num_answers);
  if (num_answers)
    {
      message = va_arg (ap, char *);
      cancel_xmstr = XmStringCreateLocalized (message);
      XtSetArg (args[i], XmNcancelLabelString, cancel_xmstr);
      i++;
      if (num_answers > 1)
	{
	  message = va_arg (ap, char *);
	  ok_xmstr = XmStringCreateLocalized (message);
	  XtSetArg (args[i], XmNokLabelString, ok_xmstr);
	  i++;
	}
    }
  XtSetArg (args[i], XmNdefaultButtonType,
	    (default_answer == 0) ? XmDIALOG_CANCEL_BUTTON
	    : ((default_answer == 1) ? XmDIALOG_OK_BUTTON : XmDIALOG_NONE));
  i++;
  dialog = XmCreateQuestionDialog (ui_window, "Question", args, i);
  if (num_answers)
    {
      XmStringFree (cancel_xmstr);
      num_answers--;
      if (num_answers)
	{
	  XmStringFree (ok_xmstr);
	  num_answers--;
	}
    }
  XmStringFree (title);
  /* We should probably provide help, but I'm not sure
     how to implement it yet. */
  XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));
  /* Add a callback for both buttons, in order to set the answer. */
  XtAddCallback (dialog, XmNokCallback, answer_callback, &answer);
  XtAddCallback (dialog, XmNcancelCallback, answer_callback, &answer);
  button_num = 2;
  while (num_answers)
    {
      /* Add another button for each answer the caller can handle */
      message = va_arg (ap, char *);
      ok_xmstr = XmStringCreateLocalized (message);
      snprintf (button_name, sizeof (button_name), "button%d", button_num);
      XtSetArg (args[0], XmNlabelString, ok_xmstr);
      XtSetArg (args[1], XmNuserData, button_num);
      i = 2;
      if (button_num == default_answer)
	{
	  XtSetArg (args[i], XmNshowAsDefault, 1);
	  i++;
	}
      button = XmCreatePushButton (dialog, button_name, args, i);
      XtAddCallback (button, XmNactivateCallback, answer_callback, &answer);
      XmStringFree (ok_xmstr);
      XtManageChild (button);
      button_num++;
      num_answers--;
    }

  /* Print the question to the message box */
  fmt = va_arg (ap, char *);
  format_message (dialog, fmt, ap);
  va_end (ap);

  /* Pop the question */
  XtManageChild (dialog);
  XtPopup (XtParent (dialog), XtGrabNone);

  /* We don't want to return without an answer.
     So we simulate the AppMainLoop by processing one event at a time
     until we receive an answer. */
  while (answer < 0)
    XtAppProcessEvent (app_context, XtIMAll);

  /* Remove the question */
  XtPopdown (XtParent (dialog));
  XtDestroyWidget (XtParent (dialog));
  XmUpdateDisplay (ui_window);

  return answer;
}

static void
answer_callback (Widget w, XtPointer client_data, XtPointer call_data)
{
  int *answerp = (int *) client_data;
  XmAnyCallbackStruct *cbs = (XmAnyCallbackStruct *) call_data;
  XtPointer user_data;

  switch (cbs->reason) {
  case XmCR_CANCEL: *answerp = 0; return;
  case XmCR_OK: *answerp = 1; return;
  case XmCR_ACTIVATE:
    XtVaGetValues (w, XmNuserData, &user_data, NULL);
    *answerp = (int) user_data;
    return;
  }
}

/* Find a whitespace character near the given position.
   This will fudge so that it looks both left and right,
   but preference is given to the left side. */
static int
find_nearest_whitespace (const char *str, int begin)
{
  int leftpos, rightpos;

  /* Look left */
  for (leftpos = begin - 1; leftpos >= 0; leftpos--)
    {
      if (isspace (str[leftpos]))
	break;
    }
  /* Look right */
  for (rightpos = begin; str[rightpos]; rightpos++)
    {
      if (isspace (str[rightpos]))
	break;
    }
  /* For the right direction, skip multiple consecutive whitespace. */
  while (str[rightpos] && isspace (str[rightpos + 1]))
    rightpos++;

  /* If the right distance is less than half the left distance
     and less than 10 characters, or the left position is < 0,
     go to the right. */
  if ((leftpos < 0) || (rightpos - begin < (begin - leftpos) / 2))
    return rightpos;
  else
    return leftpos;
}

/* Count the number of lines in a message.
   Also return the length of the longest line. */
static int
count_lines (const char *msg, int *pmax_width)
{
  int i, line_count, line_length, max_length;

  line_count = 0;
  line_length = 0;
  max_length = 0;
  for (i = 0; msg[i]; i++)
    {
      if (msg[i] != '\n')
	{
	  line_length++;
	  continue;
	}

      if (line_length > max_length)
	max_length = line_length;
      line_count++;
      line_length = 0;
    }

  /* One last check */
  if (line_length > max_length)
    max_length = line_length;
  line_count++;

  *pmax_width = max_length;
  return line_count;
}

/* Remove all newlines from a message */
static inline void
remove_newlines (char *msg)
{
  int i;

  for (i = 0; msg[i]; i++)
    {
      if (msg[i] == '\n')
	msg[i] = ' ';
    }
}

/* Reformat a message to fit more prettily in a dialog box.
   We allow a message to be about 20 characters wide for a 1-liner,
   40 characters per line for a 2-liner, 60 per line for 3 lines,
   and 80 characters per line for anything longer. */
static void
format_message (Widget dialog, const char *fmt, va_list ap)
{
  int i, num_lines, longest_line, total_length;
  va_list copy_ap = ap;
  char *message, *strp;
  XmString xmstr;

  /* Get the size of the message */
  total_length = vsnprintf (NULL, 0, fmt, ap);
  /* For non-standard libraries, assume a default length limit. */
  if (total_length <= 1)
    total_length = 2048;
  message = XtMalloc (total_length + 1);
  /* Format the message */
  ap = copy_ap;
  total_length = vsnprintf (message, total_length + 1, fmt, ap);
  /* Remove any trailing whitespace */
  while (isspace (message[total_length - 1]))
    message[--total_length] = '\0';

  /* Get a current count of the number of lines and the longest line */
  num_lines = count_lines (message, &longest_line);
  if (longest_line > ((num_lines >= 4) ? 80 : (num_lines * 20 + 5)))
    {
      /* Remove the existing newlines */
      remove_newlines (message);

      /* Attempt to reinsert newlines at better locations */
      if (total_length > 3 * 60)
	num_lines = total_length / 75;
      else if (total_length > 2 * 40)
	num_lines = 3;
      else if (total_length > 1 * 20)
	num_lines = 2;
      else
	num_lines = 1;
      longest_line = total_length / num_lines + 1;;
      strp = message;
      while (strlen (strp) > longest_line)
	{
	  i = find_nearest_whitespace (strp, longest_line);
	  if (!isspace (strp[i]))
	    break;
	  strp[i] = '\n';
	  strp += i + 1;
	  /* Recompute the longest line allowed
	     based on the length of the remaining lines */
	  num_lines--;
	  longest_line = (total_length - (strp - message)) / num_lines + 1;
	}

      /* Recompute the number of lines and maximum width */
      num_lines = count_lines (message, &longest_line);
      if (longest_line > ((num_lines >= 4) ? 80 : (num_lines * 20 + 5)))
	{
	  /* In this unlikely event, it appears that there is an
	     unbreakable word that is longer than our ideal line
	     length.  So use the shorter of that word's length
	     or 75 characters as our maximum length, and try once more. */
	  remove_newlines (message);

	  if (longest_line > 75)
	    longest_line = 75;
	  strp = message;
	  while (strlen (strp) > longest_line)
	    {
	      i = find_nearest_whitespace (strp, longest_line);
	      if (!isspace (strp[i]))
		break;
	      strp[i] = '\n';
	      strp += i + 1;
	    }
	}
    }

  /* Now that the message is formatted, convert it to a compound string
     and place it in the message box. */
  xmstr = XmStringCreateLocalized (message);
  XtVaSetValues (dialog, XmNmessageString, xmstr, NULL);
  XmStringFree (xmstr);
  XtFree (message);
}
