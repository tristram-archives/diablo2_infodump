/* UI function for managing the item placement popup.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "ui.h"
#include <Xm/ComboBox.h>
#include <Xm/List.h>
#include <Xm/PushB.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <dmalloc.h>

/* Forward declarations: */
static int update_doc_list_if_needed (Widget name_box);
static void ui_place_update_doc_list (Widget, XtPointer, XtPointer);
static void ui_place_destroy_doc_list (Widget, XtPointer, XtPointer);
static void cancel_item_placement (Widget, XtPointer, XtPointer);
static void item_move_ok (Widget okbutton, XtPointer client_data,
			  XtPointer call_data);
static void item_assign_ok (Widget okbutton, XtPointer client_data,
			    XtPointer call_data);

/* Common functions for callbacks that open the item placement popup */
static void
update_item_placement_window (Widget window, int area, int col, int row)
{
  Widget	w;
  char		strbuf[12];
  char *	old_str;

  switch (area)
    {
    case ITEM_AREA_EQUIPPED:
      w = XxNameToWidget (window, "*toggle_place_equipped");
    set_equipment_side:
      if ( ! XmToggleButtonGetState (w))
	XmRadioButtonSetOn (w);

      /* If this item is equipped on a hand or finger,
	 set the toggle for which side it's on.
	 Otherwise disable the left and right switches. */
      switch  (col)
	{
	case EQUIPPED_ON_RIGHT_HAND:
	case EQUIPPED_ON_ALT_RIGHT_HAND:
	case EQUIPPED_ON_RIGHT_FINGER:
	  w = XxNameToWidget (window, "*radio_place_side");
	  if ( ! XtIsSensitive (w))
	    XtSetSensitive (w, True);
	  w = XxNameToWidget (window, "*toggle_right_side");
	  if ( ! XmToggleButtonGetState (w))
	    XmRadioButtonSetOn (w);
	  break;

	case EQUIPPED_ON_LEFT_HAND:
	case EQUIPPED_ON_ALT_LEFT_HAND:
	case EQUIPPED_ON_LEFT_FINGER:
	  w = XxNameToWidget (window, "*radio_place_side");
	  if ( ! XtIsSensitive (w))
	    XtSetSensitive (w, True);
	  w = XxNameToWidget (window, "*toggle_left_side");
	  if ( ! XmToggleButtonGetState (w))
	    XmRadioButtonSetOn (w);
	  break;

	default:
	  w = XxNameToWidget (window, "*radio_place_side");
	  if (XtIsSensitive (w))
	    XtSetSensitive (w, False);
	  break;
	}

      /* When the item is equipped, disable the column/row fields */
      w = XxNameToWidget (window, "*form_place_coordinate");
      if (XtIsSensitive (w))
	XtSetSensitive (w, False);
      break;

    case ITEM_AREA_CORPSE:
      w = XxNameToWidget (window, "*toggle_place_corpse");
      goto set_equipment_side;

    case ITEM_AREA_HIRELING:
      w = XxNameToWidget (window, "*toggle_place_hireling");
      goto set_equipment_side;

    case ITEM_AREA_BELT:
      /* Externally present the belt location in row/column form */
      row = col / 4;
      col = col % 4;
      w = XxNameToWidget (window, "*toggle_place_belt");
      goto set_storage_position;

    case ITEM_AREA_INVENTORY:
      w = XxNameToWidget (window, "*toggle_place_inventory");
    set_storage_position:
      if ( ! XmToggleButtonGetState (w))
	XmRadioButtonSetOn (w);

      w = XxNameToWidget (window, "*form_place_coordinate");
      if ( ! XtIsSensitive (w))
	XtSetSensitive (w, True);
      w = XxNameToWidget (window, "*field_place_column");
      sprintf (strbuf, "%d", col);
      old_str = XmTextFieldGetString (w);
      if (strcmp (old_str, strbuf) != 0)
	XmTextFieldSetString (w, strbuf);
      XtFree (old_str);
      w = XxNameToWidget (window, "*field_place_row");
      sprintf (strbuf, "%d", row);
      old_str = XmTextFieldGetString (w);
      if (strcmp (old_str, strbuf) != 0)
	XmTextFieldSetString (w, strbuf);
      XtFree (old_str);

      /* When the item is stored, disable the left-hand/right-hand switches */
      w = XxNameToWidget (window, "*radio_place_side");
      if (XtIsSensitive (w))
	XtSetSensitive (w, False);
      break;

    case ITEM_AREA_STASH:
      w = XxNameToWidget (window, "*toggle_place_stash");
      goto set_storage_position;

    case ITEM_AREA_CUBE:
      w = XxNameToWidget (window, "*toggle_place_cube");
      goto set_storage_position;

    case ITEM_AREA_PICKED:
      w = XxNameToWidget (window, "*toggle_place_mouse");
    disable_other_fields:
      if ( ! XmToggleButtonGetState (w))
	XmRadioButtonSetOn (w);
      w = XxNameToWidget (window, "*form_place_coordinate");
      if (XtIsSensitive (w))
	XtSetSensitive (w, False);
      w = XxNameToWidget (window, "*radio_place_side");
      if (XtIsSensitive (w))
	XtSetSensitive (w, False);
      break;

    case ITEM_AREA_SOCKETED:
      w = XxNameToWidget (window, "*toggle_place_socket");
      goto disable_other_fields;

    default:
      fprintf (stderr, "%s: Internal error: bad argument to"
	       " update_item_placement_window(%s,%d,%d,%d)\n",
	       progname, XtName (window), area, col, row);
      break;
    }
}

static Widget
popup_item_placement_window (Widget docwindow, d2sItem *item)
{
  Widget	popup_form, popup_shell;
  MrmType	class_code;
  Cardinal	status;
  Position	x, y;
  const char *	cstr;

  /* If the placement popup already exists, just return it. */
  popup_form = XtNameToWidget (docwindow, "*form_item_placement");
  if (popup_form != NULL)
    return popup_form;

  popup_shell = XtVaCreatePopupShell ("itemPlacement",
				      transientShellWidgetClass,
				      docwindow, NULL);
  status = MrmFetchWidget (item_mrm_hierarchy, "form_item_placement",
			   popup_shell, &popup_form, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create interface form_item_placement"
	       " from UID file\n", progname);
      XtDestroyWidget (popup_shell);
      return NULL;
    }

  /* Copy the item to the popup's userData resource */
  XtVaSetValues (popup_form, XmNuserData, item, NULL);

  /* Establish the position of the dialog to match the item editor window */
  XtVaGetValues (docwindow, XmNwidth, &x, NULL);
  /* This puts the popup rougly near the top center of the item editor */
  XtTranslateCoords (docwindow, x / 2 - 32, 32, &x, &y);
  XtVaSetValues (popup_shell, XmNx, x, XmNy, y, NULL);

  /* Assign a callback to the Cancel button.
     (The caller is responsible for the OK button.) */
  XtAddCallback (XxNameToWidget (popup_form, "*button_placement_cancel"),
		 XmNactivateCallback, cancel_item_placement, popup_form);

  /* If the item cannot be equipped, disable the equip buttons */
  if (!GetEntryIntegerField (item->TypeTableEntry(), "Body"))
    {
      XtSetSensitive (XxNameToWidget (popup_form, "*toggle_place_equipped"),
		      False);
      XtSetSensitive (XxNameToWidget (popup_form, "*toggle_place_corpse"),
		      False);
      XtSetSensitive (XxNameToWidget (popup_form, "*toggle_place_hireling"),
		      False);
      XtSetSensitive (XxNameToWidget (popup_form, "*radio_place_side"),
		      False);
    }
  else
    {
      /* If the item doesn't go to the left or right side,
	 disable those switches. */
      cstr = GetEntryStringField (item->TypeTableEntry(), "BodyLoc1");
      x = GetEntryIntegerField (LookupTableEntry ("bodylocs", "Code", cstr),
				NULL);
      switch (x)
	{
	case EQUIPPED_ON_RIGHT_HAND:
	case EQUIPPED_ON_ALT_RIGHT_HAND:
	case EQUIPPED_ON_RIGHT_FINGER:
	case EQUIPPED_ON_LEFT_HAND:
	case EQUIPPED_ON_ALT_LEFT_HAND:
	case EQUIPPED_ON_LEFT_FINGER:
	  break;
	default:
	  XtSetSensitive (XxNameToWidget (popup_form, "*radio_place_side"),
			  False);
	  break;
	}

      /* If the character isn't dead, disable the corpse button */
      if ((item->Owner() == NULL) || ! item->Owner()->has_corpse())
	XtSetSensitive (XxNameToWidget (popup_form, "*toggle_place_corpse"),
			False);

      /* If the character has no hireling, disable the mercenary button */
      if ((item->Owner() == NULL) || ! item->Owner()->is_expansion()
	  || ! item->Owner()->has_hireling())
      XtSetSensitive (XxNameToWidget (popup_form, "*toggle_place_hireling"),
		      False);
    }

  /* If the item cannot be tucked in the belt, disable the belt button. */
  if (!GetEntryIntegerField (item->TypeTableEntry(), "Beltable"))
    XtSetSensitive (XxNameToWidget (popup_form, "*toggle_place_belt"),
		    False);

  /* If the item is already in a socket, enable the socket button.
     Otherwise the button is disabled.
     (Can't place the item in a socket with this popup.) */
  XtSetSensitive (XxNameToWidget (popup_form, "*toggle_place_socket"),
		  (item->Location() == ITEM_AREA_SOCKETED));

  /* Fill in the fields with the current position of the item */
  update_item_placement_window (popup_form, item->Location(),
				item->Position().x, item->Position().y);

  return popup_form;
}

/* Move a character's item from one place to another */
void
ui_item_move (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	placement_popup, name_box;
  d2sItem *	item;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if ((item == NULL) || (item->Owner() == NULL))
    {
      /* Error!  This menu item shouldn't have been enabled. */
      XtSetSensitive (w, False);
      if (item != NULL)
	{
	  XtSetSensitive (XxNameToWidget
			  (docwindow, "*menubar_item*menuitem_assign"),
			  True);
	}
      return;
    }

  placement_popup = popup_item_placement_window (docwindow, item);
  if (placement_popup == NULL)
    return;

  /* Assign a callback to the OK button. */
  XtAddCallback (XxNameToWidget (placement_popup, "*button_placement_ok"),
		 XmNactivateCallback, item_move_ok, placement_popup);

  /* Set the owner field to the name of the item's owner,
     and disable it. */
  name_box = XxNameToWidget (placement_popup, "*combo_place_owner");
  XmListDeleteAllItems (XxNameToWidget (name_box, "*List"));
  XmTextFieldSetString (XxNameToWidget (name_box, "*Text"),
			(char *) item->Owner()->GetCharacterName());
  XtVaSetValues (name_box,
		 XmNsensitive, False,
		 XmNuserData, NULL,
		 NULL);

  if (!XtIsManaged (placement_popup))
    {
      /* Show the popup box */
      XtManageChild (placement_popup);
      XtPopup (XtParent (placement_popup), XtGrabNone);
      XtRealizeWidget (XtParent (placement_popup));
    }
}

/* Give an item to a character.  Very similar to move,
   except the item doesn't have an owner yet. */
void
ui_item_assign (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	placement_popup, name_box;
  d2sItem *	item;
  d2sData *	gamePtr;
  int		i;
  Widget	*char_window_list;
  XmString	xmstr;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if ((item == NULL) || (item->Owner() != NULL))
    {
      /* Error!  This menu item shouldn't have been enabled. */
      XtSetSensitive (w, False);
      if (item != NULL)
	{
	  XtSetSensitive (XxNameToWidget
			  (docwindow, "*menubar_item*menuitem_move"),
			  True);
	  XtSetSensitive (XxNameToWidget
			  (docwindow, "*menubar_item*menuitem_remove"),
			  True);
	}
      return;
    }

  /* If there are no character windows open, ignore the request. */
  if (!doc_shell_count)
    {
      print_message ("There are no characters open to which you"
		     " can give this %s", item->Name());
      return;
    }

  placement_popup = popup_item_placement_window (docwindow, item);
  if (placement_popup == NULL)
    return;

  /* Assign a callback to the OK button. */
  XtAddCallback (XxNameToWidget (placement_popup, "*button_placement_ok"),
		 XmNactivateCallback, item_assign_ok, placement_popup);

  /* Clear the owner field, and fill the drop-down list
     with the names of characters found in all character windows. */
  name_box = XxNameToWidget (placement_popup, "*combo_place_owner");
  XmTextFieldSetString (XxNameToWidget (name_box, "*Text"),
			(char *) "(unclaimed)");
  XmListDeleteAllItems (XxNameToWidget (name_box, "*List"));
  XmComboBoxUpdate (name_box);
  /* Copy the document window list as it currently stands.
     If the list changes before the user selects a character,
     we'll have to update the drop-down list. */
  char_window_list = (Widget *) XtMalloc (doc_shell_count * sizeof (Widget));
  memcpy (char_window_list, doc_shell_list, doc_shell_count * sizeof (Widget));
  XtVaSetValues (name_box,
		 XmNuserData, char_window_list,
		 XmNvisibleItemCount, ((doc_shell_count < 10)
				       ? doc_shell_count : 10),
		 NULL);
  XtAddCallback (XxNameToWidget (name_box, "GrabShell"),
		 XmNpopupCallback, ui_place_update_doc_list, name_box);
  XtAddCallback (name_box,
		 XmNdestroyCallback, ui_place_destroy_doc_list, name_box);
  for (i = 0; i < doc_shell_count; i++)
    {
      XtVaGetValues (XxNameToWidget (doc_shell_list[i], "*form_char"),
		     XmNuserData, &gamePtr,
		     NULL);
      if (gamePtr == NULL) {
	fprintf (stderr, "%s: Internal error: document window %p has"
		 " no document\n", progname, doc_shell_list[i]);
	/* Put in a blank entry to keep the indexes in sync */
	xmstr = XmStringCreateLocalized ((char *) "--------");
      } else
	xmstr = XmStringCreateLocalized ((char *)
					 gamePtr->GetCharacterName());
      XmComboBoxAddItem (name_box, xmstr, i + 1, False);
      XmStringFree (xmstr);
    }

  if (!XtIsManaged (placement_popup))
    {
      /* Show the popup box */
      XtManageChild (placement_popup);
      XtPopup (XtParent (placement_popup), XtGrabNone);
      XtRealizeWidget (XtParent (placement_popup));
    }
}

/* Check whether the set of open character windows has changed.
   Called by several UI functions that need to pick a character.
   Returns True if the doc list was updated, False if no change. */
static int
update_doc_list_if_needed (Widget name_box)
{
  Widget	*char_window_list;
  int		count, new_position;
  Widget	previous_selection;
  d2sData *	gamePtr;
  XmString	xmstr;

  XtVaGetValues (name_box,
		 XmNitemCount, &count,
		 XmNselectedPosition, &new_position,
		 XmNuserData, &char_window_list,
		 NULL);
  if ((count == doc_shell_count)
      && (memcmp (char_window_list, doc_shell_list,
		  count * sizeof (Widget)) == 0))
    /* No changes were made. */
    return False;

  /* Get the document window of the previous selection */
  if (new_position)
    previous_selection = char_window_list[new_position - 1];
  else
    previous_selection = NULL;

  /* The list has changed.  Update it. */
  XmListDeleteAllItems (XxNameToWidget (name_box, "*List"));
  XmComboBoxUpdate (name_box);
  char_window_list = (Widget *)
    XtRealloc ((char *) char_window_list,
	       doc_shell_count * sizeof (Widget));
  memcpy (char_window_list, doc_shell_list,
	  doc_shell_count * sizeof (Widget));
  XtVaSetValues (name_box,
		 XmNrightAttachment, XmATTACH_NONE,
		 XmNuserData, char_window_list,
		 XmNvisibleItemCount, ((doc_shell_count < 10)
				       ? doc_shell_count : 10),
		 NULL);

  if (doc_shell_count)
    {
      new_position = 0;
      for (count = 0; count < doc_shell_count; count++)
	{
	  XtVaGetValues (XxNameToWidget (doc_shell_list[count], "*form_char"),
			 XmNuserData, &gamePtr,
			 NULL);
	  if (gamePtr == NULL) {
	    fprintf (stderr, "%s: Internal error: document window %p has"
		     " no document\n", progname, doc_shell_list[count]);
	    /* Put in a blank entry to keep the indexes in sync */
	    xmstr = XmStringCreateLocalized ((char *) "--------");
	  } else
	    xmstr = XmStringCreateLocalized ((char *)
					     gamePtr->GetCharacterName());
	  XmComboBoxAddItem (name_box, xmstr, count + 1, False);
	  XmStringFree (xmstr);
	  if (doc_shell_list[count] == previous_selection)
	    new_position = count + 1;
	}
    }

  /* Any time items are added to a list widget, it changes
	 its width.  This is very bad for forms. */
  XtVaSetValues (name_box,
		 XmNcolumns, 15,
		 XmNrightAttachment, XmATTACH_FORM,
		 XmNselectedPosition, new_position,
		 NULL);
  if (new_position == 0)
    /* Make sure the text field is clear */
    XmTextFieldSetString (XxNameToWidget (name_box, "*Text"),
			  (char *) "(unclaimed)");

  return True;
}

/* Each time the drop-down list is posted, check whether
   the set of open character windows has changed. */
static void
ui_place_update_doc_list (Widget w, XtPointer client_data,
			  XtPointer call_data)
{
  update_doc_list_if_needed ((Widget) client_data);
}

/* Remove the drop-down list's copy of the document window list */
static void
ui_place_destroy_doc_list (Widget w, XtPointer client_data,
			   XtPointer call_data)
{
  Widget	name_box = (Widget) client_data;
  Widget	*char_window_list;

  XtVaGetValues (name_box, XmNuserData, &char_window_list, NULL);
  if (char_window_list != NULL)
    XtFree ((char *) char_window_list);
}

/* Drop an item from its owner */
void
ui_item_remove (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	menu;
  d2sItem *	item;
  d2sData *	owner;
#if 0
  int difficulty;
#endif

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if ((item == NULL) || (item->Owner() == NULL))
    {
      /* Error!  This menu item shouldn't have been enabled. */
      XtSetSensitive (w, False);
      if (item != NULL)
	{
	  XtSetSensitive (XxNameToWidget
			  (docwindow, "*menubar_item*menuitem_assign"),
			  True);
	}
      return;
    }

  /* If the item placement popup is still shown, get rid of it. */
  menu = XtNameToWidget (docwindow, "*form_item_placement");
  if (menu != NULL)
    XtDestroyWidget (XtParent (menu));

  owner = item->Owner();
  if (display_question (0, 2, "Cancel", "Drop it",
			"Are you sure you want %s to drop this %s?",
			owner->GetCharacterName(), item->Name()))
    {
      /* Okay, the user asked for it... */
      if (item->Location() == ITEM_AREA_SOCKETED)
	{
	  d2sAttachItem *gem = (d2sAttachItem *) *item;
	  d2sDurableItem *ditem = gem->AttachedTo();
	  /* Socketed items are not removed from the character;
	     the are removed from the item they are attached to. */
	  if (ditem->RemoveGem (gem) < 0)
	    {
	      /* Can't remove it! */
	      display_error (ditem->GetErrorMessage());
	      return;
	    }
	  /* Update the item the gem was in */
	  update_socketed_item (ditem);
	}
      else
	{
	  remove_item_from_inventory (item);
	  if (owner->RemoveItem (item) < 0)
	    {
	      /* Can't remove it!  Put it back. */
	      update_item_in_inventory (item);
	      display_error (owner->GetErrorMessage());
	      return;
	    }
	}

      /* Update the menu */
      menu = XxNameToWidget (docwindow, "*menubar_item");
      XtSetSensitive (XxNameToWidget (menu, "*menuitem_move"), False);
      XtSetSensitive (XxNameToWidget (menu, "*menuitem_remove"), False);
      XtSetSensitive (XxNameToWidget (menu, "*menuitem_assign"), True);

      /* Update the title bar */
      update_item_window_title (docwindow, item);

      /* Mark the item dirty, even if it wasn't changed before removal.
	 This gives the user one last chance to save the item
	 before it is destroyed when the window is closed. */
      if (item->SourceFileName() == NULL)
	item->MarkDirty();

#if 0
      /* TO-DO: */
      /* If this is a quest item, we may need to
	 update the character's quest screen. */
      if (item->is_quest_item())
	{
	  difficulty = XmOptionMenuGetSelection
	    (XxNameToWidget (owner->GetUI(),
			     "*form_quests*option_qstdifficulty"));
	  update_quests (owner->GetUI(), owner, difficulty);
	  /* TO-DO: update_quest_edit () */
	}
#endif
    }
}

static void
cancel_item_placement (Widget w, XtPointer client_data, XtPointer call_data)
{
  /* Simply destroy the popup */
  XtDestroyWidget (XtParent ((Widget) client_data));
}

void
ui_item_place_select_character (Widget w, XtPointer client_data,
				XtPointer call_data)
{
  Widget	popup_window = (Widget) client_data;
  Widget	char_window;
  XmComboBoxCallbackStruct *cbs = (XmComboBoxCallbackStruct *) call_data;
  d2sItem *	item;
  d2sData *	gamePtr;
  int		area, col, row;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  /* If there is no selected item,
     or we were called by another widget, ignore the call. */
  if (!cbs->item_position)
    return;
  if (!XmIsComboBox (w))
    return;

  XtVaGetValues (popup_window, XmNuserData, &item, NULL);
  if (item == NULL) {
    XtDestroyWidget (XtParent (popup_window));
    return;
  }

  stdui = item->GetUI();

  /* Since the drop-down list is kept up to date every time it is
     popped up, we can assume the position index corresponds with the
     document list. */
  char_window = XxNameToWidget (doc_shell_list[cbs->item_position - 1],
				"*form_char");
  XtVaGetValues (char_window, XmNuserData, &gamePtr, NULL);

  /* Find the first available spot on this character,
     and set the placement popup to match. */
  if (gamePtr->FindEmptySpotForItem (item, &area, &col, &row) < 0)
    return;
  update_item_placement_window (popup_window, area, col, row);
}

void
ui_item_place_change_area (Widget toggle, XtPointer client_data,
			   XtPointer call_data)
{
  Widget	popup_window = (Widget) client_data;
  Widget	char_window, w;
  XmToggleButtonCallbackStruct *toggle_state
    = (XmToggleButtonCallbackStruct *) call_data;
  d2sItem *	item;
  d2sData *	gamePtr;
  int		area, col, row, status;
  char		strbuf[12], *old_str;

  /* Ignore this callback when the toggle is turned off */
  if (!toggle_state->set)
    return;

  XtVaGetValues (popup_window, XmNuserData, &item, NULL);
  if (item == NULL) {
    XtDestroyWidget (XtParent (popup_window));
    return;
  }

  stdui = item->GetUI();

  /* Get the new area */
  XtVaGetValues (toggle, XmNuserData, &area, NULL);

  gamePtr = item->Owner();
  if (gamePtr == NULL)
    {
      /* Make sure our character list is up to date, then
	 fetch the currently selected character (if any). */
      w = XxNameToWidget (popup_window, "*combo_place_owner");
      update_doc_list_if_needed (w);
      XtVaGetValues (w, XmNselectedPosition, &row, NULL);
      if (row) {
	char_window = XxNameToWidget (doc_shell_list[row - 1], "*form_char");
	XtVaGetValues (char_window, XmNuserData, &gamePtr, NULL);
      }
    }

  if (gamePtr != NULL)
    {
      if ((item->Owner() != NULL) && (area == item->Location()))
	{
	  /* Just leave the item where it is. */
	  col = item->Position().x;
	  row = item->Position().y;
	  status = 0;
	}
      else
	{
	  /* Find the first available spot in this new area */
	  status = gamePtr->FindEmptySpotForItem (item, area, &col, &row);
	}
    }
  else
    status = -1;

  /* Update the left/right or col/row fields */
  switch (area)
    {
    case ITEM_AREA_EQUIPPED:
    case ITEM_AREA_CORPSE:
    case ITEM_AREA_HIRELING:
      if (status >= 0)
	{
	  switch (col)
	    {
	    case EQUIPPED_ON_RIGHT_HAND:
	    case EQUIPPED_ON_ALT_RIGHT_HAND:
	    case EQUIPPED_ON_RIGHT_FINGER:
	      w = XxNameToWidget (popup_window, "*toggle_right_side");
	      XmRadioButtonSetOn (w);
	      w = XxNameToWidget (popup_window, "*radio_place_side");
	      if ( ! XtIsSensitive (w))
		XtSetSensitive (w, True);
	      break;

	    case EQUIPPED_ON_LEFT_HAND:
	    case EQUIPPED_ON_ALT_LEFT_HAND:
	    case EQUIPPED_ON_LEFT_FINGER:
	      w = XxNameToWidget (popup_window, "*toggle_left_side");
	      XmRadioButtonSetOn (w);
	      w = XxNameToWidget (popup_window, "*radio_place_side");
	      if ( ! XtIsSensitive (w))
		XtSetSensitive (w, True);
	      break;
	    }
	}
      w = XxNameToWidget (popup_window, "*form_place_coordinate");
      if (XtIsSensitive (w))
	XtSetSensitive (w, False);
      break;

    case ITEM_AREA_BELT:
      /* Externally present the belt location in row/column form */
      row = col / 4;
      col = col % 4;
      /* FALLTHROUGH */

    case ITEM_AREA_INVENTORY:
    case ITEM_AREA_STASH:
    case ITEM_AREA_CUBE:
      w = XxNameToWidget (popup_window, "*form_place_coordinate");
      if ( ! XtIsSensitive (w))
	XtSetSensitive (w, True);
      if (status >= 0)
	{
	  w = XxNameToWidget (popup_window, "*field_place_column");
	  sprintf (strbuf, "%d", col);
	  old_str = XmTextFieldGetString (w);
	  if (strcmp (old_str, strbuf) != 0)
	    XmTextFieldSetString (w, strbuf);
	  XtFree (old_str);
	  w = XxNameToWidget (popup_window, "*field_place_row");
	  sprintf (strbuf, "%d", row);
	  old_str = XmTextFieldGetString (w);
	  if (strcmp (old_str, strbuf) != 0)
	    XmTextFieldSetString (w, strbuf);
	  XtFree (old_str);
	}
      w = XxNameToWidget (popup_window, "*radio_place_side");
      if (XtIsSensitive (w))
	XtSetSensitive (w, False);
      break;

    case ITEM_AREA_PICKED:
    case ITEM_AREA_SOCKETED:
      w = XxNameToWidget (popup_window, "*form_place_coordinate");
      if (XtIsSensitive (w))
	XtSetSensitive (w, False);
      w = XxNameToWidget (popup_window, "*radio_place_side");
      if (XtIsSensitive (w))
	XtSetSensitive (w, False);
      break;
    }
}

/* Get the currently selected location in the placement popup */
static void
fetch_selected_placement (Widget popup_window, d2sItem *item,
			  int *ret_area, int *ret_col, int *ret_row)
{
  Widget	w;
  char		*str;
  const char *	cstr;

  XtVaGetValues (XxNameToWidget (popup_window, "*radio_place_area"),
		 XmNmenuHistory, &w,
		 NULL);
  XtVaGetValues (w, XmNuserData, ret_area, NULL);
  switch (*ret_area)
    {
    case ITEM_AREA_EQUIPPED:
    case ITEM_AREA_CORPSE:
    case ITEM_AREA_HIRELING:
      /* Tricky; the only thing we know from the user is which side
	 he wants the item on.  The actual place for the item is
	 determined instead by the item type. */
      cstr = GetEntryStringField (item->TypeTableEntry(), "BodyLoc1");
      *ret_col = GetEntryIntegerField
	(LookupTableEntry ("bodylocs", "Code", cstr), NULL);
      switch (*ret_col)
	{
	case EQUIPPED_ON_RIGHT_HAND:
	case EQUIPPED_ON_ALT_RIGHT_HAND:
	case EQUIPPED_ON_RIGHT_FINGER:
	  if (XmToggleButtonGetState
	      (XxNameToWidget (popup_window, "*toggle_left_side")))
	    (*ret_col)++;
	  break;

	case EQUIPPED_ON_LEFT_HAND:
	case EQUIPPED_ON_ALT_LEFT_HAND:
	case EQUIPPED_ON_LEFT_FINGER:
	  if (XmToggleButtonGetState
	      (XxNameToWidget (popup_window, "*toggle_right_side")))
	    (*ret_col)--;
	  break;
	}
      *ret_row = 0;
      break;

    case ITEM_AREA_BELT:
    case ITEM_AREA_INVENTORY:
    case ITEM_AREA_STASH:
    case ITEM_AREA_CUBE:
      str = XmTextFieldGetString
	(XxNameToWidget (popup_window, "*field_place_column"));
      *ret_col = atoi (str);
      XtFree (str);
      str = XmTextFieldGetString
	(XxNameToWidget (popup_window, "*field_place_row"));
      *ret_row = atoi (str);
      XtFree (str);

      /* Internally convert a belt's row/column to a slot number */
      if (*ret_area == ITEM_AREA_BELT)
	{
	  *ret_col += *ret_row * 4;
	  *ret_row = 0;
	}
      break;

    case ITEM_AREA_PICKED:
      *ret_col = 0;
      *ret_row = 0;
      break;

    case ITEM_AREA_SOCKETED:
      /* Get the item's current socket number */
      *ret_col = item->Position().x;
      *ret_row = 0;
      break;
    }
}

static void
item_move_ok (Widget okbutton, XtPointer client_data, XtPointer call_data)
{
  Widget	popup_window = (Widget) client_data;
  d2sItem	*item;
  d2sDurableItem *attached;
  int		area, col, row;

  XtVaGetValues (popup_window, XmNuserData, &item, NULL);
  if (item == NULL) {
    XtDestroyWidget (XtParent (popup_window));
    return;
  }

  stdui = item->GetUI();

  /* Get the requested item location */
  fetch_selected_placement (popup_window, item, &area, &col, &row);

  /* If we are not changing the item's location,
     we can remove the pop-up without doing anything. */
  if ((item->Location() == area)
      && (item->Position().x == col) && (item->Position().y == row))
    {
      XtDestroyWidget (XtParent (popup_window));
      return;
    }

  if (item->Location() == ITEM_AREA_SOCKETED)
    attached = ((d2sAttachItem *) *item)->AttachedTo();
  else
    attached = NULL;

  /* If the destination is the character's hand, and his hand already has
     an item, and he is an Expansion character, try the alternate hand. */
  if ((area == ITEM_AREA_EQUIPPED) && item->Owner()->is_expansion()
      && ((col == EQUIPPED_ON_RIGHT_HAND) || (col == EQUIPPED_ON_LEFT_HAND))
      && (item->Owner()->CheckLocationAvailable (item, area, col, row) < 0))
    col = ((col == EQUIPPED_ON_RIGHT_HAND) ? EQUIPPED_ON_ALT_RIGHT_HAND
	   : EQUIPPED_ON_ALT_LEFT_HAND);

  /* Ask the character to move the item. */
  if (item->Location() != ITEM_AREA_SOCKETED)
    remove_item_from_inventory (item);
  if (item->Owner()->MoveItemTo (item, area, col, row) < 0)
    {
      /* Can't move it!  Put it back. */
      if (item->Location() != ITEM_AREA_SOCKETED)
	update_item_in_inventory (item);
      display_error (item->Owner()->GetErrorMessage());
      return;
    }

  /* Show the item in its new location */
  update_item_in_inventory (item);
  /* If the item was in a socket, update the item it was in. */
  if (attached != NULL)
    update_socketed_item (attached);

      /* Remove the popup */
  XtDestroyWidget (XtParent (popup_window));
}

static void
item_assign_ok (Widget okbutton, XtPointer client_data, XtPointer call_data)
{
  Widget	popup_window = (Widget) client_data;
  Widget	char_window, w;
  d2sItem	*item;
  d2sDurableItem *attached;
  d2sData	*gamePtr;
  int		area, col, row;

  XtVaGetValues (popup_window, XmNuserData, &item, NULL);
  if (item == NULL) {
    XtDestroyWidget (XtParent (popup_window));
    return;
  }

  stdui = item->GetUI();

  /* Find out which character the user is giving this item to */
  w = XxNameToWidget (popup_window, "*combo_place_owner");
  XtVaGetValues (w, XmNselectedPosition, &col, NULL);
  update_doc_list_if_needed (w);
  XtVaGetValues (w, XmNselectedPosition, &row, NULL);
  if (row) {
    char_window = XxNameToWidget (doc_shell_list[row - 1], "*form_char");
    XtVaGetValues (char_window, XmNuserData, &gamePtr, NULL);
  }
  /* If the user had selected a character, but that character
	 is gone now, alert the user to try again. */
  else if (col) {
    display_error ("The character you selected has been closed. "
		   " Please make another selection.");
    return;
  }
  else
    gamePtr = NULL;

  /* Get the requested item location */
  fetch_selected_placement (popup_window, item, &area, &col, &row);

  /* If we are not changing the item's location,
     we can remove the pop-up without doing anything. */
  if ((gamePtr == NULL) && (item->Location() == area)
      && (item->Position().x == col) && (item->Position().y == row))
    {
      XtDestroyWidget (XtParent (popup_window));
      return;
    }

  if (item->Location() == ITEM_AREA_SOCKETED)
    attached = ((d2sAttachItem *) *item)->AttachedTo();
  else
    attached = NULL;

  /* If the item is in a socket, we cannot give it to a character
     unless we are also removing it from the socket. */
  if ((item->Location() == ITEM_AREA_SOCKETED) && (area == ITEM_AREA_SOCKETED))
    {
      display_error ("You cannot give this %s to %s while it is still in"
		     " the %s's socket.  Either give the %s to %s, or"
		     " choose a place in %s's inventory to store the %s.",
		     /* Very descriptive! */
		     item->Name(), gamePtr->GetCharacterName(),
		     attached->Name(), attached->Name(),
		     gamePtr->GetCharacterName(),
		     gamePtr->GetCharacterName(), item->Name());
      return;
    }

  /* If the item is currently socketed, and has no owner,
     we must remove it from its socket before setting the new location */
  if (item->Location() == ITEM_AREA_SOCKETED)
    {
      if (display_question
	  (0, 2, "Cancel", "Remove", (gamePtr == NULL)
	   ? "Remove this %s from its %s?"
	   : "Remove this %s from its %s before giving it to %s?",
	   item->Name(), attached->Name(),
	   (gamePtr == NULL) ? "" : gamePtr->GetCharacterName()) == 0)
	/* Cancel the operation */
	return;

      if (attached->RemoveGem ((d2sAttachItem *) *item) < 0)
	{
	  display_error (attached->GetErrorMessage());
	  return;
	}
      update_socketed_item (attached);
    }

  /* Set the item location */
  if (item->SetLocation (area, col, row) < 0)
    {
      display_error (item->GetErrorMessage());
      /* If the item was previously in a socket, try to put it back. */
      if (attached != NULL)
	{
	  if (attached->AddGem ((d2sAttachItem *) *item) >= 0)
	    update_socketed_item (attached);
	  else
	    XtDestroyWidget (XtParent (popup_window));
	}
      return;
    }

  /* Add the item to the desired character */
  if (gamePtr != NULL)
    {
      if (gamePtr->AddItem (item) < 0)
	{
	  display_error (gamePtr->GetErrorMessage());
	  /* If the item was previously in a socket, try to put it back. */
	  if (attached != NULL)
	    {
	      if (attached->AddGem ((d2sAttachItem *) *item) >= 0)
		update_socketed_item (attached);
	      else
		XtDestroyWidget (XtParent (popup_window));
	    }
	  return;
	}
      /* Update the character's inventory */
      update_item_in_inventory (item);
      /* Update the item editor's title */
      update_item_window_title ((Widget) item->GetUI(), item);
      /* Update the item placement menu options */
      w = XxNameToWidget ((Widget) item->GetUI(), "*menubar_item");
      XtSetSensitive (XxNameToWidget (w, "*menuitem_move"), True);
      XtSetSensitive (XxNameToWidget (w, "*menuitem_remove"), True);
      XtSetSensitive (XxNameToWidget (w, "*menuitem_assign"), False);
    }

  /* All done! */
  XtDestroyWidget (XtParent (popup_window));
}
