/* Create a new Diablo II item.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <errno.h>
#include "ui.h"
#include <Xm/ArrowB.h>
#include <Xm/ComboBox.h>
#include <Xm/Form.h>
#include <Xm/List.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <dmalloc.h>

/* Structure describing an item, for the item list */
typedef struct {
  uint32_t	id;
  const char	*name;
  const char	*graphic;
  short		version;
  short		level;
} NewItem;

/* Item types are arranged in a tree using this structure: */
typedef struct new_type_struct {
  const char	*name;		/* Name of the type */
  const char	*code;
  struct new_type_struct *parent;
  struct new_type_struct **children;
  int		num_children;
  Widget	form;		/* Form containing the type branch */
  Widget	toggle;		/* ToggleButton for this type */
  NewItem	*items;		/* Items which have this *specific* type */
  int		num_items;
} NewType;

/* Local callbacks */
static void init_type_tree (void);
static int sort_item_types_by_name (const void *, const void *);
static int sort_item_types_by_code (const void *, const void *);
static int sort_items (const void *, const void *);
static int compare_code_to_type (const void *, const void *);
static Widget create_type_widget_tree (Widget parent, Widget last_child,
				       NewType *parent_type);
static void expand_type_branch (Widget, XtPointer, XtPointer);
static void recursive_toggle (Widget, XtPointer, XtPointer);
static void dialog_destroyed (Widget, XtPointer, XtPointer);

/* Local variables */
static Widget new_dialog = NULL;

static NewType type_trunk = {
  "All Items", "", NULL, NULL, 0, NULL, NULL, NULL, 0
};
static NewType **sorted_types = NULL;
static int num_sorted_types = 0;
static NewItem *sorted_items = NULL;
static int num_sorted_items = 0;

/* Initialize the tree of item types */
static void
init_type_tree (void)
{
  table_entry_t type_entry, item_entry, unique_entry;
  NewType	*type, **typep;
  int		i, t, table_size;
  const char	*parent_code, *item_code;
  const char	*table_name;
  const char	*cstr;

  /* Start by reading all the types; don't bother with the hierarchy yet */
  table_size = GetTableSize ("itemtypes");
  for (i = 0; i < table_size; i++)
    {
      type_entry = LookupIndexedTableEntry ("itemtypes", i);
      if ( ! GetEntryStringField (type_entry, "Code")[0])
	continue;
      type = (NewType *) xmalloc (sizeof (NewType));
      memset (type, 0, sizeof (NewType));
      type->name = GetEntryStringField (type_entry, "ItemType");
      type->code = GetEntryStringField (type_entry, "Code");
      sorted_types = (NewType **) XtRealloc
	((char *) sorted_types, (num_sorted_types + 1) * sizeof (NewType *));
      sorted_types[num_sorted_types] = type;
      num_sorted_types++;
    }

  /* Sort the list */
  qsort (sorted_types, num_sorted_types, sizeof (NewType *),
	 sort_item_types_by_code);

  /* Now go through all items in the data tables,
     and add each item to the corresponding type structure. */
  for (t = 0; t < 3; t++) {
    switch (t) {
    case 0: table_name = "misc"; break;
    case 1: table_name = "armor"; break;
    case 2: table_name = "weapons"; break;
    }
    table_size = GetTableSize (table_name);
    for (i = 0; i < table_size; i++) {
      item_entry = LookupIndexedTableEntry (table_name, i);
      item_code = GetEntryStringField (item_entry, "code");
      if (!item_code[0])
	continue;
      parent_code = GetEntryStringField (item_entry, "type");
      typep = (NewType **) bsearch (parent_code, sorted_types,
				    num_sorted_types, sizeof (NewType *),
				    compare_code_to_type);
      if (typep == NULL)
	{
	  if (debug)
	    fprintf (stderr,
		     "%s: Internal error: item \"%s\"'s type\n"
		     " (\"%s\") not found in the item types table\n",
		     progname, TranslateString (item_code), parent_code);
	  continue;
	}
      type = *typep;
      type->items = (NewItem *) XtRealloc
	((char *) type->items, ((type->num_items + 1) * sizeof (NewItem)));
      type->items[type->num_items].id = *((uint32_t *) item_code);
      if (!GetEntryIntegerField (item_entry, "skipname"))
	type->items[type->num_items].name = TranslateString (item_code);
      else {
	unique_entry = LookupTableEntry ("uniqueitems", "code", item_code);
	if (unique_entry == NULL)
	  type->items[type->num_items].name = TranslateString (item_code);
	else
	  type->items[type->num_items].name
	    = TranslateString (GetEntryStringField (unique_entry, "name"));
      }
      if (type->items[type->num_items].name == item_code)
	{
	  if (debug)
	    fprintf (stderr, "%s: Item \"%s\" in item tables (\"%s\"?)\n"
		     " has no official name\n",
		     progname, item_code,
		     GetEntryStringField (item_entry, "name"));
	  continue;
	}
      cstr = strrchr (type->items[type->num_items].name, '\n');
      if (cstr != NULL)
	type->items[type->num_items].name = &cstr[1];
      type_entry = LookupTableEntry ("itemtypes", "Code",
				     GetEntryStringField (item_entry, "type"));
      if (GetEntryIntegerField (type_entry, "VarInvGfx"))
	cstr = GetEntryStringField (type_entry, "InvGfx1");
      else
	cstr = GetEntryStringField (item_entry, "invfile");
      if ((cstr[0] == 'i') && (cstr[1] == 'n') && (cstr[2] == 'v'))
	cstr += 3;
      type->items[type->num_items].graphic = cstr;
      type->items[type->num_items].version
	= GetEntryIntegerField (item_entry, "version");
      type->items[type->num_items].level
	= GetEntryIntegerField (item_entry, "level");
      type->num_items++;
    }
  }

  /* Go through the type list again,
     this time finding parent/child relationships */
  for (i = 0; i < num_sorted_types; i++)
    {
      type_entry = LookupTableEntry ("itemtypes", "Code",
				     sorted_types[i]->code);
      parent_code = GetEntryStringField (type_entry, "Equiv1");
      if (parent_code[0])
	{
	  typep = (NewType **) bsearch (parent_code, sorted_types,
					num_sorted_types, sizeof (NewType *),
					compare_code_to_type);
	  if (typep == NULL)
	    {
	      if (debug)
		fprintf (stderr,
			 "%s: Internal error: item type \"%s\"'s parent\n"
			 " (\"%s\") not found in the item types table\n",
			 progname, sorted_types[i]->name, parent_code);
	      type = &type_trunk;
	    }
	  else
	    type = *typep;
	}
      else
	type = &type_trunk;

      /* Set the child's parent */
      sorted_types[i]->parent = type;
      /* Add the child to the parent's list of children, and re-sort */
      type->children = (NewType **) XtRealloc
	((char *) type->children, ((type->num_children + 1)
				   * sizeof (NewType *)));
      type->children[type->num_children++] = sorted_types[i];
      qsort (type->children, type->num_children, sizeof (NewType *),
	     sort_item_types_by_name);

      /* Also, sort the list of items for this type */
      qsort (sorted_types[i]->items, sorted_types[i]->num_items,
	     sizeof (NewItem), sort_items);
    }
}

static int
sort_item_types_by_name (const void *p1, const void *p2)
{
  const NewType	*t1, *t2;
  t1 = *(const NewType * const *) p1;
  t2 = *(const NewType * const *) p2;
  return strcmp (t1->name, t2->name);
}

static int
sort_item_types_by_code (const void *p1, const void *p2)
{
  const NewType	*t1, *t2;
  t1 = *(const NewType * const *) p1;
  t2 = *(const NewType * const *) p2;
  return strcmp (t1->code, t2->code);
}

static int
sort_items (const void *p1, const void *p2)
{
  const NewItem *i1, *i2;
  i1 = (const NewItem *) p1;
  i2 = (const NewItem *) p2;
  return strcmp (i1->name, i2->name);
}

static int
compare_code_to_type (const void *p1, const void *p2)
{
  const char *code = (const char *) p1;
  const NewType	*type = *(const NewType * const *) p2;
  return strcmp (code, type->code);
}

/* Create a tree of toggle buttons used for selecting item types */
static Widget
create_type_widget_tree (Widget parent, Widget last_child,
			 NewType *parent_type)
{
  Arg		form_args[] = {
    { XmNallowOverlap,	(XtArgVal) False },
    { XmNmarginHeight,	(XtArgVal) 0 },
    { XmNmarginWidth,	(XtArgVal) 0 },
#define FA_TA	3
    { XmNtopAttachment, (XtArgVal) XmATTACH_WIDGET },
#define FA_TW	4
    { XmNtopWidget,	(XtArgVal) NULL },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_NONE },
    { XmNleftAttachment, (XtArgVal) XmATTACH_FORM },
#define FA_LO	7
    { XmNleftOffset,	(XtArgVal) 0 },
    { XmNrightAttachment, (XtArgVal) XmATTACH_FORM },
  };
  Arg		arrow_args[] = {
    { XmNarrowDirection, (XtArgVal) XmARROW_DOWN },
    { XmNmultiClick,	(XtArgVal) XmMULTICLICK_DISCARD },
    { XmNnavigationType, (XtArgVal) XmNONE },
    { XmNtraversalOn,	(XtArgVal) True },
    { XmNwidth,		(XtArgVal) 24 },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_OPPOSITE_WIDGET },
#define AA_BW	7
    { XmNbottomWidget,	(XtArgVal) XmNONE },
    { XmNleftAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNrightAttachment, (XtArgVal) XmATTACH_NONE },
  };
  Arg		toggle_args[] = {
    { XmNalignment,	(XtArgVal) XmALIGNMENT_BEGINNING },
    { XmNindicatorOn,	(XtArgVal) XmINDICATOR_CHECK_BOX },
    { XmNindicatorSize, (XtArgVal) 17 },
#define TA_LS	3
    { XmNlabelString,	(XtArgVal) NULL },
    { XmNmarginHeight,	(XtArgVal) 0 },
    { XmNnavigationType, (XtArgVal) XmNONE },
    { XmNset,		(XtArgVal) True },
    { XmNtraversalOn,	(XtArgVal) True },
    { XmNtopAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNbottomAttachment, (XtArgVal) XmATTACH_NONE },
    { XmNleftAttachment, (XtArgVal) XmATTACH_FORM },
    { XmNleftOffset,	(XtArgVal) 24 },
    { XmNrightAttachment, (XtArgVal) XmATTACH_FORM },
  };
  Widget	form, arrow, toggle, subform;
  XmString	xmstr;
  char		make_name[32];
  int		i;

  /* First off, if this line has no items and no children, skip it. */
  if (!parent_type->num_items && !parent_type->num_children)
    return last_child;

  /* Create a form for this part of the tree */
  snprintf (make_name, sizeof (make_name), "form_%s",
	    parent_type->code);
  if (last_child == NULL) {
      XtSetArg (form_args[FA_TA], XmNtopAttachment, XmATTACH_FORM);
    } else {
      XtSetArg (form_args[FA_TA], XmNtopAttachment, XmATTACH_WIDGET);
      XtSetArg (form_args[FA_TW], XmNtopWidget, last_child);
    }
  /* Certain resources depend on whether this is the top level */
  if ((parent_type->parent == NULL) || (parent_type->parent->parent == NULL))
    XtSetArg (form_args[FA_LO], XmNleftOffset, 0);
  else
    XtSetArg (form_args[FA_LO], XmNleftOffset, 24);
  form = XmCreateForm (parent, make_name, form_args, XtNumber (form_args));
  parent_type->form = form;

  /* If this is not the top-level trunk, we need a toggle button. */
  if (parent_type->parent != NULL)
    {
      snprintf (make_name, sizeof (make_name), "toggle_%s",
		parent_type->code);
      xmstr = XmStringCreateLocalized ((char *) parent_type->name);
      XtSetArg (toggle_args[TA_LS], XmNlabelString, xmstr);
      toggle = XmCreateToggleButton (form, make_name,
				     toggle_args, XtNumber (toggle_args));
      XmStringFree (xmstr);
      XtAddCallback (toggle, XmNvalueChangedCallback,
		     recursive_toggle, parent_type);
      XtManageChild (toggle);
      parent_type->toggle = toggle;
    }
  else
    toggle = NULL;

  /* If this branch has any children, add them now. */
  subform = toggle;
  for (i = 0; i < parent_type->num_children; i++)
    subform = create_type_widget_tree (form, subform,
				       parent_type->children[i]);

  /* If any children were added, we need an arrow button. */
  if ((parent_type->parent != NULL) && (subform != toggle))
    {
      snprintf (make_name, sizeof (make_name), "arrow_%s",
		parent_type->code);
      XtSetArg (arrow_args[AA_BW], XmNbottomWidget, toggle);
      arrow = XmCreateArrowButton (form, make_name,
				   arrow_args, XtNumber (arrow_args));
      XtAddCallback (arrow, XmNactivateCallback,
		     expand_type_branch, parent_type);
      XtManageChild (arrow);
    }

  /* If no children were added, and this type has no items,
     we must delete the form entirely. */
  if ((subform == toggle) && !parent_type->num_items)
    {
      XtDestroyWidget (form);
      parent_type->form = NULL;
      parent_type->toggle = NULL;
      return last_child;
    }

  /* Only manage the top-level branches to begin with */
  if ((parent_type->parent == NULL) || (parent_type->parent->parent == NULL))
    XtManageChild (form);
  return form;
}

/* When the user clicks on an arrow button in the tree,
   either expand or collapse the children of that branch. */
static void
expand_type_branch (Widget arrow, XtPointer client_data, XtPointer call_data)
{
  unsigned char arrow_direction;
  NewType	*parent = (NewType *) client_data;
  int		i;

  XtVaGetValues (arrow, XmNarrowDirection, &arrow_direction, NULL);
  switch (arrow_direction) {
  case XmARROW_UP:	/* The branch is expanded; collapse it */
    for (i = parent->num_children - 1; i >= 0; i--)
      if (parent->children[i]->form != NULL)
	XtUnmanageChild (parent->children[i]->form);
    XtVaSetValues (arrow, XmNarrowDirection, XmARROW_DOWN, NULL);
    break;

  case XmARROW_DOWN:	/* The branch is collapsed; expand it */
    for (i = 0; i < parent->num_children; i++)
      if (parent->children[i]->form != NULL)
	XtManageChild (parent->children[i]->form);
    XtVaSetValues (arrow, XmNarrowDirection, XmARROW_UP, NULL);
    break;
  }
}

/* When the user changes the state of any toggle in the tree,
   change the state of all children of that branch to match. */
static void
recursive_toggle (Widget toggle, XtPointer client_data, XtPointer call_data)
{
  XmToggleButtonCallbackStruct *cbs
    = (XmToggleButtonCallbackStruct *) call_data;
  NewType	*parent = (NewType *) client_data;
  int		i;

  for (i = 0; i < parent->num_children; i++)
    if (parent->children[i]->toggle != NULL)
      XmToggleButtonSetState (parent->children[i]->toggle, cbs->set, True);
}

static void
dialog_destroyed (Widget w, XtPointer client_data, XtPointer call_data)
{
  new_dialog = NULL;
}

void
ui_item_create (Widget w, XtPointer client_data, XtPointer call_data)
{
  Dimension	high, wide;
  Position	x, y;
  Widget	shell;
  MrmType	class_code;
  Cardinal	status;

  /* If this is the first call, initialize the dialog */
  if (new_dialog == NULL)
    {
      shell = XtVaCreatePopupShell
	("newItemDialog", transientShellWidgetClass, toplevel, NULL);
      status = MrmFetchWidget (item_mrm_hierarchy, "form_new_item", shell,
			       &new_dialog, &class_code);
      if (status != MrmSUCCESS)
	{
	  if (debug)
	    fprintf (stderr, "%s: Unable to create interface form_new_item"
		     " from UID file\n", progname);
	  XtDestroyWidget (shell);
	  return;
	}

      /* Don't allow the combo box' text field to be edited */
      XtVaSetValues (XxNameToWidget (new_dialog, "*combo_new_item_name*Text"),
		     XmNcursorPositionVisible, False,
		     XmNeditable, False,
		     XmNnavigationType, XmNONE,
		     XmNtraversalOn, False,
		     NULL);

      /* Fill in the tree of item types; generated dynamically */
      if (num_sorted_types == 0)
	init_type_tree ();
      create_type_widget_tree (XxNameToWidget
			       (new_dialog, "*slist_new_item_type"),
			       NULL, &type_trunk);

      /* Set the initial item list */
      ui_new_item_filter (XxNameToWidget
			  (new_dialog, "*button_new_item_filter"),
			  NULL, call_data);

      /* Assign certain callbacks */
      XtAddCallback (new_dialog, XmNdestroyCallback, dialog_destroyed, NULL);
      /* But don't destroy the dialog by default */
      XtVaSetValues (XtParent (new_dialog),
		     XmNdeleteResponse, XmUNMAP,
		     NULL);

      /* Try to center the dialog */
      XtVaGetValues (XtParent (w),
		     XmNheight, &high,
		     XmNwidth, &wide,
		     XmNx, &x,
		     XmNy, &y,
		     NULL);
      if (wide < 400)
	wide = 400;
      if (high < 300)
	high = 300;
      x += (wide - 400) / 2;
      y += (high - 300) / 2;
      XtManageChild (new_dialog);
      XtRealizeWidget (shell);
      XtVaSetValues (shell, XmNx, x, XmNy, y, NULL);
    }

  XtManageChild (new_dialog);
  XtPopup (XtParent (new_dialog), XtGrabNone);
}

/* When the filter button is pressed, reset the list of available
   items according to the filter parameters. */
void
ui_new_item_filter (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	combo, list;
  uint32_t	current_item;
  int		position;
  char		*str;
  int		min_level, max_level;
  Boolean	expansion;
  int		i, t;
  XmString	xmstr;

  combo = XxNameToWidget (new_dialog, "*combo_new_item_name");
  list = XxNameToWidget (combo, "*List");

  /* Remove the current list of items */
  current_item = 0;
  if (sorted_items != NULL)
    {
      /* Find the currently selected item */
      XtVaGetValues (combo, XmNselectedPosition, &position, NULL);
      if ((unsigned) position < (unsigned) num_sorted_items)
	current_item = sorted_items[position].id;
      XtFree ((char *) sorted_items);
      sorted_items = NULL;
      num_sorted_items = 0;
    }
  XmListDeleteAllItems (list);

  /* Get the extra filter requirements */
  str = XmTextFieldGetString
    (XxNameToWidget (new_dialog, "*field_item_min_level"));
  if (!str[0])
    XmTextFieldSetString
      (XxNameToWidget (new_dialog, "*field_item_min_level"), "0");
  min_level = atoi (str);
  XtFree (str);
  str = XmTextFieldGetString
    (XxNameToWidget (new_dialog, "*field_item_max_level"));
  if (str[0])
    max_level = atoi (str);
  else {
    XmTextFieldSetString
      (XxNameToWidget (new_dialog, "*field_item_max_level"), "99");
    max_level = 99;
  }
  XtFree (str);
  if (min_level > max_level)
    {
      position = min_level;
      min_level = max_level;
      max_level = position;
    }
  expansion = XmToggleButtonGetState
    (XxNameToWidget (new_dialog, "*toggle_new_expansion_item"));

  /* Go through the item types, and for each type whose toggle button
     is set, add the corresponding items to the new list if they match
     the current criteria. */
  for (t = 0; t < num_sorted_types; t++)
    {
      if ((sorted_types[t]->toggle == NULL)
	  || ! XmToggleButtonGetState (sorted_types[t]->toggle))
	continue;
      sorted_items = (NewItem *) XtRealloc
	((char *) sorted_items,
	 ((num_sorted_items + sorted_types[t]->num_items) * sizeof (NewItem)));
      for (i = 0; i < sorted_types[t]->num_items; i++)
	{
	  if (!expansion && (sorted_types[t]->items[i].version >= 100))
	    continue;
	  if ((sorted_types[t]->items[i].level < min_level)
	      || (sorted_types[t]->items[i].level > max_level))
	    continue;
	  memcpy (&sorted_items[num_sorted_items],
		  &sorted_types[t]->items[i], sizeof (NewItem));
	  num_sorted_items++;
	}
    }
  /* Sort the list of items */
  qsort (sorted_items, num_sorted_items, sizeof (NewItem), sort_items);

  /* Add the new set of items to the combo list.  If we come across
     the item that was previously selected, select it again. */
  position = 0;
  for (i = 0; i < num_sorted_items; i++)
    {
      xmstr = XmStringCreateLocalized ((char *) sorted_items[i].name);
      XmListAddItemUnselected (list, xmstr, i + 1);
      XmStringFree (xmstr);
      if (sorted_items[i].id == current_item)
	position = i;
    }
  XmComboBoxUpdate (combo);
  XtVaSetValues (combo, XmNselectedPosition, position, NULL);
}

void
ui_new_item_cancel (Widget w, XtPointer client_data, XtPointer call_data)
{
  XtPopdown (XtParent (new_dialog));
}

void
ui_new_item_selected (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmComboBoxCallbackStruct *cbs = (XmComboBoxCallbackStruct *) call_data;
  Widget	picture_box;
  Pixmap	picture, old_picture;
  char		*xpm_path;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  stdui = NULL;

  if ((unsigned) cbs->item_position >= (unsigned) num_sorted_items)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: item #%d selected,\n"
		 " but the list should only have %d items\n",
		 progname, cbs->item_position + 1, num_sorted_items);
      return;
    }

  picture_box = XxNameToWidget (new_dialog, "*picture_new_item");
  XtVaGetValues (picture_box, XmNlabelPixmap, &old_picture, NULL);

  /* Find the item's picture.  Halfway mirrors load_item_picture(),
     but we don't have an item object to work from. */
  xpm_path = xfindfile ("items", sorted_items[cbs->item_position].graphic,
			".xpm", path_to_images);
  if (xpm_path == NULL)
    picture = XmUNSPECIFIED_PIXMAP;
  else
    picture = XmGetPixmap (XtScreen (w), xpm_path,
			   WhitePixelOfScreen (XtScreen (w)),
			   BlackPixelOfScreen (XtScreen (w)));

  if (picture != old_picture)
    {
      XtVaSetValues (picture_box,
		     XmNlabelPixmap, picture,
		     XmNlabelType, ((picture == XmUNSPECIFIED_PIXMAP)
				    ? XmSTRING : XmPIXMAP),
		     NULL);
      if (old_picture != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (w), old_picture);
    }
}

void
ui_new_item_create (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	combo, editor;
  d2sItem	*item;
  int		position;

  /* Find the currently selected item */
  combo = XxNameToWidget (new_dialog, "*combo_new_item_name");
  XtVaGetValues (combo,
		 XmNselectedPosition, &position,
		 NULL);
  if (position >= num_sorted_items)
    {
      XBell (XtDisplay (w), 0);
      display_error ("No item selected");
      return;
    }

  editor = open_item_editor_window (NULL);
  if (editor == NULL)
    return;
  stdui = editor;

  /* Attempt to create the new item */
  item = CreateItemFromCode (((item_id_t *) &sorted_items[position].id)->ch);
  if (item == NULL)
    {
      display_error ("Can't create a %s", sorted_items[position].name);
      return;
    }
  if (item->GetErrorMessage() != NULL)
    {
      display_error (item->GetErrorMessage());
      delete item;
      return;
    }
  if (item->Type() == UNKNOWN_EXTENDED_ITEM)
    {
      display_error ("This editor can't handle %s items yet\n",
		     GetEntryStringField (item->TypeTableEntry(), "ItemType"));
      delete item;
      return;
    }

  /* Close the dialog, and open the item in an item editor window */
  XtPopdown (XtParent (new_dialog));
  place_item_in_window (editor, item);
}
