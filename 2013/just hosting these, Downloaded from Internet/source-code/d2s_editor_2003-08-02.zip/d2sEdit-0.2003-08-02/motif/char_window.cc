/* UI functions for managing the character window.
 *
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <time.h>
#include <Xm/Xm.h>
#include <Xm/ComboBox.h>
#include <Xm/List.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <Xm/SpinB.h>
#include "ui.h"
#include <dmalloc.h>

static void update_status_line (Widget, d2sData *);
static void display_stats (Widget, d2sData *);
static void update_skill_box (Widget spinbox, d2sData *d2sp);
static void update_skills (Widget frame, d2sData *d2sp);
static void display_skills (Widget, d2sData *, int skill_set);
static void update_gold_fields (Widget topform, d2sData *d2sp);
static void assign_label_to_item_button
	(Widget button, d2sItem *, int keep_size, Pixmap empty_background);
static void assign_item_to_sci
	(Widget button, d2sItem *, int col, int row);
static void display_equipment
	(Widget form, d2sData *, const char *box_prefix,
	 d2sItem * (d2sData::*GetItemFunction) (int) const);
static void display_belt (Widget, d2sData *, int);
static void display_inventory (Widget, d2sData *);
static void display_acts (Widget form, d2sData *, int difficulty);
static void display_waypoints (Widget, d2sData *, int difficulty);
static void update_quests (Widget form, d2sData *, int difficulty);
static void display_quests (Widget, d2sData *, int difficulty);
static void update_quest_edit
	(Widget, d2sData *, int difficulty, int act, int quest);
static void display_hireling (Widget, d2sData *);

/* Icon names -- place in the same order as the xxx_CLASS macros */
static const char *class_icon_names[NUM_CHAR_CLASSES + MAX_NUM_ACTS] = {
  "amazon_icon", "sorceress_icon", "necromancer_icon",
  "paladin_icon", "barbarian_icon", "druid_icon", "assassin_icon",
  "rogue_icon", "desert_merc_icon", "iron_wolf_icon",
  "skeleton_icon", "barbarian_merc_icon"
};
/* Character Icons */
Pixmap class_icons[NUM_CHAR_CLASSES + MAX_NUM_ACTS];
#define DEAD_ICON class_icons[NUM_CHAR_CLASSES + 3]


/* Pixmaps for empty slots in the inventory screen --
   place in the same order as the EQUIPMENT_ON_xxx macros */
static const char *slot_icon_names[MSIZE_EQUIPMENT] = {
  "empty_gem_socket", "empty_head", "empty_neck", "empty_body",
  "empty_hand", "empty_hand", "empty_finger", "empty_finger",
  "empty_waist", "empty_feet", "empty_hands",
  "empty_hand", "empty_hand"
};
static Pixmap slot_icons[MSIZE_EQUIPMENT];
Pixmap gem_socket_icon;

/* Quest icons */
static Pixmap quest_icons[MAX_NUM_ACTS][MAX_NUM_QUESTS];

/* Backgrounds for the skill page */
static const char *skill_bg_names[NUM_CHAR_CLASSES][NUM_SKILL_SETS] = {
  { "ama1", "ama2", "ama3" }, { "sor1", "sor2", "sor3" },
  { "nec1", "nec2", "nec3" }, { "pal1", "pal2", "pal3" },
  { "bar1", "bar2", "bar3" },
  { "dru1", "dru2", "dru3" }, { "ass1", "ass2", "ass3" },
};
static Pixmap skill_background;
static Pixmap skill_backgrounds[NUM_CHAR_CLASSES][NUM_SKILL_SETS];
static Pixel gray50_pixel;



/* Initialize the screens with constant data (labels).
   Most of the initial settings (hopefully) should be set correctly
   in the UID files.  The specific sections that we need to change
   (which may currently be filled in by spacers or dummy data) are:

   We don't actually need to blank out unused text fields ourself;
   instead, call ui_clear_d2sdata() which will do it for us.
   Just concentrate on the constant data.
*/
void
ui_init_display (void)
{
  int i, j, status;
  char *xpm_path;
  char make_name[8];

  /* Load backgrounds for the inventory screens. */
  for (i = 0; i < MSIZE_EQUIPMENT; i++)
    {
      if (slot_icon_names[i] != NULL)
	{
	  status = MrmFetchIconLiteral
	    (mrm_hierarchy, (String) slot_icon_names[i],
	     XtScreen (toplevel), XtDisplay (toplevel),
	     BlackPixelOfScreen (XtScreen (toplevel)),
	     WhitePixelOfScreen (XtScreen (toplevel)),
	     &slot_icons[i]);
	  if (status != MrmSUCCESS)
	    slot_icons[i] = XmUNSPECIFIED_PIXMAP;
	}
    }
  gem_socket_icon = slot_icons[0];

  /* Load our character icons */
  for (i = 0; i < (int) XtNumber (class_icons); i++)
    {
      status = MrmFetchIconLiteral
	(mrm_hierarchy, (String) class_icon_names[i],
	 XtScreen (toplevel), XtDisplay (toplevel),
	 BlackPixelOfScreen (XtScreen (toplevel)),
	 WhitePixelOfScreen (XtScreen (toplevel)),
	 &class_icons[i]);
      if (status != MrmSUCCESS)
	class_icons[i] = XmUNSPECIFIED_PIXMAP;
    }

  /* Load the quest icons */
  strcpy (make_name, "a1q1");
  for (i = 0; i < MAX_NUM_ACTS; i++)
    {
      make_name[1] = (char) ('1' + i);
      for (j = 0; j < MAX_NUM_QUESTS; j++)
	{
	  make_name[3] = (char) ('1' + j);
	  xpm_path = xfindfile ("quests", make_name, ".xpm", path_to_images);
	  if (xpm_path != NULL)
	    {
	      quest_icons[i][j] = XmGetPixmap
		(XtScreen (toplevel), xpm_path,
		 WhitePixelOfScreen (XtScreen (toplevel)),
		 BlackPixelOfScreen (XtScreen (toplevel)));
	      free (xpm_path);
	    }
	  else
	    quest_icons[i][j] = XmUNSPECIFIED_PIXMAP;
	}
    }

  /* Load the skill page backgrounds. */
  xpm_path = xfindfile ("skills", "stone", ".xpm", path_to_images);
  if (xpm_path != NULL)
    {
      skill_background = XmGetPixmap
	(XtScreen (toplevel), xpm_path,
	 WhitePixelOfScreen (XtScreen (toplevel)),
	 BlackPixelOfScreen (XtScreen (toplevel)));
      free (xpm_path);
    }
  else
    skill_background = XmUNSPECIFIED_PIXMAP;

  for (i = 0; i < NUM_CHAR_CLASSES; i++)
    for (j = 0; j < NUM_SKILL_SETS; j++)
      {
	xpm_path = xfindfile ("skills", skill_bg_names[i][j],
			      ".xpm", path_to_images);
	if (xpm_path != NULL)
	  {
	    skill_backgrounds[i][j] = XmGetPixmap
	      (XtScreen (toplevel), xpm_path,
	       WhitePixelOfScreen (XtScreen (toplevel)),
	       BlackPixelOfScreen (XtScreen (toplevel)));
	    free (xpm_path);
	  }
	else
	  skill_backgrounds[i][j] = XmUNSPECIFIED_PIXMAP;
      }

  /* This color is used on the skill frame */
  if (MrmFetchColorLiteral (mrm_hierarchy, "gray50_color",
			    XtDisplay (toplevel), (Colormap) 0,
			    &gray50_pixel)
      != MrmSUCCESS)
    {
      /* As an alternate, use the shadow color of some button */
      XtVaGetValues (XxNameToWidget (toplevel, "*menuitem_new"),
		     XmNbottomShadowColor, &gray50_pixel,
		     NULL);
    }
}

/* Define menu items which should be disabled when a file is closed
   and/or enabled when a file is opened. */
static const struct {
  const char *	name;
  Boolean	disable_on_close;
  Boolean	enable_on_open;
} menu_items[] = {
  /* Note: we won't enable the "Save" menu item
     until the file has been modified. */
  { "*menuitem_save", True, False },
  { "*menuitem_save_as", True, True },
  /* We also won't enable the "Export Item" menu item
     unless the user has selected an item in the inventory. */
  { "*menuitem_export_item", True, False },
  { "*menuitem_load_items", True, True },
  { "*menuitem_save_items", True, True },
  { "*menuitem_close", True, True },
  /* The Cut/Copy/Paste editing items won't be enabled
     until the user makes a selection. */
  { "*menuitem_cut", True, False },
  { "*menuitem_copy", True, False },
  { "*menuitem_paste", True, False },
};

/* Define statistics fields which should be cleared when a file
   is closed, and filled when a new file is opened. */
static const struct {
  const char *	name;
  int		data_type;	/* Type of the data field; one of: */
#define SF_TYPE_INT	0
#define SF_TYPE_ULONG	1
#define SF_TYPE_DBL	2
#define SF_TYPE_STRING	3
  /* WARNING: the function pointer used below
     must match the value stored in is_ul. */
  union {
    int (d2sData::*get_int_value) (void) const;
    unsigned long (d2sData::*get_ul_value) (void) const;
    double (d2sData::*get_dbl_value) (void) const;
    const char * (d2sData::*get_str_value) (void) const;
  }; // Where to get the data
} stat_fields[] = {
  { "*field_name", SF_TYPE_STRING,
    { get_str_value: &d2sData::GetCharacterName } },
  { "*field_char_class", SF_TYPE_STRING,
    { get_str_value: &d2sData::GetCharacterClassName } },
  { "*field_level", SF_TYPE_INT,
    { get_int_value: &d2sData::GetCharacterLevel } },
  { "*field_experience", SF_TYPE_ULONG,
    { get_ul_value: &d2sData::GetExperience } },
  { "*field_next_level", SF_TYPE_ULONG,
    { get_ul_value: &d2sData::GetExpNextLevel } },
  { "*field_strength", SF_TYPE_ULONG,
    { get_ul_value: &d2sData::GetStrength } },
  { "*field_energy", SF_TYPE_ULONG,
    { get_ul_value: &d2sData::GetEnergy } },
  { "*field_dexterity", SF_TYPE_ULONG,
    { get_ul_value: &d2sData::GetDexterity } },
  { "*field_vitality", SF_TYPE_ULONG,
    { get_ul_value: &d2sData::GetVitality } },
  { "*field_life_base", SF_TYPE_DBL,
    { get_dbl_value: &d2sData::GetLifeBase } },
  { "*field_life_current", SF_TYPE_DBL,
    { get_dbl_value: &d2sData::GetCurrentLife } },
  { "*field_mana_base", SF_TYPE_DBL,
    { get_dbl_value: &d2sData::GetManaBase } },
  { "*field_mana_current", SF_TYPE_DBL,
    { get_dbl_value: &d2sData::GetCurrentMana } },
  { "*field_stamina_base", SF_TYPE_DBL,
    { get_dbl_value: &d2sData::GetStaminaBase } },
  { "*field_stamina_current", SF_TYPE_DBL,
    { get_dbl_value: &d2sData::GetCurrentStamina } },
  { "*field_stat_points", SF_TYPE_INT,
    { get_int_value: &d2sData::GetStatPointsRemaining } },
};

/* Statistics fields for the hireling */
static const struct {
  const char *	name;
  unsigned long (d2sData::*get_ul_value) (void) const;
} hire_stat_fields[] = {
  { "*field_hire_level", &d2sData::GetHirelingLevel },
  { "*field_hire_experience", &d2sData::GetHirelingExperience },
  { "*field_hire_life", &d2sData::GetHirelingLife },
  { "*field_hire_strength", &d2sData::GetHirelingStrength },
  { "*field_hire_dexterity", &d2sData::GetHirelingDexterity },
  { "*field_hire_defense", &d2sData::GetHirelingDefense },
  { "*field_hire_resistances", &d2sData::GetHirelingResist },
};

/* Statistics buttons. */
static const char * const add_button_names[] = {
  "*button_add_strength", "*button_add_energy",
  "*button_add_dexterity", "*button_add_vitality"
};

/* Index equipment boxes; order matches
   item_equipment_slot_t in "../d2sItem.h" */
static const char * const equipment_button_names[] = {
  /* Index 0 isn't used */ "",
  "head", "neck", "body", "rhand", "lhand", "rfing", "lfing",
  "waist", "feet", "hands", "arhand", "alhand"
};

static const char * const ordinal_adjectives[] = {
  "First", "Second", "Third"
};

/* Clear the character window's various forms
   when there is no game loaded.  This includes;

   * The game data window (*game_data)
   * The text fields in the statistics window (*form_stats*field_XXX)
   * Basically all labels, text, and arrows in the skills window
     (*form_skills*XXXX)
   * Waypoint and quest completion checkboxes
   * Item boxes
   * Hireling's text fields and item boxes

   In addition, set the sensitivity of various item menus to correctly
   disable functions whech can't be used without a loaded file.
*/
void
ui_clear_d2sdata (Widget formchar)
{
  Widget	w, form, subform;
  int		i, n, skill, act;
  int		row, col;
  char		make_name[32];
  XmString	xmstr;
  Arg		args[1];

  xmstr = XmStringCreateLocalized ("d2sEdit");
  XtVaSetValues (formchar,
		 /* Reset the window title */
		 XmNdialogTitle, xmstr,
		 /* Clear the user data field */
		 XmNuserData, NULL,
		 NULL);
  XmStringFree (xmstr);

  /* Disable the menu items which no longer apply. */
  form = XxNameToWidget (formchar, "*menubar_char");
  for (i = 0; i < (int) XtNumber (menu_items); i++)
    if (menu_items[i].disable_on_close)
      XtVaSetValues (XxNameToWidget (form, menu_items[i].name),
		     XmNsensitive, False, NULL);

  /* Show the default read only mode. */
  XmToggleButtonSetState (XxNameToWidget (formchar, "*menuitem_read_only"),
			  options.character.edit.default_read_only, False);

  /* Make sure the Hireling's equipment box is visible
     (it is disabled for non-expansion characters) */
  XtManageChild (XxNameToWidget
		 (formchar, "*form_hireling*frame_hire_equipment"));

  /* Set all editable widgets to non-editable */
  init_character_window_insensitive (formchar);

  /* Clear the status bar and game data window */
  XmTextFieldSetString (XxNameToWidget (formchar, "*status_bar"),
			"No file loaded");
  XmTextSetString
    (XxNameToWidget (formchar, "*game_data"), "");

  form = XxNameToWidget (formchar, "*form_stats");

  /* Clear the scale bar under the Experience field. */
  XtVaSetValues (XxNameToWidget (form, "*scale_experience"),
		 XmNvalue, 0,
		 NULL);

  /* Remove the character picture */
  XtVaSetValues (XxNameToWidget (form, "*picture_char_class"),
		 XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		 NULL);

  /* Clear the toggles */
  XmToggleButtonSetState (XxNameToWidget (form, "*toggle_expansion"),
			  False, False);
  XmToggleButtonSetState (XxNameToWidget (form, "*toggle_hardcore"),
			  False, False);
  XmToggleButtonSetState (XxNameToWidget (form, "*toggle_dead"),
			  False, False);

  /* If the stat "Up" buttons don't have a picture available,
     switch to the string label. */
  for (i = 0; i < (int) XtNumber (add_button_names); i++)
    {
      Pixmap icon;
      w = XxNameToWidget (form, add_button_names[i]);
      XtVaGetValues (w, XmNlabelPixmap, &icon, NULL);
      if (icon == XmUNSPECIFIED_PIXMAP)
	XtVaSetValues (w,
		       XmNhighlightThickness, 2,
		       XmNlabelType, XmSTRING,
		       XmNshadowThickness, 2,
		       NULL);
    }

  /* Clear each of the text fields in the stats form. */
  for (i = 0; i < (int) XtNumber (stat_fields); i++)
    {
      w = XxNameToWidget (form, stat_fields[i].name);
      XmTextFieldSetString (w, "");
    }

  /* On to the skills window... */
  form = XxNameToWidget (formchar, "*frame_skills");
  /* The label for the window should be generic */
  xmstr = XmStringCreateLocalized ("Character Skills");
  XtVaSetValues (XxNameToWidget (form, "flabel_skills"),
		 XmNlabelString, xmstr,
		 NULL);
  XmStringFree (xmstr);
  form = XxNameToWidget (form, "*form_skills");
  /* The background should be blank */
  XtVaSetValues (XxNameToWidget (form, "*picture_skill_background"),
		 XmNlabelPixmap, skill_background,
		 NULL);

  for (i = 0; i < NUM_SKILL_SETS; i++)
    {
      /* The label for each skill set button should be generic */
      sprintf (make_name, "Skill\nSet %d", i + 1);
      xmstr = XmStringCreateLocalized (make_name);
      sprintf (make_name, "*button_skill_set%d", i + 1);
      w = XxNameToWidget (form, make_name);
      XtVaSetValues (w, XmNlabelString, xmstr, NULL);
      XmChangeColor (w, gray50_pixel);
      XmStringFree (xmstr);
    }

  for (skill = 0; skill < NUM_SKILLS_PER_SET; skill++)
    {
      /* All skill buttons and text are unmanaged when there is
	 no character loaded. */
      sprintf (make_name, "*label_skill%c", skill + 'a');
      XtUnmanageChild (XxNameToWidget (form, make_name));
      sprintf (make_name, "*button_skill%c", skill + 'a');
      w = XxNameToWidget (form, make_name);
      XtUnmanageChild (w);
      XtVaSetValues (w, XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		     XmNuserData, 0,
		     NULL);
      sprintf (make_name, "*spinbox_skill%c", skill + 'a');
      w = XxNameToWidget (form, make_name);
      XtUnmanageChild (w);
      XtVaSetValues (w,
		     XmNposition, 0,
		     XmNuserData, 0,
		     NULL);
      sprintf (make_name, "*field_skill%c", skill + 'a');
      w = XxNameToWidget (w, make_name);
      XtVaSetValues (w, XmNuserData, 0, NULL);
    }

  /* Don't forget to take care of the skill choices remaining */
  w = XxNameToWidget (form, "*field_skill_points");
  XmTextFieldSetString (w, "");

  /* On to the inventory window... */
  form = XxNameToWidget (formchar, "*form_inventory");
  XmTextFieldSetString (XxNameToWidget (form, "*field_gold_stash"), "");
  XmTextFieldSetString (XxNameToWidget (form, "*field_gold_stash_max"),
			"Gold Max: 50000");
  XmTextFieldSetString (XxNameToWidget (form, "*field_gold_inv"), "");
  XmTextFieldSetString (XxNameToWidget (form, "*field_gold_inv_max"),
			"Max: 10000");
  subform = XxNameToWidget (form, "*area_equipment");
  display_equipment (subform, NULL, "equip", NULL);
  /* Make sure both hands are set sensitive
     and the Expansion Set slots are visible */
  XtSetSensitive (XxNameToWidget (subform, "*box_equip_lhand"), True);
  XtSetSensitive (XxNameToWidget (subform, "*box_equip_rhand"), True);
  w = XxNameToWidget (subform, "*box_equip_alhand");
  XtSetSensitive (w, True);
  XtManageChild (w);
  w = XxNameToWidget (subform, "*box_equip_arhand");
  XtSetSensitive (w, True);
  XtManageChild (w);
  w = XxNameToWidget (form, "*box_mouse");
  XtVaSetValues (w, XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		 XmNlabelType, XmPIXMAP,
		 XmNtoolTipString, NULL,
		 XmNuserData, NULL,
		 NULL);
  XtSetArg (args[0], XmNdropSiteActivity, XmDROP_SITE_ACTIVE);
  XmDropSiteUpdate (w, args, 1);
  subform = XxNameToWidget (form, "*matrix_stash");
  for (row = 0; row < VSIZE_STASH; row++)
    for (col = 0; col < HSIZE_STASH; col++)
      {
	sprintf (make_name, "*box_stash_%d%d", row, col);
	w = XxNameToWidget (subform, make_name);
	XtVaSetValues (w, XmNheight, 28,
		       XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		       XmNlabelType, XmPIXMAP,
		       XmNtoolTipString, NULL,
		       XmNuserData, NULL,
		       /* Make sure all boxes are 1 unit square */
		       XmNwidth, 28,
		       NULL);
	XmDropSiteUpdate (w, args, 1);
	/* Make sure all boxes are visible */
	XtManageChild (w);
      }
  subform = XxNameToWidget (form, "*matrix_cube");
  for (row = 0; row < VSIZE_CUBE; row++)
    for (col = 0; col < HSIZE_CUBE; col++)
      {
	sprintf (make_name, "*box_cube_%d%d", row, col);
	w = XxNameToWidget (subform, make_name);
	XtVaSetValues (w, XmNheight, 28,
		       XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		       XmNlabelType, XmPIXMAP,
		       XmNtoolTipString, NULL,
		       XmNuserData, NULL,
		       /* Make sure all boxes are 1 unit square */
		       XmNwidth, 28,
		       NULL);
	XmDropSiteUpdate (w, args, 1);
	/* Make sure all boxes are visible */
	XtManageChild (w);
      }
  subform = XxNameToWidget (form, "*matrix_belt");
  for (col = 0; col < MSIZE_BELT; col++)
    {
      sprintf (make_name, "*box_belt_%d", col);
      w = XxNameToWidget (subform, make_name);
      XtVaSetValues (w, XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		     XmNlabelType, XmPIXMAP,
		     XmNtoolTipString, NULL,
		     XmNuserData, NULL,
		     NULL);
      XmDropSiteUpdate (w, args, 1);
      /* Make sure all boxes are visible */
      XtManageChild (w);
    }
  subform = XxNameToWidget (form, "*matrix_inventory");
  for (row = 0; row < VSIZE_INVENTORY; row++)
    for (col = 0; col < HSIZE_INVENTORY; col++)
      {
	sprintf (make_name, "*box_inv_%d%d", row, col);
	w = XxNameToWidget (subform, make_name);
	XtVaSetValues (w, XmNheight, 28,
		       XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		       XmNlabelType, XmPIXMAP,
		       XmNtoolTipString, NULL,
		       XmNuserData, NULL,
		       /* Make sure all boxes are 1 unit square */
		       XmNwidth, 28,
		       NULL);
	XmDropSiteUpdate (w, args, 1);
	/* Make sure all boxes are visible */
	XtManageChild (w);
      }
  /* Make sure the Corpse button is visible */
  XtManageChild (XxNameToWidget (form, "*button_corpse"));

  /* On to the acts window... */
  form = XxNameToWidget (formchar, "*form_acts");
  XmOptionMenuSetSelection (XxNameToWidget (form, "*option_current_act"), 0);
  XmOptionMenuSetSelection (XxNameToWidget (form, "*option_actdifficulty"), 0);
  for (act = 0; act < MAX_NUM_ACTS; act++)
    {
      sprintf (make_name, "*toggle_act%d_intro", act + 1);
      w = XxNameToWidget (form, make_name);
      XmToggleButtonSetState (w, False, False);
      n = GetNumberOfNPCsInAct (act);
      for (i = 0; i < n; i++)
	{
	  sprintf (make_name, "*toggle_act%d_npc%d", act + 1, i + 1);
	  w = XtNameToWidget (form, make_name);
	  if (w == NULL)
	    break;
	  XmToggleButtonSetState (w, False, False);
	}
      sprintf (make_name, "*toggle_act%d_exit", act + 1);
      w = XxNameToWidget (form, make_name);
      XmToggleButtonSetState (w, False, False);
    }
  /* Make sure that Act 5 is visible
     (it is disabled for non-expansion characters) */
  XtManageChild (XxNameToWidget (form, "*frame_act5"));
  XtManageChild (XxNameToWidget (form, "*optionitem_act5"));
  XtManageChild (XxNameToWidget (form, "*toggle_act4_exit"));

  /* On to the waypoints window... */
  form = XxNameToWidget (formchar, "*form_waypoints");
  XmOptionMenuSetSelection (XxNameToWidget (form, "option_wpdifficulty"), 0);
  for (act = 0; act < MAX_NUM_ACTS; act++)
    {
      sprintf (make_name, "*column_wp%d", act + 1);
      subform = XxNameToWidget (form, make_name);
      n = GetNumberOfWaypointsInAct (act);
      for (i = 0; i < n; i++)
	{
	  sprintf (make_name, "*toggle_wp%d_%d", act + 1, i + 1);
	  w = XxNameToWidget (subform, make_name);
	  XmToggleButtonSetState (w, False, False);
	}
    }
  /* Make sure that Act 5 is visible
     (it is disabled for non-expansion characters) */
  XtManageChild (XxNameToWidget (form, "*frame_wp5"));

  /* On to the quests window... */
  form = XxNameToWidget (formchar, "*form_quests");
  XmOptionMenuSetSelection (XxNameToWidget (form, "*option_qstdifficulty"), 0);
  for (act = 0; act < MAX_NUM_ACTS; act++)
    {
      sprintf (make_name, "*column_qst%d", act + 1);
      subform = XxNameToWidget (form, make_name);
      n = GetNumberOfQuestsInAct (act);
      for (i = 0; i < n; i++)
	{
	  sprintf (make_name, "*toggle_qst%d_%d", act + 1, i + 1);
	  w = XxNameToWidget (subform, make_name);
	  XmToggleButtonSetValue (w, XmUNSET, False);
	}
    }
  /* Clear and disable the quest editor */
  XtVaSetValues (XxNameToWidget (form, "*picture_quest"),
		 XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		 NULL);
  XmTextFieldSetString (XxNameToWidget (form, "*combo_qsthex*Text"), "");
  XmTextSetString (XxNameToWidget (form, "*text_describe_quest"), "");
  /* Make sure that Act 5 is visible
     (it is disabled for non-expansion characters) */
  XtManageChild (XxNameToWidget (form, "*frame_qst5"));
  /* Unmanage the quest editor window.  We never use it
     unless the user has selected a quest (and they're all disabled). */
  XtVaSetValues (XxNameToWidget (form, "*form_edit_quest"),
		 XmNuserData, -1,
		 NULL);
  XtUnmanageChild (XxNameToWidget (form, "*frame_edit_quest"));

  /* On to the hireling window... */
  form = XxNameToWidget (formchar, "*form_hireling");
  /* Remove the hireling picture */
  XtVaSetValues (XxNameToWidget (form, "*picture_hireling"),
		 XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		 NULL);
  XmToggleButtonSetState (XxNameToWidget (form, "*toggle_hire_death"),
			  False, False);
  /* Clear the scale bar under the Experience field */
  XtVaSetValues (XxNameToWidget (form, "*scale_hire_experience"),
		 XmNvalue, 0,
		 NULL);
  /* Clear each of the text fields in the hireling stats */
  for (i = 0; i < (int) XtNumber (hire_stat_fields); i++)
    XmTextFieldSetString (XxNameToWidget (form, hire_stat_fields[i].name), "");
  /* Clean the hireling's equipment area */
  subform = XxNameToWidget (form, "*area_hire_equipment");
  display_equipment (subform, NULL, "hire_equip", NULL);
  /* Clear the list of mercenary names */
  w = XxNameToWidget (form, "*combo_hire_name*List");
  XmListDeleteAllItems (w);
  XtVaSetValues (w, XmNuserData, -1, NULL);
  /* Clear the hireling's name */
  w = XxNameToWidget (form, "*combo_hire_name");
  XmTextFieldSetString (XxNameToWidget (w, "*Text"), "");
  /* Synchronize the combo box */
  XmComboBoxUpdate (w);
  /* Clear the option menus */
  XmOptionMenuSetSelection (XxNameToWidget (form, "*option_hire_class"), 0);
  XmOptionMenuSetSelection (XxNameToWidget (form, "*option_hire_ability"), 0);
  xmstr = XmStringCreateLocalized (" ");
  XtVaSetValues (XxNameToWidget (form, "*optionitem_hire_fire"),
		 XmNlabelString, xmstr,
		 NULL);
  XmStringFree (xmstr);
  XtUnmanageChild (XxNameToWidget (form, "*optionitem_hire_cold"));
  XtUnmanageChild (XxNameToWidget (form, "*optionitem_hire_ltng"));
  w = XxNameToWidget (form, "*option_hire_difficulty");
  XmOptionMenuSetSelection (w, 0); 
}

/* Fill out the character window's various forms
   with data from the saved game. */
void
display_d2sData (Widget formchar, d2sData *d2sp)
{
  Widget	form;
  int		i, difficulty;

  stdui = formchar;

  /* Set the default read only mode. */
  d2sp->read_only = (options.character.edit.default_read_only
		     && (d2sp->SourceFileName() != NULL));
  XmToggleButtonSetState (XxNameToWidget (formchar, "*menuitem_read_only"),
			  d2sp->read_only, False);

  /* Enable menu items which are now usable */
  form = XxNameToWidget (formchar, "*menubar_char");
  for (i = 0; i < (int) XtNumber (menu_items); i++)
    if (menu_items[i].enable_on_open)
      XtVaSetValues (XxNameToWidget (form, menu_items[i].name),
		     XmNsensitive, True, NULL);
  /* If this is not an expansion character,
     hide the Hireling's equipment box */
  if ( ! d2sp->is_expansion())
    XtUnmanageChild (XxNameToWidget
		     (formchar, "*form_hireling*frame_hire_equipment"));

  /* Write some useful information in the status bar */
  update_status_line (formchar, d2sp);

  /* Set each of the text fields in the stats form. */
  form = XxNameToWidget (formchar, "*form_stats");
  display_stats (form, d2sp);

  /* Display the character's picture in the stats form */
  XtVaSetValues (XxNameToWidget (form, "*picture_char_class"),
		 XmNlabelPixmap, (d2sp->has_corpse() ? DEAD_ICON
				  : class_icons[d2sp->GetCharacterClass()]),
		 NULL);

  /* Display the character state switches */
  XmToggleButtonSetState (XxNameToWidget (form, "*toggle_expansion"),
			  d2sp->is_expansion(), False);
  XmToggleButtonSetState (XxNameToWidget (form, "*toggle_hardcore"),
			  d2sp->is_hardcore(), False);
  XmToggleButtonSetState (XxNameToWidget (form, "*toggle_dead"),
			  d2sp->has_died(), False);

  /* On to the skills window... */
  form = XxNameToWidget (formchar, "*frame_skills");
  display_skills (form, d2sp, 0);

  /* On to the inventory window... */
  form = XxNameToWidget (formchar, "*form_inventory");
  display_inventory (form, d2sp);

  /* On to the acts window... */
  form = XxNameToWidget (formchar, "*form_acts");
  /* Show the data for the character's current game by default */
  difficulty = d2sp->GetCurrentDifficulty ();
  XmOptionMenuSetSelection (XxNameToWidget
			    (form, "*option_actdifficulty"), difficulty);
  display_acts (form, d2sp, difficulty);
  /* If this is not an expansion character, hide Act 5. */
  if (d2sp->NumberOfActs () < 5) {
    XtUnmanageChild (XxNameToWidget (form, "*frame_act5"));
    XtUnmanageChild (XxNameToWidget (form, "*optionitem_act5"));
    XtUnmanageChild (XxNameToWidget (form, "*toggle_act4_exit"));
  }

  /* On to the waypoints window... */
  form = XxNameToWidget (formchar, "*form_waypoints");
  XmOptionMenuSetSelection (XxNameToWidget
			    (form, "*option_wpdifficulty"), difficulty);
  display_waypoints (form, d2sp, difficulty);
  /* If this is not an expansion character, hide Act 5. */
  if (d2sp->NumberOfActs () < 5)
    XtUnmanageChild (XxNameToWidget (form, "*frame_wp5"));

  /* On to the quests window... */
  form = XxNameToWidget (formchar, "*form_quests");
  XmOptionMenuSetSelection (XxNameToWidget
			    (form, "*option_qstdifficulty"), difficulty);
  display_quests (form, d2sp, difficulty);
  /* If this is not an expansion character, hide Act 5. */
  if (d2sp->NumberOfActs () < 5)
    XtUnmanageChild (XxNameToWidget (form, "*frame_qst5"));

  /* On to the hireling window... */
  form = XxNameToWidget (formchar, "*form_hireling");
  display_hireling (form, d2sp);

  /* Initialize the editability of all widgets if the game is not read-only
     (if it is, the widgets were set insensitive by ui_clear_d2sdata). */
  if (!d2sp->read_only)
    update_character_window_sensitive (d2sp);
}

/* Update the status line */
static void
update_status_line (Widget window, d2sData *d2sp)
{
  int		i;
  time_t	tt;
  const char *	cstr;
  char		strbuf[160];

  cstr = d2sp->GetCharacterTitle ();
  i = snprintf (strbuf, sizeof (strbuf), "%sharacter data for the %s%s '",
		d2sp->is_expansion() ? "Expansion Set c" : "C",
		d2sp->is_hardcore() ? "Hardcore " : "",
		d2sp->GetCharacterClassName ());
  if (*cstr)
    i += snprintf (&strbuf[i], sizeof (strbuf) - i, "%s %s",
		   cstr, d2sp->GetCharacterName ());
  else
    i += snprintf (&strbuf[i], sizeof (strbuf) - i, "%s",
		   d2sp->GetCharacterName ());
  tt = (time_t) d2sp->GetTimestamp ();
  i += snprintf (&strbuf[i], sizeof (strbuf) - i, "', %sd %s",
		 (d2sp->SourceFileName() != NULL) ? "save" : "create",
		 ctime (&tt));
  /* Be sure to remove the trailing NL from the time field */
  strbuf[--i] = '\0';
  XmTextFieldSetString (XxNameToWidget (window, "*status_bar"), strbuf);
}

/* Update the experience field based on the value of the slider. */
void
ui_slider_sync (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmScaleCallbackStruct *scale = (XmScaleCallbackStruct *) call_data;
  d2sData *d2sp;
  unsigned long new_experience;
  char numstr[16];

  stdui = client_data;

  XtVaGetValues ((Widget) client_data, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game loaded?  The slider should not be editable... */
    return;

  /* Compute the requested experience.  Remember that the slider's
     value is a percentage (+ 1 decimal place) of the current
     level's experience range. */
  new_experience = d2sp->GetExperienceMin() + (unsigned long)
    (((double) scale->value / 1000.0)
     * (d2sp->GetExperienceMax() - d2sp->GetExperienceMin()));

  /* Attempt to change the experience.  If we fail, try to restore the
     slider's value.  We can't report an error here because that could
     interfere with the button release event on the slider. */
  if (d2sp->SetExperience (new_experience) < 0)
    {
      if (scale->reason != XmCR_DRAG)
	{
	  XtVaSetValues (w, XmNvalue,
			 (int) (((double) (d2sp->GetExperience()
					   - d2sp->GetExperienceMin())
				 / (d2sp->GetExperienceMax()
				    - d2sp->GetExperienceMin()))
				* 1000.0),
			 NULL);
	}
    }

  /* Update the text field. */
  sprintf (numstr, "%lu", d2sp->GetExperience());
  XmTextFieldSetString
    (XxNameToWidget ((Widget) client_data, "*form_stats*field_experience"),
     numstr);
}

/* Update the fields in the stats form. */
static void
display_stats (Widget form, d2sData *d2sp)
{
  Widget	text_field, scale;
  int		i, perc, old_perc;
  char		field_value[16], *old_value;
  Arg		args[4];

  for (i = 0; i < (int) XtNumber (stat_fields); i++)
    {
      text_field = XxNameToWidget (form, stat_fields[i].name);
      switch ((int) stat_fields[i].data_type)
	{
	case SF_TYPE_INT:
	  sprintf (field_value, "%d",
		   (d2sp->*stat_fields[i].get_int_value) ());
	  break;
	case SF_TYPE_ULONG:
	  sprintf (field_value, "%lu",
		   (d2sp->*stat_fields[i].get_ul_value) ());
	  break;
	case SF_TYPE_DBL:
	  sprintf (field_value, "%g",
		   (d2sp->*stat_fields[i].get_dbl_value) ());
	  break;
	case SF_TYPE_STRING:
	  snprintf (field_value, sizeof (field_value), "%s",
		   (d2sp->*stat_fields[i].get_str_value) ());
	  break;
	default:
	  field_value[0] = '\0';
	  break;
	}
      old_value = XmTextFieldGetString (text_field);
      if (strcmp (field_value, old_value) != 0)
	XmTextFieldSetString (text_field, field_value);
      XtFree (old_value);
    }

  /* Enable the scale bar under the Experience field. */
  scale = XxNameToWidget (form, "*scale_experience");
  XtVaGetValues (scale,
		 XmNvalue, &old_perc,
		 NULL);
  i = 0;
  perc = (int) (((double) (d2sp->GetExperience() - d2sp->GetExperienceMin())
		 / (double) (d2sp->GetExperienceMax()
			     - d2sp->GetExperienceMin()))
		* 1000.0);
  if (perc < 0)
    perc = 0;
  else if (perc > 1000)
    perc = 1000;
  if (perc != old_perc)
    {
      XtSetArg (args[i], XmNvalue, perc);
      i++;
    }
  if (i)
    XtSetValues (scale, args, i);

  /* Update the sensitivity of items in the stats frame */
  update_character_form_sensitive (d2sp, "*form_stats");
}

/* After a text field in the stats window is changed and accepted,
   attempt to make the modification to the saved game. */
void
ui_stat_changed_name (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;
  char *	new_name;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  new_name = XmTextFieldGetString (w);
  if (!*new_name) {
    /* The field is empty; the user must have deleted
       the previous name.  Put the old name back. */
    XtFree (new_name);
    XmTextFieldSetString (w, (char *) d2sp->GetCharacterName());
    return;
  }

  if (strcmp (new_name, d2sp->GetCharacterName()) == 0)
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's name. */
  if (d2sp->SetCharacterName (new_name) < 0)
    {
      XmTextFieldSetString (w, (char *) d2sp->GetCharacterName());
      display_error (d2sp->GetErrorMessage());
      return;
    }
}

void
ui_stat_changed_title (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  print_message ("Stub function ui_stat_changed_title called\n");

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;
}

void
ui_stat_changed_level (Widget w, XtPointer client_data, XtPointer call_data)
{
  int		new_level;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%d", d2sp->GetCharacterLevel());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_level = atoi (text);
  XtFree (text);

  if (new_level == d2sp->GetCharacterLevel())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's level. */
  if (d2sp->SetCharacterLevel (new_level) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%d", d2sp->GetCharacterLevel());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats and skills windows */
  if (options.character.link.level_stats
      || options.character.link.level_experience)
    display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
  if (options.character.link.level_stats)
    update_skills (XxNameToWidget (docwindow, "*form_skills"), d2sp);
  update_gold_fields (XxNameToWidget (docwindow, "*form_inventory"), d2sp);
}

void
ui_stat_changed_experience (Widget w, XtPointer client_data,
			    XtPointer call_data)
{
  unsigned long	new_experience;
  int		old_level;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetExperience());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_experience = strtoul (text, NULL, 10);
  XtFree (text);

  if (new_experience == d2sp->GetExperience())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's experience. */
  old_level = d2sp->GetCharacterLevel();
  if (d2sp->SetExperience (new_experience) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetExperience());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* If the level has changed as well, we also need to
     update the stats and skills windows */
  if (d2sp->GetCharacterLevel() != old_level)
    {
      display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
      if (options.character.link.level_stats)
	update_skills (XxNameToWidget (docwindow, "*form_skills"), d2sp);
    }
}

void
ui_toggle_expansion (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;
  XmToggleButtonCallbackStruct *cbs
    = (XmToggleButtonCallbackStruct *) call_data;
  int		row, col;
  char		make_name[32];
  Widget	frame, box;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Quick check for read only.  If so, just reset the toggle. */
  if (d2sp->read_only || !options.character.edit.expansion)
    {
      XmToggleButtonSetState (w, d2sp->is_expansion(), False);
      display_error (options.character.edit.expansion
		     ? "%s is read-only"
		     : "Can't convert between Expansion and Standard",
		     d2sp->GetCharacterName());
      return;
    }

  if (cbs->set)
    {
      /* In either case, confirm the action, because this change
	 affects a whole lot of the rest of the character. */
      if (!display_question
	  (0, 2, "No", "Yes", "Are you sure you want to convert %s"
	   " to an Expansion character?  Once the conversion is done,"
	   " it will be difficult to change it back to a standard game.",
	   d2sp->GetCharacterName()))
	{
	  XmToggleButtonSetState (w, d2sp->is_expansion(), False);
	  return;
	}
      /* Make the change */
      if (d2sp->ConvertToExpansion() < 0)
	{
	  XmToggleButtonSetState (w, d2sp->is_expansion(), False);
	  display_error (d2sp->GetErrorMessage());
	  return;
	}

      /* Show the frames for Act 5 */
      frame = XxNameToWidget (docwindow, "*form_acts");
      XtManageChild (XxNameToWidget (frame, "*frame_act5"));
      XtManageChild (XxNameToWidget (frame, "*optionitem_act5"));
      XtManageChild (XxNameToWidget (frame, "*toggle_act4_exit"));
      XtManageChild (XxNameToWidget (docwindow, "*form_waypoints*frame_wp5"));
      XtManageChild (XxNameToWidget (docwindow, "*form_quests*frame_qst5"));

      /* Increase the size of the stash */
      frame = XxNameToWidget (docwindow, "*form_inventory*matrix_stash");
      for (row = VSIZE_STASH / 2; row < VSIZE_STASH; row++)
	for (col = 0; col < HSIZE_STASH; col++)
	  {
	    sprintf (make_name, "*box_stash_%d%d", row, col);
	    box = XxNameToWidget (frame, make_name);
	    XtManageChild (box);
	  }

      /* Display the extra set of hands */
      frame = XxNameToWidget (docwindow, "*form_inventory");
      XtManageChild (XxNameToWidget
		     (frame, "*area_equipment*box_equip_arhand"));
      XtManageChild (XxNameToWidget
		     (frame, "*area_equipment*box_equip_alhand"));

      /* Display the hireling's inventory */
      XtManageChild (XxNameToWidget
		     (docwindow, "*form_hireling*frame_hire_equipment"));
    }

  else
    {
      if (!display_question
	  (0, 2, "No", "Yes", "Are you sure you want to convert %s"
	   " to a standard game character?  This type of conversion"
	   " is not supported.", d2sp->GetCharacterName()))
	{
	  XmToggleButtonSetState (w, d2sp->is_expansion(), False);
	  return;
	}
      /* Make the change */
      if (d2sp->ConvertToStandard() < 0)
	{
	  XmToggleButtonSetState (w, d2sp->is_expansion(), False);
	  display_error (d2sp->GetErrorMessage());
	  return;
	}

      /* Hide the frames for Act 5 */
      frame = XxNameToWidget (docwindow, "*form_acts");
      XtUnmanageChild (XxNameToWidget (frame, "*frame_act5"));
      XtUnmanageChild (XxNameToWidget (frame, "*optionitem_act5"));
      XtUnmanageChild (XxNameToWidget (frame, "*toggle_act4_exit"));
      XtUnmanageChild (XxNameToWidget (docwindow,
				       "*form_waypoints*frame_wp5"));
      XtUnmanageChild (XxNameToWidget (docwindow, "*form_quests*frame_qst5"));

      /* Decrease the size of the stash */
      frame = XxNameToWidget (docwindow, "*form_inventory*matrix_stash");
      for (row = VSIZE_STASH / 2; row < VSIZE_STASH; row++)
	for (col = 0; col < HSIZE_STASH; col++)
	  {
	    sprintf (make_name, "*box_stash_%d%d", row, col);
	    box = XxNameToWidget (frame, make_name);
	    XtUnmanageChild (box);
	  }

      /* Remove the extra set of hands */
      frame = XxNameToWidget (docwindow, "*form_inventory");
      XtUnmanageChild (XxNameToWidget
		       (frame, "*area_equipment*box_equip_arhand"));
      XtUnmanageChild (XxNameToWidget
		       (frame, "*area_equipment*box_equip_alhand"));

      /* Remove the hireling's inventory */
      XtUnmanageChild (XxNameToWidget
		     (docwindow, "*form_hireling*frame_hire_equipment"));
    }

  /* Update the status bar */
  update_status_line (docwindow, d2sp);
}

void
ui_toggle_hardcore (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;
  XmToggleButtonCallbackStruct *cbs
    = (XmToggleButtonCallbackStruct *) call_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  if (d2sp->SetHardcore (cbs->set) < 0)
    {
      XmToggleButtonSetState (w, d2sp->is_hardcore(), False);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the status bar */
  update_status_line (docwindow, d2sp);
}

void
ui_toggle_death (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;
  Widget	button;
  XmToggleButtonCallbackStruct *cbs
    = (XmToggleButtonCallbackStruct *) call_data;
  int		skeleton;
  char		strbuf[12];

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  skeleton = d2sp->has_corpse();
  if (d2sp->SetDied (cbs->set) < 0)
    {
      XmToggleButtonSetState (w, d2sp->has_died(), False);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* If the character was previously dead,
     reset his picture. */
  if (skeleton != d2sp->has_corpse())
    {
      XtVaSetValues
	(XxNameToWidget (docwindow, "*form_stats*picture_char_class"),
	 XmNlabelPixmap, (d2sp->has_corpse() ? DEAD_ICON
			  : class_icons[d2sp->GetCharacterClass()]),
	 NULL);
      /* Also update the corpse toggle on the inventory screen
	 and the equipment display. */
      button = XxNameToWidget (docwindow, "*form_inventory*button_corpse");
      if (!d2sp->has_corpse())
	XtUnmanageChild (button);
      else
	XtManageChild (button);
      XmToggleButtonSetState (button, False, False);
      display_equipment (XxNameToWidget (docwindow, "*form_inventory"),
			 d2sp, "equip", &d2sData::GetItemEquippedOn);
    }

  /* Update the life value */
  snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetCurrentLife());
  XmTextFieldSetString (XxNameToWidget (docwindow,
					"*form_stats*field_life_current"),
			strbuf);

  /* Update the status bar */
  update_status_line (docwindow, d2sp);

  /* Update the belt (in case it was retrieved from the corpse) */
  display_belt (XxNameToWidget (docwindow, "*form_inventory"), d2sp, False);
}

void
ui_stat_changed_strength (Widget w, XtPointer client_data,
			  XtPointer call_data)
{
  unsigned long	new_strength;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetStrength());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_strength = strtoul (text, NULL, 10);
  XtFree (text);

  if (new_strength == d2sp->GetStrength())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's strength. */
  if (d2sp->SetStrength (new_strength) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetStrength());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  if (options.character.link.stats_points)
    display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_add_strength (Widget w, XtPointer client_data,
			  XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Attempt to increment the character's strength. */
  if (d2sp->SetStrength (d2sp->GetStrength() + 1) < 0)
    {
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_changed_energy (Widget w, XtPointer client_data,
			XtPointer call_data)
{
  unsigned long	new_energy;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetEnergy());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_energy = strtoul (text, NULL, 10);
  XtFree (text);

  if (new_energy == d2sp->GetEnergy())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's energy. */
  if (d2sp->SetEnergy (new_energy) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetEnergy());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  if (options.character.link.stats_points
      || options.character.link.stats_stats2)
    display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_add_energy (Widget w, XtPointer client_data,
			  XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Attempt to increment the character's energy. */
  if (d2sp->SetEnergy (d2sp->GetEnergy() + 1) < 0)
    {
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_changed_dexterity (Widget w, XtPointer client_data,
			   XtPointer call_data)
{
  unsigned long	new_dexterity;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetDexterity());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_dexterity = strtoul (text, NULL, 10);
  XtFree (text);

  if (new_dexterity == d2sp->GetDexterity())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's dexterity. */
  if (d2sp->SetDexterity (new_dexterity) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetDexterity());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  if (options.character.link.stats_points)
    display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_add_dexterity (Widget w, XtPointer client_data,
			  XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Attempt to increment the character's dexterity. */
  if (d2sp->SetDexterity (d2sp->GetDexterity() + 1) < 0)
    {
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_changed_vitality (Widget w, XtPointer client_data,
			  XtPointer call_data)
{
  unsigned long	new_vitality;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetVitality());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_vitality = strtoul (text, NULL, 10);
  XtFree (text);

  if (new_vitality == d2sp->GetVitality())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's vitality. */
  if (d2sp->SetVitality (new_vitality) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetVitality());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  if (options.character.link.stats_points
      || options.character.link.stats_stats2)
    display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_add_vitality (Widget w, XtPointer client_data,
			  XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Attempt to increment the character's vitality. */
  if (d2sp->SetVitality (d2sp->GetVitality() + 1) < 0)
    {
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_changed_life_base (Widget w, XtPointer client_data,
			   XtPointer call_data)
{
  double	new_life;
  char *	text;
  char		strbuf[16];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetLifeBase());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_life = atof (text);
  XtFree (text);

  if (new_life == d2sp->GetLifeBase())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's life. */
  if (d2sp->SetLifeBase (new_life) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetLifeBase());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  if (options.character.link.stats2_base)
    display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_changed_life_current (Widget w, XtPointer client_data,
			      XtPointer call_data)
{
  double	new_life;
  char *	text;
  char		strbuf[16];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetCurrentLife());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_life = atof (text);
  XtFree (text);

  if (new_life == d2sp->GetCurrentLife())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's life. */
  if (d2sp->SetCurrentLife (new_life) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetCurrentLife());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }
}

void
ui_stat_changed_mana_base (Widget w, XtPointer client_data,
			   XtPointer call_data)
{
  double	new_mana;
  char *	text;
  char		strbuf[16];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetManaBase());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_mana = atof (text);
  XtFree (text);

  if (new_mana == d2sp->GetManaBase())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's mana. */
  if (d2sp->SetManaBase (new_mana) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetManaBase());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  if (options.character.link.stats2_base)
    display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_changed_mana_current (Widget w, XtPointer client_data,
			      XtPointer call_data)
{
  double	new_mana;
  char *	text;
  char		strbuf[16];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetCurrentMana());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_mana = atof (text);
  XtFree (text);

  if (new_mana == d2sp->GetCurrentMana())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's mana. */
  if (d2sp->SetCurrentMana (new_mana) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetCurrentMana());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }
}

void
ui_stat_changed_stamina_base (Widget w, XtPointer client_data,
			      XtPointer call_data)
{
  double	new_stamina;
  char *	text;
  char		strbuf[16];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetStaminaBase());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_stamina = atof (text);
  XtFree (text);

  if (new_stamina == d2sp->GetStaminaBase())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's stamina. */
  if (d2sp->SetStaminaBase (new_stamina) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetStaminaBase());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the stats window */
  if (options.character.link.stats2_base)
    display_stats (XxNameToWidget (docwindow, "*form_stats"), d2sp);
}

void
ui_stat_changed_stamina_current (Widget w, XtPointer client_data,
				 XtPointer call_data)
{
  double	new_stamina;
  char *	text;
  char		strbuf[16];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetCurrentStamina());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_stamina = atof (text);
  XtFree (text);

  if (new_stamina == d2sp->GetCurrentStamina())
    /* Nothing actually changed */
    return;

  /* Attempt to change the character's stamina. */
  if (d2sp->SetCurrentStamina (new_stamina) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%g", d2sp->GetCurrentStamina());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }
}

void
ui_stat_changed_statp_remaining (Widget w, XtPointer client_data,
				 XtPointer call_data)
{
  int		new_statp;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%d", d2sp->GetStatPointsRemaining());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_statp = atoi (text);
  XtFree (text);

  if (new_statp == d2sp->GetStatPointsRemaining())
    /* Nothing actually changed */
    return;

  /* Attempt to change the stat points remaining */
  if (d2sp->SetStatPointsRemaining (new_statp) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%d",
		d2sp->GetStatPointsRemaining());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* On success, update the sensitivity of stats. */
  if (options.character.link.stats_points)
    update_character_form_sensitive (d2sp, "*form_stats");
}

void
ui_stat_changed_skillp_remaining (Widget w, XtPointer client_data,
				  XtPointer call_data)
{
  int		new_skillp;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%d", d2sp->GetSkillPointsRemaining());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_skillp = atoi (text);
  XtFree (text);

  if (new_skillp == d2sp->GetSkillPointsRemaining())
    /* Nothing actually changed */
    return;

  /* Attempt to change the skill points remaining */
  if (d2sp->SetSkillPointsRemaining (new_skillp) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%d",
		d2sp->GetSkillPointsRemaining());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* On success, update the sensitivity of skills. */
  if (options.character.link.skills_points)
    update_character_form_sensitive (d2sp, "*form_skills");
}

void
ui_stat_changed_gold_inventory (Widget w, XtPointer client_data,
				XtPointer call_data)
{
  unsigned long	new_gold;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetGoldInInventory());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_gold = strtoul (text, NULL, 10);
  XtFree (text);

  if (new_gold == d2sp->GetGoldInInventory())
    /* Nothing actually changed */
    return;

  /* Attempt to change the amount of gold */
  if (d2sp->SetGoldInInventory (new_gold) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu",
		d2sp->GetGoldInInventory());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }
}

void
ui_stat_changed_gold_stash (Widget w, XtPointer client_data,
			    XtPointer call_data)
{
  unsigned long	new_gold;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetGoldInStash());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_gold = strtoul (text, NULL, 10);
  XtFree (text);

  if (new_gold == d2sp->GetGoldInStash())
    /* Nothing actually changed */
    return;

  /* Attempt to change the amount of gold */
  if (d2sp->SetGoldInStash (new_gold) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu",
		d2sp->GetGoldInStash());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }
}

/* Update a single skill box entry (including text field and buttons) */
static void
update_skill_box (Widget spinfield, d2sData *d2sp)
{
  int		skill, old_level, new_level;
  char *	text;
  char		strbuf[4];

  /* Get the current skill level. */
  XtVaGetValues (spinfield, XmNuserData, &skill, NULL);
  if (!skill)
    /* No skills set; probably still in initialization */
    return;
  new_level = d2sp->GetSkillLevel (skill);

  /* Get the current state of the spin box.  It could save time
     if we don't have to change the setting. */
  XtVaGetValues (spinfield, XmNposition, &old_level, NULL);
  if (new_level != old_level)
    XtVaSetValues (spinfield, XmNposition, new_level, NULL);

  /* Get the current state of the text field. */
  text = XmTextFieldGetString (spinfield);
  /* Compare with the current skill level as a string */
  snprintf (strbuf, sizeof (strbuf), "%d", new_level);
  if ((strcmp (strbuf, text) != 0)
      && (new_level || (*text && (*text != '0'))))
    XmTextFieldSetString (spinfield, strbuf);
  XtFree (text);
}

/* Update the character's displayed skill data.
   This function may be called repeatedly to update the display;
   e.g., when changing a skill level from 0 to 1 (or vice-versa)
   could change what other skills are available, or when
   changing the editor options to allow/disallow setting skills
   beyond the normal range. */
static void
update_skills (Widget form, d2sData *d2sp)
{
  int		box_num;
  char		make_name[24];
  Widget	textf;
  char		*old_text;

  /* Go through all of the skills listed on the current page
     and update each one */
  for (box_num = 0; box_num < NUM_SKILLS_PER_SET; box_num++)
    {
      sprintf (make_name, "*field_skill%c", box_num + 'a');
      textf = XxNameToWidget (form, make_name);
      update_skill_box (textf, d2sp);
    }

  /* This function also updates the "skill points remaining" text field */
  textf = XxNameToWidget (form, "*field_skill_points");
  old_text = XmTextFieldGetString (textf);
  sprintf (make_name, "%d", d2sp->GetSkillPointsRemaining());
  if (strcmp (make_name, old_text) != 0)
    XmTextFieldSetString (textf, make_name);
  XtFree (old_text);

  /* Update the editability of everything on the page */
  update_character_form_sensitive (d2sp, "*form_skills");
}

/* Display the character's skill data.
   This function changes the icon, label, and position of each skill.
   It should be called when loading a character or when changing
   the skill set from one page to another. */
static void
display_skills (Widget frame, d2sData *d2sp, int skill_set)
{
  Widget	form, w;
  char		make_name[32];
  char *	str;
  const char *	cstr;
  XmString	xmstr;
  int		i, skill, button_index, x, y;
  Pixel		def_bg;
  Pixmap	skill_icon;
  table_entry_t skill_entry;

  /* The label for the window should indicate the character class */
  cstr = d2sp->SkillSetName (skill_set);
  str = (char *) XtMalloc (strlen (d2sp->GetCharacterClassName()) + 3
			   + strlen (cstr) + 1);
  sprintf (str, "%s - %s", d2sp->GetCharacterClassName(), cstr);
  xmstr = XmStringCreateLocalized (str);
  XtVaSetValues (XxNameToWidget (frame, "flabel_skills"),
		 XmNlabelString, xmstr,
		 NULL);
  XmStringFree (xmstr);
  XtFree (str);

  form = XxNameToWidget (frame, "*form_skills");

  /* Color all of the set buttons 50% gray except for the current one */
  XtVaGetValues (form, XmNbackground, &def_bg, NULL);
  for (i = 0; i < NUM_SKILL_SETS; i++)
    {
      sprintf (make_name, "*button_skill_set%d", i + 1);
      w = XxNameToWidget (form, make_name);
      if (i == skill_set)
	XmChangeColor (w, def_bg);
      else
	XmChangeColor (w, gray50_pixel);

      /* Set the button label to the name of the skill set */
      cstr = SkillSetNameWithLineBreaks (d2sp->GetCharacterClass(), i);
      xmstr = XmStringCreateLocalized ((char *) cstr);
      XtVaSetValues (w, XmNlabelString, xmstr, NULL);
      XmStringFree (xmstr);
    }

  /* Update the background to show skill dependencies */
  XtVaSetValues (XxNameToWidget (form, "*picture_skill_background"),
		 XmNlabelPixmap, (skill_backgrounds
				  [d2sp->GetCharacterClass()][skill_set]),
		 NULL);

  /* Search through all of this character's skills. */
  button_index = 'a';
  for (skill = d2sp->FirstClassSkill();
       skill <= d2sp->LastClassSkill(); skill++)
    {
      skill_entry = LookupNumericTableEntry ("skills", "Id", skill);
      if (skill_entry == NULL) {
	fprintf (stderr, "%s: Internal error: skill %d not found"
		 " in the skill table\n", progname, skill);
	continue;
      }
      /* Skip the skill if it's not on this page */
      if (GetEntryIntegerField (skill_entry, "SkillPage") - 1 != skill_set)
	continue;

      /* Get the skill's relative position on the page */
      x = (GetEntryIntegerField (skill_entry, "SkillColumn") - 1) * 128;
      y = (GetEntryIntegerField (skill_entry, "SkillRow") - 1) * 64;

      /* Grab the icon for this skill */
      sprintf (make_name, "skill_%d", skill);
      str = xfindfile ("skills", make_name, ".xpm", path_to_images);
      if (str == NULL)
	/* If we can't find the particular skill icon,
	   just name the label "Max".  It's more descriptive, anyway. */
	skill_icon = XmUNSPECIFIED_PIXMAP;
      else {
	skill_icon = XmGetPixmap (XtScreen (form), str,
				  WhitePixelOfScreen (XtScreen (form)),
				  BlackPixelOfScreen (XtScreen (form)));
	free (str);
      }
      /* Place the button and set its icon */
      sprintf (make_name, "*button_skill%c", button_index);
      w = XxNameToWidget (form, make_name);
      XtVaSetValues (w, XmNlabelPixmap, skill_icon,
		     XmNlabelType, ((skill_icon == XmUNSPECIFIED_PIXMAP)
				    ? XmSTRING : XmPIXMAP),
		     XmNuserData, skill,
		     XmNx, 7 + x,
		     XmNy, 7 + y,
		     NULL);
      if ( ! XtIsManaged (w))
	XtManageChild (w);

      /* Place the spin box / text field for this skill */
      sprintf (make_name, "*spinbox_skill%c", button_index);
      w = XxNameToWidget (form, make_name);
      XtVaSetValues (w, XmNuserData, skill,
		     XmNx, 60 + x,
		     XmNy, 8 + y,
		     NULL);
      if ( ! XtIsManaged (w))
	XtManageChild (w);
      sprintf (make_name, "*field_skill%c", button_index);
      XtVaSetValues (XxNameToWidget (w, make_name),
		     XmNuserData, skill,
		     NULL);

      /* Generate a new label for the skill. */
      sprintf (make_name, "*label_skill%c", button_index);
      w = XxNameToWidget (form, make_name);
      cstr = SkillName (skill);
      /* If the label looks like it would be too long (we only have
	 about 72 pixels between buttons), try to split it. */
      if ((strlen (cstr) > 12) && (strchr (cstr, ' ') != NULL))
	{
	  /* We won't try to split it any finer than two lines. */
	  int l = strlen (cstr) / 2;
	  str = xstrdup (cstr);
	  for (i = 0; i < l; i++)
	    {
	      if (str[l - i] == ' ')
		{
		  str[l - i] = '\n';
		  break;
		}
	      if (str[l + i] == ' ')
		{
		  str[l + i] = '\n';
		  break;
		}
	    }
	  xmstr = XmStringCreateLocalized (str);
	  free (str);
	}
      else
	xmstr = XmStringCreateLocalized ((char *) cstr);
      XtVaSetValues (w, XmNlabelString, xmstr,
		     XmNx, 60 + x,
		     XmNy, 44 + y,
		     NULL);
      XmStringFree (xmstr);
      if ( ! XtIsManaged (w))
	XtManageChild (w);

      /* Lastly, don't forget to increment the button index. */
      button_index++;
    }

  /* Now that all buttons and labels have been put in place,
     fill in the values and update the sensitivity. */
  update_skills (form, d2sp);
}

/* After the value of a text field in a spinbox has been changed and
   accepted, update the sensitivity of the spinbox arrows and the
   spinbox' internal value.  (Do NOT call this from the text field's
   XmNvalueChangedCallback, since that would be called to infinite
   recursion when we update the text field!) */
void
ui_spinbox_sync (Widget w, XtPointer client_data, XtPointer call_data)
{
  int		value, skill, min, max, oldpos, newpos;
  char *	text;
  char		strbuf[4];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to synchronize with. */
    return;

  /* Get the skill number for this field */
  XtVaGetValues (w, XmNuserData, &skill, NULL);

  /* Get the limits and the current skill level */
  min = d2sp->GetSkillMin (skill);
  max = d2sp->GetSkillMax (skill);
  oldpos = d2sp->GetSkillLevel (skill);

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; either the user has deleted the previous
       value, or this field is disabled.  If the former case, put the
       old value back. */
    print_message ("  (Empty field)");
    XtFree (text);
    if (oldpos || max) {
      print_message (" (restoring the position)");
      snprintf (strbuf, sizeof (strbuf), "%d", oldpos);
      XmTextFieldSetString (w, strbuf);
    }
    return;
  }
  value = atoi (text);
  XtFree (text);

  /* Attempt to change the skill level. */
  newpos = value;
  if (newpos != oldpos)
    {
      if (d2sp->SetSkillLevel (skill, newpos) < 0)
	display_error (d2sp->GetErrorMessage());
      newpos = d2sp->GetSkillLevel (skill);
    }

  if (newpos != value) {
    /* Update the text field to match the spin position */
    snprintf (strbuf, sizeof (strbuf), "%d", newpos);
    XmTextFieldSetString (w, strbuf);
  }

  if (newpos != oldpos)
    /* If the skill level has changed from zero to non-zero or
       vice-versa, it could affect the availability of other skills in
       the set.  In addition, in certain option modes a change in
       skill level will change the amout of skill points remaining,
       which in turn would affect all skills in all sets.  To be safe,
       redisplay all of the skills' spinboxes. */
    update_skills (XxNameToWidget (docwindow, "*form_skills"), d2sp);
}

/* After a button on a spinner has been pressed, update the sensitivity
   of the spinbox arrows and update any other affected boxes. */
void
ui_spinbox_changed (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmSpinBoxCallbackStruct *spin = (XmSpinBoxCallbackStruct *) call_data;
  int		skill, status;
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the skill number for this spinner */
  XtVaGetValues (spin->widget, XmNuserData, &skill, NULL);

  if (spin->position == d2sp->GetSkillLevel (skill))
    /* No change was actually done this time. */
    return;

  /* Attempt to change the skill level. */
  switch (spin->reason)
    {
      case XmCR_SPIN_FIRST:
	/* The user really wants the minimum value */
	status = d2sp->SetSkillLevel (skill, d2sp->GetSkillMin (skill));
	break;

    case XmCR_SPIN_LAST:
      /* The user really wants the maximum value */
      status = d2sp->SetSkillLevel (skill, d2sp->GetSkillMax (skill));
      break;

    default:
      status = d2sp->SetSkillLevel (skill, spin->position);
      break;
    }

  /* With the skill level changed, update any affected boxes.  This
     includes practically all skill boxes, plus the skill points
     remaining box. */
  update_skills (XxNameToWidget (docwindow, "*form_skills"), d2sp);
}

/* When a skill icon has been pressed, level up.
   Since providing the same function as the up arrow on the spinner
   would be redundant, and the pushbutton doesn't have the auto-
   repeat behavior that the spinner does, we'll use the button
   to maximize the skill level. */
void
ui_spinbox_up (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  int		skill;
  d2sData *	d2sp;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the skill number for this button */
  XtVaGetValues (w, XmNuserData, &skill, NULL);

  /* Attempt to increment the skill level. */
  if (d2sp->SetSkillLevel (skill, d2sp->GetSkillMax (skill)) < 0)
    {
      XBell (XtDisplay (w), 0);
      return;
    }

  /* On success, update the skill page. */
  update_skills (XxNameToWidget (docwindow, "*form_skills"), d2sp);
}

void
ui_select_skill_set (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  int		skill_set;
  d2sData *	d2sp;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to do. */
    return;

  /* The skill set index is embedded in the button */
  XtVaGetValues (w, XmNuserData, &skill_set, NULL);
  display_skills (XxNameToWidget (docwindow, "*frame_skills"),
		  d2sp, skill_set);
}

/* Update the gold fields in the inventory */
static void
update_gold_fields (Widget topform, d2sData *d2sp)
{
  Widget	w;
  char		strbuf[32];
  char *	text;

  w = XxNameToWidget (topform, "*field_gold_stash");
  sprintf (strbuf, "%lu", d2sp->GetGoldInStash ());
  text = XmTextFieldGetString (w);
  if (strcmp (text, strbuf) != 0)
    XmTextFieldSetString (w, strbuf);
  XtFree (text);
  w = XxNameToWidget (topform, "*field_gold_stash_max");
  sprintf (strbuf, "Gold Max: %lu", d2sp->GetGoldInStashMax ());
  text = XmTextFieldGetString (w);
  if (strcmp (text, strbuf) != 0)
    XmTextFieldSetString (w, strbuf);
  XtFree (text);
  w = XxNameToWidget (topform, "*field_gold_inv");
  sprintf (strbuf, "%lu", d2sp->GetGoldInInventory ());
  text = XmTextFieldGetString (w);
  if (strcmp (text, strbuf) != 0)
    XmTextFieldSetString (w, strbuf);
  XtFree (text);
  w = XxNameToWidget (topform, "*field_gold_inv_max");
  sprintf (strbuf, "Max: %lu", d2sp->GetGoldInInventoryMax ());
  text = XmTextFieldGetString (w);
  if (strcmp (text, strbuf) != 0)
    XmTextFieldSetString (w, strbuf);
  XtFree (text);
}

/* Common part of filling out the inventory:
   assign a label to an item's button. */
static void
assign_label_to_item_button (Widget button, d2sItem *item, int keep_size,
			     Pixmap empty_background)
{
  coordinate_t	size = { 1, 1 };
  char		*str;
  XmString	xmstr;
  Pixmap	item_pixmap, old_pixmap;
  Arg		args[1];

  /* Grab any prior picture in the button, so we can release it.
     Unless it's a background picture. */
  XtVaGetValues (button, XmNlabelPixmap, &old_pixmap, NULL);
  if (old_pixmap == empty_background)
    old_pixmap = XmUNSPECIFIED_PIXMAP;

  if (item != NULL)
    size = item->Size ();
  /* Set the box size to match the item size. */
  if (!keep_size)
    XtVaSetValues (button,
		   XmNheight, 29 * size.y - 1,
		   XmNwidth, 29 * size.x - 1,
		   NULL);
  else {
    XtVaGetValues (button,
		   XmNheight, &size.y,
		   XmNwidth, &size.x,
		   NULL);
    size.x = size.x / 29 + 1;
    size.y = size.y / 29 + 1;
  }

  /* Additionally, if the box is at least 2x3 units large,
     display the item's full description in place of the short name.
     If the box is 2x1 (as with belts) or 2x2, display the short name.
     If the box is only 1 unit wide, display its code instead of its name.
     Unless we have a pixmap for the item, in which case display the pixmap. */
  item_pixmap = ((item == NULL) ? empty_background
		 : load_item_picture (XtScreen (button), item));
  if ((item_pixmap == XmUNSPECIFIED_PIXMAP) && (item != NULL))
    {
      if (size.x == 1)
	xmstr = XmStringCreateLocalized ((char *) item->Code ());
      else if (size.y <= 2)
	xmstr = XmStringCreateLocalized ((char *) item->Name ());
      else
	{
	  /* This probably won't fit, but... */
	  str = item->FullDescription ();
	  xmstr = XmStringCreateLocalized (str);
	  free (str);
	}
      XtVaSetValues (button,
		     XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
		     XmNlabelString, xmstr,
		     XmNlabelType, XmSTRING,
		     /* Associate each button with its item */
		     XmNuserData, item,
		     NULL);
      XmStringFree (xmstr);
    }
  else
    {
      XtVaSetValues (button,
		     XmNlabelPixmap, item_pixmap,
		     XmNlabelType, XmPIXMAP,
		     /* Associate each button with its item */
		     XmNuserData, item,
		     NULL);
    }

  /* Add a Motif tooltip with the item's (full) name */
  if (item == NULL)
    XtVaSetValues (button, XmNtoolTipString, NULL, NULL);
  else
    {
      if (item->Type() < UNKNOWN_EXTENDED_ITEM)
	str = xstrdup (item->Name());
      else
	str = ((d2sExtendedItem *) *item)->FullName();
      xmstr = XmStringCreateLocalized (str);
      XtVaSetValues (button, XmNtoolTipString, xmstr, NULL);
      XmStringFree (xmstr);
      free (str);
    }

  /* If we removed an item, allow use of the button as a drop site.
     If we added an item, disable it as a drop site. */
  if (item != NULL)
    XtSetArg (args[0], XmNdropSiteActivity, XmDROP_SITE_INACTIVE);
  else
    XtSetArg (args[0], XmNdropSiteActivity, XmDROP_SITE_ACTIVE);
  XmDropSiteUpdate (button, args, 1);

  /* Free the old picture. */
  if (old_pixmap != XmUNSPECIFIED_PIXMAP)
    XmDestroyPixmap (XtScreen (button), old_pixmap);
}

/* Common part of filling out the inventory:
   assign an item to a button in the stash, cube, or inventory. */
static void
assign_item_to_sci (Widget button, d2sItem *item, int col, int row)
{
  coordinate_t pos;

  if (item != NULL)
    {
      pos = item->Position ();
      /* If the item position doesn't match our row/col number,
	 we are in the middle of the item.  Disable this button. */
      if ((row != pos.y) || (col != pos.x))
	{
	  if (XtIsManaged (button))
	    XtUnmanageChild (button);
	  assign_label_to_item_button (button, NULL, False,
				       XmUNSPECIFIED_PIXMAP);
	}
      else
	{
	  if (!XtIsManaged (button))
	    XtManageChild (button);
	  assign_label_to_item_button (button, item, False,
				       XmUNSPECIFIED_PIXMAP);
	}
    }
  else
    {
      /* Make sure buttons are made visible again when items are removed */
      if (!XtIsManaged (button))
	XtManageChild (button);
      assign_label_to_item_button (button, NULL, False, XmUNSPECIFIED_PIXMAP);
    }
}

/* Update an item's picture in the inventory.
   Called after changing an item. */
void
update_item_in_inventory (d2sItem *item)
{
  Widget	docwindow, form, button;
  char		make_name[32];
  const char *	matrix_name;
  coordinate_t	position, size;
  int		i, j;

  /* Get the owner's game window. */
  if (item->Owner() == NULL)
    /* No owner!  Nothing to update here. */
    return;
  docwindow = (Widget) item->Owner()->GetUI();
  if (docwindow == NULL)
    /* No document window?!
       This shouldn't happen if the item has an owner. */
    {
      fprintf (stderr, "%s: Internal error: item %s belongs to %s,\n"
	       " but %s does not have a document window\n",
	       progname, item->Name(), item->Owner()->GetCharacterName(),
	       item->Owner()->GetCharacterName());
      return;
    }
  /* There is only one exception to this--the mercenary. */
  form = XxNameToWidget (docwindow, "*form_inventory");

  /* Figure out which part of the inventory the item belongs to. */
  position = item->Position ();
  switch (item->Location())
    {
    case ITEM_AREA_EQUIPPED:
      /* If this is a belt, update the belt boxes. */
      if (position.x == EQUIPPED_ON_WAIST)
	display_belt (form, item->Owner(), False);
      /* FALLTHROUGH */
    case ITEM_AREA_CORPSE:
      /* We only need to update it if this equipment set is being displayed */
      if ((XmToggleButtonGetState
	   (XxNameToWidget (form, "*button_corpse"))
	   == XmSET) != (item->Location() == ITEM_AREA_CORPSE))
	return;
      form = XxNameToWidget (form, "*area_equipment");
      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
		equipment_button_names[position.x]);
      button = XtNameToWidget (form, make_name);
      if (button == NULL)
	/* Error in the item data? */
	return;
      assign_label_to_item_button (button, item, True, slot_icons[position.x]);

      /* If this is a two-handed-only weapon, we must likewise
	 update the other hand's picture and disable the other button. */
      if ((position.x == EQUIPPED_ON_RIGHT_HAND)
	  || (position.x == EQUIPPED_ON_ALT_RIGHT_HAND))
	{
	  if (((item->Location() == ITEM_AREA_EQUIPPED)
	       ? item->Owner()->GetItemEquippedOn (position.x + 1)
	       : item->Owner()->GetCorpseItemEquippedOn (position.x + 1))
	      == item)
	    {
	      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
			equipment_button_names[position.x + 1]);
	      button = XtNameToWidget (form, make_name);
	      assign_label_to_item_button (button, item, True,
					   slot_icons[position.x + 1]);
	      XtSetSensitive (button, False);
	    }
	}
      else if ((position.x == EQUIPPED_ON_LEFT_HAND)
	  || (position.x == EQUIPPED_ON_ALT_LEFT_HAND))
	{
	  if (((item->Location() == ITEM_AREA_EQUIPPED)
	       ? item->Owner()->GetItemEquippedOn (position.x - 1)
	       : item->Owner()->GetCorpseItemEquippedOn (position.x - 1))
	      == item)
	    {
	      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
			equipment_button_names[position.x - 1]);
	      button = XtNameToWidget (form, make_name);
	      assign_label_to_item_button (button, item, True,
					   slot_icons[position.x - 1]);
	      XtSetSensitive (button, False);
	    }
	}
      return;

    case ITEM_AREA_HIRELING:
      /* This is on a different form. */
      form = XxNameToWidget (docwindow, "*form_hireling*area_hire_equipment");
      snprintf (make_name, sizeof (make_name), "*box_hire_equip_%s",
		equipment_button_names[position.x]);
      button = XtNameToWidget (form, make_name);
      if (button == NULL)
	/* Error in the item data? */
	return;
      assign_label_to_item_button (button, item, True, slot_icons[position.x]);

      /* If this is a two-handed-only weapon, we must likewise
	 update the other hand's picture and disable the other button. */
      if ((position.x == EQUIPPED_ON_RIGHT_HAND)
	  || (position.x == EQUIPPED_ON_ALT_RIGHT_HAND))
	{
	  if (item->Owner()->GetHirelingItemEquippedOn (position.x + 1)
	      == item)
	    {
	      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
			equipment_button_names[position.x + 1]);
	      button = XtNameToWidget (form, make_name);
	      assign_label_to_item_button (button, item, True,
					   slot_icons[position.x + 1]);
	      XtSetSensitive (button, False);
	    }
	}
      else if ((position.x == EQUIPPED_ON_LEFT_HAND)
	  || (position.x == EQUIPPED_ON_ALT_LEFT_HAND))
	{
	  if (item->Owner()->GetHirelingItemEquippedOn (position.x - 1)
	      == item)
	    {
	      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
			equipment_button_names[position.x - 1]);
	      button = XtNameToWidget (form, make_name);
	      assign_label_to_item_button (button, item, True,
					   slot_icons[position.x - 1]);
	      XtSetSensitive (button, False);
	    }
	}
      return;

    case ITEM_AREA_BELT:
      form = XxNameToWidget (form, "*matrix_belt");
      snprintf (make_name, sizeof (make_name), "*box_belt_%d",
		position.x);
      button = XtNameToWidget (form, make_name);
      if (button == NULL)
	/* Error in the item data? */
	return;
      assign_label_to_item_button (button, item, True, XmUNSPECIFIED_PIXMAP);
      return;

    case ITEM_AREA_INVENTORY:
      form = XxNameToWidget (form, "*matrix_inventory");
      matrix_name = "inv";
    update_in_matrix:
      snprintf (make_name, sizeof (make_name), "*box_%s_%d%d",
		matrix_name, position.y, position.x);
      button = XtNameToWidget (form, make_name);
      if (button == NULL)
	/* Error in the item data? */
	return;
      assign_label_to_item_button (button, item, False, XmUNSPECIFIED_PIXMAP);

      /* If this item is larger than 1x1, we must disable the
	 adjacent buttons which are overlapped. */
      size = item->Size();
      for (j = 0; j < size.y; j++)
	for (i = 0; i < size.x; i++)
	  {
	    if (!i && !j)
	      continue;
	    snprintf (make_name, sizeof (make_name), "*box_%s_%d%d",
		      matrix_name, position.y + j, position.x + i);
	    button = XtNameToWidget (form, make_name);
	    if (button == NULL)
	      /* Error in the item data? */
	      return;
	    XtUnmanageChild (button);
	  }
      return;

    case ITEM_AREA_STASH:
      form = XxNameToWidget (form, "*matrix_stash");
      matrix_name = "stash";
      goto update_in_matrix;

    case ITEM_AREA_CUBE:
      form = XxNameToWidget (form, "*matrix_cube");
      matrix_name = "cube";
      goto update_in_matrix;

    case ITEM_AREA_PICKED:
      button = XxNameToWidget (form, "*box_mouse");
      assign_label_to_item_button (button, item, True, XmUNSPECIFIED_PIXMAP);
      return;

    case ITEM_AREA_SOCKETED:
      /* Socketed items are not shown in the inventory. */
      return;
    }
  /* NOTREACHED */
  return;
}

/* Remove an item's picture from the inventory.  Called *BEFORE*
   moving or removing an item (so we know where it *WAS*). */
void
remove_item_from_inventory (d2sItem *item)
{
  Widget	docwindow, form, button;
  char		make_name[32];
  const char *	matrix_name;
  coordinate_t	position, size;
  int		i, j;

  /* Get the owner's game window. */
  if (item->Owner() == NULL)
    /* No owner!  Nothing to update here. */
    return;
  docwindow = (Widget) item->Owner()->GetUI();
  if (docwindow == NULL)
    /* No document window?!
       This shouldn't happen if the item has an owner. */
    {
      fprintf (stderr, "%s: Internal error: item %s belongs to %s,\n"
	       " but %s does not have a document window\n",
	       progname, item->Name(), item->Owner()->GetCharacterName(),
	       item->Owner()->GetCharacterName());
      return;
    }
  /* There is only one exception to this--the mercenary. */
  form = XxNameToWidget (docwindow, "*form_inventory");

  /* Figure out which part of the inventory the item is being removed from. */
  position = item->Position ();
  switch (item->Location())
    {
    case ITEM_AREA_EQUIPPED:
      /* If this is a belt, update the belt boxes. */
      if (position.x == EQUIPPED_ON_WAIST)
	display_belt (form, item->Owner(), True);
      /* FALLTHROUGH */
    case ITEM_AREA_CORPSE:
      /* We only need to update it if this equipment set is being displayed */
      if ((XmToggleButtonGetState
	   (XxNameToWidget (form, "*button_corpse"))
	   == XmSET) != (item->Location() == ITEM_AREA_CORPSE))
	return;
      form = XxNameToWidget (form, "*area_equipment");
      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
		equipment_button_names[position.x]);
      button = XtNameToWidget (form, make_name);
      if (button == NULL)
	/* Error in the item data? */
	return;
      /* This function handles cleaning up the old pixmap. */
      assign_label_to_item_button (button, NULL, True, slot_icons[position.x]);

      /* If this is a two-handed-only weapon, we must likewise
	 remove the other hand's picture and enable the other button. */
      if ((position.x == EQUIPPED_ON_RIGHT_HAND)
	  || (position.x == EQUIPPED_ON_ALT_RIGHT_HAND))
	{
	  if (((item->Location() == ITEM_AREA_EQUIPPED)
	       ? item->Owner()->GetItemEquippedOn (position.x + 1)
	       : item->Owner()->GetCorpseItemEquippedOn (position.x + 1))
	      == item)
	    {
	      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
			equipment_button_names[position.x + 1]);
	      button = XtNameToWidget (form, make_name);
	      assign_label_to_item_button (button, NULL, True,
					   slot_icons[position.x + 1]);
	      XtSetSensitive (button, True);
	    }
	}
      else if ((position.x == EQUIPPED_ON_LEFT_HAND)
	  || (position.x == EQUIPPED_ON_ALT_LEFT_HAND))
	{
	  if (((item->Location() == ITEM_AREA_EQUIPPED)
	       ? item->Owner()->GetItemEquippedOn (position.x - 1)
	       : item->Owner()->GetCorpseItemEquippedOn (position.x - 1))
	      == item)
	    {
	      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
			equipment_button_names[position.x - 1]);
	      button = XtNameToWidget (form, make_name);
	      assign_label_to_item_button (button, NULL, True,
					   slot_icons[position.x - 1]);
	      XtSetSensitive (button, True);
	    }
	}
      return;

    case ITEM_AREA_HIRELING:
      /* This is on a different form. */
      form = XxNameToWidget (docwindow, "*form_hireling*area_hire_equipment");
      snprintf (make_name, sizeof (make_name), "*box_hire_equip_%s",
		equipment_button_names[position.x]);
      button = XtNameToWidget (form, make_name);
      if (button == NULL)
	/* Error in the item data? */
	return;
      assign_label_to_item_button (button, NULL, True, slot_icons[position.x]);

      /* If this is a two-handed-only weapon, we must likewise
	 update the other hand's picture and disable the other button. */
      if ((position.x == EQUIPPED_ON_RIGHT_HAND)
	  || (position.x == EQUIPPED_ON_ALT_RIGHT_HAND))
	{
	  if (item->Owner()->GetHirelingItemEquippedOn (position.x + 1)
	      == item)
	    {
	      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
			equipment_button_names[position.x + 1]);
	      button = XtNameToWidget (form, make_name);
	      assign_label_to_item_button (button, NULL, True,
					   slot_icons[position.x + 1]);
	      XtSetSensitive (button, True);
	    }
	}
      else if ((position.x == EQUIPPED_ON_LEFT_HAND)
	  || (position.x == EQUIPPED_ON_ALT_LEFT_HAND))
	{
	  if (item->Owner()->GetHirelingItemEquippedOn (position.x - 1)
	      == item)
	    {
	      snprintf (make_name, sizeof (make_name), "*box_equip_%s",
			equipment_button_names[position.x - 1]);
	      button = XtNameToWidget (form, make_name);
	      assign_label_to_item_button (button, NULL, True,
					   slot_icons[position.x - 1]);
	      XtSetSensitive (button, True);
	    }
	}
      return;

    case ITEM_AREA_BELT:
      form = XxNameToWidget (form, "*matrix_belt");
      snprintf (make_name, sizeof (make_name), "*box_belt_%d",
		position.x);
      button = XtNameToWidget (form, make_name);
      if (button == NULL)
	/* Error in the item data? */
	return;
      assign_label_to_item_button (button, NULL, True, XmUNSPECIFIED_PIXMAP);
      return;

    case ITEM_AREA_INVENTORY:
      form = XxNameToWidget (form, "*matrix_inventory");
      matrix_name = "inv";
    update_in_matrix:
      snprintf (make_name, sizeof (make_name), "*box_%s_%d%d",
		matrix_name, position.y, position.x);
      button = XtNameToWidget (form, make_name);
      if (button == NULL)
	/* Error in the item data? */
	return;
      assign_label_to_item_button (button, NULL, False, XmUNSPECIFIED_PIXMAP);

      /* If this item is larger than 1x1, we must re-enable the
	 adjacent buttons which were overlapped. */
      size = item->Size();
      for (j = 0; j < size.y; j++)
	for (i = 0; i < size.x; i++)
	  {
	    if (!i && !j)
	      continue;
	    snprintf (make_name, sizeof (make_name), "*box_%s_%d%d",
		      matrix_name, position.y + j, position.x + i);
	    button = XtNameToWidget (form, make_name);
	    if (button == NULL)
	      /* Error in the item data? */
	      return;
	    XtManageChild (button);
	  }
      return;

    case ITEM_AREA_STASH:
      form = XxNameToWidget (form, "*matrix_stash");
      matrix_name = "stash";
      goto update_in_matrix;

    case ITEM_AREA_CUBE:
      form = XxNameToWidget (form, "*matrix_cube");
      matrix_name = "cube";
      goto update_in_matrix;

    case ITEM_AREA_PICKED:
      button = XxNameToWidget (form, "*box_mouse");
      assign_label_to_item_button (button, NULL, True, XmUNSPECIFIED_PIXMAP);
      return;

    case ITEM_AREA_SOCKETED:
      /* Socketed items are not shown in the inventory. */
      return;
    }
  /* NOTREACHED */
  return;
}

/* Fill out the equipment part of the inventory.
   Can be used for character's inventory, corpse, or hireling,
   by passing the appropriate box_prefix and GetItemFunction. */
static void
display_equipment (Widget form, d2sData *d2sp, const char *box_prefix,
		   d2sItem * (d2sData::*GetItemFunction) (int) const)
{
  Widget w;
  int slot;
  char make_name[32];
  d2sItem *item;

  for (slot = 1; slot < (int) XtNumber (equipment_button_names); slot++)
    {
      /* Check the existence of the slot --
	 the hireling doesn't have them all */
      snprintf (make_name, sizeof (make_name), "*box_%s_%s",
		box_prefix, equipment_button_names[slot]);
      w = XtNameToWidget (form, make_name);
      if (w == NULL)
	continue;

      /* Get the item at this location.  If there is none,
	 restore the empty background. */
      item = (d2sp == NULL) ? NULL : (d2sp->*GetItemFunction) (slot);
      assign_label_to_item_button (w, item, True, slot_icons[slot]);
      if ((item != NULL) && (item->Position().x != slot))
	{
	  /* If the item's slot doesn't match this button,
	     it must be a two-handed weapon; disable the extra button. */
	  XtSetSensitive (w, False);
	}
    }
}

/* Fill out the belt part of the inventory.
   Call this when changed the equipped belt too. */
static void
display_belt (Widget topform, d2sData *d2sp, int remove)
{
  Widget	w, subform;
  int		slot, belt_size;
  char		make_name[32];
  d2sItem	*item;

  /* If the belt has been removed from display,
     use a size of 4.  Don't rely on d2sData::BeltSize,
     because if the belt has been removed, that won't
     be updated until after the inventory is redisplayed. */
  belt_size = remove ? 4 : d2sp->BeltSize();
  subform = XxNameToWidget (topform, "*matrix_belt");
  for (slot = 0; slot < MSIZE_BELT; slot++)
    {
      sprintf (make_name, "*box_belt_%d", slot);
      w = XxNameToWidget (subform, make_name);
      item = d2sp->GetItemFromBelt (slot);
      if ((slot >= belt_size) && (item == NULL))
	{
	  /* Disable the extra belt rows */
	  if (XtIsManaged (w))
	    XtUnmanageChild (w);
	}
      else
	{
	  if (!XtIsManaged (w))
	    XtManageChild (w);
	}
      assign_label_to_item_button (w, item, True, XmUNSPECIFIED_PIXMAP);
    }
}

/* Fill out the inventory */
static void
display_inventory (Widget topform, d2sData *d2sp)
{
  Widget w, subform;
  int col, row;
  char make_name[32];
  d2sItem *item;

  /* Start simple: fill in the amount of gold the player has */
  update_gold_fields (topform, d2sp);

  /* Fill in the equipment area next. */
  subform = XxNameToWidget (topform, "*area_equipment");
  if ( ! d2sp->is_expansion ())
    {
      /* Disable the expansion slots */
      w = XxNameToWidget (subform, "*box_equip_arhand");
      if (XtIsManaged (w))
	XtUnmanageChild (w);
      w = XxNameToWidget (subform, "*box_equip_alhand");
      if (XtIsManaged (w))
	XtUnmanageChild (w);
    }
  display_equipment (subform, d2sp, "equip", &d2sData::GetItemEquippedOn);

  /* Turn the Corpse button off */
  XmToggleButtonSetState (XxNameToWidget (topform, "*button_corpse"),
			  False, False);
  /* If the character does not have a corpse, hide the corpse button */
  if (!d2sp->has_corpse ())
    XtUnmanageChild (XxNameToWidget (topform, "*button_corpse"));

  /* Fill in the mouse item */
  w = XxNameToWidget (topform, "*box_mouse");
  item = d2sp->GetPickedItem ();
  assign_label_to_item_button (w, item, True, XmUNSPECIFIED_PIXMAP);

  /* Fill in the stash */
  subform = XxNameToWidget (topform, "*matrix_stash");
  for (row = 0; row < VSIZE_STASH; row++)
    for (col = 0; col < HSIZE_STASH; col++)
      {
	sprintf (make_name, "*box_stash_%d%d", row, col);
	w = XxNameToWidget (subform, make_name);
	if ((row >= VSIZE_STASH / 2) && !d2sp->is_expansion ())
	  {
	    /* Disable the expanded stash */
	    XtUnmanageChild (w);
	    continue;
	  }

	item = d2sp->GetItemFromStash (col, row);
	assign_item_to_sci (w, item, col, row);
      }

  /* Fill in the cube */
  subform = XxNameToWidget (topform, "*matrix_cube");
  for (row = 0; row < VSIZE_CUBE; row++)
    for (col = 0; col < HSIZE_CUBE; col++)
      {
	sprintf (make_name, "*box_cube_%d%d", row, col);
	w = XxNameToWidget (subform, make_name);

	item = d2sp->GetItemFromCube (col, row);
	assign_item_to_sci (w, item, col, row);
      }

  /* Fill in the belt */
  display_belt (topform, d2sp, False);

  /* Fill in the inventory */
  subform = XxNameToWidget (topform, "*matrix_inventory");
  for (row = 0; row < VSIZE_INVENTORY; row++)
    for (col = 0; col < HSIZE_INVENTORY; col++)
      {
	sprintf (make_name, "*box_inv_%d%d", row, col);
	w = XxNameToWidget (subform, make_name);

	item = d2sp->GetItemFromInventory (col, row);
	assign_item_to_sci (w, item, col, row);
      }
}

/* Fill out the act form for a given difficulty level. */
static void
display_acts (Widget form, d2sData *d2sp, int difficulty)
{
  Widget w;
  int act, num_acts, npc, num_npcs;
  char make_name[32];

  /* Show the current location in this difficulty level */
  XmOptionMenuSetSelection (XxNameToWidget (form, "*option_current_act"),
			    d2sp->GetCurrentAct (difficulty));
  num_acts = d2sp->NumberOfActs ();
  for (act = 0; act < num_acts; act++)
    {
      sprintf (make_name, "*toggle_act%d_intro", act + 1);
      w = XxNameToWidget (form, make_name);
      XmToggleButtonSetState (w, d2sp->GetActIntros (difficulty, act)
			      ? True : False, False);
      num_npcs = GetNumberOfNPCsInAct (act);
      for (npc = 0; npc < num_npcs; npc++)
	{
	  sprintf (make_name, "*toggle_act%d_npc%d", act + 1, npc + 1);
	  w = XtNameToWidget (form, make_name);
	  if (w == NULL)
	    break;
	  XmToggleButtonSetState
	    (w, d2sp->GetNPCIntro (difficulty, act, npc), False);
	}
      sprintf (make_name, "*toggle_act%d_exit", act + 1);
      w = XxNameToWidget (form, make_name);
      XmToggleButtonSetState (w, (d2sp->GetActCompletion (difficulty, act)
				  & 1) ? True : False, False);
    }
}

/* Toggle whether an NPC has been introduced */
void
ui_toggle_act_intro (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	form;
  int		difficulty, act;
  d2sData *	d2sp;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the act number for this toggle */
  XtVaGetValues (w, XmNuserData, &act, NULL);

  /* We also need the current difficulty from the option menu */
  form = XxNameToWidget (docwindow, "*form_acts");
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget (form, "*option_actdifficulty"));

  if (d2sp->SetActIntros (difficulty, act, XmToggleButtonGetState (w)) < 0)
    {
      XmToggleButtonSetState
	(w, d2sp->GetActIntros (difficulty, act) != 0, False);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the acts if they were linked to changes in acts */
  if (options.character.link.act_entry && options.character.link.auto_act)
    {
      display_acts (form, d2sp, difficulty);
      /* Update the town waypoints if they are set automatically */
      if (options.character.link.act_waypoint)
	{
	  form = XxNameToWidget (docwindow, "*form_waypoints");
	  if (difficulty == XmOptionMenuGetSelection
	      (XxNameToWidget (form, "*option_wpdifficulty")))
	    display_waypoints (form, d2sp, difficulty);
	}
      /* Update the quest states if they were linked to acts */
      if (options.character.link.act_quest
	  && options.character.link.auto_quest)
	{
	  form = XxNameToWidget (docwindow, "*form_quests");
	  if (difficulty == XmOptionMenuGetSelection
	      (XxNameToWidget (form, "*option_qstdifficulty")))
	    update_quests (form, d2sp, difficulty);
	}
    }
}

void
ui_toggle_npc_intro (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	form;
  int		difficulty, act, npc;
  d2sData *	d2sp;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the act & NPC number for this toggle */
  XtVaGetValues (w, XmNuserData, &npc, NULL);
  act = npc / 100;
  npc = npc % 100;

  /* We also need the current difficulty from the option menu */
  form = XxNameToWidget (docwindow, "*form_acts");
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget (form, "*option_actdifficulty"));

  if (d2sp->SetNPCIntro (difficulty, act, npc,
			 XmToggleButtonGetState (w)) < 0)
    {
      XmToggleButtonSetState
	(w, d2sp->GetNPCIntro (difficulty, act, npc) != 0, False);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the acts if they were linked to changes in acts */
  if (options.character.link.act_entry && options.character.link.auto_act)
    {
      display_acts (form, d2sp, difficulty);
      /* Update the town waypoints if they are set automatically */
      if (options.character.link.act_waypoint)
	{
	  form = XxNameToWidget (docwindow, "*form_waypoints");
	  if (difficulty == XmOptionMenuGetSelection
	      (XxNameToWidget (form, "*option_wpdifficulty")))
	    display_waypoints (form, d2sp, difficulty);
	}
      /* Update the quest states if they were linked to acts */
      if (options.character.link.act_quest
	  && options.character.link.auto_quest)
	{
	  form = XxNameToWidget (docwindow, "*form_quests");
	  if (difficulty == XmOptionMenuGetSelection
	      (XxNameToWidget (form, "*option_qstdifficulty")))
	    update_quests (form, d2sp, difficulty);
	}
    }
}

void
ui_toggle_act_exit (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	form;
  int		difficulty, act;
  d2sData *	d2sp;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the act number for this toggle */
  XtVaGetValues (w, XmNuserData, &act, NULL);

  /* We also need the current difficulty from the option menu */
  form = XxNameToWidget (docwindow, "*form_acts");
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget (form, "*option_actdifficulty"));

  if (d2sp->SetActCompletion
      (difficulty, act, XmToggleButtonGetState (w)) < 0)
    {
      XmToggleButtonSetState
	(w, d2sp->GetActCompletion (difficulty, act) & 1, False);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the other acts if they were linked to changes in acts */
  if (options.character.link.act_entry && options.character.link.auto_act)
    {
      display_acts (form, d2sp, difficulty);
      /* Update *all* the waypoints;
	 un-exiting an act may turn them all off */
      form = XxNameToWidget (docwindow, "*form_waypoints");
      if (difficulty == XmOptionMenuGetSelection
	  (XxNameToWidget (form, "*option_wpdifficulty")))
	display_waypoints (form, d2sp, difficulty);
      /* Update the quest states */
      form = XxNameToWidget (docwindow, "*form_quests");
      if (difficulty == XmOptionMenuGetSelection
	  (XxNameToWidget (form, "*option_qstdifficulty")))
	update_quests (form, d2sp, difficulty);
    }
}

/* Fill out the waypoint form for a given difficulty level. */
static void
display_waypoints (Widget form, d2sData *d2sp, int difficulty)
{
  Widget w, subform;
  int act, num_acts, point, num_points;
  char make_name[32];

  num_acts = d2sp->NumberOfActs ();
  for (act = 0; act < num_acts; act++)
    {
      sprintf (make_name, "*column_wp%d", act + 1);
      subform = XxNameToWidget (form, make_name);
      num_points = GetNumberOfWaypointsInAct (act);
      for (point = 0; point < num_points; point++)
	{
	  sprintf (make_name, "*toggle_wp%d_%d", act + 1, point + 1);
	  w = XxNameToWidget (subform, make_name);
	  XmToggleButtonSetState
	    (w, d2sp->GetWaypoint (difficulty, act, point), False);
	}
    }
}

/* Turn a waypoint on or off */
void
ui_toggle_waypoint (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	form;
  int		difficulty, act, point;
#if 0
  char *	text;
#endif
  d2sData *	d2sp;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the act & waypoint number for this toggle */
  XtVaGetValues (w, XmNuserData, &point, NULL);
  act = point / 10;
  point = point % 10;

#if 0
  /* This is sort of a hack, but it's easier than trying to pass
     a structure through client_data using UIL.  Extract the act
     and waypoint number from the widget name. */
  text = XtName (w);
  act = text[9 /* strlen ("toggle_wp") */] - '1';
  point = text[11 /* strlen ("toggle_wp1_") */] - '1';
#endif

  /* We also need the current difficulty from the option menu */
  form = XxNameToWidget (docwindow, "*form_waypoints");
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget (form, "*option_wpdifficulty"));

#if 0
  if ((d2sp->GetWaypoint (difficulty, act, point) != False)
      == (XmToggleButtonGetState (w) != False))
    /* Nothing actually changed. */
    return;
#endif

  /* Attempt to change the waypoint */
  if (d2sp->SetWaypoint (difficulty, act, point,
			 XmToggleButtonGetState (w)) < 0)
    {
      XmToggleButtonSetState (w, d2sp->GetWaypoint (difficulty, act, point),
			      False);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the acts if they were linked to changes in acts */
  if (options.character.link.act_entry && options.character.link.auto_act)
    {
      /* Update the town waypoints if they are set automatically */
      if (options.character.link.act_waypoint)
	display_waypoints (form, d2sp, difficulty);
      form = XxNameToWidget (docwindow, "*form_acts");
      if (difficulty == XmOptionMenuGetSelection
	  (XxNameToWidget (form, "*option_actdifficulty")))
	display_acts (form, d2sp, difficulty);
      /* Update the quest states if they were linked to acts */
      if (options.character.link.act_quest
	  && options.character.link.auto_quest)
	{
	  form = XxNameToWidget (docwindow, "*form_quests");
	  if (difficulty == XmOptionMenuGetSelection
	      (XxNameToWidget (form, "*option_qstdifficulty")))
	    update_quests (form, d2sp, difficulty);
	}
    }
}

/* Update the quest checkboxes in the quest form */
static void
update_quests (Widget form, d2sData *d2sp, int difficulty)
{
  Widget w, subform;
  int act, num_acts, quest, num_quests, data;
  char make_name[32];

  num_acts = d2sp->NumberOfActs ();
  for (act = 0; act < num_acts; act++)
    {
      sprintf (make_name, "*column_qst%d", act + 1);
      subform = XxNameToWidget (form, make_name);
      num_quests = GetNumberOfQuestsInAct (act);
      for (quest = 0; quest < num_quests; quest++)
	{
	  sprintf (make_name, "*toggle_qst%d_%d", act + 1, quest + 1);
	  w = XxNameToWidget (subform, make_name);
	  data = d2sp->GetQuestData (difficulty, act, quest);
	  XmToggleButtonSetValue
	     /* If the data field is 0, the quest hasn't been started.
		If bit 0 is set, the quest has been completed. */
	    (w, data ? ((data & 1) ? XmSET : XmINDETERMINATE) : XmUNSET,
	     False);
	}
    }

  /* Update the quest editor frame too
     (it may have been altered as a side effect of dependencies) */
  subform = XxNameToWidget (form, "*form_edit_quest");
  XtVaGetValues (subform, XmNuserData, &quest, NULL);
  if (quest >= 0)
    {
      act = quest / 10;
      quest = quest % 10;
      update_quest_edit (form, d2sp, difficulty, act, quest);
    }
}

/* Fill out the quest form for a given difficulty level. */
static void
display_quests (Widget form, d2sData *d2sp, int difficulty)
{
  /* Unmanage the quest editor window.  We'll put it back
     once we have a selection to put in it. */
  XtVaSetValues (XxNameToWidget (form, "*form_edit_quest"),
		 XmNuserData, -1,
		 NULL);
  XtUnmanageChild (XxNameToWidget (form, "*frame_edit_quest"));

  /* This function does most of the work */
  update_quests (form, d2sp, difficulty);
}

/* Update the text in a quest edit form after quest data has changed */
static void
update_quest_edit (Widget topform, d2sData *d2sp,
		   int difficulty, int act, int quest)
{
  int		data;
  char		*strbuf;
  const char	*cstr, *state;
  char		make_name[24];

  /* Get the value and state of the quest */
  data = d2sp->GetQuestData (difficulty, act, quest);
  state = d2sp->GetQuestState (difficulty, act, quest);

  /* The hex value and short description goes in the text field */
  if (state != NULL) {
    cstr = GetQuestStateDesc (state);
    strbuf = (char *) xmalloc (sizeof ("%.4x: ") + strlen (cstr) + 1);
    sprintf (strbuf, "%.4x: %s", data, cstr);
  } else {
    strbuf = (char *) xmalloc (sizeof ("%.4x") + 1);
    sprintf (strbuf, "%.4x", data);
  }
  XmTextFieldSetString (XxNameToWidget (topform, "*combo_qsthex*Text"),
			strbuf);
  free (strbuf);
  /* Synchronize the combo box */
  XmComboBoxUpdate (XxNameToWidget (topform, "*combo_qsthex"));

  /* The long description goes in the scrolled text box */
  if (state != NULL)
    cstr = GetQuestLogEntry (state);
  else
    cstr = "";
  XmTextSetString (XxNameToWidget (topform, "*text_describe_quest"),
		   (char *) cstr);

  /* Update the check mark */
  sprintf (make_name, "*toggle_qst%d_%d", act + 1, quest + 1);
  XmToggleButtonSetValue
    (XxNameToWidget (topform, make_name),
     data ? ((data & 1) ? XmSET : XmINDETERMINATE) : XmUNSET,
     False);
}

void
ui_set_read_only (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  d2sData *	d2sp;

  stdui = docwindow;

  /* Change the default read only state for newly loaded characters */
  options.character.edit.default_read_only = XmToggleButtonGetState (w);

  /* Get the game data from the document. */
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* This document doesn't have an associated game! */
    return;

  d2sp->read_only = XmToggleButtonGetState (w);

  /* Update the editability of the entire character window
     and all of the character's item windows */
  update_character_window_sensitive (d2sp);
}

void
ui_swap_corpse_inventory (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data;
  Widget subform;
  d2sData *d2sp;

  stdui = docwindow;

  /* Get the game data from the document. */
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* This document doesn't have an associated game! */
    return;

  subform = XxNameToWidget (docwindow, "*area_equipment");
  /* Are we displaying the living or the dead? */
  if (XmToggleButtonGetState (XxNameToWidget (docwindow, "*button_corpse")))
    display_equipment (subform, d2sp, "equip",
		       &d2sData::GetCorpseItemEquippedOn);
  else
    display_equipment (subform, d2sp, "equip", &d2sData::GetItemEquippedOn);
}

void
ui_set_act_location (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data, form;
  short difficulty, location;
  d2sData *d2sp;

  stdui = docwindow;

  /* Get the game data from the document. */
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* This document doesn't have an associated game! */
    return;

  /* Get the requested location from the widget that called us */
  XtVaGetValues (w, XmNpositionIndex, &location, NULL);
  /* Get the player's current difficulty from the acts form */
  form = XxNameToWidget (docwindow, "*form_acts");
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget (form, "*option_actdifficulty"));

  /* Make the change */
  if (d2sp->SetCurrentAct (difficulty, location) < 0)
    {
      XmOptionMenuSetSelection (XxNameToWidget (form, "*option_current_act"),
				 d2sp->GetCurrentAct (difficulty));
      display_error (d2sp->GetErrorMessage());
    }
}

void
ui_show_actdifficulty (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data, form;
  short difficulty;
  d2sData *d2sp;

  stdui = docwindow;

  XtVaGetValues (w, XmNpositionIndex, &difficulty, NULL);
  form = XxNameToWidget (docwindow, "*form_acts");

  /* Get the game data from the document. */
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* This document doesn't have an associated game! */
    return;

  /* Change the form */
  display_acts (form, d2sp, difficulty);
}

void
ui_show_wpdifficulty (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data, form;
  short difficulty;
  d2sData *d2sp;

  stdui = docwindow;

  XtVaGetValues (w, XmNpositionIndex, &difficulty, NULL);
  form = XxNameToWidget (docwindow, "*form_waypoints");

  /* Get the game data from the document. */
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* This document doesn't have an associated game! */
    return;

  /* Change the form */
  display_waypoints (form, d2sp, difficulty);
}

void
ui_show_qstdifficulty (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data, form;
  short difficulty;
  d2sData *d2sp;

  stdui = docwindow;

  XtVaGetValues (w, XmNpositionIndex, &difficulty, NULL);
  form = XxNameToWidget (docwindow, "*form_quests");

  /* Get the game data from the document. */
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* This document doesn't have an associated game! */
    return;

  /* Change the form */
  display_quests (form, d2sp, difficulty);
}

void
ui_select_quest (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow, form, combo_widget, list_widget;
  int		difficulty, act, quest, data;
  struct quest_value *data_list;
  int		list_count;
  d2sData	*d2sp;
  char		*strbuf;
  XmString	xmstr;

  docwindow = (Widget) client_data;
  form = XxNameToWidget (docwindow, "*form_edit_quest");
  stdui = docwindow;

  /* Get the game data from the document. */
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* This document doesn't have an associated game! */
    return;

  /* Get the act and quest number from the toggle */
  XtVaGetValues (w, XmNuserData, &quest, NULL);
  act = quest / 10;
  quest = quest % 10;

  /* Compare it with the number currently set on the form */
  XtVaGetValues (form, XmNuserData, &data, NULL);
  if (data < 0)
    /* The quest edit form is not currently displayed.  Manage it. */
    XtManageChild (XxNameToWidget (docwindow, "*frame_edit_quest"));
  if (data != act * 10 + quest)
    {
      /* Display the selected quest */
      XtVaSetValues (form, XmNuserData, act * 10 + quest, NULL);
      XtVaSetValues (XxNameToWidget (form, "*picture_quest"),
		     XmNlabelPixmap, quest_icons[act][quest],
		     NULL);
      xmstr = XmStringCreateLocalized ((char *) GetQuestName (act, quest));
      XtVaSetValues (XxNameToWidget (docwindow, "*flabel_edit_quest"),
		     XmNlabelString, xmstr,
		     NULL);
      XmStringFree (xmstr);

      /* Reset the drop-down list to include the list of known hex values */
      combo_widget = XxNameToWidget (form, "*combo_qsthex");
      list_widget = XxNameToWidget (combo_widget, "*List");
      XmListDeleteAllItems (list_widget);
      list_count = GetQuestValues (act, quest, &data_list);
      for (data = 0; data < list_count; data++)
	{
	  strbuf = (char *) xmalloc
	    (sizeof ("%.4x: ") + strlen (data_list[data].description) + 1);
	  sprintf (strbuf, "%.4x: %s", data_list[data].value,
		   data_list[data].description);
	  xmstr = XmStringCreateLocalized (strbuf);
	  XmListAddItem (list_widget, xmstr, 0);
	  XmStringFree (xmstr);
	  free (strbuf);
	}
      free (data_list);
      XtVaSetValues (combo_widget,
		     XmNvisibleItemCount, (list_count < 8) ? list_count : 8,
		     XmNrightAttachment, XmATTACH_NONE,
		     NULL);
      /* The list widget resizes the text field when we change list items.
	 This moves the drop-down arrow, which is a bad thing.
	 We need to keep the text field's size. */
      XtVaSetValues (combo_widget, XmNrightAttachment, XmATTACH_FORM, NULL);
    }

  /* Update the drop-down list and quest log */
  form = XxNameToWidget (docwindow, "*form_quests");
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget (form, "*option_qstdifficulty"));
  update_quest_edit (form, d2sp, difficulty, act, quest);
}

void
ui_quest_changed_hex (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	form = XxNameToWidget (docwindow, "*form_quests");
  int		difficulty, act, quest, data, old_data;
  static int	recursive = 0;
  d2sData *	d2sp;
  char *	str;

  stdui = docwindow;
  if (recursive)
    return;
  recursive++;

  /* Get the game data from the document. */
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL) {
    /* This document doesn't have an associated game! */
    recursive--;
    return;
  }

  /* Get the difficulty from the option menu */
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget (docwindow, "*option_qstdifficulty"));
  /* Get the act and quest number from the edit form */
  XtVaGetValues (XxNameToWidget (form, "*form_edit_quest"),
		 XmNuserData, &quest,
		 NULL);
  act = quest / 10;
  quest = quest % 10;

  /* Get the value of the hex field in the text box.
     (This callback may be called by either the text field or the combo list,
     so we have to look up the text field to be sure.) */
  str = XmTextFieldGetString (XxNameToWidget (form, "*combo_qsthex*Text"));
  data = strtol (str, NULL, 16);

  /* If the new value differs from the current one,
     attempt to change the quest data. */
  old_data = d2sp->GetQuestData (difficulty, act, quest);
  if (data != old_data)
    d2sp->SetQuestData (difficulty, act, quest, data);

  /* Whether the value itself changed or not, update the quest edit form,
     because some values can have different states.  We also update
     the toggles for all quests, in case of automated dependency changes.
     This function takes care of both. */
  update_quests (form, d2sp, difficulty);
  if (data != old_data)
    {
      /* Update the acts and waypoints forms
	 in case they were changed by dependencies. */
      if (options.character.link.act_entry && options.character.link.auto_act)
	{
	  form = XxNameToWidget (docwindow, "*form_acts");
	  if (difficulty == XmOptionMenuGetSelection
	      (XxNameToWidget (form, "*option_actdifficulty")))
	    display_acts (form, d2sp, difficulty);
	  form = XxNameToWidget (docwindow, "*form_waypoints");
	  if (difficulty == XmOptionMenuGetSelection
	      (XxNameToWidget (form, "*option_wpdifficulty")))
	    display_waypoints (form, d2sp, difficulty);
	}
      /* Lastly, update the inventory in case quest items had to be changed */
      if (options.character.link.quest_inventory)
	{
	  form = XxNameToWidget (docwindow, "*form_inventory");
	  display_inventory (form, d2sp);
	}
    }
  recursive--;
  return;
}

static void
display_hireling (Widget form, d2sData *d2sp)
{
  Widget	combo, w;
  Pixmap	picture, old_picture;
  table_entry_t hireling_entry;
  const char	*cstr;
  XmString	xmstr;
  int		i, j, n, merc_class, old_class, perc, old_perc;
  char		field_value[16], *old_value;
  StringList	name_list;
  static const char * const hire_ability_opt[MAX_NUM_ACTS] = {
    "*optionitem_hire_fire", "*optionitem_hire_cold", "*optionitem_hire_ltng"
  };

  hireling_entry = d2sp->GetHirelingTableEntry();
  merc_class = GetEntryIntegerField (hireling_entry, "Act") - 1;

  /* Update the hireling's picture */
  w = XxNameToWidget (form, "*picture_hireling");
  if (d2sp->hireling_is_dead() && d2sp->is_expansion())
    picture = DEAD_ICON;
  else if (merc_class < 0)
    /* There is no hireling */
    picture = XmUNSPECIFIED_PIXMAP;
  else
    picture = class_icons[NUM_CHAR_CLASSES + merc_class];
  XtVaGetValues (w, XmNlabelPixmap, &old_picture, NULL);
  if (picture != old_picture)
    XtVaSetValues (w, XmNlabelPixmap, picture, NULL);

  w = XxNameToWidget (form, "*toggle_hire_death");
  XmToggleButtonSetState (w, d2sp->hireling_is_dead(), False);

  /* Update the list of hireling names.  The list widget also holds
     the act number where the hireling came from, which tells us
     whether the list needs changing. */
  combo = XxNameToWidget (form, "*combo_hire_name");
  w = XxNameToWidget (combo, "*List");
  XtVaGetValues (w, XmNuserData, &old_class, NULL);
  if (merc_class != old_class)
    {
      /* Get the new list of hireling names */
      name_list = d2sp->GetAllHirelingNames();
      install_names_in_dropdown_list (combo, name_list);
      /* Update the mercenary class on the list widget */
      XtVaSetValues (w, XmNuserData, merc_class, NULL);

      /* Update the option menu for the hireling's special ability */
      /* (Hard-coded for now;
	 can't think of a good way to get these in lists) */
      j = 0;
      n = 0;
      switch (merc_class) {
      case 0:	/* Rogue Scout */	j = 0; n = 2; break;
      case 1:	/* Desert Merc. */	j = 6; n = 3; break;
      case 2:	/* Eastern Sorc. */	j = 15; n = 3; break;
      }
      for (i = 0; i < 3; i++)
	{
	  w = XxNameToWidget (form, hire_ability_opt[i]);
	  if (i < n)
	    {
	      /* Enable items for which we have an ability */
	      XtManageChild (w);
	      /* Look up the ability code */
	      cstr = GetEntryStringField
		(LookupNumericTableEntry ("hireling", "Id", j + i),
		 "HireDesc");
	      XtVaSetValues (w, XmNuserData, cstr, NULL);
	      /* Convert the code to a full description */
	      cstr = TranslateString
		(GetEntryStringField
		 (LookupTableEntry ("hiredesc", "Code", cstr),
		  "Hireling Description"));
	      xmstr = XmStringCreateLocalized ((char *) cstr);
	      XtVaSetValues (w, XmNlabelString, xmstr, NULL);
	      XmStringFree (xmstr);
	    }
	  else if (!i)
	    {
	      /* Leave one blank item for space */
	      xmstr = XmStringCreateLocalized (" ");
	      XtVaSetValues (w, XmNlabelString, xmstr, NULL);
	      XmStringFree (xmstr);
	    }
	  else
	    /* Disable excess items */
	    XtUnmanageChild (w);
	}
    }

  /* Update the hireling's name */
  XtVaSetValues (combo,
		 XmNselectedPosition, d2sp->GetHirelingNameIndex(),
		 NULL);

  /* Update the hireling's ability */
  w = XxNameToWidget (form, "*option_hire_ability");
  cstr = GetEntryStringField (hireling_entry, "HireDesc");
  j = GetEntryIntegerField (LookupTableEntry ("hiredesc", "Code", cstr),
			    NULL);
  switch (merc_class) {
  case 0:	/* Rogue Scout */	j -= 1; break;
  case 1:	/* Desert Merc. */	j -= 3; break;
  case 2:	/* Eastern Sorc. */	j -= 6; break;
  }
  XmOptionMenuSetSelection (w, j);

  /* Update the hireling's difficulty mode */
  w = XxNameToWidget (form, "*option_hire_difficulty");
  XmOptionMenuSetSelection
    (w, GetEntryIntegerField (hireling_entry, "Difficulty") - 1);

  /* Update the hireling's class description */
  w = XxNameToWidget (form, "*option_hire_class");
  XmOptionMenuSetSelection (w, merc_class + 1);

  /* Update the text fields */
  for (i = 0; i < (int) XtNumber (hire_stat_fields); i++)
    {
      w = XxNameToWidget (form, hire_stat_fields[i].name);
      if (merc_class < 0)
	field_value[0] = '\0';
      else
	sprintf (field_value, "%lu",
		 (d2sp->*hire_stat_fields[i].get_ul_value) ());
      old_value = XmTextFieldGetString (w);
      if (strcmp (field_value, old_value) != 0)
	XmTextFieldSetString (w, field_value);
      XtFree (old_value);
    }

  /* Update the scale bar under the Experience field. */
  w = XxNameToWidget (form, "*scale_hire_experience");
  XtVaGetValues (w, XmNvalue, &old_perc, NULL);
  if (merc_class < 0)
    perc = 0;
  else
    perc = (int) (((double) (d2sp->GetHirelingExperience()
			     - d2sp->GetHirelingExperienceMin())
		   / (double) (d2sp->GetHirelingExperienceMax()
			       - d2sp->GetHirelingExperienceMin()))
		  * 1000.0);
  if (perc < 0)
    perc = 0;
  else if (perc > 1000)
    perc = 1000;
  if (perc != old_perc)
    XtVaSetValues (w, XmNvalue, perc, NULL);

  /* Update the hireling's equipment */
  display_equipment (XxNameToWidget (form, "*area_hire_equipment"),
		     d2sp, "hire_equip", &d2sData::GetHirelingItemEquippedOn);
}

/* Resurrect a hireling */
void
ui_toggle_hire_death (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;
  XmToggleButtonCallbackStruct *cbs
    = (XmToggleButtonCallbackStruct *) call_data;
  int		merc_class;
  Pixmap	picture;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  if (d2sp->SetHirelingDead (cbs->set) < 0)
    {
      XmToggleButtonSetState (w, d2sp->hireling_is_dead(), False);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Change the hireling's picture. */
  merc_class = GetEntryIntegerField (d2sp->GetHirelingTableEntry(), "Act") - 1;
  if (d2sp->hireling_is_dead() && d2sp->is_expansion())
    picture = DEAD_ICON;
  else if (merc_class < 0)
    /* There is no hireling */
    picture = XmUNSPECIFIED_PIXMAP;
  else
    picture = class_icons[NUM_CHAR_CLASSES + merc_class];
  XtVaSetValues
    (XxNameToWidget (docwindow, "*form_hireling*picture_hireling"),
     XmNlabelPixmap, picture,
     NULL);
}

/* Change the hireling's name */
void
ui_hire_changed_name (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;
  XmComboBoxCallbackStruct *cbs = (XmComboBoxCallbackStruct *) call_data;

  if (cbs->event == NULL)
    /* Called by the program, or action not completed. */
    return;

  /* BUG WORKAROUND: Ungrab the mouse */
  ui_ungrab (w, NULL, cbs);

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  if (d2sp->SetHirelingName (cbs->item_position) < 0)
    {
      /* Error!  Restore the combo box. */
      XtVaSetValues (w, XmNselectedPosition, d2sp->GetHirelingNameIndex(),
		     NULL);
      display_error (d2sp->GetErrorMessage());
      return;
    }
}

/* Change the hireling's attribute */
void
ui_hire_changed_attribute (Widget w, XtPointer client_data,
			   XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  d2sData *	d2sp;
  const char	*attr_str;
  int		j;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the attribute associated with the selected button */
  XtVaGetValues (w, XmNuserData, &attr_str, NULL);

  /* Attempt to change the hireling attribute */
  if (d2sp->SetHirelingAttribute (attr_str) < 0)
    {
      /* Error!  Restory the original attribute */
      j = GetEntryIntegerField
	(LookupTableEntry ("hiredesc", "code", GetEntryStringField
			   (d2sp->GetHirelingTableEntry(), "HireDesc")),
	 NULL);
      if (j) {
	j -= 1;
	if (j >= 2) {
	  j -= 2;
	  if (j >= 3)
	    j -= 3;
	}
      }
      XmOptionMenuSetSelection
	(XxNameToWidget (docwindow, "*form_hireling*option_hire_ability"), j);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the experience and all stats */
  display_hireling (XxNameToWidget (docwindow, "*form_hireling"), d2sp);
}

/* Change the hireling's level */
void
ui_hire_changed_level (Widget w, XtPointer client_data, XtPointer call_data)
{
  int		new_level;
  char *	text;
  char		strbuf[16];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetHirelingLevel());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_level = atoi (text);
  XtFree (text);

  if (new_level == (int) d2sp->GetHirelingLevel())
    /* Nothing actually changed */
    return;

  /* Attempt to change the hireling's level. */
  if (d2sp->SetHirelingLevel (new_level) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetHirelingLevel());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* Update the experience and all stats */
  display_hireling (XxNameToWidget (docwindow, "*form_hireling"), d2sp);
}

/* Change the hireling's experience */
void
ui_hire_changed_experience (Widget w, XtPointer client_data,
			    XtPointer call_data)
{
  unsigned long	new_experience;
  int		old_level;
  char *	text;
  char		strbuf[12];
  d2sData *	d2sp;
  Widget	docwindow = (Widget) client_data;

  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game!  Nothing to update. */
    return;

  /* Get the current value in the text field */
  text = XmTextFieldGetString (w);
  if (!*text) {
    /* The field is empty; the user must have deleted
       the previous value.  Put the old value back. */
    XtFree (text);
    snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetHirelingExperience());
    XmTextFieldSetString (w, strbuf);
    return;
  }
  new_experience = strtoul (text, NULL, 10);
  XtFree (text);

  if (new_experience == d2sp->GetHirelingExperience())
    /* Nothing actually changed */
    return;

  /* Attempt to change the hireling's experience. */
  old_level = d2sp->GetHirelingLevel();
  if (d2sp->SetHirelingExperience (new_experience) < 0)
    {
      snprintf (strbuf, sizeof (strbuf), "%lu", d2sp->GetHirelingExperience());
      XmTextFieldSetString (w, strbuf);
      display_error (d2sp->GetErrorMessage());
      return;
    }

  /* If the level has changed as well, we need to
     update all of the other stats. */
  if ((int) d2sp->GetHirelingLevel() != old_level)
    display_hireling (XxNameToWidget (docwindow, "*form_hireling"), d2sp);

  /* Otherwise, just update the slider. */
  else
    XtVaSetValues (XxNameToWidget (docwindow,
				   "*form_hireling*scale_hire_experience"),
		   XmNvalue, (int)
		   (((double) (d2sp->GetHirelingExperience()
			       - d2sp->GetHirelingExperienceMin())
		     / (d2sp->GetHirelingExperienceMax()
			- d2sp->GetHirelingExperienceMin()))
		    * 1000.0),
		   NULL);
}

/* Update the hireling's experience field based on the value of the slider. */
void
ui_slider_hire_sync (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmScaleCallbackStruct *scale = (XmScaleCallbackStruct *) call_data;
  d2sData *d2sp;
  unsigned long new_experience;
  char numstr[16];

  stdui = client_data;

  XtVaGetValues ((Widget) client_data, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game loaded?  The slider should not be editable... */
    return;

  /* Compute the requested experience.  Remember that the slider's
     value is a percentage (+ 1 decimal place) of the current
     level's experience range. */
  new_experience = d2sp->GetHirelingExperienceMin() + (unsigned long)
    (((double) scale->value / 1000.0)
     * (d2sp->GetHirelingExperienceMax() - d2sp->GetHirelingExperienceMin()));

  /* Attempt to change the experience.  If we fail, try to restore the
     slider's value.  We can't report an error here because that could
     interfere with the button release event on the slider. */
  if (d2sp->SetHirelingExperience (new_experience) < 0)
    {
      if (scale->reason != XmCR_DRAG)
	{
	  XtVaSetValues (w, XmNvalue,
			 (int) (((double) (d2sp->GetHirelingExperience()
					   - d2sp->GetHirelingExperienceMin())
				 / (d2sp->GetHirelingExperienceMax()
				    - d2sp->GetHirelingExperienceMin()))
				* 1000.0),
			 NULL);
	}
    }

  /* Update the text field. */
  sprintf (numstr, "%lu", d2sp->GetHirelingExperience());
  XmTextFieldSetString
    (XxNameToWidget ((Widget) client_data,
		     "*form_hireling*field_hire_experience"),
     numstr);
}
