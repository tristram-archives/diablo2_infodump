/* UI functions for reading item images.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "ui.h"
#include <Xm/Text.h>
#include <Xm/ToggleB.h>
#include <X11/xpm.h>
#include <dmalloc.h>

/* for DEBUGGING: */
#undef XmGetPixmap
#undef load_item_picture
#undef load_item_mask

/* Load an item image.  If the item is colored, change the palette
   before converting the XPM file to a pixmap. */
Pixmap
load_item_picture (Screen *screen, d2sItem *item)
{
  char *xpm_path;
  d2sExtendedItem *ext_item;
  char *palette_path;
  char image_name[32];
  Pixmap xm_pixmap;
  char **xpm_data, **palette_data;
  XpmImage xpm_image;
  XImage *composite_image, *item_mask;

  /* Find the XPM image file */
  xpm_path = xfindfile ("items", item->Graphic(), ".xpm", path_to_images);
  if (xpm_path == NULL)
    {
      if (debug > 1)
	fprintf (stderr, "%s: Item image %s not found\n",
		 progname, item->Graphic());
      return XmUNSPECIFIED_PIXMAP;
    }
  palette_path = NULL;
  if (item->Type() >= EXTENDED_ITEM)
    {
      ext_item = (d2sExtendedItem *) *item;
      if (ext_item->is_colored())
	palette_path = xfindfile
	  ("items/palettes", ext_item->Color(), ".xpm", path_to_images);
    }

  /* If there is a color change, we must manipulate the XPM file. */
  if (palette_path != NULL) {
    /* First, check whether the image is already cached. */
    snprintf (image_name, sizeof (image_name), "%s-%s",
	      ext_item->Graphic(), ext_item->Color());
    xm_pixmap = XmGetPixmap (screen, image_name, WhitePixelOfScreen (screen),
			     BlackPixelOfScreen (screen));
    if (xm_pixmap != XmUNSPECIFIED_PIXMAP)
      {
	free (xpm_path);
	return xm_pixmap;
      }

    if (XpmReadFileToData (xpm_path, &xpm_data) == XpmSuccess) {
      if (XpmReadFileToData (palette_path, &palette_data) == XpmSuccess) {
	int ncolors = -1, i = -1;
	char *ts;

	/* Make sure the palette sizes are valid */
	sscanf (xpm_data[0], "%*d %*d %d", &ncolors);
	sscanf (palette_data[0], "%*d %*d %d", &i);
	if (ncolors == i) {
	  /* Swap palette entries */
	  for (i = 0; i < ncolors; i++) {
	    ts = xpm_data[1 + i];
	    xpm_data[1 + i] = palette_data[1 + i];
	    /* Not sure whether this is compatible with the Xpm library... */
	    palette_data[1 + i] = ts;
	  }

	  /* Convert the modified image to a Pixmap and give it to Motif */
	  if (XpmCreateXpmImageFromData (xpm_data, &xpm_image, NULL)
	      == XpmSuccess) {
	    if (XpmCreateImageFromXpmImage
		(DisplayOfScreen(screen), &xpm_image,
		 &composite_image, &item_mask, NULL) == XpmSuccess) {
	      /* Image succesfully created!  Install it in Motif. */
	      if (XmInstallImage (composite_image, image_name)) {
		/* Create a pixmap from the newly installed image */
		xm_pixmap = XmGetPixmap (screen, image_name,
					 WhitePixelOfScreen (screen),
					 BlackPixelOfScreen (screen));
		/* We no longer need the image (as long as the pixmap
		   is cached), so we can remove it now. */
		XmUninstallImage (composite_image);

		/* Back out gracefully and clean up after ourself. */
	      }
	      XDestroyImage (item_mask);
	      XDestroyImage (composite_image);
	    }
	    XpmFreeXpmImage (&xpm_image);
	  }
	}
	XpmFree (palette_data);
      }
      XpmFree (xpm_data);
    }

    if (xm_pixmap != XmUNSPECIFIED_PIXMAP)
      {
	free (xpm_path);
	return xm_pixmap;
      }
  }

  /* If there is no color change, or the color change failed,
     let Motif handle loading the unmodified image. */
  xm_pixmap = XmGetPixmap (screen, xpm_path, WhitePixelOfScreen (screen),
			   BlackPixelOfScreen (screen));
  if (xm_pixmap == XmUNSPECIFIED_PIXMAP)
    {
      /* Shouldn't happen, because we found the file
	 at the beginning of this function! */
      if (debug)
	fprintf (stderr, "%s: Warning: XmGetPixmap failed with"
		 " XmUNSPECIFIED_PIXMAP for %s\n",
		 progname, xpm_path);
    }
  free (xpm_path);
  return xm_pixmap;
}

/* Load an item mask.  This requires XPM to read the image so that
   we get the transparency mask, but it can still be cached by Motif.
   We don't need to worry about palette changes here. */
Pixmap
load_item_mask (Screen *screen, d2sItem *item)
{
  char		*xpm_path;
  char		mask_name[32];
  Pixmap	xm_pixmap;
  XImage	*composite_image, *item_mask;

  /* Create a name for the mask */
  snprintf (mask_name, sizeof (mask_name), "%s-mask", item->Graphic());

  /* If the mask is already cached, return it */
  xm_pixmap = XmGetPixmapByDepth (screen, mask_name,
				  WhitePixelOfScreen (screen),
				  BlackPixelOfScreen (screen), 1);
  if (xm_pixmap != XmUNSPECIFIED_PIXMAP)
    return xm_pixmap;

  /* Find the XPM image file */
  xpm_path = xfindfile ("items", item->Graphic(), ".xpm", path_to_images);
  if (xpm_path == NULL)
    {
      if (debug > 1)
	fprintf (stderr, "%s: Item image %s not found\n",
		 progname, item->Graphic());
      return XmUNSPECIFIED_PIXMAP;
    }

  /* Read the XPM file to create a mask */
  if (XpmReadFileToImage (DisplayOfScreen (screen), xpm_path,
			  &composite_image, &item_mask, NULL) == XpmSuccess) {
    /* Mask succesfully created!  Install it in Motif. */
    if (XmInstallImage (item_mask, mask_name)) {
      xm_pixmap = XmGetPixmapByDepth (screen, mask_name,
				      WhitePixelOfScreen (screen),
				      BlackPixelOfScreen (screen), 1);
      /* We no longer need the mask (as long as the bitmap
	 is cached), so we can remove it now. */
      XmUninstallImage (item_mask);

      /* Back out gracefully and clean up after ourself. */
    }
    XDestroyImage (item_mask);
    XDestroyImage (composite_image);
  }

  if (xm_pixmap == XmUNSPECIFIED_PIXMAP)
    {
      /* Shouldn't happen, because we found the file
	 at the beginning of this function! */
      if (debug)
	fprintf (stderr, "%s: Warning: XmGetPixmap failed with"
		 " XmUNSPECIFIED_PIXMAP for %s (%s)\n",
		 progname, xpm_path, mask_name);
    }
  free (xpm_path);
  return xm_pixmap;
}
