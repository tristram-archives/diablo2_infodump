/* UI functions for copying/pasting items and drag & drop
 * (The name 'clipboard.c' may be a misnomer, but
 *  'cutandpasteanddraganddrop.c' just doesn't work! ;-)
 *
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <Xm/Xm.h>
#include <Xm/AtomMgr.h>
#include <Xm/CutPaste.h>
#include <Xm/DragDrop.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <X11/Xatom.h>
#include <X11/xpm.h>
#include <unistd.h>
#include "ui.h"
#include <dmalloc.h>

/* Maximum number of sockets supported by the UIL interface */
#define MAX_DISPLAYED_SOCKETS 8

/* Index equipment boxes; order matches
   item_equipment_slot_t in "../d2sItem.h" */
static const char * const equipment_button_names[] = {
  /* Index 0 isn't used */ "",
  "head", "neck", "body", "rhand", "lhand", "rfing", "lfing",
  "waist", "feet", "hands", "arhand", "alhand"
};

/* Names for equipment slots in the item types table;
   only use BodyLoc1 when two are given */
static const char * const body_loc_names[] = {
  /* Index 0 isn't used */ "none",
  "head", "neck", "tors", "rarm", "rarm", "rrin", "rrin",
  "belt", "feet", "glov", "rarm", "rarm"
};

/* Drop sites for drag-and-drop operations */
static const char * const no_drops[] = {
  "*status_bar", "*game_data",
  "*frame_stats*form_stats_head*field_char_class",
  "*frame_stats*form_stats_head*field_next_level",
  "*frame_inventory*frame_stash*field_gold_stash_max",
  "*frame_inventory*frame_inv*field_gold_inv_max",
  "*frame_quests*frame_edit_quest*text_describe_quest",
  "*frame_hireling*form_hire_top_left*combo_hire_name*Text",
  "*frame_hireling*form_hire_stats*field_hire_life",
  "*frame_hireling*form_hire_stats*field_hire_strength",
  "*frame_hireling*form_hire_stats*field_hire_dexterity",
  "*frame_hireling*form_hire_stats*field_hire_defense",
  "*frame_hireling*form_hire_stats*field_hire_resistances",
};

static const char * const hide_drops[] = {
  "*table_window", "*frame_stats", "*frame_skills", "*frame_acts",
  "*frame_waypoints", "*frame_quests", "*frame_inventory", "*frame_hireling"
};

static const char * const reparent_drops[] = {
  "*frame_stats*form_stats_head*field_name",
  "*frame_stats*form_stats_head*field_level",
  "*frame_stats*form_stats_head*field_experience",
  "*frame_stats*form_stats_strength*field_strength",
  "*frame_stats*form_stats_dexterity*field_dexterity",
  "*frame_stats*form_stats_vitality*field_vitality",
  "*frame_stats*form_stats_vitality*field_stamina_base",
  "*frame_stats*form_stats_vitality*field_stamina_current",
  "*frame_stats*form_stats_vitality*field_life_base",
  "*frame_stats*form_stats_vitality*field_life_current",
  "*frame_stats*form_stats_energy*field_energy",
  "*frame_stats*form_stats_energy*field_mana_base",
  "*frame_stats*form_stats_energy*field_mana_current",
  "*frame_stats*field_stat_points",
  "*frame_skills*field_skill_points",
  "*frame_skills*spinbox_skilla*field_skilla",
  "*frame_skills*spinbox_skillb*field_skillb",
  "*frame_skills*spinbox_skillc*field_skillc",
  "*frame_skills*spinbox_skilld*field_skilld",
  "*frame_skills*spinbox_skille*field_skille",
  "*frame_skills*spinbox_skillf*field_skillf",
  "*frame_skills*spinbox_skillg*field_skillg",
  "*frame_skills*spinbox_skillh*field_skillh",
  "*frame_skills*spinbox_skilli*field_skilli",
  "*frame_skills*spinbox_skillj*field_skillj",
  "*frame_quests*frame_edit_quest*combo_qsthex*Text",
  "*frame_inventory*frame_stash*field_gold_stash",
  "*frame_inventory*frame_inv*field_gold_inv",
  "*frame_hireling*form_hire_top_left*field_hire_level",
  "*frame_hireling*form_hire_top_left*field_hire_experience",
};

static const char * const no_item_drops[] = {
  "*status_bar", "*game_data",
  "*form_item_description*field_item_base_name",
  "*form_item_description*field_item_type",
  "*form_item_description*field_item_req_level",
  "*frame_extended_item*form_durable_item*field_item_req_dexterity",
  "*frame_extended_item*form_durable_item*field_item_req_strength",
  "*frame_extended_item*form_durable_item*field_item_class_restriction",
  "*frame_extended_item*form_durable_item*field_standard_durability",
  "*frame_extended_item*form_armor_defense*field_defense_range",
  "*frame_extended_item*form_armor_shield*field_chance_to_block",
  "*frame_extended_item*form_armor_shield*field_smite_damage",
  "*frame_extended_item*form_armor_belt*field_belt_class",
  "*frame_extended_item*form_armor_belt*field_belt_boxes",
  "*frame_extended_item*form_stacked_item*field_item_max_quantity",
  "*frame_extended_item*form_weapon_1hd*field_1hw_damage",
  "*frame_extended_item*form_weapon_2hd*field_2hw_damage",
  "*frame_extended_item*form_weapon_speed*field_weapon_speed_number",
  "*frame_extended_item*form_weapon_speed*field_weapon_speed_text",
  "*frame_item_quality*form_quality_low_high*field_grade_name",
  "*frame_item_quality*form_quality_magic*field_magic_prefix_level",
  "*frame_item_quality*form_quality_magic*field_magic_prefix_color",
  "*frame_item_quality*form_quality_magic*field_magic_suffix_level",
  "*frame_item_quality*form_quality_magic*field_magic_suffix_color",
  "*frame_item_quality*form_quality_set*field_set_color",
  "*frame_item_quality*form_quality_set*field_set_item_name",
  "*frame_item_quality*form_quality_set*field_set_item_level",
  "*frame_item_quality*form_quality_set*field_set_property_count",
  "*frame_item_quality*form_quality_rare*field_rare_hidden1_level",
  "*frame_item_quality*form_quality_rare*field_rare_hidden1_color",
  "*frame_item_quality*form_quality_rare*field_rare_hidden2_level",
  "*frame_item_quality*form_quality_rare*field_rare_hidden2_color",
  "*frame_item_quality*form_quality_rare*field_rare_hidden3_level",
  "*frame_item_quality*form_quality_rare*field_rare_hidden3_color",
  "*frame_item_quality*form_quality_rare*field_rare_hidden4_level",
  "*frame_item_quality*form_quality_rare*field_rare_hidden4_color",
  "*frame_item_quality*form_quality_rare*field_rare_hidden5_level",
  "*frame_item_quality*form_quality_rare*field_rare_hidden5_color",
  "*frame_item_quality*form_quality_rare*field_rare_hidden6_level",
  "*frame_item_quality*form_quality_rare*field_rare_hidden6_color",
  "*frame_item_quality*form_quality_unique*field_unique_level",
  "*frame_item_quality*form_quality_unique*field_unique_color",
  "*frame_socketed_item*form_socket1*field_socketed_gem1_name",
  "*frame_socketed_item*form_socket1*field_socketed_gem1_level",
  "*frame_socketed_item*form_socket2*field_socketed_gem2_name",
  "*frame_socketed_item*form_socket2*field_socketed_gem2_level",
  "*frame_socketed_item*form_socket3*field_socketed_gem3_name",
  "*frame_socketed_item*form_socket3*field_socketed_gem3_level",
  "*frame_socketed_item*form_socket4*field_socketed_gem4_name",
  "*frame_socketed_item*form_socket4*field_socketed_gem4_level",
  "*frame_socketed_item*form_socket5*field_socketed_gem5_name",
  "*frame_socketed_item*form_socket5*field_socketed_gem5_level",
  "*frame_socketed_item*form_socket6*field_socketed_gem6_name",
  "*frame_socketed_item*form_socket6*field_socketed_gem6_level",
  "*frame_socketed_item*form_socket7*field_socketed_gem7_name",
  "*frame_socketed_item*form_socket7*field_socketed_gem7_level",
  "*frame_socketed_item*form_socket8*field_socketed_gem8_name",
  "*frame_socketed_item*form_socket8*field_socketed_gem8_level",
  "*frame_socketed_item*form_socket9*field_socketed_gem9_name",
  "*frame_socketed_item*form_socket9*field_socketed_gem9_level",
  "*frame_socketed_item*form_socket10*field_socketed_gem10_name",
  "*frame_socketed_item*form_socket10*field_socketed_gem10_level",
  "*frame_socketed_item*form_socket11*field_socketed_gem11_name",
  "*frame_socketed_item*form_socket11*field_socketed_gem11_level",
  "*frame_socketed_item*form_socket12*field_socketed_gem12_name",
  "*frame_socketed_item*form_socket12*field_socketed_gem12_level",
};

/* Cursors used in drag operations */
static Widget no_cursor = NULL;
static Widget empty_cursor = NULL;
static Widget copy_cursor = NULL;

/* This structure holds information we need to process an incremental drop */
struct drop_data_t {
  Widget	drop_site;
  Window	drop_window;
  d2sData	*drop_char;
  d2sDurableItem *drop_socket;
  unsigned char operation;
  unsigned char referenced;
  Window	source_window;
  pid_t		source_pid;
  d2sItem	*itemPtr;
};


static int get_focus_area (Widget focus);
static coordinate_t get_box_location (Widget box, int area);
static void post_to_clipboard (Widget, d2sItem *, Time);
static int get_clipboard_data_length (Widget);
static void start_grp_drag (Widget, XEvent *, d2sItem *item);
static void drag_op_changed (Widget, XtPointer, XtPointer);
static void drag_op_change_none (Widget, XtPointer, XtPointer);
static void DragFinish (Widget, XtPointer, XtPointer);
static void GRPDragFinish (Widget, XtPointer, XtPointer);
static void ui_drop_item (Widget, XtPointer, XtPointer);
static void ui_drop_gem (Widget, XtPointer, XtPointer);
static Boolean DragConvert (Widget, Atom *, Atom *, Atom *,
			    XtPointer *, unsigned long *, int *,
			    unsigned long *, XtPointer, XtRequestId *);
static Boolean GRPDragConvert (Widget, Atom *, Atom *, Atom *,
			       XtPointer *, unsigned long *, int *,
			       unsigned long *, XtPointer, XtRequestId *);
static void DropTransfer (Widget, XtPointer, Atom *, Atom *,
			  XtPointer, unsigned long *, int *);
static Boolean drop_finish (struct drop_data_t *);
static void put_item_back (struct drop_data_t *, d2sData *prev_owner,
			   int old_area, coordinate_t old_location,
			   d2sDurableItem *prev_socket);

/**************** CUT AND PASTE ****************/

/* Find the widget that has the current focus.  If that widget is
   a PushButton on the inventory frame or the hireling's equipment frame,
   return an ITEM_AREA_xxx macro that tells which part of the inventory
   the widget is in.  Returns 0 if the widget is not an item box. */
static int
get_focus_area (Widget focus)
{
  int		i;
  static const struct {
    int		item_area;
    const char *parent_name;
  } area_parents[] = {
    { ITEM_AREA_EQUIPPED, "area_equipment" },
    { ITEM_AREA_BELT, "matrix_belt" },
    { ITEM_AREA_INVENTORY, "matrix_inventory" },
    { ITEM_AREA_STASH, "matrix_stash" },
    { ITEM_AREA_CUBE, "matrix_cube" },
    /* { ITEM_AREA_CORPSE, "area_equipment" }, *//* special case */
    { ITEM_AREA_HIRELING, "area_hire_equipment" },
    { ITEM_AREA_PICKED, "frame_mouse" },
    { ITEM_AREA_SOCKETED, "form_socketed_item" },
  };

  if ((focus == NULL) || !XmIsPushButton (focus))
    {
      /* Special case for the sockets frame of the item editor */
      if ((focus != NULL) && XmIsForm (focus)
	  && (strcmp (XtName (XtParent (focus)), "form_socketed_item") == 0))
	return ITEM_AREA_SOCKETED;
      return 0;
    }

  /* Compare the button's parent's name to the names of the manager
     widgets we know for each area. */
  for (i = 0; i < (int) XtNumber (area_parents); i++) {
    if (strcmp (XtName (XtParent (focus)),
		area_parents[i].parent_name) == 0) {
      /* If this is the character equipment area, we need to
	 further distinguish the character him(/her)self from
	 his(/her) corpse. */
      if ((area_parents[i].item_area == ITEM_AREA_EQUIPPED)
	  && (XmToggleButtonGetState
	      (XxNameToWidget (XtParent (focus), "*button_corpse"))))
	return ITEM_AREA_CORPSE;
      return area_parents[i].item_area;
    }
  }
  /* One extra check for sockets */
  if (strcmp (XtName (XtParent (XtParent (focus))),
              "form_socketed_item") == 0)
    return ITEM_AREA_SOCKETED;

  /* Not an item box */
  return 0;
}

/* Decode an item box widget's name to get its position */
static coordinate_t
get_box_location (Widget box, int area)
{
  coordinate_t	location = { 0, 0 };
  const char	*suffix;

  switch (area)
    {
    case ITEM_AREA_EQUIPPED:
    case ITEM_AREA_CORPSE:
      suffix = &(XtName (box)[strlen ("box_equip_")]);
    find_equipment_slot:
      for (location.x = 1;
	   location.x < (int) XtNumber (equipment_button_names);
	   location.x++) {
	if (strcmp (suffix, equipment_button_names[location.x]) == 0)
	  return location;
      }
      /* No match?! */
      if (debug)
	fprintf (stderr, "%s: Internal error: get_box_location\n"
		 " (%s,ITEM_AREA_%s) (slot not found)\n",
		 progname, XtName (box), (area == ITEM_AREA_EQUIPPED)
		 ? "EQUIPPED" : ((area == ITEM_AREA_CORPSE)
				 ? "CORPSE" : "HIRELING"));
      location.x = 0;
      return location;

    case ITEM_AREA_HIRELING:
      suffix = &(XtName (box)[strlen ("box_hire_equip_")]);
      goto find_equipment_slot;

    case ITEM_AREA_BELT:
      suffix = &(XtName (box)[strlen ("box_belt_")]);
      location.x = atoi (suffix);
      return location;

    case ITEM_AREA_INVENTORY:
      suffix = &(XtName (box)[strlen ("box_inv_")]);
    get_matrix_coordinate:
      location.y = suffix[0] - '0';
      location.x = suffix[1] - '0';
      return location;

    case ITEM_AREA_STASH:
      suffix = &(XtName (box)[strlen ("box_stash_")]);
      goto get_matrix_coordinate;

    case ITEM_AREA_CUBE:
      suffix = &(XtName (box)[strlen ("box_cube_")]);
      goto get_matrix_coordinate;

    case ITEM_AREA_PICKED:
      /* Only one box! */
      return location;

    case ITEM_AREA_SOCKETED:
      suffix = XtName (box);
      if (suffix[0] == 'f')
	suffix += strlen ("form_socket");
      else if (suffix[0] == 'b')
	suffix += strlen ("button_socket");
      location.x = atoi (suffix);
      return location;
    }
  /* NOTREACHED */
  /* (I hope) */
  if (debug)
    fprintf (stderr, "%s: Internal error: bad argument to"
	     " get_box_location(%s,%d)\n", progname, XtName (box), area);
  return location;
}

/* Copy an item to the clipboard.  Shared by both Cut and Copy. */
static void
post_to_clipboard (Widget window, d2sItem *item, Time when)
{
  d2sItem	*copy_of_item;
  struct data_stream ds;
  XmString	xmstr;
  long		item_id;
  int		retry = 0;

  /* Set up a new data stream to which the raw item data will be written */
  dstream_set (ds, NULL, 0, 0);
  /* Copy the item (so we don't disturb the original) */
  copy_of_item = item->Copy();
  /* Write the raw data from the copy */
  copy_of_item->Write (&ds);
  /* Compute the actual size of the item data
     (dstream_write() allocates extra space for future writes) */
  ds.size = ds.ptr - ds.base;

  /* Copy the item's raw data to the X clipboard */
  xmstr = XmStringCreateLocalized ((char *) copy_of_item->Name());
  /* All done with the copy */
  delete copy_of_item;
  /* The StartCopy function must be retried until we aquire the clipboard */
  while (XmClipboardStartCopy (XtDisplay (window), XtWindow (window), xmstr,
			       CurrentTime, NULL, NULL, &item_id)
	 == XmClipboardLocked) {
    if (++retry >= 1000) {
      if (debug)
	fprintf (stderr, "%s: Timed out waiting for the clipboard"
		 " to become available\n", progname);
      free (ds.base);
      XBell (XtDisplay (window), 0);
      return;
    }
    /* Give other procs a little CPU time while waiting */
    usleep (1);
  }
  XmStringFree (xmstr);
  while (XmClipboardCopy (XtDisplay (window), XtWindow (window), item_id,
			  "DIABLO_ITEM_STRUCT", ds.base, ds.size, 0, NULL)
	 == XmClipboardLocked) {
    if (++retry >= 1000) {
      if (debug)
	fprintf (stderr, "%s: Timed out waiting for the clipboard"
		 " to become available\n", progname);
      free (ds.base);
      XBell (XtDisplay (window), 0);
      return;
    }
    usleep (1);
  }
  while (XmClipboardEndCopy (XtDisplay (window), XtWindow (window), item_id)
	 == XmClipboardLocked) {
    if (++retry >= 1000) {
      if (debug)
	fprintf (stderr, "%s: Timed out waiting for the clipboard"
		 " to become available\n", progname);
      free (ds.base);
      XBell (XtDisplay (window), 0);
      return;
    }
    usleep (1);
  }

  free (ds.base);
}

static int
get_clipboard_data_length (Widget window)
{
  long unsigned int len = 0;
  int		retry = 0;
  int		status;

  while ((status = (XmClipboardInquireLength
		    (XtDisplay (window), XtWindow (window),
		     "DIABLO_ITEM_STRUCT", &len))) == XmClipboardLocked) {
    if (++retry >= 1000) {
      if (debug)
	fprintf (stderr, "%s: Timed out waiting to read the clipboard\n",
		 progname);
      XBell (XtDisplay (window), 0);
      return 0;
    }
    usleep (1000);
  }
  return ((status == XmClipboardSuccess) ? len : 0);
}


/* When the Edit menu is posted, check whether an item in the
   inventory has the current focus.  Set the sensitivity of the
   Cut and Copy menu items accordingly. */
void
ui_check_copy (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	menu, frame, focus;
  d2sData	*d2sp;
#if 0
  d2sItem	*item;
#endif
  int		enable = False;

  menu = XxNameToWidget (docwindow, "*menubar_char");
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No game; turn the buttons off */
    goto set_sensitive;

  frame = NULL;
  focus = NULL;
  /* Which view is currently displayed? */
  if (XmToggleButtonGetState
      (XxNameToWidget (menu, "*menuitem_inventory"))) {
    frame = XxNameToWidget (docwindow, "*form_inventory");
    focus = XmGetFocusWidget (frame);
  }
  else if (XmToggleButtonGetState
	   (XxNameToWidget (menu, "*menuitem_mercenary"))
	   && d2sp->is_expansion()) {
    frame = XxNameToWidget (docwindow,
			    "*form_hireling*area_hire_equipment");
    XtVaGetValues (frame, XmNinitialFocus, &focus, NULL);
  }

  /* The focus is bogus in this callback, so forget it.
     Just enable the Cut and Copy items if we're on the inventory screen. */
#if 0
  print_message ("Function ui_check_copy(%s) called; %s has the focus",
		 (d2sp == NULL) ? "no character" : d2sp->GetCharacterName(),
		 (focus == NULL) ? "no widget" : XtName (focus));
  if ((focus != NULL) && XmIsPushButton (focus)) {
    /* Luckily for us, every PushButton in the inventory screen
       is an item box.  So we don't need any more tests.
       Next question: does the box contain an item? */
    XtVaGetValues (focus, XmNuserData, &item, NULL);
    enable = (item != NULL);
  }
#else
  enable = True;
#endif

  /* If altering the character's inventory is not allowed,
     the Cut menu option is always disabled. */
 set_sensitive:
  XtSetSensitive (XxNameToWidget (menu, "*menuitem_cut"),
		  enable && !d2sp->read_only
		  && options.character.edit.inventory);
  XtSetSensitive (XxNameToWidget (menu, "*menuitem_copy"), enable);
}

/* Also when the Edit menu is posted, check whether there is a
   Diablo item on the clipboard.  Set the sensitivity of the
   Paste menu item accordingly. */
void
ui_check_paste (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	menu;
  d2sData	*d2sp;
  int		enable = False;

  menu = XxNameToWidget (docwindow, "*menubar_char");
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if ((d2sp != NULL) && !d2sp->read_only)
    {
      /* Match the editing options with
	 whichever view is currently displayed */
      if ((options.character.edit.inventory && XmToggleButtonGetState
	   (XxNameToWidget (menu, "*menuitem_inventory")))
	  || (options.character.edit.hireling_inventory
	      && d2sp->has_hireling() && d2sp->is_expansion()
	      && (XmToggleButtonGetState
		  (XxNameToWidget (menu, "*menuitem_mercenary")))))
	enable = get_clipboard_data_length (docwindow) > 0;
    }

  XtSetSensitive (XxNameToWidget (menu, "*menuitem_paste"), enable);
}

/* When the item editor's Edit menu is posted, check whether there
   is a Diablo item on the clipboard, and an empty socket available
   in the item.  Set the sensitivity of the Paste menu item accordingly. */
void
ui_check_socket_paste (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	menu;
  d2sItem	*item;
  d2sDurableItem *ditem;
  int		enable = False;

  menu = XxNameToWidget (docwindow, "*menubar_item");
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if ((item != NULL) && !item->read_only() && options.item.edit.socketed_gems
      && ((item->Type() == ARMOR_ITEM) || (item->Type() == WEAPON_ITEM)))
    {
      ditem = (d2sDurableItem *) *item;
      if (ditem->NumberOfGems() < ditem->ModNumberOfSockets())
	enable = get_clipboard_data_length (docwindow) > 0;
    }

  XtSetSensitive (XxNameToWidget (menu, "*menuitem_paste"), enable);
}

/* Ditto, check for whether a gem can be 'cut'.
   (Since Motif changes the keyboard focus before calling this callback,
   we have no idea whether a gem is actually highlighted.  Just pretend.) */
void
ui_check_socket_cut (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	menu;
  d2sItem	*item;
  d2sDurableItem *ditem;
  int		enable = False;

  /* Debug */
  if (debug)
    ui_ungrab (w, client_data, call_data);

  menu = XxNameToWidget (docwindow, "*menubar_item");
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if ((item != NULL) && !item->read_only()
      && options.item.edit.socketed_gems && options.item.edit.gem
      && ((item->Type() == ARMOR_ITEM) || (item->Type() == WEAPON_ITEM)))
    {
      ditem = (d2sDurableItem *) *item;
      enable = (ditem->NumberOfGems() > 0);
    }

  XtSetSensitive (XxNameToWidget (menu, "*menuitem_cut"), enable);
}


void
ui_edit_cut (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  XmPushButtonCallbackStruct *cbs = (XmPushButtonCallbackStruct *) call_data;
  Widget	focus, menu;
  d2sData	*d2sp;
  d2sItem	*item;
  int		area;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL) {
    /* No character!  The Cut menu item should have been disabled. */
    if (debug)
      fprintf (stderr, "%s: Internal error: %s enabled but window has"
	       " no character\n", progname, XtName (w));
    return;
  }

  /* Which button is currently highlighted? */
  focus = XmGetFocusWidget ((Widget) client_data);
  area = get_focus_area (focus);
  if (!area) {
    /* The focus is not on an item box */
    XBell (XtDisplay (w), 0);
    return;
  }

  /* Does this button contain an item? */
  XtVaGetValues (focus, XmNuserData, &item, NULL);
  if (item == NULL)
    /* No item to cut here */
    return;

  /* Remove the item from the character */
  remove_item_from_inventory (item);
  if (d2sp->RemoveItem (item) < 0) {
    /* Error!  Put the item back. */
    update_item_in_inventory (item);
    display_error (d2sp->GetErrorMessage());
    return;
  }
  /* If the box had an item pop-up window attached, destroy it. */
  if ((item->GetUI() != NULL)
      && (strcmp (XtName ((Widget) item->GetUI()), "form_item_popup") == 0)) {
    XtDestroyWidget (XtParent ((Widget) item->GetUI()));
    item->SetUI (NULL);
  }

  post_to_clipboard (docwindow, item,
		     ((cbs->event->type == ButtonRelease)
		      ? cbs->event->xbutton.time : CurrentTime));

  /* If the item does not have its own window, destroy it. */
  if (item->GetUI() == NULL)
    delete item;
  else {
    /* Otherwise, update the item's window */
    menu = XxNameToWidget ((Widget) item->GetUI(), "*menubar_item");
    XtSetSensitive (XxNameToWidget (menu, "*menuitem_move"), False);
    XtSetSensitive (XxNameToWidget (menu, "*menuitem_remove"), False);
    XtSetSensitive (XxNameToWidget (menu, "*menuitem_assign"), True);
    update_item_window_title ((Widget) item->GetUI(), item);
    if (item->SourceFileName() == NULL)
      item->MarkDirty();
  }
}

void
ui_edit_copy (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  XmPushButtonCallbackStruct *cbs = (XmPushButtonCallbackStruct *) call_data;
  Widget	focus;
  d2sData	*d2sp;
  d2sItem	*item;
  int		area;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL) {
    /* No character!  The Cut menu item should have been disabled. */
    if (debug)
      fprintf (stderr, "%s: Internal error: %s enabled but window has"
	       " no character\n", progname, XtName (w));
    return;
  }

  /* Which button is currently highlighted? */
  focus = XmGetFocusWidget ((Widget) client_data);
  area = get_focus_area (focus);
  if (!area) {
    /* The focus is not on an item box */
    XBell (XtDisplay (w), 0);
    return;
  }

  /* Does this button contain an item? */
  XtVaGetValues (focus, XmNuserData, &item, NULL);
  if (item == NULL)
    /* No item to copy here */
    return;

  post_to_clipboard (docwindow, item,
		     ((cbs->event->type == ButtonRelease)
		      ? cbs->event->xbutton.time : CurrentTime));
}

void
ui_edit_paste (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  Widget	focus;
  d2sData	*d2sp;
  d2sItem	*item;
  struct data_stream ds;
  int		status, retry = 0;
  long unsigned int len;
  int		area;
  coordinate_t	position, size;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL) {
    /* No character!  The Paste menu item should have been disabled. */
    if (debug)
      fprintf (stderr, "%s: Internal error: %s enabled but window has"
	       " no character\n", progname, XtName (w));
    return;
  }

  /* Which button is currently highlighted? */
  focus = XmGetFocusWidget ((Widget) client_data);
  area = get_focus_area (focus);
  if (!area) {
    /* The focus is not on an item box.  Even if it's in a TextField
       in the inventory or another widget on the hireling screen,
       it's not worth it to try figuring out where the user wants
       the item, particularly since the inventory may be hidden. */
    XBell (XtDisplay (w), 0);
    return;
  }

  /* Does the clipboard contain a DIABLO_ITEM_STRUCT? */
  len = get_clipboard_data_length (docwindow);
  if (!len) {
    /* There ought to be a way of determining this automatically... */
    XBell (XtDisplay (w), 0);
    return;
  }

  /* Set up our data stream to hold the item's data */
  dstream_set (ds, xmalloc (len), 0, len);

  /* Read the data from the clipboard */
  while ((status = (XmClipboardRetrieve
		    (XtDisplay (docwindow), XtWindow (docwindow),
		     "DIABLO_ITEM_STRUCT", ds.base, ds.size, &len, NULL)))
	 == XmClipboardLocked) {
    if (++retry >= 1000) {
      if (debug)
	fprintf (stderr, "%s: Timed out waiting for the clipboard"
		 " to become available\n", progname);
      free (ds.base);
      XBell (XtDisplay (w), 0);
      return;
    }
    usleep (1);
  }
  if ((status != XmClipboardSuccess) || (len != ds.size)) {
    if (debug)
      fprintf (stderr, "%s: Error reading item data from the clipboard\n",
	       progname);
    free (ds.base);
    XBell (XtDisplay (w), 0);
    return;
  }

  /* Convert the data to an item */
  item = ReadItemFromFile (&ds);
  free (ds.base);
  if (item == NULL) {
    if (debug)
      fprintf (stderr, "%s: Error converting item data from the clipboard\n",
	       progname);
    XBell (XtDisplay (w), 0);
    return;
  }
  if (item->GetErrorMessage() != NULL) {
    if (debug)
      fprintf (stderr, "%s: Error converting item data from the clipboard:\n"
	       " %s\n", progname, item->GetErrorMessage());
    display_error (item->GetErrorMessage());
    delete item;
    return;
  }

  /* With extended items, we need to modify the unique ID
     so that Diablo doesn't suspect we're copying items. */
  if (item->Type() >= UNKNOWN_EXTENDED_ITEM)
    ((d2sExtendedItem *) *item)->GenerateUniqueID();

  /* Place the item.  If the focus box is empty, try to put the item there.
     If it won't go there, find an empty spot. */
  if (area) {
    position = get_box_location (focus, area);
    /* Clip the item to the bounds of the area */
    size = item->Size();
    switch (area) {
    case ITEM_AREA_STASH:
      if (position.x + size.x > HSIZE_STASH)
	position.x = HSIZE_STASH - size.x;
      if (position.y + size.y
	  > (d2sp->is_expansion() ? VSIZE_STASH : (VSIZE_STASH / 2)))
	position.y = (d2sp->is_expansion()
		      ? VSIZE_STASH : (VSIZE_STASH / 2)) - size.y;
      break;
    case ITEM_AREA_INVENTORY:
      if (position.x + size.x > HSIZE_INVENTORY)
	position.x = HSIZE_INVENTORY - size.x;
      if (position.y + size.y > VSIZE_INVENTORY)
	position.y = HSIZE_INVENTORY - size.y;
      break;
    case ITEM_AREA_CUBE:
      if (position.x + size.x > HSIZE_CUBE)
	position.x = HSIZE_CUBE - size.x;
      if (position.y + size.y > VSIZE_CUBE)
	position.y = HSIZE_CUBE - size.y;
      break;
    }
    if (d2sp->CheckLocationAvailable
	(item, area, position.x, position.y) >= 0)
      goto empty_spot_found;

    /* Focus box is not available.  Try anywhere else in the same area. */
    if (d2sp->FindEmptySpotForItem
	(item, area, &position.x, &position.y) >= 0)
      goto empty_spot_found;
  }

  /* No spot is available in the preferred area.  Try anywhere else. */
  if (d2sp->FindEmptySpotForItem
      (item, &area, &position.x, &position.y) < 0) {
    display_error ("You have no room to put a %s", item->Name());
    delete item;
    return;
  }

 empty_spot_found:
  if (item->SetLocation (area, position.x, position.y) < 0) {
    if (debug)
      fprintf (stderr, "%s: Internal error: can't set the location"
	       " of a new item\n", progname);
    display_error ("Internal error");
    delete item;
    return;
  }
  if (d2sp->AddItem (item) < 0) {
    display_error (d2sp->GetErrorMessage());
    delete item;
    return;
  }
  else {
    /* Placement successful; update the inventory */
    update_item_in_inventory (item);
    return;
  }
}

void
ui_item_copy (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  XmPushButtonCallbackStruct *cbs = (XmPushButtonCallbackStruct *) call_data;
  d2sItem	*item;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      /* No item in this window.  This menu option shouldn't be enabled. */
      XtSetSensitive (w, False);
      return;
    }

  post_to_clipboard (docwindow, item,
		     ((cbs->event->type == ButtonRelease)
		      ? cbs->event->xbutton.time : CurrentTime));
}

void
ui_item_cut_gem (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  XmPushButtonCallbackStruct *cbs = (XmPushButtonCallbackStruct *) call_data;
  Widget	focus;
  d2sItem	*item;
  d2sDurableItem *ditem;
  d2sAttachItem *gem;
  int		index;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      /* No item in this window.  This menu option shouldn't be enabled. */
      XtSetSensitive (w, False);
      return;
    }
  if ((item->Type() != ARMOR_ITEM) && (item->Type() != WEAPON_ITEM))
    {
      /* Item is not socketable.  This menu option shouldn't be enabled. */
      XtSetSensitive (w, False);
      return;
    }

  ditem = (d2sDurableItem *) *item;
  if (!ditem->NumberOfGems())
    {
      /* Item has no filled sockets.  This menu item shouldn't be enabled. */
      XtSetSensitive (w, False);
      return;
    }

  /* Is one of the socket lines highlighted? */
  focus = XmGetFocusWidget (docwindow);
  if (get_focus_area (focus) != ITEM_AREA_SOCKETED)
    {
      XBell (XtDisplay (w), 0);
      return;
    }
  index = get_box_location (focus, ITEM_AREA_SOCKETED).x;
  if (index > ditem->NumberOfGems())
    /* Ignore the request */
    return;

  /* Try to remove the selected gem */
  gem = ditem->Gem (index);
  if (ditem->RemoveGem (index) < 0)
    {
      display_error (ditem->GetErrorMessage());
      return;
    }
  /* Make sure the item's location is changed. */
  gem->SetLocation (ITEM_AREA_PICKED, 0);

  /* Update the item */
  update_socketed_item (ditem);

  /* Post the gem to the clipboard */
  post_to_clipboard (docwindow, gem,
		     ((cbs->event->type == ButtonRelease)
		      ? cbs->event->xbutton.time : CurrentTime));

  /* If the gem didn't have its own editor window open, delete it. */
  if (gem->GetUI() == NULL)
    delete gem;
  else if (strcmp (XtName ((Widget) gem->GetUI()), "form_item_popup") == 0)
    {
      XtVaSetValues ((Widget) gem->GetUI(), XmNuserData, NULL, NULL);
      XtDestroyWidget (XtParent ((Widget) gem->GetUI()));
      delete gem;
    }
}

void
ui_item_paste (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  d2sItem	*item;
  d2sDurableItem *ditem;
  long unsigned int len;
  struct data_stream ds;
  int		status, retry = 0;
  d2sAttachItem *gem;

  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      /* No item in this window.  This menu option shouldn't be enabled. */
      XtSetSensitive (w, False);
      return;
    }
  if ((item->Type() != ARMOR_ITEM) && (item->Type() != WEAPON_ITEM))
    {
      /* Item is not socketable.  This menu option shouldn't be enabled. */
      XtSetSensitive (w, False);
      return;
    }

  ditem = (d2sDurableItem *) *item;
  if (ditem->NumberOfGems() >= ditem->ModNumberOfSockets())
    {
      /* Item has no empty sockets.  This menu item shouldn't be enabled. */
      XtSetSensitive (w, False);
      return;
    }

  /* Does the clipboard contain a DIABLO_ITEM_STRUCT? */
  len = get_clipboard_data_length (docwindow);
  if (!len) {
    /* There ought to be a way of determining this automatically... */
    XBell (XtDisplay (w), 0);
    return;
  }

  /* Set up our data stream to hold the item's data */
  dstream_set (ds, xmalloc (len), 0, len);

  /* Read the data from the clipboard */
  while ((status = (XmClipboardRetrieve
		    (XtDisplay (docwindow), XtWindow (docwindow),
		     "DIABLO_ITEM_STRUCT", ds.base, ds.size, &len, NULL)))
	 == XmClipboardLocked) {
    if (++retry >= 1000) {
      if (debug)
	fprintf (stderr, "%s: Timed out waiting for the clipboard"
		 " to become available\n", progname);
      free (ds.base);
      XBell (XtDisplay (w), 0);
      return;
    }
    usleep (1);
  }
  if ((status != XmClipboardSuccess) || (len != ds.size)) {
    if (debug)
      fprintf (stderr, "%s: Error reading item data from the clipboard\n",
	       progname);
    free (ds.base);
    XBell (XtDisplay (w), 0);
    return;
  }

  /* Convert the data to an item */
  item = ReadItemFromFile (&ds);
  free (ds.base);
  if (item == NULL) {
    if (debug)
      fprintf (stderr, "%s: Error converting item data from the clipboard\n",
	       progname);
    XBell (XtDisplay (w), 0);
    return;
  }
  if (item->GetErrorMessage() != NULL) {
    if (debug)
      fprintf (stderr, "%s: Error converting item data from the clipboard:\n"
	       " %s\n", progname, item->GetErrorMessage());
    display_error (item->GetErrorMessage());
    delete item;
    return;
  }

  /* Make sure the item is a gem (, rune, or jewel) */
  if ((item->Type() != GEM_ITEM) && (item->Type() != RUNE_ITEM)
      && (item->Type() != JEWEL_ITEM))
    {
      /* Fail silently; the user might have
	 forgotten what was in the clipboard */
      XBell (XtDisplay (w), 0);
      delete item;
      return;
    }

  /* Try to attach the gem to the next empty socket */
  gem = (d2sAttachItem *) *item;
  if (ditem->AddGem (gem) < 0)
    {
      display_error (ditem->GetErrorMessage());
      delete gem;
      return;
    }

  /* Placement successful; update the ditem's socket frame,
     and the ditem's picture(s). */
  update_socketed_item (ditem);
}

/**************** DRAG AND DROP ****************/

void
register_drop_sites (Widget window)
{
  Widget	form, child;
  char		child_name[32];
  int		i, j;
  Arg		hide_args[] = {
    { XmNanimationStyle, (XtArgVal) XmDRAG_UNDER_NONE },
    { XmNdropSiteActivity, (XtArgVal) XmDROP_SITE_INACTIVE },
    { XmNdropSiteOperations, (XtArgVal) XmDROP_NOOP },
    { XmNdropSiteType, (XtArgVal) XmDROP_SITE_COMPOSITE },
  };
  Atom *	saved_text_import_targets;
  Cardinal	saved_num_import_targets;
  XtCallbackProc saved_text_drag_proc;
  XtCallbackProc saved_text_drop_proc;
  Arg		textdrop_args[6] = {
    /* All drop sites are marked inactive until a character is loaded */
    { XmNdropSiteActivity, (XtArgVal) XmDROP_SITE_INACTIVE },
    { XmNdropSiteOperations, (XtArgVal) XmDROP_COPY },
  };
  Atom		item_import_targets[1];
  Arg		itemdrop_args[] = {
    { XmNdropProc, (XtArgVal) ui_drop_item },
    /* All drop sites are marked no-ops until a character is loaded */
    { XmNdropSiteOperations, (XtArgVal) XmDROP_NOOP },
    { XmNimportTargets, (XtArgVal) item_import_targets },
    { XmNnumImportTargets, (XtArgVal) 1 },
  };

  /* Unregister default text widget drop sites that we don't support */
  for (i = 0; i < (int) XtNumber (no_drops); i++)
    {
      child = XxNameToWidget (window, no_drops[i]);
      XmDropSiteUnregister (child);
    }

  /* Unregister the rest of the text widget drop sites,
     because they need to be reparented. */
  child = XxNameToWidget (window, reparent_drops[0]);
  XtSetArg (textdrop_args[2], XmNimportTargets, &saved_text_import_targets);
  XtSetArg (textdrop_args[3], XmNnumImportTargets, &saved_num_import_targets);
  XtSetArg (textdrop_args[4], XmNdragProc, &saved_text_drag_proc);
  XtSetArg (textdrop_args[5], XmNdropProc, &saved_text_drop_proc);
  XmDropSiteRetrieve (child, &textdrop_args[2], 4);
  for (i = 0; i < (int) XtNumber (reparent_drops); i++)
    {
      child = XxNameToWidget (window, reparent_drops[i]);
      XmDropSiteUnregister (child);
    }

  /* Register new container drop sites so that we can manage hiding
     and unhiding drop sites in frames that get mapped/unmapped. */
  for (i = 0; i < (int) XtNumber (hide_drops); i++)
    {
      child = XxNameToWidget (window, hide_drops[i]);
      XmDropSiteRegister (child, hide_args, XtNumber (hide_args));
    }
  /* Put the stats frame on top by default, and activate it */
  XmDropSiteConfigureStackingOrder (XxNameToWidget (window, hide_drops[1]),
				    NULL, XmABOVE);
  XtSetArg (hide_args[1], XmNdropSiteActivity, XmDROP_SITE_ACTIVE);
  for (i = 0; i <= 1; i++)
    {
      child = XxNameToWidget (window, hide_drops[i]);
      XmDropSiteUpdate (child, &hide_args[1], 1);
    }

  /* Re-register text drop sites in the new hierarchy */
  XtSetArg (textdrop_args[2], XmNimportTargets, saved_text_import_targets);
  XtSetArg (textdrop_args[3], XmNnumImportTargets, saved_num_import_targets);
  XtSetArg (textdrop_args[4], XmNdragProc, saved_text_drag_proc);
  XtSetArg (textdrop_args[5], XmNdropProc, saved_text_drop_proc);
  for (i = 0; i < (int) XtNumber (reparent_drops); i++)
    {
      child = XxNameToWidget (window, reparent_drops[i]);
      XmDropSiteRegister (child, textdrop_args, 6);
    }

  /* Register item drop sites */
  item_import_targets[0] = XmInternAtom
    (XtDisplay (window), "DIABLO_ITEM_STRUCT", False);
  form = XxNameToWidget (window, "*frame_inventory*frame_stash");
  for (j = 0; j < VSIZE_STASH; j++)
    for (i = 0; i < HSIZE_STASH; i++)
      {
	sprintf (child_name, "*box_stash_%d%d", j, i);
	child = XxNameToWidget (form, child_name);
	XmDropSiteRegister (child, itemdrop_args, XtNumber (itemdrop_args));
      }
  form = XxNameToWidget (window, "*frame_inventory*frame_cube");
  for (j = 0; j < VSIZE_CUBE; j++)
    for (i = 0; i < HSIZE_CUBE; i++)
      {
	sprintf (child_name, "*box_cube_%d%d", j, i);
	child = XxNameToWidget (form, child_name);
	XmDropSiteRegister (child, itemdrop_args, XtNumber (itemdrop_args));
      }
  form = XxNameToWidget (window, "*frame_inventory*frame_inv");
  for (j = 0; j < VSIZE_INVENTORY; j++)
    for (i = 0; i < HSIZE_INVENTORY; i++)
      {
	sprintf (child_name, "*box_inv_%d%d", j, i);
	child = XxNameToWidget (form, child_name);
	XmDropSiteRegister (child, itemdrop_args, XtNumber (itemdrop_args));
      }
  child = XxNameToWidget (window, "*frame_inventory*frame_mouse*box_mouse");
  XmDropSiteRegister (child, itemdrop_args, XtNumber (itemdrop_args));

  item_import_targets[0] = XmInternAtom
    (XtDisplay (window), "DIABLO_ITEM_BELTABLE", False);
  form = XxNameToWidget (window, "*frame_inventory*frame_belt");
  for (i = 0; i < MSIZE_BELT; i++)
    {
      sprintf (child_name, "*box_belt_%d", i);
      child = XxNameToWidget (form, child_name);
      XmDropSiteRegister (child, itemdrop_args, XtNumber (itemdrop_args));
    }
  form = XxNameToWidget (window, "*frame_inventory*frame_equipment");
  for (i = 1; i < (int) XtNumber (equipment_button_names); i++)
    {
      sprintf (child_name, "DIABLO_ITEM_BODY_%s", body_loc_names[i]);
      item_import_targets[0]
	= XmInternAtom (XtDisplay (form), child_name, False);
      sprintf (child_name, "*box_equip_%s", equipment_button_names[i]);
      child = XxNameToWidget (form, child_name);
      XmDropSiteRegister (child, itemdrop_args, XtNumber (itemdrop_args));
    }
  form = XxNameToWidget (window, "*frame_hireling*frame_hire_equipment");
  for (i = 1; i < (int) XtNumber (equipment_button_names); i++)
    {
      sprintf (child_name, "*box_hire_equip_%s", equipment_button_names[i]);
      child = XtNameToWidget (form, child_name);
      if (child != NULL)
	{
	  sprintf (child_name, "DIABLO_ITEM_BODY_%s", body_loc_names[i]);
	  item_import_targets[0]
	    = XmInternAtom (XtDisplay (form), child_name, False);
	  XmDropSiteRegister (child, itemdrop_args, XtNumber (itemdrop_args));
	}
    }
}

/* Enable or disable a group of drop sites
   when a frame is mapped or unmapped */
void
ui_view_drop_site_update (Widget w, XtPointer client_data, XtPointer call_data)
{
#if 1
  Widget	frame = (Widget) client_data;
  Arg		args[1];

  /* I think all we need to do is put the composite drop site
     at the top of the stacking order! */
  if (XmToggleButtonGetState (w)) {
    XmDropSiteConfigureStackingOrder (frame, NULL, XmABOVE);
    /* ... and activate the container drop site. :-P */
    XtSetArg (args[0], XmNdropSiteActivity, XmDROP_SITE_ACTIVE);
  } else {
    XtSetArg (args[0], XmNdropSiteActivity, XmDROP_SITE_INACTIVE);
  }
  XmDropSiteUpdate (frame, args, 1);
#else /* 0ld code */
  Widget	parent = (Widget) client_data;
  WidgetList	children;
  int		i, num_children;
  Boolean	drop_state;
  Arg		args[1];

  if (XmIsLabel (parent))
    {
      /* Set the drop site active if:
       * - the widget is visible, and
       * - if the widget is a text widget, it is editable; or
       * - if the widget is an item box, we have a writable character
       */
      drop_state = XmToggleButtonGetState (w);
      if (XmIsTextField (parent))
	drop_state = drop_state && XmTextFieldGetEditable (parent);
      else if (XmIsText (parent))
	drop_state = False;

      XtSetArg (args[0], XmNdropSiteActivity,
		drop_state ? XmDROP_SITE_ACTIVE : XmDROP_SITE_INACTIVE);
      XmDropSiteUpdate (parent, args, 1);
    }

  if (!XtIsComposite (parent))
    return;

  XmDropSiteStartUpdate (parent);
  XtVaGetValues (parent,
		 XmNchildren, &children,
		 XmNnumChildren, &num_children,
		 NULL);
  for (i = 0; i < num_children; i++)
    {
      if (XtIsComposite (children[i]))
	ui_view_drop_site_update (w, children[i], call_data);
      else if (XmIsLabel (children[i]))
	XmDropSiteUpdate (children[i], args, 1);
    }
  XmDropSiteEndUpdate (parent);
#endif
}

void
register_item_drop_sites (Widget window)
{
  Widget	form, child;
  char		child_name[32];
  int		i;
  Atom		gem_import_targets[1];
  Arg		drop_args[] = {
    { XmNdropProc, (XtArgVal) ui_drop_gem },
    { XmNdropSiteOperations, (XtArgVal) XmDROP_NOOP },
    { XmNimportTargets, (XtArgVal) gem_import_targets },
    { XmNnumImportTargets, (XtArgVal) 1 },
  };

  /* Unregister default text widget drop sites that we don't support */
  for (i = 0; i < (int) XtNumber (no_item_drops); i++)
    {
      child = XtNameToWidget (window, no_item_drops[i]);
      if (child != NULL)
	XmDropSiteUnregister (child);
    }

  /* If the item has a sockets frame,
     register a drop site for each socket. */
  form = XtNameToWidget (window, "*frame_socketed_item");
  if (form == NULL)
    return;
  gem_import_targets[0] = XmInternAtom
    (XtDisplay (window), "DIABLO_ITEM_SOCKETABLE", False);
  for (i = 1; i <= MAX_DISPLAYED_SOCKETS; i++)
    {
      sprintf (child_name, "*form_socket%d", i);
      child = XtNameToWidget (form, child_name);
      if (child == NULL)
	break;
      XmDropSiteRegister (child, drop_args, XtNumber (drop_args));
    }
}

/* Initialize some common drag cursors */
static void
init_drag_cursors (Screen *screen)
{
  Dimension	width, height;
  Pixmap	bitmap, mask;
  Arg		args[12];
  int		n;

  /* Initialize the 'no' drag cursor */
  MrmFetchBitmapLiteral (mrm_hierarchy, "no_cursor",
			 screen, DisplayOfScreen (screen),
			 &bitmap, &width, &height);
  MrmFetchBitmapLiteral (mrm_hierarchy, "no_cursor_mask",
			 screen, DisplayOfScreen (screen),
			 &mask, &width, &height);
  n = 0;
  XtSetArg (args[n], XmNattachment, XmATTACH_NORTH_WEST); n++;
  XtSetArg (args[n], XmNheight, height); n++;
  /* The hotspot should be in the middle of this cursor */
  XtSetArg (args[n], XmNhotX, width / 2); n++;
  XtSetArg (args[n], XmNhotY, height / 2); n++;
  XtSetArg (args[n], XmNmask, mask); n++;
  /* The offset is chosen to place the cursor's hotspot in the middle
     of the top left box that the item occupies. */
  XtSetArg (args[n], XmNoffsetX, 14 - width / 2); n++;
  XtSetArg (args[n], XmNoffsetY, 14 - height / 2); n++;
  XtSetArg (args[n], XmNpixmap, bitmap); n++;
  XtSetArg (args[n], XmNwidth, width); n++;
  no_cursor = XmCreateDragIcon (toplevel, "no_cursor", args, n);

  /* Initialize the empty cursor */
  MrmFetchBitmapLiteral (mrm_hierarchy, "empty_cursor",
			 screen, DisplayOfScreen (screen),
			 &bitmap, &width, &height);
  n = 0;
  XtSetArg (args[n], XmNheight, height); n++;
  XtSetArg (args[n], XmNmask, bitmap); n++;
  XtSetArg (args[n], XmNoffsetX, 14); n++;
  XtSetArg (args[n], XmNoffsetY, 14); n++;
  XtSetArg (args[n], XmNpixmap, bitmap); n++;
  XtSetArg (args[n], XmNwidth, width); n++;
  empty_cursor = XmCreateDragIcon (toplevel, "empty_cursor", args, n);

  /* Initialize the copy drag cursor */
  MrmFetchBitmapLiteral (mrm_hierarchy, "copy_cursor",
			 screen, DisplayOfScreen (screen),
			 &bitmap, &width, &height);
  MrmFetchBitmapLiteral (mrm_hierarchy, "copy_cursor_mask",
			 screen, DisplayOfScreen (screen),
			 &mask, &width, &height);
  n = 0;
  XtSetArg (args[n], XmNattachment, XmATTACH_NORTH_WEST); n++;
  XtSetArg (args[n], XmNheight, height); n++;
  XtSetArg (args[n], XmNmask, mask); n++;
  /* The offset is chosen to place the center of the cursor
     on the top left corner of the item */
  XtSetArg (args[n], XmNoffsetX, -(width / 2)); n++;
  XtSetArg (args[n], XmNoffsetY, -(height / 2)); n++;
  XtSetArg (args[n], XmNpixmap, bitmap); n++;
  XtSetArg (args[n], XmNwidth, width); n++;
  copy_cursor = XmCreateDragIcon (toplevel, "no_cursor", args, n);
}

/* Start a drag-and-drop operation */
void
ui_start_drag (Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  Arg		args[12];
  Atom		export_list[8];
  Cardinal	num_exports;
  d2sItem	*item;
  Pixmap	icon, mask;
  Widget	drag_context, drag_icon;
  coordinate_t	item_size;
  char		make_name[32];
  int		n;

  /* Get the item associated with this button */
  XtVaGetValues (w, XmNuserData, &item, NULL);
  if (item == NULL)
    /* No item; return without doing anything (essentially a no-op). */
    return;

  /* Create an icon to use for the drag operation */
  icon = load_item_picture (XtScreen (w), item);
  mask = load_item_mask (XtScreen (w), item);
  item_size = item->Size();
  n = 0;
  XtSetArg (args[n], XmNheight, item_size.y * 28);
  /* The icon's hotspot should be the center of the top left box
     in an item that spans multiple boxes. */
  XtSetArg (args[n], XmNhotX, 14); n++;
  XtSetArg (args[n], XmNhotY, 14); n++;
  XtSetArg (args[n], XmNmask, mask); n++;
  XtSetArg (args[n], XmNpixmap, icon); n++;
  XtSetArg (args[n], XmNwidth, item_size.x * 28);
  drag_icon = XmCreateDragIcon (w, "drag_icon", args, n);
  if (drag_icon == NULL)
    {
      /* Error creating the drag icon!  Release the pixmaps. */
      if (icon != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (w), icon);
      if (mask != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (w), mask);
    }

  /* Create an icon for the initial drag state. */
  if (!no_cursor)
    init_drag_cursors (XtScreen (w));

  /* Technically, we only support one data type, but we support two
     modes of transfer - by pointer (within the same application) and
     by raw data (between applications).  But for the purpose of
     matching drag source with drop site, we take a different
     approach, and have a separate Atom for each *location* in which
     at item can be dropped. */
  num_exports = 0;
  export_list[num_exports++]
    = XmInternAtom (XtDisplay (w), "DIABLO_ITEM_STRUCT", False);
  if (GetEntryIntegerField (item->TypeTableEntry(), "Beltable"))
    export_list[num_exports++]
      = XmInternAtom (XtDisplay (w), "DIABLO_ITEM_BELTABLE", False);
  else if (GetEntryIntegerField (item->TypeTableEntry(), "Body")) {
    snprintf (make_name, sizeof (make_name), "DIABLO_ITEM_BODY_%s",
	     GetEntryStringField (item->TypeTableEntry(), "BodyLoc1"));
    export_list[num_exports++]
      = XmInternAtom (XtDisplay (w), make_name, False);
  }
  else if (IsTypeAMemberOf
	   (GetEntryStringField (item->TypeTableEntry(), "Code"), "sock"))
    export_list[num_exports++]
      = XmInternAtom (XtDisplay (w), "DIABLO_ITEM_SOCKETABLE", False);

  /* Create the drag context */
  n = 0;
  XtSetArg (args[n], XmNblendModel, XmBLEND_ALL); n++;
  XtSetArg (args[n], XmNclientData, w); n++;
  XtSetArg (args[n], XmNconvertProc, DragConvert); n++;
  /* If the item's owner is read-only or doesn't allow moving items,
     only allow the COPY operation (to a different character). */
  if ((item->Owner() != NULL) && (item->Owner()->read_only
				  || !options.character.edit.item_location)) {
    XtSetArg (args[n], XmNdragOperations, XmDROP_COPY); n++;
    XtSetArg (args[n], XmNoperationCursorIcon, copy_cursor); n++;
  } else {
    XtSetArg (args[n], XmNdragOperations, XmDROP_COPY | XmDROP_MOVE); n++;
    XtSetArg (args[n], XmNoperationCursorIcon, empty_cursor); n++;
  }
  XtSetArg (args[n], XmNexportTargets, export_list); n++;
  XtSetArg (args[n], XmNnumExportTargets, num_exports); n++;
  XtSetArg (args[n], XmNsourcePixmapIcon, drag_icon); n++;
  XtSetArg (args[n], XmNstateCursorIcon, no_cursor); n++;
  drag_context = XmDragStart (w, event, args, n);
  /* Do this using XtVaSetValues so that we can do type conversion */
  XtVaSetValues (drag_context,
		 XtVaTypedArg, XmNcursorBackground,
			       XtRString, "gray", sizeof ("gray"),
		 XtVaTypedArg, XmNnoneCursorForeground,
			       XtRString, "red", sizeof ("red"),
		 XtVaTypedArg, XmNinvalidCursorForeground,
			       XtRString, "red", sizeof ("red"),
		 XtVaTypedArg, XmNvalidCursorForeground,
			       XtRString, "green", sizeof ("green"),
		 NULL);

  /* Register callbacks */
  XtAddCallback (drag_context, XmNdragDropFinishCallback, DragFinish, NULL);
  XtAddCallback (drag_context, XmNdropSiteEnterCallback,
		 drag_op_changed, NULL);
  XtAddCallback (drag_context, XmNdropSiteLeaveCallback,
		 drag_op_change_none, NULL);
  XtAddCallback (drag_context, XmNoperationChangedCallback,
		 drag_op_changed, NULL);
}

/* Start a drag from a gem selection table */
void
ui_start_gem_drag (Widget w, XEvent *event, String *params,
		   Cardinal *num_params)
{
  int		type, grade;
  d2sGemItem	*gem;

  /* Get the gem associated with this button */
  XtVaGetValues (w, XmNuserData, &type, NULL);
  grade = type / 10;
  type = type % 10;
  gem = new d2sGemItem ();
  gem->TransformInto (type, grade);

  /* Move on to the common gem/rune/potion StartDrag function */
  start_grp_drag (w, event, gem);
}

/* Start a drag from a rune selection table */
void
ui_start_rune_drag (Widget w, XEvent *event, String *params,
		   Cardinal *num_params)
{
  int		number;
  d2sRuneItem	*rune;

  /* Get the rune associated with this button */
  XtVaGetValues (w, XmNuserData, &number, NULL);
  rune = new d2sRuneItem ();
  rune->TransformInto (number);

  /* Move on to the common gem/rune/potion StartDrag function */
  start_grp_drag (w, event, rune);
}

/* Start a drag from a potion selection table */
void
ui_start_potion_drag (Widget w, XEvent *event, String *params,
		   Cardinal *num_params)
{
  int		type, grade;
  d2sPotionItem	*potion;

  /* Get the potion associated with this button */
  XtVaGetValues (w, XmNuserData, &type, NULL);
  grade = type % 10;
  type = type / 10;
  potion = new d2sPotionItem ();
  potion->TransformInto (type, grade);

  /* Move on to the common gem/rune/potion StartDrag function */
  start_grp_drag (w, event, potion);
}

static void
start_grp_drag (Widget w, XEvent *event, d2sItem *item)
{
  Arg		args[12];
  Atom		export_list[2];
  Pixmap	icon, mask;
  Widget	drag_context, drag_icon;
  int		n;

  /* Create an icon to use for the drag operation */
  icon = load_item_picture (XtScreen (w), item);
  mask = load_item_mask (XtScreen (w), item);
  n = 0;
  XtSetArg (args[n], XmNheight, 28);
  /* The icon's hotspot should be the center of the top left box
     in an item that spans multiple boxes. */
  XtSetArg (args[n], XmNhotX, 14); n++;
  XtSetArg (args[n], XmNhotY, 14); n++;
  XtSetArg (args[n], XmNmask, mask); n++;
  XtSetArg (args[n], XmNpixmap, icon); n++;
  XtSetArg (args[n], XmNwidth, 28);
  drag_icon = XmCreateDragIcon (w, "drag_icon", args, n);
  if (drag_icon == NULL)
    {
      /* Error creating the drag icon!  Release the pixmaps. */
      if (icon != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (w), icon);
      if (mask != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (w), mask);
    }

  /* Create an icon for the initial drag state. */
  if (!no_cursor)
    init_drag_cursors (XtScreen (w));

  /* We export two 'types' of data - generic item and
     either socketable or beltable item */
  export_list[0]
    = XmInternAtom (XtDisplay (w), "DIABLO_ITEM_STRUCT", False);
  export_list[1]
    = ((item->Type() == POTION_ITEM)
       ? XmInternAtom (XtDisplay (w), "DIABLO_ITEM_BELTABLE", False)
       : XmInternAtom (XtDisplay (w), "DIABLO_ITEM_SOCKETABLE", False));

  /* Create the drag context */
  n = 0;
  XtSetArg (args[n], XmNblendModel, XmBLEND_ALL); n++;
  XtSetArg (args[n], XmNclientData, item); n++;
  XtSetArg (args[n], XmNconvertProc, GRPDragConvert); n++;
  XtSetArg (args[n], XmNdragOperations, XmDROP_COPY); n++;
  XtSetArg (args[n], XmNexportTargets, export_list); n++;
  XtSetArg (args[n], XmNnumExportTargets, 2); n++;
  XtSetArg (args[n], XmNoperationCursorIcon, copy_cursor); n++;
  XtSetArg (args[n], XmNsourcePixmapIcon, drag_icon); n++;
  XtSetArg (args[n], XmNstateCursorIcon, no_cursor); n++;
  drag_context = XmDragStart (w, event, args, n);
  /* Do this using XtVaSetValues so that we can do type conversion */
  XtVaSetValues (drag_context,
		 XtVaTypedArg, XmNcursorBackground,
			       XtRString, "gray", sizeof ("gray"),
		 XtVaTypedArg, XmNnoneCursorForeground,
			       XtRString, "red", sizeof ("red"),
		 XtVaTypedArg, XmNinvalidCursorForeground,
			       XtRString, "red", sizeof ("red"),
		 XtVaTypedArg, XmNvalidCursorForeground,
			       XtRString, "green", sizeof ("green"),
		 NULL);

  /* Register callbacks */
  XtAddCallback (drag_context, XmNdragDropFinishCallback, GRPDragFinish, NULL);
  XtAddCallback (drag_context, XmNdropSiteEnterCallback,
		 drag_op_changed, NULL);
  XtAddCallback (drag_context, XmNdropSiteLeaveCallback,
		 drag_op_change_none, NULL);
  XtAddCallback (drag_context, XmNoperationChangedCallback,
		 drag_op_changed, NULL);
}

/* Change the operation cursor */
static void
drag_op_changed (Widget drag_context,
		 XtPointer client_data, XtPointer call_data)
{
  XmOperationChangedCallbackStruct *cbs
    = (XmOperationChangedCallbackStruct *) call_data;
  XtVaSetValues
    (drag_context,
     XmNoperationCursorIcon, ((cbs->operation == XmDROP_COPY)
			      ? copy_cursor : empty_cursor),
     XmNstateCursorIcon, ((cbs->dropSiteStatus == XmDROP_SITE_VALID)
			  ? empty_cursor : no_cursor),
     NULL);
}

static void
drag_op_change_none (Widget drag_context,
		     XtPointer client_data, XtPointer call_data)
{
  XtVaSetValues (drag_context,
		 XmNstateCursorIcon, no_cursor,
		 NULL);
}

/* Clean up after a drag-and-drop */
static void
DragFinish (Widget drag, XtPointer client_data, XtPointer call_data)
{
  Widget	drag_icon;
  Pixmap	icon, mask;

  XtVaGetValues (drag,
		 XmNsourcePixmapIcon, &drag_icon,
		 NULL);
  if (drag_icon != NULL)
    {
      /* Destroy the icon pixmaps */
      XtVaGetValues (drag_icon,
		     XmNmask, &mask,
		     XmNpixmap, &icon,
		     NULL);
      XtVaSetValues (drag_icon,
		     XmNmask, XmUNSPECIFIED_PIXMAP,
		     XmNpixmap, XmUNSPECIFIED_PIXMAP,
		     NULL);
      if (icon != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (drag), icon);
      if (mask != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (drag), mask);

      /* Destroy the icon widget */
      XtDestroyWidget (drag_icon);
    }
}

static void
GRPDragFinish (Widget drag, XtPointer client_data, XtPointer call_data)
{
  Widget	drag_icon;
  Pixmap	icon, mask;
  d2sItem	*item;

  XtVaGetValues (drag,
		 XmNclientData, &item,
		 XmNsourcePixmapIcon, &drag_icon,
		 NULL);
  /* Delete the gem we created just for this drag operation */
  delete item;
  if (drag_icon != NULL)
    {
      /* Destroy the icon pixmaps */
      XtVaGetValues (drag_icon,
		     XmNmask, &mask,
		     XmNpixmap, &icon,
		     NULL);
      XtVaSetValues (drag_icon,
		     XmNmask, XmUNSPECIFIED_PIXMAP,
		     XmNpixmap, XmUNSPECIFIED_PIXMAP,
		     NULL);
      if (icon != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (drag), icon);
      if (mask != XmUNSPECIFIED_PIXMAP)
	XmDestroyPixmap (XtScreen (drag), mask);

      /* Destroy the icon widget */
      XtDestroyWidget (drag_icon);
    }
}

/* Process dropping an item onto an item box */
static void
ui_drop_item (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmDropProcCallbackStruct *cbs = (XmDropProcCallbackStruct *) call_data;
  Widget	docwindow;
  d2sData	*gamePtr;
  Arg		args[6];
  XmDropTransferEntryRec drop_transfers[4];
  int		n = 0, nt = 0;
  int		area;
  struct drop_data_t *drop_data;

  /* If we are not a valid drop site for the object, refuse the
     transfer.  Also, we don't support help (at this time). */
  if ((cbs->dropSiteStatus != XmDROP_SITE_VALID)
      || (cbs->dropAction != XmDROP))
    {
      XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_FAILURE); n++;
      XmDropTransferStart (cbs->dragContext, args, n);
      return;
    }

  docwindow = XtParent (w);
  while (!XtIsShell (XtParent (docwindow)))
    docwindow = XtParent (docwindow);
  stdui = docwindow;

  XtVaGetValues (docwindow, XmNuserData, &gamePtr, NULL);
  if (gamePtr == NULL)
    {
      fprintf (stderr, "%s: Internal error: drop site active on a window"
	       " with no character\n", progname);
      XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_FAILURE); n++;
      XmDropTransferStart (cbs->dragContext, args, n);
      return;
    }

  /* Get the destination area */
  area = get_focus_area (w);
  if (!area)
    {
      fprintf (stderr, "%s: Internal error: can't determine the area\n"
	       "where the drop site %s is located\n",
	       progname, XtName (w));
      XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_FAILURE); n++;
      XmDropTransferStart (cbs->dragContext, args, n);
      return;
    }

  /* Allocate a structure to hold the transfer data */
  drop_data = (struct drop_data_t *) XtMalloc (sizeof (struct drop_data_t));
  memset (drop_data, 0, sizeof (struct drop_data_t));
  drop_data->drop_site = w;
  drop_data->drop_window = XtWindow (docwindow);
  drop_data->drop_char = gamePtr;
  drop_data->operation = cbs->operation;
  drop_transfers[nt].client_data = (XtPointer) drop_data;

  /* If this is a copy operation, we simply need to determine
     whether the target allows adding items, and ask the
     drag source to send a copy of the item data. */
  if (cbs->operation == XmDROP_COPY)
    {
      if (gamePtr->read_only
	  || ((area == ITEM_AREA_HIRELING)
	      ? !options.character.edit.hireling_inventory
	      : ((area == ITEM_AREA_CORPSE)
		 ? !options.character.edit.corpse_inventory
		 : !options.character.edit.inventory)))
	{
	  XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_FAILURE); n++;
	  XmDropTransferStart (cbs->dragContext, args, n);
	  display_error ("You may not add items to %s",
			 gamePtr->GetCharacterName());
	  return;
	}

      /* Tell the drag source to send us a copy of the item. */
      drop_transfers[nt].target
	= XmInternAtom (XtDisplay (w), "DIABLO_ITEM_STRUCT", False); nt++;
    }

  else
    {
      /* The first peice of information we need from the drag source
	 is the window of the character the item was dragged from.  In
	 case the window is not the same character as this drop site,
	 we also would like to know whether the drag source and drop
	 site are managed by the same client.  The client is
	 identified by a client machine name (which we can derive from
	 the window, if needed) and a process ID. */
      drop_transfers[nt].target = XA_WINDOW; nt++;
    }
  XtSetArg (args[n], XmNdropTransfers, drop_transfers); n++;
  XtSetArg (args[n], XmNnumDropTransfers, nt); n++;
  XtSetArg (args[n], XmNtransferProc, DropTransfer); n++;
  XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_SUCCESS); n++;
  XmDropTransferStart (cbs->dragContext, args, n);
}

/* Process dropping an item onto a socket */
static void
ui_drop_gem (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmDropProcCallbackStruct *cbs = (XmDropProcCallbackStruct *) call_data;
  Widget	docwindow, socket_frame;
  d2sDurableItem *ditem;
  Arg		args[6];
  XmDropTransferEntryRec drop_transfers[4];
  int		n = 0, nt = 0;
  int		row;
  struct drop_data_t *drop_data;

  /* If we are not a valid drop site for the object, refuse the
     transfer.  Also, we don't support help (at this time). */
  if ((cbs->dropSiteStatus != XmDROP_SITE_VALID)
      || (cbs->dropAction != XmDROP))
    {
      XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_FAILURE); n++;
      XmDropTransferStart (cbs->dragContext, args, n);
      return;
    }

  docwindow = XtParent (w);
  while (!XtIsShell (XtParent (docwindow)))
    docwindow = XtParent (docwindow);
  stdui = docwindow;

  socket_frame = XxNameToWidget (docwindow, "*frame_socketed_item");
  XtVaGetValues (socket_frame, XmNuserData, &ditem, NULL);
  if (ditem == NULL)
    {
      fprintf (stderr, "%s: Internal error: drop site active on a socket"
	       " with no item\n", progname);
      XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_FAILURE); n++;
      XmDropTransferStart (cbs->dragContext, args, n);
      return;
    }

  /* If inserting gems is not allowed, and we are on a row with
     a gem already attached, fail. */
  row = get_box_location (w, ITEM_AREA_SOCKETED).x;
  if (ditem->read_only() || !options.item.edit.socketed_gems
      || (!options.item.edit.gem && (row < ditem->NumberOfGems())))
    {
      XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_FAILURE); n++;
      XmDropTransferStart (cbs->dragContext, args, n);
      XBell (XtDisplay (w), 0);
      return;
    }

  /* Allocate a structure to hold the transfer data */
  drop_data = (struct drop_data_t *) XtMalloc (sizeof (struct drop_data_t));
  memset (drop_data, 0, sizeof (struct drop_data_t));
  drop_data->drop_site = w;
  if (ditem->Owner() == NULL)
    drop_data->drop_window = XtWindow (docwindow);
  else {
    drop_data->drop_char = ditem->Owner();
    drop_data->drop_window = XtWindow ((Widget) ditem->Owner()->GetUI());
  }
  drop_data->drop_socket = ditem;
  drop_data->operation = cbs->operation;
  drop_transfers[nt].client_data = (XtPointer) drop_data;

  /* If this is a copy operation, we simply need to ask
     the drag source to send a copy of the gem data. */
  if (cbs->operation == XmDROP_COPY)
    {
      /* Tell the drag source to send us a copy of the item. */
      drop_transfers[nt].target
	= XmInternAtom (XtDisplay (w), "DIABLO_ITEM_STRUCT", False); nt++;
    }

  else
    {
      /* The first peice of information we need from the drag source
	 is the window of the character the item was dragged from.  In
	 case the window is not the same character as this drop site,
	 we also would like to know whether the drag source and drop
	 site are managed by the same client.  The client is
	 identified by a client machine name (which we can derive from
	 the window, if needed) and a process ID. */
      drop_transfers[nt].target = XA_WINDOW; nt++;
    }
  XtSetArg (args[n], XmNdropTransfers, drop_transfers); n++;
  XtSetArg (args[n], XmNnumDropTransfers, nt); n++;
  XtSetArg (args[n], XmNtransferProc, DropTransfer); n++;
  XtSetArg (args[n], XmNtransferStatus, XmTRANSFER_SUCCESS); n++;
  XmDropTransferStart (cbs->dragContext, args, n);
}

/* Drag source: return any requested data about the item being dragged. */
static Boolean
DragConvert (Widget drag_context, Atom *selection, Atom *target,
	     Atom *type_return, XtPointer *value_return,
	     unsigned long *length_return, int *format_return,
	     unsigned long *max_length, XtPointer client_data,
	     XtRequestId *request_id)
{
  Widget	button, docwindow;
  Atom		*atom_list;
  d2sItem	*item, *copy_of_item;
  struct data_stream item_data;
  char		*atom_name;

  /* Get the source widget */
  XtVaGetValues (drag_context, XmNclientData, &button, NULL);
  if (button == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: drag context did not have"
		 " the clientData resource set\n", progname);
      return False;
    }

  /* If this is not a drop, ignore the conversion request */
  if (*selection != XmInternAtom
      (XtDisplay (button), "_MOTIF_DROP", False))
    {
      if (debug)
	{
	  atom_name = XGetAtomName (XtDisplay (button), *selection);
	  fprintf (stderr, "%s: DragConvert() called with a selection of\n"
		   " \"%s\",", progname, atom_name);
	  XFree (atom_name);
	  atom_name = XGetAtomName (XtDisplay (button), *target);
	  fprintf (stderr, " a target of \"%s\", and client_data \"%s\"\n",
		   atom_name, XtName ((Widget) client_data));
	  XFree (atom_name);
	}
      return False;
    }

  /* Backtrack to the shell window so we know where to direct messages */
  docwindow = XtParent (button);
  while (!XtIsWMShell (XtParent (docwindow)))
    docwindow = XtParent (docwindow);
  stdui = docwindow;

  /* Get the source item */
  XtVaGetValues (button, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: drag source has no item\n",
		 progname);
      return False;
    }

  /* Check the transfer type */
  if (*target == XmInternAtom
      (XtDisplay (button), "TARGETS", False))
    {
      /* The drop site wants to know what targets we support. */
      if (debug)
	fprintf (stderr, "%s: DragConvert() called with a target of\n"
		 " \"TARGETS\" and client_data \"%s\"\n",
		 progname, XtName ((Widget) client_data));
      *type_return = *target;
      atom_list = (Atom *) XtMalloc (5 * sizeof (Atom));
      *value_return = (XtPointer) atom_list;
      atom_list[0] = XA_WINDOW;
      atom_list[1] = XmInternAtom (XtDisplay (button), "PROCESS", False);
      atom_list[2] = XmInternAtom (XtDisplay (button), "POINTER", False);
      atom_list[3] = XmInternAtom
	(XtDisplay (button), "DIABLO_ITEM_STRUCT", False);
      atom_list[4] = XmInternAtom (XtDisplay (button), "DELETE", False);
      *length_return = 5;
      *format_return = 8 * sizeof (Atom);
      return True;
    }

  if (*target == XA_WINDOW)
    {
      /* The drop site wants to know the window ID of the drag source.
	 This will be either the character window, or the item editor
	 window if the item was taken from a socket or has no owner. */
      *type_return = XA_WINDOW;
      *value_return = (XtPointer) XtMalloc (sizeof (Window));
      if (item->Location() == ITEM_AREA_SOCKETED)
	*((Window *) *value_return) = XtWindow
	  ((Widget) ((d2sAttachItem *) *item)->AttachedTo()->GetUI());
      else if (item->Owner() != NULL)
	*((Window *) *value_return) = XtWindow
	  ((Widget) item->Owner()->GetUI());
      else
	*((Window *) *value_return) = XtWindow ((Widget) item->GetUI());
      *length_return = 1;
      *format_return = 8 * sizeof (Window);
      return True;
    }

  if (*target == XmInternAtom
      (XtDisplay (button), "PROCESS", False))
    {
      /* The drop site wants to know our process ID. */
      *type_return = *target;
      *value_return = (XtPointer) XtMalloc (sizeof (pid_t));
      *((pid_t *) *value_return) = getpid();
      *length_return = 1;
      *format_return = 8 * sizeof (pid_t);
      return True;
    }

  if (*target == XmInternAtom
      (XtDisplay (button), "POINTER", False))
    {
      /* The drop site is managed by the same process as the drag
	 source, so we can simply pass the item by reference. */
      *type_return = *target;
      *value_return = (XtPointer) XtMalloc (sizeof (d2sItem *));
      *((d2sItem **) *value_return) = item;
      *length_return = 1;
      *format_return = 8 * sizeof (void *);
      return True;
    }

  if (*target == XmInternAtom
      (XtDisplay (button), "DIABLO_ITEM_STRUCT", False))
    {
      /* The drop site needs a copy of the item.
	 We must be sure to use XtMalloc to allocate storage for the
	 item data, so the toolkit will release the space properly.
	 (1K should be plenty for any item; if not, hope that
	 the C library realloc() is compatible with XtRealloc()!) */
      copy_of_item = item->Copy();
      dstream_set (item_data, XtMalloc (1024), 0, 1024);
      copy_of_item->Write (&item_data);
      delete copy_of_item;
      *type_return = *target;
      *value_return = (XtPointer) item_data.base;
      *length_return = item_data.ptr - item_data.base;
      *format_return = 8;
      return True;
    }

  if (*target == XmInternAtom
      (XtDisplay (button), "DELETE", False))
    {
      /* The drop site has successfully obtained a copy of the item,
	 and since it was a move operation, it wants us to delete the
	 original.  Note that this operation may yet fail if the
	 item's owner will not allow us to remove the item.  If it
	 fails, the drop site needs to react by removing its copy. */
      if (item->Owner() != NULL)
	{
	  remove_item_from_inventory (item);
	  if (item->Owner()->RemoveItem (item) < 0)
	    {
	      update_item_in_inventory (item);
	      display_error (item->Owner()->GetErrorMessage());
	      return False;
	    }
	}
      /* If the item had either a popup window or an editor window,
	 destroy it.  (The DELETE target is only used when moving
	 an item from one client to another, I think.) */
      if (item->GetUI() != NULL)
	{
	  XtDestroyWidget (XtParent ((Widget) item->GetUI()));
	  XtVaSetValues ((Widget) item->GetUI(), XmNuserData, NULL, NULL);
	  item->SetUI (NULL);
	}
      /* Destroy the item */
      delete item;

      /* Tell the drop site that we've deleted the original item. */
      *type_return = *target;
      *value_return = NULL;
      *length_return = 0;
      *format_return = 8;
      return True;
    }

  /* No match for the target type */
  return False;
}

static Boolean
GRPDragConvert (Widget drag_context, Atom *selection, Atom *target,
		Atom *type_return, XtPointer *value_return,
		unsigned long *length_return, int *format_return,
		unsigned long *max_length, XtPointer client_data,
		XtRequestId *request_id)
{
  Atom		*atom_list;
  d2sItem	*item;
  struct data_stream item_data;

  /* If this is not a drop, ignore the conversion request */
  if (*selection != XmInternAtom
      (XtDisplay (toplevel), "_MOTIF_DROP", False))
    return False;

  /* Get the source gem */
  XtVaGetValues (drag_context, XmNclientData, &item, NULL);

  /* Check the transfer type */
  if (*target == XmInternAtom
      (XtDisplay (toplevel), "TARGETS", False))
    {
      /* The drop site wants to know what targets we support. */
      if (debug)
	fprintf (stderr, "%s: DragConvert() called with a target of\n"
		 " \"TARGETS\" and client_data \"%s\"\n",
		 progname, XtName ((Widget) client_data));
      *type_return = *target;
      atom_list = (Atom *) XtMalloc (sizeof (Atom));
      *value_return = (XtPointer) atom_list;
      atom_list[0] = XmInternAtom
	(XtDisplay (toplevel), "DIABLO_ITEM_STRUCT", False);
      *length_return = 1;
      *format_return = 8 * sizeof (Atom);
      return True;
    }

  if (*target == XmInternAtom
      (XtDisplay (toplevel), "DIABLO_ITEM_STRUCT", False))
    {
      /* The drop site needs a copy of the gem.
	 We must be sure to use XtMalloc to allocate storage for the
	 item data, so the toolkit will release the space properly. */
      dstream_set (item_data, XtMalloc (sizeof (item_header)),
		   0, sizeof (item_header));
      item->Write (&item_data);
      *type_return = *target;
      *value_return = (XtPointer) item_data.base;
      *length_return = item_data.ptr - item_data.base;
      *format_return = 8;
      return True;
    }

  /* No match for the target type */
  return False;
}

/* Drop site: gather data about the item being dragged,
   and request more data as needed. */
static void
DropTransfer (Widget w, XtPointer client_data, Atom *selection,
	      Atom *type, XtPointer value,
	      unsigned long *length, int *format)
{
  struct drop_data_t *drop_data = (struct drop_data_t *) client_data;
  XmDropTransferEntryRec drop_transfers[2];
  int		nt = 0;
  struct data_stream item_data;
  Widget	docwindow;
  int		area;
  coordinate_t	location;
  char		*atom_name;

  docwindow = XtParent (drop_data->drop_site);
  while (!XtIsShell (XtParent (docwindow)))
    docwindow = XtParent (docwindow);
  stdui = docwindow;

  if (*type == XA_WINDOW)
    {
      drop_data->source_window = *((Window *) value);
      drop_transfers[nt].client_data = (XtPointer) drop_data;
      /* Is the source window the same as the destination? */
      if (drop_data->source_window == drop_data->drop_window)
	{
	  /* Good!  Moving within the same character.
	     All we need then is a pointer to the item. */
	  drop_transfers[nt].target = XmInternAtom
	    (XtDisplay (docwindow), "POINTER", False); nt++;
	}
      else
	{
	  /* We would like to know whether the source is the same
	     client as us.  If so, we can get the item by reference. */
	  drop_transfers[nt].target = XmInternAtom
	    (XtDisplay (docwindow), "PROCESS", False); nt++;
	}
      XmDropTransferAdd (w, drop_transfers, nt);
      return;
    }

  if (*type == XmInternAtom (XtDisplay (docwindow), "PROCESS", False))
    {
      drop_data->source_pid = *((pid_t *) value);
      drop_transfers[nt].client_data = (XtPointer) drop_data;
      if (drop_data->source_pid == getpid())
	{
	  /* Sure, the two PID's are the same, but are they both
	     on the same machine?  To determine this, we look
	     at the client associated with each window. */
	  /* TO-DO; for now, assume it is very unlikely (< 0.01%)
	     that two d2sEdit programs running on two different
	     clients will have the same PID. */
	}
      if (drop_data->source_pid == getpid())
	{
	  /* Ask for the item by reference. */
	  drop_transfers[nt].target = XmInternAtom
	    (XtDisplay (docwindow), "POINTER", False); nt++;
	}
      else
	{
	  /* The source is in a different client,
	     so ask him to send us the item data. */
	  drop_transfers[nt].target = XmInternAtom
	    (XtDisplay (docwindow), "DIABLO_ITEM_STRUCT", False); nt++;
	}
      XmDropTransferAdd (w, drop_transfers, nt);
      return;
    }

  if (*type == XmInternAtom (XtDisplay (docwindow), "POINTER", False)) {
    /* We have the item being transferred by reference! */
    drop_data->itemPtr = *((d2sItem **) value);
    drop_data->referenced = True;
    if (!drop_finish (drop_data))
      /* Error encountered during the drop */
      XtVaSetValues (w, XmNtransferStatus, XmTRANSFER_FAILURE, NULL);
    /* Always remember to free our temporary storage
       when the transfer is finished. */
    XtFree ((char *) drop_data);
    return;
  }

  if (*type == XmInternAtom (XtDisplay (docwindow),
			     "DIABLO_ITEM_STRUCT", False)) {
    /* We've been given a copy of the item data.
       Convert it to an item object. */
    dstream_set (item_data, value, 0, *length);
    drop_data->itemPtr = ReadItemFromFile (&item_data);
    if (drop_data->itemPtr == NULL) {
      XtVaSetValues (w, XmNtransferStatus, XmTRANSFER_FAILURE, NULL);
    } else if (drop_data->itemPtr->GetErrorMessage() != NULL) {
      display_error (drop_data->itemPtr->GetErrorMessage());
      XtVaSetValues (w, XmNtransferStatus, XmTRANSFER_FAILURE, NULL);
    } else {
      /* If this is a move operation, don't actually perform the
	 add until the drag source has deleted the original item. */
      if (drop_data->operation == XmDROP_MOVE) {
	area = get_focus_area (drop_data->drop_site);
	if (area == ITEM_AREA_SOCKETED) {
	  /* TO DO */
	} else {
	  if (drop_data->drop_char->read_only
	      || ((area == ITEM_AREA_HIRELING)
		  ? !options.character.edit.hireling_inventory
		  : ((area == ITEM_AREA_CORPSE)
		     ? !options.character.edit.corpse_inventory
		     : !options.character.edit.inventory))) {
	    display_error ("You may not add items to %s",
			   drop_data->drop_char->GetCharacterName());
	    XtVaSetValues (w, XmNtransferStatus, XmTRANSFER_FAILURE, NULL);
	    XtFree ((char *) drop_data);
	    return;
	  }
	  location = get_box_location (drop_data->drop_site, area);
	  if (drop_data->drop_char->CheckLocationAvailable
	      (drop_data->itemPtr, area, location.x, location.y) < 0) {
	    /* Not enough room here; most likely overlapping another item */
	    display_error ("No room to put the %s there",
			   drop_data->itemPtr->Name());
	    XtVaSetValues (w, XmNtransferStatus, XmTRANSFER_FAILURE, NULL);
	    XtFree ((char *) drop_data);
	    return;
	  }
	}
	/* The destination looks okay; request the original to be deleted */
	drop_transfers[nt].client_data = (XtPointer) drop_data;
	drop_transfers[nt].target = XmInternAtom
	  (XtDisplay (docwindow), "DELETE", False); nt++;
	XmDropTransferAdd (w, drop_transfers, nt);
	return;
      }
      if (!drop_finish (drop_data))
	XtVaSetValues (w, XmNtransferStatus, XmTRANSFER_FAILURE, NULL);
    }
    XtFree ((char *) drop_data);
    return;
  }

  if (*type == XmInternAtom (XtDisplay (docwindow), "DELETE", False)) {
    /* Finish the move operation that was deferred above */
    if (!drop_finish (drop_data))
      XtVaSetValues (w, XmNtransferStatus, XmTRANSFER_FAILURE, NULL);
    XtFree ((char *) drop_data);
    return;
  }

  if (debug)
    {
      atom_name = XGetAtomName (XtDisplay (docwindow), *type);
      fprintf (stderr, "%s: Internal error: DropTransfer called with\n"
	       " unknown transfer type \"%s\"\n", progname, atom_name);
      XFree (atom_name);
    }
  XtVaSetValues (w, XmNtransferStatus, XmTRANSFER_FAILURE, NULL);
  XtFree ((char *) drop_data);
  return;
}

static Boolean
drop_finish (struct drop_data_t *drop_data)
{
  d2sItem	*itemPtr = drop_data->itemPtr;
  d2sAttachItem *gem = NULL;
  d2sDurableItem *prev_socket = NULL;
  d2sData	*prev_owner = NULL;
  int		area, old_area;
  coordinate_t	location, old_location, size;

  /* Get the desired destination */
  area = get_focus_area (drop_data->drop_site);
  location = get_box_location (drop_data->drop_site, area);

  /* If this is a move operation, start by removing the item
     from its previous location.  (If the item was passed by
     value, this was already done by a DELETE message.) */
  if ((drop_data->operation == XmDROP_MOVE) && drop_data->referenced) {
    /* In case there is an error, and we need to
       put the item back, remember where it came from. */
    prev_owner = itemPtr->Owner();
    old_area = itemPtr->Location();
    old_location = itemPtr->Position();
    if (prev_owner != NULL)
      stdui = prev_owner->GetUI();

    if (old_area == ITEM_AREA_SOCKETED) {
      gem = ((d2sAttachItem *) *itemPtr);
      prev_socket = gem->AttachedTo();
      if ((prev_socket->GetUI() != NULL)
	  && (strcmp (XtName ((Widget) prev_socket->GetUI()),
		      "form_item") == 0))
	stdui = prev_socket->GetUI();
      /* Move the gem out of its current socket. */
      if (prev_socket->RemoveGem (gem) < 0) {
	display_error (prev_socket->GetErrorMessage());
	return False;
      }
      gem->RemoveFromOwner();
      /* Update the gem's previous owner, unless the gem
	 is going to go back in later. */
      if ((area != old_area) || (drop_data->drop_socket != prev_socket))
	update_socketed_item (prev_socket);
    }

    else if (prev_owner != NULL) {
      if ((area == ITEM_AREA_SOCKETED)
	  || (drop_data->drop_char != prev_owner)) {
	/* Remove the item from its current owner. */
	remove_item_from_inventory (itemPtr);
	if (prev_owner->RemoveItem (itemPtr) < 0) {
	  /* Error!  Put the item back. */
	  update_item_in_inventory (itemPtr);
	  display_error (prev_owner->GetErrorMessage());
	  return False;
	}
      }
      else {
	/* Item is being moved within a single character's inventory. */
	remove_item_from_inventory (itemPtr);
	if (prev_owner->MoveItemTo
	    (itemPtr, area, location.x, location.y) < 0) {
	  /* Error!  Put the item back. */
	  update_item_in_inventory (itemPtr);
	  display_error (prev_owner->GetErrorMessage());
	  return False;
	}
	/* We're done processing in this case */
	update_item_in_inventory (itemPtr);
	if ((itemPtr->GetUI() != NULL)
	    && (strcmp (XtName ((Widget) itemPtr->GetUI()), "form_item") == 0))
	  update_item_window_title ((Widget) itemPtr->GetUI(), itemPtr);
	return True;
      }
    }
  } /* Move an item by reference */

  /* Now try to assign the item to its new location */
  if (area != ITEM_AREA_SOCKETED) {
    stdui = drop_data->drop_char->GetUI();
    /* Clip the item's location if it's too big */
    size = itemPtr->Size();
    switch (area) {
    case ITEM_AREA_STASH:
      if (location.x + size.x > HSIZE_STASH)
	location.x = HSIZE_STASH - size.x;
      if (location.y + size.y
	  > (drop_data->drop_char->is_expansion()
	     ? VSIZE_STASH : (VSIZE_STASH / 2)))
	location.y = (drop_data->drop_char->is_expansion()
		      ? VSIZE_STASH : (VSIZE_STASH / 2)) - size.y;
      break;
    case ITEM_AREA_INVENTORY:
      if (location.x + size.x > HSIZE_INVENTORY)
	location.x = HSIZE_INVENTORY - size.x;
      if (location.y + size.y > VSIZE_INVENTORY)
	location.y = HSIZE_INVENTORY - size.y;
      break;
    case ITEM_AREA_CUBE:
      if (location.x + size.x > HSIZE_CUBE)
	location.x = HSIZE_CUBE - size.x;
      if (location.y + size.y > VSIZE_CUBE)
	location.y = HSIZE_CUBE - size.y;
      break;
    }
    if (itemPtr->SetLocation (area, location.x, location.y) < 0) {
      /* Error!  Put the item back. */
      put_item_back (drop_data, prev_owner, old_area,
		     old_location, prev_socket);
      return False;
    }
    if (drop_data->drop_char->AddItem (itemPtr) < 0) {
      /* Error!  Put the item back. */
      put_item_back (drop_data, prev_owner, old_area,
		     old_location, prev_socket);
      return False;
    }

    /* Success!  Update the character's inventory. */
    update_item_in_inventory (itemPtr);
    /* If the item is displayed in an editor window,
       update the window title to show the (possibly changed) owner. */
    if ((itemPtr->GetUI() != NULL)
	&& (strcmp (XtName ((Widget) itemPtr->GetUI()), "form_item") == 0))
      update_item_window_title ((Widget) itemPtr->GetUI(), itemPtr);
    return True;
  } /* Not destined for a socket */

  else {
    /* The item is going into a socket.  First, assign the item
       to the character who owns the socketed item. */
    gem = ((d2sAttachItem *) *itemPtr);
    gem->AssignTo (drop_data->drop_char);
    /* Then, add the gem to the desired socket */
    if (location.x > drop_data->drop_socket->NumberOfGems())
      location.x = drop_data->drop_socket->NumberOfGems();
    if (drop_data->drop_socket->AddGem (gem, location.x) < 0) {
      /* Error!  Put the item back. */
      gem->RemoveFromOwner ();
      put_item_back (drop_data, prev_owner, old_area,
		     old_location, prev_socket);
      return False;
    }

    /* Success!  Update the item we got stuck in. */
    update_socketed_item (drop_data->drop_socket);
    /* Gem descriptions can change after insertion into an item,
       so update the gem's editor window too. */
    if ((gem->GetUI() != NULL)
	&& (strcmp (XtName ((Widget) gem->GetUI()), "form_item") == 0))
      {
	update_item_window_title ((Widget) gem->GetUI(), gem);
	update_basic_item_description ((Widget) gem->GetUI(), gem);
      }
    return True;
  }
}

/* If the above function failed, and we have already removed a
   referenced item from its previous location, (try to) restore
   its original location. */
static void
put_item_back (struct drop_data_t *drop_data, d2sData *prev_owner,
	       int old_area, coordinate_t old_location,
	       d2sDurableItem *prev_socket)
{
  if (!drop_data->referenced) {
    /* We were given a copy of the item.  Delete the copy. */
    delete drop_data->itemPtr;
    drop_data->itemPtr = NULL;
    return;
  }

  if (old_area == ITEM_AREA_SOCKETED) {
    /* Put the item back in the socket it came from */
    d2sAttachItem *gem = (d2sAttachItem *) *(drop_data->itemPtr);
    if (prev_owner != NULL)
      gem->AssignTo (prev_owner, old_area);
    if (prev_socket->AddGem (gem, old_location.x) < 0) {
      if (debug)
	fprintf (stderr, "%s: Internal error: unable to replace\n"
		 " %s in %s after removing it\n",
		 progname, drop_data->itemPtr->Name(), prev_socket->Name());
    }
    else
      update_socketed_item (prev_socket);
    return;
  }

  if (prev_owner != NULL) {
    /* Give the item back to its former owner */
    if (prev_owner->AddItem (drop_data->itemPtr) < 0) {
      if (debug)
	fprintf (stderr, "%s: Internal error: unable to replace\n"
		 " %s's %s after removing it\n",
		 progname, prev_owner->GetCharacterName(),
		 drop_data->itemPtr->Name());
    }
    else
      update_item_in_inventory (drop_data->itemPtr);
    return;
  }
}
