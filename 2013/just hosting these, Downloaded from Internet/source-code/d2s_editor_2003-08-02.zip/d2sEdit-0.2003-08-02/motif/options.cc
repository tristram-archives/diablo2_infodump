/* UI function for managing the editor options dialog.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "ui.h"
#include <Xm/ComboBox.h>
#include <Xm/DragDrop.h>
#include <Xm/List.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <dmalloc.h>

/* Forward declarations: */
static Widget create_options_dialog (void);
static void close_options_dialog (Widget, XtPointer, XtPointer);
static void destroy_options_dialog (Widget, XtPointer, XtPointer);
static void ui_force_toggle_when_set (Widget, XtPointer, XtPointer);
static void ui_force_toggle_when_unset (Widget, XtPointer, XtPointer);
static void ui_options_ok (Widget, XtPointer, XtPointer);

static void update_all_character_windows (void);
static void update_unclaimed_item_windows (void);
static void update_widget_tree (Widget window, const char *tree_prefix,
				void *objPtr, int read_only,
				struct condition_list_t *cl, int list_size);
static void update_widget_editable (Widget parent,
				    void *objPtr, int read_only,
				    struct condition_list_t *cl);

/* Action functions: */
typedef void (*action_function_t) (Widget, int);
static void TextFieldSetEditable (Widget textf, int editable);
static void ButtonSetSensitive (Widget w, int sensitive);
static void ScaleSetEditable (Widget scale, int editable);
static void SpinBoxSetArrows (Widget spinbox, int arrows);
static void WidgetSetManaged (Widget w, int managed);
static void WidgetSetDropSite (Widget w, int droppable);

/* Predicate functions must be one of these types
   (where the 'void *' is either a d2sData* or d2sItem*) */
typedef int (*predicate_t) (void *, Widget);
typedef int (*array_predicate_t) (void *, Widget, int);
typedef int (*matrix_predicate_t) (void *, Widget, int, int);

/* Forward declarations of predicates: */
static int char_stat_points_available (void *, Widget);
static int char_skill_editable (void *, Widget);
static int char_skill_available (void *, Widget);
static int char_inventory_drop (void *, Widget);
static int char_npcs_editable (void *, Widget, int, int);
static int char_act_exit_editable (void *, Widget, int);
static int char_waypoint_editable (void *, Widget, int, int);
static int char_quest_editable (void *, Widget, int, int);
static int char_quests_editable (void *, Widget);
static int hireling_name_editable (void *, Widget);
static int hireling_class_editable (void *, Widget);
static int hireling_attribute_editable (void *, Widget);
static int hireling_experience_editable (void *, Widget);
static int hireling_level_editable (void *, Widget);
static int hireling_inventory_drop (void *, Widget);
static int item_repable (void *, Widget);
static int item_moveable (void *, Widget);
static int item_removeable (void *, Widget);
static int item_unclaimed (void *, Widget);
static int item_ethereal (void *, Widget);
static int item_can_have_more_sockets (void *, Widget);
static int item_can_have_less_sockets (void *, Widget);
static int item_gem_can_move_up (void *, Widget, int);
static int item_gem_can_move_down (void *, Widget, int);
static int item_can_add_gems (void *, Widget, int);
static int item_identification_changeable (void *, Widget);
static int item_personalization_changeable (void *, Widget);
static int item_quality_changeable (void *, Widget);
static int item_quality_can_be_low (void *, Widget);
static int item_quality_can_be_normal (void *, Widget);
static int item_quality_can_be_high (void *, Widget);
static int item_quality_can_be_magic (void *, Widget);
static int item_quality_can_be_set (void *, Widget);
static int item_quality_can_be_rare (void *, Widget);
static int item_quality_can_be_unique (void *, Widget);
static int install_magic_prefixes (void *, Widget);
static int install_magic_suffixes (void *, Widget);
static int install_set_names (void *, Widget);
static int install_rare_first_names (void *, Widget);
static int install_rare_last_names (void *, Widget);
static int install_rare_xfixes (void *, Widget, int);
static int install_unique_names (void *, Widget);
static void install_magic_xfixes (Widget, const d2sItem *, Boolean rare,
				  StringList (*) (const char *, int, int,
						  int, int, int));


/* This structure defines the relationship between game options
   and toggle buttons in the option dialog: */
static struct {
  int		*poption;
  const char	*toggle_button;
} toggle_map[] = {
  { &options.character.edit.name,	"*toggle_edit_name"	},
  { &options.character.edit.title,	"*toggle_edit_title"	},
  { &options.character.edit.expansion,	"*toggle_edit_expansion" },
  { &options.character.edit.hardcore,	"*toggle_edit_hardcore"	},
  { &options.character.edit.died,	"*toggle_edit_died"	},
  { &options.character.edit.up_and_down, "*toggle_edit_up_and_down"	},
  { &options.character.edit.experience,	"*toggle_edit_experience"	},
  { &options.character.edit.level,	"*toggle_edit_level"	},
  { &options.character.edit.stats,	"*toggle_edit_stats"	},
  { &options.character.edit.stats2,	"*toggle_edit_stats2"	},
  { &options.character.edit.stat_points, "*toggle_edit_stat_points"	},
  { &options.character.edit.skills,	"*toggle_edit_skills"	},
  { &options.character.edit.skill_points, "*toggle_edit_skill_points"	},
  { &options.character.edit.gold,	"*toggle_edit_gold"	},
  { &options.character.edit.item_location, "*toggle_edit_item_location"	},
  { &options.character.edit.inventory,	"*toggle_edit_inventory"	},
  { &options.character.edit.corpse_inventory,
    "*toggle_edit_corpse_inventory" },
  { &options.character.edit.backward,	"*toggle_edit_backward"	},
  { &options.character.edit.all_difficulties,
    "*toggle_edit_all_difficulties" },
  { &options.character.edit.npcs,	"*toggle_edit_npcs"	},
  { &options.character.edit.acts,	"*toggle_edit_acts"	},
  { &options.character.edit.act_location, "*toggle_edit_act_location"	},
  { &options.character.edit.waypoints,	"*toggle_edit_waypoints"	},
  { &options.character.edit.quests_complete, "*toggle_edit_quests_complete" },
  { &options.character.edit.quests_intermediate,
    "*toggle_edit_quests_intermediate"	},
  { &options.character.edit.hireling_add, "*toggle_edit_hireling_add"	},
  { &options.character.edit.hireling_name, "*toggle_edit_hireling_name"	},
  { &options.character.edit.hireling_attribute,
    "*toggle_edit_hireling_attribute" },
  { &options.character.edit.hireling_experience,
    "*toggle_edit_hireling_experience"	},
  { &options.character.edit.hireling_level, "*toggle_edit_hireling_level" },
  { &options.character.edit.hireling_inventory,
    "*toggle_edit_hireling_inventory"	},
  { &options.character.link.level_experience,
    "*toggle_link_level_experience" },
  { &options.character.link.level_stats, "*toggle_link_level_stats"	},
  { &options.character.link.stats_points, "*toggle_link_stats_points"	},
  { &options.character.link.stats_stats2, "*toggle_link_stats_stats2"	},
  { &options.character.link.stats2_base, "*toggle_link_stats2_base"	},
  { &options.character.link.skills_points, "*toggle_link_skills_points"	},
  { &options.character.link.skills_level, "*toggle_link_skills_level"	},
  { &options.character.link.skills_skills, "*toggle_link_skills_skills"	},
  { &options.character.link.auto_skill, "*toggle_link_auto_skill"	},
  { &options.character.link.equipment_level, "*toggle_link_equipment_level" },
  { &options.character.link.equipment_class, "*toggle_link_equipment_class" },
  { &options.character.link.act_entry,	"*toggle_link_act_entry"	},
  { &options.character.link.auto_act,	"*toggle_link_auto_act"	},
  { &options.character.link.act_quest,	"*toggle_link_act_quest"	},
  { &options.character.link.act_location, "*toggle_link_act_location"	},
  { &options.character.link.act_waypoint, "*toggle_link_act_waypoint"	},
  { &options.character.link.quest_quest, "*toggle_link_quest_quest"	},
  { &options.character.link.quest_inventory, "*toggle_link_quest_inventory" },
  { &options.character.link.auto_quest,	"*toggle_link_auto_quest"	},
  { &options.character.link.freeform,	"*toggle_link_freeform"	},
  { &options.item.edit.potion,		"*toggle_edit_potion"	},
  { &options.item.edit.gem,		"*toggle_edit_gem"	},
  { &options.item.edit.identified,	"*toggle_edit_identified"	},
  { &options.item.edit.personalized,	"*toggle_edit_personalized"	},
  { &options.item.edit.newbie,		"*toggle_edit_newbie"	},
  { &options.item.edit.ethereal,	"*toggle_edit_ethereal"	},
  { &options.item.edit.quantity,	"*toggle_edit_quantity"	},
  { &options.item.edit.durability,	"*toggle_edit_durability"	},
  { &options.item.edit.base_durability,	"*toggle_edit_base_durability"	},
  { &options.item.edit.defense,		"*toggle_edit_defense"	},
  { &options.item.edit.socketed_gems,	"*toggle_edit_socketed_gems"	},
  { &options.item.edit.socket_count,	"*toggle_edit_socket_count"	},
  { &options.item.edit.fingerprint,	"*toggle_edit_fingerprint"	},
  { &options.item.edit.level,		"*toggle_edit_item_level"	},
  { &options.item.edit.quality,		"*toggle_edit_quality"	},
  { &options.item.edit.picture,		"*toggle_edit_picture"	},
  { &options.item.edit.magic_name,	"*toggle_edit_magic_name"	},
  { &options.item.edit.set_or_unique,	"*toggle_edit_set_or_unique"	},
  { &options.item.edit.magic_properties, "*toggle_edit_magic_properties" },
  { &options.item.edit.magic_property_list,
    "*toggle_edit_magic_property_list" },
  { &options.item.link.item_expansion,	"*toggle_link_item_expansion"	},
  { &options.item.link.durability_ethereal,
    "*toggle_link_durability_ethereal" },
  { &options.item.link.durability_base,	"*toggle_link_durability_base"	},
  { &options.item.link.quantity_max,	"*toggle_link_quantity_max"	},
  { &options.item.link.durability_max,	"*toggle_link_durability_max"	},
  { &options.item.link.defense_max,	"*toggle_link_defense_max"	},
  { &options.item.link.quality_magic,	"*toggle_link_quality_magic"	},
  { &options.item.link.properties_range, "*toggle_link_properties_range" },
  { &options.item.link.show_popup,	"*toggle_link_show_popup"	},
};

/* This structure defines toggles which should be set when a related
   toggle is set, and vice-versa.  (i.e., don't allow the first
   toggle to be clear and the second to be set at the same time.) */
static struct {
  const char	*toggle_set;
  const char	*toggle_unset;
} toggle_sync[] = {
  { "*toggle_edit_item_location", "*toggle_edit_inventory" },
  { "*toggle_edit_item_location", "*toggle_edit_corpse_inventory" },
  { "*toggle_edit_item_location", "*toggle_edit_hireling_inventory" },
  { "*toggle_edit_quests_complete", "*toggle_edit_quests_intermediate" },
  { "*toggle_edit_hireling_experience", "*toggle_edit_hireling_level" },
  { "*toggle_edit_acts",	"*toggle_link_auto_act" },
  { "*toggle_edit_inventory",	"*toggle_link_quest_inventory" },
  { "*toggle_link_skills_skills", "*toggle_link_auto_skill" },
  { "*toggle_link_act_entry",	"*toggle_link_auto_act" },
  { "*toggle_link_act_quest",	"*toggle_link_auto_quest" },
  { "*toggle_link_quest_quest",	"*toggle_link_auto_quest" },
  { "*toggle_edit_quantity",	"*toggle_link_quantity_max" },
  { "*toggle_edit_durability",	"*toggle_link_durability_ethereal" },
  { "*toggle_edit_durability",	"*toggle_link_durability_max" },
  { "*toggle_edit_base_durability", "*toggle_link_defense_max" },
  { "*toggle_edit_defense",	"*toggle_link_defense_max" },
  { "*toggle_edit_quality",	"*toggle_link_quality_magic" },
  { "*toggle_edit_magic_properties", "*toggle_link_properties_range" },
  { "*toggle_edit_magic_properties", "*toggle_edit_magic_property_list" },
};


/* Conditions for editability */
#define IF_WRITABLE	0	/* Only test the read-only attribute	*/
#define IF_OPTION_TRUE	1	/* Test whether *predicate is true	*/
#define IF_OPTION_FALSE	2	/* Test whether *predicate is false	*/
#define IF_PREDICATE	3	/* Call the predicate function		*/

/* Additional values for non-trivial widgets */
#define IS_PREFIX	5	/* Subtree for the following widgets
				 * (if predicate function is given,
				 * determines whether to follow tree)	*/
#define IS_ARRAY	6	/* Linear array of widgets
				 * (the widget_name is a sprintf-format
				 * string with one or two repeated %d's) */
#define IS_MATRIX	7	/* 2-dimensional array of widgets
				 * (the widget_name is a sprintf-format
				 * string with two %d's) */

struct condition_list_t {
  const char	*widget_name;
  int		condition;
  void		*predicate;	/* int* or a predicate_t */
  action_function_t action;
};

struct condition_list_t char_widget_conditions[] = {
  { "*form_stats",		IS_PREFIX },
  { "*field_name",			IF_OPTION_TRUE,
    &options.character.edit.name,	TextFieldSetEditable },
  { "*field_level",			IF_OPTION_TRUE,
    &options.character.edit.level,	TextFieldSetEditable },
  { "*field_experience",		IF_OPTION_TRUE,
    &options.character.edit.experience,	TextFieldSetEditable },
  { "*scale_experience",		IF_OPTION_TRUE,
    &options.character.edit.experience, ScaleSetEditable },
  { "*field_strength",			IF_OPTION_TRUE,
    &options.character.edit.stats,	TextFieldSetEditable },
  { "*button_add_strength",		IF_PREDICATE,
    (void *) char_stat_points_available, WidgetSetManaged },
  { "*field_dexterity",			IF_OPTION_TRUE,
    &options.character.edit.stats,	TextFieldSetEditable },
  { "*button_add_dexterity",		IF_PREDICATE,
    (void *) char_stat_points_available, WidgetSetManaged },
  { "*field_vitality",			IF_OPTION_TRUE,
    &options.character.edit.stats,	TextFieldSetEditable },
  { "*button_add_vitality",		IF_PREDICATE,
    (void *) char_stat_points_available, WidgetSetManaged },
  { "*field_energy",			IF_OPTION_TRUE,
    &options.character.edit.stats,	TextFieldSetEditable },
  { "*button_add_energy",		IF_PREDICATE,
    (void *) char_stat_points_available, WidgetSetManaged },
  { "*field_life_base",			IF_OPTION_TRUE,
    &options.character.edit.stats2,	TextFieldSetEditable },
  { "*field_life_current",		IF_OPTION_TRUE,
    &options.character.edit.stats,	TextFieldSetEditable },
  { "*field_mana_base",			IF_OPTION_TRUE,
    &options.character.edit.stats2,	TextFieldSetEditable },
  { "*field_mana_current",		IF_OPTION_TRUE,
    &options.character.edit.stats,	TextFieldSetEditable },
  { "*field_stamina_base",		IF_OPTION_TRUE,
    &options.character.edit.stats2,	TextFieldSetEditable },
  { "*field_stamina_current",		IF_OPTION_TRUE,
    &options.character.edit.stats,	TextFieldSetEditable },
  { "*field_stat_points",		IF_OPTION_TRUE,
    &options.character.edit.stat_points, TextFieldSetEditable },
  { "*form_skills",		IS_PREFIX },
  { "*field_skill_points",		IF_OPTION_TRUE,
    &options.character.edit.skill_points, TextFieldSetEditable },
  { "*field_skilla",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skillb",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skillc",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skilld",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skille",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skillf",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skillg",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skillh",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skilli",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*field_skillj",			IF_PREDICATE,
    (void *) char_skill_editable,	SpinBoxSetArrows },
  { "*button_skilla",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skillb",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skillc",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skilld",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skille",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skillf",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skillg",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skillh",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skilli",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*button_skillj",			IF_PREDICATE,
    (void *) char_skill_available,	ButtonSetSensitive },
  { "*form_inventory",		IS_PREFIX },
  { "*field_gold_stash",		IF_OPTION_TRUE,
    &options.character.edit.gold,	TextFieldSetEditable },
  { "*field_gold_inv",			IF_OPTION_TRUE,
    &options.character.edit.gold,	TextFieldSetEditable },
  { "*box_stash_%d%d",			IS_MATRIX,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_cube_%d%d",			IS_MATRIX,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_head",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_body",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_waist",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_rhand",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_arhand",		IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_lhand",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_alhand",		IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_hands",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_feet",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_neck",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_rfing",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_equip_lfing",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_belt_%d",			IS_ARRAY,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_inv_%d%d",			IS_MATRIX,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*box_mouse",			IF_PREDICATE,
    (void *) char_inventory_drop,	WidgetSetDropSite },
  { "*form_acts",		IS_PREFIX },
  { "*option_current_act",		IF_OPTION_TRUE,
    &options.character.edit.act_location, ButtonSetSensitive },
  { "*option_actdifficulty",		IF_OPTION_TRUE,
    &options.character.edit.all_difficulties, ButtonSetSensitive },
  { "*toggle_act%d_intro",		IS_ARRAY,
    (void *) char_npcs_editable,	ButtonSetSensitive },
  { "*toggle_act%d_npc%d",		IS_MATRIX,
    (void *) char_npcs_editable,	ButtonSetSensitive },
  /* There's a discontinuity here; there are no NPC's in Act IV. */
  { "*toggle_act5_npc%d",		IS_ARRAY,
    (void *) char_npcs_editable,	ButtonSetSensitive },
  { "*toggle_act%d_exit",		IS_ARRAY,
    (void *) char_act_exit_editable,	ButtonSetSensitive },
  { "*form_waypoints",		IS_PREFIX },
  { "*option_wpdifficulty",		IF_OPTION_TRUE,
    &options.character.edit.all_difficulties,	ButtonSetSensitive },
  { "*toggle_wp%d_%d",			IS_MATRIX,
    (void *) char_waypoint_editable,	ButtonSetSensitive },
  { "*form_quests",		IS_PREFIX },
  { "*option_qstdifficulty",		IF_OPTION_TRUE,
    &options.character.edit.all_difficulties,	ButtonSetSensitive },
  { "*toggle_qst%d_%d",			IS_MATRIX,
    (void *) char_quest_editable,	ButtonSetSensitive },
  { "*frame_edit_quest*combo_qsthex",	IF_PREDICATE,
    (void *) char_quests_editable,	ButtonSetSensitive },
  { "*frame_edit_quest*combo_qsthex*Text",	IF_OPTION_TRUE,
    &options.character.edit.quests_intermediate, TextFieldSetEditable },
  { "*form_hireling",		IS_PREFIX },
  { "*combo_hire_name",			IF_PREDICATE,
    (void *) hireling_name_editable,	ButtonSetSensitive },
  { "*option_hire_class",		IF_PREDICATE,
    (void *) hireling_class_editable,	ButtonSetSensitive },
  { "*option_hire_ability",		IF_PREDICATE,
    (void *) hireling_attribute_editable, ButtonSetSensitive },
  { "*field_hire_experience",		IF_PREDICATE,
    (void *) hireling_experience_editable, TextFieldSetEditable },
  { "*scale_hire_experience",		IF_PREDICATE,
    (void *) hireling_experience_editable, ScaleSetEditable },
  { "*field_hire_level",		IF_PREDICATE,
    (void *) hireling_level_editable,	TextFieldSetEditable },
  { "*box_hire_equip_head",		IF_PREDICATE,
    (void *) hireling_inventory_drop,	WidgetSetDropSite },
  { "*box_hire_equip_body",		IF_PREDICATE,
    (void *) hireling_inventory_drop,	WidgetSetDropSite },
  { "*box_hire_equip_rhand",		IF_PREDICATE,
    (void *) hireling_inventory_drop,	WidgetSetDropSite },
  { "*box_hire_equip_lhand",		IF_PREDICATE,
    (void *) hireling_inventory_drop,	WidgetSetDropSite },
};

struct condition_list_t item_popup_widget_conditions[] = {
  { "*popitem_repair",			IF_PREDICATE,
    (void *) item_repable,		ButtonSetSensitive },
  { "*popitem_edit",			IF_WRITABLE,
    NULL,				ButtonSetSensitive },
};

struct condition_list_t item_widget_conditions[] = {
  { "*menubar_item",		IS_PREFIX },
  { "*menuitem_move",			IF_PREDICATE,
    (void *) item_moveable,		ButtonSetSensitive },
  { "*menuitem_remove",			IF_PREDICATE,
    (void *) item_removeable,		ButtonSetSensitive },
  { "*menuitem_assign",			IF_PREDICATE,
    (void *) item_unclaimed,		ButtonSetSensitive },
  { "*frame_extended_item*form_durable_item", IS_PREFIX },
  { "*toggle_newbie_item",		IF_OPTION_TRUE,
    &options.item.edit.newbie,		ButtonSetSensitive },
  { "*toggle_ethereal_item",		IF_PREDICATE,
    (void *) item_ethereal,		ButtonSetSensitive },
  { "*field_current_durability",	IF_OPTION_TRUE,
    &options.item.edit.durability,	TextFieldSetEditable },
  { "*field_base_durability",		IF_OPTION_TRUE,
    &options.item.edit.base_durability,	TextFieldSetEditable },
  { "*frame_extended_item",	IS_PREFIX },
  { "*form_armor_defense*field_armor_defense", IF_OPTION_TRUE,
    &options.item.edit.defense,		TextFieldSetEditable },
  { "*form_stacked_item*field_item_quantity", IF_OPTION_TRUE,
    &options.item.edit.quantity,	TextFieldSetEditable },
  { "*field_fingerprint",		IF_OPTION_TRUE,
    &options.item.edit.fingerprint,	TextFieldSetEditable },
  { "*field_item_level",		IF_OPTION_TRUE,
    &options.item.edit.level,		TextFieldSetEditable },
  { "*frame_socketed_item",	IS_PREFIX },
  { "*button_add_socket",		IF_PREDICATE,
    (void *) item_can_have_more_sockets, ButtonSetSensitive },
  { "*button_remove_socket",		IF_PREDICATE,
    (void *) item_can_have_less_sockets, ButtonSetSensitive },
  { "*form_socket%d*arrow_socket%d_up", IS_ARRAY,
    (void *) item_gem_can_move_up,	WidgetSetManaged },
  { "*form_socket%d*arrow_socket%d_down", IS_ARRAY,
    (void *) item_gem_can_move_down,	WidgetSetManaged },
  { "*form_socket%d",			IS_ARRAY,
    (void *) item_can_add_gems,		WidgetSetDropSite },
  { "*frame_item_quality*pulldown_quality",	IS_PREFIX },
  { "*optionitem_quality_low",		IF_PREDICATE,
    (void *) item_quality_can_be_low,	ButtonSetSensitive },
  { "*optionitem_quality_normal",	IF_PREDICATE,
    (void *) item_quality_can_be_normal, ButtonSetSensitive },
  { "*optionitem_quality_high",		IF_PREDICATE,
    (void *) item_quality_can_be_high,	ButtonSetSensitive },
  { "*optionitem_quality_magic",	IF_PREDICATE,
    (void *) item_quality_can_be_magic, ButtonSetSensitive },
  { "*optionitem_quality_set",		IF_PREDICATE,
    (void *) item_quality_can_be_set,	ButtonSetSensitive },
  { "*optionitem_quality_rare",		IF_PREDICATE,
    (void *) item_quality_can_be_rare,	ButtonSetSensitive },
  { "*optionitem_quality_unique",	IF_PREDICATE,
    (void *) item_quality_can_be_unique, ButtonSetSensitive },
  { "*frame_item_quality",	IS_PREFIX },
  { "*optionmenu_quality",		IF_PREDICATE,
    (void *) item_quality_changeable,	ButtonSetSensitive },
  { "*toggle_identified",		IF_PREDICATE,
    (void *) item_identification_changeable, ButtonSetSensitive },
  { "*field_item_owner",		IF_PREDICATE,
    (void *) item_personalization_changeable, TextFieldSetEditable },
  { "*field_grade_number",		IF_OPTION_TRUE,
    &options.item.edit.magic_name,	TextFieldSetEditable },
  { "*form_quality_magic*combo_magic_prefix", IF_PREDICATE,
    (void *) install_magic_prefixes,	ButtonSetSensitive },
  { "*form_quality_magic*combo_magic_suffix", IF_PREDICATE,
    (void *) install_magic_suffixes,	ButtonSetSensitive },
  { "*form_quality_set*combo_set_sets", IF_PREDICATE,
    (void *) install_set_names,		ButtonSetSensitive },
  { "*form_quality_rare*combo_rare_first_name", IF_PREDICATE,
    (void *) install_rare_first_names,	ButtonSetSensitive },
  { "*form_quality_rare*combo_rare_last_name", IF_PREDICATE,
    (void *) install_rare_last_names,	ButtonSetSensitive },
  { "*form_quality_rare*combo_rare_hidden%d", IS_ARRAY,
    (void *) install_rare_xfixes,	ButtonSetSensitive },
  { "*form_quality_unique*combo_unique_name", IF_PREDICATE,
    (void *) install_unique_names,	ButtonSetSensitive },
  { "*field_quality_unknown_field",	IF_OPTION_TRUE,
    &options.item.edit.magic_name,	TextFieldSetEditable },
  { "*frame_item_magic",	IS_PREFIX },
  { "*button_property_add",		IF_OPTION_TRUE,
    &options.item.edit.magic_property_list, WidgetSetManaged },
};


/****************************************************************/

/* Local variables: */
static Widget option_dialog = NULL;
static String option_uid_file[] = { "options" };


static Widget
create_options_dialog (void)
{
  Widget	dialog_form;
  MrmHierarchy	hierarchy;
  MrmType	class_code;
  Cardinal	status;
  char		*full_path;
  int		i;

  /* Find the User Interface Definition file */
  full_path = xfindfile (NULL, option_uid_file[0], ".uid", path_to_uid);
  if (full_path == NULL) {
    fprintf (stderr, "%s: Unable to locate %s UID file.\n",
	      progname, option_uid_file[0]);
    /* This is not a fatal error */
    return NULL;
  }
  option_uid_file[0] = full_path;

  /* Open up the User Interface Definition files */
  status = MrmOpenHierarchyPerDisplay
    (XtDisplay (toplevel), XtNumber (option_uid_file),
     option_uid_file, NULL, &hierarchy);
  if (status != MrmSUCCESS) {
    fprintf (stderr, "%s: Unable to open UID files for the options dialog.\n",
	     progname);
    return NULL;
  }

  option_dialog = XtVaAppCreateShell ("d2sedit", "d2sEdit",
				     topLevelShellWidgetClass,
				     XtDisplay (toplevel), NULL);
  status = MrmFetchWidget (hierarchy, "form_options", option_dialog,
			   &dialog_form, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create interface form_options"
	       " from UID file\n", progname);
      XtDestroyWidget (option_dialog);
      option_dialog = NULL;
      return NULL;
    }

  /* Change the default response for the dialog's close button
     so that it simply hides the window. */
  XtVaSetValues (option_dialog, XmNdeleteResponse, XmUNMAP, NULL);
  /* We should never need this, but just in case... */
  XtAddCallback (option_dialog, XmNdestroyCallback,
		 destroy_options_dialog, NULL);

  /* Initialize the toggle buttons to the current option values */
  for (i = 0; i < (int) XtNumber (toggle_map); i++)
    XmToggleButtonSetState
      (XxNameToWidget (dialog_form, toggle_map[i].toggle_button),
       *toggle_map[i].poption ? True : False, False);

  /* Add callbacks */
  for (i = 0; i < (int) XtNumber (toggle_sync); i++)
    {
      Widget wset = XxNameToWidget (dialog_form,
				    toggle_sync[i].toggle_set);
      Widget wunset = XxNameToWidget (dialog_form,
				      toggle_sync[i].toggle_unset);
      XtAddCallback (wset, XmNvalueChangedCallback,
		     ui_force_toggle_when_unset, wunset);
      XtAddCallback (wunset, XmNvalueChangedCallback,
		     ui_force_toggle_when_set, wset);
    }
  XtAddCallback (XxNameToWidget (dialog_form, "*button_options_ok"),
		 XmNactivateCallback, ui_options_ok, (XtPointer) 1);
  XtAddCallback (XxNameToWidget (dialog_form, "*button_options_apply"),
		 XmNactivateCallback, ui_options_ok, (XtPointer) 0);
  XtAddCallback (XxNameToWidget (dialog_form, "*button_options_cancel"),
		 XmNactivateCallback, close_options_dialog, NULL);

  XtManageChild (dialog_form);
  XtRealizeWidget (option_dialog);
  return option_dialog;
}

static void
close_options_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
  XUnmapWindow (XtDisplay (option_dialog), XtWindow (option_dialog));
}

static void
destroy_options_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
  /* Dialog box is being destroyed.  Remember that,
     so that we will re-create it the next time it is asked for. */
  option_dialog = NULL;
}

/* Force a toggle button to match the state of another */
static void
ui_force_toggle_when_set (Widget w, XtPointer client_data,
			  XtPointer call_data)
{
  Widget	dest = (Widget) client_data;
  XmToggleButtonCallbackStruct *source
    = (XmToggleButtonCallbackStruct *) call_data;

  if (source->set)
    XmToggleButtonSetState (dest, True, True);
}

static void
ui_force_toggle_when_unset (Widget w, XtPointer client_data,
			    XtPointer call_data)
{
  Widget	dest = (Widget) client_data;
  XmToggleButtonCallbackStruct *source
    = (XmToggleButtonCallbackStruct *) call_data;

  if ( ! source->set)
    XmToggleButtonSetState (dest, False, True);
}

void
ui_edit_options (Widget w, XtPointer client_data, XtPointer call_data)
{
  if (option_dialog == NULL)
    {
      if (create_options_dialog () == NULL)
      return;
    }
  else
    {
      /* Raise the existing dialog */
      XMapRaised (XtDisplay (option_dialog), XtWindow (option_dialog));
    }

  /* Turn the 'page' to the related options */
  XtVaSetValues (XxNameToWidget (option_dialog, "*tabs_options"),
		 XmNcurrentPageNumber, *((int *) client_data),
		 NULL);
}

static void
ui_options_ok (Widget w, XtPointer client_data, XtPointer call_data)
{
  int		i;

  /* Copy the toggle button states to the editor's option values */
  for (i = 0; i < (int) XtNumber (toggle_map); i++)
    *toggle_map[i].poption = XmToggleButtonGetState
      (XxNameToWidget (option_dialog, toggle_map[i].toggle_button));

  /* Update all character and item windows */
  update_all_character_windows ();
  update_unclaimed_item_windows ();

  if ((int) client_data)
    /* Hide the dialog */
    XUnmapWindow (XtDisplay (option_dialog), XtWindow (option_dialog));
}


/* Go through the list of character windows and
   update the editability on all of them. */
static void
update_all_character_windows (void)
{
  int		i;
  d2sData *	gamePtr;

  for (i = 0; i < doc_shell_count; i++)
    {
      XtVaGetValues (XxNameToWidget (doc_shell_list[i], "*form_char"),
		     XmNuserData, &gamePtr,
		     NULL);
      if (gamePtr != NULL)
	update_character_window_sensitive (gamePtr);
    }
}

/* Go through the list of item editor windows and update the
   editability of the ones which are unclaimed.  (Items that have
   owners are handled by the previous function. */
static void
update_unclaimed_item_windows (void)
{
  int i;
  d2sItem *	itemPtr;

  for (i = 0; i < item_doc_shell_count; i++)
    {
      XtVaGetValues (XxNameToWidget (item_doc_shell_list[i], "*form_item"),
		     XmNuserData, &itemPtr,
		     NULL);
      if (itemPtr != NULL)
	update_item_editor_sensitive (itemPtr);
    }
}

/* Initialize the editability of all widgets for an unused character
   window.  The d2sData* is NULL, so elements are set insensitive. */
void
init_character_window_insensitive (Widget window)
{
  update_widget_tree (window, "", NULL, True, char_widget_conditions,
		      XtNumber (char_widget_conditions));
}

/* Update the editability of all widgets for a single
   character window.  Also, because this is normally used when
   a character changes read-only state, and item popups aren't
   available on a separate list, go through the character's
   items and update any of their windows. */
void
update_character_window_sensitive (d2sData *gamePtr)
{
  d2sItem *item;

  update_widget_tree ((Widget) gamePtr->GetUI(), "", gamePtr,
		      gamePtr->read_only, char_widget_conditions,
		      XtNumber (char_widget_conditions));
  for (item = gamePtr->GetFirstItem(); item != NULL; item = item->next)
    {
      if (item->GetUI() == NULL)
	continue;
      if (strcmp (XtName ((Widget) item->GetUI()), "form_item_popup") == 0)
	update_item_popup_sensitive (item);
      else
	update_item_editor_sensitive (item);
    }
  for (item = gamePtr->GetFirstCorpseItem(); item != NULL; item = item->next)
    {
      if (item->GetUI() == NULL)
	continue;
      if (strcmp (XtName ((Widget) item->GetUI()), "form_item_popup") == 0)
	update_item_popup_sensitive (item);
      else
	update_item_editor_sensitive (item);
    }
  for (item = gamePtr->GetFirstHirelingItem(); item != NULL; item = item->next)
    {
      if (item->GetUI() == NULL)
	continue;
      if (strcmp (XtName ((Widget) item->GetUI()), "form_item_popup") == 0)
	update_item_popup_sensitive (item);
      else
	update_item_editor_sensitive (item);
    }
}

/* Update the editability of all widgets within a given tree
   for a single character window */
void
update_character_form_sensitive (d2sData *gamePtr, const char *tree_prefix)
{
  update_widget_tree ((Widget) gamePtr->GetUI(), tree_prefix, gamePtr,
		      gamePtr->read_only, char_widget_conditions,
		      XtNumber (char_widget_conditions));
}

/* Update the editability of all widgets
   in a single item popup window */
void
update_item_popup_sensitive (d2sItem *itemPtr)
{
  update_widget_tree ((Widget) itemPtr->GetUI(), "", itemPtr,
		      itemPtr->read_only(), item_popup_widget_conditions,
		      XtNumber (item_popup_widget_conditions));
}

/* Update the editability of all widgets
   in a single item editor window */
void
update_item_editor_sensitive (d2sItem *itemPtr)
{
  update_widget_tree ((Widget) itemPtr->GetUI(), "", itemPtr,
		      itemPtr->read_only(), item_widget_conditions,
		      XtNumber (item_widget_conditions));
}

/* Update the editability of all widgets within a given tree
   for a single item window */
void
update_item_form_sensitive (d2sItem *itemPtr, const char *tree_prefix)
{
  update_widget_tree ((Widget) itemPtr->GetUI(), tree_prefix, itemPtr,
		      itemPtr->read_only(), item_widget_conditions,
		      XtNumber (item_widget_conditions));
}

/* Update the editability of all widgets within a given tree
   for a particular object. */
static void
update_widget_tree (Widget window, const char *tree_prefix,
		    void *objPtr, int read_only,
		    struct condition_list_t *cl, int list_size)
{
  Widget	subform;
  int		i, prefix_len;

  prefix_len = (tree_prefix == NULL) ? 0 : strlen (tree_prefix);
  XmDropSiteStartUpdate (window);
  for (i = 0; i < list_size; i++)
    {
      /* Search for the next prefix matching the given tree. */
      if (cl[i].condition != IS_PREFIX)
	continue;
      if (prefix_len
	  && strncmp (cl[i].widget_name, tree_prefix, prefix_len) != 0)
	continue;

      /* Get the child tree widget */
      if ((cl[i].widget_name != NULL) && (cl[i].widget_name[0]))
	{
	  subform = XtNameToWidget (window, cl[i].widget_name);
	  if (subform == NULL)
	    /* Tree isn't a part of the window
	       (this can happen in the item editor).  Skip it. */
	    continue;
	}
      else
	subform = window;

      /* Update all widgets up to the next prefix */
      for (i++; i < list_size; i++)
	{
	  if (cl[i].condition == IS_PREFIX)
	    {
	      /* Back up and let the outer loop determine
		 whether to process this next prefix */
	      --i;
	      break;
	    }

	  update_widget_editable (subform, objPtr, read_only, &cl[i]);
	}
    }
  XmDropSiteEndUpdate (window);
}

/* Update the editability of a given widget. */
static void
update_widget_editable (Widget parent, void *objPtr, int read_only,
			struct condition_list_t *cl)
{
  Widget	w;
  int		editable;
  char		make_name[64];
  int		i, j;

  switch (cl->condition)
    {
    case IF_WRITABLE:
      editable = !read_only;
    single_widget:
      w = XxNameToWidget (parent, cl->widget_name);
      cl->action (w, editable);
      return;

    case IF_OPTION_TRUE:
      editable = (!read_only && *((int *) cl->predicate));
      goto single_widget;

    case IF_OPTION_FALSE:
      editable = (!read_only && !*((int *) cl->predicate));
      goto single_widget;

    case IF_PREDICATE:
      w = XxNameToWidget (parent, cl->widget_name);
      /* Since some predicates are multi-state (i.e., SpinBox arrows),
	 we must not AND the predicate with the read_only flag. */
      editable = (read_only ? 0 : ((predicate_t) cl->predicate) (objPtr, w));
      cl->action (w, editable);
      return;

    case IS_ARRAY:
      /* Run through a list of widgets and repeat getting the
	 editability and setting the sensitivity for each.
	 Since we don't know the range of the array, we just
	 keep going until we run out of widgets.  Also, we don't
	 know whether the widgets are on zero-base or one-base,
	 so make the 0 index optional. */
      for (i = 0; i < 100; i++)
	{
	  snprintf (make_name, sizeof (make_name), cl->widget_name, i, i);
	  w = XtNameToWidget (parent, make_name);
	  if (w == NULL)
	    {
	      if (i)
		break;
	      else
		continue;
	    }
	  editable = (read_only ? 0 : ((array_predicate_t)
				       cl->predicate) (objPtr, w, i));
	  cl->action (w, editable);
	}
      return;

    case IS_MATRIX:
      /* Same as above, but in 2 dimensions. */
      for (i = 0; i < 100; i++) {
	for (j = 0; j < 100; j++) {
	  snprintf (make_name, sizeof (make_name), cl->widget_name, i, j);
	  w = XtNameToWidget (parent, make_name);
	  if (w == NULL)
	    {
	      if (j)
		break;
	      else
		continue;
	    }
	  editable = (read_only ? 0 : ((matrix_predicate_t)
				       cl->predicate) (objPtr, w, i, j));
	  cl->action (w, editable);
	}
	/* If the inner loop broke at 1, there were no widgets
           on that line.  Break if the outer loop is non-zero. */
	if ((j <= 1) && (i >= 1))
	  break;
      }
      return;
    }
}


/* Set whether a text field is editable */
static void
TextFieldSetEditable (Widget textf, int editable)
{
  Arg	args[1];

  if (XmTextFieldGetEditable (textf) != editable)
    {
      XtVaSetValues (textf,
		     XmNeditable, editable,
		     /* Should this be left out? */
		     /* XmNnavigationType, editable ? XmTAB_GROUP : XmNONE, */
		     XmNtraversalOn, editable,
		     NULL);
      /* For text fields, also update the active state of the drop site */
      XtSetArg (args[0], XmNdropSiteActivity,
		editable ? XmDROP_SITE_ACTIVE : XmDROP_SITE_INACTIVE);
      XmDropSiteUpdate (textf, args, 1);
    }
}

/* Set whether a push button is pressable */
static void
ButtonSetSensitive (Widget w, int sensitive)
{
  if (XtIsSensitive (w) != sensitive)
    XtVaSetValues (w, XmNsensitive, sensitive, NULL);
}

/* Set whether a slider is editable */
static void
ScaleSetEditable (Widget scale, int editable)
{
  Boolean old_editable;

  XtVaGetValues (scale, XmNeditable, &old_editable, NULL);
  if (old_editable != editable)
    XtVaSetValues (scale, XmNeditable, editable, NULL);
}

/* Set the arrow sensitivity on a spin box */
static void
SpinBoxSetArrows (Widget spinbox_textfield, int arrows)
{
  int old_arrows, editable;
  char *text;

  /* Get the current state of the spin arrows */
  XtVaGetValues (spinbox_textfield, XmNarrowSensitivity, &old_arrows, NULL);

  /* Update the arrow sensitivity */
  editable = (arrows != XmARROWS_INSENSITIVE);
  if (old_arrows != arrows)
    {
      XtVaSetValues (spinbox_textfield,
		     XmNarrowSensitivity, arrows,
		     XmNnavigationType, editable ? XmTAB_GROUP :  XmNONE,
		     XmNeditable, editable,
		     XmNtraversalOn, editable,
		     NULL);
      /* We also need to update the traversal on the parent spinner. */
      XtVaSetValues (XtParent (spinbox_textfield),
		     XmNtraversalOn, editable,
		     NULL);
    }

  /* One more thing to make it look pretty:
     If the box is disabled and the value is zero, clear the text field.
     Otherwise make sure the text field is set.
     This must be done *after* setting the position, because
     otherwise the spinner would override it. */
  text = XmTextFieldGetString (spinbox_textfield);
  if (editable) {
    if (!*text)
      XmTextFieldSetString (spinbox_textfield, "0");
  } else {
    if (strcmp (text, "0") == 0)
      XmTextFieldSetString (spinbox_textfield, "");
  }
  XtFree (text);
}

/* Set whether a widget is managed */
static void
WidgetSetManaged (Widget w, int managed)
{
  if (!managed && XtIsManaged (w))
    XtUnmanageChild (w);
  else if (managed && !XtIsManaged (w))
    XtManageChild (w);
}

/* Set whether a widget can be used as a drop site.
   The parameter is used only to set the drop operations;
   whether the drop site is active depends solely on
   whether the button contains an item. */
static void
WidgetSetDropSite (Widget w, int droppable)
{
  Arg	args[1];

  XtSetArg (args[0], XmNdropSiteOperations,
	    (droppable > 0) ? droppable : XmDROP_NOOP);
  XmDropSiteUpdate (w, args, 1);
}

/* Return true if the primary stats can be increased.
   The condition is satisfied if they are editable and either
   not linked to stat points or there are stat points remaining. */
static int
char_stat_points_available (void *objPtr, Widget w)
{
  d2sData *gamePtr = (d2sData *) objPtr;

  return (options.character.edit.stats
	  && (!options.character.link.stats_points
	      || gamePtr->GetStatPointsRemaining()));
}

/* Returns an arrow sensitivity macro depending on whether
   a given skill can be increased, decreased, or both. */
static int
char_skill_editable (void *objPtr, Widget spinbox_textfield)
{
  int skill, level, min, max;
  d2sData *gamePtr = (d2sData *) objPtr;

  /* Get the skill number */
  XtVaGetValues (spinbox_textfield, XmNuserData, &skill, NULL);
  /* Get the skill's current level, minimum, and maximum */
  level = gamePtr->GetSkillLevel (skill);
  min = gamePtr->GetSkillMin (skill);
  max = gamePtr->GetSkillMax (skill);

  /* If the minimum and maximum are the same as the current level,
     both arrows are disabled. */
  if ((min >= level) && (level >= max))
    return XmARROWS_INSENSITIVE;
  /* If the value is at the minimum or maximum level,
     disable the corresponding arrow. */
  if (min >= level)
    return XmARROWS_INCREMENT_SENSITIVE;
  if (level >= max)
    return XmARROWS_DECREMENT_SENSITIVE;
  /* The level can go either way. */
  return XmARROWS_SENSITIVE;
}

/* Return true if a given skill can be increased. */
static int
char_skill_available (void *objPtr, Widget w)
{
  d2sData *gamePtr = (d2sData *) objPtr;
  int skill, level, max;

  /* Get the skill number */
  XtVaGetValues (w, XmNuserData, &skill, NULL);
  /* Get the skill's current level and maximum */
  level = gamePtr->GetSkillLevel (skill);
  max = gamePtr->GetSkillMax (skill);

  return (level < max);
}

/*
 * Return a set of supported drop site operations
 * if the character's inventory can be used as a drop site.
 * The return value is XmDROP_MOVE if items can be moved within the
 * inventory, or XmDROP_COPY + XmDROP_MOVE if items can be added.
 * It is False if moving items is forbidden.
 */
static int
char_inventory_drop (void *objPtr, Widget w)
{
  if (!options.character.edit.item_location)
    return False;
  return (options.character.edit.inventory
	  ? (XmDROP_COPY | XmDROP_MOVE) : XmDROP_MOVE);
}

/*
 * Return true if an NPC introduction can be changed.
 * The condition is true if npc's are editable, AND
 * (the difficulty displayed is the current difficulty,
 *  OR all difficulties may be edited), AND
 * (the act that the NPC is in has been visited,
 *  OR all acts may be edited, OR acts are completed automatically).
 */
static int
char_npcs_editable (void *objPtr, Widget w, int act, int npc)
{
  d2sData *gamePtr = (d2sData *) objPtr;
  int difficulty;

  if (!options.character.edit.npcs)
    return False;
  /* What difficulty are we currently in? */
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget ((Widget) gamePtr->GetUI(),
		     "*form_acts*option_actdifficulty"));
  if (!options.character.edit.all_difficulties
      && (difficulty != gamePtr->GetCurrentDifficulty()))
    return False;
  if (options.character.link.act_entry && !options.character.link.auto_act
      /* Remember, the widget numbers are 1-based,
	 but the function argument is 0-based. */
      && (act > 1) && !gamePtr->GetActCompletion (difficulty, act - 2))
    return False;
  return True;
}

/*
 * Return true if an act can be exited.
 * The condition is true if act exits are editable, AND
 * (the difficulty displayed is the current difficulty,
 *  OR all difficulties may be edited)
 */
static int
char_act_exit_editable (void *objPtr, Widget w, int act)
{
  d2sData *gamePtr = (d2sData *) objPtr;
  int difficulty;

  if (!options.character.edit.acts)
    return False;
  /* What difficulty are we currently in? */
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget ((Widget) gamePtr->GetUI(),
		     "*form_acts*option_actdifficulty"));
  if (!options.character.edit.all_difficulties
      && (difficulty != gamePtr->GetCurrentDifficulty()))
    return False;
  return True;
}

/*
 * Return true if a waypoint can be activated (or deactivated).
 * The condition is true if waypoints are editable, AND
 * (the difficulty displayed is the current difficulty,
 *  OR all difficulties may be edited), AND
 * (the act that the waypoint is in has been visited,
 *  OR all acts may be edited, OR acts are completed automatically), AND
 * (this is not the town waypoint,
 *  OR town waypoints may be changed,
 *  OR acts are completed automatically).
 */
static int
char_waypoint_editable (void *objPtr, Widget w, int act, int waypoint)
{
  d2sData *gamePtr = (d2sData *) objPtr;
  int difficulty;

  if (!options.character.edit.waypoints)
    return False;
  /* What difficulty are we currently in? */
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget ((Widget) gamePtr->GetUI(),
		     "*form_waypoints*option_wpdifficulty"));
  if (!options.character.edit.all_difficulties
      && (difficulty != gamePtr->GetCurrentDifficulty()))
    return False;
  if (options.character.link.act_entry && !options.character.link.auto_act
      && (act > 1) && !gamePtr->GetActCompletion (difficulty, act - 2))
    return False;
  if ((waypoint == 1) && options.character.link.act_waypoint
      && ((act == 1) || !options.character.link.auto_act))
    return False;
  return True;
}

/*
 * Return true if a quest state can be changed.
 * The condition is true if quests are editable, AND
 * (the difficulty displayed is the current difficulty,
 *  OR all difficulties may be edited), AND
 * (the act that the quest is in has been visited,
 *  OR all acts may be edited, OR acts are completed automatically).
 */
static int
char_quest_editable (void *objPtr, Widget w, int act, int quest)
{
  d2sData *gamePtr = (d2sData *) objPtr;
  int difficulty;

  if (!options.character.edit.quests_complete
      && !options.character.edit.quests_intermediate)
    return False;
  /* What difficulty are we currently in? */
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget ((Widget) gamePtr->GetUI(),
		     "*form_quests*option_qstdifficulty"));
  if (!options.character.edit.all_difficulties
      && (difficulty != gamePtr->GetCurrentDifficulty()))
    return False;
  if (options.character.link.act_entry && !options.character.link.auto_act
      && (act > 1) && !gamePtr->GetActCompletion (difficulty, act - 2))
    return False;
  return True;
}

/*
 * Same, but for the quest edit box.  Since there is just one box
 * for all quests, we ignore the condition that depends on which
 * quest is being edited.
 */
static int
char_quests_editable (void *objPtr, Widget w)
{
  d2sData *gamePtr = (d2sData *) objPtr;
  int difficulty;

  if (!options.character.edit.quests_complete
      && !options.character.edit.quests_intermediate)
    return False;
  /* What difficulty are we currently in? */
  difficulty = XmOptionMenuGetSelection
    (XxNameToWidget ((Widget) gamePtr->GetUI(),
		     "*form_quests*option_qstdifficulty"));
  if (!options.character.edit.all_difficulties
      && (difficulty != gamePtr->GetCurrentDifficulty()))
    return False;
  return True;
}

/* Return true if the character has a hireling
   and the hireling's name can be changed. */
static int
hireling_name_editable (void *objPtr, Widget w)
{
  d2sData *gamePtr = (d2sData *) objPtr;

  return (options.character.edit.hireling_name
	  && gamePtr->has_hireling()
	  && (gamePtr->is_expansion() || !gamePtr->hireling_is_dead()));
}

/* Return true if hirelings can be added, deleted, or replaced. */
static int
hireling_class_editable (void *objPtr, Widget w)
{
  d2sData *gamePtr = (d2sData *) objPtr;

  return (options.character.edit.hireling_add
	  && gamePtr->is_expansion());
}

/* Return true if the character has a hireling
   and the hireling's attribute can be changed. */
static int
hireling_attribute_editable (void *objPtr, Widget w)
{
  d2sData *gamePtr = (d2sData *) objPtr;

  return (options.character.edit.hireling_attribute
	  && gamePtr->has_hireling()
	  && (gamePtr->is_expansion() || !gamePtr->hireling_is_dead()));
}

/* Return true if the character has a hireling
   and the hireling's experience can be changed. */
static int
hireling_experience_editable (void *objPtr, Widget w)
{
  d2sData *gamePtr = (d2sData *) objPtr;

  return (options.character.edit.hireling_experience
	  && gamePtr->has_hireling()
	  && (gamePtr->is_expansion() || !gamePtr->hireling_is_dead()));
}

/* Return true if the character has a hireling
   and the hireling's level can be changed. */
static int
hireling_level_editable (void *objPtr, Widget w)
{
  d2sData *gamePtr = (d2sData *) objPtr;

  return (options.character.edit.hireling_level
	  && gamePtr->has_hireling()
	  && (gamePtr->is_expansion() || !gamePtr->hireling_is_dead()));
}

/*
 * Return a set of supported drop site operations
 * if the hireling's inventory can be used as a drop site.
 * The return value is XmDROP_MOVE if items can be moved within the
 * inventory, or XmDROP_COPY + XmDROP_MOVE if items can be added.
 * It is False if the widget already contains an item,
 * but -1 if moving items is forbidden.
 */
static int
hireling_inventory_drop (void *objPtr, Widget w)
{
  d2sItem *itemPtr;

  XtVaGetValues (w, XmNuserData, &itemPtr, NULL);
  if (itemPtr != NULL)
    return False;
  if (!options.character.edit.item_location)
    return -1;
  return (options.character.edit.hireling_inventory
	  ? (XmDROP_COPY | XmDROP_MOVE) : XmDROP_MOVE);
}

/* Return true if a stack item can be replenished
   or a durable item can be repaired. */
static int
item_repable (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sStackItem *sitem;
  d2sDurableItem *ditem;

  switch (itemPtr->Type())
    {
    case STACK_ITEM:
    case STACKED_WEAPON_ITEM:
      sitem = (d2sStackItem *) *itemPtr;
      return (options.item.edit.quantity
	      && (sitem->Quantity() < sitem->MaxQuantity()));

    case ARMOR_ITEM:
    case WEAPON_ITEM:
      ditem = (d2sDurableItem *) *itemPtr;
      return (options.item.edit.durability
	      && (ditem->Durability() < ditem->MaxDurability()));
    case UNKNOWN_ITEM:
      /* All other item types are listed here simply to alleviate
	 compiler warnings about missing enumeration values. */
    case SIMPLE_ITEM:
    case GEM_ITEM:
    case RUNE_ITEM:
    case POTION_ITEM:
    case UNKNOWN_EXTENDED_ITEM:
    case EXTENDED_ITEM:
    case CHARM_ITEM:
    case JEWEL_ITEM:
      break;
    }
  return False;
}

/* Return true if an item can be moved from its current location */
static int
item_moveable (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  return (options.character.edit.item_location
	  && (itemPtr->Owner() != NULL)
	  && ((itemPtr->Location() != ITEM_AREA_CORPSE)
	      || options.character.edit.corpse_inventory)
	  && ((itemPtr->Location() != ITEM_AREA_HIRELING)
	      || options.character.edit.hireling_inventory));
}

/* Return true if an item can be removed from its current owner */
static int
item_removeable (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  return (options.character.edit.inventory
	  && (itemPtr->Owner() != NULL)
	  && ((itemPtr->Location() != ITEM_AREA_CORPSE)
	      || options.character.edit.corpse_inventory)
	  && ((itemPtr->Location() != ITEM_AREA_HIRELING)
	      || options.character.edit.hireling_inventory));
}

/* Return true if an item does not have an owner */
static int
item_unclaimed (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  return (itemPtr->Owner() == NULL);
}

/* Return true if an item's ethereal property can be modified */
static int
item_ethereal (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  return (options.item.edit.ethereal
	  && (options.item.link.item_expansion
	      || (itemPtr->Owner() == NULL)
	      || (itemPtr->Owner()->is_expansion())));
}

/*
 * Return true if sockets can be added to an item.
 * The condition is true if the socket count is editable, AND
 * the current number of sockets is below the maximum.
 */
static int
item_can_have_more_sockets (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sDurableItem *ditem;

  if (!options.item.edit.socket_count)
    return False;
  if ((itemPtr->Type() != ARMOR_ITEM) && (itemPtr->Type() != WEAPON_ITEM))
    return False;
  ditem = (d2sDurableItem *) *itemPtr;
  return (ditem->ModNumberOfSockets() < ditem->MaximumNumberOfSockets());
}

/*
 * Return true if sockets can be removed from an item.
 * The condition is true if the socket count is editable, AND
 * (there is at least one empty socket,
 *  OR socketed gems may be removed).
 */
static int
item_can_have_less_sockets (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sDurableItem *ditem;

  if (!options.item.edit.socket_count)
    return False;
  if ((itemPtr->Type() != ARMOR_ITEM) && (itemPtr->Type() != WEAPON_ITEM))
    return False;
  ditem = (d2sDurableItem *) *itemPtr;
  return ((ditem->NumberOfSockets() > 0)
	  && ((options.item.edit.gem && options.item.edit.socketed_gems)
	      || (ditem->ModNumberOfSockets() > ditem->NumberOfGems())));
}

/*
 * Return true if a socketed gem can be moved up.
 * The condition is true if socketed gems can be moved, AND
 * there is a gem at the designated spot, AND
 * this is not the first gem.
 */
static int
item_gem_can_move_up (void *objPtr, Widget arrow_button, int index)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sDurableItem *ditem;

  if (!options.item.edit.gem || !options.item.edit.socketed_gems
      || (index <= 1))
    return False;
  if ((itemPtr->Type() != ARMOR_ITEM) && (itemPtr->Type() != WEAPON_ITEM))
    return False;
  ditem = (d2sDurableItem *) *itemPtr;
  return (ditem->Gem(index - 1) != NULL);
}

/*
 * Return true if a socketed gem can be moved down.
 * The condition is true if socketed gems can be moved, AND
 * there is a gem at the designated spot, AND
 * this is not the last gem.
 */
static int
item_gem_can_move_down (void *objPtr, Widget arrow_button, int index)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sDurableItem *ditem;

  if (!options.item.edit.gem || !options.item.edit.socketed_gems)
    return False;
  if ((itemPtr->Type() != ARMOR_ITEM) && (itemPtr->Type() != WEAPON_ITEM))
    return False;
  ditem = (d2sDurableItem *) *itemPtr;
  /* +1 to look for a gem in the next socket;
     -1 to transform a 1-base number into a 0-base. */
  return (ditem->Gem(index + 1 - 1) != NULL);
}

/*
 * Return drop operations if gems can be dropped into a socket.
 * The return value is XmDROP_COPY + XmDROP_MOVE
 * on the first empty socket if gems can be added,
 * on all filled sockets if gems can be inserted,
 * XmDROP_MOVE on all sockets if gems can be moved and all sockets are full,
 * and False otherwise.
 */
static int
item_can_add_gems (void *objPtr, Widget w, int index)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sDurableItem *ditem;
  if (!options.item.edit.socketed_gems)
    return False;
  if ((itemPtr->Type() != ARMOR_ITEM) && (itemPtr->Type() != WEAPON_ITEM))
    return False;
  ditem = (d2sDurableItem *) *itemPtr;
  if (ditem->NumberOfGems() > ditem->ModNumberOfSockets())
    return False;
  if (index > ditem->NumberOfSockets())
    return False;
  if ((ditem->NumberOfGems() >= ditem->ModNumberOfSockets())
      && options.item.edit.gem)
    return XmDROP_MOVE;
  if (!options.item.edit.gem && (index <= ditem->NumberOfGems()))
    return False;
  return (XmDROP_COPY + XmDROP_MOVE);
}

/*
 * Return true if an item can be identified or hidden.
 * The condition is true if items can be identified, AND
 * the item has a magical (or higher) quality, AND
 * (the item has not been identified yet,
 *  OR game progression may be reversed).
 */
static int
item_identification_changeable (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sExtendedItem *eitem;

  if (!options.item.edit.identified)
    return False;
  if (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM)
    return False;
  eitem = (d2sExtendedItem *) *itemPtr;
  if (eitem->Quality()->QualityClass() < MAGIC_QUALITY)
    return False;
  if (options.character.edit.backward)
    return True;
  return (!eitem->is_identified());
}

/*
 * Return true if an item can be personalized.
 * The condition is true if items can be personalized, AND
 * the item is nameable, AND
 * (the item has no owner, OR
 *  the item's owner is an Expansion character, OR
 *  expansion mods are allowed on standard items), AND
 * (the item has not been personalized yet,
 *  OR game progression may be reversed).
 */
static int
item_personalization_changeable (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sExtendedItem *eitem;

  if (!options.item.edit.personalized)
    return False;
  if (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM)
    return False;
  if (!GetEntryIntegerField (itemPtr->ItemTableEntry(), "nameable"))
    return False;
  if (!options.item.link.item_expansion
      && (itemPtr->Owner() != NULL) && !itemPtr->Owner()->is_expansion())
    return False;
  if (options.character.edit.backward)
    return True;
  eitem = (d2sExtendedItem *) *itemPtr;
  return (!eitem->is_personalized());
}

/*
 * Return true if an item's quality category can be changed.
 * The condition is true if item quality can be changed, AND
 * the item is NOT a quest item, AND
 * the item is NOT required to be normal.
 */
static int
item_quality_changeable (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  if (!options.item.edit.quality)
    return False;
  if (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM)
    return False;
  if (options.character.link.freeform)
    return True;
  if (itemPtr->is_quest_item())
    return False;
  return (!GetEntryIntegerField (itemPtr->TypeTableEntry(), "Normal"));
}

/* Unlike most other sensitivity options, the following seven
   do not depend on user settings.  Instead, they depend only
   on the item type. */
/* Return true if an item can be of low quality. */
static int
item_quality_can_be_low (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  return (!itemPtr->is_quest_item()
	  && !GetEntryIntegerField (itemPtr->TypeTableEntry(), "Normal")
	  && !GetEntryIntegerField (itemPtr->TypeTableEntry(), "Magic"));
}

/* Return true if an item can be of normal quality. */
static int
item_quality_can_be_normal (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;
  d2sExtendedItem *eitem;

  /* Special care must be taken for quest items.  Quest items
     are either normal or unique, and the only way to tell
     the difference is by which quality they currently have. */
  if (itemPtr->is_quest_item())
    {
      if (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM)
	return True;
      eitem = (d2sExtendedItem *) *itemPtr;
      return (eitem->Quality()->QualityClass() == NORMAL_QUALITY);
    }
  return (!GetEntryIntegerField (itemPtr->TypeTableEntry(), "Magic"));
}

/* Return true if an item can be of high quality. */
static int
item_quality_can_be_high (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  return (!itemPtr->is_quest_item()
	  && !GetEntryIntegerField (itemPtr->TypeTableEntry(), "Normal")
	  && !GetEntryIntegerField (itemPtr->TypeTableEntry(), "Magic"));
}

/* Return true if an item can have a magical quality. */
static int
item_quality_can_be_magic (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  return (!itemPtr->is_quest_item()
	  && !GetEntryIntegerField (itemPtr->TypeTableEntry(), "Normal"));
}

/* Return true if an item can be part of a set. */
static int
item_quality_can_be_set (void *objPtr, Widget w)
{
  d2sItem *	itemPtr = (d2sItem *) objPtr;
  d2sExtendedItem *eitem;
  StringList	names;
  int		expansion, level;

  if (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM)
    return False;
  eitem = (d2sExtendedItem *) *itemPtr;
  if (eitem->Quality()->QualityClass() == PART_OF_A_SET)
    return True;

  /* Okay, search required. */
  expansion = (options.item.link.item_expansion
	       || (itemPtr->Owner() == NULL)
	       || (itemPtr->Owner()->is_expansion()));
  level = options.character.link.freeform ? 0 : eitem->Level();
  names = GetSetsContainingItem (itemPtr->Code(), expansion, level);
  if (names != NULL)
    {
      /* We don't need the list for anything;
	 just wanted to know if there was one. */
      free (names);
      return True;
    }
  /* None of the set items match this item's code */
  return False;
}

/* Return true if an item can have a rare quality. */
static int
item_quality_can_be_rare (void *objPtr, Widget w)
{
  d2sItem *itemPtr = (d2sItem *) objPtr;

  return (!itemPtr->is_quest_item()
	  && GetEntryIntegerField (itemPtr->TypeTableEntry(), "Rare"));
}

/* Return true if an item can be a unique item. */
static int
item_quality_can_be_unique (void *objPtr, Widget w)
{
  d2sItem *	itemPtr = (d2sItem *) objPtr;
  d2sExtendedItem *eitem;
  StringList	names;
  int		expansion, level;

  if (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM)
    return False;
  eitem = (d2sExtendedItem *) *itemPtr;
  if (eitem->Quality()->QualityClass() == UNIQUE_QUALITY)
    return True;

  /* Okay, search required. */
  expansion = (options.item.link.item_expansion
	       || (itemPtr->Owner() == NULL)
	       || (itemPtr->Owner()->is_expansion()));
  level = options.character.link.freeform ? 0 : eitem->Level();
  names = GetUniqueItemsMatching (itemPtr->Code(), expansion, level);
  if (names != NULL)
    {
      /* We don't need the list for anything;
	 just wanted to know if there was one. */
      free (names);
      return True;
    }
  /* None of the valid unique items match this item's code */
  return False;
}

/* These functions take advantage of the option changing engine
   to install lists of names in ComboBox widgets in addition to
   returning whether the lists can be accessed.  To avoid
   unnecessary changes to the lists, we have to store a little
   extra information about how each list is constructed.  This
   information is "hidden" at the end of the StringList. */
struct hidden_in_list {
  const char *	type_code;	/* Item that list was created for, or NULL */
  Boolean	expansion;	/* Whether the list includes expansion names */
  Boolean	rare;		/* Whether '' is restricted to rare names */
  int		level;		/* Item level restriction */
};

static int
count_duplicates (_StringListEntry *partial_list, int search_count,
		  _StringListEntry *search_string)
{
  int	i, found = 0;

  for (i = 0; i < search_count; i++)
    if (strcmp (search_string->label, partial_list[i].label) == 0)
      found++;
  return found;
}

/* Associate a StringList of name/value pairs with a drop-down list.
   The names in the list are added as items to the drop-down. */
void
install_names_in_dropdown_list (Widget combo_box, StringList names)
{
  StringList	old_names;
  char		*replace_string;
  XmString	xmstr;
  int		i, b, n;
  int		value = -1, position = 0;

  /* Clear whatever is currently in the box */
  XtVaGetValues (combo_box, XmNuserData, &old_names, NULL);
  if (old_names != NULL)
    {
      /* Remember the currently selected item, so we can
	 select it again in the new list (if it's there) */
      XtVaGetValues (combo_box, XmNselectedPosition, &i, NULL);
      if (i && (i <= old_names->count))
	value = old_names->string[i - 1].value;
      free (old_names);
    }
  XmListDeleteAllItems (XxNameToWidget (combo_box, "*List"));
  XmComboBoxUpdate (combo_box);
  /* Add names to the list, one at a time. */
  n = (names == NULL) ? 0 : names->count;
  for (i = 0; i < n; i++)
    {
      /* If the name is not unique, we need to make it unique.
	 Otherwise the combo box will screw up the user's selection
	 by always selecting the first instance of a name. */
      b = count_duplicates (&names->string[0], i, &names->string[i]);
      if (b)
	b++;
      else {
	b = count_duplicates (&names->string[i + 1], n - i - 1,
			      &names->string[i]);
	if (b)
	  b = 1;
      }
      if (b) {
	replace_string = XtMalloc (strlen (names->string[i].label) + 16);
	sprintf (replace_string, "%s (%d)", names->string[i].label, b);
	xmstr = XmStringCreateLocalized (replace_string);
	XtFree (replace_string);
      } else {
	xmstr = XmStringCreateLocalized ((char *) names->string[i].label);
      }
      XmComboBoxAddItem (combo_box, xmstr, i + 1, False);
      XmStringFree (xmstr);
      /* Check for a match of the previously selected item */
      if (names->string[i].value == value)
	position = i + 1;
    }
  /* Save the list of names */
  XtVaSetValues (combo_box,
		 XmNuserData, names,
		 /* Limit the visible item count to 10 */
		 XmNvisibleItemCount, (n < 10) ? (n ? n : 1) : 10,
		 /* Set the visible item */
		 XmNselectedPosition, position,
		 NULL);

  /* Attempt to force the widget to constrain itself properly */
  /* TO-DO: re-setting the right offset didn't work,
     and unmanaging/re-managing the ComboBox didn't work.
     The problem is with the Text widget (and/or arrow button)
     *inside* the ComboBox, not the ComboBox itself. */
}

static void
install_magic_xfixes (Widget combo_box, const d2sItem *itemPtr,
		      Boolean rare, StringList (*GetMagicXfixesFor)
		      (const char *, int, int, int, int, int))
{
  StringList	names;
  struct hidden_in_list *hide;
  const char *	code;
  Boolean	expansion;
  int		level;

  /* Figure out what kind of list we want installed */
  code = (options.character.link.freeform ? NULL
	  : GetEntryStringField (itemPtr->TypeTableEntry(), "code"));
  expansion = (options.item.link.item_expansion
	       || (itemPtr->Owner() == NULL)
	       || (itemPtr->Owner()->is_expansion()));
  if (options.character.link.freeform)
    rare = False;
  level = ((options.character.link.freeform
	    || (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM))
	   ? 0 : ((d2sExtendedItem *) *itemPtr)->Level());

  /* Get the currently installed list of names */
  XtVaGetValues (combo_box, XmNuserData, &names, NULL);
  /* Does this match the list we want? */
  if (names != NULL)
    {
      hide = (struct hidden_in_list *) &names->string[names->count];
      if ((hide->type_code == code) && (hide->expansion == expansion)
	  && (hide->rare == rare) && (hide->level == level))
	/* It's a match; leave the list alone and return. */
	return;
    }

  /* Generate a new list of magic prefixes */
  names = (*GetMagicXfixesFor) (code, expansion, rare, level, 0, 0);
  /* Append our hidden fields */
  names = (StringList) xrealloc (names, sizeof (_StringList)
				 + names->count * sizeof (_StringListEntry)
				 + sizeof (struct hidden_in_list));
  hide = (struct hidden_in_list *) &names->string[names->count];
  hide->type_code = code;
  hide->expansion = expansion;
  hide->rare = rare;
  hide->level = level;
  /* Install the names */
  install_names_in_dropdown_list (combo_box, names);
}

static int
install_magic_prefixes (void *objPtr, Widget combo_box)
{
  install_magic_xfixes (combo_box, (d2sItem *) objPtr,
			False, GetMagicPrefixesFor);

  /* Return whether the user can change the magic prefix */
  return options.item.edit.magic_name;
}

static int
install_magic_suffixes (void *objPtr, Widget combo_box)
{
  install_magic_xfixes (combo_box, (d2sItem *) objPtr,
			False, GetMagicSuffixesFor);

  /* Return whether the user can change the magic suffix */
  return options.item.edit.magic_name;
}

static int
install_set_names (void *objPtr, Widget combo_box)
{
  d2sItem *	itemPtr = (d2sItem *) objPtr;
  StringList	names;
  struct hidden_in_list *hide;
  int		expansion, level;

  /* Figure out what kind of list we want installed */
  expansion = (options.item.link.item_expansion
	       || (itemPtr->Owner() == NULL)
	       || (itemPtr->Owner()->is_expansion()));
  level = ((options.character.link.freeform
	    || (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM))
	   ? 0 : ((d2sExtendedItem *) *itemPtr)->Level());

  /* Get the currently installed list of names */
  XtVaGetValues (combo_box, XmNuserData, &names, NULL);
  /* Does this match the list we want? */
  if (names != NULL)
    {
      hide = (struct hidden_in_list *) &names->string[names->count];
      if ((hide->type_code == itemPtr->Code())
	  && (hide->expansion == expansion) && (hide->level == level))
	/* It's a match; leave the list alone. */
	return (options.item.edit.set_or_unique && (names->count > 1));
    }

  /* Get a new list of set items */
  names = GetSetsContainingItem (itemPtr->Code(), expansion, level);
  if (names == NULL)
    {
      /* No set items match this item (within restrictions).
	 Create an empty list. */
      names = (StringList) xmalloc (sizeof (_StringList)
				    + sizeof (struct hidden_in_list));
      names->count = 0;
    }
  else
    {
      /* Append our hidden fields */
      names = (StringList) xrealloc (names, sizeof (_StringList)
				     + names->count * sizeof (_StringListEntry)
				     + sizeof (struct hidden_in_list));
    }
  hide = (struct hidden_in_list *) &names->string[names->count];
  hide->type_code = itemPtr->Code();
  hide->expansion = expansion;
  hide->rare = False;
  hide->level = level;
  /* Install the names */
  install_names_in_dropdown_list (combo_box, names);

  return (options.item.edit.set_or_unique && (names->count > 1));
}

static void
install_rare_names (Widget combo_box, const d2sItem *itemPtr,
		    StringList (*GetRareNamesFor) (const char *))
{
  StringList	names;
  struct hidden_in_list *hide;
  const char *	code;

  /* Figure out what kind of list we want installed */
  code = (options.character.link.freeform ? NULL
	  : GetEntryStringField (itemPtr->TypeTableEntry(), "code"));
  /* There are no expansion- or level-specific rare names */

  /* Get the currently installed list of names */
  XtVaGetValues (combo_box, XmNuserData, &names, NULL);
  /* Does this match the list we want? */
  if (names != NULL)
    {
      hide = (struct hidden_in_list *) &names->string[names->count];
      if (hide->type_code == code)
	/* It's a match; leave the list alone and return. */
	return;
    }

  /* Generate a new list of rare names */
  names = (*GetRareNamesFor) (code);
  /* Append our hidden fields */
  names = (StringList) xrealloc (names, sizeof (_StringList)
				 + names->count * sizeof (_StringListEntry)
				 + sizeof (struct hidden_in_list));
  hide = (struct hidden_in_list *) &names->string[names->count];
  hide->type_code = code;
  hide->expansion = 0;
  hide->rare = True;
  hide->level = 0;
  /* Install the names */
  install_names_in_dropdown_list (combo_box, names);
}

static int
install_rare_first_names (void *objPtr, Widget combo_box)
{
  install_rare_names (combo_box, (d2sItem *) objPtr, GetRareTitle1stWordsFor);

  /* Return whether the user can change the rare name */
  return options.item.edit.magic_name;
}

static int
install_rare_last_names (void *objPtr, Widget combo_box)
{
  install_rare_names (combo_box, (d2sItem *) objPtr, GetRareTitle2ndWordsFor);

  /* Return whether the user can change the rare name */
  return options.item.edit.magic_name;
}

static int
install_rare_xfixes (void *objPtr, Widget combo_box, int field)
{
  install_magic_xfixes (combo_box, (d2sItem *) objPtr, True,
			/* Remember, this FIELD argument is one-based. */
			(field & 1) ? GetMagicPrefixesFor
			: GetMagicSuffixesFor);

  /* Return whether the user can change the magic prefix */
  return options.item.edit.magic_name;
}

static int
install_unique_names (void *objPtr, Widget combo_box)
{
  d2sItem *	itemPtr = (d2sItem *) objPtr;
  StringList	names;
  struct hidden_in_list *hide;
  int		expansion, level;

  /* Figure out what kind of list we want installed */
  expansion = (options.item.link.item_expansion
	       || (itemPtr->Owner() == NULL)
	       || (itemPtr->Owner()->is_expansion()));
  level = ((options.character.link.freeform
	    || (itemPtr->Type() < UNKNOWN_EXTENDED_ITEM))
	   ? 0 : ((d2sExtendedItem *) *itemPtr)->Level());

  /* Get the currently installed list of names */
  XtVaGetValues (combo_box, XmNuserData, &names, NULL);
  /* Does this match the list we want? */
  if (names != NULL)
    {
      hide = (struct hidden_in_list *) &names->string[names->count];
      if ((hide->type_code == itemPtr->Code())
	  && (hide->expansion == expansion) && (hide->level == level))
	/* It's a match; leave the list alone. */
	return (options.item.edit.set_or_unique && (names->count > 1));
    }

  /* Get a new list of unique items */
  names = GetUniqueItemsMatching (itemPtr->Code(), expansion, level);
  if (names == NULL)
    {
      /* No set items match this item (within restrictions).
	 Create an empty list. */
      names = (StringList) xmalloc (sizeof (_StringList)
				    + sizeof (struct hidden_in_list));
      names->count = 0;
    }
  else
    {
      /* Append our hidden fields */
      names = (StringList) xrealloc (names, sizeof (_StringList)
				     + names->count * sizeof (_StringListEntry)
				     + sizeof (struct hidden_in_list));
    }
  hide = (struct hidden_in_list *) &names->string[names->count];
  hide->type_code = itemPtr->Code();
  hide->expansion = expansion;
  hide->rare = False;
  hide->level = level;
  /* Install the names */
  install_names_in_dropdown_list (combo_box, names);

  return (options.item.edit.set_or_unique && (names->count > 1));
}

/* Delete a StringList when the drop-down widget using it is destroyed */
void
ui_remove_names_from_dropdown (Widget combo_box, XtPointer client_data,
			       XtPointer call_data)
{
  StringList	names;

  XtVaGetValues (combo_box, XmNuserData, &names, NULL);
  if (names != NULL)
    free (names);
  XtVaSetValues (combo_box, XmNuserData, NULL, NULL);
}
