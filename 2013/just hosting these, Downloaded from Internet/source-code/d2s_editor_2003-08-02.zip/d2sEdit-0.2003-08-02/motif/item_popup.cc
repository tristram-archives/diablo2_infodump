/* UI function for managing the item popup window.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "ui.h"
#include <Xm/Text.h>
#include <Xm/ToggleB.h>
#include <dmalloc.h>

void
ui_show_item_popup (Widget w, XtPointer client_data, XtPointer call_data)
{
  d2sItem *	item;
  Widget	popup_shell, form_item_popup, box;
  MrmType	class_code;
  char *	make_name;
  int		status, more_rows;
  Position	x, y;
  XmString	item_text;

  XtVaGetValues (w, XmNuserData, &item, NULL);
  /* If there is no item in the box, ignore the button press */
  if (item == NULL)
    return;

  /* If the item is already associated with a window, ignore the request. */
  if (item->GetUI() != NULL)
    {
      /* Raise the window so that the user knows it's there */
      XMapRaised (XtDisplay (w), XtWindow (XtParent (item->GetUI())));
      return;
    }

  /* If the user doesn't want popups, skip directly to the item editor. */
  if (!options.item.link.show_popup)
    {
      if (open_item_editor_window (item) >= 0)
	return;
    }

  /* Create a new item popup window */
  popup_shell = XtVaCreatePopupShell ("itemPopup", transientShellWidgetClass,
				      w, NULL);
  status = MrmFetchWidget (mrm_hierarchy, "form_item_popup", popup_shell,
			   &form_item_popup, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create interface form_item_popup"
	       " from UID file\n", progname);
      XtDestroyWidget (popup_shell);
      return;
    }

  /* Add a callback for closing the window */
  XtAddCallback (popup_shell, XmNdestroyCallback,
		 ui_item_popup_destroyed, form_item_popup);

  /* Make up a suitable name for the popup shell widget */
  if (item->Owner() != NULL)
    {
      make_name = (char *) XtMalloc (16 + 3 + strlen (item->Name()) + 1);
      sprintf (make_name, "%s's %s",
	       item->Owner()->GetCharacterName(), item->Name());
    }
  else if (item->SourceFileName() != NULL)
    {
      make_name = (char *) XtMalloc (strlen (item->Name()) + 2
				      + strlen (item->SourceFileName()) + 2);
      sprintf (make_name, "%s (%s)",
	       item->Name(), item->SourceFileName());
    }
  else
    {
      make_name = (char *) XtMalloc (strlen (item->Name() + 1));
      strcpy (make_name, item->Name());
    }
  item_text = XmStringCreateLocalized (make_name);

  /* Assign the popup window to the item */
  item->SetUI (form_item_popup);
  /* And vice-versa */
  XtVaSetValues (form_item_popup,
		 XmNdialogTitle, item_text,
		 XmNuserData, item,
		 NULL);
  XmStringFree (item_text);
  XtFree (make_name);

  /* Establish the position of the dialog to match the item button. */
  XtVaGetValues (w,
		 XmNheight, &y,
		 XmNwidth, &x,
		 NULL);
  /* This translates the coordinates of the bottom right
     corner of the widget to root-relative. */
  XtTranslateCoords (w, x, y, &x, &y);
  XtVaSetValues (popup_shell,
		 XmNallowShellResize, True,
		 XmNx, x,
		 XmNy, y,
		 NULL);

  if (item->Owner() != NULL)
    {
      /* If the item's owner is set to read-only,
	 disable the Edit button. */
      if (item->Owner()->read_only)
	XtVaSetValues (XxNameToWidget (form_item_popup, "*popitem_edit"),
		       XmNsensitive, False,
		       NULL);

      /* If the item's owner is set to read-only,
	 disable the Repair button. */
      if (item->Owner()->read_only
	  || (!options.item.edit.durability && !options.item.edit.quantity))
	XtVaSetValues (XxNameToWidget (form_item_popup, "*popitem_repair"),
		       XmNsensitive, False,
		       NULL);
    }

  /* A lot of our work is duplicated in the update_item_popup function */
  update_item_popup (item);

  /* Start filling in the long version of the dialog,
     even though it's not being shown yet. */
  box = XxNameToWidget (form_item_popup, "*popitem_more_text");
  make_name = (char *) XtMalloc (32);
  x = sprintf (make_name, "Item code: '%.3s'", item->Code());
  more_rows = 1;
  if (item->Type() >= ARMOR_ITEM) {
    d2sDurableItem *ditem = (d2sDurableItem *) *item;
    /* Add a tag for newbie items */
    if (ditem->is_newbie()) {
      make_name = (char *) XtRealloc (make_name,
				      x + sizeof ("\n(Newbie)") + 2);
      x += sprintf (&make_name[x], "\n(Newbie)");
      more_rows++;
    }
    /* Stacked weapons, bows, and crossbows don't show
       their durability fields by default. */
    if ((item->Type() == STACKED_WEAPON_ITEM)
	|| ((item->Type() == WEAPON_ITEM)
	    && ((((d2sWeaponItem *) ditem)->WeaponClass() == BOW_CLASS)
		|| (((d2sWeaponItem *) ditem)->WeaponClass()
		    == CROSSBOW_CLASS)))) {
      make_name = (char *) XtRealloc
	(make_name, x + sizeof ("\nHidden durability: 123 of 123") + 16);
      x += sprintf (&make_name[x], "\nHidden durability: %d of %d",
		    ditem->Durability(), ditem->MaxDurability());
      more_rows++;
    }
  }
  if (item->Type() >= UNKNOWN_EXTENDED_ITEM) {
    d2sExtendedItem *eitem = (d2sExtendedItem *) *item;
    /* Add various hidden and unknown data about extended items */
    make_name = (char *) XtRealloc
      (make_name, x + sizeof ("\nFingerprint: 0xdeadbeef\nItem Level: 123"
			      "\nPicture: #3\n11-bit unknown: 1234"
			      "\nColor: Crystal Yellow") + 16);
    x += sprintf (&make_name[x], "\nFingerprint: %#.8lx\nItem Level: %d",
		  eitem->UniqueID(), eitem->Level());
    more_rows += 2;
    if (eitem->Quality()->has_a_picture()) {
      x += sprintf (&make_name[x], "\nPicture: #%d",
		    eitem->Quality()->Picture() + 1);
      more_rows++;
    }
    if (eitem->Quality()->has_an_11_bit_field()) {
      x += sprintf (&make_name[x], "\n11-bit unknown: %d",
		    eitem->Quality()->Unknown11());
      more_rows++;
    }
    if (eitem->Quality()->is_colored()) {
      x += sprintf (&make_name[x], "\nColor: %s", GetEntryStringField
		    (LookupTableEntry ("colors", "Code",
				       eitem->Quality()->Color()),
		     "Transform Color"));
      more_rows++;
    }
    /* Add data specific to different quality types */
    switch ((int) eitem->Quality()->QualityClass()) {
    case LOW_QUALITY:
      make_name = (char *) XtRealloc
	(make_name, x + sizeof ("\nLow Quality Rating: 3") + 8);
      x += sprintf (&make_name[x], "\nLow Quality Rating: %d",
		    ((d2sLowQuality *) eitem->Quality())->Grade());
      more_rows++;
      break;
    case HIGH_QUALITY:
      make_name = (char *) XtRealloc
	(make_name, x + sizeof ("\nHigh Quality Rating: 3") + 8);
      x += sprintf (&make_name[x], "\nHigh Quality Rating: %d",
		    ((d2sHighQuality *) eitem->Quality())->Grade());
      more_rows++;
      break;
    case RARE_QUALITY:
      /* Fun one!  There are 6 *optional* hidden fields, each one
	 representing a magic prefix or suffix. */
      make_name = (char *) XtRealloc
	(make_name, x + sizeof ("\nHidden Names:") + 6 * 40);
      x += sprintf (&make_name[x], "\nHidden Names:");
      for (y = 0; y < 6; y++) {
	if (((d2sRareQuality *) eitem->Quality())->HiddenFieldID(y))
	  x += snprintf (&make_name[x], 40, "%s \"%.35s\"", y ? "," : "",
			 ((d2sRareQuality *) eitem->Quality())
			 ->HiddenField(y));
      }
      more_rows++;
    }
  }
  if (item->Type() == STACK_ITEM) {
    d2sStackItem *sitem = (d2sStackItem *) *item;
    /* If this has a tome's 5-bit field, add it to the display. */
    if (sitem->is_tome()) {
      make_name = (char *) XtRealloc
	(make_name, x + sizeof ("\nTome: 31") + 8);
      x += sprintf (&make_name[x], "\nTome: %d", sitem->TomeField());
      more_rows++;
    }
  }
  XmTextSetString (box, make_name);
  free (make_name);
  XtVaSetValues (box,
		 XmNrows, (more_rows < 6) ? more_rows : ((more_rows + 5) / 2),
		 NULL);

  /* If the item is not a derivative of a stack or durable item,
     remove the Repair button.  If it is a stack, change the label
     to "Replenish". */
  switch (item->Type())
    {
    case UNKNOWN_ITEM:
    case SIMPLE_ITEM:
    case UNKNOWN_EXTENDED_ITEM:
    case EXTENDED_ITEM:
    default:
      XtUnmanageChild (XxNameToWidget (form_item_popup, "*popitem_repair"));
      break;
    case STACK_ITEM:
    case STACKED_WEAPON_ITEM:
      item_text = XmStringCreateLocalized ("Replenish");
      XtVaSetValues (XxNameToWidget (form_item_popup, "*popitem_repair"),
		     XmNlabelString, item_text,
		     NULL);
      XmStringFree (item_text);
      /* If the item is already at maximum capacity,
	 disable the replenish button. */
      if (((d2sStackItem *) *item)->Quantity()
	  >= ((d2sStackItem *) *item)->MaxQuantity())
	XtVaSetValues (XxNameToWidget (form_item_popup, "*popitem_repair"),
		       XmNsensitive, False,
		       NULL);
      break;
    case ARMOR_ITEM:
    case WEAPON_ITEM:
      {
	d2sDurableItem *ditem = (d2sDurableItem *) *item;

	/* If the item is already at maximum durability,
	   disable the repair button. */
	if (ditem->Durability() >= ditem->MaxDurability())
	  XtVaSetValues (XxNameToWidget (form_item_popup, "*popitem_repair"),
			 XmNsensitive, False,
			 NULL);
	break;
      }
    }

  /* Show the popup box. */
  XtManageChild (form_item_popup);
  XtPopup (popup_shell, XtGrabNone);
  XtRealizeWidget (popup_shell);
}

void
ui_item_popup_destroyed (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	popup_window = (Widget) client_data;
  d2sItem	*item;
  Pixmap	item_pixmap;
  char		box_name[16] = "*popitem_gem_1";
  int		i;

  /* Get the associated item */
  XtVaGetValues (popup_window, XmNuserData, &item, NULL);
  if (item != NULL) {
    /* Disassociate ourself */
    item->SetUI (NULL);
    XtVaSetValues (popup_window, XmNuserData, NULL, NULL);
  }

  /* Be sure to tidy up after ourself. */
  XtVaGetValues (XxNameToWidget (w, "*popitem_image"),
		 XmNlabelPixmap, &item_pixmap,
		 NULL);
  /* This decrements the reference count to the item's
     picture in Motif's Pixmap cache.  The pixmap is
     destroyed when no more widgets are using it. */
  if (item_pixmap != XmUNSPECIFIED_PIXMAP)
    XmDestroyPixmap (XtScreen (w), item_pixmap);
  /* Also release pictures of any attached gems */
  for (i = 1; i <= 12; i++)
    {
      sprintf (&box_name[13], "%d", i);
      XtVaGetValues (XxNameToWidget (w, box_name),
		     XmNlabelPixmap, &item_pixmap,
		     NULL);
      if ((item_pixmap != XmUNSPECIFIED_PIXMAP)
	  && (item_pixmap != gem_socket_icon))
	XmDestroyPixmap (XtScreen (w), item_pixmap);
    }
}

/* When the "More >>" button is pressed, manage the extra text
   window in the item popup and change the button to "Less <<".
   When the "Less <<" button is pressed, reverse the procedure. */
void
ui_popitem_more_less (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	form_item_popup = (Widget) client_data;
  Widget	stw;
  XmString	xmstr;
  XtWidgetGeometry box_size;
  Dimension	popup_height;

  stw = XxNameToWidget (form_item_popup, "*popitem_more_box");

  /* Get the size of the popup window.  This will be changed later on. */
  box_size.request_mode = (CWHeight | CWWidth);
  XtQueryGeometry (stw, NULL, &box_size);
  XtVaGetValues (XtParent (form_item_popup), XmNheight, &popup_height, NULL);

  if (XtIsManaged (stw))
    {
      /* "More" is active.  Switch to "Less". */
      XtUnmanageChild (stw);
      popup_height -= box_size.height;
      xmstr = XmStringCreateLocalized ("More >>");
      XtVaSetValues (w,
		     XmNbottomAttachment, XmATTACH_FORM,
		     XmNlabelString, xmstr,
		     NULL);
    }

  else
    {
      /* "Less" is active.  Switch to "More". */
      XtManageChild (stw);
      popup_height += box_size.height;
      xmstr = XmStringCreateLocalized ("Less <<");
      XtVaSetValues (w,
		     XmNbottomAttachment, XmATTACH_WIDGET,
		     XmNbottomWidget, stw,
		     XmNlabelString, xmstr,
		     NULL);
    }

  /* Since adding or removing the text window will affect the popup
     window's size, we need to force it to resize itself. */
  XtVaSetValues (XtParent (form_item_popup), XmNheight, popup_height, NULL);
}

void
ui_repair_popitem (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	form_item_popup = (Widget) client_data;
  d2sItem *	item;
  d2sDurableItem *dur_item;
  d2sStackItem *stack_item;
  char *	item_description;
  XmString	item_text;

  /* This button should be disabled after use. */
  XtVaSetValues (w, XmNsensitive, False, NULL);

  /* Get the item pointer */
  XtVaGetValues (form_item_popup, XmNuserData, &item, NULL);
  /* If there is no item in the window, there is a problem. */
  if (item == NULL)
    {
      fprintf (stderr, "%s: Internal error: no item has been assigned\n"
	       " to the popup window %s.\n",
	       progname, XtName (XtParent (form_item_popup)));
      return;
    }

  /* Convert to the appropriate pointer.  Stacks and stacked weapons
     are converted to d2sStackItem for replenishing.  Armor and
     normal weapons must be derivatives of d2sDurableItem. */
  if ((item->Type() == STACK_ITEM) || (item->Type() == STACKED_WEAPON_ITEM))
    {
      stack_item = (d2sStackItem *) *item;
      if (stack_item->Replenish () < 0)
	{
	  display_error (item->GetErrorMessage());
	  return;
	}
    }
  else
    {
      dur_item = (d2sDurableItem *) *item;
      if (dur_item->Repair () < 0)
	{
	  display_error (item->GetErrorMessage());
	  return;
	}
    }

  /* After repairing (or replenishing) the item,
     we need to update its description. */
  item_description = item->FullDescription();
  item_text = XmStringCreateLocalized (item_description);
  XtVaSetValues (XxNameToWidget (form_item_popup, "*popitem_description"),
		 XmNlabelString, item_text,
		 NULL);
  XmStringFree (item_text);
  free (item_description);
}

void
ui_edit_popitem (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	form_item_popup = (Widget) client_data;
  d2sItem *	item;

  XtVaGetValues (form_item_popup, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      fprintf (stderr, "%s: Internal error: item popup window %s\n"
	       " does not contain any item!\n", progname,
	       XtName (XtParent (form_item_popup)));
      /* Destroy the widowed popup window */
      XtDestroyWidget (XtParent (form_item_popup));
      return;
    }

  /* Release the item from this window */
  item->SetUI (NULL);
  XtVaSetValues (form_item_popup, XmNuserData, NULL, NULL);

  /* Create an item editor window and put this item in it. */
  if (open_item_editor_window (item) < 0)
    {
      /* Oops!  Can't open the item editor.  Better keep the popup. */
      XtVaSetValues (form_item_popup, XmNuserData, item, NULL);
      item->SetUI (form_item_popup);
      return;
    }

  /* The popup is no longer needed.  Remove it. */
  XtDestroyWidget (XtParent (form_item_popup));
}

/* This is called when an item popup needs to be updated,
   in particular when the gems attached to an item have been edited. */
void
update_item_popup (d2sItem *item)
{
  Widget	w, popup_window = (Widget) item->GetUI();
  Pixmap	item_picture, old_picture;
  char *	item_description;
  XmString	item_text;
  char		box_name[16] = "*popitem_gem_1";
  d2sDurableItem *ditem;
  d2sAttachItem *gem;
  int		x;
  Dimension	height, width, old_height, old_width;
  XtWidgetGeometry box_size;
  Dimension	old_boxh, old_boxw;

  /* Make sure this is an item popup window */
  if ((popup_window == NULL)
      || (strcmp (XtName (popup_window), "form_item_popup") != 0))
    return;

  /* Get the current window size, if it is already popped up */
  if (XtIsManaged (popup_window)) {
    XtVaGetValues (XtParent (popup_window),
		   XmNheight, &old_height,
		   XmNwidth, &old_width,
		   NULL);
    height = old_height;
    width = old_width;
  } else {
    old_height = 0;
    old_width = 0;
  }

  /* Get the old picture */
  w = XxNameToWidget (popup_window, "*popitem_image");
  XtVaGetValues (w, XmNlabelPixmap, &old_picture, NULL);
  /* Install a new picture */
  item_picture = load_item_picture (XtScreen (w), item);
  if (item_picture != old_picture)
    XtVaSetValues (w, XmNlabelPixmap, item_picture,
		   XmNlabelType, ((item_picture == XmUNSPECIFIED_PIXMAP)
				  ? XmSTRING : XmPIXMAP),
		   NULL);
  XtVaSetValues (w, XmNuserData, item, NULL);
  /* Release the old picture */
  if (old_picture != XmUNSPECIFIED_PIXMAP)
    XmDestroyPixmap (XtScreen (w), old_picture);

  /* Update the item's full description in the inset box */
  item_description = item->FullDescription();
  item_text = XmStringCreateLocalized (item_description);
  XtVaSetValues (XxNameToWidget (popup_window, "*popitem_description"),
		 XmNlabelString, item_text,
		 NULL);
  XmStringFree (item_text);
  free (item_description);
  if (old_height) {
    /* Find out how big the description box wants to be. */
    w = XxNameToWidget (popup_window, "*popitem_description_frame");
    XtVaGetValues (w, XmNheight, &old_boxh,
		   XmNwidth, &old_boxw,
		   NULL);
    /* Set a lower limit on the frame size to that of the picture */
    if (old_boxh < 115)
      old_boxh = 115;
    box_size.request_mode = (CWHeight | CWWidth);
    XtQueryGeometry (w, NULL, &box_size);
    if (box_size.height < 115)
      box_size.height = 115;

    /* Update the form size */
    if (old_boxh != box_size.height) {
      w = XxNameToWidget (popup_window, "*popitem_head");
      XtVaGetValues (w, XmNheight, &box_size.y, NULL);
      XtVaSetValues (w, XmNheight, box_size.y - old_boxh + box_size.height,
		     NULL);
    }

    /* Update the popup window size */
    height = height - old_boxh + box_size.height;
    width = width - old_boxw + box_size.width;
  }

  if (item->Type() >= ARMOR_ITEM)
    {
      ditem = (d2sDurableItem *) *item;
      /* Does the row of gems need to be displayed or removed? */
      w = XxNameToWidget (popup_window, "*popitem_gems");
      if (ditem->ModNumberOfSockets() && !XtIsManaged (w))
	{
	  XtManageChild (w);
	  XtVaSetValues (XxNameToWidget (popup_window, "*popitem_spacer"),
			 XmNtopWidget, w,
			 NULL);
	  if (old_height) {
	    box_size.request_mode = CWHeight;
	    XtQueryGeometry (w, NULL, &box_size);
	    height += box_size.height;
	  }
	}
      else if (!ditem->ModNumberOfSockets() && XtIsManaged (w))
	{
	  XtUnmanageChild (w);
	  XtVaSetValues (XxNameToWidget (popup_window, "*popitem_spacer"),
			 XmNtopWidget, XxNameToWidget (popup_window,
						       "*popitem_head"),
			 NULL);
	  if (old_height) {
	    XtVaGetValues (w, XmNheight, &old_boxh, NULL);
	    height -= old_boxh;
	  }
	}

      for (x = 0; x < ditem->ModNumberOfSockets(); x++)
	{
	  if (x >= 12)
	    break;
	  sprintf (&box_name[13], "%d", x + 1);
	  w = XxNameToWidget (popup_window, box_name);
	  XtManageChild (w);
	  gem = ditem->Gem(x);
	  XtVaGetValues (w, XmNlabelPixmap, &old_picture, NULL);
	  if (gem != NULL)
	    {
	      item_picture = load_item_picture (XtScreen (w), gem);
	      if (item_picture == XmUNSPECIFIED_PIXMAP)
		{
		  item_text
		    = XmStringCreateLocalized ((char *) gem->Code());
		  XtVaSetValues (w, XmNlabelPixmap, XmUNSPECIFIED_PIXMAP,
				 XmNlabelString, item_text,
				 XmNlabelType, XmSTRING,
				 XmNuserData, (d2sItem *) gem,
				 NULL);
		  XmStringFree (item_text);
		}
	      else
		{
		  XtVaSetValues (w, XmNlabelPixmap, item_picture,
				 XmNuserData, (d2sItem *) gem,
				 NULL);
		}
	    }
	  else
	    {
	      /* If there is no gem here, make sure
		 the user data field is clear. */
	      XtVaSetValues (w,
			     XmNlabelPixmap, gem_socket_icon,
			     XmNlabelType, XmPIXMAP,
			     XmNuserData, NULL,
			     NULL);
	    }
	  /* Release the old picture */
	  if ((old_picture != XmUNSPECIFIED_PIXMAP)
	      && (old_picture != gem_socket_icon))
	    XmDestroyPixmap (XtScreen (w), old_picture);
	}
      for ( ; x < 12; x++)
	{
	  /* Make sure the rest of the socket boxes are hidden */
	  sprintf (&box_name[13], "%d", x + 1);
	  w = XxNameToWidget (popup_window, box_name);
	  XtUnmanageChild (w);
	  XtVaGetValues (w, XmNlabelPixmap, &old_picture, NULL);
	  if ((old_picture != XmUNSPECIFIED_PIXMAP)
	      && (old_picture != gem_socket_icon))
	    XmDestroyPixmap (XtScreen (w), old_picture);
	}
    }

  if (old_height && ((width != old_width) || (height != old_height)))
    /* Update the popup window's size */
    XtVaSetValues (XtParent (popup_window),
		   XmNheight, height,
		   XmNwidth, width,
		   NULL);
}
