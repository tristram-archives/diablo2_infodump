/* Callback functions used by the interface.
 * These should cleanly separate the data processing part of the
 * application from the user interface.  All functions listed here must
 * have prototypes in callbacks.h.
 *
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "ui.h"
#include <ctype.h>
#include <Mrm/MrmPublic.h>
#include <Xm/MessageB.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <Xm/ScrolledW.h>
#include <Xm/SpinB.h>
#include <dmalloc.h>

static MrmRegisterArg callback_list[] = {
  { "ui_window_close", (XtPointer) ui_window_close },
  { "ui_file_new", (XtPointer) ui_file_new },
  { "ui_file_open", (XtPointer) ui_file_open },
  { "ui_file_save", (XtPointer) ui_file_save },
  { "ui_file_save_as", (XtPointer) ui_file_save_as },
  { "ui_file_import_item", (XtPointer) ui_file_import_item },
  { "ui_file_export_item", (XtPointer) ui_file_export_item },
  { "ui_file_load_item_set", (XtPointer) ui_file_load_item_set },
  { "ui_file_save_item_set", (XtPointer) ui_file_save_item_set },
  { "ui_file_close", (XtPointer) ui_file_close },
  { "ui_file_exit", (XtPointer) ui_file_exit },
  { "ui_edit_cut", (XtPointer) ui_edit_cut },
  { "ui_edit_copy", (XtPointer) ui_edit_copy },
  { "ui_edit_paste", (XtPointer) ui_edit_paste },
  { "ui_edit_item_editor", (XtPointer) ui_edit_item_editor },
  { "ui_edit_options", (XtPointer) ui_edit_options },
  { "ui_view_map_or_unmap", (XtPointer) ui_view_map_or_unmap },
  { "ui_view_drop_site_update", (XtPointer) ui_view_drop_site_update },
  { "ui_help_about", (XtPointer) ui_help_about },
  { "ui_help_contents", (XtPointer) ui_help_contents },
  { "ui_check_dirty", (XtPointer) ui_check_dirty },
  { "ui_check_copy", (XtPointer) ui_check_copy },
  { "ui_check_paste", (XtPointer) ui_check_paste },
  { "ui_popdown", (XtPointer) ui_popdown },
  { "ui_ungrab", (XtPointer) ui_ungrab },
  { "ui_enable_cursor", (XtPointer) ui_enable_cursor },
  { "ui_disable_cursor", (XtPointer) ui_disable_cursor },
  { "ui_char_name_verify", (XtPointer) ui_char_name_verify },
  { "ui_char_name_possible", (XtPointer) ui_char_name_possible },
  { "ui_numeric_verify", (XtPointer) ui_numeric_verify },
  { "ui_snumeric_verify", (XtPointer) ui_snumeric_verify },
  { "ui_fpnumeric_verify", (XtPointer) ui_fpnumeric_verify },
  { "ui_hexnumeric_verify", (XtPointer) ui_hexnumeric_verify },
  { "ui_hex_short_verify", (XtPointer) ui_hex_short_verify },
  { "ui_stat_changed_name", (XtPointer) ui_stat_changed_name },
  { "ui_stat_changed_title", (XtPointer) ui_stat_changed_title },
  { "ui_stat_changed_level", (XtPointer) ui_stat_changed_level },
  { "ui_stat_changed_experience", (XtPointer) ui_stat_changed_experience },
  { "ui_toggle_expansion", (XtPointer) ui_toggle_expansion },
  { "ui_toggle_hardcore", (XtPointer) ui_toggle_hardcore },
  { "ui_toggle_death", (XtPointer) ui_toggle_death },
  { "ui_stat_changed_strength", (XtPointer) ui_stat_changed_strength },
  { "ui_stat_add_strength", (XtPointer) ui_stat_add_strength },
  { "ui_stat_changed_energy", (XtPointer) ui_stat_changed_energy },
  { "ui_stat_add_energy", (XtPointer) ui_stat_add_energy },
  { "ui_stat_changed_dexterity", (XtPointer) ui_stat_changed_dexterity },
  { "ui_stat_add_dexterity", (XtPointer) ui_stat_add_dexterity },
  { "ui_stat_changed_vitality", (XtPointer) ui_stat_changed_vitality },
  { "ui_stat_add_vitality", (XtPointer) ui_stat_add_vitality },
  { "ui_stat_changed_life_base", (XtPointer) ui_stat_changed_life_base },
  { "ui_stat_changed_life_current", (XtPointer) ui_stat_changed_life_current },
  { "ui_stat_changed_mana_base", (XtPointer) ui_stat_changed_mana_base },
  { "ui_stat_changed_mana_current", (XtPointer) ui_stat_changed_mana_current },
  { "ui_stat_changed_stamina_base", (XtPointer) ui_stat_changed_stamina_base },
  { "ui_stat_changed_stamina_current",
    (XtPointer) ui_stat_changed_stamina_current },
  { "ui_stat_changed_statp_rem", (XtPointer) ui_stat_changed_statp_remaining },
  { "ui_stat_changed_skillp_rem",
    (XtPointer) ui_stat_changed_skillp_remaining },
  { "ui_stat_changed_gold_inventory",
    (XtPointer) ui_stat_changed_gold_inventory },
  { "ui_stat_changed_gold_stash", (XtPointer) ui_stat_changed_gold_stash },
  { "ui_slider_sync", (XtPointer) ui_slider_sync },
  { "ui_scroll_keyb_traversal", (XtPointer) ui_scroll_keyb_traversal },
  { "ui_tab_next", (XtPointer) ui_tab_next },
  { "ui_spinbox_sync", (XtPointer) ui_spinbox_sync },
  { "ui_spinbox_changed", (XtPointer) ui_spinbox_changed },
  { "ui_spinbox_up", (XtPointer) ui_spinbox_up },
  { "ui_select_skill_set", (XtPointer) ui_select_skill_set },
  { "ui_set_read_only", (XtPointer) ui_set_read_only },
  { "ui_show_item_popup", (XtPointer) ui_show_item_popup },
  { "ui_swap_corpse_inventory", (XtPointer) ui_swap_corpse_inventory },
  { "ui_set_act_location", (XtPointer) ui_set_act_location },
  { "ui_show_actdifficulty", (XtPointer) ui_show_actdifficulty },
  { "ui_show_wpdifficulty", (XtPointer) ui_show_wpdifficulty },
  { "ui_show_qstdifficulty", (XtPointer) ui_show_qstdifficulty },
  { "ui_toggle_act_intro", (XtPointer) ui_toggle_act_intro },
  { "ui_toggle_npc_intro", (XtPointer) ui_toggle_npc_intro },
  { "ui_toggle_act_exit", (XtPointer) ui_toggle_act_exit },
  { "ui_toggle_waypoint", (XtPointer) ui_toggle_waypoint },
  { "ui_select_quest", (XtPointer) ui_select_quest },
  { "ui_quest_changed_hex", (XtPointer) ui_quest_changed_hex },
  { "ui_toggle_hire_death", (XtPointer) ui_toggle_hire_death },
  { "ui_hire_changed_name", (XtPointer) ui_hire_changed_name },
  { "ui_hire_changed_attribute", (XtPointer) ui_hire_changed_attribute },
  { "ui_hire_changed_level", (XtPointer) ui_hire_changed_level },
  { "ui_hire_changed_experience", (XtPointer) ui_hire_changed_experience },
  { "ui_slider_hire_sync", (XtPointer) ui_slider_hire_sync },
  { "ui_popitem_more_less", (XtPointer) ui_popitem_more_less },
  { "ui_repair_popitem", (XtPointer) ui_repair_popitem },
  { "ui_edit_popitem", (XtPointer) ui_edit_popitem },
  { "ui_item_window_close", (XtPointer) ui_item_window_close },
  { "ui_check_dirty_item", (XtPointer) ui_check_dirty_item },
  { "ui_check_socket_cut", (XtPointer) ui_check_socket_cut },
  { "ui_check_socket_paste", (XtPointer) ui_check_socket_paste },
  { "ui_item_create", (XtPointer) ui_item_create },
  { "ui_item_open", (XtPointer) ui_item_open },
  { "ui_item_save", (XtPointer) ui_item_save },
  { "ui_item_save_as", (XtPointer) ui_item_save_as },
  { "ui_item_close", (XtPointer) ui_item_close },
  { "ui_item_copy", (XtPointer) ui_item_copy },
  { "ui_item_duplicate", (XtPointer) ui_item_duplicate },
  { "ui_item_cut_gem", (XtPointer) ui_item_cut_gem },
  { "ui_item_paste", (XtPointer) ui_item_paste },
  { "ui_item_move", (XtPointer) ui_item_move },
  { "ui_item_remove", (XtPointer) ui_item_remove },
  { "ui_item_assign", (XtPointer) ui_item_assign },
  { "ui_change_potion", (XtPointer) ui_change_potion },
  { "ui_change_gem", (XtPointer) ui_change_gem },
  { "ui_change_rune", (XtPointer) ui_change_rune },
  { "ui_item_change_fingerprint", (XtPointer) ui_item_change_fingerprint },
  { "ui_item_change_level", (XtPointer) ui_item_change_level },
  { "ui_item_toggle_newbie", (XtPointer) ui_item_toggle_newbie },
  { "ui_item_toggle_ethereal", (XtPointer) ui_item_toggle_ethereal },
  { "ui_item_change_durability", (XtPointer) ui_item_change_durability },
  { "ui_item_change_base_durability",
    (XtPointer) ui_item_change_base_durability },
  { "ui_item_change_defense", (XtPointer) ui_item_change_defense },
  { "ui_item_change_quantity", (XtPointer) ui_item_change_quantity },
  { "ui_edit_gem", (XtPointer) ui_edit_gem },
  { "ui_move_gem_up", (XtPointer) ui_move_gem_up },
  { "ui_move_gem_down", (XtPointer) ui_move_gem_down },
  { "ui_item_add_socket", (XtPointer) ui_item_add_socket },
  { "ui_item_remove_socket", (XtPointer) ui_item_remove_socket },
  { "ui_item_toggle_identified", (XtPointer) ui_item_toggle_identified },
  { "ui_item_change_owner", (XtPointer) ui_item_change_owner },
  { "ui_change_item_quality", (XtPointer) ui_change_item_quality },
  { "ui_change_magic_prefix", (XtPointer) ui_change_magic_prefix },
  { "ui_change_magic_suffix", (XtPointer) ui_change_magic_suffix },
  { "ui_change_set_item", (XtPointer) ui_change_set_item },
  { "ui_change_rare_name1", (XtPointer) ui_change_rare_name1 },
  { "ui_change_rare_name2", (XtPointer) ui_change_rare_name2 },
  { "ui_change_rare_hidden1", (XtPointer) ui_change_rare_hidden1 },
  { "ui_change_rare_hidden2", (XtPointer) ui_change_rare_hidden2 },
  { "ui_change_rare_hidden3", (XtPointer) ui_change_rare_hidden3 },
  { "ui_change_rare_hidden4", (XtPointer) ui_change_rare_hidden4 },
  { "ui_change_rare_hidden5", (XtPointer) ui_change_rare_hidden5 },
  { "ui_change_rare_hidden6", (XtPointer) ui_change_rare_hidden6 },
  { "ui_change_unique_item", (XtPointer) ui_change_unique_item },
  { "ui_remove_names_from_dropdown",
    (XtPointer) ui_remove_names_from_dropdown },
  { "ui_change_picture", (XtPointer) ui_change_picture },
  { "ui_item_place_select_character",
    (XtPointer) ui_item_place_select_character },
  { "ui_item_place_change_area", (XtPointer) ui_item_place_change_area },
  { "ui_new_item_create", (XtPointer) ui_new_item_create },
  { "ui_new_item_filter", (XtPointer) ui_new_item_filter },
  { "ui_new_item_cancel", (XtPointer) ui_new_item_cancel },
  { "ui_new_item_selected", (XtPointer) ui_new_item_selected },
};

static XtActionsRec action_list[] = {
  { "StartDrag", (XtActionProc) ui_start_drag },
  { "StartGemDrag", (XtActionProc) ui_start_gem_drag },
  { "StartRuneDrag", (XtActionProc) ui_start_rune_drag },
  { "StartPotionDrag", (XtActionProc) ui_start_potion_drag },
};

/* Register the callbacks.  Return 0 on success. */
int
register_callbacks (void)
{
  int status;

  status = MrmRegisterNames (callback_list, XtNumber (callback_list));
  if (status != MrmSUCCESS)
    {
      fprintf (stderr,
	       "%s: Unable to register callback functions with Mrm.\n",
	       progname);
      return -1;
    }

  /* Also register translation actions (for use with drag and drop) */
  XtAppAddActions (app_context, action_list, XtNumber (action_list));
  return 0;
}


/* These callback functions are stubbed for now.  Eventually they
   should be replaced with working functions, and moved to the
   appropriate files. */
void
ui_file_import_item (Widget w, XtPointer client_data, XtPointer call_data)
{
  stdui = client_data;
  print_message ("Stub function ui_file_import_item called.");
}

void
ui_file_export_item (Widget w, XtPointer client_data, XtPointer call_data)
{
  stdui = client_data;
  print_message ("Stub function ui_file_export_item called.");
}

void
ui_file_load_item_set (Widget w, XtPointer client_data, XtPointer call_data)
{
  stdui = client_data;
  print_message ("Stub function ui_file_load_item_set called.");
}

void
ui_file_save_item_set (Widget w, XtPointer client_data, XtPointer call_data)
{
  stdui = client_data;
  print_message ("Stub function ui_file_save_item_set called.");
}

/* Change which frame is displayed in the table window */
void
ui_view_map_or_unmap (Widget w, XtPointer client_data, XtPointer call_data)
{
  /* Map the selected frame if the toggle was turned on;
     unmap the frame if the toggle was turned off. */
  XtSetMappedWhenManaged ((Widget) client_data, XmToggleButtonGetState (w));
}

/* Note: this is not currently used; I found out the About box
   doesn't need it, if the resources are set correctly.
   May remove this function eventually. */
void
ui_popdown (Widget w, XtPointer client_data, XtPointer call_data)
{
  printf ("Stub function ui_popdown called by %s.\n", XtName (w));
  XtPopdown (XtParent (w));
}

/* Bug workaround for Motif grabbing the pointer and/or keyboard
   during popup menu operations.  Although the pointer should be
   grabbed while the menu is popped up, it is not ungrabbed before
   callbacks are made. */
void
ui_ungrab (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmAnyCallbackStruct *cbs = (XmAnyCallbackStruct *) call_data;

  if (cbs->event == NULL)
    /* User is not finished with the popup; don't ungrab */
    return;

  XtUngrabPointer (w, CurrentTime);
  XtUngrabKeyboard (w, CurrentTime);
  /* Make sure these requests get to the X server before continuing */
  XSync (XtDisplay (w), False);
}

void
ui_enable_cursor (Widget w, XtPointer client_data, XtPointer call_data)
{
  XtVaSetValues (w, XmNcursorPositionVisible, True, NULL);
}

void
ui_disable_cursor (Widget w, XtPointer client_data, XtPointer call_data)
{
  XtVaSetValues (w, XmNcursorPositionVisible, False, NULL);
}

void
ui_scroll_keyb_traversal (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmTraverseObscuredCallbackStruct *cbs
    = (XmTraverseObscuredCallbackStruct *) call_data;
  XmScrollVisible (w, cbs->traversal_destination, 3, 3);
}

void
ui_tab_next (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmProcessTraversal (w, XmTRAVERSE_NEXT_TAB_GROUP);
}


void
ui_help_about (Widget w, XtPointer client_data, XtPointer call_data)
{
  static Widget dialog = NULL;

  if (dialog == NULL)
    {
      Arg args[6];
      XmString message, title;
      XtSetArg (args[0], XmNautoUnmanage, True);
      XtSetArg (args[1], XmNdialogStyle, XmDIALOG_MODELESS);
      title = XmStringCreateLocalized ("About the .d2s editor");
      XtSetArg (args[2], XmNdialogTitle, title);
      XtSetArg (args[3], XmNmessageAlignment, XmALIGNMENT_CENTER);
      message = XmStringCreateLocalized
	("Diablo II v1.09 Character Editor\n"
	 "mostly-working alpha version\n"
	 "0.2003-07-24 (whatever)\n"
	 "\n"
	 "Copyright (C) 2002-2003 Trevin Beattie\n"
	 "\n"
	 "This is Free software.  You may modify\n"
	 "and/or redistribute it as you wish, within\n"
	 "the terms of the Gnu Public License (GPL).\n"
	 "See the file named \"COPYING\" for details.\n");
      XtSetArg (args[4], XmNmessageString, message);
      XtSetArg (args[5], XmNnoResize, True);
      dialog = XmCreateInformationDialog (w, "About", args, 6);
      XmStringFree (title);
      XmStringFree (message);
      XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON));
      XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));
      /* Set the dialog to pop down automatically when closed;
	 don't destroy it, because we can use it again later. */
      XtVaSetValues (XtParent (dialog), XmNdeleteResponse, XmUNMAP, NULL);
    }
  XtManageChild (dialog);
  XtPopup (XtParent (dialog), XtGrabNone);
}

void
ui_help_contents (Widget w, XtPointer client_data, XtPointer call_data)
{
  puts ("Stub function ui_help_contents called.");
}


/* Verify that the input conforms to a Diablo II character name. */
void
ui_char_name_verify (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmTextVerifyCallbackStruct *verify
    = (XmTextVerifyCallbackStruct *) call_data;
  int len, has_dash = 0;
  char *old_text;

  if (options.character.link.freeform)
    /* No validation is done in freeform mode */
    return;

  /* Make sure all new characters are alphabetic or a dash. */
  for (len = 0; len < verify->text->length; len++)
    {
      if (((verify->text->ptr[len] == '-')
	   || (verify->text->ptr[len] == '_'))
	  && !has_dash)
	{
	  has_dash++;
	  continue;
	}
      if (!isalpha (verify->text->ptr[len]))
	{
	  verify->doit = False;
	  return;
	}
    }

  /* Count the number of dashes.  There can be only one. */
  old_text = XmTextFieldGetString (w);
  for (len = 0; len < verify->startPos; len++)
    {
      if ((old_text[len] == '-') || (old_text[len] == '_'))
	has_dash++;
    }
  for (len = verify->endPos; old_text[len]; len++)
    {
      if ((old_text[len] == '-') || (old_text[len] == '_'))
	has_dash++;
    }
  if (has_dash > 1)
    {
      XtFree (old_text);
      verify->doit = False;
      return;
    }

  /* The first character must not be a dash.
     Neither should the last character, but we can't verify that
     until the user has typed in the whole thing. */
  if ((verify->startPos == 0) && verify->text->length
      && !isalpha (verify->text->ptr[0]))
    {
      XtFree (old_text);
      verify->doit = False;
      return;
    }
  if (((verify->endPos + verify->text->length >= 15) && verify->text->length
       && !isalpha (verify->text->ptr[verify->text->length - 1]))
      || ((verify->endPos < len) && (len + verify->text->length >= 15)
	  && !isalpha (old_text[len - 1])))
    {
      XtFree (old_text);
      verify->doit = False;
      return;
    }

  XtFree (old_text);
  return;
}

/* If the input conforms to a Diablo II character name,
   enable the OK button. */
void
ui_char_name_possible (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget button_ok = (Widget) client_data;
  int len, end_dash, valid;
  char *text;

  /* Get the current name entry */
  text = XmTextFieldGetString (w);
  len = strlen (text);
  end_dash = !isalpha (text[0]) || !isalpha (text[len - 1]);

  /* If the name looks good (or rather will look good) as it stands,
     enable the OK button.  Otherwise disable it. */
  valid = (options.character.link.freeform ? ((len >= 1) && (len <= 15))
	   : (!end_dash && (len >= 2) && (len <= 15)));
  XtSetSensitive (button_ok, valid);
}

/* Verify that the input is numeric in nature. */
void
ui_numeric_verify (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmTextVerifyCallbackStruct *verify
    = (XmTextVerifyCallbackStruct *) call_data;
  int len;

  /* Make sure all new characters are digits. */
  for (len = 0; len < verify->text->length; len++)
    {
      if (!isdigit (verify->text->ptr[len]))
	{
	  verify->doit = False;
	  return;
	}
    }
}

/* Like the above, but allow a negative sign in front of the number. */
void
ui_snumeric_verify (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmTextVerifyCallbackStruct *verify
    = (XmTextVerifyCallbackStruct *) call_data;
  int len, ch0;
  char *old_text;

  /* Make sure all new characters are digits. */
  for (len = 0; len < verify->text->length; len++)
    {
      if (!isdigit (verify->text->ptr[len]))
	{
	  /* ... except the first, which may be a '-'. */
	  if (!len && !verify->startPos && (verify->text->ptr[len] == '-'))
	    {
	      /* ... unless we are inserting, and there is already a '-' */
	      if (verify->endPos)
		continue;
	      old_text = XmTextFieldGetString (w);
	      ch0 = old_text[0];
	      XtFree (old_text);
	      if (!ch0 || isdigit (ch0))
		continue;
	    }
	  verify->doit = False;
	  return;
	}
    }
}

/* Like the above, but allow a single decimal point in the text field */
void
ui_fpnumeric_verify (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmTextVerifyCallbackStruct *verify
    = (XmTextVerifyCallbackStruct *) call_data;
  int len, dps = 0;
  char *old_text;

  /* Make sure all new characters are digits or a decimal. */
  for (len = 0; len < verify->text->length; len++)
    {
      if ((verify->text->ptr[len] == '.') && !dps)
	{
	  dps++;
	  continue;
	}
      if (!isdigit (verify->text->ptr[len]))
	{
	  verify->doit = False;
	  return;
	}
    }

  /* Make sure there is only one decimal point
     in the entire (revised) field. */
  old_text = XmTextFieldGetString (w);
  for (len = 0; len < verify->startPos; len++)
    {
      if (old_text[len] == '.')
	dps++;
    }
  for (len = verify->endPos; old_text[len]; len++)
    {
      if (old_text[len] == '.')
	dps++;
    }
  XtFree (old_text);
  if (dps > 1)
    verify->doit = False;
  return;
}

/* Verify hexadecimal input.  The first two characters are required
   to be "0x".  The rest are the hex number. */
void
ui_hexnumeric_verify (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmTextVerifyCallbackStruct *verify
    = (XmTextVerifyCallbackStruct *) call_data;
  int len;

  /* No editing may be done before the 2nd character */
  if ((verify->startPos < 2)
      && (verify->startPos || (verify->text->length < 2)
	  || (verify->text->ptr[0] != '0') || (verify->text->ptr[1] != 'x')))
    {
      verify->doit = False;
      return;
    }

  /* Make sure all new characters are hex digits. */
  for (len = 0; len < verify->text->length; len++)
    {
      if (verify->startPos + len < 2)
	continue;
      if (!isxdigit (verify->text->ptr[len]))
	{
	  verify->doit = False;
	  return;
	}
    }
}

/* Verify hexadecimal input.  Unlike other text fields,
   we don't insert or delete characters; we only overwrite. */
void
ui_hex_short_verify (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmTextVerifyCallbackStruct *verify
    = (XmTextVerifyCallbackStruct *) call_data;
  int len;
  char *old_text;

  /* The problem with this callback is that it is called both by
     user input and by program modification of the field value.
     There is no direct way of telling the difference.  So we
     implement a universal policy: the first four characters
     must be in hex, and the rest of the field may be modified
     only if the entire field is being replaced at once. */
  for (len = 0;
       (len < verify->text->length) && (verify->startPos + len < 4); len++)
    {
      if (!isxdigit (verify->text->ptr[len]))
	{
	  verify->doit = False;
	  return;
	}
    }

  old_text = XmTextFieldGetString (w);
  len = strlen (old_text);
  if ((verify->startPos == 0) && (verify->endPos == len)
      && (verify->text->length >= 4))
    {
      /* Replacing the entire string; must be an internal call.
	 Even if it isn't, the first four characters are in hex,
	 so why complain? */
      return;
    }

  if (verify->startPos + verify->text->length > 4)
    {
      /* Trying to modify part of the non-hex segment */
      verify->doit = False;
      return;
    }

  /* If we're replacing part of the string, make sure the length of
     the text being replaced equals the length of the replacement
     text.  We don't insert or delete digits here. */
  verify->endPos = verify->startPos + verify->text->length;
  /* Hope that takes care of all scenarios... */
  return;
}
