/* Function prototypes for callbacks referenced by the interface.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef CALLBACKS_H
#define CALLBACKS_H

#ifndef __BEGIN_DECLS
/* Use these in header files to tell C++ that
 * data types and functions are in standard C. */
# ifdef __cplusplus
#  define __BEGIN_DECLS  extern "C" {
#  define __END_DECLS    }
# else /* C */
#  define __BEGIN_DECLS
#  define __END_DECLS
# endif /* C */
#endif /* __BEGIN_DECLS */

__BEGIN_DECLS
/* This function registers the callbacks */
int register_callbacks (void);

/* This function is called to open files from the command line */
void cl_file_open (const char *);

/* All callbacks use the same parameters */
#define CB_PARAMS Widget, XtPointer, XtPointer

/* The callback functions.  This list must be duplicated in the
   corresponding callbacks.c file. */
void ui_window_close (CB_PARAMS);
void ui_file_new (CB_PARAMS);
void ui_file_open (CB_PARAMS);
void ui_file_save (CB_PARAMS);
void ui_file_save_as (CB_PARAMS);
void ui_file_import_item (CB_PARAMS);
void ui_file_export_item (CB_PARAMS);
void ui_file_load_item_set (CB_PARAMS);
void ui_file_save_item_set (CB_PARAMS);
void ui_file_close (CB_PARAMS);
void ui_file_exit (CB_PARAMS);
void ui_edit_cut (CB_PARAMS);
void ui_edit_copy (CB_PARAMS);
void ui_edit_paste (CB_PARAMS);
void ui_edit_item_editor (CB_PARAMS);
void ui_edit_options (CB_PARAMS);
void ui_view_map_or_unmap (CB_PARAMS);
void ui_help_about (CB_PARAMS);
void ui_help_contents (CB_PARAMS);
void ui_check_dirty (CB_PARAMS);
void ui_check_copy (CB_PARAMS);
void ui_check_paste (CB_PARAMS);
void ui_popdown (CB_PARAMS);
void ui_ungrab (CB_PARAMS);
void ui_enable_cursor (CB_PARAMS);
void ui_disable_cursor (CB_PARAMS);
/* This function is called after each key is typed, but before it is
   inserted into a text field; use it to verify that the input
   conforms to a Diablo II character name. */
void ui_char_name_verify (CB_PARAMS);
void ui_char_name_possible (CB_PARAMS);
/* This function is called after each key is typed, but before it is
   inserted into a text field; use it to verify that the input is
   numeric in nature. */
void ui_numeric_verify (CB_PARAMS);
void ui_snumeric_verify (CB_PARAMS);
void ui_fpnumeric_verify (CB_PARAMS);
void ui_hexnumeric_verify (CB_PARAMS);
void ui_hex_short_verify (CB_PARAMS);
void ui_stat_changed_name (CB_PARAMS);
void ui_stat_changed_title (CB_PARAMS);
void ui_stat_changed_level (CB_PARAMS);
void ui_stat_changed_experience (CB_PARAMS);
void ui_toggle_expansion (CB_PARAMS);
void ui_toggle_hardcore (CB_PARAMS);
void ui_toggle_death (CB_PARAMS);
void ui_stat_changed_strength (CB_PARAMS);
void ui_stat_add_strength (CB_PARAMS);
void ui_stat_changed_energy (CB_PARAMS);
void ui_stat_add_energy (CB_PARAMS);
void ui_stat_changed_dexterity (CB_PARAMS);
void ui_stat_add_dexterity (CB_PARAMS);
void ui_stat_changed_vitality (CB_PARAMS);
void ui_stat_add_vitality (CB_PARAMS);
void ui_stat_changed_life_base (CB_PARAMS);
void ui_stat_changed_life_current (CB_PARAMS);
void ui_stat_changed_mana_base (CB_PARAMS);
void ui_stat_changed_mana_current (CB_PARAMS);
void ui_stat_changed_stamina_base (CB_PARAMS);
void ui_stat_changed_stamina_current (CB_PARAMS);
void ui_stat_changed_statp_remaining (CB_PARAMS);
void ui_stat_changed_skillp_remaining (CB_PARAMS);
void ui_stat_changed_gold_inventory (CB_PARAMS);
void ui_stat_changed_gold_stash (CB_PARAMS);
void ui_slider_sync (CB_PARAMS);
void ui_scroll_keyb_traversal (CB_PARAMS);
void ui_tab_next (CB_PARAMS);
void ui_spinbox_sync (CB_PARAMS);
void ui_spinbox_changed (CB_PARAMS);
void ui_spinbox_up (CB_PARAMS);
void ui_select_skill_set (CB_PARAMS);
void ui_set_read_only (CB_PARAMS);
void ui_show_item_popup (CB_PARAMS);
void ui_swap_corpse_inventory (CB_PARAMS);
void ui_set_act_location (CB_PARAMS);
void ui_show_actdifficulty (CB_PARAMS);
void ui_show_wpdifficulty (CB_PARAMS);
void ui_show_qstdifficulty (CB_PARAMS);
void ui_toggle_act_intro (CB_PARAMS);
void ui_toggle_npc_intro (CB_PARAMS);
void ui_toggle_act_exit (CB_PARAMS);
void ui_toggle_waypoint (CB_PARAMS);
void ui_select_quest (CB_PARAMS);
void ui_quest_changed_hex (CB_PARAMS);
void ui_toggle_hire_death (CB_PARAMS);
void ui_hire_changed_name (CB_PARAMS);
void ui_hire_changed_attribute (CB_PARAMS);
void ui_hire_changed_level (CB_PARAMS);
void ui_hire_changed_experience (CB_PARAMS);
void ui_slider_hire_sync (CB_PARAMS);
/* This is for drag-and-drop */
void ui_view_drop_site_update (CB_PARAMS);
/* These are for the item popup */
void ui_popitem_more_less (CB_PARAMS);
void ui_repair_popitem (CB_PARAMS);
void ui_edit_popitem (CB_PARAMS);
void ui_item_popup_destroyed (CB_PARAMS);
/* These are for the item editor */
void ui_item_window_close (CB_PARAMS);
void ui_check_dirty_item (CB_PARAMS);
void ui_check_socket_cut (CB_PARAMS);
void ui_check_socket_paste (CB_PARAMS);
void ui_item_create (CB_PARAMS);
void ui_item_open (CB_PARAMS);
void ui_item_save (CB_PARAMS);
void ui_item_save_as (CB_PARAMS);
void ui_item_close (CB_PARAMS);
void ui_item_copy (CB_PARAMS);
void ui_item_duplicate (CB_PARAMS);
void ui_item_cut_gem (CB_PARAMS);
void ui_item_paste (CB_PARAMS);
void ui_item_move (CB_PARAMS);
void ui_item_remove (CB_PARAMS);
void ui_item_assign (CB_PARAMS);
void ui_change_potion (CB_PARAMS);
void ui_change_gem (CB_PARAMS);
void ui_change_rune (CB_PARAMS);
void ui_item_change_fingerprint (CB_PARAMS);
void ui_item_change_level (CB_PARAMS);
void ui_item_toggle_newbie (CB_PARAMS);
void ui_item_toggle_ethereal (CB_PARAMS);
void ui_item_change_durability (CB_PARAMS);
void ui_item_change_base_durability (CB_PARAMS);
void ui_item_change_defense (CB_PARAMS);
void ui_item_change_quantity (CB_PARAMS);
void ui_edit_gem (CB_PARAMS);
void ui_move_gem_up (CB_PARAMS);
void ui_move_gem_down (CB_PARAMS);
void ui_item_add_socket (CB_PARAMS);
void ui_item_remove_socket (CB_PARAMS);
void ui_item_toggle_identified (CB_PARAMS);
void ui_item_change_owner (CB_PARAMS);
void ui_change_item_quality (CB_PARAMS);
void ui_change_magic_prefix (CB_PARAMS);
void ui_change_magic_suffix (CB_PARAMS);
void ui_change_set_item (CB_PARAMS);
void ui_change_rare_name1 (CB_PARAMS);
void ui_change_rare_name2 (CB_PARAMS);
void ui_change_rare_hidden1 (CB_PARAMS);
void ui_change_rare_hidden2 (CB_PARAMS);
void ui_change_rare_hidden3 (CB_PARAMS);
void ui_change_rare_hidden4 (CB_PARAMS);
void ui_change_rare_hidden5 (CB_PARAMS);
void ui_change_rare_hidden6 (CB_PARAMS);
void ui_change_unique_item (CB_PARAMS);
void ui_remove_names_from_dropdown (CB_PARAMS);
void ui_change_picture (CB_PARAMS);
void ui_change_property_value (CB_PARAMS);
void ui_select_property_value (CB_PARAMS);
void ui_delete_magic_property (CB_PARAMS);
void ui_item_place_select_character (CB_PARAMS);
void ui_item_place_change_area (CB_PARAMS);
void ui_new_item_create (CB_PARAMS);
void ui_new_item_filter (CB_PARAMS);
void ui_new_item_cancel (CB_PARAMS);
void ui_new_item_selected (CB_PARAMS);

/* Don't need this macro any more */
#undef CB_PARAMS

/* Action functions.  Again, must be in the callbacks.c file. */
void ui_start_drag (Widget, XEvent *, String *, Cardinal *);
void ui_start_gem_drag (Widget, XEvent *, String *, Cardinal *);
void ui_start_rune_drag (Widget, XEvent *, String *, Cardinal *);
void ui_start_potion_drag (Widget, XEvent *, String *, Cardinal *);

__END_DECLS

#endif /* CALLBACKS_H */
