/* Initialize the user interface -- Motif style.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "ui.h"
#include <Xm/AtomMgr.h>
#include <Xm/CutPaste.h>
#include <Xm/DialogS.h>
#include <Xm/MessageB.h>
#include <Xm/Protocols.h>
#include "tables.h"
#include <dmalloc.h>

/* This should be globally available to all modules. */
const char *progname;
void *stdui;
XtAppContext app_context;
Widget toplevel = NULL;
Widget *doc_shell_list = NULL;
int doc_shell_count = 0;
MrmHierarchy mrm_hierarchy;
const char *path_to_images = PATH_TO_IMAGES;
const char *path_to_uid = PATH_TO_UID;

/* Local functions */
static void ignore_warnings (String);

/* UID files for the character window.
   DO NOT include item editor UID's; widget names overlap */
static String uid_file_list[] = {
  "acts_frame", "char_window", "hireling_frame", "inventory_frame",
  "item_popup", "new_char", "quests_frame", "stats_frame",
  "skills_frame", "waypoints_frame"
};

/* Command-line options */
static XrmOptionDescRec cl_options[] = {
  { "-tables",		".tablePath",	XrmoptionSepArg, NULL },
  { "-images",		".imagePath",	XrmoptionSepArg, NULL },
  { "-uidfiles",	".uidPath",	XrmoptionSepArg, NULL },
};

/* Application resources */
static XtResource resources[] = {
  /* These macros shorten the resource entry for the many d2s options.
     Note the trick we use to avoid duplicating global variables that
     should be UI-independent; instead of a normal XtOffsetOf from
     a structure of our own, we just pass the actual address of the
     global variable and pass NULL for the phantom structure address.
     Also note that the options are designated Boolean, even though
     they are stored as ints (because the UI-independent part doesn't
     have any Xt data types).  This should work so long as Boolean
     is not wider than an int (and is little-endian). */
#define OPTION_RES(name,member) { "option" RES_INFIX #name,	\
		"Option" RES_INFIX #name, XtRBoolean, sizeof (Boolean), \
		(Cardinal) &options.STRUCT_INFIX.member, XtRImmediate,	\
		(XtPointer) False /* options.STRUCT_INFIX.member */ }
#define STRUCT_INFIX character.edit
#define RES_INFIX "CharEdit"
  OPTION_RES (ReadOnly, default_read_only),
  OPTION_RES (Name, name),
  OPTION_RES (Title, title),
  OPTION_RES (Expansion, expansion),
  OPTION_RES (Hardcore, hardcore),
  OPTION_RES (Died, died),
  OPTION_RES (UpAndDown, up_and_down),
  OPTION_RES (Experience, experience),
  OPTION_RES (Level, level),
  OPTION_RES (Stats, stats),
  OPTION_RES (Stats2, stats2),
  OPTION_RES (StatPoints, stat_points),
  OPTION_RES (Skills, skills),
  OPTION_RES (SkillPoints, skill_points),
  OPTION_RES (Gold, gold),
  OPTION_RES (ItemLocation, item_location),
  OPTION_RES (Inventory, inventory),
  OPTION_RES (CorpseInventory, corpse_inventory),
  OPTION_RES (Backward, backward),
  OPTION_RES (AllDifficulties, all_difficulties),
  OPTION_RES (Npcs, npcs),
  OPTION_RES (Acts, acts),
  OPTION_RES (ActLocation, act_location),
  OPTION_RES (Waypoints, waypoints),
  OPTION_RES (QuestsComplete, quests_complete),
  OPTION_RES (QuestsIntermediate, quests_intermediate),
  OPTION_RES (HirelingAdd, hireling_add),
  OPTION_RES (HirelingName, hireling_name),
  OPTION_RES (HirelingAttribute, hireling_attribute),
  OPTION_RES (HirelingExperience, hireling_experience),
  OPTION_RES (HirelingLevel, hireling_level),
  OPTION_RES (HirelingInventory, hireling_inventory),
#undef RES_INFIX
#undef STRUCT_INFIX
#define STRUCT_INFIX character.link
#define RES_INFIX "CharLink"
  OPTION_RES (LevelExperience, level_experience),
  OPTION_RES (LevelStats, level_stats),
  OPTION_RES (StatsPoints, stats_points),
  OPTION_RES (StatsStats2, stats_stats2),
  OPTION_RES (Stats2Base, stats2_base),
  OPTION_RES (SkillsPoints, skills_points),
  OPTION_RES (SkillsLevel, skills_level),
  OPTION_RES (SkillsSkills, skills_skills),
  OPTION_RES (AutoSkill, auto_skill),
  OPTION_RES (EquipmentLevel, equipment_level),
  OPTION_RES (EquipmentClass, equipment_class),
  OPTION_RES (ActEntry, act_entry),
  OPTION_RES (AutoAct, auto_act),
  OPTION_RES (ActQuest, act_quest),
  OPTION_RES (ActLocation, act_location),
  OPTION_RES (ActWaypoint, act_waypoint),
  OPTION_RES (QuestQuest, quest_quest),
  OPTION_RES (QuestInventory, quest_inventory),
  OPTION_RES (AutoQuest, auto_quest),
  OPTION_RES (Freeform, freeform),
#undef RES_INFIX
#undef STRUCT_INFIX
#define STRUCT_INFIX item.edit
#define RES_INFIX "ItemEdit"
  OPTION_RES (Potion, potion),
  OPTION_RES (Gem, gem),
  OPTION_RES (Identified, identified),
  OPTION_RES (Personalized, personalized),
  OPTION_RES (Newbie, newbie),
  OPTION_RES (Ethereal, ethereal),
  OPTION_RES (Quantity, quantity),
  OPTION_RES (Durability, durability),
  OPTION_RES (BaseDurability, base_durability),
  OPTION_RES (Defense, defense),
  OPTION_RES (SocketedGems, socketed_gems),
  OPTION_RES (SocketCount, socket_count),
  OPTION_RES (Fingerprint, fingerprint),
  OPTION_RES (ItemLevel, level),
  OPTION_RES (Quality, quality),
  OPTION_RES (Picture, picture),
  OPTION_RES (MagicName, magic_name),
  OPTION_RES (SetOrUnique, set_or_unique),
  OPTION_RES (MagicProperties, magic_properties),
  OPTION_RES (MagicPropertyList, magic_property_list),
#undef RES_INFIX
#undef STRUCT_INFIX
#define STRUCT_INFIX item.link
#define RES_INFIX "ItemLink"
  OPTION_RES (ItemExpansion, item_expansion),
  OPTION_RES (DurabilityEthereal, durability_ethereal),
  OPTION_RES (DurabilityBase, durability_base),
  OPTION_RES (QuantityMax, quantity_max),
  OPTION_RES (DurabilityMax, durability_max),
  OPTION_RES (DefenseMax, defense_max),
  OPTION_RES (QualityMagic, quality_magic),
  OPTION_RES (PropertiesRange, properties_range),
#undef RES_INFIX
#define RES_INFIX "Item"
  OPTION_RES (ShowPopup, show_popup),
#undef RES_INFIX
#undef STRUCT_INFIX
#undef OPTION_RES
  { "debug", "Debug", XtRInt, sizeof (int),
    (Cardinal) &debug, XtRImmediate, (XtPointer) True },
  { "tablePath", "TablePath", XtRString, sizeof (char *),
    (Cardinal) &path_to_tables, XtRString, (XtPointer) PATH_TO_TABLES },
  { "imagePath", "ImagePath", XtRString, sizeof (char *),
    (Cardinal) &path_to_images, XtRString, (XtPointer) PATH_TO_IMAGES },
  { "uidPath", "UIDPath", XtRString, sizeof (char *),
    (Cardinal) &path_to_uid, XtRString, (XtPointer) PATH_TO_UID },
};


int
main (int argc, char **argv)
{
  Cardinal	status;
  int		i;
  char		*full_path, *bitmap_path, *new_envar;

  progname = argv[0];

  XtSetLanguageProc (NULL, NULL, NULL);

  MrmInitialize ();

  /* Initialize the top level widget */
  toplevel = XtVaAppInitialize (&app_context, "d2sEdit",
				cl_options, XtNumber (cl_options),
				&argc, argv, NULL, NULL);

  /* Initialize the default option resources */
  for (i = 0; i < (int) XtNumber (resources); i++)
    if (resources[i].default_type == XtRImmediate)
      resources[i].default_addr = (XtPointer)
	*((int *) resources[i].resource_offset);
  /* Get our application-defined resources */
  XtVaGetApplicationResources (toplevel, NULL,
			       resources, XtNumber (resources),
			       NULL);

  /* Initialize the non-GUI portion of the program. */
  preload_tables ();

  /* Register a new data format for cut-and-paste operations */
  XmClipboardRegisterFormat (XtDisplay (toplevel), "DIABLO_ITEM_STRUCT", 8);

  /* Find the User Interface Definition files */
  for (i = 0; i < (int) XtNumber (uid_file_list); i++) {
    full_path = xfindfile (NULL, uid_file_list[i], ".uid", path_to_uid);
    if (full_path == NULL) {
      fprintf (stderr, "%s: Unable to locate %s UID file.\n",
	      progname, uid_file_list[i]);
      exit (1);
    }
    /* Replace the short name with the long one */
    uid_file_list[i] = full_path;
  }
  /* Not sure if this is the best way to do it, but...
     find the image files required by the UID files. */
  full_path = xfindfile (NULL, "gold", ".xpm", path_to_images);
  if (full_path == NULL) {
    fprintf (stderr, "%s: Unable to locate icons.\n", progname);
    /* This is not a fatal error, but it does cramp things up */
  }

  else {
    /* Remove the trailing "/images/gold.xpm" */
    bitmap_path = strstr (full_path, "/images/gold.xpm");
    if (bitmap_path != NULL)
      bitmap_path[0] = '\0';
    else {
      bitmap_path = strstr (full_path, "/gold.xpm");
      if (bitmap_path != NULL)
	bitmap_path[0] = '\0';
    }
    /* Append the path to the XMICONSEARCHPATH environment variable */
    bitmap_path = getenv ("XMICONSEARCHPATH");
    if (bitmap_path == NULL) {
      new_envar = (char *) xmalloc
	(sizeof ("XMICONSEARCHPATH=%s/%%B:%s/images/%%B")
	 + 2 * strlen (full_path));
      sprintf (new_envar, "XMICONSEARCHPATH=%s/%%B:%s/images/%%B",
	       full_path, full_path);
    } else {
      new_envar = (char *) xmalloc
	(sizeof ("XMICONSEARCHPATH=%s/%%B:%s/images/%%B:%s")
	 + 2 * strlen (full_path) + strlen (bitmap_path));
      sprintf (new_envar, "XMICONSEARCHPATH=%s/%%B:%s/images/%%B:%s",
	       full_path, full_path, bitmap_path);
    }
    putenv (new_envar);
    /* DO NOT free (new_envar); putenv stores this pointer, not a copy */
    free (full_path);
  }

  /* Open up the User Interface Definition files */
  status = MrmOpenHierarchyPerDisplay
    (XtDisplay (toplevel), XtNumber (uid_file_list),
     uid_file_list, NULL, &mrm_hierarchy);
  if (status != MrmSUCCESS) {
    fprintf (stderr, "%s: Unable to open UID files.\n", progname);
    exit (1);
  }

  /* Initialize our GUI environment; this make take a few seconds */
  if (debug)
    fprintf (stderr, "%s: Initializing GUI; please wait...\n", progname);
  else
    XtAppSetWarningHandler (app_context, ignore_warnings);
  ui_init_display ();
  ie_init ();

  /* Register all of our callback functions. */
  if (register_callbacks ())
    exit (1);

  /* If any files were specified on the command line, open them now. */
  for (i = 1; i < argc; i++)
    cl_file_open (argv[i]);

  /* If no files were opened, we need a blank document window
     so we at least have a menu bar. */
  if (doc_shell_count < 1)
    create_document_window ();

  XtAppMainLoop (app_context);

  /* NOT REACHED */
  return 0;
}

static void
ignore_warnings (String message)
{
  return;
}
