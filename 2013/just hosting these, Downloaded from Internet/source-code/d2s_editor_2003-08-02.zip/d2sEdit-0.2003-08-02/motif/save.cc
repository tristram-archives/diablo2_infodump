/* Save a file.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <errno.h>
#include <limits.h>
#include <unistd.h>
#include <time.h>
#include <Xm/Xm.h>
#include <Xm/FileSB.h>
#include <Xm/TextF.h>
#include "ui.h"
#include "util.h"
#include <dmalloc.h>

/* Local callbacks */
static void save_cancelled (Widget, XtPointer, XtPointer);
static void save_as_ok (Widget, XtPointer, XtPointer);
static void save_item_as_ok (Widget, XtPointer, XtPointer);

/* Remember the filter between saves */
static char *last_used_filter = NULL;
static char *last_used_item_filter = NULL;


/* Each time the File menu is posted, check whether the window's
   game data has been modified.  If so, and the data has an
   associated filename, enable the Save menu item. */
void
ui_check_dirty (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data;
  d2sData *d2sp;

  XtVaGetValues (docwindow, XmNuserData, &d2sp, NULL);
  if (d2sp == NULL)
    /* No associated file; no Save. */
    return;

  if (d2sp->needs_saving () && (d2sp->SourceFileName () != NULL))
    XtVaSetValues (XxNameToWidget (w, "menuitem_save"),
		   XmNsensitive, True,
		   NULL);
}

void
ui_check_dirty_item (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data;
  d2sItem *item;

  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if (item == NULL)
    /* No associated file; no Save. */
    return;

  if (item->needs_saving () && (item->SourceFileName () != NULL))
    XtVaSetValues (XxNameToWidget (w, "menuitem_save"),
		   XmNsensitive, True,
		   NULL);
}

void
ui_file_save (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data;
  d2sData *gamePtr;

  XtVaGetValues (docwindow, XmNuserData, &gamePtr, NULL);
  if (gamePtr == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: window %p's Save action\n"
		 " was active without an open document\n",
		 progname, docwindow);
      XtVaSetValues (w, XmNsensitive, False, NULL);
      return;
    }

  /* Attempt to save the game */
  stdui = docwindow;
  if (gamePtr->Save() < 0)
    {
      /* Error! */
      display_error ("%s: %s.",
		     ((gamePtr->SourceFileName() == NULL)
		      ? gamePtr->GetCharacterName()
		      : gamePtr->SourceFileName()),
		     gamePtr->GetErrorMessage());
    }

  /* If the character is clean, disable the Save button. */
  if (!gamePtr->needs_saving())
    XtVaSetValues
      (XxNameToWidget (docwindow, "*menubar_char*menuitem_save"),
       XmNsensitive, False,
       NULL);
}

void
ui_item_save (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data;
  d2sItem *item;

  printf ("Function ui_item_save called by %s\n", XtName (w));

  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: window %p's Save action\n"
		 " was active without an open document\n",
		 progname, docwindow);
      XtVaSetValues (w, XmNsensitive, False, NULL);
      return;
    }

  /* Attempt to save the item */
  stdui = docwindow;
  if (item->Save() < 0)
    {
      /* Error! */
      display_error ("%s: %s.",
		     ((item->SourceFileName() == NULL)
		      ? item->Name()
		      : item->SourceFileName()),
		     item->GetErrorMessage());
    }

  /* If the character is clean, disable the Save button. */
  if (!item->needs_saving())
    XtVaSetValues
      (XxNameToWidget (docwindow, "*menubar_item*menuitem_save"),
       XmNsensitive, False,
       NULL);
}

static Widget
create_save_as_dialog (Widget docwindow)
{
  Widget	svdialog;
  Dimension	high, wide;
  Position	x, y;
  XmString	xmstr;

  svdialog = XmCreateFileSelectionDialog
    (docwindow, "file_save_dialog", NULL, 0);
  if (svdialog == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Unable to create file save dialog.\n", progname);
      return NULL;
    }

  /* Try to position the dialog centered on the parent shell. */
  XtVaGetValues (XtParent (docwindow),
		 XmNheight, &high,
		 XmNwidth, &wide,
		 NULL);
  /* Assume the dialog's size is about 400x370.  Doesn't need to be exact. */
  XtTranslateCoords (XtParent (docwindow),
		     (wide - 400) / 2, (high - 370) / 2,
		     &x, &y);

  /* Change the label of the "OK" button to "Save" */
  xmstr = XmStringCreateLocalized ("Save");
  XtVaSetValues (svdialog,
		 /* Wish there were a way to make this modal only
		    for the top-level shell that this belongs to,
		    but there isn't. */
		 XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL,
		 XmNokLabelString, xmstr,
		 XmNtextColumns, 60,
		 NULL);
  XmStringFree (xmstr);
  XtVaSetValues (XtParent (svdialog),
		 XmNdeleteResponse, XmDESTROY,
		 XmNtitle, "Save As",
		 XmNx, x,
		 XmNy, y,
		 NULL);

  /* No help is available for this function */
  XtUnmanageChild (XmFileSelectionBoxGetChild
		   (svdialog, XmDIALOG_HELP_BUTTON));

  /* Register callback functions for cancelling the dialog */
  XtAddCallback (svdialog, XmNcancelCallback, save_cancelled, docwindow);
  XtAddCallback (svdialog, XmNdestroyCallback, save_cancelled, docwindow);

  return svdialog;
}

static void
replace_filter (char *last_filter, const char *extension,
		const char *source_filename, Widget svdialog)
{
  char		*filter, *pstr, *pattern;
  int		filter_len;
  XmString	xmstr;

  if (last_filter != NULL)
    {
      filter_len = strlen (last_filter) + 1;
      filter = (char * ) XtMalloc (filter_len);
      strcpy (filter, last_filter);
    }
  else
    {
      /* Initialize the filter to the current directory */
      filter_len = 256;
      filter = XtMalloc (filter_len);
      while (getcwd (filter, filter_len - strlen (extension)) == NULL) {
	filter_len += filter_len;
	filter = XtRealloc (filter, filter_len);
      }
      strcat (filter, extension);
    }
  /* If the game has an associated path,
     replace the filter's path with the game's path. */
  if ((source_filename != NULL)
      && (strchr (source_filename, '/') != NULL))
    {
      pstr = strrchr (filter, '/');
      if (pstr == NULL)
	pstr = filter;
      else
	pstr++;
      pattern = (char *) XtMalloc (strlen (pstr) + 1);
      strcpy (pattern, pstr);
      *pstr = '\0';

      if (strlen (filter) + strlen (source_filename)
	  >= (unsigned) filter_len)
	filter = XtRealloc
	  (filter, filter_len + strlen (source_filename));
      if (source_filename[0] == '/')
	strcpy (filter, source_filename);
      else
	{
	  pstr = strrchr (filter, '/');
	  if (pstr == NULL)
	    {
	      pstr = &filter[strlen (filter)];
	      *(pstr++) = '/';
	    }
	  else
	    pstr++;
	  strcpy (pstr, source_filename);
	}
      /* Back up to the last path separator */
      pstr = strrchr (filter, '/') + 1;
      strcpy (pstr, pattern);
      XtFree (pattern);
    }
  xmstr = XmStringCreateLocalized (filter);
  XtFree (filter);
  XmFileSelectionDoSearch (svdialog, xmstr);
  XmStringFree (xmstr);
}

void
ui_file_save_as (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	svdialog;
  Widget	docwindow = (Widget) client_data;
  d2sData *	gamePtr;
  char *	init_selection;
  char *	pstr;
  XmString	xmstr;

  /* If this window already has a file selection dialog,
     don't create another. */
  if (XtNameToWidget (docwindow, "*file_save_dialog") != NULL)
    return;

  XtVaGetValues (docwindow, XmNuserData, &gamePtr, NULL);
  if (gamePtr == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: window %p's Save As action\n"
		 " was active without an open document\n",
		 progname, docwindow);
      XtVaSetValues (w, XmNsensitive, False, NULL);
      return;
    }

  /* Create the file selection dialog;
     we can have a separate dialog for each game window. */
  svdialog = create_save_as_dialog (docwindow);
  if (svdialog == NULL)
    /* (Non-fatal?) error; return without doing anything */
    return;

  /* Register callback functions for "Save As" */
  XtAddCallback (svdialog, XmNokCallback, save_as_ok, docwindow);

  /* Set the file selection filter */
  replace_filter (last_used_filter, "/*.d2s",
		  gamePtr->SourceFileName(), svdialog);

  /* Initialize the selection to the current filename
     associated with the character, or the charcter's
     name + ".d2s" if it has no filename yet. */
  if (gamePtr->SourceFileName() != NULL)
    {
      init_selection = (char *) XtMalloc
	(strlen (gamePtr->SourceFileName()) + 1);
      strcpy (init_selection, gamePtr->SourceFileName());
      /* Be sure to strip off any leading path from the name
	 (it should have been added to the filter by now) */
      pstr = strrchr (init_selection, '/');
      if (pstr != NULL)
	memmove (init_selection, pstr + 1, strlen (pstr));
    }
  else
    {
      init_selection = (char *) XtMalloc
	(strlen (gamePtr->GetCharacterName()) + sizeof (".d2s") + 1);
      strcpy (init_selection, gamePtr->GetCharacterName());
      strcat (init_selection, ".d2s");
    }
  xmstr = XmStringCreateLocalized (init_selection);
  XtVaSetValues (svdialog,
		 XmNtextString, xmstr,
		 NULL);
  XmStringFree (xmstr);
  XtFree (init_selection);

  /* Manage the dialog */
  XtManageChild (svdialog);
  /* Go back to event processing; one of the following functions will
     be called when the dialog is closed. */
}

/* User has changed his mind; just dismiss the dialog. */
static void
save_cancelled (Widget svdialog, XtPointer client_data, XtPointer call_data)
{
  XtRemoveAllCallbacks (svdialog, XmNdestroyCallback);
  XtDestroyWidget (XtParent (svdialog));
}

static void
save_as_ok (Widget svdialog, XtPointer client_data, XtPointer call_data)
{
  Widget	docwindow = (Widget) client_data;
  XmFileSelectionBoxCallbackStruct *selection
    = (XmFileSelectionBoxCallbackStruct *) call_data;
  d2sData	*gamePtr;
  char		*fullpath;
  char		strbuf[160];
  const char	*cstr;
  XmString	xmstr;
  int		i;
  time_t	tt;

  fullpath = XxFileSelectionBoxGetFullPath (svdialog, False, selection);
  if (fullpath == NULL)
    return;

  /* Save the filter for next time */
  if (last_used_filter != NULL)
    XtFree (last_used_filter);
  if (!XmStringGetLtoR (selection->mask,
			XmFONTLIST_DEFAULT_TAG, &last_used_filter)) {
    if (debug)
      fprintf (stderr, "%s %s:%d: XmStringGetLtoR() failed.\n",
	       progname, __FILE__, __LINE__);
    last_used_filter = NULL;
  }

  /* We're done with the Save As dialog,
     whether saving the game succeeds or not. */
  XtDestroyWidget (XtParent (svdialog));

  /* Attempt to save the game */
  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &gamePtr, NULL);
  if (gamePtr->SaveAs (fullpath) < 0)
    {
      /* Error! */
      display_error ("%s: %s.", fullpath, gamePtr->GetErrorMessage());
    }
  /* If the character is clean, disable the Save button. */
  else if (!gamePtr->needs_saving())
    {
      XtVaSetValues
	(XxNameToWidget (docwindow,
			 "menubar_char*menupulldown_file.menuitem_save"),
	 XmNsensitive, False,
	 NULL);

      /* Update the status bar */
      cstr = gamePtr->GetCharacterTitle ();
      i = snprintf (strbuf, sizeof (strbuf), "%sharacter data for the %s '",
		    gamePtr->is_expansion() ? "Expansion Set c" : "C",
		    gamePtr->GetCharacterClassName ());
      if (*cstr)
	i += snprintf (&strbuf[i], sizeof (strbuf) - i, "%s %s",
		       cstr, gamePtr->GetCharacterName ());
      else
	i += snprintf (&strbuf[i], sizeof (strbuf) - i, "%s",
		       gamePtr->GetCharacterName ());
      tt = (time_t) gamePtr->GetTimestamp ();
      i += snprintf (&strbuf[i], sizeof (strbuf) - i,
		     "', saved %s", ctime (&tt));
      /* Be sure to remove the trailing NL from the time field */
      strbuf[--i] = '\0';
      XmTextFieldSetString (XxNameToWidget (docwindow, "status_bar"), strbuf);

      /* Update the window title */
      i = strlen (fullpath);
      if (i < (int) (sizeof (strbuf) - sizeof ("d2sEdit - ") - 1))
	sprintf (strbuf, "d2sEdit - %s", fullpath);
      else
	sprintf (strbuf, "d2sEdit - ... %s",
		 &fullpath[(3 * (sizeof (strbuf) - sizeof ("d2sEdit - ") - 1)
			    / 2)]);
      xmstr = XmStringCreateLocalized (strbuf);
      XtVaSetValues (docwindow, XmNdialogTitle, xmstr, NULL);
      XmStringFree (xmstr);
    }

  XtFree (fullpath);
}

void
ui_item_save_as (Widget w, XtPointer client_data, XtPointer call_data)
{
  Widget	svdialog;
  Widget	docwindow = (Widget) client_data;
  d2sItem *	item;
  char *	init_selection;
  char *	pstr;
  XmString	xmstr;

  /* If this window already has a file selection dialog,
     don't create another. */
  if (XtNameToWidget (docwindow, "*file_save_dialog") != NULL)
    return;

  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if (item == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: window %p's Save As action\n"
		 " was active without an open document\n",
		 progname, docwindow);
      XtVaSetValues (w, XmNsensitive, False, NULL);
      return;
    }

  /* Create the file selection dialog;
     we can have a separate dialog for each game window. */
  svdialog = create_save_as_dialog (docwindow);
  if (svdialog == NULL)
    /* (Non-fatal?) error; return without doing anything */
    return;

  /* Register callback functions for "Save As" */
  XtAddCallback (svdialog, XmNokCallback, save_item_as_ok, docwindow);

  /* Set the file selection filter */
  replace_filter (last_used_item_filter, "/*.d2i",
		  item->SourceFileName(), svdialog);

  /* Initialize the selection to the current filename
     associated with the item, or the item's
     full name + ".d2i" if it has no filename yet. */
  if (item->SourceFileName() != NULL)
    {
      init_selection = (char *) XtMalloc
	(strlen (item->SourceFileName()) + 1);
      strcpy (init_selection, item->SourceFileName());
      /* Be sure to strip off any leading path from the name
	 (it should have been added to the filter by now) */
      pstr = strrchr (init_selection, '/');
      if (pstr != NULL)
	memmove (init_selection, pstr + 1, strlen (pstr));
    }
  else
    {
      const char *name_str;
      if (item->Type() >= EXTENDED_ITEM)
	name_str = ((d2sExtendedItem *) *item)->FullName();
      else
	name_str = item->Name();
      init_selection = (char *) XtMalloc
	(strlen (name_str) + sizeof (".d2i") + 1);
      strcpy (init_selection, name_str);
      strcat (init_selection, ".d2i");
    }
  xmstr = XmStringCreateLocalized (init_selection);
  XtVaSetValues (svdialog,
		 XmNtextString, xmstr,
		 NULL);
  XmStringFree (xmstr);
  XtFree (init_selection);

  /* Manage the dialog */
  XtManageChild (svdialog);
  /* Go back to event processing; either save_cancelled or
     the following function will be called when the dialog is closed. */
}

static void
save_item_as_ok (Widget svdialog, XtPointer client_data, XtPointer call_data)
{
  Widget docwindow = (Widget) client_data;
  XmFileSelectionBoxCallbackStruct *selection
    = (XmFileSelectionBoxCallbackStruct *) call_data;
  d2sItem *item;
  char *fullpath;

  fullpath = XxFileSelectionBoxGetFullPath (svdialog, False, selection);
  if (fullpath == NULL)
    return;

  /* Save the filter for next time */
  if (last_used_item_filter != NULL)
    XtFree (last_used_item_filter);
  if (!XmStringGetLtoR (selection->mask,
			XmFONTLIST_DEFAULT_TAG, &last_used_item_filter)) {
    if (debug)
      fprintf (stderr, "%s %s:%d: XmStringGetLtoR() failed.\n",
	       progname, __FILE__, __LINE__);
    last_used_item_filter = NULL;
  }

  /* We're done with the Save As dialog,
     whether saving the item succeeds or not. */
  XtDestroyWidget (XtParent (svdialog));

  /* Attempt to save the item */
  stdui = docwindow;
  XtVaGetValues (docwindow, XmNuserData, &item, NULL);
  if (item->SaveAs (fullpath) < 0)
    {
      /* Error! */
      display_error ("%s: %s.", fullpath, item->GetErrorMessage());
    }
  /* If the item is clean, disable the Save button. */
  else if (!item->needs_saving())
    {
      XtVaSetValues
	(XxNameToWidget (docwindow,
			 "menubar_item*menupulldown_file.menuitem_save"),
	 XmNsensitive, False,
	 NULL);
      if (item->Owner() == NULL)
	/* Update the window title */
	update_item_window_title (docwindow, item);
    }

  XtFree (fullpath);
}
