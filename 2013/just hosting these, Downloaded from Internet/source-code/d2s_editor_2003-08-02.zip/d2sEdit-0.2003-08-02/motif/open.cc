/* Open a file and place its contents in the GUI.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/stat.h>
#include <unistd.h>
#include "ui.h"
#include <Xm/AtomMgr.h>
#include <Xm/FileSB.h>
#include <Xm/Protocols.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <dmalloc.h>

/* Local callbacks */
static void create_new_file (Widget, XtPointer, XtPointer);
static void check_for_expansion_required (Widget, XtPointer, XtPointer);
static void enforce_expansion (Widget, XtPointer, XtPointer);
static void cancel_dialog (Widget, XtPointer, XtPointer);
static void dialog_cancelled (Widget, XtPointer, XtPointer);
static void display_open_dialog (Widget parent, const char *title,
				 const char *filter, const char *pattern,
				 XtCallbackProc);
static void open_ok (Widget, XtPointer, XtPointer);
static void place_document_in_window (d2sData *, Widget);
static void configure_size (Widget shell, XtPointer client_data,
			    XEvent *event, Boolean *ctdr);
static void open_item_ok (Widget, XtPointer, XtPointer);

static Widget new_dialog = NULL;
static Widget open_dialog = NULL;

/* Remember the New dialog's last picked character class between saves */
static int last_chosen_char_class = AMAZON_CLASS;
static Boolean last_expansion_toggle_state = False;
/* Remember the Open dialog's filter between saves */
static char *last_used_filter = NULL;
static char *last_used_item_filter = NULL;


void
ui_file_new (Widget w, XtPointer client_data, XtPointer call_data)
{
  Dimension	high, wide;
  Position	x, y;
  Widget	new_shell, parent_window;
  MrmType	class_code;
  XmString	xmstr;
  int		status;

  if (new_dialog != NULL)
    return;

  for (parent_window = w; ((XtParent (parent_window) != NULL)
			   && !XtIsTopLevelShell (XtParent (parent_window)));
       parent_window = XtParent (parent_window));

  /* Create the character creation dialog. */
  new_shell = XtVaCreatePopupShell
    ("newCharacterDialog", transientShellWidgetClass, parent_window, NULL);
  status = MrmFetchWidget (mrm_hierarchy, "form_new_char", new_shell,
			   &new_dialog, &class_code);
  if (status != MrmSUCCESS)
    {
      if (debug)
	fprintf (stderr, "%s: Unable to create interface form_new_char"
		 " from UID file\n", progname);
      XtDestroyWidget (new_shell);
      return;
    }

  if (class_icons[last_chosen_char_class] == XmUNSPECIFIED_PIXMAP)
    {
      xmstr = XmStringCreateLocalized ("no image\navailable");
      XtVaSetValues (XxNameToWidget (new_dialog, "*picture_new_class"),
		     XmNlabelString, xmstr,
		     XmNlabelType, XmPIXMAP,
		     NULL);
      XmStringFree (xmstr);
    }
  else
    XtVaSetValues (XxNameToWidget (new_dialog, "*picture_new_class"),
		   XmNlabelPixmap, class_icons[last_chosen_char_class],
		   XmNlabelType, XmPIXMAP,
		   NULL);

  XtVaSetValues (XxNameToWidget (new_dialog, "*combo_new_class"),
		 XmNselectedPosition, last_chosen_char_class,
		 NULL);
  XmToggleButtonSetState (XxNameToWidget (new_dialog, "*toggle_new_expansion"),
			  last_expansion_toggle_state, False);

  /* Assign the callback for the Create and Cancel buttons */
  XtAddCallback (XxNameToWidget (new_dialog, "*button_new_create"),
		 XmNactivateCallback, create_new_file, NULL);
  XtAddCallback (XxNameToWidget (new_dialog, "*button_new_cancel"),
		 XmNactivateCallback, cancel_dialog, new_dialog);
  XtAddCallback (new_dialog, XmNdestroyCallback,
		 dialog_cancelled, &new_dialog);
  /* Also assign statically-defined callbacks for other items */
  XtAddCallback (XxNameToWidget (new_dialog, "*combo_new_class"),
		 XmNselectionCallback, check_for_expansion_required, NULL);
  XtAddCallback (XxNameToWidget (new_dialog, "*toggle_new_expansion"),
		 XmNvalueChangedCallback, enforce_expansion, NULL);

  /* Try to position the dialog centered on the parent shell. */
  XtVaGetValues (XtParent (parent_window),
		 XmNheight, &high,
		 XmNwidth, &wide,
		 XmNx, &x,
		 XmNy, &y,
		 NULL);
  /* Assume the dialog's size is about 164x194.  Doesn't need to be exact. */
  x += (wide - 164) / 2;
  y += (high - 194) / 2;

  /* Show the popup box. */
  XtManageChild (new_dialog);
  XtRealizeWidget (new_shell);
  XtVaSetValues (new_shell,
		 XmNx, x,
		 XmNy, y,
		 NULL);
  XtPopup (new_shell, XtGrabNone);
}

/* If the user has chosen an Expansion Set character class,
   set the Expansion toggle to True. */
static void
check_for_expansion_required (Widget w, XtPointer client_data,
			      XtPointer call_data)
{
  XmComboBoxCallbackStruct *combo_state
    = (XmComboBoxCallbackStruct *) call_data;
  static Boolean save_toggle_state = False;
  static Boolean toggle_state_saved = False;
  XmString xmstr;

  /* Update the class icon */
  if (class_icons[combo_state->item_position] == XmUNSPECIFIED_PIXMAP)
    {
      xmstr = XmStringCreateLocalized ("no image\navailable");
      XtVaSetValues (XxNameToWidget (new_dialog, "*picture_new_class"),
		     XmNlabelString, xmstr,
		     XmNlabelType, XmPIXMAP,
		     NULL);
      XmStringFree (xmstr);
    }
  else
    XtVaSetValues (XxNameToWidget (new_dialog, "*picture_new_class"),
		   XmNlabelPixmap, class_icons[combo_state->item_position],
		   XmNlabelType, XmPIXMAP,
		   NULL);

  if ((combo_state->item_position >= DRUID_CLASS) && !toggle_state_saved)
    {
      save_toggle_state = XmToggleButtonGetState
	(XxNameToWidget (new_dialog, "*toggle_new_expansion"));
      toggle_state_saved = True;
      XmToggleButtonSetState
	(XxNameToWidget (new_dialog, "*toggle_new_expansion"),
	 True, False);
    }
  else if ((combo_state->item_position < DRUID_CLASS) && toggle_state_saved)
    {
      XmToggleButtonSetState
	(XxNameToWidget (new_dialog, "*toggle_new_expansion"),
	 save_toggle_state, False);
      toggle_state_saved = False;
    }
}

/* If an Expansion Set character class is selected,
   don't allow changing the Expansion toggle.
   Note that we don't make the toggle insensitive,
   because that would obscure the text. */
static void
enforce_expansion (Widget w, XtPointer client_data, XtPointer call_data)
{
  XmToggleButtonCallbackStruct *toggle_state
    = (XmToggleButtonCallbackStruct *) call_data;
  int current_class;

  if (options.character.link.freeform)
    return;

  XtVaGetValues (XxNameToWidget (new_dialog, "*combo_new_class"),
		 XmNselectedPosition, &current_class,
		 NULL);

  if ((current_class >= DRUID_CLASS) && !toggle_state->set)
    XmToggleButtonSetState (w, True, False);
}

/* User has changed his mind; just dismiss the dialog. */
static void
cancel_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
  /* The dialog is only used once per call,
     since the shell's parent may die at any time. */
  XtDestroyWidget (XtParent ((Widget) client_data));
}

static void
dialog_cancelled (Widget w, XtPointer client_data, XtPointer call_data)
{
  *((Widget *) client_data) = NULL;
}

static void
create_new_file (Widget w, XtPointer client_data, XtPointer call_data)
{
  char *	new_name;
  int		expansion, hardcore;
  d2sData *	newGame;
  Widget	docwindow;

  XtVaGetValues (XxNameToWidget (new_dialog, "*combo_new_class"),
		 XmNselectedPosition, &last_chosen_char_class,
		 NULL);
  new_name = XmTextFieldGetString (XxNameToWidget
				   (new_dialog, "*field_new_name"));
  expansion = XmToggleButtonGetState (XxNameToWidget
				      (new_dialog, "*toggle_new_expansion"));
  hardcore = XmToggleButtonGetState (XxNameToWidget
				     (new_dialog, "*toggle_new_hardcore"));

  /* Get a document window for the character */
  docwindow = create_document_window ();
  if (docwindow == NULL)
    goto out;
  stdui = docwindow;

  /* Create the character */
  newGame = new d2sData (last_chosen_char_class, new_name,
			 expansion, hardcore);
  if (newGame->GetErrorMessage() != NULL)
    {
      display_error ("Unable to create \"%s\"; %s.",
		     new_name, newGame->GetErrorMessage());
      if (doc_shell_count > 1)
	ui_window_close (w, docwindow, call_data);
      delete newGame;
      goto out;
    }

  /* Display the game data. */
  place_document_in_window (newGame, docwindow);

 out:
  XtFree (new_name);
  XtDestroyWidget (XtParent (new_dialog));
  stdui = NULL;
}

void
ui_file_open (Widget w, XtPointer client_data, XtPointer call_data)
{
  display_open_dialog (w, "Open Character",
		       last_used_filter, "*.d2s",
		       open_ok);
}

static void
display_open_dialog (Widget parent, const char *title,
		     const char *last_filter, const char *pattern,
		     XtCallbackProc ok_callback)
{
  Dimension	high, wide;
  Position	x, y;
  char *	filter;
  int		filter_len;
  XmString	xmtitlestr, xmokstr, xmfilterstr;

  if (open_dialog != NULL)
    return;

  while ((XtParent (parent) != NULL)
	 && !XtIsTopLevelShell (XtParent (parent)))
    parent = XtParent (parent);

  /* Create the file selection dialog. */
  open_dialog = XmCreateFileSelectionDialog
    (parent, "file_open_dialog", NULL, 0);
  if (open_dialog == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Unable to create a file selection dialog.\n",
		 progname);
      return;
    }

  /* Try to position the dialog centered on the parent shell. */
  XtVaGetValues (XtParent (parent),
		 XmNheight, &high,
		 XmNwidth, &wide,
		 XmNx, &x,
		 XmNy, &y,
		 NULL);
  /* Assume the dialog's size is about 400x370.  Doesn't need to be exact. */
  x += (wide - 400) / 2;
  y += (high - 370) / 2;

  /* Change the label of the "OK" button to "Open" */
  xmokstr = XmStringCreateLocalized ((char *) "Open");
  xmtitlestr = XmStringCreateLocalized ((char *) title);
  XtVaSetValues (open_dialog,
		 XmNmustMatch, True,
		 XmNokLabelString, xmokstr,
		 XmNtextColumns, 60,
		 XmNdialogTitle, xmtitlestr,
		 NULL);
  XmStringFree (xmtitlestr);
  XmStringFree (xmokstr);
  XtVaSetValues (XtParent (open_dialog),
		 XmNdeleteResponse, XmDESTROY,
		 XmNx, x,
		 XmNy, y,
		 NULL);

  /* No help is available for this function */
  XtUnmanageChild (XmFileSelectionBoxGetChild
		   (open_dialog, XmDIALOG_HELP_BUTTON));

  /* Register callback functions for "Open" */
  XtAddCallback (open_dialog, XmNcancelCallback,
		 cancel_dialog, open_dialog);
  XtAddCallback (open_dialog, XmNokCallback,
		 ok_callback, NULL);
  XtAddCallback (open_dialog, XmNdestroyCallback,
		 dialog_cancelled, &open_dialog);

  /* Set the initial filter to all .d2s files in the current directory */
  if (last_filter != NULL)
    xmfilterstr = XmStringCreateLocalized ((char *) last_filter);
  else
    {
      filter_len = 256;
      filter = XtMalloc (filter_len);
      while (getcwd (filter, filter_len - strlen (pattern) - 4) == NULL) {
	filter_len += filter_len;
	filter = XtRealloc (filter, filter_len);
      }
      sprintf (&filter[strlen (filter)], "/%s", pattern);
      xmfilterstr = XmStringCreateLocalized (filter);
      XtFree (filter);
    }
  XmFileSelectionDoSearch (open_dialog, xmfilterstr);
  XmStringFree (xmfilterstr);

  /* Manage the dialog */
  XtManageChild (open_dialog);
  /* Go back to event processing; one of the following functions will
     be called when the dialog is closed. */
}

static void
open_ok (Widget opendialog, XtPointer client_data, XtPointer call_data)
{
  XmFileSelectionBoxCallbackStruct *selection
    = (XmFileSelectionBoxCallbackStruct *) call_data;
  char		*fullpath;
  Widget	docwindow;
  d2sData *	newGame;

  fullpath = XxFileSelectionBoxGetFullPath (opendialog, True, selection);
  if (fullpath == NULL)
    return;

  /* Save the filter for next time */
  if (last_used_filter != NULL)
    XtFree (last_used_filter);
  if (!XmStringGetLtoR (selection->mask,
			XmFONTLIST_DEFAULT_TAG, &last_used_filter)) {
    if (debug)
      fprintf (stderr, "%s %s:%d: XmStringGetLtoR() failed.\n",
	       progname, __FILE__, __LINE__);
    last_used_filter = NULL;
  }

  /* Get a document window for the character */
  docwindow = create_document_window ();
  if (docwindow != NULL)
    {
      stdui = docwindow;

      /* Open the character file */
      newGame = new d2sData (fullpath);
      /* The problem with C++ constructors is that they don't have a
	 way to indicate failure to initialize.  So we check to see
	 whether the associated file name is NULL. */
      if (newGame->SourceFileName () == NULL)
	{
	  display_error ("Unable to open %s; %s.\n",
			 fullpath, newGame->GetErrorMessage());
	  if (doc_shell_count > 1)
	    ui_window_close (opendialog, docwindow, call_data);
	  delete newGame;
	}
      /* Successfully opened up a game!  Now we must display the game data. */
      else
	place_document_in_window (newGame, docwindow);
    }

  XtDestroyWidget (XtParent (opendialog));
  stdui = NULL;
  XtFree (fullpath);
}

/* Open a file from the command line */
void
cl_file_open (const char *fullpath)
{
  struct stat	stbuf;
  int		fd;
  union {
    uint8_t	buffer[8];
    uint32_t	magic;
  }		small;
  d2sData *	newGame;
  d2sItem *	newItem;
  Widget	docwindow;

  /* Make sure the file exists */
  if (access (fullpath, R_OK)) {
    fprintf (stderr, "Cannot open %s; %s.\n", fullpath, strerror (errno));
    return;
  }
  if (stat (fullpath, &stbuf)) {
    fprintf (stderr, "Cannot examine %s; %s.\n", fullpath, strerror (errno));
    return;
  }

  if (!S_ISREG (stbuf.st_mode)) {
    fprintf (stderr, "%s is not a regular file.\n", fullpath);
    return;
  }

  if ((stbuf.st_size < (off_t) sizeof (struct item_header))
      || (stbuf.st_size >= 1024 * 1024)) {
    fprintf (stderr, "%s is too %s to be a valid file.\n", fullpath,
	     (stbuf.st_size < 1024) ? "small" : "large");
    return;
  }

  /* Determine whether this is a character, item, or library file.
     We could use file extensions, but file contents are more reliable,
     and we don't want to copy M$' mistake anyway. */
  fd = open (fullpath, O_RDONLY);
  if (fd < 0) {
    fprintf (stderr, "%s: Cannot open %s; %s\n",
	     progname, fullpath, strerror (errno));
    return;
  }
  read (fd, small.buffer, sizeof (small.buffer));
  close (fd);

  if (small.magic == 0xaa55aa55) {
    /* Get a document window for the character */
    docwindow = create_document_window ();
    if (docwindow == NULL)
      return;

  /* Direct any error messages to stderr */
    stdui = NULL;
    newGame = new d2sData (fullpath);
    /* The problem with C++ constructors is that they don't have a
       way to indicate failure to initialize.  So we check to see
       whether the associated file name is NULL. */
    if (newGame->SourceFileName () == NULL)
      {
	fprintf (stderr, "%s: Cannot open %s; %s\n",
		 progname, fullpath, newGame->GetErrorMessage());
	if (doc_shell_count > 1)
	  ui_window_close (docwindow, docwindow,
			   NULL /* I sure hope this isn't referenced! */);
	delete newGame;
	return;
      }

    /* Successfully opened up a game!  Now we must display the game data. */
    place_document_in_window (newGame, docwindow);
    return;
  }

  if ((small.buffer[0] == 'J') && (small.buffer[1] == 'M')) {
    if ((small.buffer[4] == 'J') && (small.buffer[5] == 'M')) {
      fprintf (stderr, "%s: Sorry, loading item libraries is"
	       " not implemented at this time.\n", progname);
      return;
    }

    /* Get a document window for the item */
    docwindow = open_item_editor_window (NULL);
    if (docwindow == NULL)
      return;

    /* Open the item file */
    newItem = ReadItemFile (fullpath);
    if (newItem == NULL) {
      fprintf (stderr, "%s: Cannot open %s; %s\n",
	       progname, fullpath, newItem->GetErrorMessage());
      ui_item_window_close (docwindow, docwindow,
			    NULL /* I sure hope this isn't referenced! */);
      return;
    }

    /* Assign the item to its window;
       the window should reconfigure itself */
    place_item_in_window (docwindow, newItem);
    return;
  }

  fprintf (stderr, "%s is not a valid Diablo II character or item file.\n",
	   fullpath);
}

/* After opening a saved game or creating a new character,
   place the game data in the given window. */
static void
place_document_in_window (d2sData *d2sp, Widget formchar)
{
  char *	window_title;
  XmString	xmwindow_title;

  /* Create a title for the window */
  if (d2sp->SourceFileName() != NULL)
    {
      window_title = XtMalloc (sizeof ("d2sEdit - ")
			       + strlen (d2sp->SourceFileName()) + 1);
      sprintf (window_title, "d2sEdit - %s", d2sp->SourceFileName());
    }
  else
    {
      window_title = XtMalloc (sizeof ("d2sEdit - ")
			       + strlen (d2sp->GetCharacterName()) + 1);
      sprintf (window_title, "d2sEdit - %s", d2sp->GetCharacterName());
    }

  /* Set the user data of the top-level shell to the game object. */
  xmwindow_title = XmStringCreateLocalized (window_title);
  XtVaSetValues (formchar,
		 XmNdialogTitle, xmwindow_title,
		 XmNuserData, d2sp,
		 NULL);
  XmStringFree (xmwindow_title);
  XtFree (window_title);
  /* ... and vice-versa */
  d2sp->SetUI (formchar);

  /* Display the game data. */
  display_d2sData (formchar, d2sp);
}

/* Create a new document window.  Use the first shell
   if it isn't already taken; otherwise create a new shell. */
Widget
create_document_window (void)
{
  d2sData *	top_level_game;
  Widget	docshell, formchar;
  MrmType	class_code;
  int		status;

  /* If the first shell already holds a game, create a new shell.
     Otherwise, use the first shell. */
  if (doc_shell_count)
    {
      formchar = XxNameToWidget (doc_shell_list[0], "form_char");
      XtVaGetValues (formchar, XmNuserData, &top_level_game, NULL);
      if (top_level_game == NULL)
	return formchar;
    }

  /* MDI time! */
  docshell = XtVaAppCreateShell ("d2sedit", "d2sEdit",
				 topLevelShellWidgetClass,
				 XtDisplay (toplevel), NULL);

  /* Add an event handler to trap the window size after it's computed. */
  XtAddEventHandler (docshell, StructureNotifyMask, False,
		     configure_size, NULL);

  /* Get another copy of the character window layout */
  status = MrmFetchWidget (mrm_hierarchy, "form_char", docshell,
			   &formchar, &class_code);
  if (status != MrmSUCCESS)
    {
      fprintf (stderr, "%s: Unable to create interface form_char"
	       " from UID file\n", progname);
      XtDestroyWidget (docshell);
      return NULL;
    }
  XtManageChild (formchar);

  /* Add this document to our document shell list */
  doc_shell_list = (Widget *)
    XtRealloc ((char *) doc_shell_list,
	       (doc_shell_count + 1) * sizeof (Widget));
  doc_shell_list[doc_shell_count++] = docshell;

  /* Set up drag and drop operations */
  register_drop_sites (formchar);

  /* Initialize the window's widgets to their default settings */
  ui_clear_d2sdata (formchar);

  /* Change the callback for the document window's close button
     so that instead of destroying the window outright
     it closes the window properly. */
  XtVaSetValues (docshell,
		 XmNdeleteResponse, XmDO_NOTHING,
		 NULL);
  XmAddWMProtocolCallback
    (docshell,
     XmInternAtom (XtDisplay (formchar), "WM_DELETE_WINDOW", False),
     ui_window_close, formchar);

  /* Process events manually until we get the size of the window */
  XtRealizeWidget (docshell);
  do {
    XtAppProcessEvent (app_context, XtIMAll);
    XtVaGetValues (docshell, XmNminWidth, &status, NULL);
  } while (status <= 0);

  return formchar;
}

static void
configure_size (Widget shell, XtPointer client_data,
		XEvent *event, Boolean *ctdr)
{
  if (event->type != ConfigureNotify)
    return;

  /* Since the forms don't look good when shrinked,
     set the top-level shell's minimum size to its current size. */
  XtVaSetValues (shell,
		 XmNminWidth, event->xconfigure.width,
		 XmNminHeight, event->xconfigure.height,
		 NULL);
  /* Our job is done. */
  XtRemoveEventHandler (shell, StructureNotifyMask, False,
			configure_size, NULL);
}

void
ui_item_open (Widget w, XtPointer client_data, XtPointer call_data)
{
  display_open_dialog (w, "Open Item",
		       last_used_item_filter, "*.d2i",
		       open_item_ok);
}

static void
open_item_ok (Widget opendialog, XtPointer client_data, XtPointer call_data)
{
  XmFileSelectionBoxCallbackStruct *selection
    = (XmFileSelectionBoxCallbackStruct *) call_data;
  char		*fullpath;
  Widget	docwindow;
  d2sItem *	newItem;
  int		old_doc_shell_count = item_doc_shell_count;

  fullpath = XxFileSelectionBoxGetFullPath (opendialog, True, selection);
  if (fullpath == NULL)
    return;

  /* Save the filter for next time */
  if (last_used_item_filter != NULL)
    XtFree (last_used_item_filter);
  if (!XmStringGetLtoR (selection->mask,
			XmFONTLIST_DEFAULT_TAG, &last_used_item_filter)) {
    if (debug)
      fprintf (stderr, "%s %s:%d: XmStringGetLtoR() failed.\n",
	       progname, __FILE__, __LINE__);
    last_used_item_filter = NULL;
  }

  /* Open a blank item window for the purpose of
     having a place to write error and warning messages */
  docwindow = open_item_editor_window (NULL);
  if (docwindow != NULL)
    {
      stdui = docwindow;

      /* Open the item file */
      newItem = ReadItemFile (fullpath);
      if (newItem == NULL)
	{
	  display_error ("Unable to open %s\n", fullpath);
	  if (item_doc_shell_count > old_doc_shell_count)
	    ui_item_window_close (opendialog, docwindow, call_data);
	}
      else
	/* Assign the item to its window;
	   the window should reconfigure itself */
	place_item_in_window (docwindow, newItem);
    }

  XtDestroyWidget (XtParent (opendialog));
  stdui = NULL;
  XtFree (fullpath);
}
