/* Non-class function declarations for the Diablo II v1.09 game editor.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdint.h>
#include "define.h"

/* This structure is created by various functions that return
   a list of ID:String pairs.  Used for generating selection lists. */
typedef struct {
  int		value;		/* Stored value for this string */
  const char *label;		/* String representing the stored value */
} _StringListEntry;
typedef struct {
  int		count;		/* Number of strings in the list */
  _StringListEntry string[0];
} _StringList, *StringList;


/* This structure is created by GetQuestValues */
struct quest_value {
  /* Value stored in the game */
  uint16_t	value;
  /* Mask used to distinguish this value from other values in the list */
  uint16_t	mask;
  /* Map of bits whose value can vary and still be considered part of
    this state.  If a value matches using the mask, but doesn't match
    when using ~dontcare, it may be an illegal value. */
  uint16_t	dontcare;
  /* If this quest state depends on items the character is carrying,
     this is the number of required items. */
  int8_t	needs_items;
  /* If this quest state depends on items the character is *not*
     carrying, this is the number of forbidden items. */
  int8_t	forbid_items;
  /* Short description of the state (for labels) */
  const char *	description;
  /* Entry in the quest log (may need line wrap) */
  const char *	log_entry;
  /* List of required items */
  char		required_items[4][4];
  /* List of forbidden items */
  char		forbidden_items[4][4];
};


#ifdef __cplusplus
extern "C" {
#endif

/* This function is like d2sData::GetCharacterClass,
   but it allows a program to get any arbitrary class name.
   Useful before creating a new character. */
const char *GetCharacterClassName (int);

/* These functions are like their counterparts in d2sData,
   except that they are independent of a saved game.
   Thus the second parameter to determine whether the caller
   wants a number for an Expansion Character or standard. */
int GetNumberOfActs (int in_expansion);
int GetNumberOfQuestsInAct (int act);
int GetNumberOfWaypointsInAct (int act);

/* Retrieve the name of a difficulty level, act, quest, or waypoint.
   These functions are truly game-independent (as long as you don't
   care whether the game is an Expansion Set), so they should only
   need to be called once at initialization. */
const char *GetDifficultyName (int);
const char *GetActName (int act);
const char *GetQuestName (int act, int quest);
const char *GetWaypointName (int act, int point);

/* Get the number of NPC's in an act.  As listed in the acts table. */
int GetNumberOfNPCsInAct (int act);
/* Get the name of the Nth NPC in an act */
const char *GetNPCName (int act, int npc);

/* Retrieve the number of possible states in a quest.  Quest states
   are a tricky thing, because often the data value stored for a quest
   can take on different meanings depending on other factors in the
   game, especially what quest items (if any) the character is
   carrying.  These functions will return all possible variants,
   because the distinction is up to the d2sData class. */
int GetNumberOfStatesInQuest (int act, int quest);
/* Retrieve a short description of a quest state,
   or the quest log entry associated with it. */
const char *GetQuestStateDesc (const char *state);
const char *GetQuestLogEntry (const char *state);
/* Return a list of known data values for a quest.
   The list is dynamically allocated, so free() when done.
   The return value is the number of entries in *pvalues. */
int GetQuestValues (int act, int quest, struct quest_value **pvalues);

/* Return the character class that owns a parcitular skill */
int CharacterClassOfSkill (int skill);
int FirstSkillOfClass (int char_class);
const char *SkillName (int skill);
/* Return the name of a skill set (0-2) for a given character class */
const char *SkillSetName (int char_class, int skill_set);
const char *SkillSetNameWithLineBreaks (int char_class, int skill_set);
/* A skill may depend on up to 2 others and have up to 2 dependents;
   all dependencies are in the same set.  These functions return -1
   if the skill has no dependency/dependent. */
int SkillDependency (int skill);
int SkillDependency2 (int skill);
int SkillDependent (int skill);
int SkillDependent2 (int skill);

/* This function is called recursively as needed
   to match a type against any superset of the type */
int IsTypeAMemberOf (const char *item_type, const char *compare_type);

/* Return a specific magic prefix or suffix by ID */
const char *GetMagicPrefix (int);
const char *GetMagicSuffix (int);

/* Return a dynamic list of strings for all of the magic prefixes/suffixes. */
StringList GetMagicPrefixes (void);
StringList GetMagicSuffixes (void);
/* Return a restricted list of magic prefixes/suffixes
   that can be applied to a given item type.
   If EXPANSION is true, include new expansion set prefixes/suffixes.
   If RARE is true, include only prefixes/suffixes approved for rare items.
   If LEVEL > 0, exclude any prefixes/suffixes whose level requirement
   is higher than LEVEL (or whose "maxlevel" is lower than LEVEL).
   The last two numbers specify name groups to exclude. */
StringList GetMagicPrefixesFor
(const char *item_type, int expansion, int rare, int level,
 int exclude1, int exclude2);
StringList GetMagicSuffixesFor
(const char *item_type, int expansion, int rare, int level,
 int exclude1, int exclude2);

/* Get a specific rate name by ID (same function for both parts) */
const char *GetRareTitleWord (int);

/* Return a dynamic list of strings for all of the rare titles. */
StringList GetRareTitle1stWords (void);
StringList GetRareTitle2ndWords (void);
/* Return a restricted list of rare titles
   that can be applied to a given item type. */
StringList GetRareTitle1stWordsFor (const char *item_type);
StringList GetRareTitle2ndWordsFor (const char *item_type);

/* Return a dynamic list of sets that contain an item of the given type. */
StringList GetSetsContainingItem (const char *code, int expansion, int level);

/* Return a dynamic list of unique items that match the given type. */
StringList GetUniqueItemsMatching (const char *code, int expansion, int level);

/* Reurn a time of day */
const char *TimeName (int time_code);

#ifdef __cplusplus
}
#endif

#endif /* FUNCTIONS_H */
