/* d2sGemOrRuneItem -- C++ intermediate class
 *		       from which gems and runes are derived.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sItem.h"
#include "d2sMagic.h"
#include "internal.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Local data: */
const char * const attachment_names[NUM_GEM_ATTACHMENTS] = {
  "Unknown", "Weapons", "Helms", "Armor", "Shields"
};

/* Initialize the d2sGemOrRuneItem part of a derived class */
d2sGemOrRuneItem::d2sGemOrRuneItem (void)
  /* Construct the base class parts first.
     Remember that since d2sInit is a virtual base class, it is
     the responsibility of our derived classes to initialize it. */
  : d2sItem (), d2sAttachItem ()
{
  int where;

  nvop = this;
  for (where = GEM_ATTACHMENT_UNKNOWN; where < NUM_GEM_ATTACHMENTS; where++)
    this->magic_properties[where] = NULL;
  gemtable_entry = NULL;
  color_code = NULL;
}

d2sGemOrRuneItem::d2sGemOrRuneItem (table_entry_t tent)
  /* Construct the base class parts first.
     d2sAttachItem does not have a table entry constructor. */
  : d2sItem (tent), d2sAttachItem ()
{
  nvop = this;
  SetItemType (tent);
}

/* Copy an existing gem or rune */
d2sGemOrRuneItem::d2sGemOrRuneItem (const d2sGemOrRuneItem &source)
  : d2sItem (source), d2sAttachItem (source)
{
  int where;

  nvop = this;
  /* Note that d2sItem::d2sItem(source) will have already copied the
     basic item fields.  Our additional fields are the magic properties,
     gem table entry, and color code. */
  for (where = GEM_ATTACHMENT_UNKNOWN; where < NUM_GEM_ATTACHMENTS; where++)
    {
      if (source.magic_properties[where] == NULL)
	this->magic_properties[where] = NULL;
      else
	this->magic_properties[where]
	  = new d2sMagic (*source.magic_properties[where]);
    }
  this->gemtable_entry = source.gemtable_entry;
  this->color_code = source.color_code;
}

/* Initialize member fields based on an item table entry */
void
d2sGemOrRuneItem::SetItemType (table_entry_t tent)
{
  int where, l, mod;
  d2sMagic *new_magic;
  char make_name[32];
  const char *code;
  int mod_param, mod_min, mod_max;

  if (tent == NULL)
    {
      gemtable_entry = NULL;
      color_code = NULL;
      return;
    }

  /* Look up the gem (or rune)'s entry in the gem table */
  gemtable_entry = LookupTableEntry ("gems", "code", item_ID.ch);

  /* Read the magic properties of a gem */
  this->magic_properties[GEM_ATTACHMENT_UNKNOWN] = NULL;
  for (where = GEM_ATTACHMENT_UNKNOWN + 1;
       where < NUM_GEM_ATTACHMENTS; where++)
    {
      new_magic = new d2sMagic ();
      switch (where) {
      case GEM_ATTACHED_WEAPON: strcpy (make_name, "weaponMod"); break;
      case GEM_ATTACHED_ARMOR:
      case GEM_ATTACHED_HELM: strcpy (make_name, "helmMod"); break;
      case GEM_ATTACHED_SHIELD: strcpy (make_name, "shieldMod"); break;
      }
      l = strlen (make_name);
      for (mod = '1'; mod < '9'; mod++)
	{
	  make_name[l] = mod;
	  strcpy (&make_name[l + 1], "Code");
	  code = GetEntryStringField (gemtable_entry, make_name);
	  if (code[0] == 0)
	    break;
	  strcpy (&make_name[l + 1], "Param");
	  mod_param = GetEntryIntegerField (gemtable_entry, make_name);
	  strcpy (&make_name[l + 1], "Min");
	  mod_min = GetEntryIntegerField (gemtable_entry, make_name);
	  strcpy (&make_name[l + 1], "Max");
	  mod_max = GetEntryIntegerField (gemtable_entry, make_name);
	  new_magic->AddProperty
	    (new d2sMagicProperty (code, mod_param, mod_min, mod_max));
	}
      magic_properties[where] = new_magic;
      /* Because many of the properties in the table may be
	 partial properties, we need to condense the list.
	 Unless the property is one that is not saved (e.g., "indestruct"). */
      if (new_magic->Property(0)->NumberOfFields())
	new_magic->Generate();
    }

  /* Get the gem's color
     Um... Runes all have a transform entry of 18 (deep purple),
     but they don't color their items in the game. */
  if (this->is_of_type ("gem"))
    {
      color_code = GetEntryStringField (gemtable_entry, "transform");
      if (isdigit (color_code[0]))
	color_code = GetEntryStringField
	  (LookupIndexedTableEntry ("colors", atoi (color_code)),
	   "Code");
      if (color_code[0] == 0)
	color_code = NULL;
    }
  else
    color_code = NULL;
}

/* The same, called called after an item has been constructed
   when an item is being transformed into another type. */
int
d2sGemOrRuneItem::ChangeItemType (table_entry_t tent)
{
  int where;

  /* Change the type in the base class first */
  if (this->d2sItem::ChangeItemType (tent) < 0)
    return -1;

  /* Remove any existing properties */
  for (where = GEM_ATTACHMENT_UNKNOWN; where < NUM_GEM_ATTACHMENTS; where++)
    {
      if (this->magic_properties[where] != NULL) {
	delete this->magic_properties[where];
	this->magic_properties[where] = NULL;
      }
    }

  /* Then change our own fields */
  SetItemType (tent);
  return 0;
}

/* Enhance the item description with a list of magical properties
   added by this gem or rune.  It's a complete list if the gem or rune
   is not attached to anything; otherwise we just list the applicable
   property. */
char *
d2sGemOrRuneItem::FullDescription (void) const
{
  char *full_desc;
  char *property_desc = NULL;
  const char *cstr;
  int i, where, length;

  full_desc = xstrdup (Name ());
  length = strlen (full_desc);

  if ((attached_type != GEM_ATTACHMENT_UNKNOWN) && (attachment != NULL))
    {
      full_desc = (char *) xrealloc
	(full_desc, (length + sizeof ("\nInserted into a %s\n")
		     + strlen (attachment->Name())));
      length += sprintf (&full_desc[length], "\nInserted into a %s\n",
			 attachment->Name());

      if (magic_properties[attached_type] != NULL)
	property_desc = magic_properties[attached_type]->Display ();
      if (property_desc != NULL) {
	full_desc = (char *)
	  xrealloc (full_desc, length + strlen (property_desc) + 1);
	strcpy (&full_desc[length], property_desc);
	length += strlen (property_desc);
	/* Free the individual description */
	free (property_desc);
      }
    }

  else
    {
      full_desc = (char *) xrealloc
	(full_desc,
	 length + sizeof ("\nCan be Inserted into Socketed Items\n") + 1);
      length += sprintf (&full_desc[length],
			 "\nCan be Inserted into Socketed Items\n");

      /* Compile a list of all possible properties */
      for (where = GEM_ATTACHMENT_UNKNOWN + 1;
	   where < NUM_GEM_ATTACHMENTS; where++)
	if (magic_properties[where] != NULL)
	  {
	    property_desc = magic_properties[where]->Display ();
	    if (property_desc != NULL) {
	      /* Convert any newlines in the description to
		 a comma (if not the first) and a space */
	      for (i = 0; property_desc[i]; i++)
		if (property_desc[i] == '\n') {
		  property_desc[i] = ' ';
		  if (i) {
		    property_desc = (char *)
		      xrealloc (property_desc, strlen (property_desc) + 2);
		    memmove (&property_desc[i + 1], &property_desc[i],
			     strlen (property_desc) - i + 1);
		    property_desc[i] = ',';
		  }
		}
	      full_desc = (char *) xrealloc
		(full_desc, (length + 1 + strlen (property_desc) + 1
			     + strlen (attachment_names[where]) + 1));
	      length += sprintf (&full_desc[length], "\n%s:%s",
				 attachment_names[where], property_desc);
	      /* Free the individual descriptions as we consume them */
	      free (property_desc);
	    }
	  }
    }

  /* Lastly, add the required level */
  if (base_level > 1)
    {
      cstr = LookupStringByKey ("ItemStats1p");
      if (cstr == NULL)
	cstr = "Required Level:";
      full_desc = (char *) xrealloc
	(full_desc, length + 2 + strlen (cstr) + sizeof (" %3d") + 1);
      length += sprintf (&full_desc[length], "\n\n%s %d",
			 cstr, base_level);
    }
  return full_desc;
}

/* The 'combined properties' of a gem includes only those
   properties valid for the item the gem is attached to. */
d2sMagic *
d2sGemOrRuneItem::CombinedProperties (void) const
{
  d2sMagic *gem_props;

  if (attached_type > GEM_ATTACHMENT_UNKNOWN)
    gem_props = new d2sMagic (*magic_properties[attached_type]);
  else
    gem_props = new d2sMagic; /* Empty list */

  return gem_props;
}

/* Return the magical property of a gem or rune given its current or
   desired location.  If 'location' is GEM_ATTACHMENT_UNKNOWN, and the
   gem or rune is in a socket, return the property for the gem or
   rune's current location. */
const d2sMagic *
d2sGemOrRuneItem::Properties (gem_attachment_t if_attached_to)
{
  /* Check the parameter */
  if ((if_attached_to < GEM_ATTACHMENT_UNKNOWN)
      || (if_attached_to >= NUM_GEM_ATTACHMENTS))
    return NULL;

  if (if_attached_to == GEM_ATTACHMENT_UNKNOWN)
    /* Use the current location */
    if_attached_to = attached_type;

  /* Return the properties for the gem's current location */
  return magic_properties[if_attached_to];
}
