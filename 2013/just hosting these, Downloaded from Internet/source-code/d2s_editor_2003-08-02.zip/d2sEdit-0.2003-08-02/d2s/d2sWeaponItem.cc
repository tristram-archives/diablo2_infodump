/* d2sWeaponItem -- C++ class that holds an internal representation
 *		    of a Diablo II v1.09 weapon.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sMagic.h"
#include "d2sQuality.h"
#include "functions.h"
#include "internal.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Initialize member fields based on an item table entry.
   Does *NOT* alter fields based on variable data. */
void
d2sWeaponItem::SetItemType (table_entry_t tent)
{
  /* Determine the weapon class from the item types table */
  if (this->is_of_type ("axe"))
    weapon_class = AXE_CLASS;
  else if (this->is_of_type ("tpot"))
    weapon_class = BOMB_CLASS;
  else if (this->is_of_type ("bow"))
    weapon_class = BOW_CLASS;
  else if (this->is_of_type ("h2h"))
    weapon_class = CLAW_CLASS;
  else if (this->is_of_type ("xbow"))
    weapon_class = CROSSBOW_CLASS;
  else if (this->is_of_type ("knif"))
    weapon_class = DAGGER_CLASS;
  else if (this->is_of_type ("jave"))
    weapon_class = JAVELIN_CLASS;
  else if (this->is_of_type ("orb"))
    weapon_class = ORB_CLASS;
  /* This must precede "blun", because it is a subclass */
  else if (this->is_of_type ("rod"))
    weapon_class = STAFF_CLASS;
  else if (this->is_of_type ("blun"))
    weapon_class = MACE_CLASS;
  else if (this->is_of_type ("pole"))
    weapon_class = POLEARM_CLASS;
  else if (this->is_of_type ("spea"))
    weapon_class = SPEAR_CLASS;
  else if (this->is_of_type ("swor"))
    weapon_class = SWORD_CLASS;
  else
    {
      weapon_class = UNKNOWN_WEAPON_CLASS;
      print_message ("Error: unable to determine the weapon class of %s,"
		     " which is a %s\n", base_name,
		     GetEntryStringField (type_entry, "ItemType"));
      error_str = "Unknown weapon class";
    }

  /* Look up the weapon speed.  It's stored in the table as a negative
     or positive number; presumably 0 is normal.  I'm not sure how the
     math works. */
  base_attack_speed = GetEntryIntegerField (table_entry, "speed");

  /* Get the amount of damage this weapon can do */
  damage[ONE_HAND_DAMAGE][MINIMUM_DAMAGE]
    = GetEntryIntegerField (table_entry, "mindam");
  damage[ONE_HAND_DAMAGE][MAXIMUM_DAMAGE]
    = GetEntryIntegerField (table_entry, "maxdam");
  damage[TWO_HAND_DAMAGE][MINIMUM_DAMAGE]
    = GetEntryIntegerField (table_entry, "2handmindam");
  damage[TWO_HAND_DAMAGE][MAXIMUM_DAMAGE]
    = GetEntryIntegerField (table_entry, "2handmaxdam");

  /* Blunt weapons have an inherent amount of damage to the undead. */
  base_damage_to_undead = (this->is_of_type ("blun") ? 150 : 0);
}

/* The same, but called after an item has been constructed
   when an item is being transformed into another type. */
int
d2sWeaponItem::ChangeItemType (table_entry_t tent)
{
  /* Class restriction: make sure we're changing to another weapon item */
  if ( ! IsTypeAMemberOf (GetEntryStringField (tent, "type"), "weap")
       || IsTypeAMemberOf (GetEntryStringField (tent, "type"), "thro"))
    {
      fprintf (stderr, "%s: Internal error: attempt to change a weapon class"
	       " item to a %s\n", progname,
	       GetEntryStringField (LookupTableEntry
				    ("itemtypes", "Code",
				     GetEntryStringField (tent, "type")),
				    "ItemType"));
      return -1;
    }
  /* Change the type in the base class first */
  if (this->d2sDurableItem::ChangeItemType (tent) < 0)
    return -1;
  /* Then change ourself */
  SetItemType (tent);
  return 0;
}

/* Create a new, blank weapon (to be filled in later) */
d2sWeaponItem::d2sWeaponItem (void)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (), d2sExtendedItem (), d2sDurableItem ()
{
  /* Override the default item class */
  item_class = WEAPON_ITEM;
  nvop = this;
  weapon_class = UNKNOWN_WEAPON_CLASS;
  base_attack_speed = 0;
  memset (damage, 0, sizeof (damage));
  base_damage_to_undead = 0;
}

/* Create a new, specific weapon as described by the weapon table entry
   (using default variable attributes) */
d2sWeaponItem::d2sWeaponItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (tent), d2sExtendedItem (tent), d2sDurableItem (tent)
{
  /* Override the default item class */
  item_class = WEAPON_ITEM;
  /* Change the nvop (very important) */
  nvop = this;
  /* Set our member fields from the item tables */
  SetItemType (tent);
}

/* Copy an existing weapon */
d2sWeaponItem::d2sWeaponItem (const d2sWeaponItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (source), d2sExtendedItem (source), d2sDurableItem (source)
{
  /* Change the nvop (very important) */
  nvop = this;

  /* Now copy our own fields */
  this->weapon_class = source.weapon_class;
  this->base_attack_speed = source.base_attack_speed;
  memcpy (&this->damage, &source.damage, sizeof (damage));
  this->base_damage_to_undead = source.base_damage_to_undead;
}

/* Copy a weapon. */
d2sItem *
d2sWeaponItem::Copy (void) const
{
  d2sWeaponItem *new_item = new d2sWeaponItem (*this);
  return (d2sItem *) new_item;
}

/* Static table of weapon classes; keys into the string table. */
static const char * const weapon_class_names[] = {
  /* IMPORTANT: The order of names shown here MUST MATCH
     the enumeration listed in d2sItem.h! */
  "(unknown class)", "WeaponDescAxe", "WeaponDescThrownPotion",
  "WeaponDescBow", "WeaponDescH2H", "WeaponDescCrossbow",
  "WeaponDescDagger", "WeaponDescJavelin", "WeaponDescMace",
  "WeaponDescOrb", "WeaponDescPolearm", "WeaponDescSpear",
  "WeaponDescStaff", "WeaponDescSword"
};

/* Weapons add their quality, damage, durability, requirements,
   speed, and magic properties to the descrption. */
char *
d2sWeaponItem::FullDescription (void) const
{
  char *descr;
  const char *cstr;
  int len;
  int required_dexterity, required_strength, required_level;
  int min_damage, max_damage, max_durability;

  /* Start with the item's full name. */
  descr = FullName();
  len = strlen (descr);
  max_durability = MaxDurability();

  if (item_class == STACKED_WEAPON_ITEM)
    {
      /* The next line is the throw damage (required for stacked weapons) */
      cstr = LookupStringByKey ("ItemStats1n");
      if (cstr == NULL)
	cstr = "Throw Damage:";
      descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
      len += sprintf (&descr[len], "\n%s", cstr);
      min_damage = GetDamage (THROW_DAMAGE, CURRENT_DAMAGE, MINIMUM_DAMAGE);
      max_damage = GetDamage (THROW_DAMAGE, CURRENT_DAMAGE, MAXIMUM_DAMAGE);
      if (min_damage == max_damage) {
	descr = (char *) xrealloc (descr, len + sizeof (" %3d") + 1);
	len += sprintf (&descr[len], " %d", min_damage);
      }
      else {
	/* NOTE: The misspelling below is intentional!
	   (It got stuck in the string translation tables that way.) */
	cstr = LookupStringByKey ("ItemStast1k");
	if (cstr == NULL)
	  cstr = "to";
	descr = (char *) xrealloc (descr, len + sizeof (" %3d %s %3d")
				   + strlen (cstr));
	len += sprintf (&descr[len], " %d %s %d",
			min_damage, cstr, max_damage);
      }
    }

  /* The next line is the one-hand damage */
  if ((item_class == STACKED_WEAPON_ITEM)
      ? (this->is_of_type ("comb"))
      : ( ! GetEntryIntegerField (table_entry, "2handed")
	  || GetEntryIntegerField (table_entry, "1or2handed")))
    {
      cstr = LookupStringByKey ("ItemStats1l");
      if (cstr == NULL)
	cstr = "One-Hand Damage:";
      descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
      len += sprintf (&descr[len], "\n%s", cstr);
      cstr = LookupStringByKey ("ItemStast1k");
      if (cstr == NULL)
	cstr = "to";
      descr = (char *) xrealloc
	(descr, len + sizeof (" %3d %s %3d") + strlen (cstr));
      len += sprintf
	(&descr[len], " %d %s %d",
	 GetDamage (ONE_HAND_DAMAGE, CURRENT_DAMAGE, MINIMUM_DAMAGE), cstr,
	 GetDamage (ONE_HAND_DAMAGE, CURRENT_DAMAGE, MAXIMUM_DAMAGE));
    }

  /* The next line is the two-hand damage */
  if (GetEntryIntegerField (table_entry, "2handed"))
    {
      cstr = LookupStringByKey ("ItemStats1m");
      if (cstr == NULL)
	cstr = "Two-Hand Damage:";
      descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
      len += sprintf (&descr[len], "\n%s", cstr);
      cstr = LookupStringByKey ("ItemStast1k");
      if (cstr == NULL)
	cstr = "to";
      descr = (char *) xrealloc
	(descr, len + sizeof (" %3d %s %3d") + strlen (cstr));
      len += sprintf
	(&descr[len], " %d %s %d",
	 GetDamage (TWO_HAND_DAMAGE, CURRENT_DAMAGE, MINIMUM_DAMAGE), cstr,
	 GetDamage (TWO_HAND_DAMAGE, CURRENT_DAMAGE, MAXIMUM_DAMAGE));
    }

  if (item_class == STACKED_WEAPON_ITEM)
    {
      /* Add the quantity */
      cstr = LookupStringByKey ("ItemStats1i");
      if (cstr == NULL)
	cstr = "Quantity:";
      descr = (char *) xrealloc (descr, len + 1 + strlen (cstr)
				 + sizeof (" %3d") + 1);
      len += sprintf (&descr[len], "\n%s %d", cstr,
		      ((d2sStackedWeaponItem *) *this)->Quantity());
    }

  else
    {
      /* Durability is next.  I'm not sure why, but bows and crossbows
	 do not display a durability. */
      if ( ! GetEntryIntegerField (table_entry, "nodurability")
	   /* Also, indestructible items don't *have* a durability */
	   && max_durability)
	{
	  cstr = LookupStringByKey ("ItemStats1d");
	  if (cstr == NULL)
	    cstr = "Durability:";
	  descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
	  len += sprintf (&descr[len], "\n%s", cstr);
	  cstr = LookupStringByKey ("ItemStats1j");
	  if (cstr == NULL)
	    cstr = "of";
	  descr = (char *) xrealloc
	    (descr, len + sizeof (" %3d %s %3d") + strlen (cstr));
	  len += sprintf (&descr[len], " %d %s %d",
			  durability, cstr, max_durability);
	}
    }

  /* If the weapon is class-specific, the class comes next. */
  if (restricted_item)
    {
      descr = (char *) xrealloc
	(descr, len + sizeof ("\n(Necromancer Only)") + 1);
      len += sprintf (&descr[len], "\n(%s Only)",
		      GetCharacterClassName (class_restriction));
    }

  /* Required dexterity, strength, and level (all optional) */
  required_dexterity = RequiredDexterity();
  if (required_dexterity)
    {
      cstr = LookupStringByKey ("ItemStats1f");
      if (cstr == NULL)
	cstr = "Required Dexterity:";
      descr = (char *) xrealloc
	(descr, len + 1 + strlen (cstr) + sizeof (" %8(not)d") + 1);
      len += sprintf (&descr[len], "\n%s %d", cstr, required_dexterity);
    }

  required_strength = RequiredStrength();
  if (required_strength)
    {
      cstr = LookupStringByKey ("ItemStats1e");
      if (cstr == NULL)
	cstr = "Required Strength:";
      descr = (char *) xrealloc
	(descr, len + 1 + strlen (cstr) + sizeof (" %8(not)d") + 1);
      len += sprintf (&descr[len], "\n%s %d", cstr, required_strength);
    }

  required_level = RequiredLevel();
  if (required_level > 1)
    {
      cstr = LookupStringByKey ("ItemStats1p");
      if (cstr == NULL)
	cstr = "Required Level:";
      descr = (char *) xrealloc
	(descr, len + 1 + strlen (cstr) + sizeof (" %3d") + 1);
      len += sprintf (&descr[len], "\n%s %d", cstr, required_level);
    }

  /* Weapon class and attack speed */
  cstr = TranslateString (weapon_class_names[weapon_class]);
  descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 4);
  len += sprintf (&descr[len], "\n%s - ", cstr);
  cstr = AttackSpeed();
  descr = (char *) xrealloc (descr, len + strlen (cstr) + 1);
  len += sprintf (&descr[len], "%s", cstr);

  /* I'm not entirely certain in what order this field is shown... */
  if ( ! max_durability)
    {
      cstr = LookupStringByKey ("ModStre9s");
      if (cstr == NULL)
	cstr = "Indestructible";
      descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
      len += sprintf (&descr[len], "\n%s", cstr);
    }

  /* Finish up */
  return FinishFullDescription (descr);
}

/* Certain weapons add an inherent "150% damage to undead"
   to the combined properties. */
d2sMagic *
d2sWeaponItem::CombinedProperties (void) const
{
  d2sMagic *ret_props;
  d2sMagicProperty *damage_undead;

  /* Start with the regular durable item combined properties */
  ret_props = d2sDurableItem::CombinedProperties();

  /* If this is a blunt weapon, add damage to the undead. */
  if (base_damage_to_undead)
    {
      damage_undead = new d2sMagicProperty
	("dmg-undead", 0, base_damage_to_undead);
      *ret_props += *damage_undead;
      delete damage_undead;
    }

  return ret_props;
}

/* Get the amount of damage inflicted.  One function to save namespace. */
int
d2sWeaponItem::GetDamage (int hands, int current, int max) const
{
  int		d;
  d2sMagic	*comb;
  d2sMagicProperty *property;

  /* Start with the base */
  d = damage[hands][max];
  if (!current)
    /* Return the base damage */
    return d;

  comb = CombinedProperties();
  /* Add +minimum / +maximum damage first */
  property = comb->Lookup (max ? "dmg-max" : "dmg-min");
  if (property == NULL)
    /* Hard-coded magic numbers here! */
    property = comb->Lookup (hands ? ((item_class == STACKED_WEAPON_ITEM)
				      ? (max ? 160 : 159)
				      : (max ? 24 : 23))
			     : (max ? 22 : 21));
  if (property != NULL)
    d += property->FieldData(0) - property->Bias();

  /* Add normal damage */
  property = comb->Lookup ("dmg-norm");
  if (property != NULL)
    d += property->FieldData(0) - property->Bias();

  /* Add damage per level */
  if (max && (character != NULL))
    {
      property = comb->Lookup ("dmg/lvl");
      if (property != NULL)
	d += property->FieldData(0) * character->GetCharacterLevel() / 8;
    }

  /* Add % enhancement next */
  property = comb->Lookup ("dmg%");
  if (property != NULL)
    d = (int) ((double) d * (100 + property->FieldData(max ? 0 : 1)
			     - property->Bias())
	       / 100.0);

  delete comb;
  return d;
}

/* Get the weapon's attack speed as a number */
int
d2sWeaponItem::AttackSpeedValue (void) const
{
  int attack_speed = base_attack_speed;
  d2sMagic	*comb;
  d2sMagicProperty *property;

  /* It appears that the formula for attack speed involves
     adding the speed modifiers to 100%, then dividing
     the result into the number of animation frames for a
     given character using a given class of weapon.
     Meaning the sign in the weapon table should be reversed.
     I'm still not sure whether this formula is correct. */

  comb = CombinedProperties();
  /* There are actually three mnemonics for attack speed.  All have
     the same ID (I think), but I prefer to take the slow approach and
     search for the strings rather than use a magic number here. */
  property = comb->Lookup ("swing1");
  if (property != NULL)
    attack_speed -= property->FieldData(0) - property->Bias();

  property = comb->Lookup ("swing2");
  if (property != NULL)
    attack_speed -= property->FieldData(0) - property->Bias();

  property = comb->Lookup ("swing3");
  if (property != NULL)
    attack_speed -= property->FieldData(0) - property->Bias();

  delete comb;
  return attack_speed;
}

/* Static table of attack speeds; keys into the string table. */
static const char * const attack_speed_names[] = {
  "WeaponAttackFastest", "WeaponAttackVeryFast", "WeaponAttackFast",
  "WeaponAttackNormal",
  "WeaponAttackSlow", "WeaponAttackVerySlow", "WeaponAttackSlowest"
};

/* Get the weapon's attack speed as a string */
const char *
d2sWeaponItem::AttackSpeed (void) const
{
  const char *cstr;
  int speed_index;

  /* I'm guessing The displayed speed changes for every
     16 points of the attack speed rating.  But I'm wrong.
     It's capped at either end. */
  speed_index = ((AttackSpeedValue()
		  + 8 * (int) XtNumber (attack_speed_names))
		 / 16);
  if (speed_index < 0)
    speed_index = 0;
  else if (speed_index >= (int) XtNumber (attack_speed_names))
    speed_index = XtNumber (attack_speed_names) - 1;
  cstr = TranslateString (attack_speed_names[speed_index]);
  return cstr;
}

/* Read class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after reading the quality fields
   and before reading the magic properties. */
int
d2sWeaponItem::ReadItemSpecificData (struct bit_stream *bstream)
{
  /* Read the base and current durability. */
  base_durability = bstream_read_field (bstream, 8);
  if (base_durability)
    durability = bstream_read_field (bstream, 8);
  else
    durability = 0;

  /* If the weapon is socketed, read the number of sockets. */
  if (socketed_item)
    {
      num_sockets = bstream_read_field (bstream, 4);
      if (num_sockets > MaximumNumberOfSockets())
	{
	  print_message ("Warning: %s found with %d sockets"
			 " (the maximum number of sockets is %d)\n",
			 base_name, num_sockets, MaximumNumberOfSockets());
	  error_str = "Invalid number of sockets";
	}
    }
  return 0;
}

/* Write class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after writing the quality fields
   and before writing the magic properties. */
int
d2sWeaponItem::WriteItemSpecificData (struct bit_stream *bstream)
{
  /* Write the base and current durability. */
  if (MaxDurability())
    {
      bstream_write_field (bstream, 8, base_durability);
      bstream_write_field (bstream, 8, durability);
    } else {
      /* This should take care of clearing the durability
	 if an "indestructible" property was added. */
      bstream_write_field (bstream, 8, 0);
    }

  /* If the weapon is socketed, write the number of sockets. */
  if (socketed_item)
    bstream_write_field (bstream, 4, num_sockets);

  return 0;
}
