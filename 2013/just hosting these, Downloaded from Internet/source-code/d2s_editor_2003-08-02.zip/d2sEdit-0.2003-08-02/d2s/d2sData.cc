/* d2sData -- C++ class that holds an internal representation
 *	      of a Diablo II v1.09 saved game file.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include "define.h"
#include "functions.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include "d2sData.h"
#include "d2sItem.h"
#include <dmalloc.h>


/* Small constant tables are stored internally. */

static const char * const title_names
	[2 /* Expansion? */][2 /* Hardcore? */][2 /* gender */][4] =
{ { {
  /* These are the titles you get in a standard Diablo II game. */
  { "", "Sir", "Lord", "Baron" },
  { "", "Dame", "Lady", "Baroness" } },
    /* If you are playing Diablo II in Hardcore mode, the titles change to: */
    { { "", "Count", "Duke", "King" },
      { "", "Countess", "Duchess", "Queen" } } },
  /* and if you are playing an Expansion Set game, the titles change to: */
  { { { "", "Slayer", "Champion", "Patriarch" },
      { "", "Slayer", "Champion", "Matriarch" } },
    /* and in Hardcore mode: */
    { { "", "Destroyer", "Conqueror", "Guardian" },
      { "", "Destroyer", "Conqueror", "Guardian" } } } };

static const char class_genders[NUM_CHAR_CLASSES] = { 1, 1, 0, 0, 0, 0, 1 };

/* Larger tables are stored externally. */

/* Forward declarations: */

static inline void init_item_list (struct item_list_t *list);
static inline void append_to_item_list (struct item_list_t *list,
					d2sItem *item);
static void remove_from_item_list (struct item_list_t *, d2sItem *);
static void compute_checksum (unsigned char *raw_file);


/********************* NON-CLASS FUNCTIONS **********************/

/* List maintenance functions */
static inline void
init_item_list (struct item_list_t *list)
{
  list->count = 0;
  list->head = NULL;
  list->tail = &list->head;
}

static inline void
append_to_item_list (struct item_list_t *list, d2sItem *item)
{
  *(list->tail) = item;
  item->next = NULL;
  item->pprev = list->tail;
  list->tail = &item->next;
  list->count++;
}

static void
remove_from_item_list (struct item_list_t *list, d2sItem *item)
{
  if (item->next == NULL)
    {
      if (list->tail != &item->next)
	{
	  fprintf (stderr, "%s: Internal error: item list corrupted\n",
		   progname);
	  exit (1);
	}
      list->tail = item->pprev;
      *(list->tail) = NULL;
    }
  else
    {
      item->next->pprev = item->pprev;
      *(item->pprev) = item->next;
      item->next = NULL;
    }
  list->count--;
}


/* Compute the checksum of a .d2s file.  This takes the entire file
   as a raw byte array.  The length of the array is taken from the
   d2s header, so make sure that is correctly set beforehand.
   Any previous checksum is overwritten. */
static void
compute_checksum (unsigned char *raw_file)
{
  struct d2s_header *d2s = (struct d2s_header *) raw_file;
  unsigned long cs = 0;
  int i;
  int length = d2s->length;

  d2s->checksum = 0;
  for (i = 0; i < length; i++)
    cs = (cs << 1) + (cs >> 31) + raw_file[i];
  d2s->checksum = cs;
}


/*********************** CLASS FUNCTIONS ************************/

/* Initialize the data structures in the object to empty.
   This is called by the constructors. */
void
d2sData::Init (void)
{
  read_only = False;
  filename = NULL;
  ui_data = NULL;
  dirty = False;
  error_str = NULL;
  memset (raw_header, 0, sizeof (raw_header));
  memset (name, 0, sizeof (name));
  char_status = 0;
  char_title = 0;
  char_class = AMAZON_CLASS;
  level = 1;
  timestamp = 0;
  hireling_status = 0;
  hireling_id = 0;
  hireling_name = 0;
  hireling_attribute = 0;
  hireling_experience = 0;
  hireling_entry = NULL;
  hireling_level = 0;
  memset (&difficulty_active, 0, sizeof (difficulty_active));
  memset (&quest_data, 0, sizeof (quest_data));
  memset (&waypoints, 0, sizeof (waypoints));
  memset (&backup_stats, 0, sizeof (backup_stats));
  memset (&stats, 0, sizeof (stats));
  first_skill = 0;
  memset (&backup_skill_data, 0, sizeof (backup_skill_data));
  memset (&skill_data, 0, sizeof (skill_data));
  init_item_list (&item_list);
  memset (&equipment, 0, sizeof (equipment));
  memset (&belt, 0, sizeof (belt));
  memset (&inventory, 0, sizeof (inventory));
  memset (&stash, 0, sizeof (stash));
  memset (&cube, 0, sizeof (cube));
  picked_item = NULL;
  has_cube = NULL;
  belt_size = 4;
  memset (&corpse_data, 0, sizeof (corpse_data));
  init_item_list (&corpse_item_list);
  memset (&corpse_equipment, 0, sizeof (corpse_equipment));
  init_item_list (&hireling_item_list);
  memset (&hireling_equipment, 0, sizeof (hireling_equipment));
}

/* Create a new character. */
d2sData::d2sData (int new_char_class, const char *new_name,
		  int new_expansion, int new_hardcore)
{
  struct d2s_header *file_header;
  struct d2sItem *item;
  int d;
  struct data_stream ds;

  Init ();

  /* Check the argument.  If it's out of range, default to Amazon. */
  if ((unsigned) new_char_class >= NUM_CHAR_CLASSES)
    {
      if (debug)
	fprintf (stderr, "%s: Error: invalid character class given to"
		 " d2sData::d2sData(%d)\n", progname, new_char_class);
      error_str = "Invalid character class";
      new_char_class = AMAZON_CLASS;
    }

  /* Load in the template for this character. */
  memcpy (&raw_header, &template_d2s_header, sizeof (raw_header));
  file_header = (struct d2s_header *) &raw_header;

  /* Install the character name given by the caller.
     If the caller didn't provide a name, make one up. */
  if ((new_name == NULL) || (validate_name (new_name) < 0))
    new_name = class_names[new_char_class];
  strcpy (file_header->name, new_name);

  /* Set the expansion and hardcore flags */
  if (new_expansion)
    file_header->char_status |= 0x20;
  else if (options.character.link.freeform)
    file_header->char_status &= ~0x20;

  if (new_hardcore)
    file_header->char_status |= 0x04;

  /* Adjust certain class-dependent fields */
  file_header->char_class = new_char_class;
  switch (new_char_class) {
  case AMAZON_CLASS:
    file_header->unknown88[5] = 0x1b;
    file_header->unknown88[7] = 0xff;
    break;
  case SORCERESS_CLASS:
    file_header->button_action[1] = 0x24 /* Fire Bolt */;
    file_header->unknown88[5] = 0x25;
    file_header->unknown88[7] = 0xff;
    break;
  case NECROMANCER_CLASS:
    file_header->button_action[1] = 0x46 /* Summon Skeleton */;
    file_header->unknown88[5] = 0x09;
    file_header->unknown88[7] = 0xff;
    break;
  case PALADIN_CLASS:
    file_header->unknown88[5] = 0x11;
    file_header->unknown88[7] = 0x4f;
    break;
  case BARBARIAN_CLASS:
    file_header->unknown88[5] = 0x04;
    file_header->unknown88[7] = 0x4f;
    break;
  case DRUID_CLASS:
    file_header->char_status = 0x20;
    file_header->unknown88[5] = 0x0c;
    file_header->unknown88[7] = 0x4f;
    break;
  case ASSASSIN_CLASS:
    file_header->char_status = 0x20;
    file_header->unknown88[5] = 0x2d;
    file_header->unknown88[7] = 0x4f;
    break;
  }

  /* Fill in some of the class members from the raw template. */
  memcpy (name, file_header->name, sizeof (name));
  char_status = file_header->char_status;
  char_class = file_header->char_class;
  level = file_header->level;
  timestamp = (unsigned long) time (NULL);
  for (d = 0; d < NUM_DIFFICULTY_LEVELS; d++)
    waypoints[d][0] = file_header->waypoints[d].points[0];

  /* Fill in the character statistics from the
     per-character class templates. */
  stats.strength = template_d2s_stats_section[char_class].strength;
  stats.energy = template_d2s_stats_section[char_class].energy;
  stats.dexterity = template_d2s_stats_section[char_class].dexterity;
  stats.vitality = template_d2s_stats_section[char_class].vitality;
  stats.life.current = template_d2s_stats_section[char_class].life.current;
  stats.life.base = template_d2s_stats_section[char_class].life.base;
  stats.mana.current = template_d2s_stats_section[char_class].mana.current;
  stats.mana.base = template_d2s_stats_section[char_class].mana.base;
  stats.stamina.current
    = template_d2s_stats_section[char_class].stamina.current;
  stats.stamina.base = template_d2s_stats_section[char_class].stamina.base;
  stats.level = template_d2s_stats_section[char_class].level;
  memcpy (&backup_stats, &stats, sizeof (stats));
  first_skill = FirstSkillOfClass (char_class);

  /* All characters come with 4 minor healing potions in their belt and
     1 Scroll of Townportal and 1 Scroll of Identify in the inventory */
  dstream_set (ds, &template_d2s_tail_section.items[0][0],
	       0, sizeof (template_d2s_tail_section.items));
  for (d = 0; d < (int) XtNumber (template_d2s_tail_section.items); d++)
    {
      item = ReadItemFromFile (&ds);
      if (item != NULL)
	{
	  item->AssignTo (this);
	  append_to_item_list (&item_list, item);
	  PlaceItem (item);
	}
    }

  /* Characters have one or two more items which are class-dependent. */
  dstream_set (ds, &template_d2s_class_items[char_class][0],
	       0, sizeof (template_d2s_class_items[char_class]));
  /* Figure out the end of this item sublist
     so we don't confuse the item reader */
  while (!ds.end[-1])
    {
      ds.end--;
      ds.size--;
    }
  for (d = 0; !dstream_eof (ds); d++)
    {
      item = ReadItemFromFile (&ds);
      if (item != NULL)
	{
	  item->AssignTo (this);
	  append_to_item_list (&item_list, item);
	  PlaceItem (item);
	}
    }

  /* New characters are marked dirty by default until they are saved. */
  MarkDirty ();
  return;
}

/* Decode a .d2s file.  Taken from the text-based charedit program. */
d2sData::d2sData (const char *filename)
{
  int		fd;
  ssize_t	status;
  uint8_t *	raw_file;
  struct stat	statbuf;
  struct d2s_header *file_header;
  int		i, d, act;
  int		items_left, corpses_left;
  struct data_stream ds;
  d2sItem *	item;

  Init ();

  if (stat (filename, &statbuf))
    {
      error_str = strerror (errno);
      print_message ("%s: %s", filename, error_str);
      return;
    }

  /* Allocate a buffer large enough to read the whole file at once */
  if ((statbuf.st_size < (off_t) sizeof (raw_header))
      /* Limit the size of the .d2s file to 64KB.  Most files are a few KB. */
      || (statbuf.st_size > 64 * 1024))
    {
      error_str = "Bad file size";
      print_message ("%s: %s (%lu)", filename, error_str, statbuf.st_size);
      return;
    }
  raw_file = (uint8_t *) xmalloc (statbuf.st_size);
  /* Read the whole file */
  fd = open (filename, O_RDONLY);
  if (fd < 0)
    {
      free (raw_file);
      error_str = strerror (errno);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  errno = 0;
  status = read (fd, raw_file, (size_t) statbuf.st_size);
  if (status < (ssize_t) statbuf.st_size)
    {
      if (errno)
	error_str = strerror (errno);
      else
	error_str = "Short read";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  close (fd);

  /* Copy the .d2s file header */
  memcpy (raw_header, raw_file, sizeof (raw_header));
  file_header = (struct d2s_header *) &raw_header;

  /* Check the validity of the file */
  if (file_header->magic != 0xaa55aa55)
    {
      error_str = "Invalid file header";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  if (file_header->version != 92)
    {
      error_str = "Incorrect version";
      free (raw_file);
      switch (file_header->version) {
      case 71:
	print_message ("%s: File was created by Diablo II %s. "
		       " This program is designed for v1.09",
		       filename, "v1.06 or earlier");
	return;
      case 87:
	print_message ("%s: File was created by Diablo II %s. "
		       " This program is designed for v1.09",
		       filename, "v1.07 or earlier");
	return;
      case 89:
	print_message ("%s: File was created by Diablo II %s. "
		       " This program is designed for v1.09",
		       filename, "v1.08");
	return;
      default:
	print_message ("%s: Incorrect version (%u). "
		       " This program is designed for version 92",
		       filename, file_header->version);
	return;
      }
    }
  if ((off_t) file_header->length != statbuf.st_size)
    {
      error_str = "File length mismatch";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  compute_checksum (raw_file);
  if (file_header->checksum != ((struct d2s_header *) raw_file)->checksum)
    {
      error_str = "Bad Checksum";
      print_message ("%s: %s", filename, error_str);
      /* In case the user modified part of the file himself,
	 we'll allow a bad checksum with confirmation. */
      if (display_question (0, 2, "No", "Yes",
			    "%s has a bad checksum. Continue loading?",
			    filename)
	  == False)
	{
	  free (raw_file);
	  return;
	}
      /* Mark the file dirty, so that we'll
	 re-save the file with the correct checksum. */
      dirty = True;
    }

  /* Copy fields from the file header to our object. */
  memcpy (name, file_header->name, sizeof (name));
  char_status = file_header->char_status;
  char_title = file_header->char_title;
  char_class = file_header->char_class;
  if (char_class >= NUM_CHAR_CLASSES)
    {
      error_str = "Invalid character class";
      free (raw_file);
      print_message ("%s: %s (%d); Only %d character classes are supported",
		     progname, error_str, char_class, NUM_CHAR_CLASSES);
      return;
    }
  level = file_header->level;
  if (level > 99)
    {
      error_str = "Invalid character level";
      free (raw_file);
      print_message ("%s: %s (%d); The maximum level is 99",
		     progname, error_str, level);
      return;
    }
  timestamp = file_header->timestamp;
  hireling_status = file_header->hireling_died;
  hireling_id = file_header->hireling_id;
  hireling_name = file_header->hireling_name;
  hireling_attribute = file_header->hireling_attribute;
  hireling_experience = file_header->hireling_experience;
  if (hireling_id)
    FindHireling ();
  else
    hireling_entry = NULL;
  memcpy (difficulty_active, file_header->difficulty, NUM_DIFFICULTY_LEVELS);

  /* Make sure the quest data is located at the expected offset */
  if (*((unsigned long *) &file_header->quest_magic)
      != *((unsigned long *) &"Woo!"))
    {
      error_str = "Invalid quest data header";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  for (d = 0; d < NUM_DIFFICULTY_LEVELS; d++) {
    for (act = 0; act < 3; act++) {
      quest_data[d].act[act].intros = file_header->quests[d].act[act].intros;
      for (i = 0; i < MAX_NUM_QUESTS; i++)
	quest_data[d].act[act].quest[i]
	  = file_header->quests[d].act[act].quests[i];
      quest_data[d].act[act].completed
	= file_header->quests[d].act[act].completed;
    }
    quest_data[d].act[3].intros = file_header->quests[d].act_4.intros;
    for (i = 0; i < 3; i++)
      quest_data[d].act[3].quest[i] = file_header->quests[d].act_4.quests[i];
    quest_data[d].act[3].completed = file_header->quests[d].act_4.completed;
    quest_data[d].act[4].intros = file_header->quests[d].act_5.intros;
    for (i = 0; i < 6; i++)
      quest_data[d].act[4].quest[i] = file_header->quests[d].act_5.quests[i];
    quest_data[d].act[4].completed = file_header->quests[d].act_5.completed;
  }

  /* Make sure the waypoint data is located at the expected offset */
  if (*((unsigned short *) &file_header->waypoint_magic)
      != *((unsigned short *) &"WS"))
    {
      error_str = "Invalid waypoint data header";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  for (d = 0; d < NUM_DIFFICULTY_LEVELS; d++) {
    struct bit_stream bs;
    bstream_set (bs, &file_header->waypoints[d].points, 0,
		 sizeof (file_header->waypoints[d].points));
    for (act = 0; act < MAX_NUM_ACTS; act++)
      waypoints[d][act]
	= bstream_read_field (&bs, GetNumberOfWaypointsInAct (act));
  }

  /* Make sure the NPC data is located at the expected offset */
  if (*((unsigned short *) &file_header->NPC_magic)
      != *((unsigned short *) &"w4"))
    {
      error_str = "Invalid NPC data header";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  /* We don't actually do anything with the NPCs yet
     (don't know the structure) */

  /* Make sure the statistics data is located at the expected offset */
  if (*((unsigned short *) &file_header->stats_magic)
      != *((unsigned short *) &"gf"))
    {
      error_str = "Invalid statistics header";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  /* At this point the structure becomes variable.
     Switch to a stream-based means of reading the raw data. */
  dstream_set (ds, raw_file, (offsetof (struct d2s_header, stats_magic)
			      + sizeof (file_header->stats_magic)),
	       file_header->length);

  /* The next 16-bit field determines the presence or absence
     of the following 16 fields. */
  d = dstream_read_item (ds, unsigned short);
#define bit(n) (1 << (n))
  if (d & bit(0))
    stats.strength = dstream_read_item (ds, unsigned long);
  if (d & bit(1))
    stats.energy = dstream_read_item (ds, unsigned long);
  if (d & bit(2))
    stats.dexterity = dstream_read_item (ds, unsigned long);
  if (d & bit(3))
    stats.vitality = dstream_read_item (ds, unsigned long);
  if (d & bit(4))
    stats.statp_remaining = dstream_read_item (ds, unsigned long);
  if (d & bit(5))
    stats.skillp_remaining = dstream_read_item (ds, unsigned long);
  if (d & bit(6))
    stats.life.current = dstream_read_item (ds, unsigned long);
  if (d & bit(7))
    stats.life.base = dstream_read_item (ds, unsigned long);
  if (d & bit(8))
    stats.mana.current = dstream_read_item (ds, unsigned long);
  if (d & bit(9))
    stats.mana.base = dstream_read_item (ds, unsigned long);
  if (d & bit(10))
    stats.stamina.current = dstream_read_item (ds, unsigned long);
  if (d & bit(11))
    stats.stamina.base = dstream_read_item (ds, unsigned long);
  if (d & bit(12)) {
    /* The level should equal the value read in the header portion.
       If not, check the range and replace the previous value. */
    stats.level = (int) dstream_read_item (ds, unsigned long);
    if ((unsigned long) stats.level >= 100) {
      error_str = "Invalid character level";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
    if (stats.level != level) {
      if (display_question (1, 2, "No", "Yes",
			    "The file header says the character level is %d, "
			    "but the stats section says the level is %d. "
			    " Is %d the correct level?",
			    level, stats.level, stats.level)) {
	level = stats.level;
      }
      else {
	stats.level = level;
      }
      /* Whichever value we're using, mark the file dirty. */
      dirty = True;
    }
  }
  if (d & bit (13))
    stats.experience = dstream_read_item (ds, unsigned long);
  if (d & bit (14))
    stats.gold_in_inventory = dstream_read_item (ds, unsigned long);
  if (d & bit (15))
    stats.gold_in_stash = dstream_read_item (ds, unsigned long);
#undef bit
  /* Back up the stats section */
  memcpy (&backup_stats, &stats, sizeof (stats));

  /* Make sure the skill data is located at the expected offset */
  d = dstream_read_item (ds, unsigned short);
  if (d != *((unsigned short *) &"if"))
    {
      error_str = "Invalid skills header";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  first_skill = FirstSkillOfClass (char_class);
  dstream_read (ds, &skill_data[0], NUM_SKILLS_PER_CHAR);
  /* Back up the skills section */
  memcpy (&backup_skill_data, &skill_data, sizeof (skill_data));

  /* Make sure the item data is located at the expected offset */
  d = dstream_read_item (ds, unsigned short);
  if (d != *((unsigned short *) &"JM"))
    {
      error_str = "Invalid item list header";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  /* Read the number of items */
  items_left = dstream_read_item (ds, unsigned short);
  while (items_left)
    {
      item = ReadItemFromFile (&ds);
      if (item == NULL)
	{
	  error_str = "Bad item data";
	  break;
	}
      if (item->AssignTo (this) < 0)
	{
	  error_str = item->GetErrorMessage();
	  print_message ("%s: %s", filename, error_str);
	}
      else
	{
	  append_to_item_list (&item_list, item);
	  PlaceItem (item);
	}
      --items_left;
    }
  if (items_left)
    {
      free (raw_file);
      return;
    }

  /* Check for corpses */
  d = dstream_read_item (ds, unsigned short);
  if (d != *((unsigned short *) &"JM"))
    {
      error_str = "Invalid item list trailer";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }
  /* Read the number of corpses? */
  corpses_left = dstream_read_item (ds, unsigned short);
  if (corpses_left)
    {
      /* There should be 12 bytes of corpse data */
      *((unsigned short *) &corpse_data[0]) = d;
      *((unsigned short *) &corpse_data[2]) = corpses_left;
      dstream_read (ds, &corpse_data[4], 12);

      /* Followed by another item header */
      d = dstream_read_item (ds, unsigned short);
      if (d != *((unsigned short *) &"JM"))
	{
	  error_str = "Invalid item list header";
	  free (raw_file);
	  print_message ("%s: %s", filename, error_str);
	  return;
	}
      /* Read the number of items */
      items_left = dstream_read_item (ds, unsigned short);
      while (items_left)
	{
	  item = ReadItemFromFile (&ds);
	  if (item == NULL)
	    {
	      error_str = "Bad item data";
	      break;
	    }
	  if (item->AssignTo (this, ITEM_AREA_CORPSE) < 0)
	    {
	      error_str = item->GetErrorMessage();
	      print_message ("%s: %s", filename, error_str);
	    }
	  else
	    {
	      append_to_item_list (&corpse_item_list, item);
	      PlaceItem (item);
	    }
	  --items_left;
	}
      if (items_left)
	{
	  free (raw_file);
	  return;
	}
    }

  if (is_expansion())
    {
      /* Read hireling items */
      d = dstream_read_item (ds, unsigned short);
      if (d != *((unsigned short *) &"jf"))
	{
	  error_str = "Invalid mercenary section header";
	  free (raw_file);
	  print_message ("%s: %s", filename, error_str);
	  return;
	}
      if (hireling_id)
	{
	  d = dstream_read_item (ds, unsigned short);
	  if (d != *((unsigned short *) &"JM"))
	    {
	      error_str = "Invalid item list header";
	      free (raw_file);
	      print_message ("%s: %s", filename, error_str);
	      return;
	    }
	  /* Read the number of items */
	  items_left = dstream_read_item (ds, unsigned short);
	  while (items_left)
	    {
	      item = ReadItemFromFile (&ds);
	      if (item == NULL)
		{
		  error_str = "Bad item data";
		  break;
		}
	      if (item->AssignTo (this, ITEM_AREA_HIRELING) < 0)
		{
		  error_str = item->GetErrorMessage();
		  print_message ("%s: %s", filename, error_str);
		}
	      else
		{
		  append_to_item_list (&hireling_item_list, item);
		  PlaceItem (item);
		}
	      --items_left;
	    }
	  if (items_left)
	    {
	      free (raw_file);
	      return;
	    }
	}
      d = dstream_read_item (ds, unsigned short);
      if (d != *((unsigned short *) &"kf"))
	{
	  error_str = "Invalid mercenary section trailer";
	  free (raw_file);
	  print_message ("%s: %s", filename, error_str);
	  return;
	}
      d = dstream_read_item (ds, char);
      if (d)
	{
	  error_str = "Invalid trailing null byte";
	  free (raw_file);
	  print_message ("%s: %s", filename, error_str);
	  return;
	}
    }

  /* We expect to be at the end of the file now. */
  if (ds.ptr != ds.end)
    {
      if (ds.ptr > ds.end)
	error_str = "Unexpected end-of-file";
      else
	error_str = "Excess data in file";
      free (raw_file);
      print_message ("%s: %s", filename, error_str);
      return;
    }

  /* Now that we've read the whole file, we can release the raw data,
     save the filename, and call it good. */
  free (raw_file);
  this->filename = xstrdup (filename);
  return;
}

/* Free all resources held by a d2sData object */
d2sData::~d2sData ()
{
  d2sItem *item, *next_item;

  /* Remove all items in all item lists */
  for (item = item_list.head; item != NULL; item = next_item)
    {
      next_item = item->next;
      delete item;
    }

  for (item = corpse_item_list.head; item != NULL; item = next_item)
    {
      next_item = item->next;
      delete item;
    }

  for (item = hireling_item_list.head; item != NULL; item = next_item)
    {
      next_item = item->next;
      delete item;
    }

  if (filename != NULL)
    free ((void *) filename);
}

/* Set the associated User Interface data for the object.
   We only allow this to be set once; not changed. */
int
d2sData::SetUI (void *uid)
{
  if ((ui_data != NULL) && (uid != NULL))
    return -1;
  ui_data = uid;
  return 0;
}

/* Save a character file under the same name; returns 0 on success.
   If the file has no associated name, use the character's name with a
   ".d2s" extension and save it to the current directory. */
int
d2sData::Save (void)
{
  char *new_filename = NULL, *backup_name = NULL;
  int fd, status;

  if (filename == NULL)
    {
      new_filename = (char *) xmalloc (strlen (name) + sizeof (".d2s") + 1);
      sprintf (new_filename, "%s.d2s", name);
      if (access (new_filename, F_OK) == 0)
	{
	  /* A file with this name already exists! */
	  if (display_question (0, 2, "Cancel", "Replace",
				"A file named %s already exists.  Do you"
				" wish to replace it with this character?",
				new_filename) == 0)
	    {
	      free (new_filename);
	      error_str = "File name conflict";
	      return -1;
	    }
	  backup_name = backup_old_file (new_filename);
	  if (backup_name == NULL)
	    {
	      free (new_filename);
	      error_str = "File name conflict";
	      return -1;
	    }
	}
      else if (errno != ENOENT)
	{
	  /* There is an unknown problem with the default path */
	  error_str = strerror (errno);
	  print_message ("%s: %s.", new_filename, error_str);
	  free (new_filename);
	  return -1;
	}
    }

  else
    {
      if (access (filename, F_OK) == 0)
	{
	  /* A file with this name already exists.  But we knew that,
	     since we either loaded that file or had previously saved
	     it.  In either case, back up the existing file. */
	  backup_name = backup_old_file (filename);
	  if (backup_name == NULL)
	    {
	      if (display_question (0, 2, "Cancel", "Overwrite",
				    "Do you wish to continue saving your"
				    " character to %s without making a"
				    " backup?", filename) == 0)
		{
		  print_message ("Save cancelled; unable to make a backup.\n");
		  error_str = "Unable to make backup";
		  return -1;
		}
	    }
	}
      else if (errno != ENOENT)
	{
	  /* There is an unknown problem with the original filename */
	  error_str = strerror (errno);
	  print_message ("%s: %s.", filename, error_str);
	  return -1;
	}
    }

  /* Open the file for writing */
  fd = open ((filename == NULL) ? new_filename : filename,
	     O_WRONLY | O_CREAT | O_TRUNC,
	     S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  if (fd < 0)
    {
      error_str = strerror (errno);
      print_message ("%s: %s.",
		     (filename == NULL) ? new_filename : filename, error_str);
      if (backup_name != NULL)
	{
	  rename (backup_name, (filename == NULL) ? new_filename : filename);
	  free (backup_name);
	}
      if (new_filename != NULL)
	free (new_filename);
      return -1;
    }

  /* Write the game */
  status = Write (fd);
  close (fd);

  /* If a failure occurred during write,
     don't bother restoring the backup or deleting the bad file. */
  if (backup_name != NULL)
    free (backup_name);
  if (filename == NULL)
    {
      if (status == 0)
	filename = new_filename;
      else
	free (new_filename);
    }

  return status;
}

/* Save a character file using a new name; retuns 0 on success.
   Changes the associated filename on success (but not on error). */
int
d2sData::SaveAs (const char *new_filename)
{
  char *strp, *revised_filename, *backup_name = NULL;
  int fd, status;

  if (new_filename == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: NULL argument to"
		 " d2sData::SaveAs(const char *)\n", progname);
      error_str = "Invalid filename";
      return -1;
    }
  /* Make some slight adjustments to the filename.
     If it has no extension, append ".d2s". */
  revised_filename = (char *) xmalloc (strlen (new_filename) + 8);
  strcpy (revised_filename, new_filename);
  strp = strrchr (revised_filename, '/');
  if (strp == NULL)
    strp = revised_filename;
  strp = strchr (strp, '.');
  if (strp == NULL)
    strcat (revised_filename, ".d2s");
  else
    {
      /* Check whether the given extension contains ".d2s".
	 If not, warn the user about using an invalid extension. */
      if (strstr (revised_filename, ".d2s") == NULL)
	{
	  if (!display_question
	      (0, 2, "No", "Yes",
	       "The extension \"%s\" is not recognized; Diablo II characters"
	       " need the extension \".d2s\".  Do you wish to save the file"
	       " anyway?", strp))
	    {
	      error_str = "Invalid file extension";
	      print_message (error_str);
	      return -1;
	    }
	}
    }

  /* Does this file already exist? */
  if (access (revised_filename, F_OK) == 0)
    {
      /* Ask the user whether to backup the existing file or overwrite it */
      status = display_question
	(1, 3, "Cancel", "Back up", "Overwrite",
	 "A file named %s already exists.  Do you wish to back up the"
	 " existing file before proceeding, or overwrite it?",
	 revised_filename);
      if (!status)
	{
	  print_message ("Save cancelled due to filename conflict.\n");
	  error_str = "File name conflict";
	  return -1;
	}
      if (status == 1)
	{
	  backup_name = backup_old_file (revised_filename);
	  if (backup_name == NULL)
	    return -1;
	}
    }

  /* Open the file for writing */
  fd = open (revised_filename, O_WRONLY | O_CREAT | O_TRUNC,
	     S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  if (fd < 0)
    {
      error_str = strerror (errno);
      print_message ("%s: %s.", revised_filename, error_str);
      if (backup_name != NULL)
	{
	  rename (backup_name, revised_filename);
	  free (backup_name);
	}
      free (revised_filename);
      return -1;
    }

  /* Write the game */
  status = Write (fd);
  close (fd);

  /* If a failure occurred during write, don't bother restoring
     the backup or deleting the bad file.  If the write succeeded,
     replace any previous file name with the new one. */
  if (backup_name != NULL)
    free (backup_name);
  if (status == 0)
    {
      if (filename == NULL)
	free ((char *) filename);
      filename = revised_filename;
    }
  else
    free (revised_filename);

  return status;
}

/* Write the character to the given file descriptor.
   Called by Save() and SaveAs(filename) once they figure
   out which file they're saving to. */
int
d2sData::Write (int fd)
{
  struct d2s_header *	file_header;
  struct data_stream	ds;
  unsigned long		length;
  unsigned short	stats_bitfield;
  int			i, d, act;
  unsigned char *	ptr;
  d2sItem *		item;

  /* Before writing anything to fd, we must create the entire file
     in memory.  Start by allocating a buffer large enough to hold
     the fixed part of the file plus all stats and skills. */
  length = sizeof (struct d2s_header) + 17 * sizeof (long) + 32;
  file_header = (struct d2s_header *) xmalloc (length);
  dstream_set (ds, file_header, 0, length);

  /* Copy our saved raw header in order to place values
     which haven't been handled yet. */
  dstream_write (&ds, raw_header, sizeof (struct d2s_header));

  /* Copy (possibly modified) fields from our object to the file header. */
  memcpy (file_header->name, name, sizeof (name));
  file_header->char_status = char_status;
  file_header->char_title = char_title;
  file_header->char_class = char_class;
  file_header->level = level;
  /* The timestamp is rewritten with the current time. */
  timestamp = (unsigned long) time (NULL);
  file_header->timestamp = timestamp;
  file_header->hireling_died = hireling_status;
  file_header->hireling_id = hireling_id;
  file_header->hireling_name = hireling_name;
  file_header->hireling_attribute = hireling_attribute;
  file_header->hireling_experience = hireling_experience;
  memcpy (file_header->difficulty, difficulty_active, NUM_DIFFICULTY_LEVELS);

  for (d = 0; d < NUM_DIFFICULTY_LEVELS; d++) {
    for (act = 0; act < 3; act++) {
      file_header->quests[d].act[act].intros = quest_data[d].act[act].intros;
      for (i = 0; i < MAX_NUM_QUESTS; i++)
	file_header->quests[d].act[act].quests[i]
	  = quest_data[d].act[act].quest[i];
      file_header->quests[d].act[act].completed
	= quest_data[d].act[act].completed;
    }
    file_header->quests[d].act_4.intros = quest_data[d].act[3].intros;
    for (i = 0; i < 3; i++)
      file_header->quests[d].act_4.quests[i] = quest_data[d].act[3].quest[i];
    file_header->quests[d].act_4.completed = quest_data[d].act[3].completed;
    file_header->quests[d].act_5.intros = quest_data[d].act[4].intros;
    for (i = 0; i < 6; i++)
      file_header->quests[d].act_5.quests[i] = quest_data[d].act[4].quest[i];
    file_header->quests[d].act_5.completed = quest_data[d].act[4].completed;
  }

  for (d = 0; d < NUM_DIFFICULTY_LEVELS; d++) {
    struct bit_stream bs;
    bstream_set (bs, &file_header->waypoints[d].points, 0,
		 sizeof (file_header->waypoints[d].points));
    for (act = 0; act < MAX_NUM_ACTS; act++)
      bstream_write_field (&bs, GetNumberOfWaypointsInAct (act),
			   waypoints[d][act]);
  }

  /* We've arrived at the statistics structure.  Since
     dstream_write() above has already set the pointer to the byte
     following the stats magic header ("gf"), we can go straight
     into the next bitfield. */

  /* Assume certain fields are always present.  (If they've been set
     to zero, we'll just write out zeroes.  Reserve the space anyway.) */
  stats_bitfield = 0x1fcf;
#define bit(n) (1 << (n))
  if (stats.statp_remaining)
    stats_bitfield |= bit(4);
  if (stats.skillp_remaining)
    stats_bitfield |= bit(5);
  if (stats.experience)
    stats_bitfield |= bit(13);
  if (stats.gold_in_inventory)
    stats_bitfield |= bit(14);
  if (stats.gold_in_stash)
    stats_bitfield |= bit(15);
  dstream_write (&ds, &stats_bitfield, sizeof (short));
  dstream_write (&ds, &stats.strength, sizeof (long));
  dstream_write (&ds, &stats.energy, sizeof (long));
  dstream_write (&ds, &stats.dexterity, sizeof (long));
  dstream_write (&ds, &stats.vitality, sizeof (long));
  if (stats_bitfield & bit(4))
    dstream_write (&ds, (unsigned char *)
		   &stats.statp_remaining, sizeof (long));
  if (stats_bitfield & bit(5))
    dstream_write (&ds, (unsigned char *)
		   &stats.skillp_remaining, sizeof (long));
  dstream_write (&ds, &stats.life.current, sizeof (long));
  dstream_write (&ds, &stats.life.base, sizeof (long));
  dstream_write (&ds, &stats.mana.current, sizeof (long));
  dstream_write (&ds, &stats.mana.base, sizeof (long));
  dstream_write (&ds, &stats.stamina.current, sizeof (long));
  dstream_write (&ds, &stats.stamina.base, sizeof (long));
  dstream_write (&ds, &stats.level, sizeof (long));
  if (stats_bitfield & bit(13))
    dstream_write (&ds, &stats.experience, sizeof (long));
  if (stats_bitfield & bit(14))
    dstream_write (&ds, &stats.gold_in_inventory, sizeof (long));
  if (stats_bitfield & bit(15))
    dstream_write (&ds, &stats.gold_in_stash, sizeof (long));
#undef bit

  /* Write out the skill header, followed by the skill data. */
  dstream_write (&ds, &"if", 2);
  dstream_write (&ds, &skill_data, NUM_SKILLS_PER_CHAR);

  /* This is probably the most crucial variable part: Items.
     Our internal item list MUST BE CONSISTENT. */
  dstream_write (&ds, &"JM", 2);
  ptr = ds.ptr;		// Save in case we need to make a correction
  dstream_write (&ds, &item_list.count,
		 sizeof (short));	// Little-endian dependency
  item = item_list.head;
  /* The (i < 128) is here to prevent bad item links from creating
     an infinite loop.  The *maximum* number of items one can have
     is 126: 40 in the inventory, 48 in the Expanded stash, 12 in
     the Cube (-3 for having the Cube), 16 in the belt, 12 equipped,
     and one picked up by the mouse. */
  for (i = 0; (i < 128) && (item != NULL); i++, item = item->next)
    item->Write (&ds);
  if (i != item_list.count)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error in %s's d2sData:\n"
		 " item list count (%d) does not match the\n"
		 " number of items linked (%s%d)\n",
		 progname, name, item_list.count,
		 (item != NULL) ? "more than " : "", i);
      error_str = "Internal error in item list";
      /* Correct the stored item count and keep going for now. */
      *((unsigned short *) ptr) = i;
    }

  if (corpse_data[2])
    dstream_write (&ds, &corpse_data[0], sizeof (corpse_data));
  dstream_write (&ds, &"JM", 2);
  ptr = ds.ptr;		// Save in case we need to make a correction
  dstream_write (&ds, &corpse_item_list.count,
		 sizeof (short));	// Little-endian dependency
  item = corpse_item_list.head;
  /* A corpse can only have equipped items; the real limit is 12. */
  for (i = 0; (i < 16) && (item != NULL); i++, item = item->next)
    item->Write (&ds);
  if (i != corpse_item_list.count)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error in %s's d2sData:\n"
		 " corpse item list count (%d) does not match the\n"
		 " number of items linked (%s%d)\n",
		 progname, name, corpse_item_list.count,
		 (item != NULL) ? "more than " : "", i);
      error_str = "Internal error in corpse item list";
      /* Correct the stored item count and keep going for now. */
      *((unsigned short *) ptr) = i;
    }

  if (is_expansion())
    {
      dstream_write (&ds, &"jf", 2);
      if (hireling_id)
	{
	  dstream_write (&ds, &"JM", 2);
	  ptr = ds.ptr;		// Save in case we need to make a correction
	  dstream_write (&ds, &hireling_item_list.count,
			 sizeof (short));	// Little-endian dependency
	  item = hireling_item_list.head;
	  /* A hireling can only have equipped items; the real limit is 4. */
	  for (i = 0; (i < 12) && (item != NULL); i++, item = item->next)
	    item->Write (&ds);
	  if (i != hireling_item_list.count)
	    {
	      if (debug)
		fprintf (stderr, "%s: Internal error in %s's d2sData:\n"
			 " mercenary item list count (%d) does not match the\n"
			 " number of items linked (%s%d)\n",
			 progname, name, hireling_item_list.count,
			 (item != NULL) ? "more than " : "", i);
	      error_str = "Internal error in mercenary item list";
	      /* Correct the stored item count and keep going for now. */
	      *((unsigned short *) ptr) = i;
	    }
	}
      dstream_write (&ds, &"kf", 3);
    }

  /* This is the official end of the file. */
  ds.size = (unsigned long) (ds.ptr - ds.base);
  /* Remember that ds.base probably has changed,
     since each dstream_write() can call xrealloc(). */
  file_header = (struct d2s_header *) ds.base;
  file_header->length = ds.size;

  /* Compute the file's checksum. */
  compute_checksum (ds.base);

  /* Write the file. */
  length = write (fd, ds.base, ds.size);
  if (length < ds.size)
    {
      error_str = strerror (errno);
      print_message ("Error saving the game: %s.\n", error_str);
      free (file_header);
      return -1;
    }

  /* With the file successfully written, update our own backup fields
     to reflect the new state of the file. */
  memcpy (raw_header, file_header, sizeof (raw_header));
  memcpy (&backup_stats, &stats, sizeof (stats));
  memcpy (&backup_skill_data, &skill_data, sizeof (skill_data));
  free (file_header);

  /* This character is clean. */
  dirty = False;
  return 0;
}

const char *
d2sData::GetCharacterTitle (void) const
{
  return title_names[is_expansion() ? 1 : 0]
    [is_hardcore() ? 1 : 0]
    [class_genders[char_class]][char_title / NumberOfActs()];
}

const char *
d2sData::GetCharacterClassName (void) const
{ return class_names[char_class]; }

/**************** MODIFICATION SECTION ****************/

/* Convert a standard character to an expansion character.
   This direction is relatively simple, because an expansion
   character is a superset of the standard. */
int
d2sData::ConvertToExpansion (void)
{
  if (is_expansion ())
    /* No conversion needed */
    return 0;

  /* Is changing the character allowed? */
  if (read_only || !options.character.edit.expansion)
    {
      error_str = "You may not convert the character";
      print_message (error_str);
      return -1;
    }

  /* Set the expansion bit */
  char_status |= 0x20;
  MarkDirty ();
  return 0;
}

/* Convert an expansion character to a standard character.
   This direction is problematic, because a standard
   character is a subset of the expansion. */
int
d2sData::ConvertToStandard (void)
{
  int difficulty, row, col;
  d2sItem *item;

  if (!is_expansion ())
    /* No conversion needed */
    return 0;

  /* Is changing the character allowed? */
  if ((char_class >= DRUID_CLASS) && !options.character.link.freeform)
    {
      error_str = ("This character class is required"
		   " to be an expansion character");
      print_message (error_str);
      return -1;
    }
  if (read_only || !options.character.edit.expansion
      || !options.character.edit.backward)
    {
      /* Was this an Expansion character when we loaded it? */
      struct d2s_header *file_header = (struct d2s_header *) &raw_header;
      if (file_header->char_status & 0x20)
	{
	  error_str = "You may not convert the character";
	  print_message (error_str);
	  return -1;
	}
    }

  if (!options.character.link.freeform)
    {
      /* Check for anything that is not allowed in a standard
	 character.  Specifically, quests/waypoints enabled in Act V,
	 items equipped on a hireling, items equipped on alternate
	 hands, items stored in the lower half of the expanded stash,
	 or items which are specific to the Expansion Set. */
      for (difficulty = 0; difficulty < NUM_DIFFICULTY_LEVELS; difficulty++)
	{
	  if (quest_data[difficulty].act[3].completed
	      || memcmp (&quest_data[difficulty].act[4],
			 &((char *) &quest_data[difficulty].act[4])[1],
			 sizeof (quest_data[difficulty].act[4]) - 1)
	      || waypoints[difficulty][4])
	    {
	      error_str = ("You cannot convert this character to standard"
			   " after entering Act V");
	      print_message (error_str);
	      return -1;
	    }
	}
      if (hireling_item_list.head != NULL)
	{
	  error_str = ("A standard character may not have any equipment"
		       " on the mercenary");
	  print_message (error_str);
	  return -1;
	}
      if ((equipment[EQUIPPED_ON_ALT_RIGHT_HAND] != NULL)
	  || (equipment[EQUIPPED_ON_ALT_LEFT_HAND] != NULL))
	{
	  error_str = ("A standard character may not have"
		       " an alternate weapon or shield equipped");
	  print_message (error_str);
	  return -1;
	}
      for (row = VSIZE_STASH / 2; row < VSIZE_STASH; row++)
	for (col = 0; col < HSIZE_STASH; col++)
	  {
	    if (stash[row][col] != NULL)
	      {
		error_str = ("Your stashed items would overflow a"
			     " standard size stash");
		print_message (error_str);
		return -1;
	      }
	  }
      for (item = item_list.head; item != NULL; item = item->next)
	{
	  if (item->is_expansion_item()) {
	    if (!options.item.link.item_expansion
		/* This trick allows us to see whether an item is actually
		   an expansion item, or simply has expansion mods. */
		|| item->d2sItem::is_expansion_item()) {
	    cant_carry_expansion_items:
	      error_str = ("You are carrying items specific"
			   " to the Expansion Set");
	      print_message (error_str);
	      return -1;
	    }
	    if ((item->Type() == ARMOR_ITEM)
		|| (item->Type() == WEAPON_ITEM)) {
	      /* We also need to see whether there are
		 any attached runes or jewels */
	      d2sDurableItem *ditem = (d2sDurableItem *) *item;
	      for (col = 0; col < ditem->NumberOfGems(); col++) {
		if (ditem->Gem(col)->is_expansion_item())
		  goto cant_carry_expansion_items;
	      }
	    }
	  }
	}
      for (item = corpse_item_list.head; item != NULL; item = item->next)
	{
	  if (item->is_expansion_item()) {
	    if (!options.item.link.item_expansion
		|| item->d2sItem::is_expansion_item()) {
	    corpse_cant_carry_expansion_items:
	      error_str = ("Your corpse has items specific"
			   " to the Expansion Set");
	      print_message (error_str);
	      return -1;
	    }
	    if ((item->Type() == ARMOR_ITEM)
		|| (item->Type() == WEAPON_ITEM)) {
	      /* We also need to see whether there are
		 any attached runes or jewels */
	      d2sDurableItem *ditem = (d2sDurableItem *) *item;
	      for (col = 0; col < ditem->NumberOfGems(); col++) {
		if (ditem->Gem(col)->is_expansion_item())
		  goto corpse_cant_carry_expansion_items;
	      }
	    }
	  }
	}
    }

  /* Clear the expansion bit.  No guarantees. */
  char_status &= ~0x20;
  MarkDirty ();
  return 0;
}

/* Change the state of the hardcore or died bits */
int
d2sData::SetHardcore (int new_hardcore)
{
  if (is_hardcore() == (new_hardcore != 0))
    /* Nothing needs to be done */
    return 0;

  /* Is changing the hardcore state allowed? */
  if (read_only || !options.character.edit.hardcore)
    {
      error_str = "You may not change whether the character is hardcore";
      print_message (error_str);
      return -1;
    }

  /* If enabling hardcore mode, has the character died? */
  if (new_hardcore && has_died() && !options.character.link.freeform)
    {
      error_str = ("You may not switch to hardcore mode;"
		   " the character has previously died in a game");
      print_message (error_str);
      return -1;
    }

  if (new_hardcore)
    char_status |= 0x04;
  else
    char_status &= ~0x04;
  MarkDirty();
  return 0;
}

int
d2sData::SetDied (int new_died)
{
  int		e;

  if (has_died() == (new_died != 0))
    /* Nothing needs to be done */
    return 0;

  /* Is changing the death state allowed? */
  if (read_only || !options.character.edit.died)
    {
      error_str = "You do not have power over life and death";
      print_message (error_str);
      return -1;
    }

  /* Does the character have a corpse? */
  if (!new_died && (corpse_item_list.head != NULL))
    {
      /* Can we move the corpse items to the living? */
      if (!options.character.edit.inventory
	  || !options.character.edit.corpse_inventory)
	{
	  error_str = "You cannot resurrect your corpse while it is equipped";
	  print_message (error_str);
	  return -1;
	}
      for (e = 0; e < MSIZE_EQUIPMENT; e++)
	if (equipment[e] != NULL)
	  {
	    if (options.character.link.freeform)
	      break;
	    error_str = "Unable to retrieve equipment from corpse";
	    print_message (error_str);
	    return -1;
	  }

      if (e >= MSIZE_EQUIPMENT)
	{
	  /* Move the equipment */
	  for (e = 0; e < MSIZE_EQUIPMENT; e++)
	    {
	      if (corpse_equipment[e] == NULL)
		continue;
	      remove_from_item_list (&corpse_item_list, corpse_equipment[e]);
	      equipment[e] = corpse_equipment[e];
	      corpse_equipment[e] = NULL;
	      equipment[e]->AssignTo (this, ITEM_AREA_EQUIPPED);
	      append_to_item_list (&item_list, equipment[e]);
	    }
	  /* Flag the corpse as gone */
	  corpse_data[2] = 0;

	  /* If a belt was among the equipment, change the belt size. */
	  if (equipment[EQUIPPED_ON_WAIST] != NULL)
	    {
	      if (equipment[EQUIPPED_ON_WAIST]->Type() == ARMOR_ITEM)
		belt_size
		  = ((d2sArmorItem *) (d2sDurableItem *)
		     *equipment[EQUIPPED_ON_WAIST])->NumberOfBoxesInBelt();
	      else
		/* Don't know what type of belt it is; start with 2 rows */
		belt_size = 8;
	    }
	}
    }

  /* If resurrecting, make sure the character's
     life is non-zero (lest he die again!) */
  if (!new_died && !stats.life.current)
    stats.life.current = 256;

  if (new_died)
    char_status |= 0x08;
  else
    char_status &= ~0x08;
  MarkDirty();
  return 0;
}

/* Check whether a character name is valid.  Follow Diablo II rules. */
int
d2sData::validate_name (const char *new_name)
{
  int len, dash_seen = 0;

  for (len = 0; (len < (int) sizeof (name)) && new_name[len]; len++)
    {
      if ((new_name[len] == '-') || (new_name[len] == '_'))
	{
	  dash_seen++;
	  continue;
	}
      if (!isalpha (new_name[len]) && !options.character.link.freeform)
	{
	  error_str = "Invalid name";
	  return -1;
	}
    }

  if ((dash_seen > 1) && !options.character.link.freeform)
    {
      error_str = "Too many dashes";
      return -1;
    }

  if (len < (options.character.link.freeform ? 1 : 2))
    {
      error_str = "Name too short";
      return -1;
    }
  if (len > 15)
    {
      error_str = "Name too long";
      return -1;
    }

  if (!options.character.link.freeform)
    {
      if ((new_name[0] == '-') || (new_name[0] == '_'))
	{
	  error_str = "Name may not begin with a dash";
	  return -1;
	}
      if ((new_name[len - 1] == '-') || (new_name[len - 1] == '_'))
	{
	  error_str = "Name may not end with a dash";
	  return -1;
	}
    }
  return 0;
}

/* Change the name of the character. */
int
d2sData::SetCharacterName (const char *new_name)
{
  int len;

  /* Is changing the name allowed? */
  if (read_only || !options.character.edit.name)
    {
      error_str = "You may not change the character's name";
      print_message (error_str);
      return -1;
    }

  /* Make sure the new name is valid */
  if (validate_name (new_name) < 0)
    {
      print_message (error_str);
      return -1;
    }

  /* The name passed.  Change it. */
  len = strlen (new_name);
  memcpy (name, new_name, len);
  memset (&name[len], 0, sizeof (name) - len);
  MarkDirty ();
  return 0;
}
