/* Diablo II v1.09 Character Editor, text based (old; needs to go away)
 * Copyright (C) 2001 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <errno.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "items.h"

struct d2s_header {
  unsigned long magic;		/* 0xaa55aa55 */
  unsigned long version;	/* 71 for v1.00-v1.06, 87 for v1.07-v1.08
				   (expansion), 89 for v1.08 (normal),
				   92 for v1.09 */
  unsigned long length;		/* file size */
  unsigned long checksum;
  unsigned long unknown10;	/* 0; changed to 1 for Dru.22 and back for Dru.23, 1 again for Dru.24 */
  char name[16];		/* _null-terminated_ character name */
  unsigned char character_status:3; /* killed, resurrected, hardcore, dead? */
  unsigned char character_died:1;
  unsigned char unknown24_4:1;
  unsigned char expansion:1;	/* Lord of Destruction game */
  unsigned char unknown24_6:2;
  unsigned char unknown25:2;
  unsigned char title:2;	/* 1 = sir/dame, 2 = lord/lady, 3 = baron/baroness */
  unsigned char unknown25_4:4;
  unsigned char unknown26[2];	/* 0 */
  unsigned char class;		/* type of character */
  unsigned char unknown29[2];	/* { 16, 30 } */
  unsigned char level;		/* as shown on character selection screen */
  unsigned long unknown2c;	/* 0 */
  unsigned long timestamp;
  unsigned short unknown34[34]; /* 0's and -1's */
  unsigned long button_action[4]; /* Skill / action ID #; left, right,
				     alt. left, alt. right */
  unsigned char unknown88[10];	/* 2's, 3's, a 5, 60, 79, and -1 */
  /*	Unknown88 notes:
	In a brand-new game, byte 0x8d is 0x1b for Amazon, 0x2d for Assassin,
	    0x04 for Barbarian, 0x0c for Druid, 0x09 for Necromancer,
	    0x11 for Paladin, and 0x24 for Sorceress.
	In a brand-new game, byte 0x8f is set to 0xff for most characters,
	    but is 0x4f for the Druid and Paladin.
	bytes 0x88-0x8c and 0x90-0x91 changed from all -1's to { 57, 1, 1,
	    1, 1 }, { 2, 2 } and then back to -1's during the course of
	    Quest 1, then back to the same positive values later on.
	In a Sorceress game, byte 0x88 changed from -1 to 57 (set is
	    { 57, 1, 1, 1, 1, 37, -1, -1, 2, 2, -1, ... }).
	In a Druid game, bytes 0x88-0x8c and 0x90-0x91 changed from all -1's
	    to { -1, 1, 1, 1, 1 } { 2, 2 } after killing the monsters for Q1.
	    Bytes 0x88-0x91 then changed to { 57, 2, 1, 1, 1, 0x11, 0xff,
	    0x4f, 2, 2 } sometime during Q2.  Byte 0x8d changed back to
	    0x0c after completing Q2, then reversed again to 0x11 after
	    receiving a new quest.
	No change for adding a new skill (sorry).
	These bytes appear to change even when not doing a quest.
	Maybe they're related to location...?
   */
  unsigned char unknown92[22];	/* mostly -1's, except for one 168 or some 68's */
  /*  */
  unsigned char difficulty[3];	/* non-zero in [0] for normal,
				   [1] for nightmare, [2] for hell */
  /* The difficulty changed from 0x80 to 0x81
     after taking the caravan from Act I to Act II. */
  unsigned long map_id; 	/* Corresponds with one of the longwords
				   in the .map file, according to which
				   map is in use? */
  unsigned short unknownaf;	/* 0 */
  unsigned short hireling_died;
  unsigned long hireling_id;
  unsigned short hireling_name;
  unsigned short hireling_attribute;
  unsigned long hireling_experience;
  unsigned char unknownbf[144]; /* all zeroes */
  unsigned char magic14f[4];	/* "Woo!" */
  unsigned char unknown153[6];	/* the quest completion data is in here */
  struct {
    struct {
      unsigned short intros;
      /*	Intro notes:
		It looks like act[0].intros gets set after you talk to Warriv.
       */
      unsigned short quests[6]; /* Looks like bit 0 is set if started, bit 12
				   is set if completed.  Other bits vary */
      /*	Quest notes:
		act[0].quests[0] changed from 0 to 4 when Akara gave quest to Assassin.
       */
      unsigned short completed;
      /* act[0].completed changed from 0 to 0x2001
	 after travelling to Lut Gholein. */
    } act[3];
    struct {
      unsigned short intros;
      unsigned short quests[3];
      unsigned short completed;
    } act_4;
    unsigned short unknown_58[3];
    unsigned short talked_to_cain_in_act_IV;
    unsigned short unknwon_66;
    struct {
      unsigned short intros;
      unsigned short quests[6];
      unsigned short completed;
    } act_5;
    unsigned short unknown_84[6]; /* all zeroes */
  } quests[3];			/* One structure per difficulty level */
  unsigned char magic279[2];	/* "WS" */
  unsigned char unknown27b[6]; /* sparse data */
  struct {
    unsigned char unknown[2];	/* { 2, 1 } */
    unsigned char points[5];	/* LSB is 1st waypoint of act 1; */
    /* continues consecutively to bit 29 = last waypoint of act 4
       (9 each in acts 1-3, 3 in act 4), and bit 30 = first waypoint
       of act 5.*/
    /* It looks like the 1st waypoint in an act is
       automatically set as soon as that act is entered. */
    unsigned char unknown_6[17]; /* zeroes */
  } __attribute__
  ((packed)) waypoints[3]; /* One structure per difficulty level */
  unsigned char unknown2c9;
  unsigned char magic2ca[2];	/* "w4" */
  unsigned char introductions[3][8];	/* 8 bytes for each difficulty */
  unsigned char congratulations[3][8];	/* 8 bytes for each difficulty */
  unsigned char unknown2fc;
  /* Byte 0x2e5 changed from 0 to 0x7e after travelling to Lut Gholein. */
  unsigned char magic2fd[2];	/* "gf" */
  unsigned short stat_bits;
  unsigned long stats[0];
} __attribute__ ((packed));

/* The following structure may not be fully correct. */
struct d2s_stats {
  unsigned char has_strength:1; /* unconfirmed; must always be true */
  unsigned char has_energy:1; /* unconfirmed; must always be true */
  unsigned char has_dexterity:1; /* unconfirmed; must always be true */
  unsigned char has_vitality:1; /* unconfirmed; must always be true */
  unsigned char has_stat_points_remaining:1;
  unsigned char has_skill_choices_remaining:1;
  unsigned char has_life:1; /* unconfirmed; must always be true */
  unsigned char has_max_life:1; /* unconfirmed; must always be true */
  unsigned char has_mana:1; /* unconfirmed; must always be true */
  unsigned char has_max_mana:1; /* unconfirmed; must always be true */
  unsigned char has_stamina:1; /* unconfirmed; must always be true */
  unsigned char has_max_stamina:1; /* unconfirmed; must always be true */
  unsigned char has_level:1; /* unconfirmed; must always be true (there is no level 0) */
  unsigned char has_experience:1; /* confirmed! */
  unsigned char has_gold:1;
  unsigned char stashed_gold:1;
} __attribute__ ((packed));

/* If the player has any stat points remaining or skill choices remaining,
 * they are stored in the next one or two longwords. */

struct d2s_stats2 {
  unsigned long strength;
  unsigned long energy;
  unsigned long dexterity;
  unsigned long vitality;
  unsigned long stat_points;
  unsigned long skill_points;
  unsigned long life_current, life_max;
  unsigned long mana_current, mana_max;
  unsigned long stamina_current, stamina_max;
  unsigned long level;
  unsigned long experience;
  unsigned long money;
  unsigned long stashed_gold;
};

union d2s_skills {
  unsigned char magic[2];	/* "if" */
  struct {
    unsigned char magic[2];
    unsigned char magic_arrow, fire_arrow;
    unsigned char inner_sight, critical_strike;
    unsigned char jab;
    unsigned char cold_arrow, multiple_shots;
    unsigned char dodge;
    unsigned char power_strike, poison_javelin;
    unsigned char exploding_arrow;
    unsigned char slow_missiles, avoid;
    unsigned char impale, lightning_bolt;
    unsigned char ice_arrow, guided_arrow;
    unsigned char penetrate;
    unsigned char charged_strike, plague_javelin;
    unsigned char strafe, immolation_arrow;
    unsigned char decoy, evade;
    unsigned char fend;
    unsigned char freezing_arrow;
    unsigned char valkyrie, pierce;
    unsigned char lightning_strike, lightning_fury;
  } amazon;
  struct {
    unsigned char magic[2];
    unsigned char fire_bolt, warmth;
    unsigned char charged_bolt;
    unsigned char ice_bolt, frozen_armor;
    unsigned char inferno;
    unsigned char static_field, telekinesis;
    unsigned char frost_nova, ice_blast;
    unsigned char blaze, fire_ball;
    unsigned char nova, lightning;
    unsigned char shiver_armor;
    unsigned char fire_wall, enchant;
    unsigned char chain_lightning, teleport;
    unsigned char glacial_spike;
    unsigned char meteor;
    unsigned char thunderstorm, energy_shield;
    unsigned char blizzard, chilling_armor;
    unsigned char fire_mastery, hydra;
    unsigned char lightning_mastery;
    unsigned char frozen_orb, cold_mastery;
  } sorceress;
  struct {
    unsigned char magic[2];
    unsigned char amplify_damage;
    unsigned char teeth, bone_arrow;
    unsigned char skeleton_mastery, raise_skeleton;
    unsigned char dim_vision, weaken;
    unsigned char poison_dagger, corpse_explosion;
    unsigned char clay_golem;
    unsigned char iron_maiden, terror;
    unsigned char bone_wall;
    unsigned char golem_mastery, raise_skeletal_mage;
    unsigned char confuse, life_tap;
    unsigned char poison_explosion, bone_spear;
    unsigned char blood_golem;
    unsigned char attract, decrepify;
    unsigned char bone_prison;
    unsigned char summon_resist, iron_golem;
    unsigned char lower_resist;
    unsigned char poison_nova, bone_spirit;
    unsigned char fire_golem, revive;
  } necromancer;
  struct {
    unsigned char magic[2];
    unsigned char sacrifice, smite;
    unsigned char might;
    unsigned char prayer, resist_fire;
    unsigned char holy_bolt;
    unsigned char holy_fire, thorns;
    unsigned char defiance, resist_cold;
    unsigned char zeal, charge;
    unsigned char blessed_aim;
    unsigned char cleansing, lightning_resist;
    unsigned char vengeance, blessed_hammer;
    unsigned char concentration, holy_freeze;
    unsigned char vigor;
    unsigned char conversion, holy_shield;
    unsigned char holy_shock, sanctuary;
    unsigned char meditation;
    unsigned char fist_of_the_heavens;
    unsigned char fanaticism, conviction;
    unsigned char redemption, salvation;
  } paladin;
  struct {
    unsigned char magic[2];
    unsigned char bash;
    unsigned char sword_mastery, axe_mastery, mace_mastery;
    unsigned char howl;
    unsigned char find_potion;
    unsigned char leap, double_swing;
    unsigned char polearm_mastery, throwing_mastery, spear_mastery;
    unsigned char taunt, shout;
    unsigned char stun, double_throw;
    unsigned char increased_stamina;
    unsigned char find_item;
    unsigned char leap_attack, concentrate;
    unsigned char iron_skin;
    unsigned char battle_cry;
    unsigned char frenzy;
    unsigned char increased_speed;
    unsigned char battle_orders, grim_ward;
    unsigned char whirlwind, berserk;
    unsigned char natural_resistance;
    unsigned char warcry, battle_command;
  } barbarian;
  struct {
    unsigned char magic[2];
    unsigned char raven, poison_creeper;
    unsigned char werewolf, lycanthropy;
    unsigned char firestorm;
    unsigned char oak_sage, summon_spirit_wolf;
    unsigned char werebear;
    unsigned char molten_boulder, arctic_blast;
    unsigned char carrion_vine;
    unsigned char feral_rage, maul;
    unsigned char fissure, cyclone_armor;
    unsigned char heart_of_wolverine, summon_dire_wolf;
    unsigned char rabies, fire_claws;
    unsigned char twister;
    unsigned char solar_creeper;
    unsigned char hunger, shock_wave;
    unsigned char volcano, tornado;
    unsigned char spirit_of_barbs, summon_grizzly;
    unsigned char fury;
    unsigned char armageddon, hurricane;
  } druid;
  struct {
    unsigned char magic[2];
    unsigned char fire_blast;
    unsigned char claw_mastery, psychic_hammer;
    unsigned char tiger_strike, dragon_talon;
    unsigned char shock_web, blade_sentinel;
    unsigned char burst_of_speed;
    unsigned char fists_of_fire, dragon_claw;
    unsigned char charged_bolt_sentry, wake_of_fire;
    unsigned char weapon_block, cloak_of_shadows;
    unsigned char cobra_strike;
    unsigned char blade_fury;
    unsigned char fade, shadow_warrior;
    unsigned char claws_of_thunder, dragon_tail;
    unsigned char lightning_sentry, wake_of_inferno;
    unsigned char mind_blast;
    unsigned char blades_of_ice, dragon_flight;
    unsigned char death_sentry, blade_shield;
    unsigned char venom, shadow_master;
    unsigned char phoenix_strike;
  } assassin;
};

#define AMAZON_CLASS	0
#define SORCERESS_CLASS 1
#define NECROMANCER_CLASS 2
#define PALADIN_CLASS	3
#define BARBARIAN_CLASS 4
#define DRUID_CLASS	5
#define ASSASSIN_CLASS 6

const char * const class_names[7] = {
  "Amazon", "Sorceress", "Necromancer", "Paladin", "Barbarian",
  "Druid", "Assassin"
};

const char * const title_names[2][4] = {
  { "", "Sir ", "Lord ", "Baron " },
  { "", "Dame ", "Lady ", "Baroness " }
};
const char class_genders[7] = { 1, 1, 0, 0, 0, 0, 1 };

const char * const difficulty_names[3] = { "Normal", "Nightmare", "Hell" };

const unsigned long experience_for_level[] = {
  0, 0, 500, 1500, 3750, 7875, 14175, 22680, 32886, 44396, 57715,
  72144, 90180, 112725, 140906, 176132, 220165, 275207, 344008,
  430010, 537513, 671891, 839864, 1049830, 1312287, 1640359, 2050449,
  2563061, 3203826, 3902260, 4663553, 5493363, 6397855, 7383752,
  8458379, 9629723, 10906488, 12298162, 13815086, 15468534, 17270791,
  19235252, 21376515, 23710491, 26254525, 29027522, 32050088,
  35344686, 38935798, 42850109, 47116709, 51767302, 56836449,
  62361819, 68384473, 74949165, 82104680, 89904191, 98405658,
  107672256UL, 117772849UL, 128782495UL, 140783010UL, 153863570UL,
  168121381UL, 183662396UL, 200602101UL, 219066380UL, 239192444UL,
  261129853UL, 285041630UL, 311105466UL, 339515048UL, 370481492UL,
  404234916UL, 441026148UL, 481128591UL, 524840254UL, 572485967UL,
  624419793UL, 681027665UL, 742730244UL, 809986056UL, 883294891UL,
  963201521UL, 1050299747UL, 1145236814UL, 1248718217UL,
  1361512946UL, 1484459201UL, 1618470619UL, 1764543065UL,
  1923762030UL, 2097310703UL, 2286478756UL, 2492671933UL,
  2717422497UL, 2962400612UL, 3229426756UL, 3520485254UL,
  3837739017UL
};

const struct {
  const char *label;
  short offset;
  char class, required_level;
  short prereq[2];
} skill_names[] = {
  /************ Amazon skills ************/
  { "Magic Arrow", offsetof (union d2s_skills, amazon.magic_arrow),
    AMAZON_CLASS, 1, { -1, -1 } },
  { "Fire Arrow", offsetof (union d2s_skills, amazon.fire_arrow),
    AMAZON_CLASS, 1, { -1, -1 } },
  { "Inner Sight", offsetof (union d2s_skills, amazon.inner_sight),
    AMAZON_CLASS, 1, { -1, -1 } },
  { "Critical Strike", offsetof (union d2s_skills, amazon.critical_strike),
    AMAZON_CLASS, 1, { -1, -1 } },
  { "Jab", offsetof (union d2s_skills, amazon.jab),
    AMAZON_CLASS, 1, { -1, -1 } },
  { "Cold Arrow", offsetof (union d2s_skills, amazon.cold_arrow),
    AMAZON_CLASS, 6, { -1, -1 } },
  { "Multiple Shots", offsetof (union d2s_skills, amazon.multiple_shots),
    AMAZON_CLASS, 6, { offsetof (union d2s_skills, amazon.magic_arrow), -1 } },
  { "Dodge", offsetof (union d2s_skills, amazon.dodge),
    AMAZON_CLASS, 6, { -1, -1 } },
  { "Power Strike", offsetof (union d2s_skills, amazon.power_strike),
    AMAZON_CLASS, 6, { offsetof (union d2s_skills, amazon.jab), -1 } },
  { "Poison Javelin", offsetof (union d2s_skills, amazon.poison_javelin),
    AMAZON_CLASS, 6, { -1, -1 } },
  { "Exploding Arrow", offsetof (union d2s_skills, amazon.exploding_arrow),
    AMAZON_CLASS, 12, { offsetof (union d2s_skills, amazon.fire_arrow),
			offsetof (union d2s_skills, amazon.multiple_shots) } },
  { "Slow Missiles", offsetof (union d2s_skills, amazon.slow_missiles),
    AMAZON_CLASS, 12, { offsetof (union d2s_skills, amazon.inner_sight),
			-1 } },
  { "Avoid", offsetof (union d2s_skills, amazon.avoid),
    AMAZON_CLASS, 12, { offsetof (union d2s_skills, amazon.dodge), -1 } },
  { "Impale", offsetof (union d2s_skills, amazon.impale),
    AMAZON_CLASS, 12, { offsetof (union d2s_skills, amazon.jab), -1 } },
  { "Lightning Bolt", offsetof (union d2s_skills, amazon.lightning_bolt),
    AMAZON_CLASS, 12, { offsetof (union d2s_skills, amazon.poison_javelin),
			-1 } },
  { "Ice Arrow", offsetof (union d2s_skills, amazon.ice_arrow),
    AMAZON_CLASS, 18, { offsetof (union d2s_skills, amazon.cold_arrow), -1 } },
  { "Guided Arrow", offsetof (union d2s_skills, amazon.guided_arrow),
    AMAZON_CLASS, 18, { offsetof (union d2s_skills, amazon.cold_arrow),
			offsetof (union d2s_skills, amazon.multiple_shots) } },
  { "Penetrate", offsetof (union d2s_skills, amazon.penetrate),
    AMAZON_CLASS, 18, { offsetof (union d2s_skills, amazon.critical_strike),
			-1 } },
  { "Charged Strike", offsetof (union d2s_skills, amazon.charged_strike),
    AMAZON_CLASS, 18, { offsetof (union d2s_skills, amazon.power_strike),
			offsetof (union d2s_skills, amazon.lightning_bolt) } },
  { "Plague Javelin", offsetof (union d2s_skills, amazon.plague_javelin),
    AMAZON_CLASS, 18, { offsetof (union d2s_skills, amazon.lightning_bolt),
			-1 } },
  { "Strafe", offsetof (union d2s_skills, amazon.strafe),
    AMAZON_CLASS, 24, { offsetof (union d2s_skills, amazon.guided_arrow),
			-1 } },
  { "Immolation Arrow", offsetof (union d2s_skills, amazon.immolation_arrow),
    AMAZON_CLASS, 24, { offsetof (union d2s_skills, amazon.exploding_arrow),
			-1 } },
  { "Decoy", offsetof (union d2s_skills, amazon.decoy),
    AMAZON_CLASS, 24, { offsetof (union d2s_skills, amazon.slow_missiles),
			-1 } },
  { "Evade", offsetof (union d2s_skills, amazon.evade),
    AMAZON_CLASS, 24, { offsetof (union d2s_skills, amazon.avoid), -1 } },
  { "Fend", offsetof (union d2s_skills, amazon.fend),
    AMAZON_CLASS, 24, { offsetof (union d2s_skills, amazon.impale), -1 } },
  { "Freezing Arrow", offsetof (union d2s_skills, amazon.freezing_arrow),
    AMAZON_CLASS, 30, { offsetof (union d2s_skills, amazon.ice_arrow), -1 } },
  { "Valkyrie", offsetof (union d2s_skills, amazon.valkyrie),
    AMAZON_CLASS, 30, { offsetof (union d2s_skills, amazon.decoy), -1 } },
  { "Pierce", offsetof (union d2s_skills, amazon.pierce),
    AMAZON_CLASS, 30, { offsetof (union d2s_skills, amazon.penetrate), -1 } },
  { "Lightning Strike", offsetof (union d2s_skills, amazon.lightning_strike),
    AMAZON_CLASS, 30, { offsetof (union d2s_skills, amazon.charged_strike),
			-1 } },
  { "Lightning Fury", offsetof (union d2s_skills, amazon.lightning_fury),
    AMAZON_CLASS, 30, { offsetof (union d2s_skills, amazon.plague_javelin),
			-1 } },

  /************ Sorceress skills ************/
  { "Fire Bolt", offsetof (union d2s_skills, sorceress.fire_bolt),
    SORCERESS_CLASS, 1, { -1, -1 } },
  { "Warmth", offsetof (union d2s_skills, sorceress.warmth),
    SORCERESS_CLASS, 1, { -1, -1 } },
  { "Charged Bolt", offsetof (union d2s_skills, sorceress.charged_bolt),
    SORCERESS_CLASS, 1, { -1, -1 } },
  { "Ice Bolt", offsetof (union d2s_skills, sorceress.ice_bolt),
    SORCERESS_CLASS, 1, { -1, -1 } },
  { "Frozen Armor", offsetof (union d2s_skills, sorceress.frozen_armor),
    SORCERESS_CLASS, 1, { -1, -1 } },
  { "Inferno", offsetof (union d2s_skills, sorceress.inferno),
    SORCERESS_CLASS, 6, { -1, -1 } },
  { "Static Field", offsetof (union d2s_skills, sorceress.static_field),
    SORCERESS_CLASS, 6, { -1, -1 } },
  { "Telekinesis", offsetof (union d2s_skills, sorceress.telekinesis),
    SORCERESS_CLASS, 6, { -1, -1 } },
  { "Frost Nova", offsetof (union d2s_skills, sorceress.frost_nova),
    SORCERESS_CLASS, 6, { -1, -1 } },
  { "Ice Blast", offsetof (union d2s_skills, sorceress.ice_blast),
    SORCERESS_CLASS, 6, { offsetof (union d2s_skills, sorceress.ice_bolt),
			  -1 } },
  { "Blaze", offsetof (union d2s_skills, sorceress.blaze),
    SORCERESS_CLASS, 12, { offsetof (union d2s_skills, sorceress.inferno),
			   -1 } },
  { "Fire Ball", offsetof (union d2s_skills, sorceress.fire_ball),
    SORCERESS_CLASS, 12, { offsetof (union d2s_skills, sorceress.fire_bolt),
			   -1 } },
  { "Nova", offsetof (union d2s_skills, sorceress.nova),
    SORCERESS_CLASS, 12, { offsetof (union d2s_skills, sorceress.static_field),
			   -1 } },
  { "Lightning", offsetof (union d2s_skills, sorceress.lightning),
    SORCERESS_CLASS, 12, { offsetof (union d2s_skills, sorceress.charged_bolt),
			   -1 } },
  { "Shiver Armor", offsetof (union d2s_skills, sorceress.shiver_armor),
    SORCERESS_CLASS, 12, { offsetof (union d2s_skills, sorceress.frozen_armor),
			   offsetof (union d2s_skills,
				     sorceress.ice_blast) } },
  { "Fire Wall", offsetof (union d2s_skills, sorceress.fire_wall),
    SORCERESS_CLASS, 18, { offsetof (union d2s_skills, sorceress.blaze),
			   -1 } },
  { "Enchant", offsetof (union d2s_skills, sorceress.enchant),
    SORCERESS_CLASS, 18, { offsetof (union d2s_skills, sorceress.warmth),
			   offsetof (union d2s_skills,
				     sorceress.fire_ball) } },
  { "Chain Lightning", offsetof (union d2s_skills, sorceress.chain_lightning),
    SORCERESS_CLASS, 18, { offsetof (union d2s_skills, sorceress.lightning),
			   -1 } },
  { "Teleport", offsetof (union d2s_skills, sorceress.teleport),
    SORCERESS_CLASS, 18, { offsetof (union d2s_skills, sorceress.telekinesis),
			   -1 } },
  { "Glacial Spike", offsetof (union d2s_skills, sorceress.glacial_spike),
    SORCERESS_CLASS, 18, { offsetof (union d2s_skills, sorceress.ice_blast),
			   -1 } },
  { "Meteor", offsetof (union d2s_skills, sorceress.meteor),
    SORCERESS_CLASS, 24, { offsetof (union d2s_skills, sorceress.fire_ball),
			   offsetof (union d2s_skills,
				     sorceress.fire_wall) } },
  { "Thunderstorm", offsetof (union d2s_skills, sorceress.thunderstorm),
    SORCERESS_CLASS, 24, { offsetof (union d2s_skills, sorceress.nova),
			   offsetof (union d2s_skills,
				     sorceress.chain_lightning) } },
  { "Energy Shield", offsetof (union d2s_skills, sorceress.energy_shield),
    SORCERESS_CLASS, 24, { offsetof (union d2s_skills,
				     sorceress.chain_lightning),
			   offsetof (union d2s_skills, sorceress.teleport) } },
  { "Blizzard", offsetof (union d2s_skills, sorceress.blizzard),
    SORCERESS_CLASS, 24, { offsetof (union d2s_skills, sorceress.frost_nova),
			   offsetof (union d2s_skills,
				     sorceress.glacial_spike) } },
  { "Chilling Armor", offsetof (union d2s_skills, sorceress.chilling_armor),
    SORCERESS_CLASS, 24, { offsetof (union d2s_skills, sorceress.shiver_armor),
			   -1 } },
  { "Fire Mastery", offsetof (union d2s_skills, sorceress.fire_mastery),
    SORCERESS_CLASS, 30, { -1, -1 } },
  { "Hydra", offsetof (union d2s_skills, sorceress.hydra),
    SORCERESS_CLASS, 30, { offsetof (union d2s_skills, sorceress.enchant),
			   -1 } },
  { "Lightning Mastery", offsetof (union d2s_skills,
				   sorceress.lightning_mastery),
    SORCERESS_CLASS, 30, { -1, -1 } },
  { "Frozen Orb", offsetof (union d2s_skills, sorceress.frozen_orb),
    SORCERESS_CLASS, 30, { offsetof (union d2s_skills, sorceress.blizzard),
			   -1 } },
  { "Cold Mastery", offsetof (union d2s_skills, sorceress.cold_mastery),
    SORCERESS_CLASS, 30, { -1, -1 } },

  /************ Necromancer skills ************/
  { "Amplify Damage", offsetof (union d2s_skills, necromancer.amplify_damage),
    NECROMANCER_CLASS, 1, { -1, -1 } },
  { "Teeth", offsetof (union d2s_skills, necromancer.teeth),
    NECROMANCER_CLASS, 1, { -1, -1 } },
  { "Bone Armor", offsetof (union d2s_skills, necromancer.bone_arrow),
    NECROMANCER_CLASS, 1, { -1, -1 } },
  { "Skeleton Mastery", offsetof (union d2s_skills,
				  necromancer.skeleton_mastery),
    NECROMANCER_CLASS, 1, { offsetof (union d2s_skills,
				      necromancer.raise_skeleton),
			    -1 } },
  { "Raise Skeleton", offsetof (union d2s_skills, necromancer.raise_skeleton),
    NECROMANCER_CLASS, 1, { -1, -1 } },
  { "Dim Vision", offsetof (union d2s_skills, necromancer.dim_vision),
    NECROMANCER_CLASS, 6, { -1, -1 } },
  { "Weaken", offsetof (union d2s_skills, necromancer.weaken),
    NECROMANCER_CLASS, 6, { offsetof (union d2s_skills,
				      necromancer.amplify_damage),
			    -1 } },
  { "Poison Dagger", offsetof (union d2s_skills, necromancer.poison_dagger),
    NECROMANCER_CLASS, 6, { -1, -1 } },
  { "Corpse Explosion", offsetof (union d2s_skills,
				  necromancer.corpse_explosion),
    NECROMANCER_CLASS, 6, { offsetof (union d2s_skills, necromancer.teeth),
			    -1 } },
  { "Clay Golem", offsetof (union d2s_skills, necromancer.clay_golem),
    NECROMANCER_CLASS, 6, { -1, -1 } },
  { "Iron Maiden", offsetof (union d2s_skills, necromancer.iron_maiden),
    NECROMANCER_CLASS, 12, { offsetof (union d2s_skills,
				       necromancer.amplify_damage),
			     -1 } },
  { "Terror", offsetof (union d2s_skills, necromancer.terror),
    NECROMANCER_CLASS, 12, { offsetof (union d2s_skills, necromancer.weaken),
			     -1 } },
  { "Bone Wall", offsetof (union d2s_skills, necromancer.bone_wall),
    NECROMANCER_CLASS, 12, { offsetof (union d2s_skills,
				       necromancer.bone_arrow),
			     -1 } },
  { "Golem Mastery", offsetof (union d2s_skills, necromancer.golem_mastery),
    NECROMANCER_CLASS, 12, { offsetof (union d2s_skills,
				       necromancer.clay_golem),
			     -1 } },
  { "Raise Skeletal Mage", offsetof (union d2s_skills,
				     necromancer.raise_skeletal_mage),
    NECROMANCER_CLASS, 12, { offsetof (union d2s_skills,
				       necromancer.raise_skeleton),
			     -1 } },
  { "Confuse", offsetof (union d2s_skills, necromancer.confuse),
    NECROMANCER_CLASS, 18, { offsetof (union d2s_skills,
				       necromancer.dim_vision),
			     -1 } },
  { "Life Tap", offsetof (union d2s_skills, necromancer.life_tap),
    NECROMANCER_CLASS, 18, { offsetof (union d2s_skills,
				       necromancer.iron_maiden),
			     -1 } },
  { "Poison Explosion", offsetof (union d2s_skills,
				  necromancer.poison_explosion),
    NECROMANCER_CLASS, 18, { offsetof (union d2s_skills,
				       necromancer.poison_dagger),
			     offsetof (union d2s_skills,
				       necromancer.corpse_explosion) } },
  { "Bone Spear", offsetof (union d2s_skills, necromancer.bone_spear),
    NECROMANCER_CLASS, 18, { offsetof (union d2s_skills,
				       necromancer.corpse_explosion), -1 } },
  { "Blood Golem", offsetof (union d2s_skills, necromancer.blood_golem),
    NECROMANCER_CLASS, 18, { offsetof (union d2s_skills,
				       necromancer.clay_golem),
			     -1 } },
  { "Attract", offsetof (union d2s_skills, necromancer.attract),
    NECROMANCER_CLASS, 24, { offsetof (union d2s_skills, necromancer.confuse),
			     -1 } },
  { "Decrepify", offsetof (union d2s_skills, necromancer.decrepify),
    NECROMANCER_CLASS, 24, { offsetof (union d2s_skills, necromancer.terror),
			     -1 } },
  { "Bone Prison", offsetof (union d2s_skills, necromancer.bone_prison),
    NECROMANCER_CLASS, 24, { offsetof (union d2s_skills,
				       necromancer.bone_wall),
			     offsetof (union d2s_skills,
				       necromancer.bone_spear) } },
  { "Summon Resist", offsetof (union d2s_skills, necromancer.summon_resist),
    NECROMANCER_CLASS, 24, { offsetof (union d2s_skills,
				       necromancer.golem_mastery),
			     -1 } },
  { "Iron Golem", offsetof (union d2s_skills, necromancer.iron_golem),
    NECROMANCER_CLASS, 24, { offsetof (union d2s_skills,
				       necromancer.blood_golem),
			     -1 } },
  { "Lower Resist", offsetof (union d2s_skills, necromancer.lower_resist),
    NECROMANCER_CLASS, 24, { offsetof (union d2s_skills, necromancer.life_tap),
			     offsetof (union d2s_skills,
				       necromancer.decrepify) } },
  { "Poison Nova", offsetof (union d2s_skills, necromancer.poison_nova),
    NECROMANCER_CLASS, 30, { offsetof (union d2s_skills,
				       necromancer.poison_explosion), -1 } },
  { "Bone Spirit", offsetof (union d2s_skills, necromancer.bone_spirit),
    NECROMANCER_CLASS, 30, { offsetof (union d2s_skills,
				       necromancer.bone_spear),
			     -1 } },
  { "Fire Golem", offsetof (union d2s_skills, necromancer.fire_golem),
    NECROMANCER_CLASS, 30, { offsetof (union d2s_skills,
				       necromancer.iron_golem),
			     -1 } },
  { "Revive", offsetof (union d2s_skills, necromancer.revive),
    NECROMANCER_CLASS, 30, { offsetof (union d2s_skills,
				       necromancer.raise_skeletal_mage),
			     offsetof (union d2s_skills,
				       necromancer.iron_golem) } },

  /************ Paladin skills ************/
  { "Sacrifice", offsetof (union d2s_skills, paladin.sacrifice),
    PALADIN_CLASS, 1, { -1, -1 } },
  { "Smite", offsetof (union d2s_skills, paladin.smite),
    PALADIN_CLASS, 1, { -1, -1 } },
  { "Might", offsetof (union d2s_skills, paladin.might),
    PALADIN_CLASS, 1, { -1, -1 } },
  { "Prayer", offsetof (union d2s_skills, paladin.prayer),
    PALADIN_CLASS, 1, { -1, -1 } },
  { "Resist Fire", offsetof (union d2s_skills, paladin.resist_fire),
    PALADIN_CLASS, 1, { -1, -1 } },
  { "Holy Bolt", offsetof (union d2s_skills, paladin.holy_bolt),
    PALADIN_CLASS, 6, { -1, -1 } },
  { "Holy Fire", offsetof (union d2s_skills, paladin.holy_fire),
    PALADIN_CLASS, 6, { offsetof (union d2s_skills, paladin.might), -1 } },
  { "Thorns", offsetof (union d2s_skills, paladin.thorns),
    PALADIN_CLASS, 6, { -1, -1 } },
  { "Defiance", offsetof (union d2s_skills, paladin.defiance),
    PALADIN_CLASS, 6, { -1, -1 } },
  { "Resist Cold", offsetof (union d2s_skills, paladin.resist_cold),
    PALADIN_CLASS, 6, { -1, -1 } },
  { "Zeal", offsetof (union d2s_skills, paladin.zeal),
    PALADIN_CLASS, 12, { offsetof (union d2s_skills, paladin.sacrifice),
			 -1 } },
  { "Charge", offsetof (union d2s_skills, paladin.charge),
    PALADIN_CLASS, 12, { offsetof (union d2s_skills, paladin.smite), -1 } },
  { "Blessed Aim", offsetof (union d2s_skills, paladin.blessed_aim),
    PALADIN_CLASS, 12, { offsetof (union d2s_skills, paladin.might), -1 } },
  { "Cleansing", offsetof (union d2s_skills, paladin.cleansing),
    PALADIN_CLASS, 12, { offsetof (union d2s_skills, paladin.prayer), -1 } },
  { "Lightning Resist", offsetof (union d2s_skills, paladin.lightning_resist),
    PALADIN_CLASS, 12, { -1, -1 } },
  { "Vengeance", offsetof (union d2s_skills, paladin.vengeance),
    PALADIN_CLASS, 18, { offsetof (union d2s_skills, paladin.zeal), -1 } },
  { "Blessed Hammer", offsetof (union d2s_skills, paladin.blessed_hammer),
    PALADIN_CLASS, 18, { offsetof (union d2s_skills, paladin.holy_bolt),
			 -1 } },
  { "Concentration", offsetof (union d2s_skills, paladin.concentration),
    PALADIN_CLASS, 18, { offsetof (union d2s_skills, paladin.blessed_aim),
			 -1 } },
  { "Holy Freeze", offsetof (union d2s_skills, paladin.holy_freeze),
    PALADIN_CLASS, 18, { offsetof (union d2s_skills, paladin.holy_fire),
			 -1 } },
  { "Vigor", offsetof (union d2s_skills, paladin.vigor),
    PALADIN_CLASS, 18, { offsetof (union d2s_skills, paladin.defiance),
			 offsetof (union d2s_skills, paladin.cleansing) } },
  { "Conversion", offsetof (union d2s_skills, paladin.conversion),
    PALADIN_CLASS, 24, { offsetof (union d2s_skills, paladin.vengeance),
			 -1 } },
  { "Holy Shield", offsetof (union d2s_skills, paladin.holy_shield),
    PALADIN_CLASS, 24, { offsetof (union d2s_skills, paladin.charge),
			 offsetof (union d2s_skills,
				   paladin.blessed_hammer) } },
  { "Holy Shock", offsetof (union d2s_skills, paladin.holy_shock),
    PALADIN_CLASS, 24, { offsetof (union d2s_skills, paladin.holy_freeze),
			 -1 } },
  { "Sanctuary", offsetof (union d2s_skills, paladin.sanctuary),
    PALADIN_CLASS, 24, { offsetof (union d2s_skills, paladin.thorns),
			 offsetof (union d2s_skills, paladin.holy_freeze) } },
  { "Meditation", offsetof (union d2s_skills, paladin.meditation),
    PALADIN_CLASS, 24, { offsetof (union d2s_skills, paladin.cleansing),
			 -1 } },
  { "Fist Of The Heavens", offsetof (union d2s_skills,
				     paladin.fist_of_the_heavens),
    PALADIN_CLASS, 30, { offsetof (union d2s_skills, paladin.blessed_hammer),
			 offsetof (union d2s_skills, paladin.conversion) } },
  { "Fanaticism", offsetof (union d2s_skills, paladin.fanaticism),
    PALADIN_CLASS, 30, { offsetof (union d2s_skills, paladin.concentration),
			 -1 } },
  { "Conviction", offsetof (union d2s_skills, paladin.conviction),
    PALADIN_CLASS, 30, { offsetof (union d2s_skills, paladin.sanctuary),
			 -1 } },
  { "Redemption", offsetof (union d2s_skills, paladin.redemption),
    PALADIN_CLASS, 30, { offsetof (union d2s_skills, paladin.vigor), -1 } },
  { "Salvation", offsetof (union d2s_skills, paladin.salvation),
    PALADIN_CLASS, 30, { -1, -1 } },

  /************ Barbarian skills ************/
  { "Bash", offsetof (union d2s_skills, barbarian.bash),
    BARBARIAN_CLASS, 1, { -1, -1 } },
  { "Sword Mastery", offsetof (union d2s_skills, barbarian.sword_mastery),
    BARBARIAN_CLASS, 1, { -1, -1 } },
  { "Axe Mastery", offsetof (union d2s_skills, barbarian.axe_mastery),
    BARBARIAN_CLASS, 1, { -1, -1 } },
  { "Mace Mastery", offsetof (union d2s_skills, barbarian.mace_mastery),
    BARBARIAN_CLASS, 1, { -1, -1 } },
  { "Howl", offsetof (union d2s_skills, barbarian.howl),
    BARBARIAN_CLASS, 1, { -1, -1 } },
  { "Find Potion", offsetof (union d2s_skills, barbarian.find_potion),
    BARBARIAN_CLASS, 1, { -1, -1 } },
  { "Leap", offsetof (union d2s_skills, barbarian.leap),
    BARBARIAN_CLASS, 6, { -1, -1 } },
  { "Double Swing", offsetof (union d2s_skills, barbarian.double_swing),
    BARBARIAN_CLASS, 6, { offsetof (union d2s_skills, barbarian.bash), -1 } },
  { "Polearm Mastery", offsetof (union d2s_skills, barbarian.polearm_mastery),
    BARBARIAN_CLASS, 6, { -1, -1 } },
  { "Throwing Mastery", offsetof (union d2s_skills,
				  barbarian.throwing_mastery),
    BARBARIAN_CLASS, 6, { -1, -1 } },
  { "Spear Mastery", offsetof (union d2s_skills, barbarian.spear_mastery),
    BARBARIAN_CLASS, 6, { -1, -1 } },
  { "Taunt", offsetof (union d2s_skills, barbarian.taunt),
    BARBARIAN_CLASS, 6, { offsetof (union d2s_skills, barbarian.howl), -1 } },
  { "Shout", offsetof (union d2s_skills, barbarian.shout),
    BARBARIAN_CLASS, 6, { offsetof (union d2s_skills, barbarian.howl), -1 } },
  { "Stun", offsetof (union d2s_skills, barbarian.stun),
    BARBARIAN_CLASS, 12, { offsetof (union d2s_skills, barbarian.bash), -1 } },
  { "Double Throw", offsetof (union d2s_skills, barbarian.double_throw),
    BARBARIAN_CLASS, 12, { offsetof (union d2s_skills, barbarian.double_swing),
			   -1 } },
  { "Increased Stamina", offsetof (union d2s_skills,
				   barbarian.increased_stamina),
    BARBARIAN_CLASS, 12, { -1, -1 } },
  { "Find Item", offsetof (union d2s_skills, barbarian.find_item),
    BARBARIAN_CLASS, 12, { offsetof (union d2s_skills, barbarian.find_potion),
			   -1 } },
  { "Leap Attack", offsetof (union d2s_skills, barbarian.leap_attack),
    BARBARIAN_CLASS, 18, { offsetof (union d2s_skills, barbarian.leap), -1 } },
  { "Concentrate", offsetof (union d2s_skills, barbarian.concentrate),
    BARBARIAN_CLASS, 18, { offsetof (union d2s_skills, barbarian.stun), -1 } },
  { "Iron Skin", offsetof (union d2s_skills, barbarian.iron_skin),
    BARBARIAN_CLASS, 18, { -1, -1 } },
  { "Battle Cry", offsetof (union d2s_skills, barbarian.battle_cry),
    BARBARIAN_CLASS, 18, { offsetof (union d2s_skills, barbarian.taunt),
			   -1 } },
  { "Frenzy", offsetof (union d2s_skills, barbarian.frenzy),
    BARBARIAN_CLASS, 24, { offsetof (union d2s_skills, barbarian.double_throw),
			   -1 } },
  { "Increased Speed", offsetof (union d2s_skills, barbarian.increased_speed),
    BARBARIAN_CLASS, 24, { offsetof (union d2s_skills,
				     barbarian.increased_stamina), -1 } },
  { "Battle Orders", offsetof (union d2s_skills, barbarian.battle_orders),
    BARBARIAN_CLASS, 24, { offsetof (union d2s_skills, barbarian.shout),
			   -1 } },
  { "Grim Ward", offsetof (union d2s_skills, barbarian.grim_ward),
    BARBARIAN_CLASS, 24, { offsetof (union d2s_skills, barbarian.find_item),
			   -1 } },
  { "Whirlwind", offsetof (union d2s_skills, barbarian.whirlwind),
    BARBARIAN_CLASS, 30, { offsetof (union d2s_skills, barbarian.leap_attack),
			   offsetof (union d2s_skills,
				     barbarian.concentrate) } },
  { "Berserk", offsetof (union d2s_skills, barbarian.berserk),
    BARBARIAN_CLASS, 30, { offsetof (union d2s_skills, barbarian.concentrate),
			   -1 } },
  { "Natural Resistance", offsetof (union d2s_skills,
				    barbarian.natural_resistance),
    BARBARIAN_CLASS, 30, { offsetof (union d2s_skills, barbarian.iron_skin),
			   -1 } },
  { "Warcry", offsetof (union d2s_skills, barbarian.warcry),
    BARBARIAN_CLASS, 30, { offsetof (union d2s_skills, barbarian.battle_cry),
			   offsetof (union d2s_skills,
				     barbarian.battle_orders) } },
  { "Battle Command", offsetof (union d2s_skills, barbarian.battle_command),
    BARBARIAN_CLASS, 30, { offsetof (union d2s_skills,
				     barbarian.battle_orders), -1 } },

  /************ Druid skills ************/
  { "Raven", offsetof (union d2s_skills, druid.raven),
    DRUID_CLASS, 1, { -1, -1 } },
  { "Poison Creeper", offsetof (union d2s_skills, druid.poison_creeper),
    DRUID_CLASS, 1, { -1, -1 } },
  { "Werewolf", offsetof (union d2s_skills, druid.werewolf),
    DRUID_CLASS, 1, { -1, -1 } },
  { "Lycanthropy", offsetof (union d2s_skills, druid.lycanthropy),
    DRUID_CLASS, 1, { offsetof (union d2s_skills, druid.werewolf), -1 } },
  { "Firestorm", offsetof (union d2s_skills, druid.firestorm),
    DRUID_CLASS, 1, { -1, -1 } },
  { "Oak Sage", offsetof (union d2s_skills, druid.oak_sage),
    DRUID_CLASS, 6, { -1, -1 } },
  { "Summon Spirit Wolf", offsetof (union d2s_skills,
				    druid.summon_spirit_wolf),
    DRUID_CLASS, 6, { -1, -1 } },
  { "Werebear", offsetof (union d2s_skills, druid.werebear),
    DRUID_CLASS, 6, { -1, -1 } },
  { "Molten Boulder", offsetof (union d2s_skills, druid.molten_boulder),
    DRUID_CLASS, 6, { offsetof (union d2s_skills, druid.firestorm), -1 } },
  { "Arctic Blast", offsetof (union d2s_skills, druid.arctic_blast),
    DRUID_CLASS, 6, { -1, -1 } },
  { "Carrion Vine", offsetof (union d2s_skills, druid.carrion_vine),
    DRUID_CLASS, 12, { offsetof (union d2s_skills, druid.poison_creeper),
		       -1 } },
  { "Feral Rage", offsetof (union d2s_skills, druid.feral_rage),
    DRUID_CLASS, 12, { offsetof (union d2s_skills, druid.werewolf), -1 } },
  { "Maul", offsetof (union d2s_skills, druid.maul),
    DRUID_CLASS, 12, { offsetof (union d2s_skills, druid.werebear), -1 } },
  { "Fissure", offsetof (union d2s_skills, druid.fissure),
    DRUID_CLASS, 12, { offsetof (union d2s_skills, druid.molten_boulder),
		       -1 } },
  { "Cyclone Armor", offsetof (union d2s_skills, druid.cyclone_armor),
    DRUID_CLASS, 12, { offsetof (union d2s_skills, druid.arctic_blast), -1 } },
  { "Heart Of Wolverine", offsetof (union d2s_skills,
				    druid.heart_of_wolverine),
    DRUID_CLASS, 18, { offsetof (union d2s_skills, druid.oak_sage), -1 } },
  { "Summon Dire Wolf", offsetof (union d2s_skills, druid.summon_dire_wolf),
    DRUID_CLASS, 18, { offsetof (union d2s_skills, druid.oak_sage),
		       offsetof (union d2s_skills,
				 druid.summon_spirit_wolf) } },
  { "Rabies", offsetof (union d2s_skills, druid.rabies),
    DRUID_CLASS, 18, { offsetof (union d2s_skills, druid.feral_rage), -1 } },
  { "Fire Claws", offsetof (union d2s_skills, druid.fire_claws),
    DRUID_CLASS, 18, { offsetof (union d2s_skills, druid.feral_rage),
		       offsetof (union d2s_skills, druid.maul) } },
  { "Twister", offsetof (union d2s_skills, druid.twister),
    DRUID_CLASS, 18, { offsetof (union d2s_skills, druid.cyclone_armor),
		       -1 } },
  { "Solar Creeper", offsetof (union d2s_skills, druid.solar_creeper),
    DRUID_CLASS, 24, { offsetof (union d2s_skills, druid.carrion_vine), -1 } },
  { "Hunger", offsetof (union d2s_skills, druid.hunger),
    DRUID_CLASS, 24, { offsetof (union d2s_skills, druid.fire_claws), -1 } },
  { "Shock Wave", offsetof (union d2s_skills, druid.shock_wave),
    DRUID_CLASS, 24, { offsetof (union d2s_skills, druid.maul), -1 } },
  { "Volcano", offsetof (union d2s_skills, druid.volcano),
    DRUID_CLASS, 24, { offsetof (union d2s_skills, druid.fissure), -1 } },
  { "Tornado", offsetof (union d2s_skills, druid.tornado),
    DRUID_CLASS, 24, { offsetof (union d2s_skills, druid.twister), -1 } },
  { "Spirit Of Barbs", offsetof (union d2s_skills, druid.spirit_of_barbs),
    DRUID_CLASS, 30, { offsetof (union d2s_skills,
				 druid.heart_of_wolverine), -1 } },
  { "Summon Grizzly", offsetof (union d2s_skills, druid.summon_grizzly),
    DRUID_CLASS, 30, { offsetof (union d2s_skills, druid.summon_dire_wolf),
		       -1 } },
  { "Fury", offsetof (union d2s_skills, druid.fury),
    DRUID_CLASS, 30, { offsetof (union d2s_skills, druid.rabies), -1 } },
  { "Armageddon", offsetof (union d2s_skills, druid.armageddon),
    DRUID_CLASS, 30, { offsetof (union d2s_skills, druid.volcano),
		       offsetof (union d2s_skills, druid.hurricane) } },
  { "Hurricane", offsetof (union d2s_skills, druid.hurricane),
    DRUID_CLASS, 30, { offsetof (union d2s_skills, druid.tornado), -1 } },

  /************ Assassin skills ************/
  { "Fire Blast", offsetof (union d2s_skills, assassin.fire_blast),
    ASSASSIN_CLASS, 1, { -1, -1 } },
  { "Claw Mastery", offsetof (union d2s_skills, assassin.claw_mastery),
    ASSASSIN_CLASS, 1, { -1, -1 } },
  { "Psychic Hammer", offsetof (union d2s_skills, assassin.psychic_hammer),
    ASSASSIN_CLASS, 1, { -1, -1 } },
  { "Tiger Strike", offsetof (union d2s_skills, assassin.tiger_strike),
    ASSASSIN_CLASS, 1, { -1, -1 } },
  { "Dragon Talon", offsetof (union d2s_skills, assassin.dragon_talon),
    ASSASSIN_CLASS, 1, { -1, -1 } },
  { "Shock Web", offsetof (union d2s_skills, assassin.shock_web),
    ASSASSIN_CLASS, 6, { offsetof (union d2s_skills, assassin.fire_blast),
			 -1 } },
  { "Blade Sentinel", offsetof (union d2s_skills, assassin.blade_sentinel),
    ASSASSIN_CLASS, 6, { -1, -1 } },
  { "Burst Of Speed", offsetof (union d2s_skills, assassin.burst_of_speed),
    ASSASSIN_CLASS, 6, { offsetof (union d2s_skills, assassin.claw_mastery),
			 -1 } },
  { "Fists Of Fire", offsetof (union d2s_skills, assassin.fists_of_fire),
    ASSASSIN_CLASS, 6, { -1, -1 } },
  { "Dragon Claw", offsetof (union d2s_skills, assassin.dragon_claw),
    ASSASSIN_CLASS, 6, { offsetof (union d2s_skills, assassin.dragon_talon),
			 -1 } },
  { "Charged Bolt Sentry", offsetof (union d2s_skills,
				     assassin.charged_bolt_sentry),
    ASSASSIN_CLASS, 12, { offsetof (union d2s_skills, assassin.shock_web),
			  -1 } },
  { "Wake Of Fire", offsetof (union d2s_skills, assassin.wake_of_fire),
    ASSASSIN_CLASS, 12, { offsetof (union d2s_skills, assassin.fire_blast),
			  -1 } },
  { "Weapon Block", offsetof (union d2s_skills, assassin.weapon_block),
    ASSASSIN_CLASS, 12, { offsetof (union d2s_skills, assassin.claw_mastery),
			  -1 } },
  { "Cloak Of Shadows", offsetof (union d2s_skills, assassin.cloak_of_shadows),
    ASSASSIN_CLASS, 12, { offsetof (union d2s_skills, assassin.psychic_hammer),
			  -1 } },
  { "Cobra Strike", offsetof (union d2s_skills, assassin.cobra_strike),
    ASSASSIN_CLASS, 12, { offsetof (union d2s_skills, assassin.tiger_strike),
			  -1 } },
  { "Blade Fury", offsetof (union d2s_skills, assassin.blade_fury),
    ASSASSIN_CLASS, 18, { offsetof (union d2s_skills, assassin.blade_sentinel),
			  offsetof (union d2s_skills,
				    assassin.wake_of_fire) } },
  { "Fade", offsetof (union d2s_skills, assassin.fade),
    ASSASSIN_CLASS, 18, { offsetof (union d2s_skills, assassin.burst_of_speed),
			  -1 } },
  { "Shadow Warrior", offsetof (union d2s_skills, assassin.shadow_warrior),
    ASSASSIN_CLASS, 18, { offsetof (union d2s_skills,
				    assassin.cloak_of_shadows), -1 } },
  { "Claws Of Thunder", offsetof (union d2s_skills, assassin.claws_of_thunder),
    ASSASSIN_CLASS, 18, { offsetof (union d2s_skills, assassin.fists_of_fire),
			  -1 } },
  { "Dragon Tail", offsetof (union d2s_skills, assassin.dragon_tail),
    ASSASSIN_CLASS, 18, { offsetof (union d2s_skills, assassin.dragon_claw),
			  -1 } },
  { "Lightning Sentry", offsetof (union d2s_skills, assassin.lightning_sentry),
    ASSASSIN_CLASS, 24, { offsetof (union d2s_skills,
				    assassin.charged_bolt_sentry), -1 } },
  { "Wake Of Inferno", offsetof (union d2s_skills, assassin.wake_of_inferno),
    ASSASSIN_CLASS, 24, { offsetof (union d2s_skills, assassin.wake_of_fire),
			  -1 } },
  { "Mind Blast", offsetof (union d2s_skills, assassin.mind_blast),
    ASSASSIN_CLASS, 24, { offsetof (union d2s_skills,
				    assassin.cloak_of_shadows), -1 } },
  { "Blades Of Ice", offsetof (union d2s_skills, assassin.blades_of_ice),
    ASSASSIN_CLASS, 24, { offsetof (union d2s_skills,
				    assassin.claws_of_thunder), -1 } },
  { "Dragon Flight", offsetof (union d2s_skills, assassin.dragon_flight),
    ASSASSIN_CLASS, 24, { offsetof (union d2s_skills, assassin.dragon_tail),
			  -1 } },
  { "Death Sentry", offsetof (union d2s_skills, assassin.death_sentry),
    ASSASSIN_CLASS, 30, { offsetof (union d2s_skills,
				    assassin.lightning_sentry), -1 } },
  { "Blade Shield", offsetof (union d2s_skills, assassin.blade_shield),
    ASSASSIN_CLASS, 30, { offsetof (union d2s_skills, assassin.blade_fury),
			  -1 } },
  { "Venom", offsetof (union d2s_skills, assassin.venom),
    ASSASSIN_CLASS, 30, { offsetof (union d2s_skills, assassin.fade), -1 } },
  { "Shadow Master", offsetof (union d2s_skills, assassin.shadow_master),
    ASSASSIN_CLASS, 30, { offsetof (union d2s_skills, assassin.shadow_warrior),
			  -1 } },
  { "Phoenix Strike", offsetof (union d2s_skills, assassin.phoenix_strike),
    ASSASSIN_CLASS, 30, { offsetof (union d2s_skills, assassin.cobra_strike),
			  offsetof (union d2s_skills,
				    assassin.blades_of_ice) } },

};


const char *d2s_filename;
unsigned char d2s_data[4096];
const char *progname;

void compute_checksum (void);
int dump_known_data (void);
int read_number (const char *prompt, int max_limit);
int read_yes_no (const char *prompt, int default_answer);
int read_skill_name (const char *prompt);
int read_stat_name (const char *prompt);
int load_game (void);
int save_game (void);

void
compute_checksum (void)
{
  struct d2s_header * const d2s = (struct d2s_header *) &d2s_data[0];
  unsigned long cs = 0;
  int i;
  int length = d2s->length;

  d2s->checksum = 0;
  for (i = 0; i < length; i++)
    cs = (cs << 1) + (cs >> 31) + d2s_data[i];
  d2s->checksum = cs;
}

int
dump_known_data (void)
{
  struct d2s_header * const d2s = (struct d2s_header *) &d2s_data[0];
  struct d2s_stats2 stats2 = { 0 };
  unsigned long *statp;
  unsigned char *skillp;
  time_t tt = (time_t) d2s->timestamp;
  int i, n;

  printf ("%sharacter data for the %s%s %s%s, saved %s",
	  d2s->expansion ? "Expansion set c" : "C",
	  d2s->character_died ? "dead " : "", class_names[d2s->class],
	  title_names[(int) class_genders[d2s->class]][d2s->title],
	  d2s->name, ctime (&tt));

  /* Get a count of the number of quests which appear to be completed */
  for (i = 0; i < 3; i++)
    {
      int j, act, started, completed;

      if (!d2s->difficulty[i])
	continue;

      printf ("%s difficulty: you are in act %d\n", difficulty_names[i],
	      (d2s->difficulty[i] & 0x0f) + 1);

      /* Temporary hack until we figure out all bits in the "w4" section */
      printf ("You have been introduced to:");
      for (j = 0; j < 8 * 8; j++)
	{
	  if (d2s->introductions[i][j / 8] & (1 << (j % 8)))
	    {
	      switch (j)
		{
		case 9: printf (" Gheed"); break;
		case 10: printf (" Akara"); break;
		case 11: printf (" Kashya"); break;
		case 12: printf (" Warriv (in Rogue Encampment)"); break;
		case 13: printf (" Charsi"); break;
		case 15: printf (" Warriv (in Lut Gholein)"); break;
		case 17: printf (" Drognan"); break;
		case 18: printf (" Fara"); break;
		case 19: printf (" Lysander"); break;
		case 20: printf (" Geglash"); break;
		case 21: printf (" Meshif (in Lut Gholein)"); break;
		case 22: printf (" Jerhyn"); break;
		case 23: printf (" Greiz"); break;
		case 24: printf (" Elzix"); break;
		case 26: printf (" Cain (in Kurast)"); break;
		case 29: printf (" Asheara"); break;
		case 30: printf (" Hratli"); break;
		case 31: printf (" Alkor"); break;
		case 32: printf (" Ormus"); break;
		case 35: printf (" Meshif (in Kurast)"); break;
		case 36: printf (" Natalya"); break;
		case 38: printf (" Anya"); break;
		case 39: printf (" Malah"); break;
		case 40: printf (" Nihlathak"); break;
		case 41: printf (" Qual-Kehk"); break;
		case 42: printf (" Cain (in Harrogath)"); break;
		default: printf (" NPC-%d", j); break;
		}
	    }
	}
      putchar ('\n');

      printf ("You have been congratulated by:");
      for (j = 0; j < 8 * 8; j++)
	{
	  if (d2s->congratulations[i][j / 8] & (1 << (j % 8)))
	    {
	      switch (j)
		{
		case 9: printf (" Gheed"); break;
		case 10: printf (" Akara"); break;
		case 11: printf (" Kashya"); break;
		case 12: printf (" Warriv (in Rogue Encampment)"); break;
		case 13: printf (" Charsi"); break;
		case 15: printf (" Warriv (in Lut Gholein)"); break;
		case 17: printf (" Drognan"); break;
		case 18: printf (" Fara"); break;
		case 19: printf (" Lysander"); break;
		case 20: printf (" Geglash"); break;
		case 21: printf (" Meshif (in Lut Gholein)"); break;
		case 22: printf (" Jerhyn"); break;
		case 23: printf (" Greiz"); break;
		case 24: printf (" Elzix"); break;
		case 26: printf (" Cain (in Kurast)"); break;
		case 29: printf (" Asheara"); break;
		case 30: printf (" Hratli"); break;
		case 31: printf (" Alkor"); break;
		case 32: printf (" Ormus"); break;
		case 35: printf (" Meshif (in Kurast)"); break;
		case 36: printf (" Natalya"); break;
		case 38: printf (" Anya"); break;
		case 39: printf (" Malah"); break;
		case 40: printf (" Nihlathak"); break;
		case 41: printf (" Qual-Kehk"); break;
		case 42: printf (" Cain (in Harrogath)"); break;
		default: printf (" NPC-%d", j); break;
		}
	    }
	}
      putchar ('\n');

      for (act = 0; act < 3; act++)
	{
	  if (d2s->quests[i].act[act].intros)
	    printf ("    Act %d started (%d)\n",
		    act + 1, d2s->quests[i].act[act].intros);
	  printf ("\tQuests: ");
	  started = 0;
	  completed = 0;
	  for (j = 0; j < 6; j++)
	    {
	      if (d2s->quests[i].act[act].quests[j])
		{
		  started++;
		  printf (" %d (%#.4x), ", j + 1,
			  d2s->quests[i].act[act].quests[j]);
		  if (d2s->quests[i].act[act].quests[j] & 1)
		    completed++;
		}
	    }
	  printf ("\b\n\t%d/%d quests completed\n",
		  completed, started);
	  if (d2s->quests[i].act[act].completed)
	    printf ("    Act %d completed (%d)\n",
		    act + 1, d2s->quests[i].act[act].completed);
	  if (((*((short *) &d2s->waypoints[i].points[act * 9 / 8])
		>> (act * 9 % 8)) & 0x1ff) == 0x1ff)
	    printf ("    All waypoints in act %d are active\n", act + 1);
	  else
	    {
	      for (n = 0, j = act * 9; j < act * 9 + 9; j++)
		if (d2s->waypoints[i].points[j / 8] & (1 << (j % 8)))
		  n++;
	      if (n)
		printf ("    %d waypoints in act %d are active\n", n, act + 1);
	    }
	}
      if (d2s->quests[i].act_4.intros)
	printf ("    Act 4 started (%d)\n", d2s->quests[i].act_4.intros);
      printf ("\tQuests: ");
      started = 0;
      completed = 0;
      for (j = 0; j < 3; j++)
	{
	  if (d2s->quests[i].act_4.quests[j])
	    {
	      started++;
	      printf (" %d (%#.4x), ", j + 1,
		      d2s->quests[i].act_4.quests[j]);
	      if (d2s->quests[i].act_4.quests[j] & 1)
		completed++;
	    }
	}
      printf ("\b\n\t%d/%d quests completed\n",
	      completed, started);
      if (d2s->quests[i].act_4.completed)
	printf ("    Act 4 completed (%d)\n",
		d2s->quests[i].act_4.completed);
      if (((d2s->waypoints[i].points[27 / 8] >> (27 % 8)) & 7) == 7)
	printf ("    All waypoints in act %d are active\n", 4);
      else
	{
	  for (n = 0, j = 27; j < 30; j++)
	    if (d2s->waypoints[i].points[j / 8] & (1 << (j % 8)))
	      n++;
	  if (n)
	    printf ("    %d waypoints in act %d are active\n", n, 4);
	}
      if (d2s->quests[i].act_5.intros)
	printf ("    Act 5 started (%d)\n", d2s->quests[i].act_5.intros);
      printf ("\tQuests: ");
      started = 0;
      completed = 0;
      for (j = 0; j < 6; j++)
	{
	  if (d2s->quests[i].act_5.quests[j])
	    {
	      started++;
	      printf (" %d (%#.4x), ", j + 1,
		      d2s->quests[i].act_5.quests[j]);
	      if (d2s->quests[i].act_5.quests[j] & 1)
		completed++;
	    }
	}
      printf ("\b\n\t%d/%d quests completed\n",
	      completed, started);
      if (d2s->quests[i].act_5.completed)
	printf ("    Act 5 completed (%d)\n",
		d2s->quests[i].act_5.completed);
      if (((*((short *) &d2s->waypoints[i].points[30 / 8])
	    >> (30 % 8)) & 0x1ff) == 0x1ff)
	printf ("    All waypoints in act %d are active\n", 5);
      else
	{
	  for (n = 0, j = 30; j < 39; j++)
	    if (d2s->waypoints[i].points[j / 8] & (1 << (j % 8)))
	      n++;
	  if (n)
	    printf ("    %d waypoints in act %d are active\n", n, 5);
	}
    }

  printf ("Mouse button actions:");
  for (i = 0; i < 4; i++)
    {
      printf (" %s%s=", (i & 2) ? "alt." : "", (i & 1) ? "Right" : "Left");
      switch (d2s->button_action[i]) {
      case 0: printf ("Attack"); break;
      case 1: printf ("Kick"); break;
      case 2: printf ("Throw"); break;
      case 3: printf ("Unsummon"); break;
      case 4: printf ("Left Hand Throw"); break;
      case 5: printf ("Left Hand Swing"); break;
      case 217: printf ("Scroll of Identify"); break;
      case 218: printf ("Tome of Identify"); break;
      case 219: printf ("Scroll of Townportal"); break;
      case 220: printf ("Tome of Townportal"); break;
      default:
	if ((d2s->button_action[i] >= 6)
	    && (d2s->button_action[i] < 6 + 5 * 30))
	  printf (skill_names[d2s->button_action[i] - 6].label);
	else if ((d2s->button_action[i] >= 221)
		 && (d2s->button_action[i] < 221 + 2 * 30))
	  printf (skill_names[d2s->button_action[i] - 221 + 5 * 30].label);
	else
	  printf ("%ld", d2s->button_action[i]);
      }
    }
  putchar ('\n');

  if (d2s->hireling_id)
    {
      printf ("Hireling%s: ID = %#.8lx,\n",
	      d2s->hireling_died ? " (deceased)" : "", d2s->hireling_id);
      printf ("\t  Name = %d, Type = %d, Experience = %lu\n",
	      d2s->hireling_name, d2s->hireling_attribute,
	      d2s->hireling_experience);
    }
  /* All stats are optional */
  statp = (unsigned long *) &d2s->stats;
  for (i = 0; i < 16; i++)
    if (d2s->stat_bits & (1 << i))
      ((unsigned long *) &stats2)[i] = *(statp++);
  printf ("Strength: %lu\n", stats2.strength);
  printf ("Energy: %lu\n", stats2.energy);
  printf ("Dexterity: %lu\n", stats2.dexterity);
  printf ("Vitality: %lu\n", stats2.vitality);
  printf ("Stat Points Remaining: %lu\n", stats2.stat_points);
  printf ("Skill Choices Remaining: %lu\n", stats2.skill_points);
  printf ("Life: %g/%g\n", (double) stats2.life_current / 256.0,
	  (double) stats2.life_max / 256.0);
  printf ("Mana: %g/%g\n", (double) stats2.mana_current / 256.0,
	  (double) stats2.mana_max / 256.0);
  printf ("Stamina: %g/%g\n", (double) stats2.stamina_current / 256.0,
	  (double) stats2.stamina_max / 256.0);
  printf ("Level: %lu, ", stats2.level);
  printf ("%.0f%% to next level (experience: %lu/%lu)\n",
	  100.0 * (stats2.experience - experience_for_level[stats2.level])
	  / (experience_for_level[stats2.level + 1]
	     - experience_for_level[stats2.level]),
	  stats2.experience, experience_for_level[stats2.level + 1]);
  printf ("Gold in inventory: %lu\n", stats2.money);
  printf ("Gold in stash: %lu\n", stats2.stashed_gold);
  skillp = (unsigned char *) statp;

  /* Verify the skill list is at the expected location */
  if (*((unsigned short *) skillp) != *((unsigned short *) &"if"))
    {
      for (i = 1; i < d2s->length - (skillp - &d2s_data[0]); i++)
	{
	  if (*((unsigned short *) skillp) == *((unsigned short *) &"if"))
	    break;
	}
      if (*((unsigned short *) skillp) != *((unsigned short *) &"if"))
	{
	  printf ("Error: skill list is not at the expected location\n");
	  exit (1);
	}
      else
	{
	  printf ("Warning: %d bytes of data found before skill list\n", i);
	  skillp += i;
	}
    }
  n = (int) (sizeof (skill_names) / sizeof (skill_names[0]));
  printf ("Skills:\n");
  for (i = 0; i < n; i++)
    {
      if ((skill_names[i].class == d2s->class)
	  && skillp[skill_names[i].offset])
	printf ("%20s - level %d\n", skill_names[i].label,
		skillp[skill_names[i].offset]);
    }

  return (int) (&skillp[sizeof (union d2s_skills)] - &d2s_data[0]);
}

int
read_number (const char *prompt, int max_limit)
{
  char buffer[80], *endp;
  int value;

  while (1)
    {
      printf ("%s: ", prompt);
      fflush (stdout);
      fgets (buffer, sizeof (buffer), stdin);
      if (buffer[0] == '\n')
	return -1;

      value = strtol (buffer, &endp, 0);
      if (*endp && (*endp != '\n'))
	{
	  printf ("Bad numeric value; try again (or hit [Enter] to skip)\n");
	  continue;
	}
      if (value > max_limit)
	{
	  printf ("%d is too large; you can enter at most %d\n",
		  value, max_limit);
	  continue;
	}
      return value;
    }
}

int
read_yes_no (const char *prompt, int default_answer)
{
  char buffer[80];

  while (1)
    {
      printf ("%s? ", prompt);
      fflush (stdout);
      fgets (buffer, sizeof (buffer), stdin);
      if (buffer[0] == '\n')
	return default_answer;
      buffer[strlen (buffer) - 1] = '\0';

      if ((strcasecmp (buffer, "y") == 0)
	  || (strcasecmp (buffer, "yes") == 0))
	return 1;
      if ((strcasecmp (buffer, "n") == 0)
	  || (strcasecmp (buffer, "no") == 0))
	return 0;
      printf ("Huh?  Please answer yes or no.  ");
    }
}

int
read_skill_name (const char *prompt)
{
  char buffer[80];
  int skill, i, len;
  struct d2s_header * const d2s = (struct d2s_header *) &d2s_data[0];

  while (1)
    {
      printf ("%s: ", prompt);
      fflush (stdout);
      fgets (buffer, sizeof (buffer), stdin);
      len = strlen (buffer);
      if (buffer[len - 1] == '\n')
	buffer[--len] = '\0';
      if (!len)
	return -1;

      if (strcasecmp (buffer, "list") == 0)
	{
	  int column;
	  column = printf ("Valid skills are:");
	  for (i = 0; i < sizeof (skill_names) / sizeof (skill_names[0]); i++)
	    {
	      if (skill_names[i].class != d2s->class)
		continue;
	      column += printf (" '%s'", skill_names[i].label);
	      if ((i < sizeof (skill_names) / sizeof (skill_names[0]))
		  && column >= 76 - strlen (skill_names[i + 1].label))
		column = printf ("\n                ");
	    }
	  printf ("\n");
	  continue;
	}

      skill = -1;
      for (i = 0; i < sizeof (skill_names) / sizeof (skill_names[0]); i++)
	{
	  /* Only check the skills listed for this character class */
	  if (skill_names[i].class != d2s->class)
	    continue;

	  /* Exact match? */
	  if (strcasecmp (buffer, skill_names[i].label) == 0)
	    return i;

	  /* Partial match? */
	  if (strncasecmp (buffer, skill_names[i].label, len) == 0)
	    {
	      /* Ambiguous? */
	      if (skill >= 0)
		{
		  skill = -99;
		  break;
		}
	      skill = i;
	      continue;
	    }
	}

      if (skill >= 0)
	return skill;
      if (skill == -99)
	printf ("\"%s\" is ambiguous; please be more specific\n", buffer);
      else
	printf ("There is no skill matching \"%s\" for a %s\n",
		buffer, class_names[d2s->class]);
    }
}

const char * const stat_names[] = {
  "Strength", "Energy", "Dexterity", "Vitality", "Life",
  "Mana", "Stamina", "Experience", "Gold", "Skill",
  "Hireling's Experience"
};
#define STAT_STRENGTH	0
#define STAT_ENERGY	1
#define STAT_DEXTERITY	2
#define STAT_VITALITY	3
#define STAT_LIFE	4
#define STAT_MANA	5
#define STAT_STAMINA	6
#define STAT_EXPERIENCE 7
#define STAT_GOLD	8
#define STAT_SKILL	9
#define STAT_HIRE_EXP	10

int
read_stat_name (const char *prompt)
{
  char buffer[80];
  int stat, i, len;

  while (1)
    {
      printf ("%s: ", prompt);
      fflush (stdout);
      fgets (buffer, sizeof (buffer), stdin);
      len = strlen (buffer);
      if (buffer[len - 1] == '\n')
	buffer[--len] = '\0';
      if (!len)
	return -1;

      if (strcasecmp (buffer, "list") == 0)
	{
	  printf ("Valid stats are:");
	  for (i = 0; i < sizeof (stat_names) / sizeof (stat_names[0]); i++)
	    {
	      printf (" %s", stat_names[i]);
	      if (i == 4)
		printf ("\n                ");
	    }
	  printf ("\n");
	  continue;
	}

      if (strcasecmp (buffer, "show") == 0)
	{
	  dump_known_data ();
	  continue;
	}

      stat = -1;
      for (i = 0; i < sizeof (stat_names) / sizeof (stat_names[0]); i++)
	{
	  /* Exact match? */
	  if (strcasecmp (buffer, stat_names[i]) == 0)
	    return i;

	  /* Partial match? */
	  if (strncasecmp (buffer, stat_names[i], len) == 0)
	    {
	      /* Ambiguous? */
	      if (stat >= 0)
		{
		  stat = -99;
		  break;
		}
	      stat = i;
	      continue;
	    }
	}

      if (stat >= 0)
	return stat;
      if (stat == -99)
	printf ("\"%s\" is ambiguous; please be more specific\n", buffer);
      else
	printf ("There is no stat matching \"%s\"\n", buffer);
    }
}

int
lookup_prereq (int class, int offset)
{
  int i;

  for (i = 0; i < sizeof (skill_names) / sizeof (skill_names[0]); i++)
    {
      if ((skill_names[i].class == class)
	  && (skill_names[i].offset == offset))
	return i;
    }
  return -1;
}

int
check_prereqs (int skill, unsigned char *skillp)
{
  int prq;

  if (skill_names[skill].prereq[0] < 0)
    return 0;
  prq = lookup_prereq (skill_names[skill].class,
		       skill_names[skill].prereq[0]);
  if (!skillp[skill_names[prq].offset])
    {
      printf ("%s requires %s first\n", skill_names[skill].label,
	      skill_names[prq].label);
      if (check_prereqs (prq, skillp) < 0)
	return -1;
      printf ("Do you wish to put a skill point in %s",
	      skill_names[prq].label);
      if (read_yes_no ("", 1))
	skillp[skill_names[prq].offset] = 1;
      else
	return -1;
    }

  if (skill_names[skill].prereq[1] < 0)
    return 1;
  prq = lookup_prereq (skill_names[skill].class,
		       skill_names[skill].prereq[1]);
  if (!skillp[skill_names[prq].offset])
    {
      printf ("%s requires %s first\n", skill_names[skill].label,
	      skill_names[prq].label);
      if (check_prereqs (prq, skillp) < 0)
	return -1;
      printf ("Do you wish to put a skill point in %s",
	      skill_names[prq].label);
      if (read_yes_no ("", 1))
	skillp[skill_names[prq].offset] = 1;
      else
	return -1;
    }

  return 1;
}

int
load_game (void)
{
  FILE *fp;
  int status;
  unsigned long saved_checksum;
  struct d2s_header * const d2s = (struct d2s_header *) &d2s_data[0];

  fp = fopen (d2s_filename, "rb");
  if (fp == NULL)
    {
      perror (d2s_filename);
      return -1;
    }
  status = fread (d2s_data, 1, sizeof (d2s_data), fp);
  fclose (fp);
  if (status < sizeof (struct d2s_header))
    {
      if (status >= 0)
	fprintf (stderr, "Error reading %s: only %d bytes read\n",
		 d2s_filename, status);
      else
	perror (d2s_filename);
      return -1;
    }

  /* Make sure the magic number, checksum, and file length are valid. */
  if (d2s->magic != 0xaa55aa55)
    {
      fprintf (stderr, "Error: invalid magic number in header of %s\n",
	       d2s_filename);
      return -1;
    }
  if (d2s->version != 92)
    {
      fprintf (stderr, "Error: incorrect file version");
      if (d2s->version == 71)
	fprintf (stderr, "; this is for Diablo v1.06 or earlier\n");
      else if (d2s->version == 87)
	fprintf (stderr, "; this is for Diablo v1.07\n");
      else if (d2s->version == 89)
	fprintf (stderr, "; this is for Diablo v1.08\n");
      else
	fprintf (stderr, " %lu; expecting 92\n", d2s->version);
      return -1;
    }
  if (d2s->length != status)
    {
      fprintf (stderr, "Error: invalid length field in header"
	       " - %lu (read %d bytes)\n", d2s->length, status);
      return -1;
    }
  saved_checksum = d2s->checksum;
  compute_checksum ();
  if (saved_checksum != d2s->checksum)
    {
      fprintf (stderr, "Error: checksum mismatch - read %#lx, computed %#lx\n",
	       saved_checksum, d2s->checksum);
      if (!read_yes_no ("Shall I try to process the file anyway", 0))
	return -1;
    }

  return 0;
}

int
save_game (void)
{
  char *backup_name;
  int len, suffix;
  FILE *fp;
  int status;
  struct d2s_header * const d2s = (struct d2s_header *) &d2s_data[0];

  d2s->timestamp = (unsigned long) time (NULL);
  compute_checksum ();

  len = strlen (d2s_filename);
  backup_name = (char *) malloc (len + 10);
  strcpy (backup_name, d2s_filename);
  for (suffix = 1; suffix <= 9999; suffix++)
    {
      snprintf (&backup_name[len], 10, ".~%d~", suffix);
      if (access (backup_name, F_OK) < 0)
	break;
    }
  if (rename (d2s_filename, backup_name) < 0)
    {
      perror (backup_name);
      return -1;
    }

  fp = fopen (d2s_filename, "wb");
  if (fp == NULL)
    {
      perror (d2s_filename);
      return -1;
    }
  status = fwrite (d2s_data, 1, d2s->length, fp);
  fclose (fp);
  if (status < d2s->length)
    {
      perror (d2s_filename);
      return -1;
    }

  return 0;
}

void
print_message (const char *fmt, ...)
{
  va_list ap;

  va_start (ap, fmt);
  vfprintf (stderr, fmt, ap);
  va_end (ap);
}

int
main (int argc, char **argv)
{
  int i, item_offset;
  struct d2s_header * const d2s = (struct d2s_header *) &d2s_data[0];
  unsigned char *datap;

  progname = argv[0];
  if (argc < 2)
    {
      printf ("Usage: %s <name>.d2s\n", progname);
      return 1;
    }

  d2s_filename = argv[1];
  if (load_game ())
    return 1;

  item_offset = dump_known_data ();
  if (read_yes_no ("Do you wish to see the item list", 0))
    {
      datap = dump_item_data (&d2s_data[item_offset],
			      d2s->length - item_offset);
      if ((datap[0] == 'J') && (datap[1] == 'M'))
	{
	  if (*((unsigned short *) &datap[2]))
	    {
	      printf ("Corpse data: %#.4x", *((unsigned short *) &datap[2]));
	      for (i = 0; i < 12; i++)
		printf (" %.2x", datap[4 + i]);
	      printf ("\n");
	      datap += 16;
	      datap = dump_item_data
		(datap, d2s->length - (datap - &d2s_data[0]));
	    }
	  else
	    datap += 4;

	  if (d2s->expansion && (datap[0] == 'j') && (datap[1] == 'f'))
	    {
	      datap += 2;
	      if (d2s->hireling_id)
		{
		  printf ("Hireling item list:\n");
		  datap = dump_item_data
		    (datap, d2s->length - (datap - &d2s_data[0]));
		}
	      if ((datap[0] == 'k') && (datap[1] == 'f'))
		{
		  datap += 2;
		  if (datap[0] == 0)
		    datap++;
		}
	    }
	}
      if (datap != &d2s_data[d2s->length])
	printf ("Error: data parsed does not match file length!\n");
    }

  return 0;
}
