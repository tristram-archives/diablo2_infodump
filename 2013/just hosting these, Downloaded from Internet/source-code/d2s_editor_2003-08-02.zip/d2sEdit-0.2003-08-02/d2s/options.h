/* User-configurable options for managing the d2s game and item editors.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

struct d2s_options {
  struct {
    struct {
      /* Allowed changes to the character file */
      int	default_read_only;
      int	name;
      int	title;
      int	expansion;
      int	hardcore;
      int	died;
      int	up_and_down;
      int	experience;
      int	level;
      int	stats;
      int	stats2;
      int	stat_points;
      int	skills;
      int	skill_points;
      int	gold;
      int	item_location;
      int	inventory;
      int	corpse_inventory;
      int	backward;
      int	all_difficulties;
      int	npcs;
      int	acts;
      int	act_location;
      int	waypoints;
      int	quests_complete;
      int	quests_intermediate;
      int	hireling_add;
      int	hireling_name;
      int	hireling_attribute;
      int	hireling_experience;
      int	hireling_level;
      int	hireling_inventory;
    } edit;
    struct {
      /* Automatic changes, requirement tests, and range checking */
      int	level_experience;
      int	level_stats;
      int	stats_points;
      int	stats_stats2;
      int	stats2_base;
      int	skills_points;
      int	skills_level;
      int	skills_skills;
      int	auto_skill;
      int	equipment_level;
      int	equipment_class;
      int	act_entry;
      int	auto_act;
      int	act_quest;
      int	act_location;
      int	act_waypoint;
      int	quest_quest;
      int	quest_inventory;
      int	auto_quest;
      int	freeform;
    } link;
  } character;
  struct {
    struct {
      /* Allowed changes to items */
      int	potion;
      int	gem;
      int	identified;
      int	personalized;
      int	newbie;
      int	ethereal;
      int	quantity;
      int	durability;
      int	base_durability;
      int	defense;
      int	socketed_gems;
      int	socket_count;
      int	fingerprint;
      int	level;
      int	quality;
      int	picture;
      int	magic_name;
      int	set_or_unique;
      int	magic_properties;
      int	magic_property_list;
    } edit;
    struct {
      /* Automatic changes and range checking for items */
      int	item_expansion;
      int	durability_ethereal;
      int	durability_base;
      int	quantity_max;
      int	durability_max;
      int	defense_max;
      int	quality_magic;
      int	properties_range;
      int	show_popup;
    } link;
  } item;
};

extern struct d2s_options options;
extern int debug;
