/* d2sArmorItem -- C++ class that holds an internal representation
 *		   of a Diablo II v1.09 piece of armor.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sMagic.h"
#include "d2sQuality.h"
#include "functions.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Initialize member fields based on an item table entry.
   Does *NOT* alter fields based on variable data. */
void
d2sArmorItem::SetItemType (table_entry_t tent)
{
  int	min_defense, max_defense;

  /* Choose a defense rating at random */
  min_defense = GetEntryIntegerField (table_entry, "minac");
  max_defense = GetEntryIntegerField (table_entry, "maxac");
  base_defense = min_defense + rand() % (max_defense - min_defense + 1);

  /* These may be overridden later */
  base_chance_to_block = 0;
  belt_boxes = 4;
  /* Determine the armor class from the item types table */
  if (this->is_of_type ("belt"))
    {
      armor_class = BELT_CLASS;
      belt_boxes = GetEntryIntegerField
	(LookupIndexedTableEntry ("belts",
				  GetEntryIntegerField (table_entry,
							"belt")),
	 "numboxes");
      if ((belt_boxes < 4) || (belt_boxes > MSIZE_BELT))
	{
	  print_message ("Item %s (\"%3.3s\") has an invalid belt size (%d)\n",
			 base_name, item_ID.ch, belt_boxes);
	  error_str = "Bad belt table entry";
	  /* Show all possible boxes, just in case */
	  belt_boxes = MSIZE_BELT;
	}
    }
  else if (this->is_of_type ("tors"))
    armor_class = BODY_ARMOR_CLASS;
  else if (this->is_of_type ("boot"))
    armor_class = BOOT_CLASS;
  else if (this->is_of_type ("glov"))
    armor_class = GLOVE_CLASS;
  else if (this->is_of_type ("helm"))
    armor_class = HELMET_CLASS;
  else if (this->is_of_type ("shld"))
    {
      armor_class = SHIELD_CLASS;
      /* All shields have a minimum 20% chance to block;
	 that is the bias for the item table. */
      base_chance_to_block = GetEntryIntegerField (table_entry, "block") + 20;
    }
  else
    {
      print_message ("Item %s (\"%3.3s\") has an unknown armor type"
		     " (\"%s\")\n", base_name, item_ID.ch,
		     GetEntryStringField (table_entry, "type"));
      armor_class = UNKNOWN_ARMOR_CLASS;
    }
}

/* The same, but called after an item has been constructed
   when an item is being transformed into another type. */
int
d2sArmorItem::ChangeItemType (table_entry_t tent)
{
  /* Class restriction: make sure we're changing to another armor item */
  if ( ! IsTypeAMemberOf (GetEntryStringField (tent, "type"), "armo"))
    {
      fprintf (stderr, "%s: Internal error: attempt to change an armor class"
	       " item to a %s\n", progname,
	       GetEntryStringField (LookupTableEntry
				    ("itemtypes", "Code",
				     GetEntryStringField (tent, "type")),
				    "ItemType"));
      return -1;
    }
  /* Change the type in the base class first */
  if (this->d2sDurableItem::ChangeItemType (tent) < 0)
    return -1;
  /* Then change ourself */
  SetItemType (tent);
  return 0;
}

/* Create a new, blank piece of armor (to be filled in later) */
d2sArmorItem::d2sArmorItem (void)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (), d2sExtendedItem (), d2sDurableItem ()
{
  /* Override the default item class */
  item_class = ARMOR_ITEM;
  nvop = this;
  armor_class = UNKNOWN_ARMOR_CLASS;
  base_defense = 0;
  base_chance_to_block = 0;
  belt_boxes = 4;
}

/* Create a new, specific armor item as described by the armor table entry
   (using default variable attributes) */
d2sArmorItem::d2sArmorItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (tent), d2sExtendedItem (tent), d2sDurableItem (tent)
{
  /* Override the default item class */
  item_class = ARMOR_ITEM;
  /* Change the nvop (very important) */
  nvop = this;
  /* Set our member fields from the item tables */
  SetItemType (tent);
}

/* Copy an existing piece of armor */
d2sArmorItem::d2sArmorItem (const d2sArmorItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (source), d2sExtendedItem (source), d2sDurableItem (source)
{
  /* Change the nvop (very important) */
  nvop = this;

  /* Now copy our own fields */
  this->armor_class = source.armor_class;
  this->base_defense = source.base_defense;
  this->base_chance_to_block = source.base_chance_to_block;
  this->belt_boxes = source.belt_boxes;
}

/* Copy a piece of armor. */
d2sItem *
d2sArmorItem::Copy (void) const
{
  d2sArmorItem *new_item = new d2sArmorItem (*this);
  return (d2sItem *) new_item;
}

/* Armor adds their quality, defense, durability, requirements,
   and magic properties (and for shields, chance to block)
   to the descrption. */
char *
d2sArmorItem::FullDescription (void) const
{
  char *descr;
  const char *cstr;
  int len;
  int required_dexterity, required_strength, required_level;
  int max_durability;

  /* Start with the item's full name. */
  descr = FullName();
  len = strlen (descr);

  /* The next line is the (current) defense rating */
  cstr = LookupStringByKey ("ItemStats1h");
  if (cstr == NULL)
    cstr = "Defense:";
  descr = (char *) xrealloc
    (descr, len + 1 + strlen (cstr) + sizeof (" %04d"));
  len += sprintf (&descr[len], "\n%s %d", cstr, Defense());

  /* If this is a shield, show the Chance to Block next */
  if (armor_class == SHIELD_CLASS)
    {
      cstr = LookupStringByKey ("ItemStats1r");
      if (cstr == NULL)
	cstr = "Chance to Block:";
      descr = (char *) xrealloc
	(descr, len + 1 + strlen (cstr) + sizeof (" %3d%%"));
      len += sprintf (&descr[len], "\n%s %d%%", cstr, ChanceToBlock());

      /* If the owner is a Paladin, the shield also has Smite Damage.
	 I think these settings should eventually become members of
	 the armor class (or Durable Item class, since it's shared by
	 shields, boots, and 1-handed weapons.) */
      if (!character || (character->GetCharacterClass() == PALADIN_CLASS))
	{
	  cstr = LookupStringByKey ("ItemStats1o");
	  if (cstr == NULL)
	    cstr = "Smite Damage:";
	  descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
	  len += sprintf (&descr[len], "\n%s", cstr);
	  /* NOTE: The misspelling below is intentional!
	     (It got stuck in the string translation tables that way.) */
	  cstr = LookupStringByKey ("ItemStast1k");
	  if (cstr == NULL)
	    cstr = "to";
	  descr = (char *) xrealloc
	    (descr, len + sizeof (" %3d %s %3d") + strlen (cstr));
	  len += sprintf (&descr[len], " %d %s %d",
			  GetEntryIntegerField (table_entry, "mindam"), cstr,
			  GetEntryIntegerField (table_entry, "maxdam"));
	}
    }

  /* Next is the durability */
  max_durability = MaxDurability();
  if (max_durability)
    {
      cstr = LookupStringByKey ("ItemStats1d");
      if (cstr == NULL)
	cstr = "Durability:";
      descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
      len += sprintf (&descr[len], "\n%s", cstr);
      cstr = LookupStringByKey ("ItemStats1j");
      if (cstr == NULL)
	cstr = "of";
      descr = (char *) xrealloc
	(descr, len + sizeof (" %3d %s %3d") + strlen (cstr));
      len += sprintf (&descr[len], " %d %s %d",
		      durability, cstr, MaxDurability());
    }

  /* If there is a class restriction on the item, that goes here */
  if (restricted_item)
    {
      descr = (char *) xrealloc
	(descr, len + sizeof ("\n(Necromancer Only)") + 1);
      len += sprintf (&descr[len], "\n(%s Only)",
		      GetCharacterClassName (class_restriction));
    }

  /* Required dexterity, strength, and level (all optional) */
  required_dexterity = RequiredDexterity();
  if (required_dexterity)
    {
      cstr = LookupStringByKey ("ItemStats1f");
      if (cstr == NULL)
	cstr = "Required Dexterity:";
      descr = (char *) xrealloc
	(descr, len + 1 + strlen (cstr) + sizeof (" %8(not)d") + 1);
      len += sprintf (&descr[len], "\n%s %d", cstr, required_dexterity);
    }

  required_strength = RequiredStrength();
  if (required_strength)
    {
      cstr = LookupStringByKey ("ItemStats1e");
      if (cstr == NULL)
	cstr = "Required Strength:";
      descr = (char *) xrealloc
	(descr, len + 1 + strlen (cstr) + sizeof (" %8(not)d") + 1);
      len += sprintf (&descr[len], "\n%s %d", cstr, required_strength);
    }

  required_level = RequiredLevel();
  if (required_level > 1)
    {
      cstr = LookupStringByKey ("ItemStats1p");
      if (cstr == NULL)
	cstr = "Required Level:";
      descr = (char *) xrealloc
	(descr, len + 1 + strlen (cstr) + sizeof (" %3d") + 1);
      len += sprintf (&descr[len], "\n%s %d", cstr, required_level);
    }

  /* I'm not entirely certain in what order this field is shown... */
  if ( ! max_durability)
    {
      cstr = LookupStringByKey ("ModStre9s");
      if (cstr == NULL)
	cstr = "Indestructible";
      descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
      len += sprintf (&descr[len], "\n%s", cstr);
    }

  /* Finish up */
  return FinishFullDescription (descr);
}

/* Get the armor's current defense rating (after mods) */
int
d2sArmorItem::Defense (void) const
{
  int defense = base_defense;
  d2sMagic	*comb;
  d2sMagicProperty *property;

  /* There are three mods that affect defense,
     and they must be applied in the correct order. */
  comb = CombinedProperties();
  property = comb->Lookup ("ac");
  if (property != NULL)
    defense += property->FieldData(0) - property->Bias();

  property = comb->Lookup ("ac/lvl");
  if (property != NULL)
    defense += (((character == NULL) ? 0 : character->GetCharacterLevel())
		* property->FieldData(0) / 8);

  property = comb->Lookup ("ac%");
  if (property != NULL)
    defense = (int) ((double) defense
		     * (100 + property->FieldData(0) - property->Bias())
		     / 100.0);
  delete comb;
  return defense;
}

/* Get the shield's current chance to block (after mods) */
int
d2sArmorItem::ChanceToBlock (void) const
{
  int chance_to_block = base_chance_to_block;
  d2sMagic	*comb;
  d2sMagicProperty *property;

  comb = CombinedProperties();
  property = comb->Lookup ("block");
  if (property != NULL)
    chance_to_block = (int)
      ((double) chance_to_block
       * (100 + property->FieldData(0) - property->Bias())
       / 100.0);
  delete comb;
  return chance_to_block;
}

/* Read class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after reading the quality fields
   and before reading the magic properties. */
int
d2sArmorItem::ReadItemSpecificData (struct bit_stream *bstream)
{
  /* Read the defense rating.
     Remember, the value is biased by 10. */
  base_defense = bstream_read_field (bstream, 10) - 10;

  /* Read the base and current durability. */
  base_durability = bstream_read_field (bstream, 8);
  if (base_durability)
    durability = bstream_read_field (bstream, 8);
  else
    durability = 0;

  /* If the armor is socketed, read the number of sockets. */
  if (socketed_item)
    {
      num_sockets = bstream_read_field (bstream, 4);
      if (num_sockets > MaximumNumberOfSockets())
	{
	  print_message ("Warning: %s found with %d sockets"
			 " (the maximum number of sockets is %d)\n",
			 base_name, num_sockets, MaximumNumberOfSockets());
	  error_str = "Invalid number of sockets";
	}
    }

  return 0;
}

/* Write class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after writing the quality fields
   and before writing the magic properties. */
int
d2sArmorItem::WriteItemSpecificData (struct bit_stream *bstream)
{
  /* Write the defense rating.
     Remember, the value is biased by 10. */
  bstream_write_field (bstream, 10, base_defense + 10);

  /* Write the base and current durability. */
  if (MaxDurability())
    {
      bstream_write_field (bstream, 8, base_durability);
      bstream_write_field (bstream, 8, durability);
    } else {
      /* This should take care of clearing the durability
	 if an "indestructible" property was added. */
      bstream_write_field (bstream, 8, 0);
    }

  /* If the armor is socketed, write the number of sockets. */
  if (socketed_item)
    bstream_write_field (bstream, 4, num_sockets);

  return 0;
}

/* Set the defense rating of an item */
int
d2sArmorItem::SetDefense (int new_defense)
{
  if (base_defense == new_defense)
    /* Nothing is changed */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.defense)
    {
      error_str = "You may not change an item's defense rating";
      print_message (error_str);
      return -1;
    }
  if (options.item.link.defense_max)
    {
      /* Check against the range given for this item in the armor table */
      if (new_defense < GetEntryIntegerField (table_entry, "minac")) {
	print_message ("The minimum defense rating for a %s is %d\n",
		       base_name,
		       GetEntryIntegerField (table_entry, "minac"));
	error_str = "Defense too low";
	return -1;
      }
      if (new_defense > GetEntryIntegerField (table_entry, "maxac")) {
	print_message ("The maximum defense rating for a %s is %d\n",
		       base_name,
		       GetEntryIntegerField (table_entry, "maxac"));
	error_str = "Defense too high";
	return -1;
      }
    }

  /* Check the range, accounting for a +10 bias */
  if ((new_defense < -10) || (new_defense > 0x3ff - 10))
    {
      print_message ("Defense (%d) is out of range; must be %s than %d\n",
		     new_defense, (new_defense < 0) ? "greater" : "less",
		     (new_defense < 0) ? -10 : (0x3ff - 10));
      error_str = "Invalid defense";
      return -1;
    }

  base_defense = new_defense;
  MarkDirty ();
  return 0;
}
