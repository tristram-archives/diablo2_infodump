/* d2sExtendedItem -- C++ intermediate class from which extended items
 *		      (anything whose data is more than 14 bytes) are derived.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <assert.h>
#include <ctype.h>
#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sQuality.h"
#include "d2sMagic.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>


/**************** EXTENDED ITEM SUPERCLASS ****************
 *
 * This class encompasses functions common
 * to all extended item classes.
 **********************************************************/

/* Clear the class member fields (called by constructors) */
void
d2sExtendedItem::Init (void)
{
  /* Override the default item class */
  item_class = UNKNOWN_EXTENDED_ITEM;
  nvop = this;
  /* Generate a new unique ID */
  unique_id = ((rand() << 12) & 0xffff0000UL) | ((rand() >> 4) & 0xffff);
  /* Set the level anywhere above the minimum */
  level = GetEntryIntegerField (table_entry, "level");
  level += rand() % 10;
  if (level > 99)
    level = 99;
  end_bit = 0;
  num_sockets = 0;
  set_field = 0;
  /* Set the quality to normal by default */
  item_quality = new d2sQuality;
  color_group = 0;
  memset (inscription, 0, sizeof (inscription));
  /* Set the magic properties to an empty list */
  magic_properties = new d2sMagic;
}

/* Create a new, blank extended item (to be filled in later) */
d2sExtendedItem::d2sExtendedItem (void)
  : d2sItem ()		// Construct the base class part first
{
  Init ();
  item_quality->SetItem (this);
  magic_properties->AssignTo (this);
}

/* Create a new, specific extended item
   as described by the item table entry */
d2sExtendedItem::d2sExtendedItem (table_entry_t tent)
  : d2sItem (tent)	// Construct the base class part first
{
  table_entry_t magic_entry;

  Init ();
  /* Presumably, if we have an item table entry, we know the item class.
     If it's not a plain extended item, this will be overridden
     by a derived class. */
  item_class = EXTENDED_ITEM;
  color_group = GetEntryIntegerField (table_entry, "InvTrans");

  /* Set the end bit.  *** PURELY A GUESS *** */
  end_bit = (*this == "ibk");

  /* If this is supposed to be a unique item, find and add the unique
     attributes.  Most quest items which are extended items are
     uniques.  The two exceptions are the Horadric Cube and Potion of
     Life.  Unfortunately, I can't find any table entry which tells
     the difference, so all we can do is look in the uniqueitems table
     and see if the item is there. */
  if (quest_item)
    {
      magic_entry = LookupTableEntry ("uniqueitems", "code", Code());
      if (magic_entry != NULL)
	{
	  delete item_quality;
	  item_quality = NULL;
	  item_quality = new d2sUniqueQuality
	    (GetEntryIntegerField (magic_entry, NULL), table_entry);
	  item_quality->RegenerateProperties (magic_properties);
	}
    }

  /* Some items (charms and derivatives) cannot be created as normal items.
     Therefore we must remove the 'normal' quality and replace it
     with some default (or random) magic property. */
  else if (GetEntryIntegerField (type_entry, "Magic"))
    {
      delete item_quality;
      /* We must clear item_quality because
	 the new quality may reference it */
      item_quality = NULL;
      item_quality = new d2sMagicalQuality (table_entry);
      item_quality->RegenerateProperties (magic_properties);
    }
  item_quality->SetItem (this);
  magic_properties->AssignTo (this);
}

/* Copy an existing extended item */
d2sExtendedItem::d2sExtendedItem (const d2sExtendedItem &source)
  : d2sItem (source)	// Construct the base class part first
{
  /* Change the nvop (must be overridden by a derived class) */
  nvop = this;

  /* Generate a new unique ID */
  unique_id = ((rand() << 12) & 0xffff0000UL) | ((rand() >> 4) & 0xffff);
  /* Copy the rest of the integer fields */
  this->level = source.level;
  this->end_bit = source.end_bit;
  this->num_sockets = source.num_sockets;
  this->set_field = source.set_field;
  this->color_group = source.color_group;

  /* Copy the item quality */
  this->item_quality = source.item_quality->Copy();

  /* Copy the inscription */
  memcpy (this->inscription, source.inscription, sizeof (inscription));

  /* Create a new d2sMagic object which is a copy of the source's */
  this->magic_properties = new d2sMagic (*source.magic_properties);

  this->item_quality->SetItem (this);
  this->magic_properties->AssignTo (this);

  /* The item is dirty, because of the new unique ID. */
  dirty = True;
}

/* Destructor */
d2sExtendedItem::~d2sExtendedItem ()
{
  /* Delete the attached quality and magic properties */
  delete item_quality;
  delete magic_properties;
}

/* Create and return a copy of this item. */
d2sItem *
d2sExtendedItem::Copy (void) const
{
  d2sExtendedItem *new_item = new d2sExtendedItem (*this);
  return (d2sItem *) new_item;
}

/* Create an item by filling in data from a file. */
int
d2sExtendedItem::Read (struct data_stream *dstream)
{
  int		status = 0, set_count;
  int		n;
  struct bit_stream bstream;

  /* The d2sItem class reads the fixed part of the item data */
  if (this->d2sItem::Read (dstream) < 0)
    return -1;

  /* All right!  Variable field time.  This is a little tricky,
     because our derived classes know more about the variable
     fields than we do.  We depend on the derived classes'
     ReadItemSpecificData() function.  Note that
     d2sItem::Read(dstream) will have already set the dstream
     pointer to just after the fixed header. */
  dstream->ptr -= sizeof (struct item_header);
  bstream_set (bstream, dstream->ptr, 8 * sizeof (struct item_header) - 1,
	       (dstream->end - dstream->ptr));
  unique_id = bstream_read_field (&bstream, 32);
  level = bstream_read_field (&bstream, 7);
  delete item_quality;
  item_quality = NULL;
  item_quality = ReadQualityFromItem (&bstream, table_entry);
  assert (item_quality != NULL);
  if (item_quality->GetErrorMessage() != NULL)
    {
      error_str = item_quality->GetErrorMessage();
      status = -1;
    }

  /* If the item has a Rune Word, read the Rune Word value. */
  if (runeworded_item)
    runeword_id = bstream_read_field (&bstream, 16);

  /* If the item has been personalized, read the (previous) owner's name */
  memset (inscription, 0, sizeof (inscription));
  if (personalized_item)
    for (n = 0; n < (int) sizeof (inscription); n++)
      {
	inscription[n] = bstream_read_field (&bstream, 7);
	if (!inscription[n])
	  break;
      }

  /* Unknown field; this is usually 0, but is 1 on a Tome of Identify */
  end_bit = bstream_read_field (&bstream, 1);
  if (end_bit && (*this != "ibk")) {
    print_message ("Non-zero bit follows the quality data (%s bit %lu)\n",
		   base_name, bstream.ptr - 1);
    error_str = "Non-zero bit follows the quality data";
    return -1;
  }

  if (item_class != UNKNOWN_EXTENDED_ITEM)
    /* Read the item-specific data */
    if (ReadItemSpecificData (&bstream) < 0)
      status = -1;

  /* If there was any read error up to this point, don't try reading more. */
  if (status < 0)
    goto guess_extended_item_length;

  if (item_class != UNKNOWN_EXTENDED_ITEM)
    {
      /* If this item is part of a set, read the set count. */
      set_count = 0;
      if (item_quality->QualityClass() == PART_OF_A_SET)
	{
	  set_count = bstream_read_field (&bstream, 5);
	  ((d2sQPartOfASet *) item_quality)->SetSetCount (set_count);
	}

      /* Read the magic properties */
      if (magic_properties->Read (&bstream) < 0)
	{
	  error_str = magic_properties->GetErrorMessage();
	  /* If there was an error reading the properties,
	     we need to make a best guess at how much more
	     data there is in this item. */
	  status = -1;
	  goto guess_extended_item_length;
	}

      /* If this item is runeworded, the runeword properties *begin*
	 with an end-of-property-list tag. */
      if (runeworded_item && (magic_properties->Append (&bstream) < 0))
	{
	  error_str = magic_properties->GetErrorMessage();
	  status = -1;
	  goto guess_extended_item_length;
	}

      /* If this item is part of a set, we'll need to
	 read additional lists of magic properties. */
      while (set_count)
	{
	  if (magic_properties->Append (&bstream) < 0)
	    {
	      error_str = magic_properties->GetErrorMessage();
	      status = -1;
	      goto guess_extended_item_length;
	    }
	  set_count >>= 1;
	}

      /* After reading the last bit field, we *MUST* align
	 the bit stream pointer to the next byte boundary. */
      bstream.ptr = (bstream.ptr + 7) & ~7;
    }

  else
    {
      /* This next part is critical.  Because we don't know what the item
	 is, there is going to be a undetermined number of bits from the
	 current bstream position to the end of the magic data.  We must
	 guess how long the item data is.  There are two ways of going
	 about this:

	 1) We could search the bit stream for a string of 9 consecutive 1
	 bits.  This is very problematic, because besides the difficulty
	 in scanning bit strings, 9 1's may be a valid data field for some
	 magic properties, and is also NOT necessarily a terminator for
	 set items.

	 2) We could search the byte stream for the next "JM" item header.
	 Although it's possible to have this sequence embedded in item
	 data, it is highly unlikely.  Which makes it a perfect
	 candidate.  Note that in the event this is the last item in the
	 list, we must also check for certain other section headers.
      */
    guess_extended_item_length:
      /* Rewind back to the end of the fixed header */
      bstream_set (bstream, dstream->ptr, 8 * sizeof (struct item_header),
		   (dstream->end - dstream->ptr));
      /* Search for the next item marker or section marker */
      while (bstream.ptr < bstream.size)
	{
	  if ((*((short *) &bstream.base[bstream.ptr / 8])
	       == *((short *) &"JM"))
	      || (*((short *) &bstream.base[bstream.ptr / 8])
		  == *((short *) &"jf"))
	      || (*((short *) &bstream.base[bstream.ptr / 8])
		  == *((short *) &"kf")))
	    break;
	  bstream.ptr += 8;
	}
      print_message ("Attempting to guess %s's item length (from offset %p)"
		     " ... trying %d bytes\n", base_name,
		     dstream->ptr - dstream->base, bstream.ptr / 8);
      if (display_question (0, 2, "Cancel", "Continue",
			    "The item data in this file may be corrupt. "
			    " Do you want to continue loading?"))
	status = 0;
    }

  /* This needed to be delayed until after the magic properties were read */
  item_quality->SetItem (this);

  /* Now that we have all the data, save it. */
  ReplaceRawData (bstream.base, bstream.ptr / 8);

  /* Update the data stream */
  dstream->ptr += bstream.ptr / 8;

  assert (magic_properties != NULL);
  return status;
}

/* Initialize member fields based on an item table entry.
   This one cannot be called from a constructor. */
int
d2sExtendedItem::ChangeItemType (table_entry_t new_entry)
{
  /* Call the base class' version */
  if (this->d2sItem::ChangeItemType (new_entry) < 0)
    return -1;

  color_group = GetEntryIntegerField (table_entry, "InvTrans");

  /* Not knowing whether the item was changed from one class to
     another, we can't determine whether to keep the existing
     quality rating and magic properties. */
  item_quality->SetItem (new_entry);

  /* TO-DO: recompute the required level based on the magic property 'ease' */
  return 0;
}

/* If an extended item was changed, change it back. */
void
d2sExtendedItem::DiscardChanges (void)
{
  struct bit_stream bstream;
  int		n, set_count;

  if (!dirty)
    /* No changes; nothing to do */
    return;

  /* Discard changes to the base class first. */
  this->d2sItem::DiscardChanges ();

  /* Re-read the unique ID and item level fields */
  bstream_set (bstream, raw_data,
	       sizeof (struct item_header) * 8 - 1, raw_length);
  unique_id = bstream_read_field (&bstream, 32);
  level = bstream_read_field (&bstream, 7);

  /* Re-read the item quality */
  delete item_quality;
  item_quality = NULL;
  item_quality = ReadQualityFromItem (&bstream, table_entry);

  /* If the item has a Rune Word, re-read the Rune Word value. */
  if (runeworded_item)
    runeword_id = bstream_read_field (&bstream, 16);

  /* Re-read the owner's name */
  memset (inscription, 0, sizeof (inscription));
  if (personalized_item)
    for (n = 0; n < (int) sizeof (inscription); n++)
      {
	inscription[n] = bstream_read_field (&bstream, 7);
	if (!inscription[n])
	  break;
      }

  /* Unknown field */
  end_bit = bstream_read_field (&bstream, 1);

  if (item_class != UNKNOWN_EXTENDED_ITEM)
    /* Re-read the item-specific data */
    ReadItemSpecificData (&bstream);

  if (item_class != UNKNOWN_EXTENDED_ITEM)
    {
      /* If this item is part of a set, read the set count. */
      set_count = 0;
      if (item_quality->QualityClass() == PART_OF_A_SET)
	{
	  set_count = bstream_read_field (&bstream, 5);
	  ((d2sQPartOfASet *) item_quality)->SetSetCount (set_count);
	}

      if (magic_properties->Read (&bstream) >= 0)
	{
	  while (set_count)
	    {
	      if (magic_properties->Append (&bstream) < 0)
		break;
	      set_count >>= 1;
	    }
	}
    }

  /* This needed to be delayed until after the magic properties were read */
  item_quality->SetItem (this);
}

static const char *
trim_graphic_name (const char *invname)
{
  /* Should we eventually replace the item graphics
     with their original names? */
  if ((invname[0] == 'i') && (invname[1] == 'n') && (invname[2] == 'v'))
    return &invname[3];
  else
    return invname;
}

/* Return the graphic used to display an item.
   Computed on the fly because some items have variable graphics
   which depend on the state of the item quality. */
const char *
d2sExtendedItem::Graphic (void) const
{
  char field_name[12];
  const char *cstr;

  if (item_quality->QualityClass() == PART_OF_A_SET) {
    cstr = GetEntryStringField (table_entry, "setinvfile");
    if (cstr[0])
      return trim_graphic_name (cstr);
  }
  else if (item_quality->QualityClass() == UNIQUE_QUALITY) {
    cstr = GetEntryStringField (table_entry, "uniqueinvfile");
    if (cstr[0])
      return trim_graphic_name (cstr);
  }

  if ((int) item_quality->Picture()
      < GetEntryIntegerField (type_entry, "VarInvGfx"))
    {
      sprintf (field_name, "InvGfx%d",
	       item_quality->Picture() + 1);
      cstr = GetEntryStringField (type_entry, field_name);
      if (cstr[0])
	return trim_graphic_name (cstr);
    }

  /* No alternate graphic.  Use the original. */
  return graphic;
}

/* Return the required level to use an item.
   Computed on the fly because it depends on the state
   of the item quality and any magical modifiers. */
int
d2sExtendedItem::RequiredLevel (void) const
{
  int max_level;
  d2sMagic *comb;
  d2sMagicProperty *property;

  /* Start by taking the max of the base level
     and the quality's required level. */
  max_level = item_quality->RequiredLevel();
  if (base_level > max_level)
    max_level = base_level;

  /* The only magic property (that I know of) which modifies
     the requirements is "ease". */
  comb = CombinedProperties();
  property = comb->Lookup ("ease");
  if (property != NULL)
    max_level = (int)
      ((double) max_level
       * (100 + property->FieldData(0) - property->Bias()) / 100.0);
  delete comb;
  return max_level;
}

/* Return whether an item is an Expansion Set item.
   It qualifies if the item is new to the expansion set,
   if the quality setting contains expansion-specific names,
   or if any of the magic properties are new to the expansion set. */
int
d2sExtendedItem::is_expansion_item (void) const
{
  return (expansion_item
	  || (item_quality->is_expansion())
	  || (magic_properties->is_expansion()));
}

/* For most extended items, the combined properties
   is just a copy of the item's own properties. */
d2sMagic *
d2sExtendedItem::CombinedProperties (void) const
{
  return new d2sMagic (*magic_properties);
}

/* Return an item's fully qualified name (dynamically allocated) */
char *
d2sExtendedItem::FullName (void) const
{
  char *full_name, *qual_name, *rune_name = NULL;
  const char *rune_word = NULL, *gemmed = NULL;
  int	len, len_rw = 0, len_insc = 0, len_rn = 0, len_qn;

  /* Get the parts of the name */
  qual_name = item_quality->QualifyName (base_name);
  len_qn = strlen (qual_name);

  if (personalized_item)
    len_insc = strlen (inscription);

  if (gem_count
      && ((item_class == ARMOR_ITEM) || (item_class == WEAPON_ITEM))) {
    d2sDurableItem *ditem = (d2sDurableItem *) *((d2sItem *) this);
    /* If there are any runes installed, include the rune name */
    rune_name = ditem->RuneName();
    if (rune_name != NULL)
      len_rn = strlen (rune_name);

      /* Check for a Rune Word */
    if (runeworded_item
	&& ((item_class == ARMOR_ITEM) || (item_class == WEAPON_ITEM))) {
      d2sDurableItem *ditem = (d2sDurableItem *) *((d2sItem *) this);
      rune_word = ditem->RuneWord();
      if (rune_word != NULL)
	len_rw = strlen (rune_word);
      else {
	if (debug)
	  fprintf (stderr, "%s: Internal error: no rune word found for this"
		   " %s\n which has the runeword bit set (\'%s\').\n",
		   progname, base_name, ditem->RuneName());
      }
    } else if (item_quality->QualityClass() < MAGIC_QUALITY) {
      /* With no rune word, include the prefix "Gemmed"
	 on normal quality items. */
      gemmed = TranslateString ("Gemmed");
      len_rw = strlen (gemmed);
    }
  }

  /* Allocate the return string */
  full_name = (char *) xmalloc (len_rw + 1 + len_insc + 3
				+ len_qn + 2 + len_rn + 2);
  /* Write it out by pieces */
  len = 0;
  if (rune_word != NULL)
    len += sprintf (&full_name[len], "%s\n", rune_word);
  if (personalized_item)
    len += sprintf (&full_name[len], "%s'%s ", inscription,
		    (((inscription[len_insc - 1] == 's')
		      || (inscription[len_insc - 1] == 'x'))
		     ? "" : "s"));
  if (gemmed != NULL)
    len += sprintf (&full_name[len], "%s ", gemmed);
  len += sprintf (&full_name[len], "%s", qual_name);
  free (qual_name);
  if (rune_name != NULL) {
    len += sprintf (&full_name[len], "\n'%s'", rune_name);
    free (rune_name);
  }

  return full_name;
}

/* Return the color of an item.  Computed on the fly because
   it usually depends on the state of the item quality. */
const char *
d2sExtendedItem::Color (void) const 
{
  if (color_group >= 5)
    return item_quality->Color();
  else if (color_group && (item_quality->Color() != NULL))
    return GetEntryStringField
      (LookupTableEntry ("colors", "Code", item_quality->Color()),
       "Grey");
  else
    return NULL;
}

/* Change whether an item has been identified */
int
d2sExtendedItem::SetIdentified (int set_identified)
{
  struct item_header *ih = (struct item_header *) raw_data;

  if ((int) identified_item == set_identified)
    /* Nothing to do */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.identified
      || (!set_identified && (character != NULL)
	  && !options.character.edit.backward
	  && (ih != NULL) && !ih->identified)
      || (item_quality->QualityClass() < MAGIC_QUALITY))
    {
      print_message ("You may not %s this %s\n",
		     set_identified ? "identify" : "hide", base_name);
      error_str = "Identified status may not be modified";
      return -1;
    }

  identified_item = (set_identified != 0);
  MarkDirty ();
  return 0;
}

/* Change the unique ID of an extended item */
int
d2sExtendedItem::GenerateUniqueID (void)
{
  /* We don't pay attention to any of the global options,
     as this is normally used when creating a copy of an existing item. */
  if (read_only())
    {
      print_message ("You may not alter this %s's fingerprint\n", base_name);
      error_str = "Fingerprint may not be modified";
      return -1;
    }

  unique_id = ((rand() << 12) & 0xffff0000UL) | ((rand() >> 4) & 0xffff);
  MarkDirty ();
  return 0;
}

int
d2sExtendedItem::SetUniqueID (unsigned long new_finger)
{
  if (new_finger == unique_id)
    /* Nothing to do */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.fingerprint)
    {
      print_message ("You may not alter this %s's fingerprint\n", base_name);
      error_str = "Fingerprint may not be modified";
      return -1;
    }

  unique_id = new_finger;
  MarkDirty ();
  return 0;
}

/* Change an item's level */
int
d2sExtendedItem::SetLevel (int new_level)
{
  if (new_level == level)
    /* Nothing to do */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.level)
    {
      error_str = "You may not edit the item level";
      print_message (error_str);
      return -1;
    }

  /* Make sure the level meets the item minimum */
  if (!options.character.link.freeform) {
    if (new_level < GetEntryIntegerField (table_entry, "level")) {
      print_message ("Level is too low; a %s must be at least level %d",
		     base_name, GetEntryIntegerField (table_entry, "level"));
      error_str = "Level too low";
      return -1;
    }
    /* Set and unique items also have a minimum level requirement */
    if (item_quality->QualityClass() == PART_OF_A_SET) {
      int set_id = ((d2sQPartOfASet *) item_quality)->SetID();
      table_entry_t set_entry = LookupIndexedTableEntry
	("setitems", /* HACK! */ (set_id < 32) ? set_id : (set_id + 1));
      if (new_level < GetEntryIntegerField (set_entry, "level")) {
	print_message ("Level is too low; %s items must be at least level %d",
		       ((d2sQPartOfASet *) item_quality)->SetName(),
		       GetEntryIntegerField (set_entry, "level"));
	error_str = "Level too low";
	return -1;
      }
    }
    else if (item_quality->QualityClass() == UNIQUE_QUALITY) {
      int uniq_id = ((d2sUniqueQuality *) item_quality)->UniqueID();
      table_entry_t uniq_entry
	= LookupIndexedTableEntry ("uniqueitems", uniq_id);
      if (new_level < GetEntryIntegerField (uniq_entry, "Level")) {
	print_message ("Level is too low; %s must be at least level %d",
		       ((d2sUniqueQuality *) item_quality)->UniqueName(),
		       GetEntryIntegerField (uniq_entry, "Level"));
	error_str = "Level too low";
	return -1;
      }
    }
  }
  if (new_level > 100)
    {
      error_str = "Level is too high";
      print_message (error_str);
      return -1;
    }

  level = new_level;
  MarkDirty ();
  return 0;
}

/* Personalize an item */
int
d2sExtendedItem::Personalize (const char *owner_name)
{
  int		len, dash_seen = 0;
  struct item_header *ih;

  /* Check the argument */
  if (owner_name == NULL)
    /* Accept this as the same as removing the inscription */
    owner_name = "";
  for (len = 0; (len < (int) sizeof (inscription)) && owner_name[len]; len++)
    {
      if ((owner_name[len] == '-') || (owner_name[len] == '_'))
	{
	  dash_seen++;
	  continue;
	}
      if (!isalpha (owner_name[len]) && !options.character.link.freeform)
	{
	  error_str = "Invalid name";
	  return -1;
	}
    }

  if ((dash_seen > 1) && !options.character.link.freeform)
    {
      error_str = "Too many dashes";
      return -1;
    }

  if ((len == 1) && !options.character.link.freeform)
    {
      error_str = "Name too short";
      return -1;
    }
  if (len > (int) sizeof (inscription) - 1)
    {
      error_str = "Name too long";
      return -1;
    }

  if (!options.character.link.freeform)
    {
      if ((owner_name[0] == '-') || (owner_name[0] == '_'))
	{
	  error_str = "Name may not begin with a dash";
	  return -1;
	}
      if ((owner_name[len - 1] == '-') || (owner_name[len - 1] == '_'))
	{
	  error_str = "Name may not end with a dash";
	  return -1;
	}
    }

  if (strcmp (owner_name, inscription) == 0)
    /* Nothing to do */
    return 0;

  if (!GetEntryStringField (table_entry, "nameable")
      && !options.character.link.freeform)
    {
      print_message ("You cannot personalize %s%s\n",
		     quest_item ? "" : "a ", base_name);
      error_str = "Item cannot be personalized";
      return -1;
    }

  /* Check for editing options */
  if (read_only() || !options.item.edit.personalized)
    {
      print_message ("You may not personalize this %s\n", base_name);
      error_str = "Item may not be personalized";
      return -1;
    }
  ih = (struct item_header *) raw_data;
  if ((ih != NULL) && ih->personalized && personalized_item
      && !options.character.edit.backward)
    {
      if (owner_name[0])
	print_message ("This %s has already been personalized by %s\n",
		       base_name, inscription);
      else
	print_message ("You may not remove %s's name\n",
		       inscription);
      error_str = "Existing personalization may not be changed";
      return -1;
    }

  /* The change is allowed */
  memset (inscription, 0, sizeof (inscription));
  strcpy (inscription, owner_name);
  personalized_item = (inscription[0] != 0);
  MarkDirty ();
  return 0;
}

/* Change an item's quality */
int
d2sExtendedItem::ChangeQuality (int new_quality)
{
  d2sQuality	*q;
  StringList	uniques;
  int		uniq_id, min_level;

  if ((new_quality < LOW_QUALITY) || (new_quality > CRAFTED_QUALITY))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to\n"
		 " d2sExtendedItem::ChangeQuality(%d)\n",
		 progname, new_quality);
      error_str = "Invalid argument";
      return -1;
    }

  /* Check the argument against the item type */
  if ((new_quality != NORMAL_QUALITY)
      && GetEntryIntegerField (type_entry, "Normal"))
    {
      print_message ("%s must be normal",
		     GetEntryStringField (type_entry, "ItemType"));
      error_str = "Item must be normal";
      return -1;
    }
  if ((new_quality < MAGIC_QUALITY)
      && GetEntryIntegerField (type_entry, "Magic"))
    {
      print_message ("%s must be magical",
		     GetEntryStringField (type_entry, "ItemType"));
      error_str = "Item must be magical";
      return -1;
    }
  if (((new_quality == RARE_QUALITY) || (new_quality == CRAFTED_QUALITY))
      && !GetEntryIntegerField (type_entry, "Rare"))
    {
      print_message ("%s can not be rare",
		     GetEntryStringField (type_entry, "ItemType"));
      error_str = "Item can not be rare";
      return -1;
    }

  /* Check for editing options */
  if (read_only() || !options.item.edit.quality)
    {
      print_message ("You may not change this %s's quality", base_name);
      error_str = "Quality may not be changed";
      return -1;
    }

  switch (new_quality)
    {
    case LOW_QUALITY:
      q = new d2sLowQuality ();
      break;

    case NORMAL_QUALITY:
      q = new d2sQuality ();
      break;

    case HIGH_QUALITY:
      q = new d2sHighQuality ();
      break;

    case MAGIC_QUALITY:
      q = new d2sMagicalQuality (table_entry);
      break;

    case PART_OF_A_SET:
      /* We need to find a set member that matches this item type */
      uniques = GetSetsContainingItem
	(Code(), ((character == NULL) ? True
		  : character->is_expansion()), level);
      if (uniques == NULL) {
	/* Make one more attempt, at a different item level. */
	uniques = GetSetsContainingItem
	  (Code(), ((character == NULL) ? True
		    : character->is_expansion()), 0);
	if (uniques == NULL) {
	  printf ("There are no %s's in any set", base_name);
	  error_str = "Item can not be part of a set";
	  return -1;
	}
      }
      uniq_id = (uniques->string[rand() % uniques->count].value
		 /* The set item list records the member index as well
		    as the set ID.  The member index is in bits 0-2. */
		 >> 3);
      free (uniques);
      /* Make sure the item level is OK for this set item */
      min_level = GetEntryIntegerField
	(LookupIndexedTableEntry
	 ("setitems", (uniq_id < 16) ? uniq_id : (uniq_id + 1)),
	 "level");
      if (level < min_level)
	level = min_level;
      q = new d2sQPartOfASet (uniq_id, table_entry);
      break;

    case RARE_QUALITY:
      q = new d2sRareQuality (table_entry);
      break;

    case UNIQUE_QUALITY:
      /* We need to find a unique item that matches this item type */
      uniques = GetUniqueItemsMatching
	(Code(), ((character == NULL) ? True
		  : character->is_expansion()), level);
      if (uniques == NULL) {
	/* Make one more attempt, at a different item level. */
	uniques = GetUniqueItemsMatching
	  (Code(), ((character == NULL) ? True
		    : character->is_expansion()), 0);
	if (uniques == NULL) {
	  printf ("There are no unique %s's", base_name);
	  error_str = "Item can not be unique";
	  return -1;
	}
      }
      uniq_id = uniques->string[rand() % uniques->count].value;
      free (uniques);
      /* Make sure the item level is OK for this unique item */
      min_level = GetEntryIntegerField
	(LookupIndexedTableEntry ("uniqueitems", uniq_id), "Level");
      if (level < min_level)
	level = min_level;
      q = new d2sUniqueQuality (uniq_id, table_entry);
      break;

    case CRAFTED_QUALITY:
      q = new d2sCraftedQuality (table_entry);
      break;
    }

  /* Replace the current quality with the new one */
  delete item_quality;
  item_quality = q;
  if (options.item.link.quality_magic)
    /* Regenerate our magic properties based on the new quality */
    item_quality->RegenerateProperties (magic_properties);
  item_quality->SetItem (this);
  MarkDirty ();
  return 0;
}

int
d2sExtendedItem::ChangeQuality (d2sQuality *new_quality)
{
  int		min_level;

  /* Check the argument against the item type */
  if ((new_quality->QualityClass() != NORMAL_QUALITY)
      && GetEntryIntegerField (type_entry, "Normal"))
    {
      print_message ("%s must be normal",
		     GetEntryStringField (type_entry, "ItemType"));
      error_str = "Item must be normal";
      return -1;
    }
  if ((new_quality->QualityClass() < MAGIC_QUALITY)
      && GetEntryIntegerField (type_entry, "Magic"))
    {
      print_message ("%s must be magical",
		     GetEntryStringField (type_entry, "ItemType"));
      error_str = "Item must be magical";
      return -1;
    }
  if (((new_quality->QualityClass() == RARE_QUALITY)
       || (new_quality->QualityClass() == CRAFTED_QUALITY))
      && !GetEntryIntegerField (type_entry, "Rare"))
    {
      print_message ("%s can not be rare",
		     GetEntryStringField (type_entry, "ItemType"));
      error_str = "Item can not be rare";
      return -1;
    }

  /* Check for editing options */
  if (read_only() || !options.item.edit.quality)
    {
      print_message ("You may not change this %s's quality", base_name);
      error_str = "Quality may not be changed";
      return -1;
    }

  /* Check item level requirements */
  if (new_quality->QualityClass() == PART_OF_A_SET) {
    int set_id = ((d2sQPartOfASet *) new_quality)->SetID();
    min_level = GetEntryIntegerField
      (LookupIndexedTableEntry
       ("setitems", (set_id < 16) ? set_id : (set_id + 1)),
       "level");
  }
  else if (new_quality->QualityClass() == UNIQUE_QUALITY)
    min_level = GetEntryIntegerField
      (LookupIndexedTableEntry
       ("uniqueitems", ((d2sUniqueQuality *) new_quality)->UniqueID()),
       "Level");

  new_quality->SetItem (this);
  if (new_quality->GetErrorMessage() != NULL)
    {
      new_quality->SetItem ((d2sExtendedItem *) NULL);
      error_str = new_quality->GetErrorMessage();
      display_error (error_str);
      return -1;
    }

  /* Replace the current quality with the new one */
  delete item_quality;
  item_quality = new_quality;
  if (options.item.link.quality_magic)
    /* Regenerate our magic properties based on the new quality */
    item_quality->RegenerateProperties (magic_properties);
  item_quality->SetItem (this);
  MarkDirty ();
  return 0;
}

/* Read class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after reading the quality fields
   and before reading the magic properties. */
int
d2sExtendedItem::ReadItemSpecificData (struct bit_stream *bstream)
{
  if (item_class == EXTENDED_ITEM)
    /* No item-specific data */
    return 0;

  fprintf (stderr, "Internal error! d2sExtendedItem::ReadItemSpecificData()\n"
	   " called by \"%s\"", base_name);
  error_str = "Internal error";
  return -1;
}

/* Derived classes call this to append common fields
   to their full description: required level, magic properties,
   sockets, ethereal */
char *
d2sExtendedItem::FinishFullDescription (char *descr) const
{
  int n, len = strlen (descr);
  char *magic_descr;
  const char *cstr, *set_names;
  d2sMagic *combined_magic;
  d2sQPartOfASet *set_q;

#if 0
  /* If the item has been personalized, insert the inscription
     in front of the (complete) item name. */
  if (personalized_item) {
    n = strlen (inscription);
    magic_descr = (char *) xmalloc (n + 3 + len + 1);
    len = sprintf (magic_descr, "%s'%s %s", inscription,
		   ((inscription[n - 1] == 's')
		    || (inscription[n - 1] == 'x')) ? "" : "s",
		   descr);
    free (descr);
    descr = magic_descr;
  }
#endif

  /* If this item hasn't been identified,
     add the line "Unidentified".  Then tell what it is anyway. :) */
  if (!identified_item) {
    cstr = LookupStringByKey ("ItemStats1b");
    if (cstr == NULL)
      cstr = "Unidentified";
    descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
    len += sprintf (&descr[len], "\n%s", cstr);
  }

  /* Add the magical properties.  Some items need to add their
     inherent properties to the regular magic properties before we
     print them out.  Durable items need to add the active properties
     of any attached gems, runes, or jewels. */
  combined_magic = CombinedProperties();
  /* Some properties need to refer to the owner for display */
  combined_magic->AssignTo ((d2sExtendedItem *) this);
  magic_descr = combined_magic->Display();
  delete combined_magic;
  if (magic_descr != NULL)
    {
      descr = (char *) xrealloc (descr, len + strlen (magic_descr) + 1);
      strcpy (&descr[len], magic_descr);
      len += strlen (&descr[len]);
      free (magic_descr);
    }

  /* Number of sockets and/or ethereal property */
  if (ethereal_item)
    {
      descr = (char *) xrealloc
	(descr, len + sizeof ("\nEthereal (Cannot be Repaired)") + 1);
      len += sprintf (&descr[len], "\nEthereal (Cannot be Repaired)");
    }

  n = num_sockets;
  if (n && ((item_class == ARMOR_ITEM) || (item_class == WEAPON_ITEM)))
    n = ((d2sDurableItem *) *((d2sItem *) this))->ModNumberOfSockets();
  if (n)
    {
      cstr = TranslateString ("Socketable");
      descr = (char *) xrealloc (descr, len + 2 + strlen (cstr)
				 + sizeof (" (%d)") + 1);
      len += sprintf (&descr[len], "%s%s (%d)",
		      ethereal_item ? ", " : "\n", cstr, n);
    }

  /* If this item is part of a set, we also need to display the name
     of the set, and the names of all (known) members of the set. */
  if (item_quality->QualityClass() == PART_OF_A_SET)
    {
      set_q = (d2sQPartOfASet *) item_quality;

      set_names = set_q->SetName();
      if (set_names != NULL)
	{
	  descr = (char *) xrealloc
	    (descr, len + 2 + strlen (set_names) + 1);
	  len += sprintf (&descr[len], "\n\n%s", set_names);

	  for (n = 0; n < set_q->NumberOfItemsInSet(); n++)
	    {
	      set_names = set_q->GetMemberName (n);
	      if (set_names != NULL)
		{
		  descr = (char *) xrealloc
		    (descr, len + 1 + strlen (set_names) + 1);
		  len += sprintf (&descr[len], "\n%s", set_names);
		}
	    }
	}
    }

  return descr;
}

/* Commit changes made to the item to the raw data field. */
void
d2sExtendedItem::CommitChanges (void)
{
  struct bit_stream bstream;
  int		n;

  /* Commit changes to the base class first */
  this->d2sItem::CommitChanges ();

  /* Write the unique ID and item level fields */
  bstream_set (bstream, raw_data,
	       sizeof (struct item_header) * 8 - 1, raw_length);
  bstream_write_field (&bstream, 32, unique_id);
  bstream_write_field (&bstream, 7, level);

  /* Write the item quality */
  item_quality->Write (&bstream);

  if (runeworded_item)
    /* Write the Rune Word value */
    bstream_write_field (&bstream, 16, runeword_id);

  if (personalized_item)
    /* Write the owner's name */
    for (n = 0; n < (int) sizeof (inscription); n++)
      {
	bstream_write_field (&bstream, 7, inscription[n]);
	if (!inscription[n])
	  break;
      }

  /* Write the unknown bit */
  bstream_write_field (&bstream, 1, end_bit);

  /* Write the item-specific data */
  WriteItemSpecificData (&bstream);

  /* If this item is part of a set, write the set count. */
  if (item_quality->QualityClass() == PART_OF_A_SET)
    bstream_write_field (&bstream, 5,
			 ((d2sQPartOfASet *) item_quality)->GetSetCount());

  /* Write the magic properties */
  magic_properties->Write (&bstream);

  /* Pad the last byte with 0 bits */
  if (bstream.ptr & 7)
    bstream_write_field (&bstream, 8 - (bstream.ptr & 7), 0);

  /* In case the raw data needed reallocation, update the raw data pointer */
  raw_data = bstream.base;
  /* Set the new data length */
  raw_length = bstream.ptr / 8;

  /* The raw data is clean. */
  dirty = 0;
  return;
}

/* Write class-specific fields to the item data bit stream.
   Called by d2sExtendedItem after writing the quality fields
   and before writing the magic properties. */
int
d2sExtendedItem::WriteItemSpecificData (struct bit_stream *bstream)
{
  if (item_class == EXTENDED_ITEM)
    /* No item-specific data */
    return 0;

  fprintf (stderr, "Internal error! d2sExtendedItem::WriteItemSpecificData()\n"
	   " called by \"%s\"", base_name);
  error_str = "Internal error";
  return -1;
}
