/* d2sData-Item -- functions in the d2sData class
 *		   that deal with a character's items.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "functions.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include "d2sData.h"
#include "d2sItem.h"
#include <dmalloc.h>

/* Forward declarations: */

static inline void append_to_item_list (struct item_list_t *, d2sItem *);
static void remove_from_item_list (struct item_list_t *, d2sItem *);


/********************* NON-CLASS FUNCTIONS **********************/

/* List maintenance functions */
static inline void
append_to_item_list (struct item_list_t *list, d2sItem *item)
{
  *(list->tail) = item;
  item->next = NULL;
  item->pprev = list->tail;
  list->tail = &item->next;
  list->count++;
}

static void
remove_from_item_list (struct item_list_t *list, d2sItem *item)
{
  if (item->next == NULL)
    {
      if (list->tail != &item->next)
	{
	  fprintf (stderr, "%s: Internal error: item list corrupted\n",
		   progname);
	  exit (1);
	}
      list->tail = item->pprev;
      *(list->tail) = NULL;
    }
  else
    {
      item->next->pprev = item->pprev;
      *(item->pprev) = item->next;
      item->next = NULL;
    }
  list->count--;
}

/*********************** CLASS FUNCTIONS ************************/

/* Search a character's items for an object */
d2sItem *
d2sData::find_carried_item (const char *item_code) const
{
  d2sItem *item;

  for (item = item_list.head; item != NULL; item = item->next)
    if (*item == item_code)
      return item;
  for (item = corpse_item_list.head; item != NULL; item = item->next)
    if (*item == item_code)
      return item;
  for (item = hireling_item_list.head; item != NULL; item = item->next)
    if (*item == item_code)
      return item;
  return NULL;
}

d2sItem *
d2sData::GetItemFrom (int area, int col, int row) const
{
  switch (area) {
  case ITEM_AREA_EQUIPPED:
    if ((unsigned) col >= MSIZE_EQUIPMENT)
      return NULL;
    return equipment[col];

  case ITEM_AREA_BELT:
    col += row * 4;
    if ((unsigned) col >= MSIZE_BELT)
      return NULL;
    return belt[col];

  case ITEM_AREA_INVENTORY:
    if (((unsigned) col >= HSIZE_INVENTORY)
	|| ((unsigned) row >= VSIZE_INVENTORY))
      return NULL;
    return inventory[row][col];

  case ITEM_AREA_STASH:
    if (((unsigned) col >= HSIZE_STASH)
	|| ((unsigned) row >= (is_expansion () ? VSIZE_STASH
			       : (VSIZE_STASH / 2))))
      return NULL;
    return stash[row][col];

  case ITEM_AREA_CUBE:
    if (((unsigned) col >= HSIZE_CUBE)
	|| ((unsigned) row >= VSIZE_CUBE))
      return NULL;
    return cube[row][col];

  case ITEM_AREA_PICKED:
    return picked_item;

  case ITEM_AREA_CORPSE:
    /* We don't have any type of layout for this. */
    return NULL;

  case ITEM_AREA_HIRELING:
    if ((unsigned) col >= MSIZE_EQUIPMENT)
      return NULL;
    return hireling_equipment[col];
  }
  /* We shouldn't reach this point */
  return NULL;
}

/* Remove an item from the character.  (The item is disassociated
   from the character -- i.e., no longer in the item list --
   but is not destroyed.) */
int
d2sData::RemoveItem (d2sItem *old_item)
{
  /* Check the argument */
  if (old_item == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: NULL argument to"
		 " d2sData::RemoveItem\n", progname);
      error_str = "Invalid argument";
      return -1;
    }
  if (old_item->Owner() != this)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: attempt to remove"
		 " %s (%p)%s %s from %s (%p)\n", progname,
		 (old_item->Owner() == NULL) ? "an unclaimed"
		 : old_item->Owner()->GetCharacterName(), old_item->Owner(),
		 (old_item->Owner() == NULL) ? "" : "'s",
		 old_item->Name(), name, this);
      error_str = "Character does not possess this item";
      return -1;
    }

  /* Do not allow removing socketed gems with this function */
  if (old_item->Location() == ITEM_AREA_SOCKETED)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: called d2sData::RemoveItem()"
		 " to remove a socketed item\n", progname);
      error_str = "Internal error";
      return -1;
    }

  /* Is removing items allowed? */
  if (read_only || !options.character.edit.inventory)
    {
      error_str = "You may not remove items";
      print_message (error_str);
      return -1;
    }

  /* Okay then... */
  if (remove_item (old_item) < 0)
    return -1;

  /* Once the item is removed from the inventory lists,
     remove it from the linked list of items. */
  switch (old_item->Location())
    {
    default:
      remove_from_item_list (&item_list, old_item);
      break;
    case ITEM_AREA_CORPSE:
      remove_from_item_list (&corpse_item_list, old_item);
      break;
    case ITEM_AREA_HIRELING:
      remove_from_item_list (&hireling_item_list, old_item);
      break;
    }

  /* Now that we no longer have the item,
     tell the item it doesn't have an owner. */
  old_item->RemoveFromOwner();

  if (options.character.link.quest_inventory && old_item->is_quest_item())
    {
      /* TO-DO: Find out which quest this belonged to
	 and update the quest state */
    }

  MarkDirty ();
  return 0;
}

/* The the actual work of removing an item.
   Return -1 if there is an error (e.g., item not found). */
int
d2sData::remove_item (d2sItem *old_item)
{
  int found, i, j;
  coordinate_t size, position;

  /* Use the item's location to find the structure member
     that references the item. */
  size = old_item->Size();
  position = old_item->Position();
  switch (old_item->Location())
    {
    case ITEM_AREA_EQUIPPED:
      if (equipment[position.x] != old_item)
	goto error_item_location;
      /* The item was found in the expected slot.  Remove it. */
      equipment[position.x] = NULL;
      /* If this is a two-handed weapon, we need to remove it
	 from the opposite slot as well. */
      if ((position.x == (int) EQUIPPED_ON_RIGHT_HAND)
	  || (position.x == (int) EQUIPPED_ON_ALT_RIGHT_HAND)) {
	if (equipment[position.x + 1] == old_item)
	  equipment[position.x + 1] = NULL;
      } else if ((position.x == (int) EQUIPPED_ON_LEFT_HAND)
		 || (position.x == (int) EQUIPPED_ON_ALT_LEFT_HAND)) {
	if (equipment[position.x - 1] == old_item)
	  equipment[position.x - 1] = NULL;
      }
      /* If we've just removed the belt, reset the belt size. */
      if (equipment[EQUIPPED_ON_WAIST] == NULL)
	belt_size = 4;
      break;

    case ITEM_AREA_BELT:
      if (belt[position.x] != old_item)
	goto error_item_location;
      belt[position.x] = NULL;
      break;

    case ITEM_AREA_INVENTORY:
      if ((inventory[position.y][position.x] != old_item)
	  || (inventory[position.y + size.y - 1]
	      [position.x + size.x - 1] != old_item))
	goto error_item_location;
      /* Remove the item from all boxes which it covers */
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  inventory[position.y + i][position.x + j] = NULL;
      break;

    case ITEM_AREA_STASH:
      if ((stash[position.y][position.x] != old_item)
	  || (stash[position.y + size.y - 1]
	      [position.x + size.x - 1] != old_item))
	goto error_item_location;
      /* Remove the item from all boxes which it covers */
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  stash[position.y + i][position.x + j] = NULL;
      break;

    case ITEM_AREA_CUBE:
      if ((cube[position.y][position.x] != old_item)
	  || (cube[position.y + size.y - 1]
	      [position.x + size.x - 1] != old_item))
	goto error_item_location;
      /* Remove the item from all boxes which it covers */
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  cube[position.y + i][position.x + j] = NULL;
      break;

    case ITEM_AREA_CORPSE:
      if (corpse_equipment[position.x] != old_item)
	goto error_item_location;
      corpse_equipment[position.x] = NULL;
      if ((position.x == (int) EQUIPPED_ON_RIGHT_HAND)
	  || (position.x == (int) EQUIPPED_ON_ALT_RIGHT_HAND)) {
	if (corpse_equipment[position.x + 1] == old_item)
	  corpse_equipment[position.x + 1] = NULL;
      } else if ((position.x == (int) EQUIPPED_ON_LEFT_HAND)
		 || (position.x == (int) EQUIPPED_ON_ALT_LEFT_HAND)) {
	if (corpse_equipment[position.x - 1] == old_item)
	  corpse_equipment[position.x - 1] = NULL;
      }
      break;

    case ITEM_AREA_HIRELING:
      if (hireling_equipment[position.x] != old_item)
	goto error_item_location;
      hireling_equipment[position.x] = NULL;
      if ((position.x == (int) EQUIPPED_ON_RIGHT_HAND)
	  || (position.x == (int) EQUIPPED_ON_ALT_RIGHT_HAND)) {
	if (hireling_equipment[position.x + 1] == old_item)
	  hireling_equipment[position.x + 1] = NULL;
      } else if ((position.x == (int) EQUIPPED_ON_LEFT_HAND)
		 || (position.x == (int) EQUIPPED_ON_ALT_LEFT_HAND)) {
	if (hireling_equipment[position.x - 1] == old_item)
	  hireling_equipment[position.x - 1] = NULL;
      }
      break;

    case ITEM_AREA_PICKED:
      if (picked_item != old_item)
	goto error_item_location;
      picked_item = NULL;
      break;

    case ITEM_AREA_SOCKETED:
      {
	d2sAttachItem *gem = (d2sAttachItem *) *old_item;
	if (gem->AttachedTo() == NULL) {
	  if (debug)
	    fprintf (stderr, "%s: Internal error: %s says it is socketed"
		     " but attached to nothing.\n", progname, gem->Name());
	  error_str = "Internal error";
	  return -1;
	}
	if (gem->AttachedTo()->RemoveGem (gem) < 0) {
	  error_str = gem->AttachedTo()->GetErrorMessage();
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to remove %s"
		     " from %s;\n %s\n", progname, gem->Name(),
		     gem->AttachedTo()->Name(), error_str);
	  return -1;
	}
	break;
      }

    default:
      /* Oops!  The item is not where it should be. */
    error_item_location:
      if (debug)
	fprintf (stderr, "%s: Internal error: item's location (%d,%d,%d)\n"
		 " does not correspond with character's inventory.\n",
		 progname, old_item->Location(), position.x, position.y);
      /* Take the long approach: search all of our lists
	     for this item.  If found, continue to remove it. */
      found = 0;
      for (i = 0; i < MSIZE_EQUIPMENT; i++) {
	if (equipment[i] == old_item) {
	  found = 1;
	  equipment[i] = NULL;
	}
	if (corpse_equipment[i] == old_item) {
	  found = 1;
	  corpse_equipment[i] = NULL;
	}
	if (hireling_equipment[i] == old_item) {
	  found = 1;
	  hireling_equipment[i] = NULL;
	}
      }
      for (i = 0; i < MSIZE_BELT; i++) {
	if (belt[i] == old_item) {
	  found = 1;
	  belt[i] = NULL;
	}
      }
      for (i = 0; i < VSIZE_INVENTORY; i++)
	for (j = 0; j < HSIZE_INVENTORY; j++) {
	  if (inventory[i][j] == old_item) {
	    found = 1;
	    inventory[i][j] = NULL;
	  }
	}
      for (i = 0; i < VSIZE_STASH; i++)
	for (j = 0; j < HSIZE_STASH; j++) {
	  if (stash[i][j] == old_item) {
	    found = 1;
	    stash[i][j] = NULL;
	  }
	}
      for (i = 0; i < VSIZE_CUBE; i++)
	for (j = 0; j < HSIZE_CUBE; j++) {
	  if (cube[i][j] == old_item) {
	    found = 1;
	    cube[i][j] = NULL;
	  }
	}
      if (picked_item == old_item) {
	found = 1;
	picked_item = NULL;
      }
      if (found)
	break;
      if (debug)
	fprintf (stderr, "%s: Internal error: %s (%p) claims to belong\n"
		 " to %s (%p), but %s doesn't have a record of the item.\n",
		 progname, old_item->Name(), old_item,
		 name, this, name);
      error_str = "Internal error";
      return -1;
    }

  /* If we've just removed the cube, clear has_cube */
  if (old_item == has_cube)
    has_cube = NULL;
  return 0;
}

/* Check whether an item can go into a certain equipment slot.
   If the item cannot be placed there, error_str is set and -1
   is returned.  A message is also printed out if the WARN
   argument is true.  If the slot is empty, 1 is returned.
   0 is returned if the given item is already in the slot. */
int
d2sData::check_equipment_slot_available (int area, d2sItem *item,
					 int slot, int warn)
{
  int		found, opposite_hand;
  const char	*cstr;
  d2sItem * const *equip;

  /* Only expansion characters have as many hands as Vishnu */
  if ((slot >= EQUIPPED_ON_ALT_RIGHT_HAND) && ! is_expansion())
    {
      if (warn)
	{
	  error_str = ("Standard game characters do not have"
		       " swappable equipment");
	  print_message (error_str);
	}
      return -1;

    }

  /* Can this type of item go in the requested slot? */
  if (item->CheckLocationChange (area, slot, 0, warn) < 0)
    return -1;

  if (options.character.link.equipment_class)
    {
      /* Is this a class-specific item? */
      cstr = GetEntryStringField (item->TypeTableEntry(), "Class");
      if (cstr[0]
	  && (strcmp (cstr, GetEntryStringField
		      (LookupIndexedTableEntry ("playerclass", char_class),
		       "Code"))
	      != 0))
	{
	  if (warn)
	    {
	      print_message
		("Only a %s can equip a %s\n",
		 GetEntryStringField
		 (LookupTableEntry ("playerclass", "code", cstr),
		  "Player Class"),
		 item->Name());
	      error_str = "Item is class restricted";
	    }
	  return -1;
	}
    }

  /* Is the slot available? */
  switch (area) {
  case ITEM_AREA_EQUIPPED: equip = &equipment[0]; break;
  case ITEM_AREA_CORPSE: equip = &corpse_equipment[0]; break;
  case ITEM_AREA_HIRELING: equip = &hireling_equipment[0]; break;
  }
  if (equip[slot] == NULL)
    found = 1;
  else if (equip[slot] != item)
    {
      /* There is an exception to this test.  If the slot is
	 'occupied' by a bow or crossbow which is really in
	 the opposite slot, and the item being equipped is
	 ammunition, we'll allow it. */
      cstr = GetEntryStringField (equip[slot]->TypeTableEntry(), "Shoots");
      if ((equip[slot]->Position().x == slot)
	  || (cstr[0] == 0)
	  || (strcmp (cstr, GetEntryStringField
		      (item->TypeTableEntry(), "Code")) != 0))
	{
	  if (warn)
	    {
	      print_message
		("%s%s already has a %s on his %s\n", name,
		 (area == ITEM_AREA_EQUIPPED)
		 ? "" : ((area == ITEM_AREA_CORPSE)
			 ? "'s corpse" : "'s mercenary"),
		 equip[slot]->Name(),
		 GetEntryStringField
		 (LookupIndexedTableEntry ("bodylocs", slot), "shortloc"));
	      error_str = "That slot is already occupied";
	    }
	  return -1;
	}
      /* Say that we found an empty spot,
	 so that we'll overwrite the current weapon pointer. */
      found = 1;
    }

  /* If we are equipping a two-handed weapon, check the other hand. */
  if ((item->Type() == WEAPON_ITEM)
      && GetEntryIntegerField (item->ItemTableEntry(), "2handed")
      && ! GetEntryIntegerField (item->ItemTableEntry(), "1or2handed"))
    {
      if ((slot == EQUIPPED_ON_RIGHT_HAND)
	  || (slot == EQUIPPED_ON_ALT_RIGHT_HAND))
	opposite_hand = slot + 1;
      else
	opposite_hand = slot - 1;
      if ((equip[opposite_hand] != NULL)
	  && (equip[opposite_hand] != item))
	{
	  /* If the opposite slot is occupied by a quiver
	     and we are equipping the matching bow/crossbow,
	     we'll allow it. */
	  cstr = GetEntryStringField (item->TypeTableEntry(), "Shoots");
	  if (cstr[0] == 0)
	    {
	      if (warn)
		{
		  print_message ("%s needs both hands free to use a %s\n",
				 name, item->Name());
		  error_str = "Other hand is already occupied";
		}
	      return -1;
	    }
	  if (strcmp (cstr, GetEntryStringField
		      (equip[opposite_hand]->TypeTableEntry(), "Code")) != 0)
	    {
	      if (warn)
		{
		  print_message
		    ("You cannot use a %s with a %s\n",
		     name,
		     GetEntryStringField (item->TypeTableEntry(), "ItemType"),
		     GetEntryStringField
		     (equip[opposite_hand]->TypeTableEntry(), "ItemType"));
		  error_str = "Other hand is already occupied";
		}
	      return -1;
	    }
	}
    }

  /* At this point, the destination looks okay. */
  return found;
}

/* Check whether an item can go into a given location.
   If the item cannot be placed there, error_str is set and -1
   is returned.  A message is also printed out if the WARN
   argument is true.  If the location is empty, 1 is returned.
   0 is returned if the given item is already in that location. */
int
d2sData::check_location_available (d2sItem *item, int area,
				   int *pcolumn, int *prow, int warn)
{
  int found, i, j, column = *pcolumn, row = *prow;
  coordinate_t size;

  found = 0;
  size = item->Size();
  switch (area)
    {
    default:
    error_bad_argument:
      if (debug) 
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::MoveItemTo(%s,%d,%d,%d)\n",
		 progname, item->Name(), area, column, row);
      error_str = "Invalid argument";
      return -1;

    case ITEM_AREA_EQUIPPED:
      if ((column < (int) EQUIPPED_ON_HEAD)
	  || (column > (int) EQUIPPED_ON_ALT_LEFT_HAND) || row)
	goto error_bad_argument;
      found = check_equipment_slot_available (area, item, column, True);
      if (found < 0)
	return -1;
      /* Does the character meet the item's requirements? */
      if (options.character.link.equipment_level
	  && (check_requirements (item, True) < 0))
	return -1;
      break;

    case ITEM_AREA_BELT:
      /* We'll allow a row/col as well as slot number */
      if (((unsigned) column >= MSIZE_BELT)
	  || (((unsigned) column >= 4) && row)
	  || ((unsigned) row >= MSIZE_BELT / 4))
	goto error_bad_argument;
      column += row * 4;
      *pcolumn = column;
      *prow = 0;
      /* Can this type of item go in the belt? */
      if (item->CheckLocationChange (area, column, row, warn) < 0)
	return -1;
      if (column >= belt_size)
	{
	  if (warn)
	    {
	      print_message ("You only have %d slots in your belt\n",
			     belt_size);
	      error_str = "Not enough belt slots";
	    }
	  return -1;
	}
      if (belt[column] == NULL)
	found = 1;
      else if (belt[column] != item)
	{
	  if (warn)
	    {
	      print_message ("%s already has a %s in that belt slot\n",
			     name, belt[column]->Name());
	      error_str = "That slot is already occupied";
	    }
	  return -1;
	}
      break;

    case ITEM_AREA_INVENTORY:
      if (((unsigned) column >= HSIZE_INVENTORY)
	  || ((unsigned) row >= VSIZE_INVENTORY))
	goto error_bad_argument;
      /* Clip the item's position according to its size */
      if (column > HSIZE_INVENTORY - size.x)
	*pcolumn = column = HSIZE_INVENTORY - size.x;
      if (row > VSIZE_INVENTORY - size.y)
	*prow = row = VSIZE_INVENTORY - size.y;
      /* We need to check all boxes that will be occupied by the item */
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  {
	    if (inventory[row + i][column + j] == NULL)
	      found = 1;
	    else if (inventory[row + i][column + j] != item)
	      {
		if (warn)
		  {
		    print_message ("%s already has a %s in that spot\n", name,
				   inventory[row + i][column + j]->Name());
		    error_str = "That location is already occupied";
		  }
		return -1;
	      }
	  }
      break;

    case ITEM_AREA_STASH:
      if (((unsigned) column >= HSIZE_STASH)
	  || ((unsigned) row >= VSIZE_STASH))
	goto error_bad_argument;
      if ((row >= VSIZE_STASH / 2) && ! is_expansion())
	{
	  if (warn)
	    {
	      print_message ("The stash in a standard game is only"
			     " %d rows high\n", VSIZE_STASH / 2);
	      error_str = "Stash is too small";
	    }
	  return -1;
	}
      /* Clip the item's position according to its size */
      if (column > HSIZE_STASH - size.x)
	*pcolumn = column = HSIZE_STASH - size.x;
      if (row > (is_expansion() ? VSIZE_STASH : (VSIZE_STASH / 2)) - size.y)
	*prow = row = ((is_expansion() ? VSIZE_STASH : (VSIZE_STASH / 2))
		       - size.y);
      /* We need to check all boxes that will be occupied by the item */
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  {
	    if (stash[row + i][column + j] == NULL)
	      found = 1;
	    else if (stash[row + i][column + j] != item)
	      {
		if (warn)
		  {
		    print_message ("%s already has a %s in that spot\n",
				   name, stash[row + i][column + j]->Name());
		    error_str = "That location is already occupied";
		  }
		return -1;
	      }
	  }
      break;

    case ITEM_AREA_CUBE:
      if (((unsigned) column >= HSIZE_CUBE)
	  || ((unsigned) row >= VSIZE_CUBE))
	goto error_bad_argument;
      if ((has_cube == NULL) && !options.character.link.freeform)
	{
	  if (warn)
	    {
	      print_message ("%s does not have a Horadric Cube\n", name);
	      error_str = "You do not have a Horadric Cube";
	    }
	  return -1;
	}
      /* Clip the item's position according to its size */
      if (column > HSIZE_CUBE - size.x)
	*pcolumn = column = HSIZE_CUBE - size.x;
      if (row > VSIZE_CUBE - size.y)
	*prow = row = VSIZE_CUBE - size.y;
      /* We need to check all boxes that will be occupied by the item */
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  {
	    if (cube[row + i][column + j] == NULL)
	      found = 1;
	    else if (cube[row + i][column + j] != item)
	      {
		if (warn)
		  {
		    print_message ("%s already has a %s in that spot\n",
				   name, cube[row + i][column + j]->Name());
		    error_str = "That location is already occupied";
		  }
		return -1;
	      }
	  }
      break;

    case ITEM_AREA_CORPSE:
      if ((column < (int) EQUIPPED_ON_HEAD)
	  || (column > (int) EQUIPPED_ON_ALT_LEFT_HAND) || row)
	goto error_bad_argument;
      if ( ! has_corpse())
	{
	  if (warn)
	    {
	      if ( ! has_died())
		print_message ("%s has not died\n", name);
	      else
		print_message ("%s has no corpse\n", name);
	      error_str = "You have no corpse";
	    }
	  return -1;
	}
      found = check_equipment_slot_available (area, item, column, True);
      if (options.character.link.equipment_level
	  && (check_requirements (item, True) < 0))
	return -1;
      break;

    case ITEM_AREA_HIRELING:
      if ((column != (int) EQUIPPED_ON_HEAD)
	  && (column != (int) EQUIPPED_ON_TORSO)
	  && (column != (int) EQUIPPED_ON_RIGHT_HAND)
	  && (column != (int) EQUIPPED_ON_LEFT_HAND))
	goto error_bad_argument;
      if ( ! is_expansion())
	{
	  if (warn)
	    {
	      error_str = "You cannot equip a mercenary in a standard game";
	      print_message (error_str);
	    }
	  return -1;
	}
      if ( ! has_hireling())
	{
	  if (warn)
	    {
	      error_str = "You have not hired a mercenary";
	      print_message (error_str);
	    }
	  return -1;
	}
      if (hireling_is_dead() && !options.character.link.freeform)
	{
	  if (warn)
	    {
	      error_str = "Your mercenary is dead";
	      print_message (error_str);
	    }
	  return -1;
	}
      found = check_equipment_slot_available (area, item, column, True);
      /* In addition to the usual tests, we also need to find out
	 whether the hireling can handle the item type. */
      if ((column == EQUIPPED_ON_RIGHT_HAND)
	  || (column == EQUIPPED_ON_LEFT_HAND))
	{
	  const char *allowed_1, *allowed_2;
	  allowed_1 = GetEntryStringField (hireling_entry, "WType1");
	  allowed_2 = GetEntryStringField (hireling_entry, "WType2");
	  if ( ! item->is_of_type (allowed_1)
	       && ((allowed_2[0] == 0) || ! item->is_of_type (allowed_2))) {
	    if (warn) {
	      print_message ("A %s cannot use a %s; try a %s%s%s instead\n",
			     GetEntryStringField (hireling_entry, "Hireling"),
			     item->Name(), GetEntryStringField
			     (LookupTableEntry ("itemtypes", "Code",
						allowed_1), "ItemType"),
			     allowed_2[0] ? " or " : "",
			     allowed_2[0] ? GetEntryStringField
			     (LookupTableEntry ("itemtypes", "Code",
						allowed_2), "ItemType") : "");
	      error_str = "Your mercenary cannot use that type of item";
	    }
	    return -1;
	  }
	}
      if (options.character.link.equipment_level
	  && (check_requirements_for_hireling (item, warn) < 0))
	return -1;
      break;

    case ITEM_AREA_PICKED:
      /* We don't care about the other arguments */
      if (picked_item == NULL)
	found = 1;
      else if (picked_item != item)
	{
	  if (warn)
	    {
	      print_message ("%s had already picked up a %s\n",
			     name, picked_item->Name());
	      error_str = "That location is already occupied";
	    }
	  return -1;
	}
      break;

    case ITEM_AREA_SOCKETED:
      /* You cannot 'move' an item into a socket.
	 It must be removed from the character, then
	 attached to the socketed item in a separate call. */
      goto error_bad_argument;
    }
  return found;
}

/* Check whether a character meets the requirements to equip an item. */
int
d2sData::check_requirements (const d2sItem *item, int warn)
{
  d2sDurableItem *ditem;

  if (stats.level < (uint32_t) item->RequiredLevel())
    {
      if (warn)
	{
	  print_message ("You must reach level %d to use this %s\n",
			 item->RequiredLevel(), item->Name());
	  error_str = "Level requirement not met";
	}
      return -1;
    }
  if ((item->Type() == ARMOR_ITEM)
      || (item->Type() == WEAPON_ITEM)
      || (item->Type() == STACKED_WEAPON_ITEM))
    {
      ditem = (d2sDurableItem *) *item;
      if (stats.dexterity < (uint32_t) ditem->RequiredDexterity())
	{
	  if (warn)
	    {
	      print_message ("You must have %d dexterity to use this %s\n",
			     ditem->RequiredDexterity(), item->Name());
	      error_str = "Dexterity requirement not met";
	    }
	  return -1;
	}
      if (stats.strength < (uint32_t) ditem->RequiredStrength())
	{
	  if (warn)
	    {
	      print_message ("You must have %d strength to use this %s\n",
			     ditem->RequiredStrength(), item->Name());
	      error_str = "Strength requirement not met";
	    }
	  return -1;
	}
    }
  return 0;
}

int
d2sData::check_requirements_for_hireling (const d2sItem *item, int warn)
{
  d2sDurableItem *ditem;

  if (hireling_level < item->RequiredLevel())
    {
      if (warn)
	{
	  print_message ("Your mercenary must reach level %d"
			 " to use this %s\n");
	  error_str = "Level requirement not met";
	}
      return -1;
    }
  if ((item->Type() == ARMOR_ITEM)
      || (item->Type() == WEAPON_ITEM)
      || (item->Type() == STACKED_WEAPON_ITEM))
    {
      ditem = (d2sDurableItem *) *item;
      if (GetHirelingDexterity() < (unsigned long) ditem->RequiredDexterity())
	{
	  if (warn)
	    {
	      print_message ("Your mercenary must have %d dexterity"
			     " to use this %s\n",
			     ditem->RequiredDexterity(), item->Name());
	      error_str = "Dexterity requirement not met";
	    }
	  return -1;
	}
      if (GetHirelingStrength() < (unsigned long) ditem->RequiredStrength())
	{
	  if (warn)
	    {
	      print_message ("Your mercenary must have %d strength"
			     " to use this %s\n",
			     ditem->RequiredStrength(), item->Name());
	      error_str = "Strength requirement not met";
	    }
	  return -1;
	}
    }
  return 0;
}

/* Move an item from one location to another on the same character.
   If the item cannot be moved to the desired location, no change
   will be made to the item. */
int
d2sData::MoveItemTo (d2sItem *item, int new_area, int new_col, int new_row)
{
  int found, old_area;
  coordinate_t position;
  d2sDurableItem *socketed_in;

  /* Check the argument */
  if (item == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: NULL argument to"
		 " d2sData::MoveItemTo\n", progname);
      error_str = "Invalid argument";
      return -1;
    }
  if (item->Owner() != this)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: attempt to move"
		 " %s (%p)%s %s to %s (%p)\n", progname,
		 (item->Owner() == NULL) ? "an unclaimed"
		 : item->Owner()->GetCharacterName(), item->Owner(),
		 (item->Owner() == NULL) ? "" : "'s",
		 item->Name(), name, this);
      error_str = "Character does not possess this item";
      return -1;
    }

  /* Is moving items allowed? */
  if (read_only || !options.character.edit.item_location)
    {
      error_str = "You may not move items";
      print_message (error_str);
      return -1;
    }
  old_area = item->Location();
  if (!options.character.edit.corpse_inventory
      && ((old_area == ITEM_AREA_CORPSE)
	  || (new_area == ITEM_AREA_CORPSE)))
    {
      error_str = "You may not move items equipped on your corpse";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.hireling_inventory
      && ((old_area == ITEM_AREA_HIRELING)
	  || (new_area == ITEM_AREA_HIRELING)))
    {
      error_str = "You may not move items equipped on your mercenary";
      print_message (error_str);
      return -1;
    }

  /* Is the destination location available? */
  found = check_location_available (item, new_area, &new_col, &new_row, True);
  if (found < 0)
    return -1;

  /* The destination is allowed.  If 'found' is false, that means
     the slot or boxes occupied by the item already contain that item. */
  if (!found)
    {
      position = item->Position();
      if ((old_area != new_area)
	  || (new_col != position.x) || (new_row != position.y))
	{
	  /* This should only happen when a two-handed weapon
	     switches hands.  Set the item to the other hand. */
	  item->SetLocation (new_area, new_col, new_row);
	}
      /* Return success status without doing anything else. */
      return 0;
    }

  /* Now that we know the destination is free,
     we must remove the item from its current location. */
  if (old_area == ITEM_AREA_SOCKETED)
    socketed_in = ((d2sAttachItem *) *item)->AttachedTo();
  else
    socketed_in = NULL;
  if (remove_item (item) < 0)
    return -1;

  /* Change the item's location */
  if (item->SetLocation (new_area, new_col, new_row) < 0)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: d2sData::MoveItemTo()"
		 " allowed an item to be moved,\n"
		 " but the item would not accept the new location.\n",
		 progname);
      /* Try to replace the item */
      if (socketed_in == NULL)
	PlaceItem (item);
      else
	socketed_in->AddGem ((d2sAttachItem *) *item);
      return -1;
    }

  /* If moving the item to/from the corpse or hireling,
     we must remember to move the item from its current
     linked list to another. */
  if (old_area != new_area)
    {
      switch (old_area)
	{
	default:
	  if ((new_area == ITEM_AREA_CORPSE)
	      || (new_area == ITEM_AREA_HIRELING)
	      || (new_area == ITEM_AREA_SOCKETED))
	    remove_from_item_list (&item_list, item);
	  break;
	case ITEM_AREA_SOCKETED:
	  /* Do nothing; the item was not in either list */
	  break;
	case ITEM_AREA_CORPSE:
	  remove_from_item_list (&corpse_item_list, item);
	  break;
	case ITEM_AREA_HIRELING:
	  remove_from_item_list (&hireling_item_list, item);
	  break;
	}
    }

  /* Place the item in the new location */
  PlaceItem (item);

  if (old_area != new_area)
    {
      switch (new_area)
	{
	default:
	  if ((old_area == ITEM_AREA_CORPSE)
	      || (old_area == ITEM_AREA_HIRELING)
	      || (old_area == ITEM_AREA_SOCKETED))
	    append_to_item_list (&item_list, item);
	  break;
	case ITEM_AREA_SOCKETED:
	  /* Do nothing; the item doesn't go in either list */
	  break;
	case ITEM_AREA_CORPSE:
	  append_to_item_list (&corpse_item_list, item);
	  break;
	case ITEM_AREA_HIRELING:
	  append_to_item_list (&hireling_item_list, item);
	  break;
	}
    }

  /* All done! */
  MarkDirty ();
  return 0;
}

/* Give an item to a character.  The item must not belong to anyone.
   The item's desired location is taken from the item object itself.
   If the item cannot be placed in the desired location, no change
   will be made to the item. */
int
d2sData::AddItem (d2sItem *item)
{
  coordinate_t position;

  /* Check the argument */
  if (item == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: NULL argument to"
		 " d2sData::MoveItemTo\n", progname);
      error_str = "Invalid argument";
      return -1;
    }
  if (item->Owner() != NULL)
    {
      if (item->Owner() == this)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: attempt to add %s's %s to"
		     " %s again\n", progname, name, item->Name(), name);
	  error_str = "Character already possesses this item";
	}
      else
	{
	  print_message ("%s cannot take %s's %s; you must remove it"
			 " from %s first.\n",
			 name, item->Owner()->GetCharacterName(),
			 item->Name(), item->Owner()->GetCharacterName());
	  error_str = "Another character already owns this item";
	}
      return -1;
    }

  /* Is adding items allowed? */
  if (read_only || !options.character.edit.inventory)
    {
      error_str = "You may not add items";
      print_message (error_str);
      return -1;
    }

  /* Is this an expansion item? */
  if (item->is_expansion_item() && !this->is_expansion()
      && !options.character.link.freeform
      && (!options.item.link.item_expansion
	  || item->d2sItem::is_expansion_item()))
    {
      print_message ("That %s is only available in the Expansion Set.\n",
		     item->Name());
      error_str = "Expansion Set required";
      return -1;
    }

  /* If this is a quest item, we have a *lot* of extra work to do. */
  if (item->is_quest_item())
    {
      if (!options.character.link.freeform)
	{
	  /* Make sure the character doesn't already
	     have a copy of this item */
	  if (this->is_carrying_a (item->Code()))
	    {
	      print_message ("%s already has a %s.\n", name, item->Name());
	      error_str = "You already have this quest item";
	      return -1;
	    }
	}

      if (options.character.link.quest_inventory)
	{
#if 0
	  /* TO-DO */
	  int act, quest, num_quests, state, num_states;
	  char quest_code[8] = "a1q1";
	  char state_key[8] = "state0";
	  const char *state_code;
	  table_entry_t qent, sent;

	  /* Tricky part: make sure the character doesn't have another
	     quest item which is mutually exclusive with the new one. */
	  for (act = 0; act < NumberOfActs(); act++) {
	    quest_code[1] = (char) ('1' + act);
	    num_quests = GetNumberOfQuestsInAct (act);
	    for (quest = 0; quest < num_quests; quest++) {
	      quest_code[3] = (char) ('1' + quest);
	      qent = LookupTableEntry ("quests", "code", quest_code);
	      num_states = GetEntryIntegerField (qent, "numStates");
	      for (state = 0; state < num_states; state++) {
		state_key[5] = (char) ('0' + state);
		state_code = GetEntryStringField (qent, state_key);
		sent = LookupTableEntry ("queststates", "code", state_code);
		/* TO-DO */
	      }
	    }
	  }
#endif
	}
    }

  /* Is the target location available? */
  position = item->Position();
  if (check_location_available (item, item->Location(),
				&position.x, &position.y, True) < 0)
    return -1;

  /* Everything looks good; add the item */
  /* In case the item's position was clipped, reset its location */
  item->SetLocation (item->Location(), position.x, position.y);
  switch (item->Location ())
    {
    default:
      item->AssignTo (this);
      append_to_item_list (&item_list, item);
      break;
    case ITEM_AREA_CORPSE:
      item->AssignTo (this, ITEM_AREA_CORPSE);
      append_to_item_list (&corpse_item_list, item);
      break;
    case ITEM_AREA_HIRELING:
      item->AssignTo (this, ITEM_AREA_HIRELING);
      append_to_item_list (&hireling_item_list, item);
      break;
    }
  PlaceItem (item);
  MarkDirty ();
  return 0;
}

/* Test whether an item can be added to a given location
   without actually adding the item.  Used to determine
   whether to look for another place to add an item. */
int
d2sData::CheckLocationAvailable (d2sItem *item, int pref_area,
				 int pref_col, int pref_row)
{
  int		i, j;
  coordinate_t	size;
  const char	*part1, *part2;
  d2sItem	**equip;

  if (item == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to\n"
		 " d2sData::CheckLocationAvailable(%p,%d,%d,%d)\n",
		 progname, item, pref_area, pref_col, pref_row);
      return -1;
    }

  size = item->Size();
  switch (pref_area)
    {
    default:
    bad_argument:
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to\n"
		 " d2sData::CheckLocationAvailable(%s,%d,%d,%d)\n",
		 progname, item->Name(), pref_area, pref_col, pref_row);
      return -1;

    case ITEM_AREA_EQUIPPED:
      equip = &equipment[0];
    equipment_common:
      if ((pref_col < EQUIPPED_ON_HEAD)
	  || (pref_col > EQUIPPED_ON_ALT_LEFT_HAND))
	goto bad_argument;
      /* Does the character meet the level requirement for this item? */
      if (options.character.link.equipment_level
	  && check_requirements (item, False) < 0)
	return -1;

      /* Can the item go in the preferred slot? */
      return (check_equipment_slot_available
	      (pref_area, item, pref_col, False));

    case ITEM_AREA_BELT:
      if ((unsigned) pref_col >= MSIZE_BELT)
	goto bad_argument;
      if ( ! GetEntryIntegerField (item->TypeTableEntry(), "Beltable"))
	/* Can't be tucked in the belt */
	return -1;
      return ((belt[pref_col] == NULL) ? 0 : -1);

    case ITEM_AREA_INVENTORY:
      if (((unsigned) pref_col >= HSIZE_INVENTORY)
	  || ((unsigned) pref_row >= VSIZE_INVENTORY))
	goto bad_argument;
      if ((pref_col + size.x > HSIZE_INVENTORY)
	  || (pref_row + size.y > VSIZE_INVENTORY))
	/* Partially out of bounds */
	return -1;
      for (j = 0; j < size.y; j++) {
	for (i = 0; i < size.x; i++) {
	  if (inventory[pref_row + j][pref_col + i] != NULL)
	    /* Occupied */
	    return -1;
	}
      }
      return 0;

    case ITEM_AREA_STASH:
      if (((unsigned) pref_col >= HSIZE_STASH)
	  || ((unsigned) pref_row >= VSIZE_STASH))
	goto bad_argument;
      if ((pref_col + size.x > HSIZE_STASH)
	  || (pref_row + size.y > (is_expansion() ? VSIZE_STASH
				   : (VSIZE_STASH / 2))))
	/* Out of bounds */
	return -1;
      for (j = 0; j < size.y; j++) {
	for (i = 0; i < size.x; i++) {
	  if (stash[pref_row + j][pref_col + i] != NULL)
	    /* Occupied */
	    return -1;
	}
      }
      return 0;

    case ITEM_AREA_CUBE:
      if (((unsigned) pref_col >= HSIZE_CUBE)
	  || ((unsigned) pref_row >= VSIZE_CUBE))
	goto bad_argument;
      if ((pref_col + size.x > HSIZE_CUBE)
	  || (pref_row + size.y > VSIZE_CUBE))
	/* Partially out of bounds */
	return -1;
      for (j = 0; j < size.y; j++) {
	for (i = 0; i < size.x; i++) {
	  if (cube[pref_row + j][pref_col + i] != NULL)
	    /* Occupied */
	    return -1;
	}
      }
      return 0;

    case ITEM_AREA_CORPSE:
      if ( ! has_corpse())
	return -1;
      equip = &corpse_equipment[0];
      goto equipment_common;

    case ITEM_AREA_HIRELING:
      if ( ! GetEntryIntegerField (item->TypeTableEntry(), "Body"))
	/* Can't be equipped */
	return -1;

      /* Does the hireling meet the level requirement for this item? */
      if (options.character.link.equipment_level
	  && (check_requirements_for_hireling (item, False) < 0))
	return -1;

      if ((pref_col != (int) EQUIPPED_ON_HEAD)
	  && (pref_col != (int) EQUIPPED_ON_TORSO)
	  && (pref_col != (int) EQUIPPED_ON_RIGHT_HAND)
	  && (pref_col != (int) EQUIPPED_ON_LEFT_HAND))
	goto bad_argument;

      if (options.character.link.equipment_class)
	{
	  /* Can this particular hireling use the requested item? */
	  if ((pref_col == (int) EQUIPPED_ON_RIGHT_HAND)
	      || (pref_col == (int) EQUIPPED_ON_LEFT_HAND))
	    {
	      part1 = GetEntryStringField (hireling_entry, "WType1");
	      part2 = GetEntryStringField (hireling_entry, "WType2");
	      if ( ! item->is_of_type (part1)
		   && ((part2[0] == 0) || ! item->is_of_type (part2)))
		return -1;
	    }
	}

      /* Is the slot open? */
      return (check_equipment_slot_available
	      (pref_area, item, pref_col, False));

    case ITEM_AREA_PICKED:
      return ((picked_item == NULL) ? 0 : -1);
    }
  /* NOTREACHED */
  return -1;
}

/* Find an empty spot where an item may be placed.  In the first
   version, the preferred destination area for the item is given.  If
   an item cannot be placed anywhere in that area, -1 is returned. */
int
d2sData::FindEmptySpotForItem (d2sItem *item, int preferred_area,
			       int *ret_col, int *ret_row)
{
  int x, y, i, j;
  int found, stash_vsize;
  coordinate_t size;
  const char *part1, *part2;
  d2sItem **equip;

  if ((item == NULL) || (ret_col == NULL) || (ret_row == NULL))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to\n"
		 " d2sData::FindEmptySpotForItem(%p,%d,%p,%p)\n",
		 progname, item, preferred_area, ret_col, ret_row);
      return -1;
    }

  size = item->Size();
  switch (preferred_area)
    {
    default:
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to\n"
		 " d2sData::FindEmptySpotForItem(%s,%d,&col,&row)\n",
		 progname, item->Name(), preferred_area);
      return -1;

    case ITEM_AREA_EQUIPPED:
      equip = &equipment[0];
    equipment_common:
      /* Does the character meet the level requirement for this item? */
      if (options.character.link.equipment_level
	  && check_requirements (item, False) < 0)
	return -1;

      /* What body part(s) can this item go on? */
      part1 = GetEntryStringField (item->TypeTableEntry(), "BodyLoc1");
      part2 = GetEntryStringField (item->TypeTableEntry(), "BodyLoc2");
      x = GetEntryIntegerField (LookupTableEntry ("bodylocs", "Code", part1),
				NULL);
      y = GetEntryIntegerField (LookupTableEntry ("bodylocs", "Code", part2),
				NULL);

      /* Is either slot open? */
      if (check_equipment_slot_available
	  (preferred_area, item, x, False) >= 0)
	{
	  *ret_col = x;
	  *ret_row = 0;
	  return 0;
	}
      if ((y != x)
	  && (check_equipment_slot_available
	      (preferred_area, item, y, False) >= 0))
	{
	  *ret_col = y;
	  *ret_row = 0;
	  return 0;
	}
      /* If this is an expansion character and we are
	 equipping something in a hand, try the alt. hands */
      if ((x != y) && (is_expansion()))
	{
	  if (x == EQUIPPED_ON_RIGHT_HAND)
	    {
	      x = EQUIPPED_ON_ALT_RIGHT_HAND;
	      if (check_equipment_slot_available
		  (preferred_area, item, x, False) >= 0)
		{
		  *ret_col = x;
		  *ret_row = 0;
		  return 0;
		}
	    }
	  if (y == EQUIPPED_ON_LEFT_HAND)
	    {
	      y = EQUIPPED_ON_ALT_LEFT_HAND;
	      if (check_equipment_slot_available
		  (preferred_area, item, y, False) >= 0)
		{
		  *ret_col = y;
		  *ret_row = 0;
		  return 0;
		}
	    }
	  /* I don't think there are any in this order, but... */
	  if (x == EQUIPPED_ON_LEFT_HAND)
	    {
	      x = EQUIPPED_ON_ALT_LEFT_HAND;
	      if (check_equipment_slot_available
		  (preferred_area, item, x, False) >= 0)
		{
		  *ret_col = x;
		  *ret_row = 0;
		  return 0;
		}
	    }
	  if (y == EQUIPPED_ON_RIGHT_HAND)
	    {
	      y = EQUIPPED_ON_ALT_RIGHT_HAND;
	      if (check_equipment_slot_available
		  (preferred_area, item, y, False) >= 0)
		{
		  *ret_col = y;
		  *ret_row = 0;
		  return 0;
		}
	    }
	}
      return -1;

    case ITEM_AREA_BELT:
      if ( ! GetEntryIntegerField (item->TypeTableEntry(), "Beltable"))
	/* Can't be tucked in the belt */
	return -1;
      for (x = 0; x < belt_size; x++)
	{
	  if (belt[x] == NULL)
	    {
	      *ret_col = x;
	      *ret_row = 0;
	      return 0;
	    }
	}
      return -1;

    case ITEM_AREA_INVENTORY:
      /* For storage, search in column-major order. */
      for (x = 0; x <= HSIZE_INVENTORY - size.x; x++)
	for (y = 0; y <= VSIZE_INVENTORY - size.y; y++)
	  {
	    found = 1;
	    for (j = 0; j < size.y; j++) {
	      for (i = 0; i < size.x; i++)
		{
		  if (inventory[y + j][x + i] != NULL)
		    {
		      found = 0;
		      break;
		    }
		}
	      if (!found)
		break;
	    }
	    if (found)
	      {
		*ret_col = x;
		*ret_row = y;
		return 0;
	      }
	  }
      return -1;

    case ITEM_AREA_STASH:
      stash_vsize = is_expansion() ? VSIZE_STASH : (VSIZE_STASH / 2);
      /* For storage, search in column-major order. */
      for (x = 0; x <= HSIZE_STASH - size.x; x++)
	for (y = 0; y <= stash_vsize - size.y; y++)
	  {
	    found = 1;
	    for (j = 0; j < size.y; j++) {
	      for (i = 0; i < size.x; i++)
		{
		  if (stash[y + j][x + i] != NULL)
		    {
		      found = 0;
		      break;
		    }
		}
	      if (!found)
		break;
	    }
	    if (found)
	      {
		*ret_col = x;
		*ret_row = y;
		return 0;
	      }
	  }
      return -1;

    case ITEM_AREA_CUBE:
      /* For storage, search in column-major order. */
      for (x = 0; x <= HSIZE_CUBE - size.x; x++)
	for (y = 0; y <= VSIZE_CUBE - size.y; y++)
	  {
	    found = 1;
	    for (j = 0; j < size.y; j++) {
	      for (i = 0; i < size.x; i++)
		{
		  if (cube[y + j][x + i] != NULL)
		    {
		      found = 0;
		      break;
		    }
		}
	      if (!found)
		break;
	    }
	    if (found)
	      {
		*ret_col = x;
		*ret_row = y;
		return 0;
	      }
	  }
      return -1;

    case ITEM_AREA_CORPSE:
      if ( ! has_corpse())
	return -1;
      equip = &corpse_equipment[0];
      goto equipment_common;

    case ITEM_AREA_HIRELING:
      if ( ! GetEntryIntegerField (item->TypeTableEntry(), "Body"))
	/* Can't be equipped */
	return -1;

      /* Does the hireling meet the level requirement for this item? */
      if (options.character.link.equipment_level
	  && (check_requirements_for_hireling (item, False) < 0))
	return -1;

      /* What body part(s) can this item go on? */
      part1 = GetEntryStringField (item->TypeTableEntry(), "BodyLoc1");
      part2 = GetEntryStringField (item->TypeTableEntry(), "BodyLoc2");
      x = GetEntryIntegerField (LookupTableEntry ("bodylocs", "Code", part1),
				NULL);
      y = GetEntryIntegerField (LookupTableEntry ("bodylocs", "Code", part2),
				NULL);
      if ((x != (int) EQUIPPED_ON_HEAD) && (x != (int) EQUIPPED_ON_TORSO)
	  && (x != (int) EQUIPPED_ON_RIGHT_HAND)
	  && (x != (int) EQUIPPED_ON_LEFT_HAND))
	return -1;

      if (options.character.link.equipment_class)
	{
	  /* Can this particular hireling use the requested item? */
	  if ((x == (int) EQUIPPED_ON_RIGHT_HAND)
	      || (x == (int) EQUIPPED_ON_LEFT_HAND))
	    {
	      part1 = GetEntryStringField (hireling_entry, "WType1");
	      part2 = GetEntryStringField (hireling_entry, "WType2");
	      if ( ! item->is_of_type (part1)
		   && ((part2[0] == 0) || ! item->is_of_type (part2)))
		return -1;
	    }
	}

      /* Is either slot open? */
      if (check_equipment_slot_available
	  (preferred_area, item, x, False) >= 0)
	{
	  *ret_col = x;
	  *ret_row = 0;
	  return 0;
	}
      if ((y != x)
	  && (check_equipment_slot_available
	      (preferred_area, item, y, False) >= 0))
	{
	  *ret_col = y;
	  *ret_row = 0;
	  return 0;
	}
      return -1;

    case ITEM_AREA_PICKED:
      return ((picked_item == NULL) ? 0 : -1);
    }
  /* NOTREACHED */
  return -1;
}

/* In the second version, any area is acceptable (except for the
   corpse and hireling).  The spot returned is the first one found in
   the same order as the ITEM_AREA_xxx macros (i.e., the function
   tries to equip the item first; if all others fail, try giving it to
   the mouse.) */
int
d2sData::FindEmptySpotForItem (d2sItem *item, int *ret_area,
			       int *ret_col, int *ret_row)
{
  if (FindEmptySpotForItem (item, ITEM_AREA_EQUIPPED, ret_col, ret_row) >= 0)
    {
      *ret_area = ITEM_AREA_EQUIPPED;
      return 0;
    }
  if (FindEmptySpotForItem (item, ITEM_AREA_BELT, ret_col, ret_row) >= 0)
    {
      *ret_area = ITEM_AREA_BELT;
      return 0;
    }
  if (FindEmptySpotForItem (item, ITEM_AREA_INVENTORY, ret_col, ret_row) >= 0)
    {
      *ret_area = ITEM_AREA_INVENTORY;
      return 0;
    }
  if (FindEmptySpotForItem (item, ITEM_AREA_STASH, ret_col, ret_row) >= 0)
    {
      *ret_area = ITEM_AREA_STASH;
      return 0;
    }
  if (FindEmptySpotForItem (item, ITEM_AREA_CUBE, ret_col, ret_row) >= 0)
    {
      *ret_area = ITEM_AREA_CUBE;
      return 0;
    }
  if (FindEmptySpotForItem (item, ITEM_AREA_PICKED, ret_col, ret_row) >= 0)
    {
      *ret_area = ITEM_AREA_PICKED;
      return 0;
    }
  /* Can't place the item anywhere! */
  return -1;
}

/* Place an item that has been read from a character file
   (or passed validation elsewhere). */
void
d2sData::PlaceItem (d2sItem *new_item)
{
  coordinate_t cord = new_item->Position();
  coordinate_t size = new_item->Size ();
  int i, j;

  /* Check for the cube */
  if (*new_item == "box")
    has_cube = new_item;

  switch (new_item->Location())
    {
    case ITEM_AREA_EQUIPPED:
      equipment[cord.x] = new_item;
      if (cord.x == (int) EQUIPPED_ON_WAIST)
	{
	  /* Update the belt size */
	  if (new_item->Type() == ARMOR_ITEM)
	    belt_size
	      = (((d2sArmorItem *)
		  (d2sDurableItem *) *new_item)->NumberOfBoxesInBelt());
	  else
	    /* Don't know what type of belt it is; start with 2 rows */
	    belt_size = 8;
	}
      if ((cord.x == (int) EQUIPPED_ON_RIGHT_HAND)
	  || (cord.x == (int) EQUIPPED_ON_ALT_RIGHT_HAND))
	{
	  /* If this is a two-handed-only weapon,
	     place in it the other hand too. */
	  if ((new_item->Type() == WEAPON_ITEM)
	      && !((d2sWeaponItem *) ((d2sDurableItem *)
				      *new_item))->is_one_handed())
	    equipment[cord.x + 1] = new_item;
	}
      return;
    case ITEM_AREA_BELT:
      belt[cord.x] = new_item;
      return;
    case ITEM_AREA_INVENTORY:
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  inventory[cord.y + i][cord.x + j] = new_item;
      return;
    case ITEM_AREA_STASH:
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  stash[cord.y + i][cord.x + j] = new_item;
      return;
    case ITEM_AREA_CUBE:
      for (i = 0; i < size.y; i++)
	for (j = 0; j < size.x; j++)
	  cube[cord.y + i][cord.x + j] = new_item;
      return;
    case ITEM_AREA_CORPSE:
      corpse_equipment[cord.x] = new_item;
      return;
    case ITEM_AREA_HIRELING:
      hireling_equipment[cord.x] = new_item;
      return;
    case ITEM_AREA_PICKED:
      picked_item = new_item;
      return;
    default:
      if (debug)
	fprintf (stderr, "%s: Internal error: d2sData::PlaceItem"
		 "(item at area %d)\n", progname, new_item->Location());
      return;
    }
}
