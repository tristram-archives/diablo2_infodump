/* Definition of C++ classes that hold an internal representation
 * of magical properties in Diablo II v1.09 items.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef D2SMAGIC_H
#define D2SMAGIC_H

#ifndef __cplusplus
#error "You need a C++ compiler to use this module"
#endif

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "d2sItem.h"
#include "functions.h"
#include "internal.h"
#include "tables.h"

#define MAX_FIELDS_IN_MAGIC_PROPERTY 4
#define MAX_PROPERTIES_IN_GROUP 4
#define END_OF_LIST_MARKER	0x1ff

/* Forward references: */
class d2sMagicProperty;
class d2sMagic;
class d2sItem;

/****************************************************************/

/* The first class defines a single magical property */
class d2sMagicProperty {
 public:
  d2sMagicProperty (void);
  /* Create a new magic property using the given ID */
  d2sMagicProperty (int id);
  /* Create a new magic property using the given code and parameters */
  d2sMagicProperty (const char *, int param = 0, int pmin = 0, int pmax = 0);
  /* Copy an existing property */
  d2sMagicProperty (const d2sMagicProperty&);
  d2sMagicProperty& operator= (const d2sMagicProperty&);

  /* Return a string describing the latest error condition */
  const char *GetErrorMessage (void) const { return error_str; }

  /* Assign a property to a list */
  int	AssignTo (d2sMagic *);

  /* Return the list a property belongs to */
  d2sMagic *ParentList (void) const { return my_list; }

  /* Read a magic property's values from a file */
  int	Read (struct bit_stream *);

  /* Write a magic property's values out to a file */
  int	Write (struct bit_stream *);

  /* Return the nmemonic for this property */
  const char *Code (void) const
    /* This is looked up from the properties table */
    { return GetEntryStringField (property_entry, "Code"); }

  /* Return the numeric ID of this property */
  int	ID (void) const { return property_id; }

  /* Return the property's entry in the properties table */
  table_entry_t TableEntry (void) const { return property_entry; }

  /* Return the description of this property */
  const char *Description (void) const
    /* This is looked up from the properties table */
    { return GetEntryStringField (property_entry, "Description"); }

  /* Return a string describing the property's full set
     of values, as displayed in the game.  String is
     allocated on demand; must be freed. */
  char *Display (void) const;

  /* Return the number of data fields this property has */
  int NumberOfFields (void) const { return field_count; }

  /* Return the description of a particular field */
  const char *FieldDescription (int n) const;

  /* Return the units of a particular field, if any (empty string if not) */
  const char *FieldUnits (int n) const;

  /* Return a code indicating the data type of a field.
     The codes are: 'b'=boolean (no display), 'i'=int,
     'd'=double, 's'=string (const char *).  Use the result
     to choose which function to use to read a field. */
  char	FieldType (int) const;

  /* Return the bias of the property. */
  int	Bias (void) const { return bias; }

  /* Return a list of strings that are valid for a string field. */
  StringList FieldStringList (int) const;

  /* Return the value of the Nth data field,
     represented as a raw (biased) integer */
  int	FieldData (int) const;

  /* Return a dynamically allocated string representing the
     (unbiased, converted) value of the Nth data field. */
  char *FieldValue (int) const;

  /* Return the width of a field in bits.  Can be used
     (with the Bias) in determining the field's maximum value. */
  int	FieldBits (int field) const { return field_width[field]; }

  /* Return whether the owner of a property is read-only. */
  int	read_only (void) const;

  /* Return whether a magic property is specific to the expansion set */
  int	is_expansion (void) const { return expansion_property; }

  /* Mark a property as having been changed.
     (We don't track dirt ourselves; just pass it on the the parent.) */
  void	MarkDirty (void);

  /* Change the value of a field */
  int	SetFieldData (int field, int data);

  /* Change the value of a field based on a converted string.
     Use this to set fields from the user interface (i.e.,
     unbiased and converted double values). */
  int	SetFieldValue (int field, const char *valuestr);

  /* Change the values of all fields to equal another magic property.
     Used in setting groups. */
  int	SetFieldsEqualTo (const d2sMagicProperty&);

  /* Add one property to another.  Both must be the same type. */
  d2sMagicProperty& operator+= (const d2sMagicProperty&);

  /* Return whether a property matches the given ID or code. */
  int	operator== (int id) const { return (property_id == id); }
  int	operator!= (int id) const { return (property_id != id); }
  int	operator== (const char *code) const
    { return (strcmp (Code(), code) == 0); }
  int	operator!= (const char *code) const
    { return (strcmp (Code(), code) != 0); }

  /* Return true if a property is a partial member of a given property.
     (e.g., "fire-min" is part of the group "dmg-fire".) */
  int	operator< (const char *code) const;
  /* Return true if a property is a group container for a given property.
     (e.g., "dmg-min" is a container for properties 21, 23, and 159.) */
  int	operator>= (const d2sMagicProperty&) const;

  /* Return whether two magic properties have the same value.
     The ID's need not be identical, so long as the field types are.
     Used to see whether resistances can be combined into a group. */
  int	matches_value_of (const d2sMagicProperty *) const;

  /* Return whether a property represents a range.
     This would be true if the property was assigned parametric values
     min and max, but it has only one field. */
  int	is_ranged (void) const
    { return (((field_count == 1) && (field_value[1] > field_value[0]))
	      /* HACK */ || (property_id == 17)); }

  /* If a property is ranged, choose a random
     (raw) data value within the range. */
  int	RangedValue (void) const;

  /* If a property is ranged, test whether a given
     (raw) data value lies within the prescribed range. */
  int	RangeTest (int data) const
    { return (((uint16_t) data >= field_value[0])
	      && ((uint16_t) data <= field_value[1])); }

  /* These are used by d2sMagic for stacked properties.
     Change the property ID to another ID within the same stack. */
  void	StackedReset (void);
  int	StackedBump (void);

 protected:
  /* Used by the constructors: */
  void Init (void);
  void UpdatedPropertyID (void);

  d2sMagic *	my_list;	// Property list which this one belongs to
  const char *	error_str;
  int		property_id;
  table_entry_t property_entry; // Entry in the property table
  /* The bias, field count, and field widths are looked up from a table,
     but stored here for faster access as they are frequently used. */
  int		expansion_property;
  int		bias;		// May optionally hold extra data
  int		field_count;
  uint8_t	field_width[MAX_FIELDS_IN_MAGIC_PROPERTY];
  uint16_t	field_value[MAX_FIELDS_IN_MAGIC_PROPERTY];
};


/****************************************************************/

/* This class combines multiple d2sMagicProperty's into a list.
   This is what gets attached to items. */
class d2sMagic {
 public:
  d2sMagic (void);
  /* Create and assign to an item in one step */
  d2sMagic (d2sItem *item);
  /* Copy an existing magic property list */
  d2sMagic (const d2sMagic&);
  ~d2sMagic (); 		// Destructor

  /* Assign a property list to an item.
     (Applies to both added and inherent property lists.) */
  int	AssignTo (d2sItem *);

  /* Return the item this list is attached to */
  d2sItem *Item (void) const { return my_item; }

  /* Return a string describing the latest error condition */
  const char *GetErrorMessage (void) const { return error_str; }

  /* Read a list of magic properties from a file */
  int	Read (struct bit_stream *);

  /* For set items, call this to append another list
     of properties to the existing list.  The current
     end-of-list marker becomes a list separator. */
  int	Append (struct bit_stream *);

  /* Write a list of magic properties to a file */
  int	Write (struct bit_stream *);

  /* Return a string describing all of the properties in this list, as
     displayed in the game.  String is allocated on demand; must be
     freed.  Each property in the string is prefixed with a newline.
     If the property list is empty, this returns NULL. */
  char *Display (void) const;

  /* Return whether the owner of a property list is read-only. */
  int		read_only (void) const
    { return ((my_item != NULL) && my_item->read_only()); }

  /* Return whether any of the magic properties in a list
     is specific to the expansion set */
  int	is_expansion (void) const;

  /* Return the number of properties in the list
     (not including the end-of-list marker) */
  int	NumberOfProperties (void) const { return (list_size - 1); }

  /* For set items, return the number of lists this class contains */
  int	NumberOfPropertyLists (void) const;

  /* For set items, return the number of properties in the Nth list */
  int	NumberOfPropertiesInList (int n = 0) const;

  /* Return the Nth magic property in the list */
  d2sMagicProperty *Property (int n) const
    { return (((unsigned) n < (unsigned) list_size - 1) ? list[n] : NULL); }

  /* Search the properties in this list for one matching the given ID */
  d2sMagicProperty *Lookup (int) const;
  d2sMagicProperty *Lookup (const char *) const;

  /* Mark a property list as having been changed
     (We don't track dirt ourselves; just pass it on the the parent.) */
  void MarkDirty (void);

  /* Copy a property list */
  d2sMagic& operator= (const d2sMagic&);

  /* Add a new property to the list.  Insert at the given location
     if the second argument is present; otherwise append. */
  int	AddProperty (d2sMagicProperty *, int n = -1);

  /* Another way of stating the above, with a difference:
     if a similar property already exists, their values are added. */
  d2sMagic& operator+= (const d2sMagicProperty&);
  /* Merge properties from another list into this one */
  d2sMagic& operator+= (const d2sMagic&);
  /* Remove a property from the list.  In most cases, the values are
     irrelevant; any existing property having the same ID is removed. */
  d2sMagic& operator-= (const d2sMagicProperty&);
  /* Remove properties in another list from this one */
  d2sMagic& operator-= (const d2sMagic&);

  /* Remove a property from the list. */
  int	RemoveProperty (d2sMagicProperty *);
  /* Same, using the property's index in the list */
  int	RemoveProperty (int);

  /* Reorder the list; move a property to the Nth position */
  int	MoveProperty (d2sMagicProperty *, int n);
  int	MoveProperty (int, int n);

  /* Take a list of properties, e.g. those found in the item tables or
     magic prefixes/suffixes, and generate a canonical property list
     based on their values or ranges.  Partial properties (e.g.,
     "fire-min" and "fire-max") are combined into a single property
     ("dmg-fire").  If a source field has a range, a random value is
     chosen from that range for the destination.  The new properties
     replace the original ones in the list.  The list is returned. */
  d2sMagic *Generate (void);

 protected:
  const char *	error_str;
  int		list_size;
  d2sMagicProperty **list;
  d2sItem *	my_item;
};


/* Non-class function: */

/* Return a dynamic list of magic properties.
   Omit properties which are already in a given list. */
StringList GetMagicPropertyNamesExcept (d2sMagic *omit, int expansion,
					const char *class_restriction);

#endif /* D2SMAGIC_H */
