/* d2sGemItem -- C++ class that holds an internal representation
 *		 of a Diablo II v1.09 gem.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

#define NUM_GEM_TYPES 7
#define NUM_GEM_GRADES 5


/***************************** DATA *****************************/

/* A list of all the gem types defined in the database
   (this list is so small, we define in statically) */
static const char * const gem_names[NUM_GEM_TYPES] = {
  "Diamond", "Ruby", "Topaz", "Emerald", "Sapphire", "Amethyst", "Skull"
};
#define GTYPE_W 0
#define GTYPE_R 1
#define GTYPE_Y 2
#define GTYPE_G 3
#define GTYPE_B 4
#define GTYPE_V 5
#define GTYPE_S 6

/* Gem grades (applies to all gem types) */
static const char * const grade_names[NUM_GEM_GRADES] = {
  "Chipped", "Flawed", "", "Flawless", "Perfect"
};
#define GGRADE_CHIPPED	0
#define GGRADE_FLAWED	1
#define GGRADE_NORMAL	2
#define GGRADE_FLAWLESS	3
#define GGRADE_PERFECT	4

/* Map gem type and grade to gem code */
static const char *code_for_type[NUM_GEM_TYPES][NUM_GEM_GRADES] = {
  { "gcw", "gfw", "gsw", "glw", "gpw" },
  { "gcr", "gfr", "gsr", "glr", "gpr" },
  { "gcy", "gfy", "gsy", "gly", "gpy" },
  { "gcg", "gfg", "gsg", "glg", "gpg" },
  { "gcb", "gfb", "gsb", "glb", "gpb" },
  { "gcv", "gfv", "gsv", "gzv", "gpv" },
  { "skc", "skf", "sku", "skl", "skz" },
};


/************************** FUNCTIONS ***************************/

/* Return the name of the Nth defined gem */
const char *
GetGemTypeName (int type)
{
  if ((unsigned) type >= NUM_GEM_TYPES)
    return NULL;
  return gem_names[type];
}

/* Return the prefix of the Nth grade of a gem */
const char *
GetGemGradePrefix (int grade)
{
  if ((unsigned) grade >= NUM_GEM_GRADES)
    return NULL;
  return grade_names[grade];
}


/**************** GEM CLASS ****************
 *
 * A simple class that can be attached to a socketed item
 * and can change form from one gem to another
 *******************************************/

/* Create a new, 'blank' gem (to be filled in later) */
d2sGemItem::d2sGemItem (void)
  /* Construct the base class part first.  Remember that since d2sInit
     is a virtual base class, it is our responsibility to initialize it. */
  : d2sItem (), d2sGemOrRuneItem ()
{
  /* Override the default item class */
  item_class = GEM_ITEM;
  nvop = this;
  major_type = GTYPE_W;		// Chipped Diamond
  grade = GGRADE_CHIPPED;
}

/* Create a new, specific gem as described by the item table entry */
d2sGemItem::d2sGemItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     is a virtual base class, it is our responsibility to initialize it. */
  : d2sItem (tent), d2sGemOrRuneItem (tent)
{
  /* Override the default item class */
  item_class = GEM_ITEM;
  nvop = this;
  /* Set the gem's major type and grade */
  LookupGem ();
}

/* Copy an existing gem */
d2sGemItem::d2sGemItem (const d2sGemItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     is a virtual base class, it is our responsibility to initialize it. */
  : d2sItem (source), d2sGemOrRuneItem (source)
{
  nvop = this;
  /* Note that d2sGemOrRuneItem::d2sGemOrRuneItem(source) will have
     already copied the gem item fields.  Our only additional fields
     are the gem type and grade. */
  this->major_type = source.major_type;
  this->grade = source.grade;
}

/* Copy a gem. */
d2sItem *
d2sGemItem::Copy (void) const
{
  d2sGemItem *new_item = new d2sGemItem (*this);
  return (d2sItem *) new_item;
}

/* Create a gem by filling in data from a file.
   (This simply calls d2sGemOrRuneItem::Read,
   then sets our own data fields) */
int
d2sGemItem::Read (struct data_stream *dstream)
{
  int status;

  /* The parent class does the actual reading */
  status = this->d2sGemOrRuneItem::Read (dstream);

  /* All we need to do is set the gem's major type and grade,
     and set the corresponding required level and magic properties. */
  LookupGem();
  return status;
}

/* If the gem type was changed, change it back. */
void
d2sGemItem::DiscardChanges (void)
{
  if (!dirty)
    /* No changes; nothing to do */
    return;

  /* Discard changes to the base class first. */
  this->d2sGemOrRuneItem::DiscardChanges ();

  /* Reset the gem's major type and grade. */
  LookupGem ();
}

/* Transform a gem into another kind of gem.
   If the grade is -1, make it a perfect gem. */
int
d2sGemItem::TransformInto (int new_type, int new_grade)
{
  table_entry_t new_entry;

  if ((major_type == new_type) && (grade == new_grade))
    /* Nothing is actually being changed. */
    return 0;

  /* Are we allowed to transform items? */
  if (read_only() || !options.item.edit.gem)
    {
      error_str = "Gem transformation not permitted";
      print_message (error_str);
      return -1;
    }
  if ((attachment != NULL) && !options.item.edit.socketed_gems)
    {
      error_str = ("You may not change gems which have been"
		   " placed in a socket");
      print_message (error_str);
      return -1;
    }

  /* Check the range of the parameters */
  if ((unsigned) new_type >= NUM_GEM_TYPES)
    {
      error_str = "Invalid gem type";
      return -1;
    }
  if ((unsigned) new_grade >= NUM_GEM_GRADES)
    new_grade = GGRADE_PERFECT;

  /* Change the gem.  This involves not only changing the type and
     grade, but also everything in the item table entry
     and gem table entry. */
  new_entry = LookupTableEntry ("misc", "code",
				code_for_type[new_type][new_grade]);
  if (new_entry == NULL)
    {
      print_message ("Error: %s gem (\"%3.3s\") is not found"
		     " in the item table\n", base_name, item_ID.ch);
      return -1;
    }

  /* Change the gem. */
  ChangeItemType (new_entry);
  major_type = new_type;
  grade = new_grade;

  /* Mark the gem dirty */
  MarkDirty ();
  return 0;
}

/* Look up the gem's type and grade in the static data table */
void
d2sGemItem::LookupGem (void)
{
  int i, j;

  for (i = 0; i < NUM_GEM_TYPES; i++)
    for (j = 0; i < NUM_GEM_GRADES; j++)
      if (item_ID.id == *((uint32_t *) code_for_type[i][j]))
	{
	  major_type = i;
	  grade = j;
	  return;
	}

  if (debug)
    fprintf (stderr, "%s: Error: %s gem (\"%3.3s\") not found"
	     " in the static gem table\n", progname, base_name, item_ID.ch);
}
