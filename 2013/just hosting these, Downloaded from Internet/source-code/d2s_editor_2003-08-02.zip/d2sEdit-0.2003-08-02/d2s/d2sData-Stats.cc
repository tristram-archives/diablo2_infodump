/* d2sData-Stats -- functions in the d2sData class
 *		    that deal with character statistics and skills.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "functions.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include "d2sData.h"
#include "d2sItem.h"
#include <dmalloc.h>

/* This table gives the amount of points added to stamina, life, and
   mana for each level gained and each point added to stats (Vitality
   -> stamina & life, Energy -> mana).  Numbers are in 8-bit fixed
   point, since a lot of entries have half points.
   Should this table be dynamically loaded? ... */
#define FIXED(n) ((unsigned long) (n * 256))
static const struct {
  struct {
    unsigned long	life;
    unsigned long	mana;
    unsigned long	stamina;
  } level, stats;
} points_added_for[NUM_CHAR_CLASSES] = {
  /* Amazon */
  { { FIXED(2), FIXED(1.5), FIXED(1) }, { FIXED(3), FIXED(1.5), FIXED(1) } },
  /* Sorceress */
  { { FIXED(1), FIXED(2), FIXED(1) }, { FIXED(2), FIXED(2), FIXED(1) } },
  /* Necromancer */
  { { FIXED(1.5), FIXED(2), FIXED(1) }, { FIXED(2), FIXED(2), FIXED(1) } },
  /* Paladin */
  { { FIXED(2), FIXED(1.5), FIXED(1) }, { FIXED(3), FIXED(1.5), FIXED(1) } },
  /* Barbarian */
  { { FIXED(2), FIXED(1), FIXED(1) }, { FIXED(4), FIXED(1), FIXED(1) } },
  /* Druid */
  { { FIXED(1.5), FIXED(2), FIXED(1) }, { FIXED(2), FIXED(2), FIXED(1) } },
  /* Assassin */
  { { FIXED(2), FIXED(1.5), FIXED(1.25) },
    { FIXED(3), FIXED(1.75), FIXED(1.25) } },
};

/* Forward declarations: */

static inline unsigned long exp_after_level (int level);


/********************* NON-CLASS FUNCTIONS **********************/

/* The experience table is referred to in several places;
   this function is here just to make the code more concise. */
static inline unsigned long
exp_after_level (int level)
{
  return GetEntryIntegerField
    (LookupNumericTableEntry ("experience", "Level", level),
     "Amazon");
}

/*********************** CLASS FUNCTIONS ************************/

const char *
d2sData::SkillSetName (int set)
{
  if ((unsigned) set >= NUM_SKILL_SETS)
    {
      if (debug)
	fprintf (stderr, "%s: Error: invalid argument to d2sData::"
		 "SkillSetName(%d)\n", progname, set);
      error_str = "Invalid argument";
      return NULL;
    }
  /* There is a name conflict here:: */
  return ::SkillSetName (char_class, set);
}

int
d2sData::GetSkillLevel (int skill) const
{
  if ((skill < first_skill) || (skill >= first_skill + NUM_SKILLS_PER_CHAR))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::GetSkillLevel(%d)\n (Valid skills are %d-%d)\n",
		 progname, skill, first_skill,
		 first_skill + NUM_SKILLS_PER_CHAR - 1);
      return 0;
    }
  return skill_data[skill - first_skill];
}

unsigned long
d2sData::GetExpNextLevel (void) const
{ return exp_after_level (level); }

unsigned long
d2sData::GetExperienceMin (void) const
{ return exp_after_level (level - 1); }

unsigned long
d2sData::GetGoldInInventoryMax (void) const
{
  /* This isn't stored in any table, but is defined simply according to
     The Arreat Summit: 10,000 gold per character level. */
  return (10000UL * (unsigned long) level);
}

unsigned long
d2sData::GetGoldInStashMax (void) const
{
  /* This isn't stored in any table, but is defined accordng to
     The Arreat Summit (see http://www.battle.net/diablo2exp/basics/):
     Levels  1-30: 50,000 per [int(level/10) + 1]
     Levels 31-99: 50,000 per [int(level/2) + 1] 	*/
  return (50000UL * (unsigned long) (level / ((level <= 30) ? 10 : 2) + 1));
}

int
d2sData::GetSkillMin (int skill) const
{
  int minimum = 0;
  int dep;

  if ((skill < first_skill) || (skill >= first_skill + NUM_SKILLS_PER_CHAR))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::GetSkillMin(%d)\n (Valid skills are %d-%d)\n",
		 progname, skill, first_skill,
		 first_skill + NUM_SKILLS_PER_CHAR - 1);
      return 0;
    }

  /* Check the restrictions first.  If the character is read-only, the
     skill cannot change.  If up-and-down editing is not enabled, the
     skill cannot be decreased (below its original level).  If
     prerequisites are not checked, the skill can go down to zero. */
  if (read_only || !options.character.edit.stats)
    return skill_data[skill - first_skill];
  if (!options.character.edit.up_and_down
      && backup_skill_data[skill - first_skill])
    return backup_skill_data[skill - first_skill];
  if (!options.character.link.skills_skills)
    return 0;

  /* Check this skill's dependent(s).  If any have a non-zero value,
     the minimum is 1.  Otherwise the minimum is 0. */
  dep = SkillDependent (skill);
  if (dep >= 0)
    {
      if (skill_data[dep - first_skill])
	minimum = 1;
      else
	{
	  dep = SkillDependent2 (skill);
	  if (dep >= 0)
	    {
	      if (skill_data[dep - first_skill])
		minimum = 1;
	    }
	}
    }

  return minimum;
}

int
d2sData::GetSkillMax (int skill) const
{
  int maximum;
  int dep, req_lvl, prereq_needed;

  if ((skill < first_skill) || (skill >= first_skill + NUM_SKILLS_PER_CHAR))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad parameter to"
		 " d2sData::GetSkillMax(%d)\n (Valid skills are %d-%d)\n",
		 progname, skill, first_skill,
		 first_skill + NUM_SKILLS_PER_CHAR - 1);
      return 0;
    }

  /* Check the restrictions first.  If the character is read-only,
     the skill cannot change.  If level requirements and
     prerequisites are not checked, the skill can go up to 20
     regardless of the other skills. */
  if (read_only || !options.character.edit.stats)
    return skill_data[skill - first_skill];
  if (!options.character.link.skills_skills
      && !options.character.link.skills_level)
    return (options.character.link.freeform ? 255 : 20);

  prereq_needed = 0;
  if (options.character.link.skills_skills)
    {
      /* Check any prerequisites. */
      dep = SkillDependency (skill);
      if (dep >= 0)
	{
	  if (!skill_data[dep - first_skill]) {
	    /* The character does not have the prerequisite. */
	    if (!options.character.link.auto_skill)
	      return 0;
	    prereq_needed++;
	  }
	  dep = SkillDependency2 (skill);
	  if (dep >= 0)
	    {
	      if (!skill_data[dep - first_skill]) {
		/* The character does not have the prerequisite. */
		if (!options.character.link.auto_skill)
		  return 0;
		prereq_needed++;
	      }
	    }
	}
    }

  maximum = (options.character.link.freeform ? 255 : 20);

  if (options.character.link.skills_level)
    {
      /* Check the character's level against
     the skill's minimum level requirement. */
      req_lvl = GetEntryIntegerField
	(LookupNumericTableEntry ("skills", "Id", skill), "reqlevel");
      if (level < req_lvl)
	/* This character does not meet the minimum level required. */
	return 0;

      /* You can have one additional skill point for each level above the
	 minimum required, up to a maximum of 20. */
      if (maximum > level - req_lvl + 1)
	maximum = level - req_lvl + 1;
    }

  if (options.character.link.skills_points)
    {
      /* The maximum is further limited
	 by the amount of skill points remaining. */
      if (maximum - (int) skill_data[skill - first_skill]
	  > (int) stats.skillp_remaining - prereq_needed)
	{
	  maximum = (skill_data[skill - first_skill]
		     + stats.skillp_remaining - prereq_needed);
	  /* In case we have more prerequisites
	     than remaining skill points... */
	  if (maximum < 0)
	    maximum = 0;
	}
    }

  return maximum;
}

/**************** MODIFICATION SECTION ****************/

/* Change the character's level.  Lots of incidental effects here. */
int
d2sData::SetCharacterLevel (int new_level)
{
  double exp_percentage;
  int added_levels = new_level - stats.level;
  unsigned long efpl, efnl;	/* Experience for previous/next level */

  /* Check the argument */
  if (!new_level || ((unsigned) new_level
		     > (options.character.link.freeform ? 255 : 99)))
    {
      error_str = "Invalid level";
      print_message (error_str);
      return -1;
    }
  if (!added_levels)
    /* Nothing needs to be done */
    return 0;

  /* Is changing the level allowed? */
  if (read_only || !options.character.edit.level)
    {
      error_str = "You may not change your level";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_level < (int) backup_stats.level))
    {
      error_str = "You may not decrease your level";
      print_message (error_str);
      return -1;
    }
  /* There's an extra hiccup here.  If the user increases his level,
     distributes stats or skills, then decreases the level, stat
     points and skill points could conceivably drop below zero.
     Don't let this happen. */
  if (options.character.link.level_stats && (added_levels < 0)
      && (((int) stats.statp_remaining + 5 * added_levels < 0)
	  || ((int) stats.skillp_remaining + added_levels < 0)))
    {
      error_str = ("You must put back your stat points and skill points"
		   " before decreasing your level");
      print_message (error_str);
      return -1;
    }

  /* The change is allowed.
     Do we need to alter other attributes as well? */
  if (options.character.link.level_experience)
    {
      /* Experience and level are tied together. */
      efpl = exp_after_level (stats.level - 1);
      efnl = exp_after_level (stats.level);
      /* Compute how far we are between the current level and the next */
      exp_percentage = ((double) (stats.experience - efpl)
			/ (double) (efnl - efpl));
      /* Clip the range, in case experience was modified in freeform mode */
      if (exp_percentage < 0.0)
	exp_percentage = 0.0;
      else if (exp_percentage > 1.0)
	exp_percentage = 1.0;
      efpl = exp_after_level (new_level - 1);
      efnl = exp_after_level (new_level);
      /* Scale the experience between the new level and the next */
      stats.experience = efpl + (unsigned long)
	(exp_percentage * (efnl - efpl));
      /* Just in case, check for rounding to the next level. */
      if (stats.experience >= efnl)
	stats.experience = efnl - 1;
      if (!options.character.edit.up_and_down
	  /* Check for decreasing below the original experience */
	  && (stats.experience < backup_stats.experience))
	stats.experience = backup_stats.experience;
    }

  if (options.character.link.level_stats)
    {
      /* Stats and level are tied together */
      stats.life.base
	+= (added_levels * points_added_for[char_class].level.life);
      /* Clip if the stats drop below zero */
      if ((int) stats.life.base < 0)
	stats.life.base = 0;
      stats.mana.base
	+= (added_levels * points_added_for[char_class].level.mana);
      if ((int) stats.life.base < 0)
	stats.life.base = 0;
      stats.stamina.base
	+= (added_levels * points_added_for[char_class].level.stamina);
      if ((int) stats.life.base < 0)
	stats.life.base = 0;
      if (options.character.link.stats2_base)
	{
	  stats.life.current
	    += (added_levels * points_added_for[char_class].level.life);
	  if ((int) stats.life.current < 0)
	    stats.life.current = 0;
	  stats.mana.current
	    += (added_levels * points_added_for[char_class].level.mana);
	  if ((int) stats.life.current < 0)
	    stats.life.current = 0;
	  stats.stamina.current
	    += (added_levels * points_added_for[char_class].level.stamina);
	  if ((int) stats.life.current < 0)
	    stats.life.current = 0;
	}

      /* Stat points and skill points are tied to level increases */
      stats.statp_remaining += 5 * added_levels;
      stats.skillp_remaining += added_levels;
    }

  /* All the incidentals are done.  Set the level itself.
     Remember that we have two copies. */
  stats.level = new_level;
  level = new_level;
  MarkDirty ();
  return 0;
}

/* Change the strength. */
int
d2sData::SetStrength (unsigned long new_strength)
{
  int added_points = new_strength - stats.strength;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 30, then added all your stat points
     (up to 490), then you could reach 520. */
  if (!new_strength || (new_strength >= (options.character.link.freeform
					 ? 1000000000 : 1000)))
    {
      error_str = "Invalid strength value";
      print_message (error_str);
      return -1;
    }
  if (!added_points)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats)
    {
      error_str = "You may not change your strength";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_strength < backup_stats.strength))
    {
      error_str = "You may not decrease your strength";
      print_message (error_str);
      return -1;
    }
  if (options.character.link.stats_points
      && (added_points > (int) stats.statp_remaining))
    {
      error_str = "You do not have enough stat points remaining";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed.
     Do we need to take the points from stat points remaining? */
  if (options.character.link.stats_points)
    stats.statp_remaining -= added_points;

  stats.strength = new_strength;
  MarkDirty ();
  return 0;
}

/* Change the energy. */
int
d2sData::SetEnergy (unsigned long new_energy)
{
  int added_points = new_energy - stats.energy;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 35, then added all your stat points
     (up to 490), then you could reach 525. */
  if (!new_energy || (new_energy >= (options.character.link.freeform
				     ? 1000000000 : 1000)))
    {
      error_str = "Invalid energy value";
      print_message (error_str);
      return -1;
    }
  if (!added_points)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats)
    {
      error_str = "You may not change your energy";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_energy < backup_stats.energy))
    {
      error_str = "You may not decrease your energy";
      print_message (error_str);
      return -1;
    }
  if (options.character.link.stats_points
      && (added_points > (int) stats.statp_remaining))
    {
      error_str = "You do not have enough stat points remaining";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed.
     Do we need to alter mana as well? */
  if (options.character.link.stats_stats2)
    {
      stats.mana.base
	+= (added_points * points_added_for[char_class].stats.mana);
      if (options.character.link.stats2_base)
	stats.mana.current
	  += (added_points * points_added_for[char_class].stats.mana);

      /* There's an extra hiccup here.  If the user increases his
	 energy in loose mode, decreases his mana, then decreases the
	 energy again, the mana could conceivably drop below zero.
	 Don't let this happen. */
      if ((signed) stats.mana.base <= 0)
	{
	  if (options.character.link.stats2_base)
	    stats.mana.current += 1 - (signed) stats.mana.base;
	  stats.mana.base = 1;
	}
      if (options.character.link.stats2_base)
	if ((signed) stats.mana.current <= 0)
	  stats.mana.current = 1;
    }

  /* Do we need to take the points from stat points remaining? */
  if (options.character.link.stats_points)
    stats.statp_remaining -= added_points;

  stats.energy = new_energy;
  MarkDirty ();
  return 0;
}

/* Change the dexterity. */
int
d2sData::SetDexterity (unsigned long new_dexterity)
{
  int added_points = new_dexterity - stats.dexterity;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 25, then added all your stat points
     (up to 490), then you could reach 515. */
  if (!new_dexterity || (new_dexterity >= (options.character.link.freeform
					   ? 1000000000 : 1000)))
    {
      error_str = "Invalid dexterity value";
      print_message (error_str);
      return -1;
    }
  if (!added_points)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats)
    {
      error_str = "You may not change your dexterity";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_dexterity < backup_stats.dexterity))
    {
      error_str = "You may not decrease your dexterity";
      print_message (error_str);
      return -1;
    }
  if (options.character.link.stats_points
      && (added_points > (int) stats.statp_remaining))
    {
      error_str = "You do not have enough stat points remaining";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed.
     Do we need to take the points from stat points remaining? */
  if (options.character.link.stats_points)
    stats.statp_remaining -= added_points;

  stats.dexterity = new_dexterity;
  MarkDirty ();
  return 0;
}

/* Change the vitality. */
int
d2sData::SetVitality (unsigned long new_vitality)
{
  int added_points = new_vitality - stats.vitality;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 25, then added all your stat points
     (up to 490), then you could reach 515. */
  if (!new_vitality || (new_vitality >= (options.character.link.freeform
					 ? 1000000000 : 1000)))
    {
      error_str = "Invalid vitality value";
      print_message (error_str);
      return -1;
    }
  if (!added_points)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats)
    {
      error_str = "You may not change your vitality";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_vitality < backup_stats.vitality))
    {
      error_str = "You may not decrease your vitality";
      print_message (error_str);
      return -1;
    }
  if (options.character.link.stats_points
      && (added_points > (int) stats.statp_remaining))
    {
      error_str = "You do not have enough stat points remaining";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed.
     Do we need to alter life and stamina as well? */
  if (options.character.link.stats_stats2)
    {
      stats.life.base
	+= (added_points * points_added_for[char_class].stats.life);
      stats.stamina.base
	+= (added_points * points_added_for[char_class].stats.stamina);
      if (options.character.link.stats2_base)
	{
	  stats.life.current
	    += (added_points * points_added_for[char_class].stats.life);
	  stats.stamina.current
	    += (added_points * points_added_for[char_class].stats.stamina);
	}

      /* There's an extra hiccup here.  If the user increases his
	 vitality in loose mode, decreases his life or stamina, then
	 decreases the vitality again, the life or stamina could
	 conceivably drop below zero.  Don't let this happen. */
      if ((signed) stats.life.base <= 0)
	{
	  if (options.character.link.stats2_base)
	    stats.life.current += 1 - (signed) stats.life.base;
	  stats.life.base = 1;
	}
      if ((signed) stats.stamina.base <= 0)
	{
	  if (options.character.link.stats2_base)
	    stats.stamina.current += 1 - (signed) stats.stamina.base;
	  stats.stamina.base = 1;
	}
      if (options.character.link.stats2_base)
	{
	  if ((signed) stats.life.current <= 0)
	    stats.life.current = 1;
	  if ((signed) stats.stamina.current <= 0)
	    stats.stamina.current = 1;
	}
    }

  /* Do we need to take the points from stat points remaining? */
  if (options.character.link.stats_points)
    stats.statp_remaining -= added_points;

  stats.vitality = new_vitality;
  MarkDirty ();
  return 0;
}

/* Change the base amount of life */
int
d2sData::SetLifeBase (double new_life)
{
  uint32_t new_life_32;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 55, added 2 for each level, then 4 more
     for each stat point (of which you had up to 490), then you
     could reach 2211. */
  if ((new_life < 0.5) || (new_life > (options.character.link.freeform
				       ? 8000000 : 10000)))
    {
      error_str = "Invalid life value";
      print_message (error_str);
      return -1;
    }
  new_life_32 = (unsigned long) rint (new_life * 256.0);
  if (new_life_32 == stats.life.base)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats2)
    {
      error_str = "You may not change your life";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_life_32 < backup_stats.life.base))
    {
      error_str = "You may not decrease your life";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed.
     Do we need to alter current life as well? */
  if (options.character.link.stats2_base)
    {
      stats.life.current += new_life_32 - stats.life.base;
      /* Make sure the current life doesn't overflow */
      if ((signed) stats.life.current < 128)
	stats.life.current = 128;
      else if (stats.life.current > 0x7a11ff80L)
	stats.life.current = 0x7a11ff80L;
    }

  stats.life.base = new_life_32;
  MarkDirty ();
  return 0;
}

/* Change the current amount of life */
int
d2sData::SetCurrentLife (double new_life)
{
  uint32_t new_life_32;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 55, added 2 for each level, then 4 more
     for each stat point (of which you had up to 490), then you
     could reach 2211. */
  if ((new_life < 0.04) || (new_life > (options.character.link.freeform
				       ? 8000000 : 10000)))
    {
      error_str = "Invalid life value";
      print_message (error_str);
      return -1;
    }
  new_life_32 = (unsigned long) rint (new_life * 256.0);
  if (new_life_32 == stats.life.current)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats)
    {
      error_str = "You may not change your life";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed. */
  stats.life.current = new_life_32;
  MarkDirty ();
  return 0;
}

/* Change the base amount of mana */
int
d2sData::SetManaBase (double new_mana)
{
  uint32_t new_mana_32;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 55, added 2 for each level, then 4 more
     for each stat point (of which you had up to 490), then you
     could reach 2211. */
  if ((new_mana < 0.5) || (new_mana > (options.character.link.freeform
				       ? 8000000 : 10000)))
    {
      error_str = "Invalid mana value";
      print_message (error_str);
      return -1;
    }
  new_mana_32 = (unsigned long) rint (new_mana * 256.0);
  if (new_mana_32 == stats.mana.base)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats2)
    {
      error_str = "You may not change your mana";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_mana_32 < backup_stats.mana.base))
    {
      error_str = "You may not decrease your mana";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed.
     Do we need to alter current mana as well? */
  if (options.character.link.stats2_base)
    {
      stats.mana.current += (new_mana_32
			     - stats.mana.base);
      /* Make sure the current mana doesn't overflow */
      if ((signed) stats.mana.current < 128)
	stats.mana.current = 128;
      else if (stats.mana.current > 0x7a11ff80L)
	stats.mana.current = 0x7a11ff80L;
    }

  stats.mana.base = new_mana_32;
  MarkDirty ();
  return 0;
}

/* Change the current amount of mana */
int
d2sData::SetCurrentMana (double new_mana)
{
  uint32_t new_mana_32;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 55, added 2 for each level, then 4 more
     for each stat point (of which you had up to 490), then you
     could reach 2211. */
  if ((new_mana < 0.001) || (new_mana > (options.character.link.freeform
				       ? 8000000 : 10000)))
    {
      error_str = "Invalid mana value";
      print_message (error_str);
      return -1;
    }
  new_mana_32 = (unsigned long) rint (new_mana * 256.0);
  if (new_mana_32 == stats.mana.current)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats)
    {
      error_str = "You may not change your mana";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed. */
  stats.mana.current = new_mana_32;
  MarkDirty ();
  return 0;
}

/* Change the base amount of stamina */
int
d2sData::SetStaminaBase (double new_stamina)
{
  uint32_t new_stamina_32;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 55, added 2 for each level, then 4 more
     for each stat point (of which you had up to 490), then you
     could reach 2211. */
  if ((new_stamina < 0.5) || (new_stamina > (options.character.link.freeform
					     ? 8000000 : 10000)))
    {
      error_str = "Invalid stamina value";
      print_message (error_str);
      return -1;
    }
  new_stamina_32 = (unsigned long) rint (new_stamina * 256.0);
  if (new_stamina_32 == stats.stamina.base)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats2)
    {
      error_str = "You may not change your stamina";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_stamina_32 < backup_stats.stamina.base))
    {
      error_str = "You may not decrease your stamina";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed.
     Do we need to alter current stamina as well? */
  if (options.character.link.stats2_base)
    {
      stats.stamina.current += (new_stamina_32
				- stats.stamina.base);
      /* Make sure the current stamina doesn't overflow */
      if ((signed) stats.stamina.current < 128)
	stats.stamina.current = 128;
      else if (stats.stamina.current > 0x7a11ff80L)
	stats.stamina.current = 0x7a11ff80L;
    }

  stats.stamina.base = new_stamina_32;
  MarkDirty ();
  return 0;
}

/* Change the current amount of stamina */
int
d2sData::SetCurrentStamina (double new_stamina)
{
  uint32_t new_stamina_32;

  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     If you started with 55, added 2 for each level, then 4 more
     for each stat point (of which you had up to 490), then you
     could reach 2211. */
  if ((new_stamina < 0.001) || (new_stamina > (options.character.link.freeform
					     ? 8000000 : 10000)))
    {
      error_str = "Invalid stamina";
      print_message (error_str);
      return -1;
    }
  new_stamina_32 = (unsigned long) rint (new_stamina * 256.0);
  if (new_stamina_32 == stats.stamina.current)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stats allowed? */
  if (read_only || !options.character.edit.stats)
    {
      error_str = "You may not change your stamina";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed. */
  stats.stamina.current = new_stamina_32;
  MarkDirty ();
  return 0;
}

/* Change the amount of stat points remaining */
int
d2sData::SetStatPointsRemaining (int new_points)
{
  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     You get 5 stat points per level increase (98),
     which totals 490; but there may be bonuses too. */
  if ((unsigned) new_points >= (options.character.link.freeform
				? 1000000000 : 1000))
    {
      error_str = "Invalid number of stat points";
      print_message (error_str);
      return -1;
    }
  if (new_points == (int) stats.statp_remaining)
    /* Nothing needs to be done */
    return 0;

  /* Is changing stat points allowed? */
  if (read_only || !options.character.edit.stat_points)
    {
      error_str = "You may not change the number of stat points remaining";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed. */
  stats.statp_remaining = new_points;
  MarkDirty ();
  return 0;
}

/* Change the amount of skill points remaining */
int
d2sData::SetSkillPointsRemaining (int new_points)
{
  /* Check the argument.
     I have no idea what the limit is; this is just a guess.
     You get 1 skill point per level increase (98);
     but there are bonuses too.  To max out on all possible
     skills, you would need 30*20=600 points. */
  if ((unsigned) new_points >= (options.character.link.freeform
				? 1000000000 : 1000))
    {
      error_str = "Invalid number of skill choices";
      print_message (error_str);
      return -1;
    }
  if (new_points == (int) stats.skillp_remaining)
    /* Nothing needs to be done */
    return 0;

  /* Is changing skill points allowed? */
  if (read_only || !options.character.edit.skill_points)
    {
      error_str = "You may not change the number of skill choices remaining";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed. */
  stats.skillp_remaining = new_points;
  MarkDirty ();
  return 0;
}

/* Change the character's experience */
int
d2sData::SetExperience (unsigned long new_experience)
{
  int new_level;

  /* I'd check the argument, but it looks as if all values may be
     legal -- the character starts at 0, and at level 99 the
     experience can reach 3837739017 (0xE4BF4009UL)! */
  if (new_experience == stats.experience)
    /* Nothing needs to be done */
    return 0;

  /* Is changing the experience allowed? */
  if (read_only || !options.character.edit.experience)
    {
      error_str = "You may not change your experience";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_experience < backup_stats.experience))
    {
      error_str = "You may not decrease your experience";
      print_message (error_str);
      return -1;
    }

  if (options.character.link.level_experience
      && ((new_experience < exp_after_level (stats.level - 1))
	  || (new_experience >= exp_after_level (stats.level))))
    {
      if (!options.character.edit.level)
	{
	  error_str = ("You may not change your experience beyond"
		       " your current level");
	  print_message (error_str);
	  return -1;
	}

      /* The change is allowed, as far as experience goes.
	 If the new experience would put the character at a different level,
	 we may also need to modify the level and other stats. */
      for (new_level = 0;
	   (new_level < 99)
	     && (new_experience >= exp_after_level (new_level));
	   new_level++);
      if (SetCharacterLevel (new_level) < 0)
	return -1;
    }

  /* All that's left is the experience itself. */
  stats.experience = new_experience;
  MarkDirty ();
  return 0;
}

/* Make your character rich (or poor) */
int
d2sData::SetGoldInInventory (unsigned long new_gold)
{
  if (new_gold > (options.character.link.freeform ? 1000000000
		  : GetGoldInInventoryMax()))
    {
      error_str = "Invalid amount of gold";
      if (new_gold <= 1000000000)
	print_message ("You cannot carry that much gold.  The most you can"
		       " keep with you is %lu.", GetGoldInInventoryMax());
      else
	print_message (error_str);
      return -1;
    }
  if (new_gold == stats.gold_in_inventory)
    /* Nothing needs to be done */
    return 0;

  /* Is changing the amount of gold allowed? */
  if (read_only || !options.character.edit.gold)
    {
      error_str = "You may not change the amount gold you have";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed. */
  stats.gold_in_inventory = new_gold;
  MarkDirty ();
  return 0;
}

int
d2sData::SetGoldInStash (unsigned long new_gold)
{
  if (new_gold > (options.character.link.freeform ? 1000000000
		  : GetGoldInStashMax()))
    {
      error_str = "Invalid amount of gold";
      if (new_gold <= 1000000000)
	print_message ("You cannot store that much gold.  The most you can"
		       " save in your stash is %lu.", GetGoldInStashMax());
      else
	print_message (error_str);
      return -1;
    }
  if (new_gold == stats.gold_in_stash)
    /* Nothing needs to be done */
    return 0;

  /* Is changing the amount of gold allowed? */
  if (read_only || !options.character.edit.gold)
    {
      error_str = "You may not change the amount gold you have";
      print_message (error_str);
      return -1;
    }

  /* The change is allowed. */
  stats.gold_in_stash = new_gold;
  MarkDirty ();
  return 0;
}

/* Change one of the character's skill levels */
int
d2sData::SetSkillLevel (int skill, int new_level)
{
  int added_points;
  int dep;

  /* Check the arguments. */
  if ((skill < first_skill)
      || (skill >= first_skill + NUM_SKILLS_PER_CHAR)
      || ((unsigned) new_level > 255))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::SetSkillLevel(%d,%d)\n",
		 progname, skill, new_level);
      error_str = "Invalid argument";
      return -1;
    }
  if (((unsigned) new_level > 20) && !options.character.link.freeform)
    {
      error_str = "Invalid skill level";
      print_message (error_str);
      return -1;
    }
  added_points = new_level - skill_data[skill - first_skill];
  if (!added_points)
    /* Nothing needs to be done */
    return 0;

  /* Is changing skill levels allowed? */
  if (read_only || !options.character.edit.skills)
    {
      error_str = "You may not change your skill level";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_level < backup_skill_data[skill - first_skill]))
    {
      error_str = "You may not decrease your skill level";
      print_message (error_str);
      return -1;
    }

  if (new_level && options.character.link.skills_level)
    {
      /* Check the range. */
      int req_level = GetEntryIntegerField
	(LookupNumericTableEntry ("skills", "Id", skill), "reqlevel");
      if (new_level > level - req_level + 1)
	{
	  error_str = "Level requirement not met";
	  print_message (error_str);
	  return -1;
	}
    }

  if (options.character.link.skills_skills)
    {
      /* Check for dependencies. */
      if (new_level) {
	dep = SkillDependency (skill);
	if (dep >= 0) {
	  if (!skill_data[dep - first_skill]) {
	    if (options.character.link.auto_skill) {
	      if (SetSkillLevel (dep, 1) < 0) {
		print_message ("Prerequisite not met");
		return -1;
	      }
	    } else {
	      error_str = "Prerequisite(s) not met";
	      print_message (error_str);
	      return -1;
	    }
	  }
	  dep = SkillDependency2 (skill);
	  if (dep >= 0) {
	    if (!skill_data[dep - first_skill]) {
	      if (options.character.link.auto_skill) {
		if (SetSkillLevel (dep, 1) < 0) {
		  print_message ("Prerequisite not met");
		  return -1;
		}
	      } else {
		error_str = "Prerequisite not met";
		print_message (error_str);
		return -1;
	      }
	    }
	  }
	}
      }

      else /* new_level == 0 */ {
	dep = SkillDependent (skill);
	if (dep >= 0) {
	  if (skill_data[dep - first_skill]) {
	    if (options.character.link.auto_skill) {
	      if (SetSkillLevel (dep, 0) < 0) {
		print_message ("You have other skills that depend"
			       " on this one");
		return -1;
	      }
	    } else {
	      error_str = "You have other skills that depend on this one";
	      print_message (error_str);
	      return -1;
	    }
	  }
	  dep = SkillDependent2 (skill);
	  if (dep >= 0) {
	    if (skill_data[dep - first_skill]) {
	      if (options.character.link.auto_skill) {
		if (SetSkillLevel (dep, 0) < 0) {
		  print_message ("You have other skills that depend"
				 " on this one");
		  return -1;
		}
	      } else {
		error_str = "You have other skills that depend on this one";
		print_message (error_str);
		return -1;
	      }
	    }
	  }
	}
      }
    }

  if (options.character.link.skills_points)
    {
      if (added_points > (int) stats.skillp_remaining)
	{
	  if (stats.skillp_remaining)
	    print_message ("You only have %d skill points remaining\n",
			   stats.skillp_remaining);
	  else
	    print_message ("You do not have any skill points remaining\n");
	  error_str = "You do not have enough skill points remaining";
	  return -1;
	}

      /* Everything checks out.  Change the level. */
      stats.skillp_remaining -= added_points;
    }

  skill_data[skill - first_skill] = new_level;
  MarkDirty ();
  return 0;
}
