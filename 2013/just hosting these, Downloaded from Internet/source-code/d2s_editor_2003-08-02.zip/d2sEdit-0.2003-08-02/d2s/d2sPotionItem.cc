/* d2sPotionItem -- C++ class that holds an internal representation
 *		    of a Diablo II v1.09 potion.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/***************************** DATA *****************************/

/* A list of all the potion types defined in the database
   (this list is so small, we define in statically) */
static const char * const potion_names[6] = {
  "Healing", "Mana", "Rejuvination", "Stamina", "Thawing", "Antidote"
};

/* Number of grades for each type of potion */
static const char num_grades_for_potion[6] = { 5, 5, 2, 1, 1, 1 };

/* Potion grades for healing and mana potions */
static const char * const hm_potion_grades[5] = {
  "Minor", "Light", "", "Greater", "Super"
};

/* Potion grades for rejuvination potions */
static const char * const r_potion_grades[2] = { "", "Full" };

/* Map potion type and grade to item ID */
static const struct {
  const char code[4];
  const char *name;
} id_from_type[6][5] = {
  { { "hp1", "Minor Healing Potion" },
    { "hp2", "Light Healing Potion" },
    { "hp3", "Healing Potion" },
    { "hp4", "Greater Healing Potion" },
    { "hp5", "Super Healing Potion" }, },
  { { "mp1", "Minor Mana Potion" },
    { "mp2", "Light Mana Potion" },
    { "mp3", "Mana Potion" },
    { "mp4", "Greater Mana Potion" },
    { "mp5", "Super Mana Potion" }, },
  { { "rvs", "Rejuvination Potion" },
    { "rvl", "Full Rejuvination Potion" }, },
  { { "vps", "Stamina Potion" }, },
  { { "wms", "Thawing Potion" }, },
  { { "yps", "Antidote Potion" }, }
};


/************************** FUNCTIONS ***************************/

/* Return the number of potion types defined. */
int
GetNumberOfPotionTypes (void)
{
  return XtNumber (potion_names);
}

/* Return the base name of the Nth defined potion */
const char *
GetPotionTypeName (int type)
{
  if ((unsigned) type >= (unsigned) XtNumber (potion_names))
    return NULL;
  return potion_names[type];
}

/* Return the number of potion grades for a potion of the given type
   (5 for health or mana, 2 for rejuvination, 1 for others). */
int GetNumberOfPotionGrades (int type)
{
  if ((unsigned) type >= (unsigned) XtNumber (potion_names))
    return 0;
  return num_grades_for_potion[type];
}

/* Return the prefix of the Nth grade of a potion type */
const char *
GetPotionGradePrefix (int type, int grade_N)
{
  if (((unsigned) type >= (unsigned) XtNumber (potion_names))
      || ((unsigned) grade_N >= (unsigned) num_grades_for_potion[type]))
    return NULL;
  return ((type < 2) ? hm_potion_grades[grade_N] : r_potion_grades[grade_N]);
}


/**************** POTION CLASS ****************
 *
 * A simple class that can be placed in the belt
 * and can change form from one potion to another
 **********************************************/

/* Create a new, blank potion (to be filled in later) */
d2sPotionItem::d2sPotionItem (void)
  : d2sItem ()		// Construct the base class part first
{
  /* Override the default item class */
  item_class = POTION_ITEM;
  nvop = this;
  major_type = 0;	// Minor Healing Potion
  grade = 0;
}

/* Create a new, specific potion as described by the item table entry */
d2sPotionItem::d2sPotionItem (table_entry_t tent)
  : d2sItem (tent)	// Construct the base class part first
{
  /* Override the default item class */
  item_class = POTION_ITEM;
  nvop = this;
  /* Look up the potion's type and grade in the static data table */
  if ((LookupPotion () < 0) && debug)
    fprintf (stderr, "%s: Error: potion \"%s\" not found"
	     " in the static potion table\n", progname, base_name);
}

/* Copy an existing potion */
d2sPotionItem::d2sPotionItem (const d2sPotionItem &source)
  : d2sItem (source)	// Construct the base class part first
{
  nvop = this;
  /* Copy our fields from the source item.
     Note that d2sItem::d2sItem(source) will have already copied
     the general item fields. */
  this->major_type = source.major_type;
  this->grade = source.grade;
}

/* Copy a potion. */
d2sItem *
d2sPotionItem::Copy (void) const
{
  d2sPotionItem *new_item = new d2sPotionItem (*this);
  return (d2sItem *) new_item;
}

/* Create a potion by filling in data from a file.
   (This simply calls d2sItem::Read, then sets our own data fields) */
int
d2sPotionItem::Read (struct data_stream *dstream)
{
  int status;

  /* The parent class does the actual reading */
  status = this->d2sItem::Read (dstream);

  /* All we need to do is set the potion's major type and grade. */
  if ((LookupPotion() < 0) && debug)
    fprintf (stderr, "%s: Error: potion \"%.4s\" not found"
	     " in the static potion table\n", progname, base_name);
  return status;
}

/* If the potion type was changed, change it back. */
void
d2sPotionItem::DiscardChanges (void)
{
  if (!dirty)
    /* No changes; nothing to do */
    return;

  /* Discard changes to the base class first. */
  this->d2sItem::DiscardChanges ();

  /* Reset the potion's major type and grade and base name. */
  LookupPotion ();
}

/* Potions add a number of points to their description. */
char *
d2sPotionItem::FullDescription (void) const
{
  char *descr;
  const char *cstr;

  /* Hardcoding this is probably wrong. */
  switch (major_type)
    {
    case 0:	/* Healing */
    case 1:	/* Mana */
      cstr = LookupStringByKey ("ItemStats1q");
      if (cstr == NULL)
	cstr = "Points:";
      descr = (char *) xmalloc (strlen (base_name) + 1 + strlen (cstr) + 12);
      sprintf (descr, "%s\n%s %d",
	       base_name, cstr, 0 /* Don't know what this should be */);
      break;

    case 2:	/* Rejuvination */
      cstr = LookupStringByKey (grade ? "ItemStatsrejuv2" : "ItemStatsrejuv1");
      if (cstr == NULL)
	cstr = (grade ? "Heals 100% Life and Mana"
		: "Heals 35% Life and Mana");
      descr = (char *) xmalloc (strlen (base_name) + 1 + strlen (cstr) + 1);
      sprintf (descr, "%s\n%s", base_name, cstr);
      break;

    default:	/* Need to get descriptions for these */
      descr = xstrdup (base_name);
    }

  return descr;
}

/* Transform a potion into another kind of potion.
   If the grade is -1, use the highest grade for that type of potion. */
int
d2sPotionItem::TransformInto (int new_type, int new_grade)
{
  table_entry_t ent_potn;

  /* Check the range of the parameters */
  if ((unsigned) new_type >= (unsigned) XtNumber (potion_names))
    {
      error_str = "Invalid potion type";
      return -1;
    }
  if (new_grade < 0)
    new_grade = num_grades_for_potion[new_type] - 1;
  else if ((signed) new_grade >= (signed) num_grades_for_potion[new_type])
    {
      error_str = "Invalid grade for potion type";
      return -1;
    }

  /* Are we allowed to transform items? */
  if (read_only() || !options.item.edit.potion)
    {
      error_str = "Potion transformation not permitted";
      print_message (error_str);
      return -1;
    }

  /* Change the potion.  This involves not only changing the type and
     grade, but also the item's table entry pointer as well. */
  ent_potn = LookupTableEntry ("misc", "code",
			       id_from_type[new_type][new_grade].code);
  if (ent_potn == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: potion %s (\"%3.3s\") in the"
		 " static\ndata table cannot be found in the external item"
		 " table\n", progname, id_from_type[new_type][new_grade].name,
		 id_from_type[new_type][new_grade].code);
      error_str = "Internal potion data error";
      return -1;
    }
  ChangeItemType (ent_potn);
  major_type = new_type;
  grade = new_grade;

  /* Mark the potion dirty */
  MarkDirty ();
  return 0;
}

/* Look up the potion's type and grade in the static data table */
int
d2sPotionItem::LookupPotion (void)
{
  int i, j;

  for (i = 0; i < (int) XtNumber (potion_names); i++)
    for (j = 0; j < num_grades_for_potion[i]; j++)
      if (item_ID.id == *((uint32_t *) id_from_type[i][j].code))
	{
	  major_type = i;
	  grade = j;
	  return 0;
	}
  return -1;
}
