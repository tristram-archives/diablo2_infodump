/* Display the hotkey assignments in a Diablo II .key file */

#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>


/* Structure of the .key file (very simple): */
struct d2_key_file {
  short		magic;		/* 37 */
  struct {
    long	function;
    short	key_code;	/* -1 = None */
    long	assignment;	/* 0 = unassigned */
  } __attribute__ ((packed)) k[114];
} __attribute__ ((packed)) file_data;

/* Function names: */
const char * const function_names[57] = {
  "Character Screen", "Inventory Screen", "Party Screen", "Message Log",
  "Quest Log", "Chat", "Help Screen", "Automap",
  "Center Automap", "Fade Automap", "Party on Automap", "Names on Automap",
  "Skill Tree", "Skill Speed Bar", "Skill 1", "Skill 2",
  "Skill 3", "Skill 4", "Skill 5", "Skill 6",
  "Skill 7", "Skill 8", "Show Belt", "Use Belt 1",
  "Use Belt 2", "Use Belt 3", "Use Belt 4", "Say 'Help'",
  "Say 'Follow Me'", "Say 'This is for you'", "Say 'Thanks'", "Say 'Sorry'",
  "Say 'Bye'", "Say 'Now you die'", "Run", "Toggle Run/Walk",
  "Stand Still", "Show Items", "Clear Screen", "Select Previous Skill",
  "Select Next Skill", "Clear Messages", "Screen Shot", "Show Portraits",
  /* The following hotkeys are only available in the Expansion Set: */
#define EXPANSION_SET_FUNCTION 44
  "Swap Weapons", "Toggle MiniMap", "Skill 9", "Skill 10",
  "Skill 11", "Skill 12", "Skill 13", "Skill 14",
  "Skill 15", "Skill 16", "Hireling Screen",
  /* But, the following key is available in a non-expansion game? */
  "Say 'Retreat'",
  /* The following hotkey is not modifyable: */
#define IMMUTABLE_FUNCTION 56
  "Option Menu"
};

/* Ordering of the function names on the Configure Controls dialog
   (-10 represents a blank line in the display): */
const int function_listing[2][64] = {
  { /* The first list is for standard characters: */
    0, 1, 2, 3, 4, 6, -10, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 39, 40, -10, 22, 23, 24, 25, 26, -10, 5, 34, 35, 36, 37, 43,
    -10, 7, 8, 9, 10, 11, -10, 27, 28, 29, 30, 31, 32, 33, 55, -10,
    42, 38, 41, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
  },
  { /* The second list is for Expansion characters: */
    0, 1, 2, 54, 3, 4, 6, -10, 12, 13, 14, 15, 16, 17, 18, 19,
    20, 21, 46, 47, 48, 49, 50, 51, 52, 53, 39, 40, -10, 22, 23, 24,
    25, 26, 44, -10, 5, 34, 35, 36, 37, 43, -10, 7, 8, 9, 10, 11,
    45, -10, 27, 28, 29, 30, 31, 32, 33, 55, -10, 42, 38, 41, -1, -1
  }
};

/* Key codes: */
const char * const key_code_names[257] = {
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, "Tab", NULL, NULL, NULL, "Enter", NULL, NULL,
  "Shift", "Ctrl", "Alt", NULL, "Caps Lock", NULL, NULL, NULL,
  NULL, NULL, NULL, "Esc", NULL, NULL, NULL, NULL,
  "Space", "Page Up", "Page Down", "End", "Home", NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, "Print Screen", "Insert", "Delete", NULL,
  "0", "1", "2", "3", "4", "5", "6", "7",
  "8", "9", NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, "A", "B", "C", "D", "E", "F", "G",
  "H", "I", "J", "K", "L", "M", "N", "O",
  "P", "Q", "R", "S", "T", "U", "V", "W",
  "X", "Y", "Z", NULL, NULL, NULL, NULL, NULL,
  "Num Pad 0", "Num Pad 1", "Num Pad 2", "Num Pad 3",
  "Num Pad 4", "Num Pad 5", "Num Pad 6", "Num Pad 7",
  "Num Pad 8", "Num Pad 9", "Num Pad *", "Num Pad +",
  NULL, "Num Pad -", NULL, "Num Pad /",
  "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8",
  "F9", "F10", "F11", "F12", NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, ";", "=", ",", "-", ".", "/",
  "~", NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, "[", "\\", "]", "'", NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  "Mouse 3"
};


int
lookup (int function, int assignment)
{
  int i;

  for (i = 0; i < 114; i++)
    {
      if ((file_data.k[i].function == function)
	  && (file_data.k[i].assignment == assignment))
	return file_data.k[i].key_code;
    }
  return -1;
}

int
main (int argc, char **argv)
{
  int fd;
  int status;
  int line;
  int key_code[2];

  if (argc < 2)
    {
      fprintf (stderr, "Please specify a .key file on the command line.\n");
      exit (1);
    }
  fd = open (argv[1], O_RDONLY);
  if (fd < 0)
    {
      fprintf (stderr, "%s: %s.\n", argv[1], strerror (errno));
      exit (1);
    }
  status = read (fd, &file_data, sizeof (file_data));
  close (fd);
  if (status != sizeof (file_data))
    {
      if (status > 0)
	fprintf (stderr, "%s: Expected %d bytes; got %d.\n",
		 argv[1], sizeof (file_data), status);
      else
	fprintf (stderr, "%s: %s.\n", argv[1], strerror (errno));
      exit (1);
    }

  printf ("%-32s%-20s%-20s\n", "Function", "Key/Button One", "Key/Button Two");
  for (line = 0; line < 64; line++)
    {
      if (function_listing[1][line] == -1)
	break;
      if (function_listing[1][line] == -10)
	{
	  putchar ('\n');
	  continue;
	}

      key_code[0] = lookup (function_listing[1][line], 1);
      key_code[1] = lookup (function_listing[1][line], 2);
      printf (" %-31s", function_names[function_listing[1][line]]);
      if (key_code[0] == -1)
	printf (" %-19s", "None");
      else if (key_code_names[key_code[0]] == NULL)
	printf (" %#-19x", key_code[0]);
      else
	printf (" %-19s", key_code_names[key_code[0]]);
      if (key_code[1] == -1)
	printf (" %-19s", "None");
      else if (key_code_names[key_code[1]] == NULL)
	printf (" %#-19x", key_code[1]);
      else
	printf (" %-19s", key_code_names[key_code[1]]);
      putchar ('\n');
    }
}
