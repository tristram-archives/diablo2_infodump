/* Non-class functions for the Diablo II v1.09 game editor.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "functions.h"
#include "internal.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* These tables are small enough to store internally */
const char * const class_names[NUM_CHAR_CLASSES] =
{ "Amazon", "Sorceress", "Necromancer", "Paladin", "Barbarian",
  "Druid", "Assassin" };

static const char * const difficulty_names[NUM_DIFFICULTY_LEVELS] =
{ "Normal", "Nightmare", "Hell" };

static int number_of_quests_in_act[MAX_NUM_ACTS] = { 0 };
static int number_of_waypoints_in_act[MAX_NUM_ACTS] = { 0 };

/* This structure is built from the external skills table.
   Since the skills table only has one-way dependencies listed,
   and they are given by name, we use that to create a tree
   that is organized in both directions by ID. */
static struct dependency_tree_t {
  int16_t	requires[2];
  int16_t	dependent[2];
} *dependency_tree = NULL;
int dependency_tree_size = 0;


/* Get the name of a particular class. */
const char *
GetCharacterClassName (int char_class)
{
  const char *cstr;

  if ((unsigned) char_class >= NUM_CHAR_CLASSES)
    {
      errno = EINVAL;
      return NULL;
    }

  /* Use the external tables with international translation if possible */
  cstr = GetEntryStringField
    (LookupIndexedTableEntry ("playerclass", char_class),
     "Player Class");
  if (cstr[0])
    cstr = TranslateString (cstr);
  /* If we don't have an entry, use the static list. */
  else
    cstr = class_names[char_class];
  return cstr;
}

int
GetNumberOfActs (int in_expansion)
{
  /* We could count the entries in the "acts" table,
     but since the number is so simple and well-defined,
     why bother? */
  return (in_expansion ? MAX_NUM_ACTS : (MAX_NUM_ACTS - 1));
}

int
GetNumberOfQuestsInAct (int act)
{
  if (act >= MAX_NUM_ACTS)
    {
      errno = EINVAL;
      return -1;
    }

  /* Populate the array if we haven't already done so */
  if ( ! number_of_quests_in_act[act])
    number_of_quests_in_act[act]
      = GetEntryIntegerField (LookupIndexedTableEntry ("acts", act),
			      "numQuests");
  return number_of_quests_in_act[act];
}

int
GetNumberOfWaypointsInAct (int act)
{
  if (act >= MAX_NUM_ACTS)
    {
      errno = EINVAL;
      return -1;
    }

  /* Populate the array if we haven't already done so */
  if ( ! number_of_waypoints_in_act[act])
    number_of_waypoints_in_act[act]
      = GetEntryIntegerField (LookupIndexedTableEntry ("acts", act),
			      "numWaypoints");
  return number_of_waypoints_in_act[act];
}

const char *
GetDifficultyName (int difficulty)
{
  if ((unsigned) difficulty < NUM_DIFFICULTY_LEVELS)
    return difficulty_names[difficulty];
  else
    {
      errno = EINVAL;
      return NULL;
    }
}

const char *
GetActName (int act)
{
  if ((unsigned) act >= MAX_NUM_ACTS)
    {
      errno = EINVAL;
      return NULL;
    }
  return GetEntryStringField (LookupIndexedTableEntry ("acts", act),
			      "Name");
}

const char *
GetQuestName (int act, int quest)
{
  char make_name[8] = "a1q1";
  const char *cstr, *quest_name;

  if (((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) quest > (unsigned) GetNumberOfQuestsInAct (act)))
    {
      errno = EINVAL;
      return NULL;
    }

  make_name[1] = (char) ('1' + act);
  make_name[3] = (char) ('1' + quest);
  cstr = GetEntryStringField (LookupTableEntry ("quests", "code", make_name),
			      "qsts");
  if (cstr[0])
    {
      quest_name = LookupStringByKey (cstr);
      if (quest_name != NULL)
	return quest_name;
    }
  quest_name = GetEntryStringField (LookupTableEntry ("quests", "code",
						      make_name),
				    "name");
  return quest_name;
}

const char *
GetWaypointName (int act, int point)
{
  char make_name[8] = "a1wp1";

  if (((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) point >= (unsigned) GetNumberOfWaypointsInAct (act)))
    {
      errno = EINVAL;
      return NULL;
    }

  make_name[1] = (char) ('1' + act);
  make_name[4] = (char) ('1' + point);
  return TranslateString (GetEntryStringField
			  (LookupTableEntry ("waypoints", "code", make_name),
			   "Name"));
}

/* Get the number of NPC's in an act.  As listed in the acts table. */
int
GetNumberOfNPCsInAct (int act)
{
  if ((unsigned) act >= MAX_NUM_ACTS)
    {
      errno = EINVAL;
      return 0;
    }
  return GetEntryIntegerField (LookupIndexedTableEntry ("acts", act),
			      "numNPCs");
}

/* Get the name of the Nth NPC in an act */
const char
*GetNPCName (int act, int npc)
{
  table_entry_t act_entry;
  int numNPCs;
  char npc_field[8] = "NPC1";

  if ((unsigned) act >= MAX_NUM_ACTS)
    {
      errno = EINVAL;
      return 0;
    }
  act_entry = LookupIndexedTableEntry ("acts", act);
  numNPCs = GetEntryIntegerField (act_entry, "numNPCs");
  if ((unsigned) npc >= numNPCs)
    {
      errno = EINVAL;
      return 0;
    }
  npc_field[3] = (char) ('1' + npc);
  return GetEntryStringField (act_entry, npc_field);
}

/* Retrieve the number of possible states in a quest.  Quest states
   are a tricky thing, because often the data value stored for a quest
   can take on different meanings depending on other factors in the
   game, especially what quest items (if any) the character is
   carrying.  These functions will return all possible variants,
   because the distinction is up to the d2sData class. */
int
GetNumberOfStatesInQuest (int act, int quest)
{
  char make_name[8] = "a1q1";

  if (((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) quest > (unsigned) GetNumberOfQuestsInAct (act)))
    {
      errno = EINVAL;
      return -1;
    }

  make_name[1] = (char) ('1' + act);
  make_name[3] = (char) ('1' + quest);
  return GetEntryIntegerField (LookupTableEntry ("quests", "code", make_name),
			       "numStates");
}

/* Retrieve a short description of a quest state,
   or the quest log entry associated with it. */
const char *
GetQuestStateDesc (const char *state_name)
{
  table_entry_t entry;

  entry = LookupTableEntry ("queststates", "code", state_name);
  return GetEntryStringField (entry, "sName");
}

const char *
GetQuestLogEntry (const char *state_name)
{
  table_entry_t entry;
  const char *key, *log;

  entry = LookupTableEntry ("queststates", "code", state_name);

  /* The log entry needs to be looked up in the string tables. */
  key = GetEntryStringField (entry, "qsts");
  log = LookupStringByKey (key);
  if (log == NULL)
    log = GetEntryStringField (entry, "Description");
  return log;
}

/* Return a list of known data values for a quest.
   The list is dynamically allocated, so free() when done.
   The return value is the number of entries in *pvalues. */
int
GetQuestValues (int act, int quest, struct quest_value **pvalues)
{
  char quest_name[8] = "a1q1";
  char state_name[12];
  char item_name[12];
  int state, num_states, item;
  table_entry_t quest_entry, state_entry;
  const char *key, *cstr;
  struct quest_value *values;

  if (((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) quest > (unsigned) GetNumberOfQuestsInAct (act)))
    {
      errno = EINVAL;
      return -1;
    }

  quest_name[1] = (char) ('1' + act);
  quest_name[3] = (char) ('1' + quest);
  quest_entry = LookupTableEntry ("quests", "code", quest_name);
  /* Get the number of states to begin with */
  num_states = GetEntryIntegerField (quest_entry, "numStates");
  if (!num_states)
    {
      *pvalues = NULL;
      return 0;
    }
  /* With the number of states, we know exactly how much space to allocate. */
  values = (struct quest_value *)
    xmalloc (num_states * sizeof (struct quest_value));
  memset (values, 0, num_states * sizeof (struct quest_value));

  for (state = 0; state < num_states; state++)
    {
      sprintf (state_name, "state%d", state);
      state_entry = LookupTableEntry
	("queststates", "code",
	 GetEntryStringField (quest_entry, state_name));

      /* Just fill in the fields as we find them!
	 Remember that the data values and masks are stored in hex. */
      values[state].value = strtol
	(GetEntryStringField (state_entry, "hexValue"), NULL, 16);
      values[state].mask = strtol
	(GetEntryStringField (state_entry, "hexMask"), NULL, 16);
      values[state].dontcare = strtol
	(GetEntryStringField (state_entry, "dontcareMask"), NULL, 16);

      values[state].description = GetEntryStringField (state_entry, "sName");
      key = GetEntryStringField (state_entry, "qsts");
      cstr = LookupStringByKey (key);
      if (cstr == NULL)
	cstr = GetEntryStringField (state_entry, "Description");
      values[state].log_entry = cstr;

      /* Count the number of required or forbidden items as we look them up */
      strcpy (item_name, "reqItem1");
      for (item = 0; item < 4; item++)
	{
	  item_name[7] = (char) ('1' + item);
	  cstr = GetEntryStringField (state_entry, item_name);
	  if (cstr[0] == 0)
	    break;
	  values[state].needs_items++;
	  *((uint32_t *) &values[state].required_items[item][0])
	    = *((uint32_t *) cstr);
	}
      strcpy (item_name, "noItem1");
      for (item = 0; item < 4; item++)
	{
	  item_name[6] = (char) ('1' + item);
	  cstr = GetEntryStringField (state_entry, item_name);
	  if (cstr[0] == 0)
	    break;
	  values[state].forbid_items++;
	  *((uint32_t *) &values[state].forbidden_items[item][0])
	    = *((uint32_t *) cstr);
	}
    }

  /* Return the results */
  *pvalues = values;
  return num_states;
}

/* Return the character class that owns a parcitular skill */
int
CharacterClassOfSkill (int skill)
{
  table_entry_t skill_entry;
  const char *cstr;

  skill_entry = LookupNumericTableEntry ("skills", "Id", skill);
  if (skill_entry == NULL) {
    errno = EINVAL;
    return -1;
  }
  cstr = GetEntryStringField (skill_entry, "charclass");
  if (cstr[0] == 0) {
    /* Not a character-specific skill */
    errno = EINVAL;
    return -1;
  }
  /* Get the index number of the player class */
  return GetEntryIntegerField (LookupTableEntry ("playerclass", "Code", cstr),
			       NULL);
}

/* Vice-versa; return the first skill belonging to a character class */
int
FirstSkillOfClass (int char_class)
{
  table_entry_t class_entry;

  class_entry = LookupIndexedTableEntry ("playerclass", char_class);
  if (class_entry == NULL) {
    errno = EINVAL;
    return -1;
  }
  return GetEntryIntegerField (class_entry, "StartSkill");
}

/* Return the name of a given skill or action */
const char *
SkillName (int skill)
{
  const char *cstr;

  /* Ach!  The index in the string table for the skill is NOT made
     from the skill ID, but rather the row number of the skill's entry
     in the skill table!  (It's off by 1 because of the line
     "Expansion" between normal skills and expansion set skills.)
     What's more, the lookup doesn't even use a string key; it uses
     the string's ordinal number (i.e., an index number in the string
     table)!  I have no idea how those numbers are computed.
     It looks like the first skill name ("skillname0") is ordinal #4373.
     The first Expansion skill name ("skillname222") is ordinal #2038.
  */
  if (skill < 221)
    cstr = LookupStringByIndex ("string", 4373 + 4 * skill);
  else
    cstr = LookupStringByIndex ("expansionstring", 2038 + 4 * (skill - 221));
  if (cstr == NULL)
    {
      fprintf (stderr, "%s: Internal error: missing entry for skill #%d"
	       " in the string table\n", progname, skill);
      cstr = "";
    }
  return cstr;
}

/* Return the name of a skill set (0-2) for a given character class */
const char *
SkillSetName (int char_class, int skill_set)
{
  table_entry_t char_class_entry;
  char field_name[12] = "SkillSet1";

  if (((unsigned) char_class >= NUM_CHAR_CLASSES)
      || ((unsigned) skill_set >= NUM_SKILL_SETS)) {
    errno = EINVAL;
    return "";
  }
  char_class_entry = LookupIndexedTableEntry ("playerclass", char_class);
  field_name[8] = (char) ('1' + skill_set);
  return GetEntryStringField (char_class_entry, field_name);
}

/* Return the name of a skill set (0-2) for a given character class */
const char *
SkillSetNameWithLineBreaks (int char_class, int skill_set)
{
  table_entry_t char_class_entry;
  char field_name[12] = "SkillTab1";

  if (((unsigned) char_class >= NUM_CHAR_CLASSES)
      || ((unsigned) skill_set >= NUM_SKILL_SETS)) {
    errno = EINVAL;
    return "";
  }
  char_class_entry = LookupIndexedTableEntry ("playerclass", char_class);
  field_name[8] = (char) ('1' + skill_set);
  return GetEntryStringField (char_class_entry, field_name);
}

/* Build the skill dependency tree */
static void
build_skill_dependency_tree (void)
{
  table_entry_t skill_entry;
  int char_class, first_skill, skill, req_id;
  const char *req_skill;

  /* Get the highest skill number we have. */
  dependency_tree_size = (FirstSkillOfClass (NUM_CHAR_CLASSES - 1)
			  + NUM_SKILLS_PER_CHAR);
  /* Allocate the whole table */
  dependency_tree = (struct dependency_tree_t *)
    xmalloc (dependency_tree_size * sizeof (struct dependency_tree_t));
  /* Initialize all values to -1 */
  memset (dependency_tree, -1,
	  dependency_tree_size * sizeof (struct dependency_tree_t));

  for (char_class = 0; char_class < NUM_CHAR_CLASSES; char_class++) {
    /* Get the first skill belonging to this character class */
    first_skill = FirstSkillOfClass (char_class);
    for (skill = first_skill;
	 skill < first_skill + NUM_SKILLS_PER_CHAR; skill++) {
      /* Get the table entry for the next skill */
      skill_entry = LookupNumericTableEntry ("skills", "Id", skill);
      /* Does this skill have a prerequisite? */
      req_skill = GetEntryStringField (skill_entry, "reqskill1");
      if (req_skill[0] == 0)
	continue;
      req_id = GetEntryIntegerField
	(LookupTableEntry ("skills", "skill", req_skill), "Id");
      if ( ! req_id) {
	fprintf (stderr, "%s: Internal error in skills table: skill %d has\n"
		 " a dependent \"%s\" which is not found in the table.\n",
		 progname, skill, req_skill);
	continue;
      }
      if ((req_id < first_skill)
	  || (req_id >= first_skill + NUM_SKILLS_PER_CHAR)) {
	fprintf (stderr, "%s: Internal error in skills table: skill %d has\n"
		 " dependent %d which does not belong to the same class.\n",
		 progname, skill, req_id);
	continue;
      }
      /* Record the required skill's ID as this skill's prerequisite,
	 and this skill's ID as the required skill's dependent. */
      dependency_tree[skill].requires[0] = req_id;
      if (dependency_tree[req_id].dependent[0] < 0)
	dependency_tree[req_id].dependent[0] = skill;
      else
	dependency_tree[req_id].dependent[1] = skill;

      /* Does this skill have a second prerequisite? */
      req_skill = GetEntryStringField (skill_entry, "reqskill2");
      if (req_skill[0] == 0)
	continue;
      req_id = GetEntryIntegerField
	(LookupTableEntry ("skills", "skill", req_skill), "Id");
      if ( ! req_id) {
	fprintf (stderr, "%s: Internal error in skills table: skill %d\n has"
		 " a 2nd dependent \"%s\" which is not found in the table.\n",
		 progname, skill, req_skill);
	continue;
      }
      if ((req_id < first_skill)
	  || (req_id >= first_skill + NUM_SKILLS_PER_CHAR)) {
	fprintf (stderr, "%s: Internal error in skills table: skill %d has\n"
		" 2nd dependent %d which does not belong to the same class.\n",
		 progname, skill, req_id);
	continue;
      }
      /* Record the required skill's ID as this skill's prerequisite,
	 and this skill's ID as the required skill's dependent. */
      dependency_tree[skill].requires[1] = req_id;
      if (dependency_tree[req_id].dependent[0] < 0)
	dependency_tree[req_id].dependent[0] = skill;
      else
	dependency_tree[req_id].dependent[1] = skill;
    }
  }
}

/* A skill may depend on up to 2 others and have up to 2 dependents;
   all dependencies are in the same set.  These functions return -1
   if the skill has no dependency/dependent. */
int
SkillDependency (int skill)
{
  if (!dependency_tree_size)
    build_skill_dependency_tree ();

  if ((unsigned) skill >= (unsigned) dependency_tree_size) {
    errno = EINVAL;
    return -1;
  }
  return dependency_tree[skill].requires[0];
}

int
SkillDependency2 (int skill)
{
  if (!dependency_tree_size)
    build_skill_dependency_tree ();

  if ((unsigned) skill >= (unsigned) dependency_tree_size) {
    errno = EINVAL;
    return -1;
  }
  return dependency_tree[skill].requires[1];
}

int
SkillDependent (int skill)
{
  if (!dependency_tree_size)
    build_skill_dependency_tree ();

  if ((unsigned) skill >= (unsigned) dependency_tree_size) {
    errno = EINVAL;
    return -1;
  }
  return dependency_tree[skill].dependent[0];
}

int
SkillDependent2 (int skill)
{
  if (!dependency_tree_size)
    build_skill_dependency_tree ();

  if ((unsigned) skill >= (unsigned) dependency_tree_size) {
    errno = EINVAL;
    return -1;
  }
  return dependency_tree[skill].dependent[1];
}

/* This function is called recursively as needed
   to match a type against any superset of the type */
int
IsTypeAMemberOf (const char *item_type, const char *compare_type)
{
  table_entry_t ent_type;

  if (item_type[0] == '\0')
    /* This happens when there is no equivalent for an item */
    return 0;
  if (strcasecmp (item_type, compare_type) == 0)
    /* Exact match */
    return 1;

  /* Recursively find whether one of the type's equivalents
     matches the requested type. */
  ent_type = LookupTableEntry ("itemtypes", "Code", item_type);
  return (IsTypeAMemberOf (GetEntryStringField (ent_type, "Equiv1"),
			   compare_type)
	  || IsTypeAMemberOf (GetEntryStringField (ent_type, "Equiv2"),
			      compare_type));
}

/* Compare an item's type to a magic name's list
   of acceptable types and return whether a match is found. */
static int
match_item_to_name_types (const char *item_type, table_entry_t name_entry,
			  int expansion)
{
  char field_name[8] = "itype1";
  const char *match_str, *cstr;
  int k;

  /* First, check for class-specific names vs. class-specific items */
  match_str = GetEntryStringField (name_entry, "classspecific");
  if (match_str[0])
    {
      cstr = GetEntryStringField
	(LookupTableEntry ("itemtypes", "Code", item_type), "Class");
      if (cstr[0] && (strcmp (cstr, match_str) != 0))
	/* Character class doesn't match */
	return 0;
    }

  /* Search for a standard match. */
  for (k = '1'; k <= '9'; k++)
    {
      field_name[5] = (char) k;
      match_str = GetEntryStringField (name_entry, field_name);
      if (match_str[0] == 0)
	break;
      if (IsTypeAMemberOf (item_type, match_str))
	return 1;
    }

  /* Allow the name if there were no types to match */
  if ((k == '1')
      && (!expansion
	  || (GetEntryStringField (name_entry, "eitem1")[0] == 0))
      && GetEntryStringField (name_entry, "mod1code")[0])
    return 1;

  /* Next, (conditionally) search for a match for the Expansion Set. */
  if (!expansion)
    return 0;
  field_name[0] = 'e';
  for (k = '1'; k <= '9'; k++)
    {
      field_name[5] = (char) k;
      match_str = GetEntryStringField (name_entry, field_name);
      if (match_str[0] == 0)
	break;
      if (IsTypeAMemberOf (item_type, match_str))
	return 1;
    }

  /* No match */
  return 0;
}

/* Return a specific magic prefix or suffix by ID */
const char *
GetMagicPrefix (int prefix)
{
  table_entry_t ent_fix;
  const char *pstr;

  if (!prefix)
    return NULL;

  ent_fix = LookupIndexedTableEntry ("magicprefix", prefix);
  if (ent_fix != NULL)
    {
      pstr = GetEntryStringField (ent_fix, "Name");
      if (pstr[0])
	return TranslateString (pstr);
    }
  return "(unknown)";
}

const char *
GetMagicSuffix (int suffix)
{
  table_entry_t ent_fix;
  const char *sstr;

  if (!suffix)
    return NULL;

  ent_fix = LookupIndexedTableEntry ("magicsuffix", suffix);
  if (ent_fix != NULL)
    {
      sstr = GetEntryStringField (ent_fix, "Name");
      if (sstr[0])
	return TranslateString (sstr);
    }
  return "(unknown)";
}

/* Return a dynamic list of strings for prefixes or suffixes.
   This is the function that does all the work
   for the global functions following. */
static StringList
get_magic_names (const char *table_name, const char *item_type,
		 int expansion, int rare, int level,
		 int exclude1, int exclude2)
{
  StringList	string_list;
  int		i, group, version, max_level, table_size;
  table_entry_t name_entry;

  /* Start by allocating the string list as big as it could possibly be. */
  table_size = GetTableSize (table_name);
  string_list = (StringList) xmalloc
    (sizeof (_StringList) + (table_size * sizeof (_StringListEntry)));

  /* The first entry in a list is the empty string, with an ID of 0 */
  string_list->string[0].value = 0;
  string_list->string[0].label = "";
  string_list->count = 1;

  /* Go through each entry in the table */
  for (i = 1; i < table_size; i++)
    {
      name_entry = LookupIndexedTableEntry (table_name, i);
      /* Check for blank entries */
      group = GetEntryIntegerField (name_entry, "group");
      if (!group)
	continue;

      /* Check for expansion set entries */
      version = GetEntryIntegerField (name_entry, "version");
      if (!version || (!expansion && (version >= 100)))
	continue;

      /* Are we restricting the list to rare names? */
      if (rare && !GetEntryIntegerField (name_entry, "rare"))
	continue;

      /* Are we restricting the list by item level? */
      if (level) {
	if (level < GetEntryIntegerField (name_entry, "level"))
	  continue;
	max_level = GetEntryIntegerField (name_entry, "maxlevel");
	if (max_level && (level > max_level))
	  continue;
      }

      /* Are we excluding certain groups? */
      if ((group == exclude1) || (group == exclude2))
	continue;

      if (item_type != NULL) {
	/* Check the list of approved items for a match. */
	if ( ! match_item_to_name_types (item_type, name_entry, expansion))
	  continue;
      }

      /* The name is accepted!  Add it to the string list. */
      string_list->string[string_list->count].value = i;
      string_list->string[string_list->count].label
	= TranslateString (GetEntryStringField (name_entry, "Name"));
      string_list->count++;
    }

  /* Trim down the allocation */
  string_list = (StringList) xrealloc
    (string_list, sizeof (_StringList) + (string_list->count
					  * sizeof (_StringListEntry)));
  return string_list;
}

/* Return a dynamic list of strings for all of the magic prefixes. */
StringList
GetMagicPrefixes (void)
{
  /* We simply call the extended version with a NULL item type */
  return get_magic_names ("magicprefix", NULL, True, True, 0, 0, 0);
}

/* Return a dynamic list of strings for all of the magic suffixes. */
StringList
GetMagicSuffixes (void)
{
  /* We simply call the extended version with a NULL item type */
  return get_magic_names ("magicsuffix", NULL, True, True, 0, 0, 0);
}

/* Return a restricted list of magic prefixes
   that can be applied to a given item type. */
StringList
GetMagicPrefixesFor (const char *item_type, int expansion, int rare,
		     int level, int exclude1, int exclude2)
{
  /* We simply call the extended version */
  return get_magic_names
    ("magicprefix", item_type, expansion, rare, level, exclude1, exclude2);
}

/* Return a restricted list of magic suffixes
   that can be applied to a given item type. */
StringList
GetMagicSuffixesFor (const char *item_type, int expansion, int rare,
		     int level, int exclude1, int exclude2)
{
  /* We simply call the extended version */
  return get_magic_names
    ("magicsuffix", item_type, expansion, rare, level, exclude1, exclude2);
}

/* Get a specific rate name by ID (same function for both parts) */
const char *
GetRareTitleWord (int id)
{
  table_entry_t ent_rare;
  int num_prefixes, num_suffixes;
  const char *cstr;

  /* Although rare prefixes and rare suffixes are in separate tables,
     the appear to be combined to get the index numbers --
     the first prefix ID is the number following the last suffix.
     Also, the first suffix with an index of 0 has an ID of 1. */
  num_prefixes = GetTableSize ("rareprefix");
  num_suffixes = GetTableSize ("raresuffix");
  if (id == 0)
    return NULL;
  if (id <= num_suffixes)
    ent_rare = LookupIndexedTableEntry ("raresuffix", id - 1);
  else
    ent_rare = LookupIndexedTableEntry ("rareprefix", id - 1 - num_suffixes);
  cstr = GetEntryStringField (ent_rare, "name");
  if (cstr[0])
    cstr = TranslateString (cstr);
  else
    cstr = "(unknown rare name)";
  return cstr;
}

/* Return a dynamic list of strings for rare names.
   This is the function that does all the work
   for the global functions following. */
static StringList
get_rare_names (const char *table_name, int id_bias, const char *item_type)
{
  StringList string_list;
  int i, table_size;
  table_entry_t name_entry;

  /* Start by allocating the string list as big as it could possibly be. */
  table_size = GetTableSize (table_name);
  string_list = (StringList) xmalloc
    (sizeof (_StringList) + ((table_size + 1)
			     * sizeof (_StringListEntry)));
  string_list->count = 0;

  if (item_type == NULL)
    {
      /* The first entry in a list is the empty string, with an ID of 0 */
      string_list->string[0].value = 0;
      string_list->string[0].label = "";
      string_list->count++;
    }

  /* Go through each entry in the table */
  for (i = 0; i < table_size; i++)
    {
      name_entry = LookupIndexedTableEntry (table_name, i);
      /* Check for blank entries */
      if (GetEntryStringField (name_entry, "version")[0] == 0)
	continue;

      if (item_type != NULL) {
	/* Check the list of approved items for a match. */
	if ( ! match_item_to_name_types (item_type, name_entry, True))
	  continue;
      }

      /* The name is accepted!  Add it to the string list. */
      string_list->string[string_list->count].value = id_bias + i;
      string_list->string[string_list->count].label
	= TranslateString (GetEntryStringField (name_entry, "name"));
      string_list->count++;
    }

  /* Trim down the allocation */
  string_list = (StringList) xrealloc
    (string_list, sizeof (_StringList) + (string_list->count
					  * sizeof (_StringListEntry)));
  return string_list;
}

/* Return a dynamic list of strings for all of the rare titles. */
StringList
GetRareTitle1stWords (void)
{
  int bias;

  /* The ID's for the first rare word are biased from the index
     into the table by the size of the second rare word table. */
  bias = GetTableSize ("raresuffix");
  /* We simply call the extended version with a NULL item type */
  return get_rare_names ("rareprefix", bias + 1, NULL);
}

StringList GetRareTitle2ndWords (void)
{
  /* We simply call the extended version with a NULL item type */
  return get_rare_names ("raresuffix", 1, NULL);
}

/* Return a restricted list of rare titles
   that can be applied to a given item type. */
StringList
GetRareTitle1stWordsFor (const char *item_type)
{
  int bias;

  /* The ID's for the first rare word are biased from the index
     into the table by the size of the second rare word table. */
  bias = GetTableSize ("raresuffix");
  /* We simply call the extended version */
  return get_rare_names ("rareprefix", bias + 1, item_type);
}

StringList
GetRareTitle2ndWordsFor (const char *item_type)
{
  /* We simply call the extended version */
  return get_rare_names ("raresuffix", 1, item_type);
}

/* Sort StringList entries by string first */
static int
sort_StringListEntries (const void *p1, const void *p2)
{
  const _StringListEntry *ent1 = (const _StringListEntry *) p1;
  const _StringListEntry *ent2 = (const _StringListEntry *) p2;
  int d;

  d = strcmp (ent1->label, ent2->label);
  if (d)
    return d;
  else
    return (ent1->value - ent2->value);
}

/* Compare a string to a StringList entry */
static int
compare_to_StringListEntry (const void *p1, const void *p2)
{
  const char *str = (const char *) p1;
  const _StringListEntry *ent = (const _StringListEntry *) p2;

  return strcmp (str, ent->label);
}

/* Create a complete (sorted) list of set items, sorted by item code */
static StringList
generate_set_item_list (void)
{
  StringList	set_items;
  table_entry_t set_entry;
  int		set_num;
  char		make_name[8] = "Item1", member_num;
  const char *	item_code;

  set_items = (StringList) xmalloc
    (sizeof (_StringList)
     + GetTableSize ("setitems") * 6 * sizeof (_StringListEntry));
  set_items->count = 0;
  for (set_num = 0; ; set_num++)
    {
      set_entry = LookupIndexedTableEntry
	/* The set items table has an extra line between standard game sets
	   and Expansion sets which is not counted in the ID!  HACK: */
	("setitems", (set_num < 16) ? set_num : (set_num + 1));
      if (set_entry == NULL)
	break;
      for (member_num = '1'; member_num <= '6'; member_num++)
	{
	  make_name[4] = member_num;
	  item_code = GetEntryStringField (set_entry, make_name);
	  if (item_code[0] == 0)
	    break;
	  set_items->string[set_items->count].label = item_code;
	  /* We make room for not only the set number,
	     but the member index as well. */
	  set_items->string[set_items->count].value
	    = (set_num << 3) + ((member_num - '1') & 7);
	  set_items->count++;
	}
    }

  /* Trim the unused space */
  set_items = (StringList) xrealloc
    (set_items, (sizeof (_StringList)
		 + set_items->count * sizeof (_StringListEntry)));

  /* Sort the list by item code */
  qsort (&set_items->string[0], set_items->count,
	 sizeof (_StringListEntry), sort_StringListEntries);
  return set_items;
}

/* Return a dynamic list of sets that contain an item of the given type. */
StringList
GetSetsContainingItem (const char *code, int expansion, int level)
{
  static StringList all_set_items = NULL;
  StringList	set_list;
  _StringListEntry *ent;
  int		i, first, last, set_id;
  table_entry_t set_entry;

  if (all_set_items == NULL)
    /* First time through; create a sorted list of set items */
    all_set_items = generate_set_item_list ();

  /* Find *a* matching set item in the list.
     May or may not be the first. */
  ent = bsearch (code, &all_set_items->string[0], all_set_items->count,
		 sizeof (_StringListEntry), compare_to_StringListEntry);
  if (ent == NULL)
    /* No sets contain this type of item! */
    return NULL;

  /* Get the index of this item in the list */
  first = ent - &all_set_items->string[0];
  last = first;

  /* Look backward to find the first matching item */
  while (first > 0)
    {
      if (strcmp (all_set_items->string[first - 1].label, ent->label) == 0)
	first--;
      else
	break;
    }

  /* Look forward to find the last matching item */
  while (last < all_set_items->count - 1)
    {
      if (strcmp (all_set_items->string[last + 1].label, ent->label) == 0)
	last++;
      else
	break;
    }

  /* Create a list of matching items */
  set_list = (StringList) xmalloc
    (sizeof (_StringList) + (last + 1 - first) * sizeof (_StringListEntry));
  set_list->count = 0;

  /* Add to the list only those items matching the given criteria */
  for (i = first; i <= last; i++)
    {
      set_id = all_set_items->string[i].value >> 3;
      set_entry = LookupIndexedTableEntry
	("setitems", (set_id < 16) ? set_id : (set_id + 1));
      if (!expansion
	  && (GetEntryIntegerField (set_entry, "version") >= 100))
	continue;
      if (level && (level < GetEntryIntegerField (set_entry, "level")))
	  continue;
      set_list->string[set_list->count].value = all_set_items->string[i].value;
      /* The text field for the returned list is the name of the set */
      set_list->string[set_list->count].label
	= TranslateString (GetEntryStringField (set_entry, "Name"));
      set_list->count++;
    }

  if (set_list->count == 0)
    {
      /* All matching set items are masked out! */
      free (set_list);
      return NULL;
    }
  return set_list;
}

/* Create a complete (sorted) list of unique items, sorted by item code */
static StringList
generate_unique_item_list (void)
{
  StringList	unique_items;
  table_entry_t unique_entry;
  int		unique_num;

  unique_items = (StringList) xmalloc
    (sizeof (_StringList)
     + GetTableSize ("uniqueitems") * sizeof (_StringListEntry));
  unique_items->count = 0;
  for (unique_num = 0; ; unique_num++)
    {
      unique_entry = LookupIndexedTableEntry ("uniqueitems", unique_num);
      if (unique_entry == NULL)
	break;
      unique_items->string[unique_items->count].label
	= GetEntryStringField (unique_entry, "code");
      if (unique_items->string[unique_items->count].label[0] == 0)
	continue;
      unique_items->string[unique_items->count].value = unique_num;
      unique_items->count++;
    }

  /* Trim the unused space */
  unique_items = (StringList) xrealloc
    (unique_items, (sizeof (_StringList)
		 + unique_items->count * sizeof (_StringListEntry)));

  /* Sort the list by item code */
  qsort (&unique_items->string[0], unique_items->count,
	 sizeof (_StringListEntry), sort_StringListEntries);
  return unique_items;
}

/* Return a dynamic list of unique items that match the given type. */
StringList
GetUniqueItemsMatching (const char *code, int expansion, int level)
{
  static StringList all_unique_items = NULL;
  StringList	unique_list;
  _StringListEntry *ent;
  int		i, first, last;
  table_entry_t unique_entry;

  if (all_unique_items == NULL)
    /* First time through; create a sorted list of unique items */
    all_unique_items = generate_unique_item_list ();

  /* Find *a* matching unique item in the list.
     May or may not be the first. */
  ent = bsearch (code, &all_unique_items->string[0], all_unique_items->count,
		 sizeof (_StringListEntry), compare_to_StringListEntry);
  if (ent == NULL)
    /* No matching unique items! */
    return NULL;

  /* Get the index of this item in the list */
  first = ent - &all_unique_items->string[0];
  last = first;

  /* Look backward to find the first matching item */
  while (first > 0)
    {
      if (strcmp (all_unique_items->string[first - 1].label, ent->label) == 0)
	first--;
      else
	break;
    }

  /* Look forward to find the last matching item */
  while (last < all_unique_items->count - 1)
    {
      if (strcmp (all_unique_items->string[last + 1].label, ent->label) == 0)
	last++;
      else
	break;
    }

  /* Create a list of matching items */
  unique_list = (StringList) xmalloc
    (sizeof (_StringList) + (last + 1 - first) * sizeof (_StringListEntry));
  unique_list->count = 0;

  /* Add to the list only those items matching the given criteria */
  for (i = first; i <= last; i++)
    {
      unique_entry = LookupIndexedTableEntry
	("uniqueitems", all_unique_items->string[i].value);
      if (!expansion
	  && (GetEntryIntegerField (unique_entry, "version") >= 100))
	continue;
      if (level && (level < GetEntryIntegerField (unique_entry, "Level")))
	continue;
      unique_list->string[unique_list->count].value
	= all_unique_items->string[i].value;
      /* The text field for the returned list is the name of the unique item */
      unique_list->string[unique_list->count].label
	= TranslateString (GetEntryStringField (unique_entry, "name"));
      unique_list->count++;
    }

  if (unique_list->count == 0)
    {
      /* All matching set items are masked out! */
      free (unique_list);
      return NULL;
    }
  return unique_list;
}

/* Return the name of a time of day matching a given code */
const char *
TimeName (int time_code)
{
  const char *cstr;
  static const char * const modstre9[4] = {
    "ModStre9e", "ModStre9g", "ModStre9d", "ModStre9f" };

  cstr = LookupStringByKey (modstre9[time_code % 4]);
  if (cstr == NULL)
    {
      fprintf (stderr, "%s: Internal error: missing entry for time %s"
	       " in the string table\n", progname, modstre9[time_code % 4]);
      cstr = "";
    }
  return cstr;
}
