/* Data pertaining to items in Diablo II saved games (outdated)
 * Copyright (C) 2001 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

struct item_list_header {
  char		magic[2];	/* "JM" */
  unsigned char item_count;	/* does not count items inside
				   the sockets of other items */
  unsigned char filler;		/* 0? */
};

struct item_data {
  char		magic[2];	/* "JM"? */
#define ITEM_MAGIC (*((unsigned short *) &"JM"))
  /* Note: little bit-endian (lowest ordered bits allocated first) */
  unsigned short unknown2:4;
  unsigned short identified:1;
  unsigned short unknown2_5:6;
  unsigned short socketed:1;
  unsigned short unknown3_4:1;
  unsigned short unknown3_5:1;	/* This value changes from 1 to 0 for items
				 * after going into the game and exiting
				 * without doing anything else. "new" bit? */
  unsigned short unknown3_6:2;
  unsigned short is_ear:1;	/* unconfirmed; this will be 0 */
  unsigned short newbie:1;	/* if set, item has sell value of 1, and repair cost of 1.  Used for items a player begins with.  Confirmed. */
  unsigned short unknown4_2:3;
  unsigned short simple:1;	/* Item is only 14 bytes long */
  unsigned short ethereal:1;
  unsigned short unknown4_7:1;
  unsigned short personalized:1;
  unsigned short unknown5_1:1;
  unsigned short runeworded:1;
  unsigned short unknown5_3:5;
  unsigned short unknown6:10;
  unsigned short location:3;
  unsigned short equipped_slot:4;	/* i.e., head, finger, feet, etc. */
  unsigned short column:4;
  unsigned short row:3;
  unsigned short unknown9:1;
  unsigned short stored_location:3;
  unsigned short type:8;	/* bit 5 is always set, 7 is always clear */
  unsigned short subtype:8;	/* ditto */
  unsigned short variant:8;	/* likewise */
  unsigned short unknownc_4:8;	/* 0x20 */
  unsigned short gem_count:3;	/* number of sockets filled (for armor, not gems) */
  unsigned short unique_id0:1;	/* Appears to be part of a unique id. */
  unsigned long unique_id:31;	/* In multiple copies of the Horadric Staff,
				   all but 2 of these 32 bits changed. */
  unsigned long unknown11_7:7;
  unsigned long attribute:4;	/* 1 = crude, 2 = normal, 3 = superior,
				   4 = magic, 5 = set, 6 = rare, 7 = unique,
				   8 = crafted (thanks, Guillaume) */
  unsigned long is_ring:1;	/* this seems to be set for rings, amulets,
				   jewels, and charms. */
  unsigned long var_data:5;	/* fields from this point may or may not
				   be present, and vary in bit length */
} __attribute__ ((packed));

/* The following structure is verified by empirical evidence */
struct gem_data {
  char		magic[2];	/* "JM" */
  unsigned short unknown2:4;
  unsigned short identified:1;
  unsigned short unknown2_5:6;
  unsigned short socketed:1;	/* highly likely */
  unsigned short unknown3_4:4;
  unsigned short unknown4:6;
  unsigned short ethereal:1;	/* not sure */
  unsigned short unknown4_7:9;
  unsigned short unknown6:10;
  unsigned short location:3;
  unsigned short equipped_slot:4;	/* i.e., head, finger, feet, etc. */
  unsigned short column:4;	/* confirmed! (only 2 bits for belt) */
  unsigned short row:3; 	/* confirmed! */
  unsigned short unknown9:1;
  unsigned short stored_location:3;
  unsigned short item_type1:5;	/* 7 for gems, 19 for skulls */
  unsigned short unknowna_1:3;	/* 3 */
  unsigned short quality:5;	/* 3 = chipped, 6 = flawed, 19 = normal,
				 * 16 maybe= perfect,
				 * 12(r) or 26(a) = flawless;
				 * but skulls follow different patterns */
  unsigned short unknownb_1:3;	/* 3 */
  unsigned short gem_type:5;	/* 2 = sapphire, 7 = emerald, 18 = ruby,
				 * 22 = amethyst, 23 = diamond, 25 = topaz */
  unsigned short unknownc_1:3;	/* 3, but sometimes 1 */
  unsigned short unknownc_4:8;	/* 0x20 */
  unsigned short gem_count:3;	/* number of sockets filled (for armor, not gems) */
  unsigned short unknownd_7:1;
} __attribute__ ((packed));

/* Function declarations */
void dump_raw_data (unsigned char *, int length);
void dump_bit_data (unsigned char *, int start, int nbits);
unsigned char *dump_item_data (unsigned char *, int length);
void dump_magic_data (unsigned char *, int start, int length);
int dump_magic_prefix (const char *, unsigned char *, int length);
void dump_ring_data (const char *, unsigned char *, int length);
