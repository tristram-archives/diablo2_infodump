/* d2sStackItem -- C++ class that holds an internal representation
 *		   of a Diablo II v1.09 stack of items;
 *		   also a base class for quivers and stacked weapons.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sMagic.h"
#include "d2sQuality.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Create a new, blank stack (to be filled in later) */
d2sStackItem::d2sStackItem (void)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (), d2sExtendedItem ()
{
  /* Override the default item class */
  item_class = STACK_ITEM;
  nvop = this;
  quantity = 1;
  min_quantity = 1;
  max_quantity = 1;
  tome = 0;
  tome_value = 0;
}

/* Create a new, specific stack as described by the item table entry
   (using default variable attributes) */
d2sStackItem::d2sStackItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (tent), d2sExtendedItem (tent)
{
  /* Override the default item class */
  item_class = STACK_ITEM;
  /* Change the nvop (very important) */
  nvop = this;

  /* Read the quantity from the item table */
  quantity = GetEntryIntegerField (tent, "spawnstack");
  min_quantity = GetEntryIntegerField (tent, "minstack");
  max_quantity = GetEntryIntegerField (tent, "maxstack");
  if (!quantity || !max_quantity)
    {
      fprintf (stderr, "%s: Error in item table: stack item %s is missing"
	       " a stack size\n", progname, base_name);
      if (!max_quantity)
	max_quantity = 1;
      quantity = max_quantity;
    }
  tome = this->is_of_type ("book");
  tome_value = 0;
}

/* Copy an existing stack */
d2sStackItem::d2sStackItem (const d2sStackItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (source), d2sExtendedItem (source)
{
  /* Change the nvop (very important) */
  nvop = this;

  /* Now copy our own fields */
  this->quantity = source.quantity;
  this->min_quantity = source.min_quantity;
  this->max_quantity = source.max_quantity;
  this->tome = source.tome;
  this->tome_value = source.tome_value;
}

/* Copy a template stack, and fill in the rest of the data
   using data from an item file or character file. */
d2sItem *
d2sStackItem::Copy (void) const
{
  d2sStackItem *new_item = new d2sStackItem (*this);
  return (d2sItem *) new_item;
}

/* Stacks add their quantity and magic properties to the descrption. */
char *
d2sStackItem::FullDescription (void) const
{
  char *descr;
  const char *cstr;
  int len;

  /* Start with the item's full name */
  descr = FullName();
  len = strlen (descr);

  /* Add the quantity */
  cstr = LookupStringByKey ("ItemStats1i");
  if (cstr == NULL)
    cstr = "Quantity:";
  descr = (char *) xrealloc (descr, len + 1 + strlen (cstr)
			     + sizeof (" %3d") + 1);
  len += sprintf (&descr[len], "\n%s %d", cstr, quantity);

  /* Finish up */
  return FinishFullDescription (descr);
}

int
d2sStackItem::MaxQuantity (void) const
{
  int limit = max_quantity;
  d2sMagic *comb;
  d2sMagicProperty *property;

  comb = CombinedProperties();
  property = comb->Lookup ("stack");
  if (property != NULL)
    limit += property->FieldData(0) - property->Bias();
  delete comb;

  return limit;
}

int
d2sStackItem::SetQuantity (int new_quantity)
{
  if (quantity == new_quantity)
    /* Nothing is being changed */
    return 0;

  /* Test for editing options first */
  if (read_only() || !options.item.edit.quantity)
    {
      print_message ("You may not change the quantity of %s\n", base_name);
      error_str = "Quantity may not be altered";
      return -1;
    }

  /* Check the range. */
  if ((new_quantity < min_quantity) || (new_quantity > MaxQuantity()))
    {
      if (!options.item.link.quantity_max
	  || ((new_quantity < 0) || (new_quantity > 0x1ff)))
      print_message ("Quantity %d is out of range for %s;"
		     " must be between %d and %d\n",
		     new_quantity, base_name, min_quantity, MaxQuantity());
      error_str = "Quantity out of range";
      return -1;
    }

  quantity = new_quantity;
  MarkDirty ();
  return 0;
}

/* Read class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after reading the quality fields
   and before reading the magic properties. */
int
d2sStackItem::ReadItemSpecificData (struct bit_stream *bstream)
{
  /* If this item is a tome, read the tome's extra 5-bit field. */
  if (tome)
    tome_value = bstream_read_field (bstream, 5);

  /* Read the current quantity */
  quantity = bstream_read_field (bstream, 9);
  return 0;
}

/* Write class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after writing the quality fields
   and before writing the magic properties. */
int
d2sStackItem::WriteItemSpecificData (struct bit_stream *bstream)
{
  /* If this item is a tome, write the tome's extra 5-bit field. */
  if (tome)
    bstream_write_field (bstream, 5, tome_value);

  /* Write the current quantity */
  bstream_write_field (bstream, 9, quantity);
  return 0;
}
