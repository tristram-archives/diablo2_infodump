/* Templates for new characters
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "define.h"
#include "internal.h"

/* This is the "<character>.key" file.
   It contains the (user definable) hotkey assignments used in the game.
   It is character class-independent, though certain assignments are
   only available to Expansion characters. */
const struct {
  /* char	magic[2];	Exists only in the default.key file; = "WS" */
  signed short	unknown00;	/* 37 */
  /* signed short file_length;	Exists only in the default.key file; = 1146 */
  struct {
    long	function;	/* index number? */
    short	key_or_button;
    long	assignment;	/* Looks like 1 if the key code is assigned,
				   0 if not ... so far... */
    long	function2;	/* index number? */
    short	key_or_button2;
    long	assignment2;	/* 1 if assigned? */
  } assignments[57];
  /* Hotkey assignments appear to be as follows:

     00 - Character Screen
     01 - Inventory Screen (it looks like this has key one / key two reversed)
     02 - Party Screen
     03 - Message Log
     04 - Quest Log
     05 - Chat (?"N")
     06 - Help Screen (?"5")
     07 - Automap (?"T")
     08 - Center Automap (?"U")
     09 - Fade Automap (?"V")
     10 - Party on Automap (?"W")
     11 - Names on Automap (?"X")
     12 - Skill Tree (?"6")
     13 - Skill Speed Bar (?"7")
     14 - Skill 1 (?"8")
     15 - Skill 2 (?"9")
     16 - Skill 3 (?"A")
     17 - Skill 4 (?"B")
     18 - Skill 5 (?"C")
     19 - Skill 6 (?"D")
     20 - Skill 7 (?"E")
     (index 21 is out of order?)
     22 - Show Belt (?"I")
     23 - Use Belt 1 (?"J")
     24 - Use Belt 2 (?"K")
     25 - Use Belt 3 (?"L")
     26 - Use Belt 4 (?"M")
     27 - Say 'Help' (?"Y")
     28 - Say 'Follow Me' (?"Z")
     29 - Say "This is for you'
     30 - Say 'Thanks'
     31 - Say 'Sorry'
     32 - Say 'Bye'
     33 - Say 'Now you die'
     34 - Run (?"O")
     35 - Toggle Run/Walk (?"P")
     36 - Stand Still (?"Q")
     37 - Show Items (?"R")
     38 - Clear Screen
     39 - Select Previous Skill (?"G")
     40 - Select Next Skill (?"H")
     41 - Clear Messages
     42 - Screen Shot
     43 - Show Portraits (?"S")
     44 - None (Swap Weapons?  Exp. only)
     45 - Toggle MiniMap (Exp. only)
     21 - Skill 8 (?"F")
     46 - None
     47 - None
     48 - None
     49 - None
     50 - None
     51 - None
     52 - None
     53 - None (Skill 16?  Exp. only)
     54 - Hireling Screen (Exp. only)
     55 - Say 'Retreat'
     56 - Option Menu (<Esc>)

     Key codes appear to be ASCII values for 0-9 and A-Z.
     Other codes are:

     0x09 - (wasn't assigned in Barb.) <Tab>?
     0x10 - <Shift>
     0x11 - <Ctrl>
     0x12 - <Alt>
     0x14 - <Caps Lock>
     0x1b - <Esc>
     '!' - <Page Up>
     '"' - <Page Down>
     '#' - (wasn't assigned in Barb.) <End>?
     '$' - <Home>
     '-' - <Insert>
     '.' - <Delete>
     '`' - [Num Pad] 0
     'a'-'i' - [Num Pad] 1-9
     'j' - [Num Pad] *
     'k' - [Num Pad] +
     'm' - [Num Pad] -
     'o' - [Num Pad] /
     'p'-'z' - <F1>-<F11>
     '{' - <F12>
     0xba - (wasn't assigned in Barb.) (ID 52 in Druid - ";"?)
     0xbb - (wasn't assigned in Barb.) (ID 50 in Druid - "="?)
     0xbc - (wasn't assigned in Barb.) (ID 47 in Druid - ","?)
     0xbd - (wasn't assigned in Barb.) (ID 51 in Druid - "-"?)
     0xbe - (wasn't assigned in Barb.) (ID 48 in Druid - "."?)
     0xbf - (wasn't assigned in Barb.) (ID 49 in Druid - "/"?)
     0xc0 - "~"?
     0xdb - "["?
     0xdc - "\"?
     0xdd - "]"?
     0xde - (wasn't assigned in Barb.) ("'"?)
     0x100 - Mouse 3
   */
} template_key = {
};

/* NOTES on character (.d2s) files:

   So far, it looks like the only significant differences between
   new games for the various character classes are the following
   (including the obvious differences):

   File length, checksum, and timestamp
   Character name (player-defined, up to 15 chars. (within rules) + nul byte)
   Character status (Assassin and Druid *require* the Expansion Set bit)
   Character class
   Right button action @ 0x7c (Necromancer is set to Raise Skeleton)
   unknown byte 0x8d
   unknown longword @ 0xab
   Character statistics (strength, energy, dexterity, vitality;
			 current/base life, mana, stamina)
   Items initially equipped (all have 1 t.p. scroll, 1 ident. scroll, and
			     4 minor healing potions (in belt); but each
			     character's weapon is different, and some
			     carry a buckler)
 */
const struct d2s_header template_d2s_header = {
  0xaa55aa55 /* Magic file header */, 92 /* Diablo II v1.09 */,
  0 /* length -- to be filled in */, 0 /* checksum -- to be filled in */,
  0, "", 0 /* must be 0x20 for Assassin and Druid */, 0, { 0, 0 },
  0 /* character class -- to be filled in */, { 16, 30 }, 1 /* level */,
  0, 0 /* timestamp -- to be filled in */,
  { 0xffff, 0xffff, 0xffff, 0, 0xffff, 0,
    0xffff, 0, 0xffff, 0, 0xffff, 0, 0xffff, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0xffff, 0, 0xffff, 0 },
  { 0 /* left button */,
    0 /* right button -- may be different for some character classes */,
    0, 0 },
  { 0xff, 0xff, 0xff, 0xff, 0xff, 0 /* varies depending on character class */,
    0xff, 0xff /* or 79 for Druid and Paladin */, 0xff, 0xff },
  { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff },
  { 0 /* 0x80? */, 0, 0 } /* Normal difficulty */,
  0 /* map ID; will be filled in by the game (I think) */,
  0, 0 /* hireling status */,
  0 /* hireling ID */, 0 /* hireling name */, 0 /* hireling attribute */,
  0 /* hireling experience */, { 0 /* repeats 143 times */ },
  { 'W', 'o', 'o', '!' } /* quest completion data header */,
  { 6, 0, 0, 0, 42, 1 },
  {
    { /* Acts I-III for normal difficulty: */
      { { 0, { 0, 0, 0, 0, 0, 0 }, 0 }, { 0, { 0, 0, 0, 0, 0, 0 }, 0 },
	{ 0, { 0, 0, 0, 0, 0, 0 }, 0 } },
      /* Act IV for normal difficulty: */
      { 0, { 0, 0, 0 }, 0 }, { 0 /* repeats 37 times */ } },
    { /* Acts I-IV for nightmare difficulty: */
      { { 0, { 0, 0, 0, 0, 0, 0 }, 0 }, { 0, { 0, 0, 0, 0, 0, 0 }, 0 },
	{ 0, { 0, 0, 0, 0, 0, 0 }, 0 } },
      { 0, { 0, 0, 0 }, 0 }, { 0 /* repeats 37 times */ } },
    { /* Acts I-IV for hell difficulty: */
      { { 0, { 0, 0, 0, 0, 0, 0 }, 0 }, { 0, { 0, 0, 0, 0, 0, 0 }, 0 },
	{ 0, { 0, 0, 0, 0, 0, 0 }, 0 } },
      { 0, { 0, 0, 0 }, 0 }, { 0 /* repeats 37 times */ } }
  },
  { 'W', 'S' } /* waypoint data header */, { 1, 0, 0, 0, 80, 0 },
  { /* waypoints for normal difficulty: */
    { { 2, 1 }, { 1, 0 }, { 0 /* repeats 16 times */ } },
    /* waypoints for nightmare difficulty: */
    { { 2, 1 }, { 1, 0 }, { 0 /* repeats 16 times */ } },
    /* waypoints for hell difficulty: */
    { { 2, 1 }, { 1, 0 }, { 0 /* repeats 16 times */ } }
  },
  1,
  { 'w', '4' } /* ???? data header */,
  { { 0 /* repeats 7 times */ } /* repeats twice more */ },
  { { 0 /* repeats 7 times */ } /* repeats twice more */ },
  0,
  { 'g', 'f' } /* statistics data header */
};

/* The presence of each stats field is constant,
   but the contents of the statistics vary from character to character. */
const struct template_stats_struct
template_d2s_stats_section[NUM_CHAR_CLASSES] = {
#define DB8FP(v) { (v) << 8, (v) << 8 }
  /* Amazon: */
  { 0x1fcf, 20, 15, 25, 20, DB8FP (50), DB8FP (15), DB8FP (84), 1 },
  /* Sorceress: */
  { 0x1fcf, 10, 35, 25, 10, DB8FP (40), DB8FP (35), DB8FP (74), 1 },
  /* Necromancer: */
  { 0x1fcf, 15, 25, 25, 15, DB8FP (45), DB8FP (25), DB8FP (79), 1 },
  /* Paladin: */
  { 0x1fcf, 25, 15, 20, 25, DB8FP (55), DB8FP (15), DB8FP (89), 1 },
  /* Barbarian: */
  { 0x1fcf, 30, 10, 20, 25, DB8FP (55), DB8FP (10), DB8FP (92), 1 },
  /* Druid: */
  { 0x1fcf, 15, 20, 20, 25, DB8FP (55), DB8FP (20), DB8FP (84), 1 },
  /* Assassin: */
  { 0x1fcf, 20, 25, 20, 20, DB8FP (50), DB8FP (25), DB8FP (95), 1 },
};

/* This part contains the (empty) skills data and the first 6 items
   assigned to every character.  The last 1 or 2 items vary. */
const struct template_tail_struct template_d2s_tail_section = {
  { 'i', 'f' }, { 0 /* repeats 29 times */ },
  { 'J', 'M' }, 6 /* will add the other(s) later */,
  {
    /* 4 healing potions in the belt */
    { 'J', 'M', 0x10, 0x20, 0xa2, 0x00, 0x01,
      0x08, 0x00, 0x80, 0x06, 0x17, 0x03, 0x02 },
    { 'J', 'M', 0x10, 0x20, 0xa2, 0x00, 0x01,
      0x08, 0x02, 0x80, 0x06, 0x17, 0x03, 0x02 },
    { 'J', 'M', 0x10, 0x20, 0xa2, 0x00, 0x01,
      0x08, 0x04, 0x80, 0x06, 0x17, 0x03, 0x02 },
    { 'J', 'M', 0x10, 0x20, 0xa2, 0x00, 0x01,
      0x08, 0x06, 0x80, 0x06, 0x17, 0x03, 0x02 },
    { 'J', 'M', 0x10, 0x20, 0xa2, 0x00, 0x01,
      0x00, 0x72, 0x42, 0x37, 0x37, 0x06, 0x02 },
    { 'J', 'M', 0x10, 0x20, 0xa2, 0x00, 0x01,
      0x00, 0x52, 0x92, 0x36, 0x37, 0x06, 0x02 }
  },
  { 'J', 'M' } /* will be moved down when items are added */
};

/* Character-specific items */
const unsigned char template_d2s_class_items[NUM_CHAR_CLASSES][48] = {
  { /* The Amazon has javelins and a buckler */
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x01,
    0x84, 0x00, 0xa0, 0x16, 0x66, 0x07, 0x02,
    0x62, 0x4e, 0xbf, 0xb2, 0x80, 0x40, 0x40,
    0x80, 0xc7, 0x7f,
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x01,
    0xa4, 0x00, 0x20, 0x56, 0x37, 0x06, 0x82,
    0xd9, 0x0f, 0xea, 0xa9, 0x80, 0xe0, 0x01,
    0x06, 0x86, 0xff },
  { /* The Sorceress has a short staff */
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x01,
    0x84, 0x00, 0x30, 0x37, 0x47, 0x07, 0x02,
    0x4c, 0x0b, 0xa0, 0xc5, 0x80, 0x80, 0x82,
    0x62, 0x0d, 0x89, 0xf0, 0x1f },
  { /* The Necromancer has a wand */
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x01,
    0x84, 0x00, 0x70, 0xe7, 0x46, 0x06, 0x02,
    0xbd, 0x01, 0x55, 0x8d, 0x80, 0xe0, 0xe1,
    0x61, 0x8d, 0x91, 0xf0, 0x1f, },
  { /* The Paladin has a short sword and a buckler */
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x01,
    0x84, 0x00, 0x30, 0x37, 0x47, 0x06, 0x82,
    0xd3, 0x3e, 0x32, 0xc1, 0x80, 0x00, 0x03,
    0xe3, 0x3f,
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x01,
    0xa4, 0x00, 0x20, 0x56, 0x37, 0x06, 0x02,
    0x34, 0x55, 0xfd, 0xdb, 0x80, 0xe0, 0x01,
    0x06, 0x86, 0xff },
  { /* The Barbarian has a hand axe and a buckler */
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x01,
    0x84, 0x00, 0x80, 0x16, 0x86, 0x07, 0x82,
    0x1d, 0xd4, 0x0a, 0xaa, 0x80, 0x80, 0x83,
    0xe3, 0x3f,
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x01,
    0xa4, 0x00, 0x20, 0x56, 0x37, 0x06, 0x02,
    0xf8, 0x54, 0x26, 0xf2, 0x80, 0xe0, 0x01,
    0x06, 0x86, 0xff },
  { /* The Druid has a club and a buckler */
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x64,
    0x84, 0x00, 0x30, 0xc6, 0x26, 0x06, 0x02,
    0xf4, 0x4e, 0x74, 0x98, 0x80, 0x00, 0x03,
    0xe3, 0x3f,
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x64,
    0xa4, 0x00, 0x20, 0x56, 0x37, 0x06, 0x02,
    0xdf, 0x34, 0xfc, 0x8b, 0x80, 0xc0, 0x01,
    0x06, 0x86, 0xff },
  { /* The Assassin has a katar and a buckler */
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x64,
    0x84, 0x00, 0xb0, 0x46, 0x27, 0x07, 0x82,
    0xac, 0x7f, 0x52, 0xa4, 0x80, 0x00, 0x06,
    0xe6, 0x3f,
    'J', 'M', 0x10, 0x20, 0x82, 0x00, 0x64,
    0xa4, 0x00, 0x20, 0x56, 0x37, 0x06, 0x02,
    0x7e, 0x54, 0xb5, 0x8a, 0x80, 0xe0, 0x01,
    0x06, 0x86, 0xff }
};
