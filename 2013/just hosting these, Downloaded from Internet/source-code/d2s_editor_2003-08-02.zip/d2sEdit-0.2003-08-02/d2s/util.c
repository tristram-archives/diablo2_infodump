/* Various utilities.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "util.h"
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
/* Not sure whether this belongs here; we use XtResolvePathname */
/* #include <X11/Intrinsic.h> */
#include <dmalloc.h>

/* These functions basically simplify error checking by performing the
   checks within the desired function, assuming any error to be fatal.
   Thus the functions are guaranteed to return a normal result. */

void *
(xmalloc) (size_t size)
{
  void *ptr;

  ptr = malloc (size);
  if (ptr == NULL) {
    fprintf (stderr, "%s: Out of memory\n", progname);
    exit (1);
  }
  return ptr;
}

void *
(xrealloc) (void *ptr, size_t size)
{
  ptr = realloc (ptr, size);
  if (ptr == NULL) {
    fprintf (stderr, "%s: Out of memory\n", progname);
    exit (1);
  }
  return ptr;
}

char *
(xstrdup) (const char *str)
{
  /* For portability sake, don't assume the target system has strdup(). */
  int len;
  char *newstr;

  len = strlen (str) + 1;
  newstr = (char *) xmalloc (len);
  memcpy (newstr, str, len);
  return newstr;
}

/* An extension of sprintf; append the format to an existing
   dynamic string, resizing the string to accomodate the extra
   message and returning a (possibly changed) pointer to the string. */
char *
scatprintf (char *str, const char *fmt, ...)
{
  va_list ap;
  int old_len, added_len;

  /* Find out the length of the formatted message */
  va_start (ap, fmt);
  added_len = vsnprintf (NULL, 0, fmt, ap);
  va_end (ap);

  /* For non-standard libraries, assume a default length limit. */
  if (added_len <= 1)
    added_len = 256;

  /* Resize the given string */
  old_len = (str == NULL) ? 0 : strlen (str);
  str = (char *) xrealloc (str, old_len + added_len + 1);

  /* Format the message */
  va_start (ap, fmt);
  vsnprintf (&str[old_len], added_len + 1, fmt, ap);
  va_end (ap);

  return str;
}


/* Find a file among a set of default or user-defined paths.
   The paths are searched in the following order:
   1. Path given on the command line (overwrites:)
   2. Installation path given at compile time
   3. User's home directory + "/." + program name
   4. Directory from which the program was run
   5. Current directory

   For each base part of the path, the subdirectory part is applied,
   followed by the base name and extension, then tried; and if it
   fails, a component is removed from the head of the subdirectory
   part and tried again.  After trying a path without any subdirectory
   part, the routine goes to the next base path.
 */
char *xfindfile (const char *subdir, const char *base_name,
		 const char *ext, const char *inst_path)
{
  int stage;
  int len, after_len;
  char *base_part, *path_part;
  const char *subdir_component;
  struct stat stat_buf;

  /* Check for NULL arguments and empty strings */
  if ((subdir != NULL) && !*subdir)
    subdir = NULL;
  if (base_name == NULL)
    base_name = "";
  if (ext == NULL)
    ext = "";
  if ((inst_path != NULL) && !*inst_path)
    inst_path = NULL;

  /* Size the components */
  after_len = (((subdir == NULL) ? 0 : (strlen (subdir))) + 1
	       + strlen (base_name) + strlen (ext) + 1);
  for (stage = 1; ; stage++)
    {
      switch (stage)
	{
	case 1:
	  /* Command line option or
	     Compile time installation path -- passed as a parameter */
	  if (inst_path != NULL)
	    {
	      base_part = xstrdup (inst_path);
	      break;
	    }
	  /* No install path given */
	  stage++;
	  /* FALLTHROUGH */

	case 2:
	  /* User's home directory */
	  base_part = getenv ("HOME");
	  if (base_part != NULL)
	    {
	      subdir_component = strrchr (progname, '/');
	      if (subdir_component == NULL)
		subdir_component = progname;
	      path_part = xmalloc (strlen (base_part) + 2
				  + strlen (subdir_component) + 1);
	      sprintf (path_part, "%s/.%s", base_part, subdir_component);
	      base_part = path_part;
	      break;
	    }
	  /* No home directory?! */
	  stage++;
	  /* FALLTHROUGH */

	case 3:
	  /* Directory from which the program was run */
	  subdir_component = strrchr (progname, '/');
	  if (subdir_component != NULL)
	    {
	      len = (int) (subdir_component - progname);
	      base_part = xstrdup (progname);
	      base_part[len] = '\0';
	      break;
	    }
	  /* Presumably the program was run from the current directory */
	  stage++;
	  /* FALLTHROUGH */

	case 4:
	  /* Current directory */
	  base_part = xstrdup (".");
	  break;

	default:
	  /* Out of search paths, and the file still is not found. */
	  errno = ENOENT;
	  return NULL;
	}

      subdir_component = subdir;
      len = strlen (base_part);
      base_part = (char *) xrealloc (base_part, len + 2 + after_len);
      path_part = &base_part[len];

      /* Try the base part with all components of the subdirectory */
      while (subdir_component)
	{
	  sprintf (path_part, "/%s/%s%s", subdir_component, base_name, ext);
	  if ((stat (base_part, &stat_buf) == 0)
	      && S_ISREG (stat_buf.st_mode))
	    /* We found it! */
	    return base_part;

	  /* Remove the leading path component from the subdirectory */
	  subdir_component = strchr (subdir_component, '/');
	  if (subdir_component != NULL)
	    subdir_component++;
	}

      /* Nothing left in the subdirectory; try it without one. */
      sprintf (path_part, "/%s%s", base_name, ext);
      if ((stat (base_part, &stat_buf) == 0)
	  && S_ISREG (stat_buf.st_mode))
	/* We found it! */
	return base_part;

      /* Not found off of this base path.  Move on to the next stage. */
      free (base_part);
    }
  /* NOTREACHED */
  errno = ENOENT;
  return NULL;
}


/* Move an existing file to a backup name.
   Return the name used for the backup (or NULL on failure). */
char *
backup_old_file (const char *orig_name)
{
  char *backup_name;
  int i, iteration_index;

  iteration_index = strlen (orig_name);
  backup_name = (char *) xmalloc (iteration_index + 10);
  strcpy (backup_name, orig_name);
  /* We'll only go up to 9,999 backup files.  Still an *AWFUL* lot. */
  for (i = 1; i < 10000; i++)
    {
      sprintf (&backup_name[iteration_index], ".~%d~", i);
      if (access (backup_name, F_OK) == 0)
	continue;
      if (errno == ENOENT)
	{
	  /* Possible candidate.  Try to rename the file. */
	  if (rename (orig_name, backup_name) == 0)
	    /* Success! */
	    return backup_name;
	  print_message ("Failed to back up %s; %s.",
			 orig_name, strerror (errno));
	  free (backup_name);
	  return NULL;
	}
      /* Unhandled error condition */
      print_message ("Unable to back up %s; %s.",
		     orig_name, strerror (errno));
      free (backup_name);
      return NULL;
    }
  print_message ("No more backup extensions available for %s", orig_name);
  free (backup_name);
  return NULL;
}


/* Helper function: write a string of bytes to a data stream in memory.
   Allocates more space to the data stream if required. */
void
dstream_write (struct data_stream *dstream, const void *buf, unsigned int len)
{
  unsigned long offset;

  if ((unsigned) (&dstream->ptr[len] - dstream->base) > dstream->size)
    {
      offset = (unsigned long) (dstream->ptr - dstream->base);
      dstream->size = (&dstream->ptr[len] - dstream->base) + 256;
      dstream->base = (unsigned char *)
	xrealloc (dstream->base, dstream->size);
      dstream->ptr = &dstream->base[offset];
      dstream->end = &dstream->base[dstream->size];
    }
  memcpy (dstream->ptr, buf, len);
  dstream->ptr += len;
}

/* Read a series of bits from a raw data stream.
   Handles bitfields up to 32 bits at any boundary. */
unsigned long
bstream_read_field (struct bit_stream *bstream, int bits)
{
  unsigned long answer;
  int so_far;

  /* Start by reading all bits from the current position
     to the third byte boundary. */
  answer = (*((unsigned long *) &bstream->base[bstream->ptr / 8])
	    >> (bstream->ptr & 7));

  /* Figure out how many bits we actually got. */
  so_far = 8 * sizeof (long) - (bstream->ptr & 7);

  /* If we read all the required bits, we're good to go.
     Otherwise, we need to read part of the following byte
     to finish the value. */
  if (bits > so_far) {
    /* We know PTR + SO_FAR is aligned to a byte boundary, because
       PTR = PTR + 32 - (PTR & 7) == 0 (MOD 8) */
    answer |= bstream->base[(bstream->ptr + so_far) / 8] << so_far;
  }

  if (bits < 32)
    answer &= (1 << bits) - 1;
  bstream->ptr += bits;
  return answer;
}

/* Write a series of bits to a raw data stream in memory.
   Allocates more space to the stream if required. */
void
bstream_write_field (struct bit_stream *bstream,
		     int bits, unsigned long value)
{
  int so_far;
  unsigned long tulip;

  /* First, make sure there is enough space left to write the BITS. */
  if (bstream->ptr + bits > bstream->aloc * 8)
    {
      bstream->aloc += sizeof (long);
      bstream->base = (unsigned char *)
	xrealloc (bstream->base, bstream->aloc);
    }

  /* Truncate the given value to the given number of bits (just to be safe) */
  if (bits < 32)
    value &= (1 << bits) - 1;

  /* Read the longword starting from the previous byte boundary. */
  tulip = *((unsigned long *) &bstream->base[bstream->ptr / 8]);
  /* Calculate the number of bits from the starting position
     to the end of the longword. */
  so_far = 8 * sizeof (long) - (bstream->ptr & 7);

  /* Zero out the part of the value which will be overwritten. */
  tulip &= ~((((bits < 32) ? (1 << bits) : 0) - 1) << (bstream->ptr & 7));
  /* Write the new value over the zeroed space. */
  tulip |= value << (bstream->ptr & 7);
  *((unsigned long *) &bstream->base[bstream->ptr / 8]) = tulip;

  /* If we wrote all the given bits, we're ready to move on.
     Otherwise, we need to write part of the following byte
     to finish the value. */
  if (bits > so_far) {
    tulip = bstream->base[(bstream->ptr + so_far) / 8];
    /* Again, zero out the part which will be overwritten. */
    tulip &= ~((1 << (bits - so_far)) - 1);
    tulip |= value >> so_far;
    bstream->base[(bstream->ptr + so_far) / 8] = (unsigned char) tulip;
  }

  /* Update the pointer. */
  bstream->ptr += bits;
  /* If we've written past the previous end of the stream,
     update the stream size. */
  if (bstream->ptr > bstream->size)
    bstream->size = bstream->ptr;
}
