/* d2sData-Act -- functions in the d2sData class that deal with
 *		  acts, quests, and other per-difficulty values.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "functions.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include "d2sData.h"
#include "d2sItem.h"
#include <dmalloc.h>


/* Little nicety for printing; act numbers in roman.
   Note: these assume the index is 0-based (i.e., act==0 => Act I) */
static const char * const roman_number[8] = {
  "I", "II", "III", "IV", "V", "VI", "VII", "VIII"
};

/* Forward declarations: */

static const char * GetQuestName (table_entry_t quest_entry);
static inline const char * GetWaypointName (table_entry_t waypoint_entry);
static table_entry_t lookup_quest_state (int act, int quest, int state);


/********************* NON-CLASS FUNCTIONS **********************/

/* Get the name of a quest or waypoint, given its entry in the data tables */
static const char *
GetQuestName (table_entry_t quest_entry)
{
  const char *code, *name;

  code = GetEntryStringField (quest_entry, "qsts");
  if (code[0]) {
    name = LookupStringByKey (code);
    if (name != NULL)
      return name;
  }
  return GetEntryStringField (quest_entry, "name");
}

static inline const char *
GetWaypointName (table_entry_t waypoint_entry)
{
  return TranslateString (GetEntryStringField (waypoint_entry, "Name"));
}

/* Find state #N of a given quest.  If N is -1, find the completion state. */
static table_entry_t
lookup_quest_state (int act, int quest, int state)
{
  table_entry_t quest_entry, state_entry;
  char quest_code[8] = "a1q1";
  char state_index[12];
  int num_states;
  const char *state_code;

  quest_code[1] = (char) ('1' + act);
  quest_code[3] = (char) ('1' + quest);
  quest_entry = LookupTableEntry ("quests", "code", quest_code);
  if (quest_entry == NULL) {
    if (debug)
      fprintf (stderr, "%s: Internal error in the quests table:"
	       " no entry for act %s quest %d\n",
	       progname, roman_number[act], quest + 1);
    return NULL;
  }
  num_states = GetEntryIntegerField (quest_entry, "numStates");
  if ((state >= num_states) || (state < -num_states)) {
    if (debug)
      fprintf (stderr, "%s: Internal error: state #%d requested for %s,\n"
	       " but only %d states are listed in the quests table.\n",
	       progname, state, GetQuestName (quest_entry), num_states);
    return NULL;
  }
  sprintf (state_index, "state%d", (state >= 0) ? state : num_states + state);
  state_code = GetEntryStringField (quest_entry, state_index);
  if (state_code[0] == 0) {
    if (debug)
      fprintf (stderr, "%s: Internal error in the quests table:"
	       " no entry for %s of %s\n",
	       progname, state_index, GetQuestName (quest_entry));
    return NULL;
  }
  state_entry = LookupTableEntry ("queststates", "code", state_code);
  if (state_entry == NULL) {
    if (debug)
      fprintf (stderr, "%s: Internal error in the quest states table:"
	       " no entry for %s (%s of %s)\n",
	       progname, state_code, state_index, GetQuestName (quest_entry));
    return NULL;
  }
  if (GetEntryStringField (state_entry, "hexValue")[0] == 0) {
    if (debug)
      fprintf (stderr, "%s: Internal error in the quest states table:"
	       " no value for %s (%s of %s)\n",
	       progname, state_code, state_index, GetQuestName (quest_entry));
    return NULL;
  }
  return state_entry;
}

/*********************** CLASS FUNCTIONS ************************/

/* Get the current difficulty in which the character is playing. */
int
d2sData::GetCurrentDifficulty (void) const
{
  int difficulty;

  /* Although it's technically possible for more than one difficulty
     to have its active bit set, I have no idea whether it's allowed.
     I haven't seen it done.  So assume that if there's one difficulty
     active, it's the only one. */
  for (difficulty = HELL_DIFFICULTY;
       difficulty > NORMAL_DIFFICULTY; difficulty--)
    if (is_game_in_progress (difficulty))
      break;
  return difficulty;
}

/* Get the status of whether the player has talked with a NPC. */
int
d2sData::GetNPCIntro (int difficulty, int act, int npc) const
{
  table_entry_t act_entry;
  char npc_field[12] = "NPC1bit";
  int npc_bit;
  struct d2s_header *header;

  /* Check the arguments */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS))
    return 0;
  act_entry = LookupIndexedTableEntry ("acts", act);
  if (npc >= GetEntryIntegerField (act_entry, "numNPCs"))
    return 0;
  npc_field[3] = (char) ('1' + npc);
  npc_bit = GetEntryIntegerField (act_entry, npc_field);
  if (!npc_bit)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error in acts table: bad value for"
		 " %s in act %s.\n", progname, npc_field, roman_number[act]);
      return 0;
    }

  /* We don't have class members for the NPC values (yet).
     Read the bits directly from the raw data. */
  header = (struct d2s_header *) &raw_header[0];
  return ((header->introductions[difficulty][npc_bit / 8]
	   >> (npc_bit % 8)) & 1);
}

/* Determine whether the character's inventory matches a quest state.
   Used to find which state matches a given value, or to determine
   whether a new state is valid. */
int
d2sData::inventory_matches_quest_state (table_entry_t state_entry,
					int difficulty) const
{
  char item_field[12];
  const char *item_code;
  int item;

  strcpy (item_field, "reqItem1");
  for (item = '1'; item <= '9'; item++)
    {
      item_field[7] = (char) item;
      item_code = GetEntryStringField (state_entry, item_field);
      if (item_code[0] == 0)
	break;
      if ( ! this->is_carrying_a (item_code))
	/* Not carrying a required item; not a match */
	return False;
    }

  strcpy (item_field, "noItem1");
  for (item = '1'; item <= '9'; item++)
    {
      item_field[6] = (char) item;
      item_code = GetEntryStringField (state_entry, item_field);
      if (item_code[0] == 0)
	break;
      if (this->is_carrying_a (item_code))
	/* Carrying a forbidden item; not a match */
	return False;
    }

  /* All items check out; it's a match */
  return True;
}

/* This function returns the quest state code for a given quest, given
   the current quest data modified by any items the character is
   carrying.  Returns NULL if no matching state is found. */
const char *
d2sData::GetQuestState (int difficulty, int act, int quest) const
{
  table_entry_t quest_entry, state_entry;
  char quest_name[8] = "a1q1";
  char state_name[12];
  const char *state_code, *candidate;
  int state, num_states, state_value, state_mask, state_ignore;

  /* Check the arguments */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) quest >= MAX_NUM_QUESTS))
    return NULL;

  /* Look up the quest entry */
  quest_name[1] = (char) ('1' + act);
  quest_name[3] = (char) ('1' + quest);
  quest_entry = LookupTableEntry ("quests", "code", quest_name);
  num_states = GetEntryIntegerField (quest_entry, "numStates");
  candidate = NULL;
  for (state = 0; state < num_states; state++)
    {
      sprintf (state_name, "state%d", state);
      state_code = GetEntryStringField (quest_entry, state_name);
      state_entry = LookupTableEntry ("queststates", "code", state_code);
      if (state_entry == NULL)
	{
	  if (debug)
	    fprintf (stderr, "%s: Error in %s table: can't find entry for\n"
		     " act %s, quest %d, state %d\n", progname,
		     state_code[0] ? "quests" : "quest states",
		     roman_number[act], quest + 1, state);
	  continue;
	}

      /* Get the value and masks for this state */
      state_value = strtol (GetEntryStringField
			    (state_entry, "hexValue"), NULL, 16);
      state_mask = strtol (GetEntryStringField
			   (state_entry, "hexMask"), NULL, 16);
      state_ignore = strtol (GetEntryStringField
			     (state_entry, "dontcareMask"), NULL, 16);

      /* If our value equals the state value under the mask,
	 it's a likely candidate (subject to item check). */
      if (((GetQuestData (difficulty, act, quest) ^ state_value)
	   & state_mask) != 0)
	continue;

      /* If our value differs from the state value other than
	 the ignored bits, it's possibly an error.  But we won't
	 check than on reading. */
      if (candidate == NULL)
	candidate = state_code;

      /* If there are items associated with this state,
	 check whether we have or don't have the required quest items. */
      if (inventory_matches_quest_state (state_entry, difficulty))
	/* We have a complete match!  Return the state. */
	return state_code;
    }

  /* We didn't find a matching state.
     Do we at least have a matching state not counting quest items? */
  if (candidate != NULL)
    {
      print_message ("Warning: the state of act %s quest %d (\"%s\")"
		     " does not correspond with the items %s is carrying.\n",
		     roman_number[act], quest + 1, TranslateString
		     (GetEntryStringField (quest_entry, "name")), name);
      return candidate;
    }

  /* No match for any known state */
  print_message ("Warning: the data for act %s quest %d (\"%s\")"
		 " does not match any known quest state (current value"
		 " = %#.4x)\n", roman_number[act], quest + 1,
		 TranslateString (GetEntryStringField (quest_entry, "name")),
		 GetQuestData (difficulty, act, quest));
  return NULL;
}

/**************** MODIFICATION SECTION ****************/

/* Change which town a player is in */
int
d2sData::SetCurrentAct (int difficulty, int act)
{
  /* Check the arguments */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::SetCurrentAct(%d,%d)\n",
		 progname, difficulty, act);
      error_str = "Invalid argument";
      return -1;
    }
  if ((act >= NumberOfActs()) && !options.character.link.freeform)
    {
      print_message ("Act %s is not available in this game\n",
		     roman_number[act]);
      error_str = "That act is not available";
      return -1;
    }

  if (act == GetCurrentAct (difficulty))
    /* Nothing needs to be done */
    return 0;

  /* Is changing the location allowed? */
  if (read_only || !options.character.edit.act_location)
    {
      error_str = "You may not teleport to another act";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.all_difficulties
      && (difficulty != GetCurrentDifficulty()))
    {
      error_str = "You may not teleport in an inactive difficulty level";
      print_message (error_str);
      return -1;
    }
  if (act && ! GetActCompletion (difficulty, act - 1)
      && options.character.link.act_entry)
    {
      if (!options.character.link.auto_act)
	{
	  error_str = "You may not teleport to an act which you have not seen";
	  print_message (error_str);
	  return -1;
	}
      if (SetActCompletion (difficulty, act - 1, 1) < 0)
	return -1;
    }

  /* The change is allowed */
  difficulty_active[difficulty] = (difficulty_active[difficulty] & ~7) | act;
  MarkDirty ();
  return 0;
}

/* Change the act and quest completion data -- BEWARE dependencies!! */
int
d2sData::SetActIntros (int difficulty, int act, int value)
{
  /* Check the arguments */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) value >= 0x10000))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::SetActIntros(%d,%d,%#.4x)\n",
		 progname, difficulty, act, value);
      error_str = "Invalid argument";
      return -1;
    }
  if ((act >= NumberOfActs()) && !options.character.link.freeform)
    {
      print_message ("Act %s is not available in this game\n",
		     roman_number[act]);
      error_str = "That act is not available";
      return -1;
    }

  if (value == GetActIntros (difficulty, act))
    /* Nothing needs to be done */
    return 0;

  /* Is changing the act introductions allowed? */
  if (read_only || !options.character.edit.npcs)
    {
      error_str = "You may not alter the act introduction status";
      print_message (error_str);
      return -1;
    }
  if ((value > 1) && !options.character.link.freeform)
    {
      error_str = "Unsupported act introduction state";
      print_message (error_str);
      return -1;
    }
  if (act && value && ! GetActCompletion (difficulty, act - 1)
      && options.character.link.act_entry)
    {
      if (!options.character.link.auto_act)
	{
	  print_message ("You may not be introduced to act %s"
			 " until you have left act %s.\n",
			 roman_number[act], roman_number[act - 1]);
	  error_str = "You have not entered this act yet";
	  return -1;
	}
      if (SetActCompletion (difficulty, act - 1, 1) < 0)
	return -1;
    }

  /* The change is allowed. */
  quest_data[difficulty].act[act].intros = value;
  MarkDirty ();
  return 0;
}

/* Get the table entry for the (next) quest required to complete an act.
   If the required quest(s) has(ve) already been completed, return NULL. */
table_entry_t
d2sData::act_exit_requirement (int difficulty, int act, int quest) const
{
  table_entry_t act_entry, quest_entry;
  const char *quest_code;
  int req_act, req_quest;

  act_entry = LookupIndexedTableEntry ("acts", act);
  if (act_entry == NULL) {
    if (debug)
      fprintf (stderr,
	       "%s: Internal error in acts table: no entry for act %s.\n",
	       progname, roman_number[act]);
    return NULL;
  }
  /* We may need to redo this to add multiple requirements */
  quest_code = GetEntryStringField (act_entry, "reqQuest");
  if (quest_code[0] == 0)
    /* No requirement */
    return NULL;
  quest_entry = LookupTableEntry ("quests", "code", quest_code);
  if (quest_entry == NULL) {
    if (debug)
      fprintf (stderr, "%s: Internal error in quests table: no entry for"
	       " \"%s\".\n", progname, quest_code);
    return NULL;
  }
  req_act = GetEntryIntegerField (quest_entry, "act");
  req_quest = GetEntryIntegerField (quest_entry, "quest");
  if (quest == req_quest)
    /* The caller wanted to know if this quest is required */
    return quest_entry;
  if (is_quest_complete (difficulty, req_act, req_quest))
    /* The required quest has been completed. */
    return NULL;
  /* This quest needs completing */
  return quest_entry;
}

/* Get the table entry for the (next) quest required to begin a new quest.
   If the required quest(s) has(ve) already been completed, return NULL. */
table_entry_t
d2sData::quest_activation_requirement (int difficulty,
				       int act, int quest) const
{
  table_entry_t quest_entry;
  char quest_code[8] = "a1q1";

  quest_code[1] = (char) ('1' + act);
  quest_code[3] = (char) ('1' + quest);
  quest_entry = LookupTableEntry ("quests", "code", quest_code);
  if (quest_entry == NULL) {
    if (debug)
      fprintf (stderr, "%s: Internal error in quests table: no entry for"
	       " act %s quest %d (\"%s\").\n",
	       progname, roman_number[act], quest + 1, quest_code);
    return NULL;
  }
  return quest_activation_requirement (difficulty, quest_entry);
}

table_entry_t
d2sData::quest_activation_requirement (int difficulty,
				       table_entry_t quest) const
{
  const char *requirement_code;
  table_entry_t requirement;
  int req_act, req_quest;

  requirement_code = GetEntryStringField (quest, "reqQst");
  if (requirement_code[0] == 0)
    /* This quest has no requirement */
    return NULL;
  requirement = LookupTableEntry ("quests", "code", requirement_code);
  if (requirement == NULL) {
    if (debug)
      fprintf (stderr, "%s: Internal error in quests table: no entry for\n"
	       " \"%s\" (referred by quest \"%s\").\n",
	       progname, requirement_code,
	       GetEntryStringField (quest, "code"));
    return NULL;
  }
  req_act = GetEntryIntegerField (requirement, "act");
  req_quest = GetEntryIntegerField (requirement, "quest");
  if (is_quest_complete (difficulty, req_act, req_quest))
    /* The required quest has been completed. */
    return NULL;
  /* This quest needs completing */
  return requirement;
}

int
d2sData::SetActCompletion (int difficulty, int act, int value)
{
  table_entry_t quest_entry;
  int		req_act, req_quest;
  const char	*quest_name;

  /* Check the arguments */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) value >= 0x10000))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::SetActCompletion(%d,%d,%#.4x)\n",
		 progname, difficulty, act, value);
      error_str = "Invalid argument";
      return -1;
    }
  if ((act >= NumberOfActs()) && !options.character.link.freeform)
    {
      print_message ("Act %s is not available in this game\n",
		     roman_number[act]);
      error_str = "That act is not available";
      return -1;
    }
  /* AFAIK, act completion cannot be set on the last act in a game. */
  if ((act + 1 >= NumberOfActs()) && !options.character.link.freeform)
    {
      error_str = ("You cannot set act completion for the"
		   " last act in the game\n");
      print_message (error_str);
      return -1;
    }

  if (value == GetActCompletion (difficulty, act))
    /* Nothing needs to be done */
    return 0;

  /* Is changing the act completion allowed? */
  if (read_only || !options.character.edit.acts)
    {
      error_str = "You may not alter the act completion status";
      print_message (error_str);
      return -1;
    }
  if ((value & ~0x2001) && !options.character.link.freeform)
    {
      error_str = "Unsupported act completion state";
      print_message (error_str);
      return -1;
    }

  /* Tricky part here.  Unless we're in freeform mode, if the user
     wants to toggle act completion, we have to check whether it's
     consistent with the quests in the current or next act. */
  /* Note the triple knot: compare boolean states, not values. */
  if (!value != !GetActCompletion (difficulty, act)) {
    if (value) {
      /* Does the player meet the exit requirement for this level? */
      if (act && ! GetActCompletion (difficulty, act - 1)
	  && options.character.link.act_entry) {
	if (!options.character.link.auto_act) {
	  print_message ("You may not leave act %s until you have"
			 " left act %s.\n",
			 roman_number[act], roman_number[act - 1]);
	  error_str = "You have not entered this act yet";
	  return -1;
	}
	if (SetActCompletion (difficulty, act - 1, 1) < 0) {
	  print_message ("Act %s has not been completed.\n",
			 roman_number[act - 1]);
	  return -1;
	}
      }

      if (options.character.link.act_quest) {
	while ((quest_entry = act_exit_requirement (difficulty, act))
	       != NULL) {
	  quest_name = GetQuestName (quest_entry);
	  if (!options.character.link.auto_quest) {
	    print_message ("You may not leave act %s until you have completed"
			   " the quest for %s.\n",
			   roman_number[act], quest_name);
	    error_str = "You have not completed the required quests";
	    return -1;
	  }
	  req_act = GetEntryIntegerField (quest_entry, "act");
	  req_quest = GetEntryIntegerField (quest_entry, "quest");
	  if (CompleteQuest (difficulty, req_act, req_quest) < 0) {
	    print_message ("Quest for %s has not been completed.\n",
			   quest_name);
	    error_str = "You have not completed the required quests";
	    return -1;
	  }
	} /* Completed the required quest */
      }
    } /* Exiting this act */

    /* Backtracking */
    else if (options.character.link.act_entry) {
      if (!options.character.edit.backward) {
	/* When we don't allow editing games backward, that means
	   from the point the game was saved.  So we need to check
	   whether the act was exited in the raw data. */
	struct d2s_header *file_header = (struct d2s_header *) &raw_header;
	if ((act < 3) ? file_header->quests[difficulty].act[act].completed
	    : ((act == 3) ? file_header->quests[difficulty].act_4.completed
	       : file_header->quests[difficulty].act_5.completed))
	  {
	    print_message ("You may not back out of act %s",
			   roman_number[act + 1]);
	    error_str = "Backtracking not allowed";
	    return -1;
	  }
      }

      /* Has the player done anything or gone anywhere in the next act? */
      if ((act + 1 < NumberOfActs())
	  || ((act + 1 == NumberOfActs())
	      && !options.character.link.freeform)) {
	if (GetActCompletion (difficulty, act + 1)) {
	  if (!options.character.link.auto_act) {
	    print_message ("You may not back out of act %s"
			   " until you first back out of act %s.\n",
			   roman_number[act + 1], roman_number[act + 2]);
	    error_str = "You have moved beyond the next act";
	    return -1;
	  }
	  if (SetActCompletion (difficulty, act + 1, 0) < 0)
	    {
	      print_message ("Act %s is still active.\n",
			     roman_number[act + 2]);
	      return -1;
	    }
	}
      }
      for (req_quest = GetNumberOfQuestsInAct (act + 1) - 1;
	   req_quest >= 0; req_quest--) {
	if (GetQuestData (difficulty, act + 1, req_quest)) {
	  quest_name = GetQuestName (act + 1, req_quest);
	  if (!options.character.link.auto_act
	      || !options.character.link.auto_quest) {
	    print_message ("You may not back out of act %s;"
			   " you have already %sed the quest for %s.\n",
			   roman_number[act + 1],
			   (quest_data[difficulty].act[act + 1]
			    .quest[req_quest] & 1) ? "complet" : "start",
			   quest_name);
	    error_str = "You have started a quest in the next act";
	    return -1;
	  }
	  if (SetQuestData (difficulty, act + 1, req_quest, 0) < 0) {
	    print_message ("Quest for %s is %s.\n", quest_name,
			   (quest_data[difficulty].act[act + 1]
			    .quest[req_quest] & 1) ? "complete" : "active");
	    return -1;
	  }
	}
      } /* for (each quest in the next act) */

      if ((act + 1 < NumberOfActs()) && waypoints[difficulty][act + 1] > 1) {
	if (!options.character.link.auto_act) {
	  print_message ("You may not back out of act %s;"
			 " you left some waypoints on.\n",
			 roman_number[act + 1]);
	  error_str = "You have waypoints left on in the next act";
	  return -1;
	}
	waypoints[difficulty][act + 1] = 0;
      }

      /* Clear the NPC intros for the next act unconditionally. */
      if (act + 1 < NumberOfActs())
	{
	  table_entry_t act_entry;
	  int	npc_bit, last_bit;
	  char	npc_field[12] = "NPC1bit";
	  struct d2s_header *header = (struct d2s_header *) &raw_header[0];

	  quest_data[difficulty].act[act + 1].intros = 0;
	  act_entry = LookupIndexedTableEntry ("acts", act + 1);
	  npc_bit = GetEntryIntegerField (act_entry, npc_field);
	  last_bit = GetEntryIntegerField (act_entry, "numNPCs");
	  npc_field[3] = (char) ('1' + last_bit - 1);
	  last_bit = GetEntryIntegerField (act_entry, npc_field);
	  /* We clear all bits from the first to the last,
	     just in case there are bits we don't know about. */
	  for ( ; npc_bit <= last_bit; npc_bit++)
	    header->introductions[difficulty][npc_bit / 8]
	      &= ~(1 << (npc_bit % 8));
	}
    } /* Backtracking */
  }

  /* The change is allowed */
  quest_data[difficulty].act[act].completed = value;
  if (options.character.link.act_waypoint)
    {
      /* If we are entering the next act, turn on the town waypoint.
	 If we are backing out of the next act, turn off the town waypoint. */
      if (value)
	waypoints[difficulty][act + 1] |= 1;
      else
	waypoints[difficulty][act + 1] &= ~1;
    }
  MarkDirty ();
  return 0;
}

int
d2sData::SetQuestData (int difficulty, int act, int quest, int value)
{
  table_entry_t quest_entry, req_entry, state_entry;
  int state, num_states;
  int req_act, req_quest, req_value;
  int mask, ignore;
  const char *quest_name, *cstr;
  char quest_code[8] = "a1q1";
  char state_code[12];
  char item_code[12];
  d2sItem *quest_item;

  /* Check the arguments */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) quest >= MAX_NUM_QUESTS)
      || ((unsigned) value >= 0x10000))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::SetQuestData(%d,%d,%d,%#.4x)\n",
		 progname, difficulty, act, quest, value);
      error_str = "Invalid argument";
      return -1;
    }
  if ((act >= NumberOfActs()) && !options.character.link.freeform)
    {
      print_message ("Act %s is not available in this game\n",
		     roman_number[act]);
      error_str = "That act is not available";
      return -1;
    }
  if ((quest >= GetNumberOfQuestsInAct (act))
      && !options.character.link.freeform)
    {
      print_message ("Act %s only has %d quests\n",
		     roman_number[act], GetNumberOfQuestsInAct (act));
      error_str = "That quest is not available";
      return -1;
    }

  if (value == GetQuestData (difficulty, act, quest))
    /* Nothing needs to be done */
    return 0;

  /* Is changing the quest data allowed? */
  if (read_only || !options.character.edit.quests_complete)
    {
      error_str = "You may not alter the quest state";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.quests_intermediate
      /* The user can make a quest inactive, or complete, but not half-baked.
	 Other than adding a whole lot of code and columns to the
	 quest table, probably the easiest way to tell the difference
	 is to look at bit 0.  I think. */
      && ((value & 1)
	  ? /* complete; allow any bits except bit 1 */ (value & 2)
	  : /* clearing; no other bits allowed */ value))
    {
      error_str = "You make not set a quest to an intermediate state";
      print_message (error_str);
      return -1;
    }

  /* Tricky part here.
     Check whether the data is valid, whether the user meets the
     requirements for the quest, and whether any quest items need
     to be added or removed.  Such a hassle! */
  quest_name = GetQuestName (act, quest);
  /* Check the value first.  If it isn't supported, there's no way
     we can check item requirements.  And we wouldn't want to have
     changed the state of other quests before realizing the error. */
  quest_code[1] = (char) ('1' + act);
  quest_code[3] = (char) ('1' + quest);
  quest_entry = LookupTableEntry ("quests", "code", quest_code);
  num_states = GetEntryIntegerField (quest_entry, "numStates");
  req_entry = NULL;
  for (state = 0; state < num_states; state++) {
    sprintf (state_code, "state%d", state);
    state_entry = LookupTableEntry
      ("queststates", "code",
       GetEntryStringField (quest_entry, state_code));
    req_value = strtol (GetEntryStringField (state_entry, "hexValue"),
			NULL, 16);
    mask = strtol (GetEntryStringField (state_entry, "hexMask"),
		   NULL, 16);
    ignore = strtol (GetEntryStringField (state_entry, "dontcareMask"),
		     NULL, 16);
    if (((value ^ req_value) & mask) != 0)
      /* Not a match */
      continue;
    /* If it *looks* like a match, but it isn't after removing
       the don't-care bits, it's an unsupported value. */
    if ((((value ^ req_value) & ~ignore) != 0)
	&& !options.character.link.freeform) {
      print_message ("Unsupported value %#.4x for %s.  The known value"
		     " that matches this state is %#.4x with an ignore"
		     " mask of %#.4x.\n",
		     value, quest_name, req_value, ignore);
      error_str = "Unsupported quest data";
      return -1;
    }

    else {
      /* If the value is a match, we still need to test for item
	 requirements.  This determines whether to use another state
	 entry for the same value, or whether we need to alter the
	 inventory. */
      if (req_entry == NULL)
	/* Save the first matching state found
	   in case no other states match */
	req_entry = state_entry;
      if (inventory_matches_quest_state (state_entry, difficulty))
	/* We have a matching state at this point! */
	break;
    }
  } /* Loop through all known states */

  if (state >= num_states) {
    if ((req_entry == NULL) && !options.character.link.freeform) {
      print_message ("Unsupported value %#.4x for %s.\n",
		     value, quest_name);
      error_str = "Unsupported quest data";
      return -1;
    }

    if (req_entry != NULL) {
      /* We -could- have a match, if we altered the inventory. */
      state_entry = req_entry;
      /* Are we allowed to do that? */
      if (!options.character.edit.inventory
	  || !options.character.link.quest_inventory) {
	print_message ("The quest for %s requires quest items. "
		       " Changing the value to %#.4x is not possible.\n",
		       quest_name, value);
	error_str = "Quest items required";
	return -1;
      }
    }
    /* Save changing the inventory for later */
  } /* Inventory change required */

  /* We have a matching state, so the value is (more or less) good.
     Now, does the player meet the prerequisites?  (The only ones
     I'm aware of at this time are completing other quests.) */
  if (value && ! GetQuestData (difficulty, act, quest)) {
    /* Is the player in this act? */
    if (!options.character.edit.all_difficulties
	&& (difficulty != GetCurrentDifficulty ())) {
      print_message ("You may not activate a quest in %s mode"
		     " when the player is in %s mode.\n",
		     GetDifficultyName (difficulty),
		     GetDifficultyName (GetCurrentDifficulty ()));
      error_str = "Cannot activate quests in another difficulty mode";
      return -1;
    }
    if (act && ! GetActCompletion (difficulty, act - 1)
	&& options.character.link.act_entry) {
      if (!options.character.link.auto_act) {
	print_message ("You need to leave act %s before you can"
		       " begin any quests in act %s.\n",
		       roman_number[act - 1], roman_number[act]);
	error_str = "You have not entered this act yet";
	return -1;
      }
      if (SetActCompletion (difficulty, act - 1, 1) < 0) {
	print_message ("Act %s has not been completed.\n",
		       roman_number[act - 1]);
	return -1;
      }
    }

    /* Check for a required quest */
    if (options.character.link.quest_quest) {
      while ((req_entry = quest_activation_requirement
	      (difficulty, quest_entry)) != NULL) {
	cstr = GetQuestName (req_entry);
	if (!options.character.link.auto_quest) {
	  print_message ("You need to complete the quest for %s"
			 " before you can begin the quest for %s.\n",
			 cstr, quest_name);
	  error_str = "You have not completed the required quests";
	  return -1;
	}
	if (CompleteQuest (difficulty,
			   GetEntryIntegerField (req_entry, "act"),
			   GetEntryIntegerField (req_entry, "quest")) < 0) {
	  print_message ("Quest for %s has not been completed.\n", cstr);
	  return -1;
	}
      } /* Quest needs completion */
    }
  } /* Activating a quest */

  else if ( ! value && GetQuestData (difficulty, act, quest)) {
    /* Do we need to shut the door to the next act? */
    if (!options.character.edit.all_difficulties
	&& (difficulty != GetCurrentDifficulty ())) {
      print_message ("You may not reset a quest in %s mode"
		     " when the player is in %s mode.\n",
		     GetDifficultyName (difficulty),
		     GetDifficultyName (GetCurrentDifficulty ()));
      error_str = "Cannot reset quests in another difficulty mode";
      return -1;
    }
    if (GetActCompletion (difficulty, act)
	&& options.character.link.act_quest) {
      /* Look up the exit for this act and see if this quest is required. */
      if (act_exit_requirement (difficulty, act, quest) != NULL) {
	if (!options.character.link.auto_act) {
	  print_message ("The quest for %s is required for passage to"
			 " Act %s.\n", quest_name, roman_number[act + 1]);
	  error_str = "Quest is required for moving to the next act";
	  return -1;
	}
	if (SetActCompletion (difficulty, act, 0) < 0) {
	  print_message ("Act %s is still active\n", roman_number[act + 1]);
	  return -1;
	}
      }
    }

    if (options.character.link.quest_quest) {
      for (req_quest = GetNumberOfQuestsInAct (act) - 1;
	   req_quest >= 0; req_quest--) {
	if (req_quest == quest)
	  continue;
	quest_code[3] = (char) ('1' + quest);
	cstr = GetEntryStringField
	  (LookupTableEntry ("quests", "code", quest_code), "reqQuest");
	if (cstr[0] && (((cstr[2] == 0) && (req_quest > quest))
			|| (cstr[2] && (cstr[3] - '1' == req_quest)))) {
	  cstr = GetQuestName (act, req_quest);
	  if (!options.character.link.auto_quest) {
	    print_message ("You may not give up the quest for %s"
			   " after you have activated the quest for %s.\n",
			   quest_name, cstr);
	    error_str = "You have started the following quest";
	    return -1;
	  }
	  if (SetQuestData (difficulty, req_act, req_quest, 0) < 0) {
	    print_message ("Quest for %s has not been abandoned.\n", cstr);
	    return -1;
	  }
	}
      } /* Loop through all quests in the act */
    } /* Give up quests that require this one */
  }

  if (state_entry) {
    if ( ! inventory_matches_quest_state (state_entry, difficulty)) {
      if (!options.character.link.quest_inventory)
	print_message ("Warning: inventory does not match quest state\n");

      /* Go through the list.  Remove items we have that are
	 forbidden.  Add items we don't have that are required. */
      strcpy (item_code, "noItem1");
      for (item_code[6] = '1'; item_code[6] <= '9'; item_code[6]++) {
	cstr = GetEntryStringField (state_entry, item_code);
	if (cstr[0] == 0)
	  break;
	quest_item = find_carried_item (cstr);
	if (quest_item != NULL) {
	  if (!options.character.link.quest_inventory)
	    print_message ("%s %s requires relinquishing %s.\n",
			   value ? ((value & 1) ? "Completing"
				    : "This state for") : "Giving up",
			   quest_name, TranslateString (cstr));
	  else if (RemoveItem (quest_item) < 0) {
	    display_error ("Unable to remove %s", quest_item->Name());
	    error_str = "Unable to remove quest item";
	    /* TO-DO: we may have already altered other items, so
	       instead of returning, we should re-compute a new quest
	       value based on the new inventory. */
	    return -1;
	  } else {
	    /* Destroy the item as well, unless it is referenced by the UI. */
	    if (quest_item->GetUI() == NULL)
	      delete quest_item;
	  }
	} /* Quest item needs to be removed */
      } /* Check for forbidden items */

      strcpy (item_code, "reqItem1");
      for (item_code[7] = '1'; item_code[7] <= '9'; item_code[7]++) {
	cstr = GetEntryStringField (state_entry, item_code);
	if (cstr[0] == 0)
	  break;
	if ( ! this->is_carrying_a (cstr)) {
	  if (!options.character.link.quest_inventory)
	    print_message ("%s %s requires obtaining %s.\n",
			   value ? ((value & 1) ? "Completing"
				    : "This state for") : "Giving up",
			   quest_name, TranslateString (cstr));
	  else {
	    int area, col, row;

	    quest_item = CreateItemFromCode (cstr);
	    if (quest_item == NULL) {
	      if (debug)
		fprintf (stderr, "%s: Internal error: unable to create quest"
			 " item %s.\n", progname, TranslateString (cstr));
	      display_error ("I'm sorry; I was unable to create the %s.\n",
			     TranslateString (cstr));
	      error_str = "Internal error";
	      /* TO-DO: we may have already altered other items, so
		 instead of returning, we should re-compute a new quest
		 value based on the new inventory. */
	      return -1;
	    }
	    /* Find somewhere to put this item */
	    if (FindEmptySpotForItem (quest_item, &area, &col, &row) < 0) {
	      print_message ("You have no room to take the %s.\n",
			     quest_item->Name());
	      display_error ("I'm sorry; I couldn't find any place to put"
			     " the %s.\n", quest_item->Name());
	      delete quest_item;
	      error_str = "No room for required item";
	      /* TO-DO: we may have already altered other items, so
		 instead of returning, we should re-compute a new quest
		 value based on the new inventory. */
	      return -1;
	    }
	    if ((quest_item->SetLocation (area, col, row) < 0)
		|| (AddItem (quest_item) < 0)) {
	      if(debug)
		fprintf (stderr, "%s: Internal error: unable to add quest"
			 " item %s.\n", progname, quest_item->Name());
	      display_error ("I'm sorry; I was unable to add the %s.\n",
			     quest_item->Name());
	      error_str = "Internal error";
	      return -1;
	    }
	  } /* Automatically add items */
	} /* Quest item needs to be added */
      } /* Check for required items */
    } /* Inventory change */
  } /* Tricky part */

  /* The change is allowed */
  if ((quest_data[difficulty].act[act].quest[quest] & 1) != (value & 1)) {
    /* If this is the last quest in an act, update the character title byte. */
    if (!options.character.link.freeform) {
      cstr = GetEntryStringField (LookupIndexedTableEntry ("acts", act),
				  "reqQuest");
      if (quest == cstr[3] - '1') {
	if (value & 1) {
	  /* Final quest completed; is this new? */
	  if ((difficulty * NumberOfActs() + act >= char_title)
	      /* We don't count killing Diablo in an Expansion game */
	      && ((act != MAX_NUM_ACTS - 2) || !is_expansion()))
	    char_title = difficulty * NumberOfActs() + act + 1;
	} else {
	  /* Final quest reset; was it counted? */
	  if (difficulty * NumberOfActs() + act < char_title) {
	    char_title = difficulty * NumberOfActs() + act;
	    /* We don't count killing Diablo in an Expansion game */
	    if ((act == MAX_NUM_ACTS - 2) && is_expansion())
	      char_title--;
	  }
	}
      }
    }
  }
  quest_data[difficulty].act[act].quest[quest] = value;
  MarkDirty ();
  return 0;
}

/* These convenience functions look up the proper value for starting
   or completing a quest, and pass that value on to SetQuestData(). */
int
d2sData::BeginQuest (int difficulty, int act, int quest)
{
  table_entry_t state_entry;
  const char *hex_value;

  /* Check the arguments */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) quest >= MAX_NUM_QUESTS))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::BeginQuest(%d,%d,%d)\n",
		 progname, difficulty, act, quest);
      error_str = "Invalid argument";
      return -1;
    }

  state_entry = lookup_quest_state (act, quest, 1);
  if (state_entry == NULL) {
    error_str = "Internal error";
    return -1;
  }

  hex_value = GetEntryStringField (state_entry, "hexValue");
  if (SetQuestData (difficulty, act, quest, strtol (hex_value, NULL, 16))
      < 0)
    return -1;
  if (GetQuestData (difficulty, act, quest))
    return 0;
  if (debug)
    fprintf (stderr, "%s: Internal error: %s did not activate the quest.\n",
	     progname, hex_value);
  return -1;
}

int
d2sData::CompleteQuest (int difficulty, int act, int quest)
{
  table_entry_t state_entry;
  const char *hex_value;

  /* Check the arguments */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) quest >= MAX_NUM_QUESTS))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::CompleteQuest(%d,%d,%d)\n",
		 progname, difficulty, act, quest);
      error_str = "Invalid argument";
      return -1;
    }

  state_entry = lookup_quest_state (act, quest, -1);
  if (state_entry == NULL) {
    error_str = "Internal error";
    return -1;
  }

  hex_value = GetEntryStringField (state_entry, "hexValue");
  if (SetQuestData (difficulty, act, quest, strtol (hex_value, NULL, 16))
      < 0)
    return -1;
  if (is_quest_complete (difficulty, act, quest))
    return 0;
  if (debug)
    fprintf (stderr, "%s: Error in quest state table: %s is not"
	     " a proper quest completion state.\n", progname, hex_value);
  return -1;
}

/* Turn a waypoint on or off. */
int
d2sData::SetWaypoint (int difficulty, int act, int point, int toggle)
{
  /* Check the arguments. */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS)
      || ((unsigned) point >= MAX_NUM_WAYPOINTS))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::SetWaypoint(%d,%d,%d,%s)\n",
		 progname, difficulty, act, point, toggle ? "True" : "False");
      error_str = "Invalid argument";
      return -1;
    }
  if ((act >= NumberOfActs()) && !options.character.link.freeform)
    {
      print_message ("Act %s is not available in this game\n",
		     roman_number[act]);
      error_str = "That act is not available";
      return -1;
    }
  if (point >= GetNumberOfWaypointsInAct (act))
    {
      print_message ("There are only %d waypoints in act %s (not %d)\n",
		     GetNumberOfWaypointsInAct (act),
		     roman_number[act], point + 1);
      error_str = "No such waypoint";
      return -1;
    }

  if ((GetWaypoint (difficulty, act, point) != 0) == (toggle != 0))
    /* Nothing needs to be done */
    return 0;

  /* Is toggling waypoints allowed? */
  if (read_only || !options.character.edit.waypoints)
    {
      error_str = "You may not alter waypoints in the game";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.all_difficulties
      && (difficulty != GetCurrentDifficulty()))
    {
      print_message ("%s difficulty is not active",
		     GetDifficultyName (difficulty));
      error_str = "You may not alter waypoints in an inactive game";
      return -1;
    }
  if (!toggle && !options.character.edit.backward)
    {
      /* When we don't allow editing games backward, that means
	 from the point the game was saved.  So we need to check
	 whether the waypoint was active in the raw data. */
      struct d2s_header *file_header = (struct d2s_header *) &raw_header;
      int bit = point, a;

      for (a = 0; a < act; a++)
	bit += GetNumberOfWaypointsInAct (a);
      if (file_header->waypoints[difficulty].points[bit / 8]
	  & (1 << (bit % 8)))
	{
	  error_str = "You may not deactivate waypoints";
	  print_message (error_str);
	  return -1;
	}
    }

  if (toggle && act && !GetActCompletion (difficulty, act - 1)
      && options.character.link.act_entry) {
    /* Waypoints may only be activated in acts that have been entered. */
    if (!options.character.link.auto_act) {
      print_message ("You may not activate the waypoint to %s"
		     " until you have entered act %s.\n",
		     GetWaypointName (act, point), roman_number[act]);
      error_str = ("You may not activate a waypoint"
		   " until you enter the act");
      return -1;
    }
    if (SetActCompletion (difficulty, act - 1, 1) < 0) {
      print_message ("Act %s has not been completed.\n",
		       roman_number[act - 1]);
      return -1;
    }
  }

  if (!toggle && !point && (!act || GetActCompletion (difficulty, act - 1))
      && options.character.link.act_waypoint) {
    if (act && options.character.link.auto_act)
      {
	/* Try to un-exit the previous act */
	if (SetActCompletion (difficulty, act - 1, 0) < 0)
	  {
	    print_message ("Act %s is still active\n", roman_number[act + 1]);
	    return -1;
	  }
      }
    else
      {
	/* The first waypoint in an entered act may *not* be deactivated. */
	error_str = "You may not deactivate the first waypoint in an act";
	print_message (error_str);
	return -1;
      }
  }

  /* The change is allowed. */
  if (toggle)
    waypoints[difficulty][act] |= (1 << point);
  else
    waypoints[difficulty][act] &= ~(1 << point);
  MarkDirty ();
  return 0;
}

/* Set whether an NPC has been introduced */
int
d2sData::SetNPCIntro (int difficulty, int act, int npc, int toggle)
{
  table_entry_t act_entry;
  char npc_field[12] = "NPC1bit";
  int npc_bit;
  struct d2s_header *header;

  /* Check the arguments. */
  if (((unsigned) difficulty >= NUM_DIFFICULTY_LEVELS)
      || ((unsigned) act >= MAX_NUM_ACTS))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad argument to"
		 " d2sData::SetNPCIntro(%d,%d,%d,%s)\n",
		 progname, difficulty, act, npc, toggle ? "True" : "False");
      error_str = "Invalid argument";
      return -1;
    }
  if ((act >= NumberOfActs()) && !options.character.link.freeform)
    {
      print_message ("Act %s is not available in this game\n",
		     roman_number[act]);
      error_str = "That act is not available";
      return -1;
    }

  /* Get the bit number for this NPC's introduction state */
  act_entry = LookupIndexedTableEntry ("acts", act);
  if (npc >= GetEntryIntegerField (act_entry, "numNPCs"))
    {
      print_message ("There are only %d NPCs in Act %s\n",
		     GetEntryIntegerField (act_entry, "numNPCs"),
		     roman_number[act]);
      error_str = "Invalid argument";
      return -1;
    }
  npc_field[3] = (char) ('1' + npc);
  npc_bit = GetEntryIntegerField (act_entry, npc_field);
  if (!npc_bit)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error in acts table: bad value for"
		 " %s in act %s.\n", progname, npc_field, roman_number[act]);
      return 0;
    }

  /* TO-DO: NPC intros need to be copied into separate local
     variables.  The original file data is used to determine
     whether the current state of intros can be undone or no. */
  /* We don't have class members for the NPC values (yet).
     Change the bits directly in the raw data. */
  header = (struct d2s_header *) &raw_header[0];
  if ((((header->introductions[difficulty][npc_bit / 8]
	 >> (npc_bit % 8)) & 1) != 0) == (toggle != 0))
    /* Nothing needs to be done */
    return 0;

  /* Is toggling NPC intros allowed? */
  if (read_only || !options.character.edit.npcs)
    {
      error_str = "You may not alter whether NPCs have been introduced";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.all_difficulties
      && (difficulty != GetCurrentDifficulty()))
    {
      print_message ("%s difficulty is not active",
		     GetDifficultyName (difficulty));
      error_str = "You may not alter NPC introductions in an inactive game";
      return -1;
    }
  if (!toggle && !options.character.edit.backward)
    {
      /* When we don't allow editing games backward, that means
	 from the point the game was saved.  So we need to check
	 whether the waypoint was active in the raw data. */
      if (header->introductions[difficulty][npc_bit / 8]
	  & (1 << (npc_bit % 8)))
	{
	  error_str = "You may not give NPCs amnesia";
	  print_message (error_str);
	  return -1;
	}
    }

  if (toggle && act && !GetActCompletion (difficulty, act - 1)
      && options.character.link.act_entry) {
    /* NPCs may only be introduced in acts that have been entered. */
    if (!options.character.link.auto_act) {
      print_message ("You may not introduce yourself to %s"
		     " until you have entered act %s.\n",
		     GetNPCName (act, npc), roman_number[act]);
      error_str = ("You may not activate a waypoint"
		   " until you enter the act");
      return -1;
    }
    if (SetActCompletion (difficulty, act - 1, 1) < 0) {
      print_message ("Act %s has not been completed.\n",
		       roman_number[act - 1]);
      return -1;
    }
  }

  /* The change is allowed. */
  if (toggle)
    header->introductions[difficulty][npc_bit / 8]
      |= 1 << (npc_bit % 8);
  else
    header->introductions[difficulty][npc_bit / 8]
      &= ~(1 << (npc_bit % 8));
  MarkDirty ();
  return 0;
}
