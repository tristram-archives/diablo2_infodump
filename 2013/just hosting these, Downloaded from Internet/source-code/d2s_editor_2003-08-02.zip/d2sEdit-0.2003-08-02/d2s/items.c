/* Diablo II v1.09 Item Editor, text based (old; needs to go away)
 * Copyright (C) 2001 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include "items.h"
#include "tables.h"

extern int read_yes_no (const char *prompt, int default_answer);
extern int read_number (const char *prompt, int max_limit);

const char * const item_slot_names[] = {
  NULL, "head", "neck", "torso", "right hand", "left hand",
  "right finger", "left finger", "waist", "feet", "hands",
  "right hand alternate", "left hand alternate"
};

const char * const item_quality_names[8] = {
  "cracked?", "Crude or Damaged or Low Quality", "normal", "Superior",
  "magic" /* blue name */, "part of a set" /* green name */,
  "rare" /* yellow name */, "unique" /* gold name */
};

/* Low quality items appear to be a special case; needs additional bits */
const char * const low_quality_names[4] = {
  "Crude", "Cracked", "Damaged", "Low Quality"
};

#define read_bits(s,n) ((*((unsigned long *) &data[(s) / 8]) >> ((s) & 7)) \
			& ((1 << (n)) - 1))
#define write_bits(s,n,v) *((unsigned long *) &data[(s) / 8])		\
	= (*((unsigned long *) &data[(s) / 8])				\
	   & ~(((1 << (n)) - 1) << ((s) & 7)))				\
	  | (((v) & ((1 << (n)) - 1)) << ((s) & 7))

void
dump_raw_data (unsigned char *data, int length)
{
  int i;

  printf ("   ");
  for (i = 0; i < length; i++)
    printf (" %02x", data[i]);
  printf ("\n");
}

void
dump_bit_data (unsigned char *data, int start, int nbits)
{
  int value;

  putchar ('\t');
  while (nbits)
    {
      value = (data[start / 8] >> (start & 7)) & 1;
      putchar ('0' + value);
      start++;
      nbits--;
    }
  putchar ('\n');
}

void
print_location (struct item_data *item)
{
  switch (item->location)
    {
    case 0:
      switch (item->stored_location)
	{
	case 1: printf (" stored in your inventory, column %d, row %d\n",
			item->column, item->row); return;
	case 4: printf (" stored in the Cube, column %d, row %d\n",
			item->column, item->row); return;
	case 5: printf (" stored in your stash, column %d, row %d\n",
			item->column, item->row); return;
	}
      break;

    case 1:
      if (item->equipped_slot && (item->equipped_slot <= 12))
	printf (" equipped on %s\n", item_slot_names[item->equipped_slot]);
      else
	printf (" equipped on %d?\n", item->equipped_slot);
      return;

    case 2:
      printf (" tucked in your belt, column %d, row %d\n",
	      item->column & 3, item->column >> 2);
      return;

    case 4:
      printf (" picked up by the mouse\n");
      return;

    case 6:
      printf (" glued into a socket\n");
      return;
    }

  printf (" location unknown! loc=%d, sto=%d, col=%d, row=%d\n",
	  item->location, item->stored_location, item->column, item->row);
}

const char * const rune_names[] = {
  "0" /* unused */, 
  "El", "Eld", "Tir", "Nef", "Eth", "Ith", "Tal", "Ral",
  "Ort", "Thul", "Amn", "Sol", "Shael", "Dol", "Hel", "Io",
  "Lum", "Ko", "Fal", "Lem", "Pul", "Um", "Mal", "Ist",
  "Gul", "Vex", "Ohm", "Lo", "Sur", "Ber", "Jah", "Cham",
  "Zod",
};

unsigned char *
dump_item_data (unsigned char *data, int length)
{
  struct item_data *item;
  struct gem_data *gem;
  const char *base_type_name;
  int i, item_count, gem_count = 0, ilen;
  int start, defense, durability, max_durability, quantity, max_quantity;
  char item_code[4];
  table_entry_t item_entry;

  if ((*((unsigned short *) data) != ITEM_MAGIC)
      || ((struct item_list_header *) data)->filler
      || (*((unsigned short *) &data[4]) != ITEM_MAGIC))
    {
      printf ("Warning: item header not found at the expected offset\n");
      for (i = 1; i < length - 6; i++)
	{
	  if ((*((unsigned short *) &data[i]) == ITEM_MAGIC)
	      && !((struct item_list_header *) &data[i])->filler
	      && (*((unsigned short *) &data[i + 4]) == ITEM_MAGIC))
	    break;
	}
      if (i >= length - 6)
	{
	  printf ("Error: item data not found\n");
	  return data;
	}
      printf ("%d bytes of intervening data\n", i);
      dump_raw_data (data, i);
      data += i;
      length -= i;
    }

  item_count = ((struct item_list_header *) data)->item_count;
  printf ("Item list header: %d items (not counting gems in sockets)\n",
	  item_count);
  data += sizeof (struct item_list_header);
  length -= sizeof (struct item_list_header);
  while ((item_count || gem_count) && (length > 4))
    {
      if (*((unsigned short *) data) != ITEM_MAGIC)
	{
	  for (i = 1; i < length - 4; i++)
	    if (*((unsigned short *) &data[i]) == ITEM_MAGIC)
	      break;
	  if (i >= length - 4)
	    break;
	  printf ("(skipping %d bytes of data)n", i);
	  dump_raw_data (data, i);
	  data += i;
	  length -= i;
	}

      /* Item records are variable length,
       * so just scan for the next "JM" header. */
      for (ilen = 2; ilen < length - 1; ilen++)
	{
	  if (*((unsigned short *) &data[ilen]) == ITEM_MAGIC)
	    break;
	  /* In an expansion set game, the main character's inventory
	     data is followed by "jf", then the hireling's inventory
	     data (if one is present), then "kf".  If a hireling is
	     present, his inventory data won't end in "JM". */
	  if ((*((unsigned short *) &data[ilen])
	       == (*((unsigned short *) &"jf")))
	      || (*((unsigned short *) &data[ilen])
		  == (*((unsigned short *) &"kf"))))
	    break;
	}
      gem = (struct gem_data *) data;
      item = (struct item_data *) data;

      if ((ilen == 4) && (*((unsigned short *) &data[2]) == 0)
	  && (*((unsigned short *) &data[4]) == *((unsigned short *) &"jf"))
	  && (*((unsigned short *) &data[6]) == ITEM_MAGIC))
	{
	  /* End of the item list; beginning of
	   * a second item list for the hireling. */
	  printf ("Hireling item list header: %d items\n",
		  ((struct item_list_header *) &data[6])->item_count);
	  data += 6 + sizeof (struct item_list_header);
	  length -= 6 + sizeof (struct item_list_header);
	  continue;
	}
      else if ((ilen == 4) && (*((unsigned short *) &data[2]) == 0)
	       && (*((unsigned short *) &data[4])
		   == *((unsigned short *) &"jf"))
	       && (*((unsigned short *) &data[6])
		   == *((unsigned short *) &"kf")))
	{
	  /* End of the item list; there is no hireling list. */
	  break;
	}

      if (item->location != 6)
	item_count--;
      else
	gem_count--;

      item_code[0] = item->type;
      item_code[1] = item->subtype;
      item_code[2] = item->variant;
      item_code[3] = '\0';
      item_entry = LookupTableEntry ("armor", "code", item_code);
      if (item_entry != NULL)
	{
	  base_type_name = GetEntryStringField (item_entry, "name");
	  goto type_armor;
	}
      item_entry = LookupTableEntry ("weapons", "code", item_code);
      if (item_entry != NULL)
	{
	  base_type_name = GetEntryStringField (item_entry, "name");
	  if (GetEntryIntegerField (item_entry, "stackable"))
	    {
	      max_quantity = GetEntryIntegerField (item_entry, "maxstack");
	      goto type_stacked_weapon;
	    }
	  else
	    goto type_weapon;
	}
      item_entry = LookupTableEntry ("misc", "code", item_code);
      if (item_entry != NULL)
	{
	  base_type_name = GetEntryStringField (item_entry, "name");
	  if (GetEntryIntegerField (item_entry, "stackable"))
	    {
	      max_quantity = GetEntryIntegerField (item_entry, "maxstack");
	      if (strcmp (GetEntryStringField (item_entry, "type"),
			  "book") == 0)
		goto type_tome;
	      else
		goto type_stack;
	    }
	  if (item->simple)
	    goto type_simple;
	  dump_ring_data (base_type_name, data, ilen);
	  goto next_item;
	}
      base_type_name = "unknown";
      if (item->simple)
	goto type_simple;
      else
	goto type_unknown;

    type_simple:
      printf ("Next item \"%c%c%c%c\":", item->type,
	      item->subtype, item->variant, item->unknownc_4);
      dump_raw_data (data, ilen);
      printf (" %s", base_type_name);
      print_location (item);
      goto next_item;

    type_stacked_weapon:
      printf ("Next item \"%c%c%c%c\" looks like throwable weapons:",
	      item->type, item->subtype, item->variant, item->unknownc_4);
      dump_raw_data (data, ilen);
      if (!item->identified) printf (" (Unidentified)");
      if (item->ethereal)
	printf (" (ethereal)");
      if (item->newbie) printf (" (newbie)");
      start = dump_magic_prefix (base_type_name, data, ilen);
      max_durability = read_bits (start, 8);
      start += 8;
      if (max_durability) {
	durability = read_bits (start + 8, 8);
	start += 8;
      } else {
	durability = 0;
      }
      quantity = read_bits (start, 9);
      print_location (item);
      printf ((max_durability ? "\t(durability: %d of %d)\n"
	       : "\t(indestructible)\n"),
	      durability, max_durability);
      printf ("\tQuantity: %d\n", quantity);
      start += 9;
      if (item->ethereal)
	printf ("\tEthereal (Cannot be Repaired)\n");
      if (item->socketed)
	{
	  /* This shouldn't happen, but just in case... */
	  printf ("\tSocketed (%lu)\n", read_bits (start, 4));
	  start += 4;
	}
      dump_magic_data (data, start, ilen);
      goto next_item;

    type_stack:
      printf ("Next item \"%c%c%c%c\" looks like %s:", item->type,
	      item->subtype, item->variant, item->unknownc_4, base_type_name);
      dump_raw_data (data, ilen);
      if (!item->identified) printf (" (Unidentified)");
      start = dump_magic_prefix (base_type_name, data, ilen);
      quantity = read_bits (start, 9);
      print_location (item);
      printf ("\tQuantity: %d\n", quantity);
      start += 9;
      dump_magic_data (data, start, ilen);
      goto next_item;

    type_tome:
      printf ("Next item \"%c%c%c%c\":", item->type,
	      item->subtype, item->variant, item->unknownc_4);
      dump_raw_data (data, ilen);
      printf (" %s w/ %lu scrolls", base_type_name, read_bits (162, 5));
      print_location (item);
      goto next_item;

    type_weapon:
      printf ("Next item \"%c%c%c%c\" looks like a weapon:", item->type,
	      item->subtype, item->variant, item->unknownc_4);
      dump_raw_data (data, ilen);
      if (!item->identified) printf (" (Unidentified)");
      if (item->ethereal)
	printf (" (ethereal)");
      if (item->socketed)
	{
	  printf (" (socketed");
	  gem_count = gem->gem_count;
	  if (gem_count)
	    printf (" w/ %d gems", gem_count);
	  printf (")");
	}
      if (item->newbie) printf (" (newbie)");
      start = dump_magic_prefix (base_type_name, data, ilen);
      print_location (item);

      max_durability = read_bits (start, 8);
      start += 8;
      if (max_durability) {
	durability = read_bits (start, 8);
	start += 8;
	printf ("\tDurability: %d of %d\n", durability, max_durability);
      } else {
	printf ("\tIndestructible\n");
      }

      if (item->ethereal)
	printf ("\tEthereal (Cannot be Repaired)\n");
      if (item->socketed)
	{
	  printf ("\tSocketed (%lu)\n", read_bits (start, 4));
	  start += 4;
	}
      dump_magic_data (data, start, ilen);
      goto next_item;

    type_armor:
      printf ("Next item \"%c%c%c%c\" looks like armor:", item->type,
	      item->subtype, item->variant, item->unknownc_4);
      dump_raw_data (data, ilen);
      if (!item->identified) printf (" (Unidentified)");
      if (item->ethereal)
	printf (" (ethereal)");
      if (item->socketed)
	{
	  printf (" (socketed");
	  gem_count = gem->gem_count;
	  if (gem_count)
	    printf (" w/ %d gems", gem_count);
	  printf (")");
	}
      if (item->newbie) printf (" (newbie)");
      start = dump_magic_prefix (base_type_name, data, ilen);
      print_location (item);

      defense = read_bits (start, 10) - 10;
      start += 10;
      printf ("\tDefense: %d\n", defense);
      max_durability = read_bits (start, 8);
      start += 8;
      if (max_durability) {
	durability = read_bits (start, 8);
	start += 8;
	printf ("\tDurability: %d of %d\n", durability, max_durability);
      } else {
	durability = 0;
      }

      if (item->ethereal)
	printf ("\tEthereal (Cannot be Repaired)\n");
      if (item->socketed)
	{
	  printf ("\tSocketed (%lu)\n", read_bits (start, 4));
	  start += 4;
	}
      dump_magic_data (data, start, ilen);
      goto next_item;

    type_unknown:
      printf ("Next item is type \"%c%c%c%c\":\n\t", item->type,
	      item->subtype, item->variant, item->unknownc_4);
      /* Make an educated guess */
      if (item->is_ring)
	{
	  dump_ring_data ("ring, amulet, jewel, or charm", data, ilen);
	  goto next_item;
	}
      dump_raw_data (data, ilen);
      if (!item->identified) printf (" (Unidentified)");
      if (item->socketed)
	{
	  printf (" (socketed");
	  gem_count = gem->gem_count;
	  if (gem_count)
	    printf (" w/ %d gems", gem_count);
	  printf (")");
	}
      if (item->newbie) printf (" (newbie)");
      /* We can at least print the magic prefix, I think */
      dump_magic_prefix ("unknown", data, ilen);
      print_location (item);
      if (item->ethereal)
	printf ("\tEthereal (Cannot be Repaired)\n");
      goto next_item;

    next_item:
      data += ilen;
      length -= ilen;
    }

  return data;
}



struct magical_modifiers_t {
  unsigned short id;		/* 9 bits */
  unsigned char data_len;	/* number of bits in the data field */
  unsigned char data2_len;	/* some magic properties have 2 data fields */
  short		bias;	    /* adjustment of stored value vs. screen value */
  short		bias2;
  const char *	name;		/* written name w/ value in printf format */
};

const struct magical_modifiers_t magical_modifiers[] = {
  { 0, 7, 0, 32, 0, "%+d to Strength" },
  { 1, 7, 0, 32, 0, "%+d to Energy" },
  { 2, 7, 0, 32, 0, "%+d to Dexterity" },
  { 3, 7, 0, 32, 0, "%+d to Vitality" },
  { 7, 8, 0, 32, 0, "%+d to Life" },
  { 9, 8, 0, 32, 0, "%+d to Mana" },
  { 11, 8, 0, 32, 0, "%+d to Maximum Stamina" },
  { 16, 9, 0, 0, 0, "%+d%% Enhanced Defense" },
  { 17, 9, 9, 0, 0, "%+d%% (& %d%%?) Enhanced Damage" },
  { 19, 10, 0, 0, 0, "%+d to Attack Rating" },
  { 20, 6, 0, 0, 0, "%d%% Increased Chance of Blocking" },
  { 21, 6, 0, 0, 0, "%+d to Minimum (one-handed?) Damage" },
  { 22, 7, 0, 0, 0, "%+d to Maximum (one-handed?) Damage" },
  { 23, 6, 0, 0, 0, "%+d to Minimum (two-handed?) Damage" },
  { 24, 7, 0, 0, 0, "%+d to Maximum (two-handed?) Damage" },
  { 27, 8, 0, 0, 0, "Regenerate Mana %d%%" },
  { 28, 8, 0, 0, 0, "Heal Stamina %d%%" },
  { 31, 10, 0, 10, 0, "%+d Defense" },
  { 32, 8, 0, 0, 0, "%+d Defense vs. Missile" },
  { 33, 8, 0, 0, 0, "%+d Defense vs. Melee" },
  { 34, 6, 0, 0, 0, "Damage Reduced by %d" },
  { 35, 6, 0, 0, 0, "Magic Damage Reduced by %d" },
  { 37, 8, 0, 0, 0, "Magic Resist %d%%??? (unsure)" },
  { 39, 8, 0, 0, 0, "Fire Resist %+d%%" },
  { 40, 5, 0, 0, 0, "%+d%% to Maximum Fire Resist" },
  { 41, 8, 0, 0, 0, "Lightning Resist %+d%%" },
  { 42, 5, 0, 0, 0, "%+d%% to Maximum Lightning Resist" },
  { 43, 8, 0, 0, 0, "Cold Resist %+d%%" },
  { 44, 5, 0, 0, 0, "%+d%% to Maximum Cold Resist" },
  { 45, 8, 0, 0, 0, "Poison Resist %+d%%" },
  { 46, 5, 0, 0, 0, "%+d%% to Maximum Poison Resist" },
  { 48, 8, 8, 0, 0, "Adds %d-%d fire damage" },
  { 49, 8, 0, 0, 0, "%+d to Maximum Fire Damage" },
  { 50, 6, 9, 0, 0, "Adds %d-%d Lightning Damage" },
  /* I have no idea whether this encoding is correct, but it looks like it has 4 fields: magic ID, minimum damage, maximum damage, length in 1/25ths of a second */
  /* { 54, 6, 8 *//* could be 6 or 7? *//*, 8, "Adds %d-%d cold damage" }, */
  /* I'm guessing that the total length of the fields is correct. */
  { 54, 6, 16, 0, 0, "Adds %d-%#x cold damage" },
  /* I have no idea how this in encoded yet, but I'm guessing it has 4 fields: magic ID, minimum damage, maximum damage, length in 1/25ths of a second */
  /* { 57, 9, 9, 8, "Adds %d-%d Poison Damage over %d seconds" }, */
  /* Since we appear to know the length of the above property, we'll fake it. */
  { 56, 8, 0, 0, 0, "(unknown - value is %d)" },
  { 57, 18, 8, 0, 0, "%#x poison damage over %d seconds" },
  { 60, 7, 0, 0, 0, "%d%% Life stolen per hit" },
  { 62, 7, 0, 0, 0, "%d%% Mana stolen per hit" },
  { 73, 8, 0, 0, 0, "%+d Maximum Durability" },
  { 74, 6, 0, 30, 0, "Replenish Life %+d" },
  { 75, 7, 0, 20, 0, "Increase Maximum Durability %d%%" },
  { 77, 6, 0, 10, 0, "Increase Maximum Mana %d%%" },
  { 78, 7, 0, 0, 0, "Attacker Takes Damage of %d" },
  { 79, 9, 0, 100, 0, "%d%% Extra Gold from Monsters" },
  { 80, 8, 0, 100, 0, "%d%% Better Chance of Getting Magic Items" },
  { 81, 7, 0, 0, 0, "Knockback (unsure; value=%d)" },
  { 83, 3, 0, 0, 0, "%+d to Amazon Skill Levels" },
  { 84, 3, 0, 0, 0, "%+d to Paladin Skill Levels" },
  { 85, 3, 0, 0, 0, "%+d to Necromancer Skill Levels" },
  { 86, 3, 0, 0, 0, "%+d to Sorceress Skill Levels" },
  { 87, 3, 0, 0, 0, "%+d to Barbarian Skill Levels" },
  { 89, 4, 0, 4, 0, "%+d to Light Radius" },
  { 91, 8, 0, 100, 0, "Requirements %+d%%" },
  { 93, 7, 0, 20, 0, "%d%% Increased Attack Speed" },
  { 96, 7, 0, 20, 0, "%d%% Faster Run/Walk" },
  { 99, 7, 0, 20, 0, "%d%% Faster Hit Recovery" },
  { 102, 7, 0, 20, 0, "%d%% Faster Block Rate" },
  { 105, 7, 0, 20, 0, "%d%% Faster Cast Rate" },
  { 107, 9, 5, 0, 0, "Skill 107:%d %+d" },
  { 108, 9, 5, 0, 0, "Skill 108:%d %+d" },
  { 109, 9, 5, 0, 0, "Skill 109:%d %+d" },
  { 110, 8, 0, 20, 0, "Poison Length Reduced by %d%%" },
  /* The following needs additional math; percentage is actually value / 127 */
  { 112, 7, 0, 0, 0, "Hit Causes Monster to Flee %d%%" },
  { 113, 7, 0, 0, 0, "Hit Blinds Target %+d" },
  { 114, 6, 0, 0, 0, "%d%% Damage Taken Goes to Mana" },
  { 115, 1, 0, 0, 0, "Ignore Target Defense" },
  { 116, 7, 0, 0, 0, "%d%% Target Defense" },
  { 117, 7, 0, 0, 0, "Prevent Monster Heal (unsure; value = %d)" },
  { 118, 1, 0, 0, 0, "Half Freeze Duration" },
  { 119, 9, 0, 20, 0, "%d%% Bonus to Attack Rating (119)" },
  { 120, 7, 0, 128, 0, "%d to Monster Defense Per Hit" },
  /* These two are duplicates of 242/244, because I'm not sure I had
     them at the correct bit offset. */
  { 121, 9, 0, 20, 0, "%+d%% Damage to Demons (unsure)" },
  { 122, 9, 0, 20, 0, "%+d%% Damage to Undead (unsure)" },
  { 123, 10, 0, 128, 0, "%+d to Attack Rating against Demons" },
  { 124, 10, 0, 128, 0, "%+d to Attack Rating against Undead" },
  { 126, 4, 0, 0, 0, "%+d to Fire Skills" },
  { 128, 5, 0, 0, 0, "Attacker Takes Lightning Damage of %d" },
  { 134, 5, 0, 0, 0, "Freezes Target" },
  { 135, 7, 0, 0, 0, "%d%% Chance of Open Wounds" },
  { 136, 7, 0, 0, 0, "%d%% Chance of Crushing Blow" },
  { 138, 7, 0, 0, 0, "%+d to Mana After Each Kill" },
  { 139, 7, 0, 0, 0, "%+d Life After Each Demon Kill" },
  { 140, 7, 0, 0, 0, "%d%% Extra Blood?" },
  { 141, 7, 0, 0, 0, "%d%% Deadly Strike" },
  { 150, 7, 0, 0, 0, "Slows Target by %d%%" },
  { 153, 1, 0, 0, 0, "Cannot Be Frozen" },
  { 156, 7, 0, 0, 0, "%d%% Piercing Attack?" },
  /* Found this once on an amulet, but all other magic properties were
     accounted for.  It followed 21:1 and 23:1 for minimum damage. */
  { 159, 6, 0, 0, 0, "%+d to Minimum (159?) Damage" },
  /* Found this once on a ring, but all other magic properties were
     accounted for.  It followed 22:1 and 24:1 for maximum damage. */
  { 160, 7, 0, 0, 0, "%+d to Maximum (160?) Damage" },
  /* No idea how this works yet; only found one example so far,
     and I'm not even sure I got the correct bitfield. */
  { 179, 3, 0, 0, 0, "%+d to Druid Skill Levels" },
  { 180, 3, 0, 0, 0, "%+d to Assassin Skill Levels" },
  { 188, 5, 5, 0, 0, "Skill %d: %+d (unsure)" },
  /* This appears to have 4 fields: magic ID, spell ID, level, chance to cast */
  { 195, 14, 7, 0, 0, "spell: %#x - %d%% Chance to cast on attack" },
  { 196, 14, 7, 0, 0, "spell: %#x - %d%% Chance to cast on attack" },
  /* This appears to have 4 fields: magic ID, spell ID, level, chance to cast */
  { 198, 14, 7, 0, 0, "spell: %#x - %d%% Chance to cast on striking" },
  { 199, 14, 7, 0, 0, "spell: %#x - %d%% Chance to cast on striking" },
  /* I have no idea how this in encoded yet, but I'm guessing it has 4 fields: magic ID, spell ID, level, chance to cast */
  /* { 201, 9, 5, 7, "%d Chance to cast level %d %s when struck" }, */
  /* Since we appear to know the length of the above property, we'll fake it. */
  { 201, 14, 7, 0, 0, "spell: %#x - %d%% Chance to Cast When Hit" },
  { 202, 14, 7, 0, 0, "spell: %#x - %d%% Chance to Cast When Hit" },
  /* This appears to have at least 4 fields, possibly 5: magic ID, spell ID, level, current charges, max. charges */
  /* { 204, 9, 5, 8, 8, "%s Level %d (%d/%d Charges)" */
  /* Since we appear to know the length of the above property, we'll fake it. */
  { 204, 14, 16, 0, 0, "spell: %#x (%#.4x Charges)" },
  { 205, 14, 16, 0, 0, "spell: %#x (%#.4x Charges)" },
  /* The following needs additional math; divide by 8 */
  { 214, 6, 0, 0, 0, "%+d/8 to Defense (Based on Character Level)" },
  { 216, 6, 0, 0, 0, "%+d/8 to Life (Based on Character Level)" },
  { 217, 6, 0, 0, 0, "%+d/8 to Mana (Based on Character Level)" },
  { 218, 6, 0, 0, 0, "%+d/8 to Maximum Damage (Based on Character Level)" },
  { 224, 6, 0, 0, 0, "%+d/8 to Attack Rating (Based on Character Level)" },
  { 225, 6, 0, 0, 0, "%d/8%% Bonus to Attack Rating (Based on Character Level)" },
  { 252, 5, 0, 0, 0, "Repairs %d durability per 100 seconds" },
  { 253, 5, 0, 0, 0, "Replenishes quantity" },
  { 254, 8, 0, 0, 0, "Increased Stack Size (by %d)" },
  { 0x1ff, 0, 0, 0, 0, "END OF LIST" },
};

/* Used in determining cast spells below */
extern const char * const class_names[];
extern struct {
  const char *label;
  long dont_care[2];
} skill_names[];
/* First sorceress skill in the above table */
#define SORC_FIRST_SKILL 30
/* Corresponds to skill number in magic properties;
   works for items that cast a spell when attacked */
#define SORC_SKILL_VALUE 36
/* First barbarian skill in the above table */
#define BARB_FIRST_SKILL 120
/* Corresponds to skill number in magic properties;
   works for items that increase a skill level */
#define BARB_SKILL_VALUE 126
/* First druid skill in the above table */
#define DRUID_FIRST_SKILL 150
/* Corresponds to skill number in magic properties;
   works for items that increase a skill level */
#define DRUID_SKILL_VALUE 221

/* Note: START is given in bits, LENGTH in bytes. */
void
dump_magic_data (unsigned char *data, int start, int length)
{
  int i, id, n = 0, value, value2;

  if (((struct item_data *) data)->attribute == 5)
    {
      /* Set items have another 5 bits of data before the magic begins */
      printf ("\t(2^Set properties)-1=%lu\n", read_bits (start, 5));
      start += 5;
    }

  /* Note: as of this point, LENGTH is
     the number of bits remaining after START. */
  length = (length * 8) - start;

  while (length >= 9)
    {
      id = read_bits (start, 9);
      start += 9;
      length -= 9;

      if (id == 0x1ff && (length < 8) && (read_bits (start, length) == 0))
	{
	  if (n)
	    printf ("List of %d properties is complete and appears valid.\n",
		    n);
	  return;
	}

      for (i = 0; (size_t) i < sizeof (magical_modifiers)
	     / sizeof (magical_modifiers[0]); i++)
	{
	  if (magical_modifiers[i].id == id)
	    break;
	}
      if ((size_t) i == sizeof (magical_modifiers)
	  / sizeof (magical_modifiers[0]))
	{
	  length += 9;
	  start -= 9;
	  printf ("Unknown magic property ID: %d;"
		  " aborting list with %d bits to go:\n", id, length);
	  while (length)
	    {
	      value = (data[start / 8] >> (start & 7)) & 1;
	      putchar ('0' + value);
	      start++;
	      length--;
	    }
	  putchar ('\n');
	  return;
	}

      n++;

      /* Handle expansion set magic properties specially */
      switch (id)
	{
	default:
	  value = (read_bits (start, magical_modifiers[i].data_len)
		   - magical_modifiers[i].bias);

	  if (magical_modifiers[i].data2_len)
	    {
	      value2 = (read_bits (start + magical_modifiers[i].data_len,
				   magical_modifiers[i].data2_len)
			- magical_modifiers[i].bias2);
	    }

	  putchar ('\t');
	  printf (magical_modifiers[i].name, value, value2);
	  putchar ('\n');
	  start += (magical_modifiers[i].data_len
		    + magical_modifiers[i].data2_len);
	  length -= (magical_modifiers[i].data_len
		     + magical_modifiers[i].data2_len);
	  break;

	case 54:
	  {
	    double secs;

	    value = read_bits (start, 6);
	    value2 = read_bits (start + 6, 8);
	    /* Note: I'm have no idea whether this offset is correct */
	    secs = read_bits (start + 14, 8) / 25.0;
	    if (value == value2)
	      printf ("\t%+d cold damage (for %g seconds)\n", value, secs);
	    else
	      printf ("\tAdds %d-%d cold damage (for %g seconds)\n",
		      value, value2, secs);
	    start += 22;
	    length -= 22;
	    break;
	  }

	case 57:
	  {
	    double mind, maxd, secs;
	    int tf;

	    /* Note: I think I finally figured out the interpretation!
	       The number represents 25/256 damage per second
	       (or 1/256 damage per unit of time, as stored in 1/25ths sec);
	       e.g., 14 would mean 14*25/256 = 1.3672 damage per second.
	       If the damage lasted 3 seconds, the total damage shown
	       would be 1.3672*3 = "+4 poison damage over 3 seconds".
	    */
	    value = read_bits (start, 9);
	    value2 = read_bits (start + 9, 9);
	    tf = read_bits (start + 18, 8);
	    secs = tf / 25.0;
	    /* Convert damage per second to total damage for the duration */
	    mind = value * tf / 256.0;
	    maxd = value2 * tf / 256.0;
	    if (value == value2)
	      printf ("\t+%.3g poison damage over %g seconds\n",
		      mind, secs);
	    else
	      printf ("\tAdds %.3g-%.3g poison damage over %g seconds\n",
		      mind, maxd, secs);
	    start += 26;
	    length -= 26;
	    break;
	  }

	case 107:
	  /* It looks like there is no difference between these three;
	     they're just used to either sort the labels or
	     make sure there's no more than three skills. */
	case 108:
	case 109:
	  {
	    int class;

	    value = read_bits (start, 9);
	    value2 = read_bits (start + 9, 5);
	    printf ("\t[%d%s] %+d to ", id - 106, (id == 107)
		    ? "st" : ((id == 108) ? "nd" : "rd"), value2);
	    /* Note: the range here is purely a guess; works for barbarian */
	    if ((value >= 6) && (value < 6 + 30 * 5))
	      {
		class = (value - 6) / 30;
		printf ("%s (%s Only)\n", skill_names[value - 6].label,
			class_names[class]);
	      }
	    else if ((value >= DRUID_SKILL_VALUE)
		     && (value < DRUID_SKILL_VALUE + 60))
	      {
		class = (value - DRUID_SKILL_VALUE) / 30 + 5;
		printf ("%s (%s Only)\n",
			skill_names[value - DRUID_SKILL_VALUE
				   + DRUID_FIRST_SKILL].label,
			class_names[class]);
	      }
	    else
	      {
		class = -1;
		printf ("{class-specific skill %d}\n", value);
	      }
	    start += 14;
	    length -= 14;
	    break;
	  }

	case 112:
	  value = read_bits (start, 7);
	  putchar ('\t');
	  printf (magical_modifiers[i].name, (value * 200 / 127 + 1) / 2);
	  putchar ('\n');
	  start += 7;
	  length -= 7;
	  break;

	case 188:
	  value = read_bits (start, 5);
	  value2 = read_bits (start + 5, 5);
	  printf ("\t%+d to ", value2);
	  switch (value) {
	  case 0:
	    printf ("Bow and Crossbow Skills (Amazon Only)\n");
	    break;
	  case 1:
	    printf ("Passive and Magic Skills (Amazon Only)\n");
	    break;
	  case 2:
	    printf ("Javelin and Spear Skills (Amazon Only)\n");
	    break;
	  case 3:
	    printf ("Fire Spells (Sorceress Only)\n");
	    break;
	  case 4:
	    printf ("Lightning Spells (Sorceress Only)\n");
	    break;
	  case 5:
	    printf ("Cold Spells (Sorceress Only)\n");
	    break;
	  case 6:
	    printf ("Curses (Necromancer Only)\n");
	    break;
	  case 7:
	    printf ("Poison and Bone Spells (Necromancer Only)\n");
	    break;
	  case 8:
	    printf ("Summoning Spells (Necromancer Only)\n");
	    break;
	  case 9:
	    printf ("Combat Skills (Paladin Only)\n");
	    break;
	  case 10:
	    printf ("Offensive Auras (Paladin Only)\n");
	    break;
	  case 11:
	    printf ("Defensive Auras (Paladin Only)\n");
	    break;
	  case 12:
	    printf ("Combat Skills (Barbarian Only)\n");
	    break;
	  case 13:
	    printf ("Combat Masteries (Barbarian Only)\n");
	    break;
	  case 14:
	    printf ("Warcries (Barbarian Only)\n");
	    break;
	  case 15:
	    printf ("Summoning Spells (Druid Only)\n");
	    break;
	  case 16:
	    printf ("Shape Shifting Spells (Druid Only)\n");
	    break;
	  case 17:
	    printf ("Elemental Spells (Druid Only)\n");
	    break;
	  case 18:
	    printf ("Traps (Assassin Only)\n");
	    break;
	  case 19:
	    printf ("Shadow Disciplines (Assassin Only)\n");
	    break;
	  case 20:
	    printf ("Martial Arts (Assassin Only)\n");
	    break;
	  default:
	    printf ("%d Skills (??? Only) (unsure)\n", value);
	    break;
	  }
	  start += 10;
	  length -= 10;
	  break;

	case 195:
	case 196:
	case 198:
	case 199:
	case 201:
	case 202:
	  {
	    int chance, level;

	    value = read_bits (start, 9);
	    level = read_bits (start + 9, 5);
	    chance = read_bits (start + 14, 7);
	    printf ("\t%d%% Chance to cast level %d ", chance, level);
	    if ((value >= 6) && (value < 6 + 30 * 5))
	      printf (skill_names[value - 6].label);
	    else
	      printf ("spell %d", value);
	    switch (id) {
	    case 195:
	    case 196: printf (" on attack\n"); break;
	    case 198:
	    case 199: printf (" on striking\n"); break;
	    case 201:
	    case 202: printf (" when struck\n"); break;
	    }
	    start += 21;
	    length -= 21;
	    break;
	  }

	case 204:
	case 205:
	  {
	    int spell, level;

	    spell = read_bits (start, 9);
	    level = read_bits (start + 9, 5);
	    value = read_bits (start + 14, 8);
	    value2 = read_bits (start + 22, 8);
	    printf ("\tlevel %d ", level);
	    if ((spell >= 6) && (spell < 6 + 30 * 5))
	      printf (skill_names[spell - 6].label);
	    else if ((spell >= 221) && (spell < 221 + 30 * 2))
	      printf (skill_names[spell - 221 + 30 * 5].label);
	    else
	      printf ("spell %d", spell);
	    printf (" (%d/%d Charges)\n", value, value2);
	    start += 30;
	    length -= 30;
	    break;
	  }

	case 252:
	  value = read_bits (start, 5);
	  printf ("\tRepairs 1 durability in %d seconds\n", 100 / value);
	  start += 5;
	  length -= 5;
	  break;

	case 253:
	  value = read_bits (start, 5);
	  /* I'm guessing at this, since the value isn't displayed. */
	  printf ("\tReplenishes quantity (1 every %d seconds)\n",
		  100 / value);
	  start += 5;
	  length -= 5;
	  break;
	}
    }
}

/* Table of rare names */
const char * const rare_name[] = {
  "" /* unused */,
  /* Suffixes */
  "Bite",	"Scratch",	"Scalpel",	"Fang",
  "Gutter",	"Thirst",	"Razor",	"Scythe",
  "Edge",	"Saw",		"Splitter",	"Cleaver",
  "Sever",	"Sunder",	"Rend",		"Mangler",
  "Slayer",	"Reaver",	"Spawn",	"Gnash",
  "Star",	"Blow",		"Smasher",	"Bane",
  "Crusher",	"Breaker",	"Grinder",	"Crack",
  "Mallet",	"Knell",	"Lance",	"Spike",
  "Impaler",	"Skewer",	"Prod",		"Scourge",
  "Wand",	"Wrack",	"Barb",		"Needle",
  "Dart",	"Bolt",		"Quarrel",	"Fletch",
  "Flight",	"Nock",		"Horn",		"Stinger",
  "Quill",	"Goad",		"Branch",	"Spire",
  "Song",	"Call",		"Cry",		"Spell",
  "Chant",	"Weaver",	"Gnarl",	"Visage",
  "Crest",	"Circlet",	"Veil",		"Hood",
  "Mask",	"Brow",		"Casque",	"Visor",
  "Cowl",	"Hide",		"Pelt",		"Carapace",
  "Coat",	"Wrap",		"Suit",		"Cloak",
  "Shroud",	"Jack",		"Mantle",	"Guard",
  "Badge",	"Rock",		"Aegis",	"Ward",
  "Tower",	"Shield",	"Wing",		"Mark",
  "Emblem",	"Hand",		"Fist",		"Claw",
  "Clutches",	"Grip",		"Grasp",	"Hold",
  "Touch",	"Finger",	"Knuckle",	"Shank",
  "Spur",	"Tread",	"Stalker",	"Greave",
  "Blazer",	"Nails",	"Trample",	"Brogues",
  "Track",	"Slippers",	"Clasp",	"Buckle",
  "Harness",	"Lock",		"Fringe",	"Winding",
  "Chain",	"Strap",	"Lash",		"Cord",
  "Knot",	"Circle",	"Loop",		"Eye",
  "Turn",	"Spiral",	"Coil",		"Gyre",
  "Band",	"Whorl",	"Talisman",	"Heart",
  "Noose",	"Necklace",	"Collar",	"Beads",
  "Torc",	"Gorget",	"Scarab",	"Wood",
  "Brand",	"Bludgeon",	"Cudgel",	"Loom",
  "Harp",	"Master",	"Barri",	"Hew",
  "Crook",	"Mar",		"Shell",	"Stake",
  "Picket",	"Pale",		"Flange",
  /* Prefixes */
  "Beast",	"Eagle",	"Raven",	"Viper",
  "Ghoul",	"Skull",	"Blood",	"Dread",
  "Doom",	"Grim",		"Bone",		"Death",
  "Shadow",	"Storm",	"Rune",		"Plague",
  "Stone",	"Wraith",	"Spirit",	"Storm",
  "Demon",	"Cruel",	"Empyrian",	"Bramble",
  "Pain",	"Loath",	"Glyph",	"Imp",
  "Fiend",	"Hailstone",	"Gale",		"Dire",
  "Soul",	"Brimstone",	"Corpse",	"Carrion",
  "Armageddon",	"Havoc",	"Bitter",	"Entropy",
  "Chaos",	"Order",	"Rule",		"Warp",
  "Rift",	"Corruption",
  /* Unused */
  " 202", " 203", " 204", " 205", " 206", " 207", " 208", " 209",
  " 210", " 211", " 212", " 213", " 214", " 215", " 216", " 217",
  " 218", " 219", " 220", " 221", " 222", " 223", " 224", " 225",
  " 226", " 227", " 228", " 229", " 230", " 231", " 232", " 233",
  " 234", " 235", " 236", " 237", " 238", " 239", " 240", " 241",
  " 242", " 243", " 244", " 245", " 246", " 247", " 248", " 249",
  " 250", " 251", " 252", " 253", " 254", " 255",
};

/* Print the extra data associated with a modified item.
   Returns the (guestimated) starting bit number of the item-specific data. */
int
dump_magic_prefix (const char *name, unsigned char *data, int length)
{
  struct item_data *item = (struct item_data *) data;
  int start = 155;	/* bit following the item->is_ring bit */
  int v, n;
  table_entry_t entry;

  printf (" unique-ID:%.4lx%.4lx level:%ld",
	  read_bits (127, 16), read_bits (111, 16), read_bits (143, 7));

  if (item->is_ring)
    {
      n = read_bits (start, 3);
      start += 3;
      switch (item->type)
	{
	default:
	  printf (" (%s picture: %d)", name, n);
	  break;

	case 'a':
	  switch (n)
	    {
	    case 0:
	      printf (" (amulet picture 0: gold disc w/ cross)");
	      break;
	    case 1:
	      printf (" (amulet picture 1: gold hexagon w/ face)");
	      break;
	    case 2:
	      printf (" (amulet picture 2: red laquered pentagram)");
	      break;
	    default:
	      printf (" (amulet picture: %d)", n);
	      break;
	    }
	  break;

	case 'c':
	  switch ((item->variant - '0') * 10 + n)
	    {
	    case 12:
	      printf (" (small charm picture 2: twin flags on white disc)");
	      break;
	    case 20:
	      printf (" (large charm picture 0: leaf of parchment)");
	      break;
	    case 22:
	      printf (" (large charm picture 2: yellow box w/ tapered top)");
	      break;
	    default:
	      printf (" (charm picture: %c%d)", item->variant, n);
	      break;
	    }
	  break;

	case 'j':
	  switch (n)
	    {
	    case 4:
	      printf (" (jewel picture 4: red)");
	      break;
	    default:
	      printf (" (jewel picture: %d)", n);
	      break;
	    }
	  break;

	case 'r':
	  switch (n)
	    {
	    case 0:
	      printf (" (ring picture 0: dark pearl on thin silver band)");
	      break;
	    case 1:
	      printf (" (ring picture 1: small blue gem)");
	      break;
	    case 2:
	      printf (" (ring picture 2: flat blue rectangular stone)");
	      break;
	    case 3:
	      printf (" (ring picture 3: tear-shaped red stone)");
	      break;
	    case 4:
	      printf (" (ring picture 4: spiked band w/ red bubble)");
	      break;
	    default:
	      printf (" (ring picture: %d)", n);
	      break;
	    }
	  break;
	}
    }

  /* I've unified the next bit.  If the next bit is set, it is
     followed by an additional 11-bit field (for expansion items with
     inherent magic). */
  if (read_bits (start, 1))
    {
      printf (" inherent magic: %ld", read_bits (start + 1, 11));
      start += 12;
    } else {
      start += 1;
    }

  putchar ('\n');

  switch (item->attribute)
    {
    case 0:
      printf (" (?0?) %s", name);
      /* Guessing there's no additional data; haven't recorded any examples */
      break;

    case 1:
      if (read_bits (start + 2, 1))
	printf (" %ld (%s?) %s", read_bits (start, 3),
		low_quality_names[read_bits (start, 2)], name);
      else
	printf (" %s %s", low_quality_names[read_bits (start, 2)], name);
      start += 3;
      break;

    case 2:
      printf (" %s", name);
      break;

    case 3:
      printf (" Superior (%ld) %s", read_bits (start, 3), name);
      start += 3;
      break;

    case 4:
      /* Standard magic items always have a prefix field and a suffix field,
	 which appear to be 11 bits each. */
      n = read_bits (start, 11);
      if (n)
	{
	  entry = LookupIndexedTableEntry ("magicprefix", n);
	  if (entry == NULL)
	    printf (" prefix %d", n);
	  else
	    printf (" %s", GetEntryStringField (entry, "Name"));
	}
      start += 11;
      printf (" %s", name);
      n = read_bits (start, 11);
      if (n)
	{
	  entry = LookupIndexedTableEntry ("magicsuffix", n);
	  if (entry == NULL)
	    printf (" of suffix %d", n);
	  else
	    printf (" %s", GetEntryStringField (entry, "Name"));
	}
      start += 11;
      break;

    case 5:
      n = read_bits (start, 12);
      entry = LookupIndexedTableEntry
	("setitems", (start < 32) ? start : (start + 1));
      if (entry == NULL)
	printf (" %s (part of set #%d)", name, n);
      else
	printf (" %s (%s part of a set)",
		GetEntryStringField (entry, "Name"), name);
      start += 12;
      break;

    case 6:
      /* Rare item; there are a variable number of bits. */
      printf (" %s %s %s", rare_name[read_bits (start, 8)],
	      rare_name[read_bits (start + 8, 8)], name);
      start += 16;
      /* There are 6 optional fields following */
      printf (" w/ extended data:");
      for (n = 0; n < 6; n++)
	{
	  if (read_bits (start, 1)) {
	    printf (" %ld", read_bits (start + 1, 11));
	    start += 12;
	  } else {
	    printf (" 0");
	    start += 1;
	  }
	}
      break;

    case 7:
      n = read_bits (start, 12);
      entry = LookupIndexedTableEntry ("uniqueitems", n);
      if (entry == NULL)
	printf (" %s (unique item #%d)", name, n);
      else
	printf (" %s (unique %s)",
		GetEntryStringField (entry, "name"), name);
      start += 12;
      break;

    case 8:
      printf (" %s %s %s (Crafted!)\n",
	      rare_name[read_bits (start, 8)],
	      rare_name[read_bits (start + 8, 8)], name);
      start += 16;
      /* There are 6 optional fields following */
      printf (" w/ extended data:");
      for (n = 0; n < 6; n++)
	{
	  if (read_bits (start, 1)) {
	    printf (" %ld", read_bits (start + 1, 11));
	    start += 12;
	  } else {
	    printf (" 0");
	    start += 1;
	  }
	}
      break;
    }

  if (item->runeworded)
    {
      n = read_bits (start, 16) - 0x501a;
      printf (" Rune Word #%d", (n < 80) ? n : (n + 1));
      start += 16;
    }

  if (item->personalized)
    {
      printf (" personalized by ");
      for (n = 0; n < 16; n++)
	{
	  v = read_bits (start, 7);
	  start += 7;
	  if (!v)
	    break;
	  putchar (v);
	}
      if (v) {
	printf ("\n WARNING: owner name corrupted, unterminated, or too long;\n"
		" the rest of the item description is invalid\n");
	dump_bit_data (data, start, length * 8 - start);
      }
    }

  if (read_bits (start, 1)) {
    printf ("\n WARNING: bit after the quality data is 1;\n"
	    " the rest of the item description is invalid\n");
    /* Dump the bits */
    dump_bit_data (data, start, length * 8 - start);
  }
  start += 1;
  return start;
}

/* Print the extra data associated with a ring, amulet, charm, or jewel */
void
dump_ring_data (const char *name, unsigned char *data, int length)
{
  struct item_data *item = (struct item_data *) data;
  int start = -1;

  printf ("Next item \"%c%c%c%c\" looks like a %s:", item->type,
	  item->subtype, item->variant, item->unknownc_4, name);
  dump_raw_data (data, length);
  if (!item->identified)
    printf (" (Unidentified)");
  start = dump_magic_prefix (name, data, length);
  print_location (item);
  if (start >= 0)
    dump_magic_data (data, start, length);
}
