/* Definition of C++ classes that hold an internal representation
 * of the quality setting of Diablo II v1.09 items.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef D2SQUALITY_H
#define D2SQUALITY_H

#ifndef __cplusplus
#error "You need a C++ compiler to use this module"
#endif

#include <stddef.h>
#include <stdint.h>
#include "internal.h"
#include "tables.h"

/* Extended item quality ratings: */
typedef enum {
  LOW_QUALITY = 1, NORMAL_QUALITY, HIGH_QUALITY, MAGIC_QUALITY,
  PART_OF_A_SET, RARE_QUALITY, UNIQUE_QUALITY, CRAFTED_QUALITY
} item_quality_t;

/* Forward declarations of classes used or defined by d2sQuality */
class d2sExtendedItem;
class d2sMagic;

class d2sQuality;
class d2sLowQuality;
class d2sHighQuality;
class d2sMagicalQuality;
class d2sQPartOfASet;
class d2sRareQuality;
class d2sUniqueQuality;
class d2sCraftedQuality;


/* Read the bit stream of an item and
   call the appropriate quality constructor */
d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t item);


/****************    QUALITY SUPERCLASS    ****************/

/* This first class is the superclass used to interface with the
   quality settings.  Virtual functions are defined here that work
   regardless of the specifics of the item quality.  This class is
   also used to instantiate normal quality items, which have no
   additional quality data. */
class d2sQuality {
  /* This function alone may construct
     new quality objects from a bit stream. */
  friend d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t);

 public:
  /********	FILE-RELATED FUNCTIONS:		********/

  d2sQuality (void);			// Create a new normal quality
  d2sQuality (table_entry_t);		// '' and assign item-specific members
  virtual d2sQuality *Copy (void);	// Copy an existing quality

  /* Associate this quality with a specific item.
     The quality needs to look up its parent item on occasion
     for checking whether certain changes are legal. */
  virtual void	SetItem (d2sExtendedItem *);
  virtual void	SetItem (table_entry_t);

  /* Return the item associated with this quality */
  d2sExtendedItem *Item (void) const { return my_item; }

  /* Write a quality record out to a raw bit stream. */
  void		Write (struct bit_stream *);

  /* Return a string describing the latest error condition */
  const char *	GetErrorMessage (void) const { return error_str; }

  /********	DATA RETRIEVAL FUNCTIONS	********/

  /* Return the quality of an item as a number */
  item_quality_t QualityClass (void) const { return quality_class; }

  /* Qualify an item's name, returning a newly allocated string */
  virtual char *QualifyName (const char *base_name) const;

  /* Return any additional level requirement imposed by its quality */
  int		RequiredLevel (void) const { return required_level; }

  /* Return whether the quality setting... */
  int		has_a_picture (void) const { return picture_bit; }
  int		has_an_11_bit_field (void) const { return unknown11_bit; }
  int		is_colored (void) const { return (color_code != NULL); }
  int		is_expansion (void) const { return expansion_mods; }

  /* If the quality includes a picture field, return its value. */
  unsigned int	Picture (void) const { return picture; }
  unsigned int	NumPictures (void) const { return num_pictures; }

  /* If the quality includes an unknown 11-bit field, return its value. */
  unsigned int	Unknown11 (void) const { return unknown11; }

  /* If the quality includes a color transformation,
     return the color code.  Otherwise return NULL. */
  const char *	Color (void) const { return color_code; }

  /********	DATA MODIFICATION FUNCTIONS	********/

  /* If the quality includes a picture field, change its value. */
  int		ChangePicture (unsigned int new_pic);

  /* If the quality includes an 11-bit unknown field, change its value. */
  int		SetUnknown11 (unsigned int new_uk11);

  /* Whenever a quality setting changes (or a new quality is created),
     the quality should recompute the magic properties assigned to an item. */
  virtual void	RegenerateProperties (d2sMagic *, int condense = 1);

 protected:
  /* Create a new quality object using data from the given bit stream. */
  d2sQuality (struct bit_stream *, table_entry_t item_entry = NULL);

  /* Read a quality record in from a raw bit stream.
     The bit stream will be updated. */
  int		Read (struct bit_stream *);

  /* Copy the base class fields from another quality object.
     All virtual Copy() functions call this. */
  d2sQuality&	operator= (const d2sQuality &);

  /* Read in the quality-specific fields.  All derived classes
     need to implement this.  Gets called between reading the 11-bit
     unknown field and the end bit. */
  virtual void	ReadQualitySpecificData (struct bit_stream *bstream)
    { return; /* Normal quality items have no quality-specific field */ }

  /* Write out the quality-specific fields.  All derived classes
     need to implement this.  Gets called between writing the 11-bit
     unknown field and the end bit. */
  virtual void	WriteQualitySpecificData (struct bit_stream *bstream)
    { return; /* Normal quality items have no quality-specific field */ }

  /* Return whether the owner of a quality is read-only. */
  int		read_only (void) const;

  /* Most derived classes should implement this.
     After a quality has been read or modified,
     update the required level and color code. */
  virtual void	UpdateRequired (void)
    { return; } /* The default instance doesn't have any update */

  const char *	error_str;	// Last error encountered
  item_quality_t quality_class; // Item quality
  int		required_level; // Any additional level requirement imposed
  const char *	color_code;	// Any color transformation to be applied
  d2sExtendedItem *my_item;	// The item we belong to
  const char *	item_code;	// Code for the item we (will) belong to
  table_entry_t item_type_entry; // Table entry for the item's type
  uint8_t	expansion_mods; // Quality's mods are expansion-specific

  /* This bit indicates whether a picture field is present. */
  uint8_t	picture_bit:1;
  /* This bit indicates whether an 11-bit unknown field is present. */
  uint8_t	unknown11_bit:1;

  uint8_t	picture;	// 3-bit picture number
  uint8_t	num_pictures;	// Number of available pictures
  uint16_t	unknown11;	// 11-bit field (unknown)

 private:
  /* Initialize the base class fields.  Called by several constructors. */
  void Init (void);
};


/****************    SUBCLASSES    ****************/

/* Return the name of a low quality grade given its number */
const char *GetLowQualityGradeName (int);

/* A low quality item adds a grade.
   Somehow it also alters the base damage of weapons, but I don't see how... */
class d2sLowQuality : public d2sQuality {
  /* This function alone may construct new quality objects. */
  friend d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t);

 public:
  d2sLowQuality (void);			// Create a new low quality
  virtual d2sQuality *Copy (void);	// Copy an existing quality
  d2sLowQuality& operator= (const d2sLowQuality &);
  virtual void	ReadQualitySpecificData (struct bit_stream *);
  virtual void	WriteQualitySpecificData (struct bit_stream *);
  virtual char *QualifyName (const char *base_name) const;

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the current grade as a number */
  int		Grade (void) const { return grade; }

  /* Get the current grade as a string */
  const char *	GradeName (void) const
    { return GetLowQualityGradeName (grade); }

  /* Change the grade of the low quality item */
  int		ChangeGrade (int new_grade);

 private:
  /* Create a new low quality object using data from the given bit stream. */
  d2sLowQuality (struct bit_stream *, table_entry_t item_entry = NULL);

  int		grade;		// Grade (crude, cracked, damaged, ...)
};


/* A high quality item adds a grade ... I think.  I've never actually
   seen any high-quality item referred to as anything but "Superior".
   Somehow it also alters the base damage of weapons, but I don't see how... */
class d2sHighQuality : public d2sQuality {
  /* This function alone may construct new quality objects. */
  friend d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t);

 public:
  d2sHighQuality (void);		// Create a new high quality
  virtual d2sQuality *Copy (void);	// Copy an existing quality
  d2sHighQuality& operator= (const d2sHighQuality &);
  virtual void	ReadQualitySpecificData (struct bit_stream *);
  virtual void	WriteQualitySpecificData (struct bit_stream *);
  virtual char *QualifyName (const char *base_name) const;
  virtual void	RegenerateProperties (d2sMagic *, int condense = 1);

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the current grade as a number */
  int		Grade (void) const { return grade; }

  /* Get the current grade as a string ("Superior") */
  const char *	GradeName (void) const;

  /* Change the grade of the high quality item */
  int		ChangeGrade (int new_grade);

 private:
  /* Create a new high quality object using data from the given bit stream. */
  d2sHighQuality (struct bit_stream *, table_entry_t item_entry = NULL);

  int		grade;		// Grade (crude, cracked, damaged, ...)
};


/* A magically enhanced item adds a prefix and/or a suffix. */
class d2sMagicalQuality : public d2sQuality {
  /* This function alone may construct new quality objects. */
  friend d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t);

 public:
  d2sMagicalQuality (void);		// Create a new magical quality
  d2sMagicalQuality (table_entry_t);	// Create a default magical quality
					//  valid for a given item
  virtual d2sQuality *Copy (void);	// Copy an existing quality
  d2sMagicalQuality& operator= (const d2sMagicalQuality &);
  virtual void	ReadQualitySpecificData (struct bit_stream *);
  virtual void	WriteQualitySpecificData (struct bit_stream *);
  virtual char *QualifyName (const char *base_name) const;
  virtual void	RegenerateProperties (d2sMagic *, int condense = 1);

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the numeric ID of the prefix */
  int		PrefixID (void) const { return prefix; }

  /* Get the numeric ID of the suffix */
  int		SuffixID (void) const { return suffix; }

  /* Get the prefix as a string */
  const char *	Prefix (void) const;

  /* Get the suffix as a string */
  const char *	Suffix (void) const;

  /* Change the item's prefix.  Need not be predefined. */
  int		ChangePrefix (int = 0);

  /* Change the item's suffix.  Need not be predefined. */
  int		ChangeSuffix (int = 0);

  /* Change the item's prefix.  Needs to be predefined,
     and valid for the type of object being modified. */
  int		ChangePrefix (const char *);

  /* Change the item's suffix.  Needs to be predefined,
     and valid for the type of object being modified. */
  int		ChangeSuffix (const char *);

 protected:
  /* Update the required level and color based on the prefix and suffix */
  virtual void	UpdateRequired (void);

 private:
  /* Create a new magically enhanced quality
     using data from the given bit stream. */
  d2sMagicalQuality (struct bit_stream *, table_entry_t item_entry = NULL);

  /* Validate a prefix or suffix when changing.
     Returns the table entry for the prefix or suffix, or NULL on error. */
  table_entry_t validate_xfix (int id, const char *table_name,
			       const char *Xfix);

  int		prefix;
  int		suffix;

  /* Table entries for the prefix and suffix */
  table_entry_t prefix_entry;
  table_entry_t suffix_entry;
};


/* A set item adds the ID of the set this object belongs to. */
class d2sQPartOfASet : public d2sQuality {
  /* This function alone may construct new quality objects. */
  friend d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t);

 public:
  d2sQPartOfASet (void);		// Create a new set quality
  d2sQPartOfASet (int, table_entry_t item_entry); // Create a specific set item
  virtual d2sQuality *Copy (void);	// Copy an existing quality
  d2sQPartOfASet& operator= (const d2sQPartOfASet &);

  /* Set the type of item this quality is associated with.
     Overridden so that we can identify members of a set. */
  virtual void	SetItem (d2sExtendedItem *);
  virtual void	SetItem (table_entry_t);

  virtual void	ReadQualitySpecificData (struct bit_stream *);
  virtual void	WriteQualitySpecificData (struct bit_stream *);
  virtual char *QualifyName (const char *base_name) const;
  virtual void	RegenerateProperties (d2sMagic *, int condense = 1);

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the numeric ID of the set */
  int		SetID (void) const { return set_id; }

  /* Get the name of the set */
  const char *	SetName (void) const { return set_name; }

  /* Get the number of items in the same set as this one */
  int		NumberOfItemsInSet (void) const { return num_members; }

  /* Get the name of the Nth member of the set.
     With no argument, the name of this member. */
  const char *	GetMemberName (int n = -1) const;

  /* Get / change the value of the 5-bit field
     following the item-specific data (set count?) */
  int		GetSetCount (void) const { return set_count; }
  int		SetSetCount (void);
  /* ***WARNING*** This should *only* be called when reading
     the number from a file.  NO VALIDITY CHECKING IS IMPLEMENTED! */
  int		SetSetCount (int);

 protected:
  /* Update the required level and color based on the set */
  virtual void	UpdateRequired (void);

  /* Find the set member based on the item type */
  void		LookupMember (void);

 private:
  /* Create a new part of a set using data from the given bit stream. */
  d2sQPartOfASet (struct bit_stream *, table_entry_t item_entry = NULL);

  int		set_id;		// The Diablo ID of the set
  int		set_count;	// The 5-bit field following item-specific data
  table_entry_t set_entry;	// Set's entry in the "setitems" table
  int		member_index;	// Index of this item in the "setitems" entry
  int		num_members;	// Number of items in the set
  const char *	set_name;	// The name of the set this item belongs to
  const char *	member_name;	// The member name of this item
};


/* A rare item includes a two-word title and
   6 optional hidden prefixes/suffixes. */
class d2sRareQuality : public d2sQuality {
  /* This function alone may construct new quality objects. */
  friend d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t);

 public:
  d2sRareQuality (void);		// Create a new rare quality
  d2sRareQuality (table_entry_t item_entry); // Create a default rare quality
					//  valid for a given item
  virtual d2sQuality *Copy (void);	// Copy an existing quality
  d2sRareQuality& operator= (const d2sRareQuality &);
  virtual void	ReadQualitySpecificData (struct bit_stream *);
  virtual void	WriteQualitySpecificData (struct bit_stream *);
  virtual char *QualifyName (const char *base_name) const;
  virtual void	RegenerateProperties (d2sMagic *, int condense = 1);

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the numeric ID of the first or second word of the title */
  int		TitleID1 (void) const { return title_id[0]; }
  int		TitleID2 (void) const { return title_id[1]; }

  /* Get the first or second word of the title as a string */
  const char *	Title1 (void) const;
  const char *	Title2 (void) const;

  /* Get the numeric ID of one of the hidden fields */
  int		HiddenFieldID (int n) const { return hidden[n]; }

  /* Get one of the hidden fields as a string */
  const char *	HiddenField (int n) const;

  /* Change the first or second word of the title.  The value need not
     be predefined, but it is restricted to be between the first and
     last defined ID's (i.e., you can only select holes). */
  int		ChangeTitle (int id1, int id2);
  int		ChangeTitle1 (int id)
    { return ChangeTitle (id, title_id[1]); }
  int		ChangeTitle2 (int id)
    { return ChangeTitle (title_id[0], id); }

  /* Change any of the hidden fields. */
  int		ChangeHiddenField (int field, int data);
  int		ChangeHiddenField (int field, const char *);

 private:
  /* Create a new rare quality using data from the given bit stream. */
  d2sRareQuality (struct bit_stream *, table_entry_t item_entry = NULL);

  /* Choose a prefix/suffix for one of the hidden names.
     Similar to d2sMagicalQuality::d2sMagicalQuality(table_entry_t),
     but restricts names to rare ones, and checks for duplicates. */
  int		GenerateHiddenName (void);

 protected:
  /* Update the required level and color based on the hidden fields */
  virtual void	UpdateRequired (void);

  uint8_t	title_id[2];
  uint16_t	hidden[6];
  /* Table entries for the hidden names */
  table_entry_t hidden_entry[6];
};


/* A unique item adds the ID of the item. */
class d2sUniqueQuality : public d2sQuality {
  /* This function alone may construct new quality objects. */
  friend d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t);

 public:
  d2sUniqueQuality (void);		// Create a new unique quality
  d2sUniqueQuality (int, table_entry_t item_entry); // Create a specific item
  virtual d2sQuality *Copy (void);	// Copy an existing quality
  d2sUniqueQuality& operator= (const d2sUniqueQuality &);
  virtual void	ReadQualitySpecificData (struct bit_stream *);
  virtual void	WriteQualitySpecificData (struct bit_stream *);
  virtual char *QualifyName (const char *base_name) const;
  virtual void	RegenerateProperties (d2sMagic *, int condense = 1);

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the numeric ID of the unique attribute
     (Note that this is -1 for some items) */
  int		UniqueID (void) const { return unique_id; }

  /* Get the unique part of the item name */
  const char *	UniqueName (void) const { return unique_name; }

  /* Change one unique item into another.  There are, of course,
     restrictions.  The parent item must match the new unique's item. */
  int		ChangeUnique (int);

 protected:
  /* Update the required level and color based on the unique item */
  virtual void	UpdateRequired (void);

 private:
  /* Create a new unique quality using data from the given bit stream. */
  d2sUniqueQuality (struct bit_stream *, table_entry_t item_entry = NULL);

  int		unique_id;
  const char *	unique_name;	// The name of this item
  table_entry_t unique_entry;	// Item's entry in the "uniqueitems" table
};


/* A crafted item is almost exactly like a rare item;
   the only difference is the color of the name, and that
   it includes some inherent magic properties. */
class d2sCraftedQuality : public d2sRareQuality {
  /* This function alone may construct new quality objects. */
  friend d2sQuality *ReadQualityFromItem (struct bit_stream *, table_entry_t);

 public:
  d2sCraftedQuality (void);		// Create a new crafted quality
  d2sCraftedQuality (table_entry_t item_entry);	// Create a def. crafted qual.
					//  valid for a given item
  virtual d2sQuality *Copy (void);	// Copy an existing quality
  d2sCraftedQuality& operator= (const d2sCraftedQuality &source);
  virtual void	RegenerateProperties (d2sMagic *, int condense = 1);

  /* Set the type of item this quality is associated with.
     Overridden so that we can figure out how this item was made. */
  virtual void	SetItem (d2sExtendedItem *);
  virtual void	SetItem (table_entry_t);

 protected:
  /* Update the required level and color based on the hidden fields */
  virtual void	UpdateRequired (void);

 private:
  /* Create a new crafted quality using data from the given bit stream. */
  d2sCraftedQuality (struct bit_stream *bstream,
		     table_entry_t item_entry = NULL);

  /* In order to regenerate magic properties correctly when a
     variable hidden name is changed, we need some idea of which
     recipe was used to craft this item. */
  void		find_craft_entry (void);

  table_entry_t craft_entry;
};


#endif /* D2SQUALITY_H */
