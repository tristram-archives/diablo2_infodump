/* d2sItem -- C++ class that holds an internal representation
 *	      of a Diablo II v1.09 item.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include "functions.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sMagic.h"
#include <dmalloc.h>

/************************** FUNCTIONS ***************************/

/* Forward declarations */
static d2sItem *guess_item_type (struct item_header *item_data);


/**************** ITEM CONSTRUCTION ****************
 *
 * As the saved character file is parsed, this function
 * is called to create instances of various items.
 * It takes the item ID, looks it up in the item tables,
 * and calls the constructor for that item type.
 ***************************************************/

static d2sItem *
guess_item_type (struct item_header *item_data)
{
  if ((*((short *) &item_data[1].magic[0]) == *((short *) &"JM"))
      || (*((short *) &item_data[1].magic[0]) == *((short *) &"jf"))
      || (*((short *) &item_data[1].magic[0]) == *((short *) &"kf")))
    /* This is a simple item.  Create a simple unknown. */
    return new d2sItem ();

  /* Check whether the item has gems attached.
     If so, we *must* construct a d2sDurableItem
     in order to save the gems. */
  else if (item_data->gem_count)
    return new d2sDurableItem ();

  /* Otherwise, we have no idea what type of item we have.
     Make a general extended unknown item. */
  else
    return new d2sExtendedItem ();
}

d2sItem *
ReadItemFromFile (struct data_stream *dstream)
{
  struct item_header *item_data = (struct item_header *) dstream->ptr;
  item_id_t item_id;
  table_entry_t item_entry;
  const char *item_type, *item_name;
  d2sItem *new_item;

  /* Check the item header */
  if (*((short *) &item_data->magic[0]) != *((short *) &"JM"))
    {
      print_message ("Bad item data at offset %#x\n",
		     dstream->ptr - dstream->base);
      return NULL;
    }

  /* Extract the item ID */
  item_id.id = item_data->item_ID;
  if (!isalnum (item_id.ch[0]) || !isalnum (item_id.ch[1])
      || !isalnum (item_id.ch[2]) || (item_data->ID_space != ' '))
    {
      print_message ("Bad item data at offset %#x (invalid code"
		     " %#.2x %#.2x %#.2x)\n",
		     dstream->ptr - dstream->base,
		     item_id.ch[0], item_id.ch[1], item_id.ch[2]);
      return NULL;
    }

  /* Get the item's name in case we need to display any messages */
  item_name = TranslateString (item_id.ch);

  /* Find the corresponding entry in one of the item tables */
  item_entry = LookupTableEntry ("misc", "code", item_id.ch);
  if (item_entry == NULL) {
    item_entry = LookupTableEntry ("armor", "code", item_id.ch);
    if (item_entry == NULL) {
      item_entry = LookupTableEntry ("weapons", "code", item_id.ch);
      if (item_entry == NULL) {
	/* Unknown item!  Dare we guess what it is? */
	print_message ("Unknown item code at offset %#x: \"%3.3s\" (%s)\n",
		       dstream->ptr - dstream->base, item_id.ch, item_name);
	new_item = guess_item_type (item_data);
	goto read_the_item;
      }
    }
  }

  /* Get the item's type to determine which constructor to call */
  item_type = GetEntryStringField (item_entry, "type");
  if (item_type[0] == 0) {
    /* Oops! Missing the type field in the item table! */
    print_message ("Item \"%s\" does not have a 'type' entry"
		   " in the data tables\n", item_name);
    new_item = guess_item_type (item_data);
  }

  /* We can divide the possible classes in two by looking at the
     'simple' bit.  (It's a copy of "compactsave" in the item tables.)  */
  if (item_data->simple)
    {
      if (IsTypeAMemberOf (item_type, "gem")) {
	new_item = new d2sGemItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "poti")) {
	/* NOTICE: We need to redo this class, because
	   scrolls can also be placed in the belt. */
	new_item = new d2sPotionItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "rune")) {
	new_item = new d2sRuneItem (item_entry);
      }
      else
	new_item = new d2sItem (item_entry);
    }

  else	/* Extended item classes */
    {
      if (IsTypeAMemberOf (item_type, "thro")
	  && GetEntryIntegerField (item_entry, "stackable")) {
	new_item = new d2sStackedWeaponItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "weap")) {
	new_item = new d2sWeaponItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "armo")) {
	new_item = new d2sArmorItem (item_entry);
      }
      else if (item_data->gem_count) {
	print_message ("Item \"%s\" has a type \"%s\" which is not weapon"
		       " or armor, but it has %d gem(s) attached.\n",
		       item_name, item_type, item_data->gem_count);
	new_item = new d2sDurableItem (item_entry);
      }
      else if (GetEntryIntegerField (item_entry, "stackable")) {
	new_item = new d2sStackItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "ring")
	       || IsTypeAMemberOf (item_type, "amul")
	       || IsTypeAMemberOf (item_type, "char")) {
	new_item = new d2sCharmItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "jewl")) {
	new_item = new d2sJewelItem (item_entry);
      }
      else {
	if ( ! IsTypeAMemberOf (item_type, "ques"))
	  print_message ("Item \"%s\" has a type \"%s\"\n which does not match"
			 " any known extended item, yet it is not simple.\n",
			 item_name, item_type);
	new_item = new d2sExtendedItem (item_entry);
      }
    }

 read_the_item:
  /* Read the item data */
  if (new_item->Read (dstream) < 0)
    {
      /* Error!  Rewind the stream, delete the item, and return NULL. */
      dstream->ptr = (unsigned char *) item_data;
      delete new_item;
      return NULL;
    }

  /* Success! */
  return new_item;
}

/* Open and read a single item from a .d2i file. */
d2sItem *
ReadItemFile (const char *filename)
{
  int		fd;
  ssize_t	status;
  struct stat	statbuf;
  struct item_header *item_header;
  struct data_stream ds;
  d2sItem *	item;

  if (stat (filename, &statbuf))
    {
      print_message ("%s: %s", filename, strerror (errno));
      return NULL;
    }

  /* Allocate a buffer large enough to read the whole file at once */
  if ((statbuf.st_size < (off_t) sizeof (struct item_header))
      /* Limit the size of the .d2i file to 1KB.
	 Most items are 14-48 bytes. */
      || (statbuf.st_size > 1024))
    {
      print_message ("%s: Bad file size (%lu)", filename, statbuf.st_size);
      return NULL;
    }
  item_header = (struct item_header *) xmalloc (statbuf.st_size);
  /* Read the whole file */
  fd = open (filename, O_RDONLY);
  if (fd < 0)
    {
      print_message ("%s: %s", filename, strerror (errno));
      free (item_header);
      return NULL;
    }
  errno = 0;
  status = read (fd, item_header, (size_t) statbuf.st_size);
  if (status < (ssize_t) statbuf.st_size)
    {
      print_message ("%s: %s", filename,
		     errno ? strerror (errno) : "Short read");
      free (item_header);
      return NULL;
    }
  close (fd);

  /* Check the validity of the file.  With items,
     the most we can do ourself is check the magic number. */
  if ((item_header->magic[0] != 'J') || (item_header->magic[1] != 'M'))
    {
      print_message ("%s: Invalid file header", filename);
      free (item_header);
      return NULL;
    }

  /* Initialize a dstream and try to read the item */
  dstream_set (ds, item_header, 0, statbuf.st_size);
  item = ReadItemFromFile (&ds);
  if (item != NULL)
    item->filename = xstrdup (filename);

  /* Free the temporary buffer and return. */
  free (item_header);
  return item;
}

/* Open and read a list of items from a library or item set file.
   Returns the number of items in the list, or -1 on error. */
int
ReadItemLibrary (const char *filename, d2sItem ***ret_list)
{
  int		fd, item_count, max_count;
  ssize_t	status;
  struct stat	statbuf;
  uint8_t	*raw_buffer;
  struct data_stream ds;
  d2sItem **	item_list;

  if (stat (filename, &statbuf))
    {
      print_message ("%s: %s", filename, strerror (errno));
      return -1;
    }

  /* Allocate a buffer large enough to read the whole file at once */
  if ((statbuf.st_size < (off_t) sizeof (struct item_header) + 4)
      /* Limit the size of the .d2l file to 128KB (over 3000 items). */
      || (statbuf.st_size > 128 * 1024))
    {
      print_message ("%s: Bad file size (%lu)", filename, statbuf.st_size);
      return -1;
    }
  raw_buffer = (uint8_t *) xmalloc (statbuf.st_size);
  /* Read the whole file */
  fd = open (filename, O_RDONLY);
  if (fd < 0)
    {
      print_message ("%s: %s", filename, strerror (errno));
      free (raw_buffer);
      return -1;
    }
  errno = 0;
  status = read (fd, raw_buffer, (size_t) statbuf.st_size);
  if (status < (ssize_t) statbuf.st_size)
    {
      print_message ("%s: %s", filename,
		     errno ? strerror (errno) : "Short read");
      free (raw_buffer);
      return -1;
    }
  close (fd);

  /* Check the validity of the file.  We expect a 2-character magic
     number, a 16-bit item count, then another 2-character magic
     number for the first item. */
  max_count = *((uint16_t *) &raw_buffer[2]);
  if ((raw_buffer[0] != 'J') || (raw_buffer[1] != 'M')
      || (raw_buffer[4] != 'J') || (raw_buffer[5] != 'M')
      || ((unsigned) max_count
	  > (statbuf.st_size - 4) / sizeof (struct item_header)))
    {
      print_message ("%s: Invalid file header", filename);
      free (raw_buffer);
      return -1;
    }

  /* Initialize a dstream and an array of item pointers */
  dstream_set (ds, raw_buffer, 4, statbuf.st_size - 4);
  item_list = (d2sItem **) xmalloc (max_count * sizeof (d2sItem *));
  memset (item_list, 0, max_count * sizeof (d2sItem *));

  /* Read in the items! */
  for (item_count = 0; item_count < max_count; item_count++)
    {
      item_list[item_count] = ReadItemFromFile (&ds);
      if (item_list[item_count] == NULL)
	break;
      item_list[item_count]->filename = xstrdup (filename);
    }

  if (!dstream_eof (ds))
    print_message ("%s: The rest of the library file was not read", filename);
  if (!item_count)
    {
      free (item_list);
      item_list = NULL;
      --item_count;
    }

  /* Free the temporary buffer and return. */
  free (raw_buffer);
  *ret_list = item_list;
  return item_count;
}

/* Create an item from scratch using the item tables for reference.
   This function figures out the matching item class and calls the
   correct constructor. */
d2sItem *
CreateItemFromCode (const char *code)
{
  table_entry_t item_entry;
  const char *item_type;
  d2sItem *new_item;

  /* Look for the item in the tables */
  item_entry = LookupTableEntry ("misc", "code", code);
  if (item_entry == NULL) {
    item_entry = LookupTableEntry ("armor", "code", code);
    if (item_entry == NULL) {
      item_entry = LookupTableEntry ("weapons", "code", code);
      if (item_entry == NULL) {
	/* No such item */
	print_message ("Unknown item code \"%3s\"\n", code);
	return NULL;
      }
    }
  }

  /* Get the item's type to determine which constructor to call */
  item_type = GetEntryStringField (item_entry, "type");
  if (item_type[0] == 0) {
    /* Oops! Missing the type field in the item table! */
    print_message ("Item \"%s\" does not have a 'type' entry"
		   " in the data tables\n", TranslateString (code));
    return NULL;
  }

  /* We can divide the possible classes in two by looking at
     the "compactsave" bit in the item tables.  It is 1 for simple items. */
  if (GetEntryIntegerField (item_entry, "compactsave"))
    {
      if (IsTypeAMemberOf (item_type, "gem")) {
	new_item = new d2sGemItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "poti")) {
	/* NOTICE: We need to redo this class, because
	   scrolls can also be placed in the belt. */
	new_item = new d2sPotionItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "rune")) {
	new_item = new d2sRuneItem (item_entry);
      }
      else
	new_item = new d2sItem (item_entry);
    }

  else	/* Extended item classes */
    {
      if (IsTypeAMemberOf (item_type, "thro")
	  && GetEntryIntegerField (item_entry, "stackable")) {
	new_item = new d2sStackedWeaponItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "weap")) {
	new_item = new d2sWeaponItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "armo")) {
	new_item = new d2sArmorItem (item_entry);
      }
      else if (GetEntryIntegerField (item_entry, "stackable")) {
	new_item = new d2sStackItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "ring")
	       || IsTypeAMemberOf (item_type, "amul")
	       || IsTypeAMemberOf (item_type, "char")) {
	new_item = new d2sCharmItem (item_entry);
      }
      else if (IsTypeAMemberOf (item_type, "jewl")) {
	new_item = new d2sJewelItem (item_entry);
      }
      else {
	if ( ! IsTypeAMemberOf (item_type, "ques"))
	  print_message ("Item \"%s\" has a type \"%s\"\n which does not match"
			 " any known extended item, yet it is not simple.\n",
			 TranslateString (code), item_type);
	new_item = new d2sExtendedItem (item_entry);
      }
    }

  /* That's all we do here. */
  return new_item;
}


/**************** ITEM SUPERCLASS ****************
 *
 * This class encompasses functions common
 * to all specific item classes.
 *************************************************/

/* Clear the class member fields (called by constructors) */
void
d2sItem::Init (void)
{
  next = NULL;
  pprev = NULL;
  nvop = this;
  filename = NULL;
  character = NULL;
  ui_data = NULL;
  dirty = False;
  error_str = NULL;
  raw_data = NULL;
  raw_length = 0;
  table_entry = NULL;
  type_entry = NULL;
  item_class = UNKNOWN_ITEM;
  identified_item = True;
  ethereal_item = False;
  personalized_item = False;
  runeworded_item = False;
  newbie_item = False;
  socketed_item = False;
  location = ITEM_AREA_PICKED;
  loc_1 = ITEM_LOCATION_IN_TRANSIT;
  stored_loc = 0;
  equipped_slot = 0;
  column = 0;
  row = 0;
  gem_count = 0;
  item_ID.id = 'x' * 0x010101;
  base_name = "(unknown)";
  graphic = "xxx";
  width = 1;
  height = 1;
  quest_item = False;
  expansion_item = False;
  base_level = 0;
}

/* Initialize member fields based on an item table entry.
   Does *NOT* alter fields based on variable data. */
void
d2sItem::SetItemType (table_entry_t tent)
{
  const char *cstr;

  /* Keep a local copy of the table entry */
  table_entry = tent;
  if (tent == NULL)
    {
      type_entry = NULL;
      return;
    }

  /* Get various fixed data about this item from the item tables */
  type_entry = LookupTableEntry ("itemtypes", "Code",
				 GetEntryStringField (tent, "type"));
  cstr = GetEntryStringField (tent, "code");
  item_ID.id = *((uint32_t *) cstr);
  base_name = LookupStringByKey (cstr);
  if (base_name == NULL) {
    print_message ("Item code \"%3.3s\" has no name in the string table\n",
		   cstr);
    error_str = "Bad item table entry";
    cstr = GetEntryStringField (tent, "name");
    if (cstr[0] == 0)
      print_message ("Item code \"%3.3s\" has no name in the item table\n",
		     base_name);
    else
      base_name = cstr;
  } else {
    /* There are two exceptions to using the plain base name:
       the Potion of Life and Book of Skill have an extra description
       line built right into the item name, and it precedes the name. */
    if (strchr (base_name, '\n') != NULL) {
      /* Fortunately the fix is easy, and global. */
      base_name = strrchr (base_name, '\n') + 1;
    }
  }
  graphic = GetEntryStringField (tent, "invfile");
  if ((graphic[0] == 'i') && (graphic[1] == 'n') && (graphic[2] == 'v'))
    graphic += 3;
  else {
    print_message ("Item %s (\"%3.3s\") does not define a graphic\n",
		   base_name, item_ID.ch);
    error_str = "Bad item table entry";
    graphic = &item_ID.ch[0];
  }
  width = GetEntryIntegerField (tent, "invwidth");
  if ((width < 1) || (width > 4)) {
    print_message ("Item %s (\"%3.3s\") has an invalid width (%d)\n",
		   base_name, item_ID.ch, width);
    error_str = "Bad item table entry";
    width = 1;
  }
  height = GetEntryIntegerField (tent, "invheight");
  if ((height < 1) || (height > 4)) {
    print_message ("Item %s (\"%3.3s\") has an invalid height (%d)\n",
		   base_name, item_ID.ch, height);
    error_str = "Bad item table entry";
    height = 1;
  }
  quest_item = GetEntryIntegerField (tent, "quest");
  expansion_item = (GetEntryIntegerField (tent, "version") >= 100);
  base_level = GetEntryIntegerField (tent, "levelreq");
}

/* The same, but called after an item has been constructed
   when an item is being transformed into another type. */
int
d2sItem::ChangeItemType (table_entry_t tent)
{
  /* There is no difference in the functions at the base class level.
     The difference comes in derived classes; in a derived class,
     d2sItem::SetItemType is called by constructors before the virtual
     functions are set, while ChangeItemType is only ready after the
     derived class has been fully constructed. */
  SetItemType (tent);
  return 0;
}

/* Create a new, blank item (to be filled in later) */
d2sItem::d2sItem (void)
{
  /* Clear the data fields */
  Init ();
  /* Create the raw data */
  CommitChanges ();
}

/* Create a new, specific item as described by the item table entry
   (using default variable attributes) */
d2sItem::d2sItem (table_entry_t tent)
{
  /* Clear the data fields */
  Init ();
  /* This will be overridden by derived classes */
  item_class = SIMPLE_ITEM;
  /* Initialize the item-specific fields */
  SetItemType (tent);
}

/* Copy an existing item */
d2sItem::d2sItem (const d2sItem &source)
{
  Init ();

  /* Start by copying the table entry */
  SetItemType (source.table_entry);

  /* If the source item is dirty, make sure the copy is marked
     dirty too (so that it will generate the correct data when written */
  if (source.dirty)
    this->dirty = True;
  /* If the source is clean, copy the original raw data. */
  else if (source.raw_data != NULL)
    {
      this->raw_length = source.raw_length;
      this->raw_data = (unsigned char *) xmalloc (raw_length);
      memcpy (this->raw_data, source.raw_data, raw_length);
    }

  /* Then copy the variable fields from the source item */
  this->item_class = source.item_class;
  this->identified_item = source.identified_item;
  this->ethereal_item = source.ethereal_item;
  this->personalized_item = source.personalized_item;
  this->runeworded_item = source.runeworded_item;
  this->newbie_item = source.newbie_item;
  this->socketed_item = source.socketed_item;
  this->location = source.location;
  /* Special handling for socketed items */
  if (location == ITEM_AREA_SOCKETED)
    {
      location = ITEM_AREA_PICKED;
      dirty = True;
    }
  this->loc_1 = source.loc_1;
  this->stored_loc = source.stored_loc;
  this->equipped_slot = source.equipped_slot;
  this->column = source.column;
  this->row = source.row;
  this->gem_count = source.gem_count;
}

/* Destroy a simple item object */
d2sItem::~d2sItem ()
{
  if (raw_data != NULL)
    free (raw_data);
  raw_data = NULL;
  if (filename != NULL)
    free (filename);
  filename = NULL;
}

/* Copy an item. */
d2sItem *
d2sItem::Copy (void) const
{
  d2sItem *new_item = new d2sItem (*this);
  return new_item;
}

/* Create an item by filling in data from a file. */
int
d2sItem::Read (struct data_stream *dstream)
{
  struct item_header *item_data = (struct item_header *) dstream->ptr;

  /* Consistency check */
  if (*((uint16_t *) &item_data->magic[0]) != *((uint16_t *) &"JM"))
    {
      print_message ("Bad item data in data stream at %#x\n",
		     dstream->ptr - dstream->base);
      error_str = "Bad item data";
      return -1;
    }

  /* Set the raw item data; assuming a simple item size */
  ReplaceRawData (dstream->ptr, sizeof (struct item_header));

  /* If we're reading an item of a different type than this object
     was created, re-initialize with a new table entry. */
  if (item_ID.id != item_data->item_ID)
    {
      item_ID.id = item_data->item_ID;
      table_entry = LookupTableEntry ("misc", "code", item_ID.ch);
      if (table_entry == NULL) {
	table_entry = LookupTableEntry ("armor", "code", item_ID.ch);
	if (table_entry == NULL) {
	  table_entry = LookupTableEntry ("weapons", "code", item_ID.ch);
	  if (table_entry == NULL)
	    print_message ("Read unknown item code \"%3.3s\""
			   " in data stream at %#x\n",
			   item_ID.ch, dstream->ptr - dstream->base);
	}
      }

      ChangeItemType (table_entry);
    }

  /* Copy fields from the header */
  identified_item = item_data->identified;
  ethereal_item = item_data->ethereal;
  personalized_item = item_data->personalized;
  runeworded_item = item_data->runeworded;
  newbie_item = item_data->newbie;
  socketed_item = item_data->socketed;
  loc_1 = item_data->location;
  stored_loc = item_data->stored_location;
  equipped_slot = item_data->equipped_slot;
  column = item_data->column;
  row = item_data->row;
  gem_count = item_data->gem_count;

  /* Consistency checks (for the simple item level) */
  if (item_data->simple != GetEntryIntegerField (table_entry, "compactsave"))
    {
      print_message ("Invalid item data (%s at %p): compactsave bit"
		     " does not match item tables\n",
		     base_name, dstream->ptr - dstream->base);
      error_str = "Bad item data";
    }
  else if (item_data->simple != item_class <= UNKNOWN_EXTENDED_ITEM)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: item class %d used to read"
		 " a%s item\n", progname, item_class,
		 item_data->simple ? " simple" : "n extended");
      error_str = "Internal error";
    }
  if ((loc_1 != ITEM_LOCATION_IN_STORAGE)
      && (stored_loc != 0))
    {
    bad_location:
      print_message ("Invalid item data (%s at %p): bad location\n",
		     base_name, dstream->ptr - dstream->base);
      error_str = "Bad item data";
    }
  else switch (loc_1)
    {
    case ITEM_LOCATION_IN_STORAGE:
      switch (stored_loc)
	{
	case ITEM_STORED_IN_INVENTORY:
	  location = ITEM_AREA_INVENTORY;
	  if ((column >= HSIZE_INVENTORY) || (row >= VSIZE_INVENTORY))
	    goto bad_location;
	  break;
	case ITEM_STORED_IN_CUBE:
	  location = ITEM_AREA_CUBE;
	  if ((column >= HSIZE_CUBE) || (row >= VSIZE_CUBE))
	    goto bad_location;
	  break;
	case ITEM_STORED_IN_STASH:
	  location = ITEM_AREA_STASH;
	  if ((column >= HSIZE_STASH) || (row >= VSIZE_STASH))
	    goto bad_location;
	  break;
	default:
	  goto bad_location;
	}
#if 0
      /* I've never actually seen a case where this field is non-zero,
	 but since column and row may be non-zero when an item is
	 equipped, the reverse *might* be valid too. */
      if (item_data->equipped_slot)
	goto bad_location;
#endif
      break;
    case ITEM_LOCATION_EQUIPPED:
      /* The location could also be on the corpse or hireling,
	 but we won't know this until we're assigned to a character. */
      location = ITEM_AREA_EQUIPPED;
      if (equipped_slot > EQUIPPED_ON_ALT_LEFT_HAND)
	goto bad_location;
      break;
    case ITEM_LOCATION_IN_BELT:
      location = ITEM_AREA_BELT;
      break;
    case ITEM_LOCATION_IN_TRANSIT:
      location = ITEM_AREA_PICKED;
      break;
    case ITEM_LOCATION_IN_SOCKET:
      location = ITEM_AREA_SOCKETED;
      break;
    default:
      goto bad_location;
    }
  if (!socketed_item && gem_count)
    {
      print_message ("Invalid item data: non-zero gem count"
		     " on non-socketed item %s at %p\n",
		     base_name, dstream->ptr - dstream->base);
      /* error_str = "Bad item data"; */
    }

  /* Update the data stream before returning */
  dstream->ptr += sizeof (item_header);
  dirty = (error_str != NULL);
  /* Always return 0 as long as the data stream
     looks like we can keep reading it */
  return 0;
}

/* Set the UI-specific data pointer. */
int
d2sItem::SetUI (void *ui)
{
  /* We only allow one UI data pointer to be set at a time. */
  if ((ui != NULL) && (ui_data != NULL))
    {
      fprintf (stderr, "%s: Internal error: attempt to change UI of %s %p"
	       " to %p\n\tafter it had already been set to %p.\n",
	       progname, base_name, this, ui, ui_data);
      error_str = "UI data is already set for this item";
      return -1;
    }
  ui_data = ui;
  return 0;
}

/* Discard changes made since the item was created. */
void
d2sItem::DiscardChanges (void)
{
  struct item_header *item_data = (struct item_header *) raw_data;

  if (!dirty)
    return;

  /* Do we actually havy any raw data? */
  if (raw_data == NULL)
    return;

  /* If the item type has changed since it was created,
     re-initialize with the original table entry. */
  item_ID.id = item_data->item_ID;
  if (item_ID.id != item_data->item_ID)
    {
      item_ID.id = item_data->item_ID;
      table_entry = LookupTableEntry ("misc", "code", item_ID.ch);
      if (table_entry == NULL) {
	table_entry = LookupTableEntry ("armor", "code", item_ID.ch);
	if (table_entry == NULL)
	  table_entry = LookupTableEntry ("weapons", "code", item_ID.ch);
      }

      ChangeItemType (table_entry);
    }

  /* Copy fields from the header */
  identified_item = item_data->identified;
  ethereal_item = item_data->ethereal;
  personalized_item = item_data->personalized;
  runeworded_item = item_data->runeworded;
  newbie_item = item_data->newbie;
  socketed_item = item_data->socketed;
  /* One change we *don't* discard is moving items around.
     We also don't discard changes to the gem count, since
     that would require storing a copy of the original gems,
     which this class doesn't know about. */
  dirty = ((loc_1 != item_data->location)
	   || (stored_loc != item_data->stored_location)
	   || (equipped_slot != item_data->equipped_slot)
	   || (column != item_data->column) || (row != item_data->row)
	   || (gem_count != item_data->gem_count));
  return;
}

/* Save an item file under the same name; returns 0 on success */
int
d2sItem::Save (void)
{
  char *backup_name = NULL;
  int fd, status;

  if (filename == NULL)
    {
      print_message ("Cannot save %s without a filename\n", base_name);
      error_str = "Item has no filename";
      return -1;
    }
  if (access (filename, F_OK) == 0)
    {
      /* A file with this name already exists.  But we knew that,
	 since we either loaded that file or had previously saved
	 it.  In either case, back up the existing file. */
      backup_name = backup_old_file (filename);
      if (backup_name == NULL)
	{
	  if (display_question (0, 2, "Cancel", "Overwrite",
				"Do you wish to continue saving your"
				" character to %s without making a"
				" backup?", filename) == 0)
	    {
	      print_message ("Save cancelled; unable to make a backup.\n");
	      error_str = "Unable to make backup";
	      return -1;
	    }
	}
    }
  else if (errno != ENOENT)
    {
      /* There is an unknown problem with the original filename */
      error_str = strerror (errno);
      print_message ("%s: %s.", filename, error_str);
      return -1;
    }

  /* Open the file for writing */
  fd = open (filename, O_WRONLY | O_CREAT | O_TRUNC,
	     S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  if (fd < 0)
    {
      error_str = strerror (errno);
      print_message ("%s: %s.", filename, error_str);
      if (backup_name != NULL)
	{
	  rename (backup_name, filename);
	  free (backup_name);
	}
      return -1;
    }

  /* Commit any changes to the raw data */
  if (dirty)
    CommitChanges ();

  /* Write the item */
  status = write (fd, raw_data, raw_length);
  close (fd);
  if (status < (int) raw_length)
    {
      error_str = strerror (errno);
      print_message ("%s: %s.\n", filename, error_str);
      status = -1;
    }

  /* If a failure occurred during write,
     don't bother restoring the backup or deleting the bad file. */
  if (backup_name != NULL)
    free (backup_name);

  return status;
}

/* Save an item file under a new name; returns 0 on success */
int
d2sItem::SaveAs (const char *new_filename)
{
  char *strp, *revised_filename, *backup_name = NULL;
  int fd, status;

  if (new_filename == NULL)
    {
      print_message ("Cannot save %s without a filename\n", base_name);
      error_str = "Missing filename";
      return -1;
    }
  /* Make some slight adjustments to the filename.
     If it has no extension, append ".d2i". */
  revised_filename = (char *) xmalloc (strlen (new_filename) + 8);
  strcpy (revised_filename, new_filename);
  strp = strrchr (revised_filename, '/');
  if (strp == NULL)
    strp = revised_filename;
  strp = strchr (strp, '.');
  if (strp == NULL)
    strcat (revised_filename, ".d2i");

  /* Does this file already exist? */
  if (access (revised_filename, F_OK) == 0)
    {
      /* Ask the user whether to backup the existing file or overwrite it */
      status = display_question
	(1, 3, "Cancel", "Back up", "Overwrite",
	 "A file named %s already exists.  Do you wish to back up the"
	 " existing file before proceeding, or overwrite it?",
	 revised_filename);
      if (!status)
	{
	  print_message ("Save cancelled due to filename conflict.\n");
	  error_str = "File name conflict";
	  return -1;
	}
      if (status == 1)
	{
	  backup_name = backup_old_file (revised_filename);
	  if (backup_name == NULL)
	    return -1;
	}
    }

  /* Open the file for writing */
  fd = open (new_filename, O_WRONLY | O_CREAT | O_TRUNC,
	     S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  if (fd < 0)
    {
      error_str = strerror (errno);
      print_message ("%s: %s.", revised_filename, error_str);
      if (backup_name != NULL)
	{
	  rename (backup_name, revised_filename);
	  free (backup_name);
	}
      free (revised_filename);
      return -1;
    }

  /* Commit any changes to the raw data */
  if (dirty)
    CommitChanges ();

  /* Write the item */
  status = write (fd, raw_data, raw_length);
  close (fd);
  if (status < (int) raw_length)
    {
      error_str = strerror (errno);
      print_message ("%s: %s.\n", new_filename, error_str);
      status = -1;
    }

  /* If a failure occurred during write, don't bother restoring
     the backup or deleting the bad file.  If the write succeeded,
     replace any previous file name with the new one. */
  if (backup_name != NULL)
    free (backup_name);
  if (status > 0)
    {
      if (filename != NULL)
	free (filename);
      filename = revised_filename;
    }
  else
    free (revised_filename);

  return ((status > 0) ? 0 : -1);
}

/* Remove an item from its associated character. */
int
d2sItem::RemoveFromOwner (void)
{
  character = NULL;
  return 0;
}

/* Assign an item to a character.  This simply defines the association;
   it is up to the character to install us in the correct place. */
int
d2sItem::AssignTo (d2sData *new_char, int area)
{
  if (character != NULL)
    {
      if (character == new_char)
	{
	  /* This may be called when changing an item from
	     the character himself to his corpse or hireling. */
	  if (area && (area != location))
	    {
	      if ((location == ITEM_AREA_EQUIPPED)
		  || (location == ITEM_AREA_CORPSE)
		  || (location == ITEM_AREA_HIRELING))
		{
		  if ((area == ITEM_AREA_EQUIPPED)
		      || (area == ITEM_AREA_CORPSE)
		      || (area == ITEM_AREA_HIRELING))
		    {
		      /* Move the item to the requested body */
		      location = area;
		      return 0;
		    }
		  fprintf (stderr, "Internal error:"
			   " %s->AssignTo(character,%d)\n", base_name, area);
		  return -1;
		}
	      fprintf (stderr, "Internal error: %s->AssignTo(character,%d)\n"
		       " when the %s is currently located in %d\n",
		       base_name, area, base_name, location);
	      return -1;
	    }
	  if ((area && (area != ITEM_AREA_SOCKETED))
	      || (location && (location != ITEM_AREA_SOCKETED)))
	  fprintf (stderr, "%s: %s is being added to %s multiple times\n",
		   progname, base_name, new_char->GetCharacterName());
	  /* Pretend success, even though this shouldn't happen. */
	  return 0;
	}
      print_message ("Item %s cannot be assigned to %s; it already belongs"
		     " to %s.\n", base_name, new_char->GetCharacterName(),
		     character->GetCharacterName());
      error_str = "This item already belongs to another character";
      return -1;
    }

  if (area && (area != location))
    {
      if ((location == ITEM_AREA_EQUIPPED)
	  || (location == ITEM_AREA_CORPSE)
	  || (location == ITEM_AREA_HIRELING))
	{
	  if ((area == ITEM_AREA_EQUIPPED)
	      || (area == ITEM_AREA_CORPSE)
	      || (area == ITEM_AREA_HIRELING))
	    {
	      /* Move the item to the requested body */
	      location = area;
	      character = new_char;
	      return 0;
	    }
	  fprintf (stderr, "Internal error:"
		   " %s->AssignTo(character,%d)\n", base_name, area);
	  return -1;
	}
      fprintf (stderr, "Internal error: %s->AssignTo(character,%d)\n"
	       " when the %s is currently located in %d\n",
	       base_name, area, base_name, location);
      return -1;
    }

  character = new_char;
  return 0;
}

/* Attached gems, quality ratings, and magic properties
   must call this function when they have changed */
void
d2sItem::MarkDirty (void)
{
  /* Not only are we dirty, */
  dirty = True;
  /* but our owner is now dirty too */
  if (character)
    character->MarkDirty();
}

/* Write an item out to a raw byte stream. */
void
d2sItem::Write (struct data_stream *dstream)
{
  /* Commit any changes made to the item */
  if (dirty)
    CommitChanges ();
  /* Write the data out */
  dstream_write (dstream, raw_data, raw_length);
}

/* Return the position of an item; this could be the equipment slot,
   belt slot, or row/column number if stowed. */
coordinate_t
d2sItem::Position (void) const
{
  coordinate_t pos = { 0, 0 };

  switch (location)
    {
    case ITEM_AREA_EQUIPPED:
    case ITEM_AREA_CORPSE:
    case ITEM_AREA_HIRELING:
      pos.x = equipped_slot;
      break;
    case ITEM_AREA_BELT:
    case ITEM_AREA_CUBE:
    case ITEM_AREA_INVENTORY:
    case ITEM_AREA_STASH:
      pos.x = column;
      pos.y = row;
      break;
    case ITEM_AREA_PICKED:
      break;
    case ITEM_AREA_SOCKETED:
      /* Figure out which socket we're in */
      {
	d2sAttachItem *gem = (d2sAttachItem *) nvop;
	pos.x = gem->SocketNumber ();
      }
    }
  return pos;
}

/* Construct and return a string containing an item's
   full description, suitable for display.
   The string must be freed when done. */
char *
d2sItem::FullDescription (void) const
{
  const char *cstr, *estr;
  char *description;
  int l;

  /* There are, in fact, two simple items whose descriptions
     are built into their names in the string table. */
  cstr = LookupStringByKey (item_ID.ch);
  if ((cstr == NULL) || (cstr == base_name))
    return xstrdup (base_name);

  /* Strings (at least for item and skill descriptions) are stored
     bottom-to-top, meaning we must reverse everything around the
     newlines.  To keep things simple, we'll assume just two lines. */
  l = strlen (cstr);
  description = (char *) xmalloc (l + 1);
  description[l] = '\0';
  estr = strchr (cstr, '\n');
  strcpy (description, &estr[1]);
  l = strlen (description);
  description[l++] = '\n';
  memcpy (&description[l], cstr, estr - cstr);
  return description;
}

/* Construct and return a list of all magic
   properties in effect on the item. */
d2sMagic *
d2sItem::CombinedProperties (void) const
{
  /* Most simple items have no properties */
  return new d2sMagic;
}

/* An item is considered read-only if the owner is read-only */
int
d2sItem::read_only (void) const
{
  return ((character != NULL) && character->read_only);
}

/* Return whether an item is a subset of a given type. */
int
d2sItem::is_of_type (const char *type) const
{
  if ((type == NULL) || (type[0] == '\0'))
    return 0;

  /* Find this item's (narrowest) type, compare and return */
  return IsTypeAMemberOf (GetEntryStringField (table_entry, "type"), type);
}

/* Change the location of an item.
   If the item belongs to a character, this must ONLY be called
   by that character!  The character is responsible for checking
   the destination.  If the item is unclaimed, we don't much care
   where the destination is. */
int
d2sItem::SetLocation (int area, int col, int rw)
{
  /* Check for negative arguments */
  if ((col < 0) || (rw < 0))
    {
      if (debug)
	fprintf (stderr, "%s: Error: invalid argument to"
		 " d2sItem::SetLocation(%d,%d,%d)\n",
		 progname, area, col, rw);
      error_str = "Invalid argument";
      return -1;
    }

  /* This function can not be used to change whether a gem is in a socket */
  if (location == ITEM_AREA_SOCKETED)
    {
      print_message ("You may not move an item which is"
		     " attached to a socket\n");
      error_str = "Invalid attempt to remove an item from a socket";
      return -1;
    }

  /* Check whether the destination is valid */
  if (CheckLocationChange (area, col, rw, True) < 0)
    {
      print_message (error_str);
      return -1;
    }

  switch (area)
    {
    case ITEM_AREA_HIRELING:
    case ITEM_AREA_EQUIPPED:
    case ITEM_AREA_CORPSE:
      loc_1 = ITEM_LOCATION_EQUIPPED;
      equipped_slot = col;
      stored_loc = 0;
      break;

    case ITEM_AREA_BELT:
      loc_1 = ITEM_LOCATION_IN_BELT;
      row = 0;
      column = col;
      stored_loc = 0;
      break;

    case ITEM_AREA_PICKED:
      loc_1 = ITEM_LOCATION_IN_TRANSIT;
      stored_loc = 0;
      break;

    case ITEM_AREA_SOCKETED:
      /* This is the wrong function for socketing an item */
      if (debug)
	fprintf (stderr, "%s: Internal error: d2sItem::SetLocation"
		 "(ITEM_AREA_SOCKETED)\n", progname);
      error_str = "Invalid attempt to set item location to a socket";
      return -1;

    case ITEM_AREA_INVENTORY:
      stored_loc = ITEM_STORED_IN_INVENTORY;
      goto move_to_storage;

    case ITEM_AREA_CUBE:
      stored_loc = ITEM_STORED_IN_CUBE;
      goto move_to_storage;

    case ITEM_AREA_STASH:
      stored_loc = ITEM_STORED_IN_STASH;
    move_to_storage:
      loc_1 = ITEM_LOCATION_IN_STORAGE;
      row = rw;
      column = col;
      break;
    }

  location = area;
  MarkDirty ();
  return 0;
}

/* Conversion operators */
d2sItem::operator d2sAttachItem* () const
{
  /* The possible class derivations are gem, rune, or jewel. */
  switch (item_class)
    {
    case GEM_ITEM:
    case RUNE_ITEM:
      return (d2sGemOrRuneItem *) nvop;
    case JEWEL_ITEM:
      return (d2sJewelItem *) nvop;
    default:
      fprintf (stderr, "%s: Internal error: attempt to cast a %s"
	       " to an attachable item\n",
	       progname, (table_entry == NULL) ? base_name
	       : GetEntryStringField (type_entry, "ItemType"));
      abort ();
    }
}

d2sItem::operator d2sExtendedItem* () const
{
  /* All derived classes of d2sExtendedItem are possible */
  switch (item_class)
    {
    case UNKNOWN_EXTENDED_ITEM:
    case EXTENDED_ITEM:
      return (d2sExtendedItem *) nvop;
    case STACK_ITEM:
      return (d2sStackItem *) nvop;
    case CHARM_ITEM:
      return (d2sCharmItem *) nvop;
    case JEWEL_ITEM:
      return (d2sJewelItem *) nvop;
    case ARMOR_ITEM:
      return (d2sArmorItem *) nvop;
    case WEAPON_ITEM:
      return (d2sWeaponItem *) nvop;
    case STACKED_WEAPON_ITEM:
      return (d2sStackedWeaponItem *) nvop;
    default:
      fprintf (stderr, "%s: Internal error: attempt to cast a %s"
	       " to an extended item\n",
	       progname, (table_entry == NULL) ? base_name
	       : GetEntryStringField (type_entry, "ItemType"));
      abort ();
    }
}

d2sItem::operator d2sCharmItem* () const
{
  /* The possible class derivations are amulet, charm, jewel, or ring. */
  switch (item_class)
    {
    case JEWEL_ITEM:
      return (d2sJewelItem *) nvop;
    case CHARM_ITEM:
      return (d2sCharmItem *) nvop;
    default:
      fprintf (stderr, "%s: Internal error: attempt to cast a %s"
	       " to a charm item\n",
	       progname, (table_entry == NULL) ? base_name
	       : GetEntryStringField (type_entry, "ItemType"));
      abort ();
    }
}

d2sItem::operator d2sStackItem* () const
{
  /* The possible class derivations are quiver or stacked weapon. */
  switch (item_class)
    {
    case STACK_ITEM:
      return (d2sStackItem *) nvop;
    case STACKED_WEAPON_ITEM:
      return (d2sStackedWeaponItem *) nvop;
    default:
      fprintf (stderr, "%s: Internal error: attempt to cast a %s"
	       " to a stack item\n",
	       progname, (table_entry == NULL) ? base_name
	       : GetEntryStringField (type_entry, "ItemType"));
      abort ();
    }
}

d2sItem::operator d2sDurableItem* () const
{
  /* The possible class derivations are armor and weapons. */
  switch (item_class)
    {
    case ARMOR_ITEM:
      return (d2sArmorItem *) nvop;
    case WEAPON_ITEM:
      return (d2sWeaponItem *) nvop;
    case STACKED_WEAPON_ITEM:
      return (d2sStackedWeaponItem *) nvop;
    default:
      fprintf (stderr, "%s: Internal error: attempt to cast a %s"
	       " to a durable item\n",
	       progname, (table_entry == NULL) ? base_name
	       : GetEntryStringField (type_entry, "ItemType"));
      abort ();
    }
}

d2sItem::operator d2sJewelItem* () const
{
  /* The class MUST be a jewel */
  switch (item_class)
    {
    case JEWEL_ITEM:
      return (d2sJewelItem *) nvop;
    default:
      fprintf (stderr, "%s: Internal error: attempt to cast a %s"
	       " to a jewel\n",
	       progname, (table_entry == NULL) ? base_name
	       : GetEntryStringField (type_entry, "ItemType"));
      abort ();
    }
}

d2sItem::operator d2sStackedWeaponItem* () const
{
  /* The class MUST be a stacked weapon */
  switch (item_class)
    {
    case STACKED_WEAPON_ITEM:
      return (d2sStackedWeaponItem *) nvop;
    default:
      fprintf (stderr, "%s: Internal error: attempt to cast a %s"
	       " to a stacked weapon\n",
	       progname, (table_entry == NULL) ? base_name
	       : GetEntryStringField (type_entry, "ItemType"));
      abort ();
    }
}

/* Replace the raw item data */
void
d2sItem::ReplaceRawData (unsigned char *data, unsigned int size)
{
  /* Copy any raw item data */
  if (size)
    {
      if (raw_length != size)
	{
	  raw_length = size;
	  raw_data = (unsigned char *) xrealloc (raw_data, raw_length);
	}
      memcpy (raw_data, data, size);
    }
  else if (raw_data != NULL)
    {
      free (raw_data);
      raw_data = NULL;
      raw_length = 0;
    }
}

/* Commit changes made to the item to the raw data field. */
void
d2sItem::CommitChanges (void)
{
  struct item_header *item_data = (struct item_header *) raw_data;

  if (raw_data == NULL)
    {
      /* No raw data has been created for this item yet (new construction).
	 Create it.  *** Derived classes must remember that this is being
	 created from scratch, and insert appropriate default values. */
      raw_length = sizeof (struct item_header);
      raw_data = (unsigned char *) xmalloc (sizeof (struct item_header));
      memset (raw_data, 0, sizeof (struct item_header));
      item_data = (struct item_header *) raw_data;

      *((uint16_t *) &item_data->magic) = *((uint16_t *) &"JM");
      item_data->new_in_session = True;
      item_data->ID_space = ' ';
    }

  item_data->item_ID = item_ID.id;
  item_data->identified = identified_item;
  item_data->simple = GetEntryIntegerField (table_entry, "compactsave");
  item_data->ethereal = ethereal_item;
  /* Bit 39 is set on all items I've seen; don't know what it means, yet... */
  item_data->unknown4_7 = 1;
  item_data->personalized = personalized_item;
  item_data->runeworded = runeworded_item;
  item_data->newbie = newbie_item;
  item_data->socketed = socketed_item;
  item_data->equipped_slot = equipped_slot;
  item_data->column = column;
  item_data->row = row;
  item_data->location = ITEM_LOCATION_IN_STORAGE;
  item_data->stored_location = 0;
  item_data->gem_count = gem_count;
  switch (location)
    {
    case ITEM_AREA_CORPSE:
      /* All items left with the corpse are equipped (I hope). */
    case ITEM_AREA_HIRELING:
      /* All hireling items are equipped. */
    case ITEM_AREA_EQUIPPED:
      item_data->location = ITEM_LOCATION_EQUIPPED;
      break;
    case ITEM_AREA_BELT:
      item_data->location = ITEM_LOCATION_IN_BELT;
      break;
    case ITEM_AREA_INVENTORY:
      item_data->stored_location = ITEM_STORED_IN_INVENTORY;
      break;
    case ITEM_AREA_STASH:
      item_data->stored_location = ITEM_STORED_IN_STASH;
      break;
    case ITEM_AREA_CUBE:
      item_data->stored_location = ITEM_STORED_IN_CUBE;
      break;
    case ITEM_AREA_PICKED:
      item_data->location = ITEM_LOCATION_IN_TRANSIT;
      break;
    case ITEM_AREA_SOCKETED:
      item_data->location = ITEM_LOCATION_IN_SOCKET;
      break;
    }

  /* Mark the item as clean */
  dirty = False;
}

/* Check whether changing a location is legal.
   If not, set the error message.
   Does NOT check whether the character will allow the change. */
int
d2sItem::CheckLocationChange (int area, int col, int rw, int warn)
{
  const char *bodstr;

  /* Check for non-existent locations */
  switch (area)
    {
    default:
    out_of_range:
      if (debug)
	fprintf (stderr, "%s: Internal error: invalid argument to"
		 " d2sItem::CheckLocationChange(%d,%d,%d)\n",
		 progname, area, col, rw);
      error_str = "Invalid argument";
      return -1;

    case ITEM_AREA_HIRELING:
      switch (col) {
      case EQUIPPED_ON_HEAD:
      case EQUIPPED_ON_TORSO:
      case EQUIPPED_ON_LEFT_HAND:
      case EQUIPPED_ON_RIGHT_HAND:
	/* All of these places exist on the hireling */
	break;
      default:
	/* There are no other possible slots */
	error_str = "No such slot on a mercenary";
	return -1;
      }
      /* FALLTHROUGH */

    case ITEM_AREA_EQUIPPED:
    case ITEM_AREA_CORPSE:
      if ( ! GetEntryIntegerField (type_entry, "Body"))
	{
	  if (warn)
	    print_message ("You cannot equip a %s\n", base_name);
	  error_str = "You cannot equip this type of item";
	  return -1;
	}
      if (!col || col > EQUIPPED_ON_ALT_LEFT_HAND)
	{
	  error_str = "Equipment slot out of range";
	  return -1;
	}

      /* Check whether the item type can be equipped on the body part */
      bodstr = GetEntryStringField (LookupIndexedTableEntry
				    ("bodylocs", col), "Code");
      if ((strcasecmp (GetEntryStringField (type_entry, "BodyLoc1"),
		       bodstr) != 0)
	  && (strcasecmp (GetEntryStringField (type_entry, "BodyLoc2"),
			  bodstr) != 0))
	{
	  if (warn)
	    print_message
	      ("%ss may only be equipped on your %s\n",
	       GetEntryStringField (type_entry, "ItemType"),
	       GetEntryStringField
	       (LookupTableEntry ("bodylocs", "Code",
				  GetEntryStringField
				  (type_entry, "BodyLoc1")),
		"shortloc"));
	  error_str = "Invalid equipment location";
	  return -1;
	}
      return 0;

    case ITEM_AREA_BELT:
      if (!GetEntryIntegerField (type_entry, "Beltable"))
	{
	  if (warn)
	    print_message ("You cannot tuck a %s in you belt", base_name);
	  error_str = "You cannot tuck this item in your belt";
	  return -1;
	}
      if (rw || ((unsigned) col >= MSIZE_BELT))
	goto out_of_range;
      return 0;

    case ITEM_AREA_PICKED:
      /* No argument checks here */
      return 0;

    case ITEM_AREA_SOCKETED:
      /* Note: we do NOT return an unconditional error in this case.
	 Simply return whether an item *can* be put in a socket. */
      if ((item_class == GEM_ITEM) || (item_class == RUNE_ITEM)
	  || (item_class == JEWEL_ITEM))
	return 0;
      else
	return -1;

      /* The rest of these simply check for range. */
    case ITEM_AREA_INVENTORY:
      if ((col < 0) || (col + width > HSIZE_INVENTORY)
	  || (rw < 0) || (rw + height > VSIZE_INVENTORY))
	goto out_of_range;
      return 0;

    case ITEM_AREA_CUBE:
      if ((col < 0) || (col + width > HSIZE_CUBE)
	  || (rw < 0) || (rw + height > VSIZE_CUBE))
	goto out_of_range;
      return 0;

    case ITEM_AREA_STASH:
      if ((col < 0) || (col + width > HSIZE_STASH)
	  || (rw < 0) || (rw + height > VSIZE_STASH))
	goto out_of_range;
      return 0;
    }
  /* NOTREACHED */
  return 0;
}
