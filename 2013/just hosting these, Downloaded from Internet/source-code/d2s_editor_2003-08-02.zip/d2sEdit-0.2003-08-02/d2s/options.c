/* Global options and their default values.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "options.h"
#define True	1
#define False	0

int debug = True;

struct d2s_options options = {
  { /* Character editor options */
    { /* What can be edited */
      False	/* default_read_only */,
      False	/* name */,
      False	/* title */,
      False	/* expansion */,
      False	/* hardcore */,
      False	/* died */,
      False	/* up_and_down */,
      True	/* experience */,
      True	/* level */,
      True	/* stats */,
      False	/* stats2 */,
      False	/* stat_points */,
      True	/* skills */,
      False	/* skill_points */,
      True	/* gold */,
      True	/* item_location */,
      True	/* inventory */,
      True	/* corpse_inventory */,
      False	/* backward */,
      False	/* all_difficulties */,
      True	/* npcs */,
      True	/* acts */,
      True	/* act_location */,
      True	/* waypoints */,
      True	/* quests_complete */,
      True	/* quests_intermediate */,
      False	/* hireling_add */,
      True	/* hireling_name */,
      True	/* hireling_attribute */,
      True	/* hireling_experience */,
      True	/* hireling_level */,
      True	/* hireling_inventory */,
    },
    { /* What changes are made recursively and/or checked */
      True	/* level_experience */,
      True	/* level_stats */,
      True	/* stats_points */,
      True	/* stats_stats2 */,
      True	/* stats2_base */,
      True	/* skills_points */,
      True	/* skills_level */,
      True	/* skills_skills */,
      True	/* auto_skill */,
      True	/* equipment_level */,
      True	/* equipment_class */,
      True	/* act_entry */,
      True	/* auto_act */,
      False	/* act_quest */,
      False	/* act_location */,
      True	/* act_waypoint */,
      False	/* quest_quest */,
      True	/* quest_inventory */,
      True	/* auto_quest */,
      False	/* freeform */,
    }
  },
  { /* Item editor options */
    { /* Allowed changes to items */
      True	/* potion */,
      True	/* gem */,
      True	/* identified */,
      True	/* personalized */,
      True	/* newbie */,
      True	/* ethereal */,
      True	/* quantity */,
      True	/* durability */,
      True	/* base_durability */,
      True	/* defense */,
      True	/* socketed_gems */,
      True	/* socket_count */,
      False	/* fingerprint */,
      True	/* level */,
      True	/* quality */,
      True	/* picture */,
      True	/* magic_name */,
      True	/* set_or_unique */,
      True	/* magic_properties */,
      True	/* magic_property_list */,
    },
    { /* What changes are made recursively and/or checked */
      False	/* item_expansion */,
      True	/* durability_ethereal */,
      True	/* durability_base */,
      True	/* quantity_max */,
      True	/* durability_max */,
      True	/* defense_max */,
      True	/* quality_magic */,
      True	/* properties_range */,
      True	/* show_popup */,
    }
  }
};
