/* Functions used in reading data tables and string lists.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef TABLES_H
#define TABLES_H

typedef const struct _TableEntry *table_entry_t;

#ifdef __cplusplus
extern "C" {
#endif

  /* Preload certain tables.  If these tables are not found,
     it is considered a fatal error, and the editor won't start.
     Any tables requested after this function are considered
     optional, and will simply return NULL if not found. */
  void preload_tables (void);

  /* Look up a string in one of the string tables by key,
     and return the string's equivalent value.
     This version returns NULL if the key is not found. */
  const char *LookupStringByKey (const char *key);

  /* Look up a string in one of the string tables by index.
     Returns NULL if there is no string at that index. */
  const char *LookupStringByIndex (const char *tbl_name, int index);

  /* Look up alternate text for a string.  The argument
     is still considered a key, but if alternate text
     is not found, the key is returned instead. */
  const char *TranslateString (const char *key);

  /* Find an entry in a data table by key.  You must provide the
     table name, the name of the key field, and the key itself.
     Returns an opaque pointer to the table entry. */
  table_entry_t LookupTableEntry (const char *table, const char *key_field,
				  const char *key);
  table_entry_t LookupNumericTableEntry (const char *table,
					 const char *key_field, int key);
  /* Find an entry in a data table by index. */
  table_entry_t LookupIndexedTableEntry (const char *table, int index);
  /* Find the entry following a given one. */
  table_entry_t LookupNextEntryAfter (table_entry_t);
  /* Find the Nth entry following (or preceding) a given one. */
  table_entry_t LookupNthEntryAfter (table_entry_t, int);

  /* Return the number of entries in a given table;
     useful for finding the range of an indexed table. */
  int GetTableSize (const char *table);

  /* Get the value of one of the fields in a table entry,
     according to the expected data type.
     ***NOTE: These functions do NOT return error conditions.
     If a field is empty or the column doesn't exist,
     GetEntryStringField will return an empty string (""),
     and GetEntryIntegerField will return 0. */
  const char *GetEntryStringField (table_entry_t, const char *field);
  int GetEntryIntegerField (table_entry_t, const char *field);

#ifdef __cplusplus
}
#endif

#endif /* TABLES_H */
