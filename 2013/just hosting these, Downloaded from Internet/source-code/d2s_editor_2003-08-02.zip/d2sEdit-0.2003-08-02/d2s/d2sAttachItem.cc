/* d2sAttachItem -- C++ intermediate class from which attachable items
 *		    (gems, runes, and jewels) are derived
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "internal.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Initialize the d2sAttachItem part of a derived class */
d2sAttachItem::d2sAttachItem (void)
  : d2sItem ()		// Construct the base class part first
{
  nvop = this;
  attachment = NULL;
  attached_type = GEM_ATTACHMENT_UNKNOWN;
  socket_number = 0;
}

/* This is just here for our derived classes */
d2sAttachItem::d2sAttachItem (table_entry_t tent)
  : d2sItem (tent)
{
  nvop = this;
  attachment = NULL;
  attached_type = GEM_ATTACHMENT_UNKNOWN;
  socket_number = 0;
}

/* Copy an existing attachable item */
d2sAttachItem::d2sAttachItem (const d2sAttachItem &source)
  : d2sItem (source)	// Construct the base class part first
{
  nvop = this;

  /* Note that d2sItem::d2sItem(source) will have already copied the
     general item fields.  Our only additional fields are links to a
     parent item.  But a copy can't share the same parent as the
     original, so we must leave these fields clear. */
  attachment = NULL;
  attached_type = GEM_ATTACHMENT_UNKNOWN;
  socket_number = 0;
}

/* Mark an attachable dirty.  In addition to the attachable itself,
   we also need to mark as dirty whatever item it is attached to. */
void
d2sAttachItem::MarkDirty (void)
{
  this->d2sItem::MarkDirty ();
  if (attachment != NULL)
    attachment->MarkDirty ();
}

/* Change the location of the attachable.  Like the superclass version,
   but extra stuff needs to be done if the item was in a socket. */
int
d2sAttachItem::SetLocation (int area, int new_slot_or_column, int new_row)
{
  int status;

  if (CheckLocationChange (area, new_slot_or_column, new_row) < 0)
    return -1;

  if (area == ITEM_AREA_SOCKETED)
    {
      fprintf (stderr, "%s: Internal error: SetLocation called"
	       " with argument ITEM_AREA_SOCKETED\n", progname);
      error_str = "Internal error";
      return -1;
    }

  /* Let the parent class handle the actual movement. */
  status = this->d2sItem::SetLocation (area, new_slot_or_column, new_row);

  /* If it succeeded, detach from the parent item. */
  if (status == 0)
    {
      /* Detach from the parent item */
      attachment = NULL;
      attached_type = GEM_ATTACHMENT_UNKNOWN;
      socket_number = 0;
    }

  return status;
}

/* Specify which item an attachable is attached to.  Note that if this
   item already belongs to a character, the item to which it is being
   attached must belong to the same character.  If so, it will first
   be removed from its current location. */
int
d2sAttachItem::AttachTo (d2sDurableItem *parent_item, int new_socket)
{
  if (CheckLocationChange (ITEM_AREA_SOCKETED, 0, 0) < 0)
    return -1;

  if (parent_item == NULL)
    {
      /* Removing from current attachment */
      attachment = NULL;
      if (location || loc_1)
	{
	  location = 0;
	  loc_1 = 0;
	  MarkDirty ();
	}
      return 0;
    }

  if ((character != NULL) && (character != parent_item->Owner()))
    {
      if (parent_item->Owner() == NULL)
	print_message ("You cannot attach %s's %s to an unclaimed %s\n",
		       character->GetCharacterName(), base_name,
		       parent_item->Name());
      else
	print_message ("You cannot attach %s's %s to %s's %s\n",
		       character->GetCharacterName(), base_name,
		       parent_item->Owner()->GetCharacterName(),
		       parent_item->Name());
      error_str = "Invalid attachment";
      return -1;
    }

  if ((location != ITEM_AREA_SOCKETED)
      || (loc_1 != ITEM_LOCATION_IN_SOCKET) || stored_loc)
    {
      location = ITEM_AREA_SOCKETED;
      loc_1 = ITEM_LOCATION_IN_SOCKET;
      stored_loc = 0;
      MarkDirty ();
    }
  attachment = parent_item;
  if (parent_item->Type() == WEAPON_ITEM)
    attached_type = GEM_ATTACHED_WEAPON;
  else if (parent_item->Type() == ARMOR_ITEM)
    {
      switch (((d2sArmorItem *) parent_item)->ArmorClass())
	{
	case BODY_ARMOR_CLASS:
	  attached_type = GEM_ATTACHED_ARMOR;
	  break;
	case HELMET_CLASS:
	  attached_type = GEM_ATTACHED_HELM;
	  break;
	case SHIELD_CLASS:
	  attached_type = GEM_ATTACHED_SHIELD;
	  break;
	default:
	  attached_type = GEM_ATTACHMENT_UNKNOWN;
	  break;
	}
    }
  else
    attached_type = GEM_ATTACHMENT_UNKNOWN;
  socket_number = new_socket;
  return 0;
}

/* Cast an attachable item to a jewel subclass. */
d2sAttachItem::operator d2sJewelItem* () const
{
  if (item_class == JEWEL_ITEM)
    return (d2sJewelItem *) nvop;
  fprintf (stderr, "%s: Internal error: attempt to cast a %s to a jewel\n",
	   progname, (table_entry == NULL) ? base_name
	   : GetEntryStringField (type_entry, "ItemType"));
  abort ();
  /* NOTREACHED */
}
