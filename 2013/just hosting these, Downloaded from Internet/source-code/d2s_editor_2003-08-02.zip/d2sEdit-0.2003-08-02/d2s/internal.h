/* Private definitions for the Diablo II v1.09 game editor.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef INTERNAL_H
#define INTERNAL_H

#include <stdint.h>
#include "define.h"

/* The structure of the constant part of a .d2s file: */
struct d2s_header {
  uint32_t	magic;		/* 0xaa55aa55 */
  uint32_t	version;	/* 71 for v1.00-v1.06, 87 for v1.07-v1.08
				   (expansion), 89 for v1.08 (normal),
				   92 for v1.09 */
  uint32_t	length;		/* file size */
  uint32_t	checksum;
  uint32_t	unknown10;	/* 0 */
  char		name[16];	/* _null-terminated_ character name */
  uint8_t	char_status;	/* killed, resurrected, hardcore, dead?
				   Also contains Expansion Character bit. */
#define CHAR_STATUS_BIT_EXPANSION	0x20
  uint8_t	char_title;	/* 4 = sir/dame, 8 = lord/lady,
				   12 = baron/baroness */
#define CHAR_TITLE_MASK 	0x0c
  uint8_t	unknown26[2];	/* 0 */
  uint8_t	char_class;	/* type of character */
  uint8_t	unknown29[2];	/* { 16, 30 } */
  uint8_t	level;		/* as shown on character selection screen */
  uint32_t	unknown2c;	/* 0 */
  uint32_t	timestamp;
  uint16_t	unknown34[34]; /* 0's and -1's */
  uint32_t	button_action[4]; /* Skill / action ID #; left, right,
				  alt. left, alt. right */
  uint8_t	unknown88[10];	/* 2's, 3's, a 5, 60, 79, and -1 */
  uint8_t	unknown92[22];	/* mostly -1's, except for one 168 or some 68's */
  uint8_t	difficulty[3];	/* non-zero in [0] for normal,
				   [1] for nightmare, [2] for hell */
  uint32_t	map_id; 	/* Corresponds with one of the longwords
				   in the .map file, according to which
				   map is in use? */
  uint16_t	unknownaf;	/* 0 */
  uint16_t	hireling_died;
  uint32_t	hireling_id;	/* Random number? */
  uint16_t	hireling_name;	/* Index into the mercenary name strings */
  /* This field (at least the first byte) is confirmed as the "id" column
     in the official hireling table -- determines hireling's difficulty
     level (of origin) and attribute (fire, offense, cold, etc.) */
  uint16_t	hireling_attribute;
  uint32_t	hireling_experience;
  uint8_t	unknownbf[144]; /* all zeroes */
  char		quest_magic[4]; /* "Woo!" */
  uint8_t	unknown153[6];	/* the quest completion data is in here */
  struct {
    struct {
      uint16_t	intros;
      uint16_t	quests[6];
      uint16_t	completed;
    } act[3];
    struct {
      uint16_t	intros;
      uint16_t	quests[3];
      uint16_t	completed;
    } act_4;
    uint16_t	unknown_58[3];
    uint16_t	talked_to_Cain_in_Act_IV;
    uint16_t	unknown_66;
    struct {
      uint16_t	intros;
      uint16_t	quests[6];
      uint16_t	completed;
    } act_5;
    uint16_t	unknown_84[6]; /* all zeroes */
  } quests[3];			/* One structure per difficulty level */
  char		waypoint_magic[2]; /* "WS" */
  uint8_t	unknown27b[6]; /* sparse data */
  struct {
    uint8_t	unknown[2];	/* { 2, 1 } */
    uint8_t	points[5];	/* LSB is 1st waypoint of act 1; */
    /* continues consecutively to bit 38 = last waypoint of act 5
       (9 each in acts 1-3 and 5, 3 in act 4) */
    uint8_t	unknown_6[17]; /* zeroes */
  } __attribute__ ((packed))
       waypoints[3]; /* One structure per difficulty level */
  uint8_t	unknown2c9;
  char		NPC_magic[2]; /* "w4" */
  uint8_t	introductions[3][8];
  uint8_t	congratulations[3][8];
  uint8_t	unknown2fc;
  char		stats_magic[2]; /* "gf" */
  /* The header ends here, because the next piece of data is a single
     byte, which is followed by several 32-bit values.  The 32-bit
     data must be *packed*! */
} __attribute__ ((packed));


/* The structure of the constant part of a Diablo II v1.09 item: */
struct item_header {
  char		magic[2];	/* "JM" */
  /* Note: little bit-endian (lowest ordered bits allocated first).
     I considered making this without bitfields, but the integer data
     is already dependent on the byte order, and this particular structure
     has bitfields crossing nearly every byte boundary there is. */
  uint16_t	unknown2:4;
  uint16_t	identified:1;
  uint16_t	unknown2_5:6;
  uint16_t	socketed:1;
  uint16_t	unknown3_4:1;
  uint16_t	new_in_session:1;
  uint16_t	unknown3_6:3;
  uint16_t	newbie:1;
  uint16_t	unknown4_2:3;
  uint16_t	simple:1;
  uint16_t	ethereal:1;
  uint16_t	unknown4_7:1;
  uint16_t	personalized:1;
  uint16_t	unknown5_1:1;
  uint16_t	runeworded:1;
  uint16_t	unknown5_3:5;
  uint16_t	unknown6:10;
  uint16_t	location:3;
#define ITEM_LOCATION_IN_STORAGE 0
#define ITEM_LOCATION_EQUIPPED	1
#define ITEM_LOCATION_IN_BELT	2
#define ITEM_LOCATION_IN_TRANSIT 4
#define ITEM_LOCATION_IN_SOCKET 6
  uint16_t	equipped_slot:4;	/* i.e., head, finger, feet, etc. */
  uint16_t	column:4;
  uint16_t	row:3;
  uint32_t	unknown9:1;
  uint32_t	stored_location:3;
#define ITEM_STORED_IN_INVENTORY 1
#define ITEM_STORED_IN_CUBE	4
#define ITEM_STORED_IN_STASH	5
  uint32_t	item_ID:24;	/* 3-letter code */
  uint32_t	ID_space:8;	/* probably part of item_ID; always ' '. */
  uint16_t	gem_count:3;
  uint16_t	unique_id0:1;	/* first bit of an extended item */
} __attribute__ ((packed));

/* The fields after an extended item's unique ID vary,
   so the extended structure is not attempted here. */


/* Table structures */

/* Templates for new characters */
struct template_stats_struct {
  unsigned short statistics_present;
  unsigned long strength, energy, dexterity, vitality;
  struct {
    unsigned long current, base;
  } life, mana, stamina;
  unsigned long level;
};

struct template_tail_struct {
  char skills_magic[2];
  unsigned char skills[30];
  char items_magic[2];
  unsigned short item_count;
  unsigned char items[6][14];
  char item_tail[4];
};


/* Global data tables */

/* These tables are generated in d2sInit.cc */
extern const char * const class_names[NUM_CHAR_CLASSES];

extern const struct d2s_header template_d2s_header;
extern const struct template_stats_struct template_d2s_stats_section[];
extern const struct template_tail_struct template_d2s_tail_section;
extern const unsigned char template_d2s_class_items[NUM_CHAR_CLASSES][48];
/* extern struct ??? template_key; */
/* This one is different for each character;
   need to see if it's different for each game. */
extern unsigned char template_map[NUM_CHAR_CLASSES][24];
/* This one seems to vary in length */
extern unsigned char template_ma0[5120];


#ifdef __cplusplus
extern "C" {
#endif
  /* For internal use; initialize the data tables. */
  void init_data_tables (void);
  void load_magic_property_tables (void);
#ifdef __cplusplus
}
#endif

#endif /* INTERNAL_H */
