/* d2sDurableItem -- C++ intermediate class from which durable items
 *		     (armor and weapons) are derived.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sMagic.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Create a new, blank durable item */
d2sDurableItem::d2sDurableItem (void)
  /* Since d2sExtendedItem is a virtual base class, d2sItem()
     should never be called.  It is only here as a formality. */
  : d2sItem (), d2sExtendedItem ()
{
  nvop = this;
  restricted_item = 0;
  class_restriction = 0;
  base_durability = 1;
  durability = 1;
  max_sockets = 0;
  base_dexterity = 0;
  base_strength = 0;
  gems = NULL;
}

/* Create a new, specific durable item as described by the item table entry
   (using default variable attributes) */
d2sDurableItem::d2sDurableItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (tent), d2sExtendedItem (tent)
{
  const char *cstr;

  /* Change the nvop (very important) */
  nvop = this;

  /* Get some of our fields from the (armor or weapons) table */
  base_durability = GetEntryIntegerField (tent, "durability");
  durability = base_durability;
  max_sockets = GetEntryIntegerField (tent, "gemsockets");
  base_dexterity = GetEntryIntegerField (tent, "reqdex");
  base_strength = GetEntryIntegerField (tent, "reqstr");

  /* The class restriction comes from the item types table */
  cstr = GetEntryStringField (type_entry, "Class");
  if (cstr[0]) {
    restricted_item = 1;
    class_restriction = GetEntryIntegerField
      (LookupTableEntry ("playerclass", "Code", cstr),
       NULL /* Returns the index number of the entry */);
    if ((unsigned) class_restriction >= NUM_CHAR_CLASSES) {
      if (debug)
	fprintf (stderr, "%s: Error in playerclass table; %s (%s) found at"
		 " index %d\n", progname,
		 GetEntryStringField (LookupTableEntry ("playerclass", "Code",
							cstr),
				      "Player Class"),
		 cstr, class_restriction);
      class_restriction = 0;
      restricted_item = 0;
    }
  } else {
    restricted_item = 0;
    class_restriction = 0;
  }

  gems = NULL;
}

/* Copy an existing durable item */
d2sDurableItem::d2sDurableItem (const d2sDurableItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (source), d2sExtendedItem (source)
{
  int		n;
  d2sAttachItem *gem;

  /* Change the nvop (very important) */
  nvop = this;

  /* Now copy our own fields */
  this->restricted_item = source.restricted_item;
  this->class_restriction = source.class_restriction;
  this->base_durability = source.base_durability;
  this->durability = source.durability;
  this->max_sockets = source.max_sockets;
  this->base_dexterity = source.base_dexterity;
  this->base_strength = source.base_strength;
  /* Hmmm... should we copy the attached gems, or no?
     I'm tempted to say yes, because the gems are (supposed to be) a
     permanent addition to the item.  On the other hand, I'm tempted
     to say no, to keep things simple. */
  gem_count = 0;
  gems = NULL;
  /* I think, because this should work with cut-and-paste operations
     (plus drag-and-drop), we need to keep all attached gems intact. */
  for (n = 0; n < source.gem_count; n++)
    {
      gem = (d2sAttachItem *) *(source.gems[n]->Copy());
      if (gem == NULL)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to copy %s\n",
		     progname, source.gems[n]->Name());
	  continue;
	}
      if (gem->GetErrorMessage() != NULL)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error copying %s; %s\n",
		     progname, gem->Name(), gem->GetErrorMessage());
	  delete gem;
	  continue;
	}
      if (this->AddGem (gem) < 0)
	delete gem;
    }
}

/* Destructor */
d2sDurableItem::~d2sDurableItem ()
{
  int i;

  if (gems != NULL)
    {
      /* Free the attached gems */
      for (i = 0; i < gem_count; i++)
	delete gems[i];
      free (gems);
      gems = NULL;
    }
}

/* Copy a template durable item, and fill in the rest of the data
   using data from an item file or character file. */
int
d2sDurableItem::Read (struct data_stream *dstream)
{
  int status, gems_left;
  unsigned char *old_ptr, *durable_item_start;
  d2sItem *gem_item;

  durable_item_start = dstream->ptr;

  /* The parent class does the actual reading */
  status = this->d2sExtendedItem::Read (dstream);
  if (status < 0)
    {
      /* This is an error that interrupts the read */
      gem_count = 0;
      MarkDirty ();
      return status;
    }

  /* If we are supposed to have gems attached,
     read them from the same file.  If there is
     no more data in the file, clear our gem count. */
  if (gem_count)
    {
      gems_left = gem_count;
      gem_count = 0;	// This will be rebuilt as we read the gems
      while (gems_left && !dstream_eof (*dstream))
	{
	  old_ptr = dstream->ptr;	// Just in case...
	  gem_item = ReadItemFromFile (dstream);
	  if (gem_item == NULL)
	    break;
	  if ((gem_item->Type() != GEM_ITEM)
	      && (gem_item->Type() != RUNE_ITEM)
	      && (gem_item->Type() != JEWEL_ITEM))
	    {
	      /* Oops!  Regurgitate the non-gem item */
	      dstream->ptr = old_ptr;
	      print_message ("Error in item data: \"%s\" is supposed to"
			     " have %d gems,\n" " but only %d gems followed"
			     " before encountering \"%s\".\n", base_name,
			     gem_count + gems_left, gem_count,
			     gem_item->Name());
	      delete gem_item;
	      break;
	    }
	  if (gem_item->Location() != ITEM_AREA_SOCKETED)
	    {
	      /* Oops!  Regurgitate the gem that isn't in a socket */
	      dstream->ptr = old_ptr;
	      print_message ("Error in item data: \"%s\" is supposed to"
			     " have %d gems,\n" " but only the next %d gems"
			     " are in a socket (\"%s\" is not).\n", base_name,
			     gem_count + gems_left, gem_count,
			     gem_item->Name());
	      delete gem_item;
	      break;
	    }

	  /* Note the funky 'type cast'; it's actually a class
	     operator <type>, which requires the class object
	     to be passed by reference rather than pointer. */
	  AddGem ((d2sAttachItem *) *gem_item);
	  --gems_left;
	}

      /* Append the gem records we've collected to our raw data. */
      ReplaceRawData (durable_item_start, dstream->ptr - durable_item_start);

      /* The AddGem() function will have marked this item dirty.
	 But it isn't (since we added the gem's raw data to our own),
	 so clear the dirty flag. */
      dirty = False;
    }

  return status;
}

/* Commit changes made to the item to the raw data field.
   In this class, that includes appending any gem records
   that are attached to this item. */
void
d2sDurableItem::CommitChanges (void)
{
  int n;
  struct data_stream dstream;

  /* Commit changes to this item first */
  this->d2sExtendedItem::CommitChanges ();

  /* We begin after our own item record */
  dstream_set (dstream, raw_data, raw_length, raw_length);

  /* For each gem, */
  for (n = 0; n < gem_count; n++)
    /* Append the gem's raw data to our own */
    gems[n]->Write (&dstream);

  /* Update our raw data pointer and length (critical!) */
  raw_data = dstream.base;
  raw_length = (unsigned int) (dstream.ptr - dstream.base);
}

/* Discard changes made to the item.
   Before calling the base class to do the work,
   we need to check any attached gems to find out if they were modified. */
void
d2sDurableItem::DiscardChanges (void)
{
  int n;

  if (!dirty)
    {
      for (n = 0; n < gem_count; n++)
	if (gems[n]->needs_saving())
	  {
	    MarkDirty ();
	    break;
	  }
    }

  if (!dirty)
    /* Nothing has changed. */
    return;

  /* Discard changes to the base class first */
  this->d2sExtendedItem::DiscardChanges ();

  /* TO-DO: re-read the attached gems */
  fprintf (stderr, "%s: Warning: d2sDurableItem::DiscardChanges stubbed\n",
	   progname);
}

/* Remove an item, and any attached items,
   from its associated character. */
int
d2sDurableItem::RemoveFromOwner (void)
{
  int n;

  for (n = 0; n < gem_count; n++)
    gems[n]->RemoveFromOwner ();
  character = NULL;
  return 0;
}

/* Assign an item, and any attached items, to a character. */
int
d2sDurableItem::AssignTo (d2sData *new_char, int area)
{
  int n;

  /* Assign ourself first */
  if (this->d2sItem::AssignTo (new_char, area) < 0)
    return -1;

  for (n = 0; n < gem_count; n++)
    gems[n]->AssignTo (new_char, ITEM_AREA_SOCKETED);
  return 0;
}

/* Return the maximum of the item's own level requirement
   and those of all its attached gems. */
int
d2sDurableItem::RequiredLevel (void) const
{
  int		max_level, i;
  d2sMagic	*comb;
  d2sMagicProperty *property;
  d2sJewelItem	*jewel;

  /* Start with the item's requirement.
     We dont call the d2sExtendedItem version, because
     we need the requirement *before* "ease" is applied. */
  max_level = item_quality->RequiredLevel();
  if (base_level > max_level)
    max_level = base_level;

  /* Compare with the requirement for each attached gem */
  for (i = 0; i < gem_count; i++)
    {
      /* Note that for jewels, we must access the required level
	 of its quality setting directly, to prevent it from
	 being modified by the jewel's own magic properties. */
      if (gems[i]->Type() == JEWEL_ITEM)
	{
	  jewel = (d2sJewelItem *) *gems[i];
	  if (max_level < jewel->Quality()->RequiredLevel())
	    max_level = jewel->Quality()->RequiredLevel();
	}
      else
	{
	  if (max_level < gems[i]->BaseRequiredLevel())
	    max_level = gems[i]->BaseRequiredLevel();
	}
    }

  /* Now apply the "ease" mod. */
  comb = CombinedProperties();
  property = comb->Lookup ("ease");
  if (property != NULL)
    max_level = (int)
      ((double) max_level
       * (100 + property->FieldData(0) - property->Bias()) / 100.0);
  delete comb;

  return max_level;
}

/* Durable items need to test whether any attached gems
   are expansion items, as well as the item itself. */
int
d2sDurableItem::is_expansion_item (void) const
{
  int n;

  if (expansion_item || item_quality->is_expansion()
      || magic_properties->is_expansion())
    return True;
  for (n = 0; n < gem_count; n++)
    if (gems[0]->is_expansion_item())
      return True;
  return False;
}

/* Return the color of an item.  Computed on the fly because it
   depends on any attached gems and the state of the item quality. */
const char *
d2sDurableItem::Color (void) const 
{
  const char *color_code;

  if (!color_group)
    return NULL;

  color_code = item_quality->Color();
  /* Gems are overridden by a default color,
     or are ignored on a rare item. */
  if ((color_code == NULL) && gem_count
      && (item_quality->QualityClass() != RARE_QUALITY))
    switch (gems[0]->Type())
      {
      case JEWEL_ITEM:
	if (((d2sJewelItem *) gems[0])->Quality()->is_colored())
	  color_code = ((d2sJewelItem *) gems[0])->Quality()->Color();
	break;
      case GEM_ITEM:
	/* All gems must have color */
	color_code = ((d2sGemItem *) gems[0])->Color();
	break;
      case RUNE_ITEM:
	/* Runes do not have color */
      case UNKNOWN_ITEM:
	/* All other item types are listed here simply to alleviate
	   compiler warnings about missing enumeration values. */
      case SIMPLE_ITEM:
      case POTION_ITEM:
      case UNKNOWN_EXTENDED_ITEM:
      case EXTENDED_ITEM:
      case STACK_ITEM:
      case CHARM_ITEM:
      case ARMOR_ITEM:
      case WEAPON_ITEM:
      case STACKED_WEAPON_ITEM:
	break;
      }

  if ((color_code == NULL) || (color_group >= 5))
    return color_code;

  /* For grey items, convert the color code to a different palette. */
  return GetEntryStringField (LookupTableEntry ("colors", "Code", color_code),
			      "Grey");
}

/* Return whether an item is colored.  A little more involved
   that the d2sExtendedItem version (two more conditions). */
int
d2sDurableItem::is_colored (void) const
{
  if (!color_group)
    return False;
  if (item_quality->Color() != NULL)
    return True;
  if (!gem_count || (item_quality->QualityClass() == RARE_QUALITY))
    return False;
  switch (gems[0]->Type())
    {
    case JEWEL_ITEM:
      return ((d2sJewelItem *) gems[0])->Quality()->is_colored();
    case RUNE_ITEM:
      return False;
    case GEM_ITEM:
      /* All gems must have a color */
      return True;
    case UNKNOWN_ITEM:
      /* All other item types are listed here simply to alleviate
	 compiler warnings about missing enumeration values. */
    case SIMPLE_ITEM:
    case POTION_ITEM:
    case UNKNOWN_EXTENDED_ITEM:
    case EXTENDED_ITEM:
    case STACK_ITEM:
    case CHARM_ITEM:
    case ARMOR_ITEM:
    case WEAPON_ITEM:
    case STACKED_WEAPON_ITEM:
      break;
    }
  /* This should never be reached */
  return False;
}

/* For most durable items, the combined properties
   adds the item's own properties to those of all attached gems. */
d2sMagic *
d2sDurableItem::CombinedProperties (void) const
{
  int n;
  /* Start with a copy of our own properties */
  d2sMagic *ret_props = new d2sMagic (*magic_properties);
  for (n = 0; n < gem_count; n++)
    {
      /* Add the properties for each attached gem */
      if (gems[n]->Type() == JEWEL_ITEM)
	*ret_props += *((d2sJewelItem *) *gems[n])->Properties();
      else
	*ret_props += *((d2sGemOrRuneItem *) gems[n])->Properties();
    }
  return ret_props;
}

/* Change the item level.  Overrides the default method
   because we need to check whether reducing the level
   would bump out any existing gems. */
int
d2sDurableItem::SetLevel (int new_level)
{
  int new_maxs, old_level;

  if (new_level == level)
    /* Nothing to do */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.level)
    {
      error_str = "You may not edit the item level";
      print_message (error_str);
      return -1;
    }

  /* Make sure the level meets the item minimum */
  if (!options.character.link.freeform
      && (new_level < GetEntryIntegerField (table_entry, "level")))
    {
      print_message ("Level is too low; a %s must be at least level %d",
		     base_name, GetEntryIntegerField (table_entry, "level"));
      error_str = "Level too low";
      return -1;
    }
  if (new_level > 100)
    {
      error_str = "Level is too high";
      print_message (error_str);
      return -1;
    }

  /* Temporarily set the new level in order to see
     the change in the maximum number of sockets. */
  old_level = level;
  level = new_level;
  if (max_sockets && (new_level < old_level)
      && !options.character.link.freeform)
    {
      new_maxs = MaximumNumberOfSockets();
      if (new_maxs < gem_count)
	{
	  level = old_level;
	  print_message ("Setting the %s level to %d would result"
			 " in a maximum of %d sockets.  This %s has"
			 " %d gems attached.  Cannot change the level.\n",
			 base_name, new_level, new_maxs, base_name, gem_count);
	  error_str = "Cannot reduce the socket count";
	  return -1;
	}

      /* Reduce the socket count if needed. */
      if (num_sockets > new_maxs)
	num_sockets = new_maxs;
    }

  MarkDirty ();
  return 0;
}

/* Change an item's quality */
int
d2sDurableItem::ChangeQuality (int new_quality)
{
  /* The parent class does the actual work */
  int status = d2sExtendedItem::ChangeQuality (new_quality);

  /* If the magic properties were regenerated,
     we may need to reapply the Rune Word properties. */
  if ((status >= 0) && runeworded_item)
    ReapplyRuneWord ();
  return status;
}

int
d2sDurableItem::ChangeQuality (d2sQuality *new_quality)
{
  /* The parent class does the actual work */
  int status = d2sExtendedItem::ChangeQuality (new_quality);

  /* If the magic properties were regenerated,
     we may need to reapply the Rune Word properties. */
  if ((status >= 0) && runeworded_item)
    ReapplyRuneWord ();
  return status;
}

/* Get the item's maximum durability
   after applying any magical enhancements */
int
d2sDurableItem::MaxDurability (void) const
{
  int max_durability = base_durability;
  d2sMagic	*comb;
  d2sMagicProperty *property;

  if (!max_durability)
    return 0;

  comb = CombinedProperties();
  property = comb->Lookup ("indestruct");
  if (property != NULL)
    max_durability = 0;
  else
    {
      property = comb->Lookup ("dur");
      if (property != NULL)
	max_durability += property->FieldData(0) - property->Bias();

      property = comb->Lookup ("dur%");
      if (property != NULL)
	max_durability = (int)
	  ((double) max_durability
	   * (100 + property->FieldData(0) - property->Bias()) / 100.0);
    }
  delete comb;

  /* The durability is capped at 255
     (the largest value that can be represented in 8 bits) */
  if (max_durability > 255)
    max_durability = 255;

  return max_durability;
}

/* Get the item's requirements */
int
d2sDurableItem::RequiredDexterity (void) const
{
  int dexterity = base_dexterity;
  d2sMagic	*comb;
  d2sMagicProperty *property;

  /* The only magic property (that I know of) which modifies
     the requirements is "ease". */
  comb = CombinedProperties();
  property = comb->Lookup ("ease");
  if (property != NULL)
    dexterity = (int)
      ((double) dexterity
       * (100 + property->FieldData(0) - property->Bias()) / 100.0);
  delete comb;
  return dexterity;
}

int
d2sDurableItem::RequiredStrength (void) const
{
  int strength = base_strength;
  d2sMagic	*comb;
  d2sMagicProperty *property;

  comb = CombinedProperties();
  property = comb->Lookup ("ease");
  if (property != NULL)
    strength = (int)
      ((double) strength
       * (100 + property->FieldData(0) - property->Bias()) / 100.0);
  delete comb;
  return strength;
}

/* Return the item's current number of sockets; base + mods */
int
d2sDurableItem::ModNumberOfSockets (void) const
{
  d2sMagicProperty *property;
  int nsock = num_sockets;

  /* The only property we need to look for is "sock".
     An item that currently is not socketed can't take the "sock" modifier */
  if (!nsock)
    return nsock;
  property = magic_properties->Lookup ("sock");
  if (property != NULL)
    {
      nsock += property->FieldData (0);
      /* Restrict the total number to the freeform limit (size or 6) */
      if (nsock > 6)
	nsock = 6;
      if (nsock > width * height)
	nsock = width * height;
    }
  return nsock;
}

/* Return the item's maximum number of sockets.
   This number is limited according to the item level. */
int
d2sDurableItem::MaximumNumberOfSockets (void) const
{
  int	maxs = max_sockets;
  int	limit;

  if (options.character.link.freeform)
    {
      /* Allow values up to the size of the item or 6, whichever is
	 less.  Any more will cause unpredictable behavior in the
	 game, including possible crash. */
      maxs = width * height;
      if (maxs > 6)
	maxs = 6;
      return maxs;
    }

  limit = GetEntryIntegerField
    (type_entry, ((level < 41) ? ((level < 26) ? "MaxSock1" : "MaxSock25")
		  : "MaxSock40"));
  if (maxs > limit)
    maxs = limit;
  if ((level >= 40) && (limit < max_sockets))
    if (debug)
      fprintf (stderr, "%s: Note: %s's maximum number of sockets is %d,\n"
	       " but a level 40+ %s's maximum number of sockets is %d.\n",
	       progname, base_name, max_sockets,
	       GetEntryStringField (type_entry, "ItemType"), limit);

  return maxs;
}

/* Return the Nth gem, rune, or jewel attached to the item */
d2sAttachItem *
d2sDurableItem::Gem (int n)
{
  if ((unsigned) n >= (unsigned) gem_count)
    return NULL;
  if (gems == NULL)
    {
      if (debug)
	fprintf (stderr, "Internal error: d2sDurableItem::gems is NULL;\n"
		 "d2sDurableItem::gem_count is %d", gem_count);
      gem_count = 0;
      return NULL;
    }
  return gems[n];
}

/* Return the word formed by any runes attached to the item */
char *
d2sDurableItem::RuneName (void) const
{
  int	n, len = 0;
  char *word = NULL;
  char	rune_key[8];
  const char *runestr;

  for (n = 0; n < gem_count; n++)
    {
      if (gems[n]->Type() != RUNE_ITEM)
	continue;
      snprintf (rune_key, sizeof (rune_key), "%sL", gems[n]->Code());
      runestr = LookupStringByKey (rune_key);
      if (runestr != NULL)
	{
	  word = (char *) xrealloc (word, len + strlen (runestr) + 1);
	  strcpy (&word[len], runestr);
	  len += strlen (runestr);
	}
    }

  return word;
}

/* When runes are inserted into an item in a certain order,
   they may form a 'Rune Word'. */
const char *
d2sDurableItem::RuneWord (void) const
{
  int	n;
  char	rune_key[16];
  table_entry_t rwe;

  if (!runeworded_item)
    return NULL;
  /* Translate the runeword ID to an index into the sorted runes table.
     Note that we have to account for a nonexistent entry (80). */
  n = runeword_id - 0x501a;
  if (n >= 80)
    n++;
  if ((n < 1) || (n > GetTableSize ("runes")))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: Rune Word ID is %#x on %s\n",
		 progname, runeword_id, base_name);
      return NULL;
    }

  sprintf (rune_key, "Runeword%d", n);
  rwe = LookupTableEntry ("runes", "Name", rune_key);
  if (rwe == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: Rune Word ID %#x\n"
		 " not found in the runes table\n",
		 progname, runeword_id);
      return NULL;
    }
  return GetEntryStringField (rwe, "Rune Name");
}

table_entry_t
d2sDurableItem::find_rune_word (void) const
{
  int		n;
  char		rune_key[16];
  const char	*cstr;
  table_entry_t rwe;
  /* According to The Arreat Summit, magic items cannot have a rune
     word, and normal items must have the exact number of sockets
     required for a rune word.  This means that all sockets must be
     filled with runes in the correct order. */
  if (item_quality->QualityClass() >= MAGIC_QUALITY)
    return NULL;
  if (gem_count != ModNumberOfSockets())
    return NULL;
  for (n = 0; n < gem_count; n++)
    if (gems[n]->Type() != RUNE_ITEM)
      return NULL;

  /* Look through the list of rune words */
  for (rwe = LookupIndexedTableEntry ("runes", 0);
       rwe != NULL; rwe = LookupNextEntryAfter (rwe))
    {
      /* There are a lot of unused entries in the runes table */
      if (!GetEntryIntegerField (rwe, "complete"))
	continue;

      /* Check whether this item matches the type required for the word */
      for (n = 0; n < 6; n++)
	{
	  sprintf (rune_key, "itype%d", n + 1);
	  cstr = GetEntryStringField (rwe, rune_key);
	  if (cstr[0] && this->is_of_type (cstr))
	    break;
	}
      if (n >= 6)
	continue;

    /* Check whether the runes match */
    for (n = 0; n < 8; n++)
      {
	sprintf (rune_key, "Rune%d", n + 1);
	cstr = GetEntryStringField (rwe, rune_key);
	if (n >= gem_count)
	  /* Check for the end of the word */
	  break;
	if (!cstr[0])
	  /* Too many gems */
	  break;
	if (*gems[n] != cstr)
	  /* Rune doesn't match */
	  break;
      }
    /* Check for a mismatch (comparison stopped short) */
    if ((n < gem_count) || cstr[0])
      continue;

    /* It's a match!  Return the rune word entry. */
    return rwe;
  }
  /* No match. */
  return NULL;
}

/* Set the base durability of an item */
int
d2sDurableItem::SetBaseDurability (int new_durability)
{
  double	percent_remaining;
  int		max_durability;

  if (base_durability == new_durability)
    /* Nothing is changed */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.base_durability)
    {
      print_message ("You may not change the durability of this %s\n",
		     base_name);
      error_str = "Base durability may not be modified";
      return -1;
    }
  /* Note that the defense_max option is used for base durability too */
  if (!options.item.link.defense_max)
    {
      /* Check against the durability given for this item in the
	 item table.  The table only gives a single number, not a
	 range; I have no idea what range is allowed by the game
	 (but it does change for low- or high-quality items). */
      if ((new_durability < (GetEntryIntegerField (table_entry, "durability")
			      * 3 / 4))
	  && new_durability) {
	  print_message
	    ("I don't know whether the durability for a %s"
	     " can drop below %d\n", base_name,
	     GetEntryIntegerField (table_entry, "durability") * 3 / 4);
	  error_str = "Durability too low";
	  return -1;
	}
	if (new_durability > (GetEntryIntegerField (table_entry, "durability")
			      * 5 / 4)) {
	  print_message
	    ("I don't know whether the durability for a %s"
	     " can rise above %d\n", base_name,
	     GetEntryIntegerField (table_entry, "durability") * 5 / 4);
	  error_str = "Durability too high";
	  return -1;
	}
    }

  if ((new_durability < 0) || (new_durability > 0xff))
    {
      print_message ("Durability (%d) is out of range; must be less than %d\n",
		     new_durability, 0xff);
      error_str = "Invalid durability";
      return -1;
    }

  if (options.item.link.durability_base)
    {
      /* The current durability scales with the maximum */
      max_durability = MaxDurability();
      if (max_durability)
	percent_remaining = (double) durability / max_durability;
      else
	percent_remaining = 1.0;
    }

  base_durability = new_durability;

  if (options.item.link.durability_base)
    durability = (int) rint (percent_remaining * MaxDurability());

  MarkDirty ();
  return 0;
}

/* Set the current durability of an item */
int
d2sDurableItem::SetDurability (int new_durability)
{
  if (durability == new_durability)
    /* Nothing is changed */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.durability)
    {
      print_message ("You may not repair items");
      error_str = "You may not repair items";
      return -1;
    }
  if (ethereal_item && !options.item.link.durability_ethereal)
    {
      print_message ("You may not repair ethereal items");
      error_str = "You may not repair ethereal items";
      return -1;
    }

  /* Check the range */
  if ((new_durability < 0) || (new_durability > 0xff))
    {
      print_message ("Durability (%d) is out of range; must be less than %d\n",
		     new_durability, 0xff);
      error_str = "Invalid durability";
      return -1;
    }
  if ((new_durability > MaxDurability()) && !options.item.link.durability_max)
    {
      print_message ("The maximum durability for this %s is %d\n",
		     base_name, MaxDurability());
      error_str = "Durability out of range";
      return -1;
    }

  durability = new_durability;
  MarkDirty ();
  return 0;
}

/* Add or remove sockets from an item */
int
d2sDurableItem::SetNumberOfSockets (int new_socket_count)
{
  d2sItem *	old_gem;
  int		i, max_socks = MaximumNumberOfSockets();
  d2sMagicProperty *property;
  int		extra = 0;

  /* Is this item socketable? */
  if (!max_socks)
    {
      print_message ("A %s is not socketable\n", base_name);
      error_str = "Item is not socketable";
      return -1;
    }

  if (num_sockets == new_socket_count)
    /* Nothing is changed */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.socket_count)
    {
      error_str = "Number of sockets may not be modified";
      print_message (error_str);
      return -1;
    }

  /* We impose a maximum socket limit regardless of whether the
     character is in freeform mode, because the game itself would
     just delete any extra sockets.  Or crash. */
  if (new_socket_count > max_socks
      && (!options.character.link.freeform
	  || (new_socket_count > width * height)))
    {
      print_message ("The maximum number of sockets on a level %d %s is %d\n",
		     level, base_name, max_socks);
      error_str = "Too many sockets";
      return -1;
    }
  /* Body armor cannot be socketed in a standard game */
  if (!options.item.link.item_expansion
      && (character != NULL) && !character->is_expansion()
      && this->is_of_type ("tors"))
    {
      error_str = "Body armor cannot be socketed in a standard game";
      print_message (error_str);
      return -1;
    }

  /* Would this change affect our attached gems? */
  property = magic_properties->Lookup ("sock");
  if (property != NULL)
    extra = property->FieldData (0);
  if (new_socket_count + extra < gem_count)
    {
      if (!options.item.edit.socketed_gems || !options.item.edit.gem)
	{
	  print_message ("You cannot change the number of sockets to %d"
			 " while you have %d gems attached.\n",
			 new_socket_count, gem_count);
	  error_str = "You have too many gems attached";
	  return -1;
	}
      /* We won't bother trying to move gems.  If the user really
	 wants to reduce the sockets, he'll either have to move the
	 gems himself, open them up in their own window, or lose them. */
      if (!display_question
	  (0, 2, "Cancel", "Remove",
	   "Changing the socket count to %d will require removing %d"
	   " gem%s.  Do you want the last %.0d%s removed automatically?",
	   new_socket_count, gem_count - new_socket_count - extra,
	   (gem_count - new_socket_count - extra > 1) ? "s" : "",
	   ((gem_count - new_socket_count - extra > 1)
	    ? gem_count - new_socket_count - extra : 0),
	   (gem_count - new_socket_count - extra > 1) ? " gems" : "gem"))
	{
	  error_str = "Operation cancelled";
	  return -1;
	}

      /* Remove the extra gems */
      while (gem_count > new_socket_count + extra) {
	old_gem = gems[new_socket_count + extra];
	RemoveGem (new_socket_count + extra);
	/* Delete gems which are no longer referenced */
	if (old_gem->GetUI() == NULL)
	  delete old_gem;
      }
    }

  num_sockets = new_socket_count;
  socketed_item = (num_sockets > 0);

  /* Re-check whether the item should be Rune Worded. */
  if (runeworded_item)
    {
      runeworded_item = False;

      if (options.item.link.quality_magic
	  && (magic_properties->NumberOfPropertyLists() > 1))
	{
	  /* Remove the Rune Word's list of magic properties from the item */
	  i = magic_properties->NumberOfPropertiesInList();
	  while (i < magic_properties->NumberOfProperties())
	    magic_properties->RemoveProperty (i);
	}
    }
  else if (gem_count == ModNumberOfSockets())
    {
      table_entry_t rwe;
      const char *cstr;

      rwe = find_rune_word ();
      if (rwe != NULL)
	{
	  runeworded_item = True;
	  /* Figure out the Rune Word ID */
	  cstr = GetEntryStringField (rwe, "Name");
	  runeword_id = 0;
	  sscanf (cstr, "Runeword%u", &runeword_id);
	  if (runeword_id < 80)
	    runeword_id += 0x501a;
	  else
	    /* There is a missing entry in the runes table */
	    runeword_id += 0x5019;

	  if (options.item.link.quality_magic)
	    /* Append the Rune Word's list of magic properties to the item */
	    ReapplyRuneWord();
	}
    }

  MarkDirty ();
  return 0;
}

/* Change whether an item is ethereal */
int
d2sDurableItem::SetEthereal (int set_ethereal)
{
  if ((int) ethereal_item == set_ethereal)
    /* Nothing to do */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.ethereal)
    {
      print_message ("You may not change the ethereal property"
		     " of this %s\n", base_name);
      error_str = "Ethereal property may not be modified";
      return -1;
    }

  /* The ethereal property is not available in standard games. */
  if (set_ethereal && (character != NULL) && !character->is_expansion()
      && !options.item.link.item_expansion)
    {
      error_str = ("The ethereal property is not available"
		   " in a standard game");
      print_message (error_str);
      return -1;
    }

  ethereal_item = (set_ethereal != 0);
  MarkDirty ();
  return 0;
}

/* Change whether an item is newbie */
int
d2sDurableItem::SetNewbie (int change_newbie)
{
  if ((int) newbie_item == change_newbie)
    /* Nothing to do */
    return 0;

  /* Check for editing options */
  if (read_only() || !options.item.edit.newbie)
    {
      print_message ("You may not change the newbie property"
		     " of this %s\n", base_name);
      error_str = "Newbie property may not be modified";
      return -1;
    }

  newbie_item = (change_newbie != 0);
  MarkDirty ();
  return 0;
}

/* Add a gem to the item.  If the POSITION is specified and a gem is
   already at the given position, insert the gem, moving existing
   gems down a socket.  Otherwise the gem gets placed at the end
   (even if POSITION is past the end). */
int
d2sDurableItem::AddGem (d2sAttachItem *new_gem, int position)
{
  int		n;
  table_entry_t rwe;
  const char	*cstr;

  /* If position is not given, add the gem to the end of the list. */
  if ((position < 0) || (position > gem_count))
    position = gem_count;

  /* Check for editing options */
  if (read_only() || !options.item.edit.socketed_gems)
    {
      error_str = "Gems may not be added";
      if (options.item.edit.socketed_gems)
	print_message ("You may not add gems to %s's %s\n",
		       character->GetCharacterName(), base_name);
      else
	print_message (error_str);
      return -1;
    }
  if ((character != NULL) && !character->is_expansion()
      && new_gem->is_expansion_item() && !options.character.link.freeform)
    {
      print_message ("%ss are not part of the standard game",
		     new_gem->Name());
      error_str = "Expansion Set required";
      return -1;
    }

  if (!options.item.edit.gem && (position < gem_count))
    {
      error_str = "Socketed gems may not be moved";
      print_message (error_str);
      return -1;
    }

  /* Check the number of sockets */
  if (gem_count >= ModNumberOfSockets())
    {
      print_message ("There are no more available sockets (%d filled)\n",
		     gem_count);
      error_str = "There are no more available sockets";
      return -1;
    }

  /* Increase the size of the gem list */
  gems = (d2sAttachItem **)
    xrealloc (gems, (gem_count + 1) * sizeof (d2sAttachItem *));
  /* Move the existing gems down */
  for (n = gem_count; n > position; n--) {
    gems[n] = gems[n - 1];
    gems[n]->AttachTo (this, n);
  }
  /* Add the new gem */
  gems[position] = new_gem;
  new_gem->AttachTo (this, position);
  gem_count++;

  /* Find out whether we've created a Rune Word. */
  rwe = find_rune_word ();
  if (rwe != NULL)
    {
      runeworded_item = True;
      /* Figure out the Rune Word ID */
      cstr = GetEntryStringField (rwe, "Name");
      runeword_id = 0;
      sscanf (cstr, "Runeword%u", &runeword_id);
      if (runeword_id < 80)
	runeword_id += 0x501a;
      else
	/* There is a missing entry in the runes table */
	runeword_id += 0x5019;

      if (options.item.link.quality_magic)
	/* Append the Rune Word's list of magic properties to the item */
	ReapplyRuneWord();
    }

  MarkDirty ();
  return 0;
}

/* Remove a gem from the item. */
int
d2sDurableItem::RemoveGem (d2sAttachItem *old_gem)
{
  int n;

  /* This version of the function just finds the gem's index number,
     then calls the next function. */
  for (n = 0; n < gem_count; n++)
    {
      if (old_gem == gems[n])
	return RemoveGem (n);
    }
  if (debug)
    {
      fprintf (stderr, "%s: Internal error: attempt to remove a %s (%p)\n",
	       progname, old_gem->Name(), old_gem);
      if (gem_count) {
	fprintf (stderr, " which is not on the %s's list of attached gems:\n",
		 base_name);
	for (n = 0; n < gem_count; n++)
	  fprintf (stderr, "\t(%p) %s\n", gems[n], gems[n]->Name());
      } else
	fprintf (stderr, " from a %s that has no gems attached\n", base_name);
    }
  error_str = "That gem is not attached to this item";
  return -1;
}

int
d2sDurableItem::RemoveGem (int position)
{
  int i, n;

  /* Check the range */
  if ((unsigned) position >= (unsigned) gem_count)
    {
      print_message ("Error: there is no gem in socket #%d of this item;"
		     " it%s has %d gem%s\n", position + 1,
		     gem_count ? " only" : "", gem_count,
		     (gem_count != 1) ? "s" : "");
      error_str = "There is no gem there";
      return -1;
    }

  /* Check for editing options */
  if (read_only() || !options.item.edit.socketed_gems
      || !options.item.edit.gem)
    {
      error_str = "Gems may not be removed";
      if (options.item.edit.socketed_gems && options.item.edit.gem)
	print_message ("You may not remove gems from %s's %s\n",
		       character->GetCharacterName(), base_name);
      else
	print_message (error_str);
      return -1;
    }

  gems[position]->AttachTo (NULL, 0);

  /* Move all following gems up a slot */
  gem_count--;
  for (n = position; n < gem_count; n++) {
    gems[n] = gems[n + 1];
    gems[n]->AttachTo (this, n);
  }

  /* In case this item was Rune Worded, remove the rune word. */
  if (runeworded_item)
    {
      runeworded_item = False;

      if (options.item.link.quality_magic
	  && (magic_properties->NumberOfPropertyLists() > 1))
	{
	  /* Remove the Rune Word's list of magic properties from the item */
	  i = magic_properties->NumberOfPropertiesInList();
	  while (i < magic_properties->NumberOfProperties())
	    magic_properties->RemoveProperty (i);
	}
    }

  MarkDirty ();
  return 0;
}

/* After regenerating an item's magic properties, call this function
   to add back the Rune Word's properties (if one exists). */
void
d2sDurableItem::ReapplyRuneWord (void)
{
  char		rune_key[16];
  table_entry_t rwe;
  int		i;
  const char	*code;
  int		param, pmin, pmax;
  d2sMagicProperty *property;

  if (magic_properties->NumberOfPropertyLists() > 1)
    /* Properties already added? */
    return;

  /* Get the Rune Word entry in the runes table */
  i = runeword_id - 0x501a;
  if (i >= 80)
    /* There is no Runeword80 in the runes table */
    i++;
  if ((i < 1) || (i > GetTableSize ("runes")))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: bad Rune Word ID (%d) on %s\n",
		 progname, runeword_id, base_name);
      return;
    }
  sprintf (rune_key, "Runeword%d", i);
  rwe = LookupTableEntry ("runes", "Name", rune_key);
  if (rwe == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: Rune Word ID (%d) not found"
		 " in the runes table\n", progname, runeword_id);
      return;
    }

  if (!GetEntryStringField (rwe, "complete"))
    /* Incomplete entry; ignore it */
    return;

  /* Add an end-of-list marker */
  property = new d2sMagicProperty (END_OF_LIST_MARKER);
  if (magic_properties->AddProperty (property) < 0)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: unable to add Rune Word"
		 " properties to %s\n", progname, base_name);
      delete property;
      return;
    }

  /* Add each Rune Word property after the marker */
  for (i = 0; i < 10; i++)
    {
      sprintf (rune_key, "T1Code%d", i + 1);
      code = GetEntryStringField (rwe, rune_key);
      if (!code[0])
	break;
      sprintf (rune_key, "T1Param%d", i + 1);
      param = GetEntryIntegerField (rwe, rune_key);
      sprintf (rune_key, "T1Min%d", i + 1);
      pmin = GetEntryIntegerField (rwe, rune_key);
      sprintf (rune_key, "T1Max%d", i + 1);
      pmax = GetEntryIntegerField (rwe, rune_key);
      property = new d2sMagicProperty (code, param, pmin, pmax);
      if (property->GetErrorMessage() != NULL)
	{
	  delete property;
	  continue;
	}
      if (magic_properties->AddProperty (property) < 0)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to add Rune Word"
		     " properties to %s\n", progname, base_name);
	  delete property;
	  return;
	}
    }
}
