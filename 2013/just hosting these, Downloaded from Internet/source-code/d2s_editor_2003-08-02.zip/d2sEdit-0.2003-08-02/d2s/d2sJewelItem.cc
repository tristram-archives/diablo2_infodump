/* d2sJewelItem -- C++ class that holds an internal representation
 *		   of a Diablo II v1.09 jewel.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stddef.h>
#include "d2sItem.h"
#include "d2sMagic.h"
#include "tables.h"
#include "internal.h"
#include <dmalloc.h>

/* Create a new, blank jewel (to be filled in later) */
d2sJewelItem::d2sJewelItem (void)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (), d2sExtendedItem (), d2sAttachItem (), d2sCharmItem ()
{
  /* Override the default item class */
  item_class = JEWEL_ITEM;
  nvop = this;
  return;
}

/* Create a new, specific jewel as described by the item table entry
   (using default variable attributes) */
d2sJewelItem::d2sJewelItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (tent), d2sExtendedItem (tent),
    d2sAttachItem (tent), d2sCharmItem (tent)
{
  /* Change the nvop (very important) */
  nvop = this;
  /* Override the default item class */
  item_class = JEWEL_ITEM;
  return;
}

d2sJewelItem::d2sJewelItem (const d2sJewelItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (source), d2sExtendedItem (source),
    d2sAttachItem (source), d2sCharmItem (source)
{
  /* Change the nvop (very important) */
  nvop = this;
  return;
}

/* Copy a template jewel, and fill in the rest of the data
   using data from an item file or character file. */
d2sItem *
d2sJewelItem::Copy (void) const
{
  d2sJewelItem *new_item = new d2sJewelItem (*this);
  return (d2sItem *) new_item;
}
