/* d2sData-Hire -- functions in the d2sData class
 *		   that deal with aspects of the hired hand.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "functions.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include "d2sData.h"
#include "d2sItem.h"
#include <dmalloc.h>

/* Figure out the hireling's table entry, name, and level. */
void
d2sData::FindHireling (void)
{
  double d;
  int exp_lvl;
  table_entry_t alt_entry;

  /* Make an initial stab at the hireling's entry in the data table */
  hireling_entry = LookupNumericTableEntry ("hireling", "Id",
					    hireling_attribute);
  if (hireling_entry == NULL)
    {
      print_message ("Error: unable to find %s's mercenary's entry"
		     " in the hireling table.\n", name);
      error_str = "Unable to locate hireling data";
      /* Make up some default data for the purpose of doing the math */
      exp_lvl = 120;	/* This appears to be the average */
    }
  else
    {
      exp_lvl = GetEntryIntegerField (hireling_entry, "Exp/Lvl");
      if (exp_lvl < 10 /* the lowest is really 100 */)
	{
	  print_message ("Error: bad or missing Exp/Lvl entry on line %d"
			 " of the hireling table.\n",
			 GetEntryIntegerField (hireling_entry, NULL)
			 /* We add 2 to count for a 1-base + header line */
			 + 2);
	  error_str = "Invalid hireling table";
	  exp_lvl = 120;
	}
    }

  /* This requires a little math.  Mathematica provided the solution
     to the general equation: Lvl^3 + Lvl^2 = Exp/K,
     where K is the hireling's "Exp/Lvl" entry in the hireling table.
     (For the inverse equation, Lvl is rounded down after solving.)

     Lvl = floor ( -1/3 + cbrt(2) / (3*cbrt(-2 + 27*Exp/K + 3*sqrt(3*Exp/K
           - 4 + 27*Exp/K))) + cbrt(-2 + 27*Exp/K + 3*sqrt(3*Exp/K - 4
	   + 27*Exp/K)) / (3*cbrt(2)))
  */
  d = hireling_experience / exp_lvl;
  d = 27*d - 2 + 3*sqrt(81*d*d - 12*d);
  d = cbrt (d / 2);
  d = (d + 1/d - 1) / 3;
  hireling_level = (unsigned char) floor (d);
  /* Slight tweak in case of rounding error */
  if ((unsigned long) (hireling_level * hireling_level
		       * (hireling_level + 1) * exp_lvl)
      > hireling_experience)
    hireling_level--;
  else if (hireling_experience
	   >= (unsigned long) ((hireling_level + 1) * (hireling_level + 1)
			       * (hireling_level + 2) * exp_lvl))
    hireling_level++;

  /* There's another little catch here.  The hireling table has
     multiple entries for most hireling types, each one with a different
     base level and statistics ramp grades.  We need to find the largest
     one which is at or below the hireling's current level. */
  while (hireling_level < GetEntryIntegerField (hireling_entry, "Level"))
    {
      alt_entry = LookupNthEntryAfter (hireling_entry, -1);
      if ((alt_entry == NULL)
	  || (GetEntryIntegerField (alt_entry, "Id") != hireling_attribute))
	{
	  print_message ("Error: mercenary's computed level (%d) is below"
			 " the minimum level for the mercenary type (%d)\n",
			 hireling_level,
			 GetEntryIntegerField (hireling_entry, "Level"));
	  error_str = "Invalid hireling experience";
	  break;
	}
      hireling_entry = alt_entry;
    }
  while (True)
    {
      alt_entry = LookupNextEntryAfter (hireling_entry);
      if ((alt_entry == NULL)
	  || (GetEntryIntegerField (alt_entry, "Id") != hireling_attribute))
	break;
      if (hireling_level < GetEntryIntegerField (alt_entry, "Level"))
	break;
      hireling_entry = alt_entry;
    }
}

/* Return a list of hireling names for the current hireling class */
StringList
d2sData::GetAllHirelingNames (void) const
{
  char		merc_name_key[32];
  int		keylen, name_index, num_names;
  StringList	name_list;

  if (!hireling_id)
    return NULL;

  /* Get the key for the first mercenary name */
  strcpy (merc_name_key, GetEntryStringField (hireling_entry, "NameFirst"));
  /* The last two characters in the key are the name index. */
  keylen = strlen (merc_name_key);
  name_index = atoi (&merc_name_key[keylen - 2]);

  /* Get the name index for the last mercenary name */
  num_names = atoi (&(GetEntryStringField (hireling_entry, "NameLast")
		      [keylen - 2]));
  /* The number of names is the difference between the two indices + 1 */
  num_names = num_names + 1 - name_index;

  /* Allocate the string list */
  name_list = (StringList) xmalloc
    (sizeof (_StringList) + num_names * sizeof (_StringListEntry));
  /* Fill it in */
  for (name_list->count = 0; num_names; num_names--)
    {
      sprintf (&merc_name_key[keylen - 2], "%02d", name_index);
      name_list->string[name_list->count].value = name_list->count;
      name_list->string[name_list->count].label
	= LookupStringByKey (merc_name_key);
      name_list->count++;
      name_index++;
    }
  return name_list;
}

const char *
d2sData::GetHirelingName (void) const
{
  const char	*first_name_key;
  char		merc_name_key[32];
  int		keylen, name_index;

  /* Do we actually have a mercenary? */
  if (!hireling_id)
    return "";

  /* Get the key for the first mercenary name */
  first_name_key = GetEntryStringField (hireling_entry, "NameFirst");
  /* The last two characters in the key are the name index. */
  keylen = strlen (first_name_key);
  name_index = atoi (&first_name_key[keylen - 2]) + hireling_name;
  /* Generate the new key */
  sprintf (merc_name_key, "%.*s%02d",
	   keylen - 2, first_name_key, name_index);

  return LookupStringByKey (merc_name_key);
}

const char *
d2sData::GetHirelingClass (void) const
{
  return GetEntryStringField (hireling_entry, "Hireling");
}

int
d2sData::GetHirelingAct (void) const
{
  return (GetEntryIntegerField (hireling_entry, "Act") - 1);
}

const char *
d2sData::GetHirelingAttribute (void) const
{
  return GetEntryStringField
    (LookupTableEntry ("hiredesc", "Code",
		       GetEntryStringField (hireling_entry, "HireDesc")),
     "Hireling Description");
}

unsigned long
d2sData::GetHirelingExperienceMin (void) const
{
  int exp_lvl;

  /* This requires a cubic polynomial, and the hireling's
     "Exp/Lvl" entry in the hireling table. */
  exp_lvl = GetEntryIntegerField (hireling_entry, "Exp/Lvl");
  return (hireling_level * hireling_level * (hireling_level + 1)
	  * exp_lvl);
}

unsigned long
d2sData::GetHirelingExperienceMax (void) const
{
  int exp_lvl;

  /* This requires a cubic polynomial, and the hireling's
     "Exp/Lvl" entry in the hireling table. */
  exp_lvl = GetEntryIntegerField (hireling_entry, "Exp/Lvl");
  return ((hireling_level + 1) * (hireling_level + 1)
	  * (hireling_level + 2) * exp_lvl - 1);
}

/* Compute and return various hireling statistics */
unsigned long
d2sData::GetHirelingStrength (void) const
{
  return (GetEntryIntegerField (hireling_entry, "Str")
	  + (GetEntryIntegerField (hireling_entry, "Str/Lvl")
	     * (hireling_level
		- GetEntryIntegerField (hireling_entry, "Level"))
	     / 8));
}

unsigned long
d2sData::GetHirelingDexterity (void) const
{
  return (GetEntryIntegerField (hireling_entry, "Dex")
	  + (GetEntryIntegerField (hireling_entry, "Dex/Lvl")
	     * (hireling_level
		- GetEntryIntegerField (hireling_entry, "Level"))
	     / 8));
}

unsigned long
d2sData::GetHirelingLife (void) const
{
  return (GetEntryIntegerField (hireling_entry, "HP")
	  + (GetEntryIntegerField (hireling_entry, "HP/Lvl")
	     * (hireling_level
		- GetEntryIntegerField (hireling_entry, "Level"))));
}

unsigned long
d2sData::GetHirelingDefense (void) const
{
  unsigned long defense;
  int where;

  /* Start with the hireling's bare defense rating */
  defense = (GetEntryIntegerField (hireling_entry, "Defense")
	     + (GetEntryIntegerField (hireling_entry, "Def/Lvl")
		* (hireling_level
		   - GetEntryIntegerField (hireling_entry, "Level"))));
  /* Add the defense rating of any armor he has equipped */
  for (where = EQUIPPED_ON_HEAD; where <= EQUIPPED_ON_HANDS; where++)
    {
      if ((hireling_equipment[where] != NULL)
	  && (hireling_equipment[where]->is_of_type ("armo")))
	defense += ((d2sArmorItem *) (d2sDurableItem *)
		    *hireling_equipment[where])->Defense();
    }
  return defense;
}

unsigned long
d2sData::GetHirelingResist (void) const
{
  return (GetEntryIntegerField (hireling_entry, "Resist")
	  + (GetEntryIntegerField (hireling_entry, "Resist/Lvl")
	     * (hireling_level
		- GetEntryIntegerField (hireling_entry, "Level"))
	     / 4));
}

/* Toggle whether a hireling is dead or alive */
int
d2sData::SetHirelingDead (int new_state)
{
  if (!hireling_id)
    {
      error_str = "You do not have a mercenary";
      print_message (error_str);
      return -1;
    }

  if ((new_state != 0) == (hireling_status != 0))
    /* Nothing needs to be done */
    return 0;

  /* Is resurrecting the hireling allowed? */
  if (read_only || !options.character.edit.died)
    {
      error_str = "You do not have power over life and death";
      print_message (error_str);
      return -1;
    }

  /* In a standard game, the hireling must match the current act. */
  /* TO-DO */

  /* Resurrect (or kill) the hireling */
  hireling_status = (new_state ? 1 : 0);
  MarkDirty ();
  return 0;
}

/* Change a hireling's name */
int
d2sData::SetHirelingName (int index)
{
  char		merc_name_key[32];
  int		keylen, keynum;

  /* Do we actually have a mercenary? */
  if (!hireling_id)
    {
      error_str = "You do not have a mercenary";
      print_message (error_str);
      return -1;
    }

  if (index == hireling_name)
    /* Nothing needs to be done */
    return 0;

  /* Is changing the mercenary's name allowed? */
  if (read_only || !options.character.edit.hireling_name)
    {
      error_str = "You may not change your mercenary's name";
      print_message (error_str);
      return -1;
    }

  /* Get the key for the first mercenary name */
  strcpy (merc_name_key, GetEntryStringField (hireling_entry, "NameFirst"));
  /* The last two characters in the key are the name index. */
  keylen = strlen (merc_name_key);
  keynum = atoi (&merc_name_key[keylen - 2]);

  /* Have we exceeded the last mercenary name? */
  sprintf (&merc_name_key[keylen - 2], "%02d", index + keynum);
  if (strcmp (merc_name_key, GetEntryStringField
	      (hireling_entry, "NameLast")) > 0)
    {
      error_str = "Invalid mercenary name index";
      print_message (error_str);
      return -1;
    }

  /* Make the change */
  hireling_name = index;
  MarkDirty ();
  return 0;
}

/* Change a hireling's level */
int
d2sData::SetHirelingLevel (int new_level)
{
  double	percent;
  unsigned long exp_min, exp_max;
  int		exp_lvl;

  /* Do we actually have a mercenary? */
  if (!hireling_id)
    {
      error_str = "You do not have a mercenary";
      print_message (error_str);
      return -1;
    }

  if (new_level == hireling_level)
    /* Nothing needs to be done */
    return 0;

  /* Is changing the level allowed? */
  if (read_only || !options.character.edit.hireling_experience
      || !options.character.edit.hireling_level)
    {
      error_str = "You may not change your mercenary's level";
      print_message (error_str);
      return -1;
    }
  if ((new_level < hireling_level) && !options.character.edit.up_and_down)
    {
      error_str = "You may not decrease your mercenary's level";
      print_message (error_str);
      return -1;
    }

  /* Find the relative amount of experience required for the mercenary to
     be at the desired level, then let SetHirelingExperience do the work. */
  exp_min = GetHirelingExperienceMin();
  exp_max = GetHirelingExperienceMax();
  percent = (double) (hireling_experience - exp_min) / (exp_max - exp_min);
  exp_lvl = GetEntryIntegerField (hireling_entry, "Exp/Lvl");
  exp_min = new_level * new_level * (new_level + 1) * exp_lvl;
  exp_max = (new_level + 1) * (new_level + 1) * (new_level + 2) * exp_lvl - 1;
  return SetHirelingExperience ((unsigned long)
				(percent * (exp_max - exp_min)) + exp_min);
}

/* Change a hireling's experience points */
int
d2sData::SetHirelingExperience (unsigned long new_experience)
{
  int exp_lvl;
  table_entry_t first_entry, alt_entry;
  int base_level;

  /* Do we actually have a mercenary? */
  if (!hireling_id)
    {
      error_str = "You do not have a mercenary";
      print_message (error_str);
      return -1;
    }

  if (new_experience == hireling_experience)
    /* Nothing needs to be done */
    return 0;

  /* Is changing the experience allowed? */
  if (read_only || !options.character.edit.hireling_experience)
    {
      error_str = "You may not change your mercenary's experience";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.up_and_down
      && (new_experience
	  < ((struct d2s_header *) &raw_header[0])->hireling_experience))
    {
      error_str = "You may not decrease your mercenary's experience";
      print_message (error_str);
      return -1;
    }
  if (!options.character.edit.hireling_level
      && ((new_experience > GetHirelingExperienceMax())
	  || (new_experience < GetHirelingExperienceMin())))
    {
      error_str = ("You may not increase your mercenary's experience"
		   " beyond his current level");
      print_message ("You may not increase your mercenary's experience"
		     " beyond %s current level",
		     GetHirelingAct() ? "his" : "her");
      return -1;
    }

  /* Find the first entry in the hireling table for this hireling's ID */
  first_entry = hireling_entry;
  while ((alt_entry = LookupNthEntryAfter (first_entry, -1)) != NULL)
    {
      if (GetEntryIntegerField (alt_entry, "Id") != hireling_attribute)
	break;
      first_entry = alt_entry;
    }
  /* Get the base level for this hireling */
  alt_entry = first_entry;
  base_level = GetEntryIntegerField (first_entry, "Level");
  exp_lvl = GetEntryIntegerField (hireling_entry, "Exp/Lvl");

  /* Are we below the minimum experience? */
  if (!options.character.link.freeform
      && (new_experience < (unsigned long)
	  (base_level * base_level * (base_level + 1) * exp_lvl)))
    {
      error_str = "Experience level is too low for this mercenary";
      print_message ("A %s %s may not have %s experience set below %lu.\n",
		     GetDifficultyName (GetEntryIntegerField
					(first_entry, "Difficulty") - 1),
		     TranslateString (GetEntryStringField
				      (first_entry, "Hireling")),
		     GetHirelingAct() ? "his" : "her",
		     (unsigned long) (base_level * base_level
				      * (base_level + 1) * exp_lvl));
      return -1;
    }

  /* At this point it looks like the change is okay. */
  hireling_experience = new_experience;
  FindHireling ();
  MarkDirty ();
  return 0;
}

/* Change a hireling's attribute */
int
d2sData::SetHirelingAttribute (const char *new_attribute)
{
  table_entry_t new_entry;
  int		c_act, c_diff, c_lvl;
  const char	*cstr;

  /* Do we actually have a mercenary? */
  if (!hireling_id)
    {
      error_str = "You do not have a mercenary";
      print_message (error_str);
      return -1;
    }

  /* Is changing the attribute allowed? */
  if (read_only || !options.character.edit.hireling_attribute)
    {
      error_str = "You may not change your mercenary's attribute";
      print_message (error_str);
      return -1;
    }

  /* Find another entry in the hireling table with a matching
     class (act), difficulty, and base level, and whose description
     matches the requested attribute. */
  c_act = GetEntryIntegerField (hireling_entry, "Act");
  c_diff = GetEntryIntegerField (hireling_entry, "Difficulty");
  c_lvl = GetEntryIntegerField (hireling_entry, "Level");
  for (new_entry = LookupIndexedTableEntry ("hireling", 0);
       new_entry != NULL; new_entry = LookupNextEntryAfter (new_entry))
    {
      if (GetEntryIntegerField (new_entry, "Act") != c_act)
	continue;
      if (GetEntryIntegerField (new_entry, "Difficulty") != c_diff)
	continue;
      if (GetEntryIntegerField (new_entry, "Level") != c_lvl)
	continue;

      /* Compare the description */
      cstr = GetEntryStringField (new_entry, "HireDesc");
      if (strcmp (cstr, new_attribute) == 0)
	break;
      if (strcmp (GetEntryStringField (LookupTableEntry ("hiredesc", "Code", cstr), "Hireling Description"), new_attribute) == 0)
	break;
    }
  if (new_entry == NULL)
    {
      /* No match found */
      print_message ("Cannot find a %s with attribute %s\n",
		     GetEntryStringField (hireling_entry, "Hireling"),
		     new_attribute);
      error_str = "Invalid parameter";
      return -1;
    }

  /* Set the new table entry and attribute */
  hireling_entry = new_entry;
  hireling_attribute = GetEntryIntegerField (hireling_entry, "Id");
  /* Recompute the hireling's level.  Hirelings with different attributes,
     even in the same class, may have different Exp/Lvl values. */
  FindHireling();
  MarkDirty ();
  return 0;
}
