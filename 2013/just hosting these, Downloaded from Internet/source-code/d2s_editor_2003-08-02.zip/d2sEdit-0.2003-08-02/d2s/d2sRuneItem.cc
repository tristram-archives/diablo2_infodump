/* d2sRuneItem -- C++ class that holds an internal representation
 *		  of a Diablo II v1.09 rune.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/***************************** DATA *****************************/

static int number_of_rune_entries = -1;


/************************** FUNCTIONS ***************************/

/* Return the number of runes defined. */
int
GetNumberOfRunes (void)
{
  if (number_of_rune_entries < 0)
    {
      int i, min = 0, max = 99;
      char rune_id[4];

      /* We need to figure out how many runes there are.
	 Do this by using a binary search for the largest numbered rune. */
      rune_id[0] = 'r';
      rune_id[3] = '\0';
      while (min + 1 < max)
	{
	  i = (min + max) / 2;
	  rune_id[1] = (char) ('0' + i / 10);
	  rune_id[2] = (char) ('0' + i % 10);
	  if (LookupTableEntry ("misc", "code", rune_id) == NULL)
	    /* Rune not found; move the upper limit down to i */
	    max = i;
	  else
	    /* Rune found; move the lower limit up to i */
	    min = i;
	}

      /* When min (the largest rune found) is just 1 less than max
	 (the smallest rune not found), min is equal to the number
	 of runes (Going by a one-base). */
      number_of_rune_entries = min;
    }
  return number_of_rune_entries;
}

/* Return the name of the Nth rune */
const char *
GetRuneName (int n)
{
  char rune_id[4];
  table_entry_t rune_entry;
  const char *name;

  snprintf (rune_id, sizeof (rune_id), "r%02d", n);
  rune_entry = LookupTableEntry ("misc", "code", rune_id);
  name = GetEntryStringField (rune_entry, "name");
  if (name[0] == 0)
    return NULL;
  return TranslateString (name);
}


/**************** RUNE CLASS ****************
 *
 * A simple class that can be attached to a socketed item
 * and can change form from one rune to another
 *******************************************/

/* Create a new, 'blank' rune (to be filled in later) */
d2sRuneItem::d2sRuneItem (void)
  /* Construct the base class part first.  Remember that since d2sInit
     is a virtual base class, it is our responsibility to initialize it. */
  : d2sItem (), d2sGemOrRuneItem ()
{
  /* Override the default item class */
  item_class = RUNE_ITEM;
  nvop = this;
  rune_num = 0;
}

/* Create a new, specific rune as described by the item table entry */
d2sRuneItem::d2sRuneItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     is a virtual base class, it is our responsibility to initialize it. */
  : d2sItem (tent), d2sGemOrRuneItem (tent)
{
  /* Override the default item class */
  item_class = RUNE_ITEM;
  nvop = this;
  /* Extract the rune number from the item ID */
  rune_num = (item_ID.ch[1] - '0') * 10 + (item_ID.ch[2] - '0');
}

/* Copy an existing rune */
d2sRuneItem::d2sRuneItem (const d2sRuneItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     is a virtual base class, it is our responsibility to initialize it. */
  : d2sItem (source), d2sGemOrRuneItem (source)
{
  nvop = this;
  /* Note that d2sGemOrRuneItem::d2sGemOrRuneItem(source) will have
     already copied the rune item fields.  Our only additional field
     is the rune number. */
  this->rune_num = source.rune_num;
}

/* Copy a rune. */
d2sItem *
d2sRuneItem::Copy (void) const
{
  d2sRuneItem *new_item = new d2sRuneItem (*this);
  return (d2sItem *) new_item;
}

/* Create a rune by filling in data from a file.
   (This simply calls d2sGemOrRuneItem::Read,
   then sets our own data fields) */
int
d2sRuneItem::Read (struct data_stream *dstream)
{
  int status;

  /* The parent class does the actual reading */
  status = this->d2sGemOrRuneItem::Read (dstream);

  /* All we need to do is set the rune's number. */
  rune_num = (item_ID.ch[1] - '0') * 10 + (item_ID.ch[2] - '0');
  return status;
}

/* If the rune type was changed, change it back. */
void
d2sRuneItem::DiscardChanges (void)
{
  if (!dirty)
    /* No changes; nothing to do */
    return;

  /* Discard changes to the base class first. */
  this->d2sGemOrRuneItem::DiscardChanges ();

  /* Reset the rune's number. */
  rune_num = (item_ID.ch[1] - '0') * 10 + (item_ID.ch[2] - '0');
}

/* Transform a rune into another kind of rune. */
int
d2sRuneItem::TransformInto (int new_num)
{
  table_entry_t new_entry;
  char		new_code[4];
  d2sDurableItem *ditem;

  if (rune_num == new_num)
    /* Nothing is actually being changed. */
    return 0;

  /* Are we allowed to transform items? */
  if (read_only() || !options.item.edit.gem)
    {
      error_str = "Rune transformation not permitted";
      print_message (error_str);
      return -1;
    }
  if ((attachment != NULL) && !options.item.edit.socketed_gems)
    {
      error_str = ("You may not change runes which have been"
		   " placed in a socket");
      print_message (error_str);
      return -1;
    }

  /* Look up the desired rune */
  if ((new_num < 1) || (new_num > 99))
    new_entry = NULL;
  else {
    snprintf (new_code, sizeof (new_code), "r%02d", new_num);
    new_entry = LookupTableEntry ("misc", "code", new_code);
  }
  if (new_entry == NULL)
    {
      print_message ("Invalid rune number\n");
      error_str = "Invalid rune number";
      return -1;
    }

  /* In order for Rune Words to be processed properly,
     we must detach the rune before changing it. */
  ditem = attachment;
  if (ditem != NULL)
    ditem->RemoveGem (this);

  /* Change the rune. */
  ChangeItemType (new_entry);
  rune_num = new_num;

  /* Replace it in the item */
  if (ditem != NULL)
    ditem->AddGem (this, socket_number);

  /* Mark the rune dirty */
  MarkDirty ();
  return 0;
}
