/* Functions used in reading data tables and string lists.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include "paths.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Global variable */
const char *path_to_tables = PATH_TO_TABLES;


/* These tables are preloaded by the game.  If these tables are
   not found, it is considered a fatal error, and the editor
   won't start.  Any tables requested after this function
   are considered optional, and will simply return NULL if not found. */
static const struct {
  const char *name;
  const char *key_field;
} required_tables[] = {
  { "acts", NULL },
  { "waypoints", "code" },
  { "quests", "code" },
  { "queststates", "code" },
  { "misc" /* items */, "code" },
  { "armor", "code" },
  { "weapons", "code" },
  /* Hmmm... I'm not sure if this is available in the Standard version,
     but the item tables appear to require it */
  { "itemtypes", "code" },
  { "belts", NULL },
  { "setitems", NULL },
  { "uniqueitems", NULL },
  { "magicprefix", NULL },
  { "magicsuffix", NULL },
  { "rareprefix", NULL },
  { "raresuffix", NULL },
  { "bodylocs", NULL },
  { "playerclass", "Code" },
  { "experience", "Level" },
  { "skills", "Id" },
};

/* These are the string tables to load.
   The first one is required; the next two are optional. */
static const char * const required_strings[] = {
  "string", "expansionstring", "patchstring"
};

/* These structures are used to read compiled string tables */
struct string_tbl_header {
  uint16_t	CRC;		/* Unused here */
  uint16_t	num_strings;	/* Number of strings in the .tbl file */
  uint32_t	num_hashes;	/* Number of hash entries */
  uint8_t	version;	/* 1 */
  char *	beginning_of_strings;
  uint32_t	longest_hash_entry;	/* Unused here */
  char *	end_of_strings;
  uint16_t	index_to_hash[0];	/* NUM_STRINGS Indices into an array
					   of the following structures */
} __attribute__ ((packed));

struct string_hash_entry {
  uint8_t	used;		/* Whether the entry is in use */
  uint16_t	string_index;	/* Index into INDEX_TO_HASH above;
				   string ordinal in this table */
  uint32_t	hash;		/* Hash number; unused here */
  const char *	key_ptr;	/* Pointer to the key */
  const char *	string_ptr;	/* Pointer to the value */
  uint16_t	string_length;	/* Length of the string */
} __attribute__ ((packed));

/* After reading the string tables, we generate an array of pointers
   to string_hash_entry's, sorted by key. */
static struct string_hash_entry **sorted_string_keys = NULL;
static int sorted_string_count = 0;
/* Also keep track of the original string tables */
struct string_table_desc {
  const char *	name;
  struct string_tbl_header *header;
  struct string_hash_entry *hash_array;
};
static struct string_table_desc *string_table_list = NULL;
static int string_table_count = 0;


/* This structure holds information that describes each table */
struct table_desc {
  const char *	name;		/* Name of the table */
  int		num_entries;	/* Number of rows in the table
				   (not counting the header) */
  int		num_fields;	/* Number of columns in the table */
  int		key;		/* The column of the key field
				   used to sort the entry list */
  const char **	field_list;	/* Array of column names */
  struct _TableEntry *entry_list; /* Array of table entries */
};

/* Define the opaque data structure used as a handle to a table entry */
struct _TableEntry {
  struct table_desc *table;	/* The table in which the entry is located */
  int		key;		/* The column of the key field
				   used to find this entry */
  int		index;		/* The (unsorted) index number of this entry */
  const char **	value_list;	/* Array of values */
};

/* List of table descriptors.  The list is sorted
   by name and key for searching. */
static struct table_desc **table_list = NULL;
static int table_count = 0;


/* Forward declarations: */
static int snarf_file (const char *filename, const char *mode,
		       void **ret_buffer);
static int sort_string_hashes (const void *p1, const void *p2);
static int search_string_hash (const void *key, const void *phash);
static int search_string_hash_case_sensitive (const void *vkey,
					      const void *phash);
static struct string_table_desc *read_string_tbl (const char *filename);
static int read_entry_from_table_file (char **linep,
				       const char ***ret_value_list);
static int read_string_txt (const char *filename);
static int load_string_tables (void);
static struct table_desc *read_data_table (const char *filename);
static void sort_data_table (struct table_desc *);
static int sort_table_descs (const void *p1, const void *p2);
static int search_table_descs (const void *key, const void *ptdesc);
static int sort_data_entries (const void *p1, const void *p2);
static int search_data_entries (const void *key, const void *pentry);
static int find_key_field (const struct table_desc *table,
			   const char *key_name);
static struct table_desc *find_data_table (const char *name,
					   const char *key_field);


/****************************************************************
 *			Internal Functions			*
 ****************************************************************/

/* Read a whole file at once.  Eliminate duplicate code. */
static int
snarf_file (const char *filename, const char *mode, void **ret_buffer)
{
  FILE *file;
  int status;
  struct stat stat_buf;
  char *buffer;

  /* Get the file size */
  status = stat (filename, &stat_buf);
  if (status < 0)
    return -1;

  /* Check for a bad file */
  if (!S_ISREG (stat_buf.st_mode))
    {
      if (S_ISDIR (stat_buf.st_mode))
	errno = EISDIR;
      else
	errno = ESPIPE;
      return -1;
    }
  /* Arbitrary limit (the largest table I've seen is < 400K) */
  if (stat_buf.st_size > 16 * 1024 * 1024)
    {
      errno = EFBIG;	/* File too large */
      return -1;
    }

  /* Open the file */
  file = fopen (filename, mode);
  if (file == NULL)
    return -1;

  /* Allocate a buffer for the table. *** This storage
     becomes permanent; never freed.  All data are
     referenced directly from the buffer. */
  buffer = (char *) xmalloc (stat_buf.st_size + 1);
  /* Read the entire file at once */
  status = fread (buffer, 1, stat_buf.st_size, file);
  if ((status <= 0) || ferror (file))
    {
      fclose (file);
      free (buffer);
      return -1;
    }
  fclose (file);
  /* For text files (the usual case),
     make sure the buffer is null-terminated */
  buffer[status] = '\0';
  *ret_buffer = buffer;
  return status;
}

/* Sort two string hash entries.
   We compare the key strings, and if the keys are the same,
   compare the string index.  That way, multiple entries for
   a key will be sorted in the order that the tables were
   loaded (making it easier to identify string overrides). */
static int
sort_string_hashes (const void *p1, const void *p2)
{
  const struct string_hash_entry *hash1
    = *((const struct string_hash_entry **) p1);
  const struct string_hash_entry *hash2
    = *((const struct string_hash_entry **) p2);
  int diff;

  diff = strcasecmp (hash1->key_ptr, hash2->key_ptr);
  if (diff)
    return diff;
  /* In some cases, keys may be spelled the same
     but have different case characters.  Try a case-sensitive sort. */
  diff = strcmp (hash1->key_ptr, hash2->key_ptr);
  if (diff)
    return diff;
  /* Exact match.  Sort by index number. */
  return (hash1->string_index - hash2->string_index);
}

/* Compare a string to an entry in the string table.
   Remember that more than one entry may match the string;
   the caller should take the last entry that matches. */
static int
search_string_hash (const void *vkey, const void *phash)
{
  const char *key = (const char *) vkey;
  struct string_hash_entry *hash
    = *((struct string_hash_entry **) phash);

  return strcasecmp (key, hash->key_ptr);
}

/* Compare a case-sensitive string to an entry in the string table.
   This should be tried first when searching; use the case-insensitive
   search if an exact match cannot be found. */
static int
search_string_hash_case_sensitive (const void *vkey, const void *phash)
{
  const char *key = (const char *) vkey;
  struct string_hash_entry *hash
    = *((struct string_hash_entry **) phash);
  int diff;

  if (strcmp (key, hash->key_ptr) == 0)
    return 0;
  /* If it isn't an exact match, remember that the difference
     has to go in case-insensitive order. */
  diff = strcasecmp (key, hash->key_ptr);
  return (diff ? diff : strcmp (key, hash->key_ptr));
}

/* Read in a string .tbl file.
   After reading it, add its hash entries to the key list and sort.
   On error, sets errno and returns -1.  Otherwise returns 0. */
static struct string_table_desc *
read_string_tbl (const char *filename)
{
  int i, file_size;
  struct string_tbl_header *header;
  struct string_hash_entry *hash, *hash_array;

  /* Read the raw string table */
  file_size = snarf_file (filename, "rb", (void **) &header);
  if (file_size < 0)
    return NULL;

  /* Initial consistency check */
  if ((header->version != 1)
      || (header->beginning_of_strings >= header->end_of_strings)
      || ((int) header->end_of_strings <= sizeof (struct string_tbl_header))
      || ((int) header->end_of_strings > file_size))
    {
      errno = EBADF;
      return NULL;
    }
  hash_array = (struct string_hash_entry *)
    &header->index_to_hash[header->num_strings];
  if ((char *) &hash_array[header->num_hashes]
      > &header->beginning_of_strings[(ptrdiff_t) header])
    {
      errno = EBADF;
      return NULL;
    }

  /* Allocate more space for the sorted hash pointers */
  sorted_string_keys = (struct string_hash_entry **)
    xrealloc (sorted_string_keys, ((sorted_string_count + header->num_strings)
				   * sizeof (struct string_hash_entry *)));
  memset (&sorted_string_keys[sorted_string_count], 0,
	  header->num_strings * sizeof (struct string_hash_entry *));

  /* Run through the list of strings, adding their entries
     to the end of the sorted key list. */
  for (i = 0; i < header->num_strings; i++)
    {
      /* More consistency checking */
      if (header->index_to_hash[i] >= header->num_hashes)
	{
	  errno = EBADF;
	  free (header);
	  return NULL;
	}
      hash = &hash_array[header->index_to_hash[i]];
      if (!hash->used || (hash->string_index != i)
	  || (hash->key_ptr < header->beginning_of_strings)
	  || (hash->key_ptr >= header->end_of_strings)
	  || (hash->string_ptr < header->beginning_of_strings)
	  || (&hash->string_ptr[hash->string_length]
	      > header->end_of_strings))
	{
	  errno = EBADF;
	  free (header);
	  return NULL;
	}

      sorted_string_keys[sorted_string_count + i] = hash;
      /* Along the way, adjust the hash's string index
	 to reflect the string's overall index among all
	 tables (must be done before sorting); and change
	 the file offsets to pointers in memory. */
      hash->string_index += sorted_string_count;
      hash->key_ptr += (ptrdiff_t) header;
      hash->string_ptr += (ptrdiff_t) header;
    }

  /* All strings read!  Sort them. */
  sorted_string_count += i;
  qsort (sorted_string_keys, sorted_string_count,
	 sizeof (struct string_hash_entry *), sort_string_hashes);

  /* Add the string table to our list */
  string_table_list = (struct string_table_desc *)
    xrealloc (string_table_list,
	      (string_table_count + 1) * sizeof (struct string_table_desc));
  string_table_list[string_table_count].name = filename;
  string_table_list[string_table_count].header = header;
  string_table_list[string_table_count].hash_array = hash_array;
  string_table_count++;
  return &string_table_list[string_table_count - 1];
}

/* Scan fields from a row in a tab-delimited .txt file.
   This function is shared by both the string table function
   and excel table function.  Fields are separated by tabs,
   but anything within a pair of double quotes is passed as
   a single field.  Consecutive pairs of double quotes are
   converted to a single pair.  Leading and trailing whitespace
   is removed (except where it occurs within double quotes).
   The entry is terminated by a newline.  This fuction will
   replace the end of each field with a null terminator,
   allocate an array of string pointers, and return the number
   of fields read in this line. */
static int
read_entry_from_table_file (char **linep, const char ***ret_value_list)
{
  int quoting = 0;
  int num_fields;
  const char **value_list = NULL;
  char save_ch;
  char *strp, *line = *linep;

  for (num_fields = 0; ; num_fields++)
    {
      /* Skip any leading spaces (not tabs or newlines) */
      while ((*line == ' ') || (*line == '\r'))
	line++;

      /* Check for early termination */
      if (*line == '\0')
	break;
      if (*line == '\n')
	{
	  line++;
	  break;
	}

      /* Allocate another string pointer */
      value_list = (const char **)
	xrealloc (value_list, (num_fields + 1) * sizeof (char *));
      strp = line;
      value_list[num_fields] = strp;

      /* Scan in the string */
      while (*line)
	{
	  if (!quoting && ((*line == '\t') || (*line == '\n')))
	    /* End of this field. */
	    break;

	  if (*line == '\r')
	    {
	      /* Discard CR's */
	      line++;
	      continue;
	    }

	  if (*line == '\"')
	    {
	      /* Quoted string.  Convert any consecutive pair of
                 double quotes to one.  Otherwise, switch from
                 normal to quoted mode or vice-versa. */
	      line++;
	      quoting = !quoting;
	      if (*line == '\"')
		quoting = !quoting;
	      else
		continue;
	    }

	  /* Regular character.  Copy to *str (in case of skew) */
	  *strp = *line;
	  strp++;
	  line++;
	}

      /* Terminate the field */
      save_ch = *line;
      *strp = '\0';

      if (!save_ch)
	/* End of file */
	break;
      line++;
      if (save_ch == '\n')
	{
	  /* End of entry; be sure to count it if it's not empty */
	  if (strp[-1])
	    num_fields++;
	  break;
	}
      if (save_ch == '\t')
	/* End of field; go on to the next */
	continue;

      fprintf (stderr, "%s: Internal error in read_entry_from_table_file\n"
	       " (%s:%d): field unexpectedly ended at character '%c'\n",
	       progname, __FILE__, __LINE__, save_ch);
      exit (1);
    }

  *linep = line;
  *ret_value_list = value_list;
  return num_fields;
}

/* Read in a tab-delimited string .txt file.
   Each entry must consist of a key string (with no special characters),
   followed by a tab, then a double-quoted value string (may contain
   any special characters except another double quote), followed by
   a closing double quote, an optional tab, and a newline.
   After reading the strings and creating hash entries to reference them,
   this function adds the generated hash entries to the key list and sorts.
   On error, sets errno and returns -1.  Otherwise returns 0. */
static int
read_string_txt (const char *filename)
{
  int i, file_size, hash_array_size = 0;
  struct string_hash_entry *hash, *hash_array = NULL;
  char *buffer, *line;
  const char **field_list;
  int num_fields;

  /* Read the entire file at once */
  file_size = snarf_file (filename, "r", (void **) &buffer);
  if (file_size < 0)
    return -1;

  line = buffer;
  for (i = 0; *line && (line < &buffer[file_size]); i++)
    {
      /* Allocate more hash entries if we need them */
      if (i >= hash_array_size)
	{
	  /* Is this a good estimate? */
	  hash_array_size += (int) (&buffer[file_size] - line) / 256 + 4;
	  hash_array = (struct string_hash_entry *)
	    xrealloc (hash_array, (hash_array_size
				   * sizeof (struct string_hash_entry)));
	}
      hash = &hash_array[i];
      hash->used = 1;
      hash->string_index = sorted_string_count + i;
      hash->hash = 0;

      /* Read the string on this line */
      num_fields = read_entry_from_table_file (&line, &field_list);
      if (!num_fields)
	{
	  /* Empty line?  I'm not sure whether to skip it
	     or count is as empty strings.  For string tables,
	     it's probably safe to skip it. */
	  --i;
	  continue;
	}
      if ((num_fields < 2) || !field_list[1][strspn (field_list[1], " ")])
	{
	  /* No value (or empty value).  If we actually used it, it
	     could end up effectively deteling an earlier association
	     for this key.  So we'll skip it too. */
	  free (field_list);
	  --i;
	  continue;
	}

      hash->key_ptr = field_list[0];
      hash->string_ptr = field_list[1];
      hash->string_length = strlen (hash->string_ptr);
      /* Remember to free the array of string pointers when we're done */
      free (field_list);
    }

  /* Okay!  Now that we have a new array of hash entries,
     trim them and sort them into the index. */
  hash_array_size = i;
  hash_array = (struct string_hash_entry *)
    xrealloc (hash_array, i * sizeof (struct string_hash_entry));
  if (hash_array_size == 0)
    {
      /* Oops!  No entries in this table. */
      free (buffer);
      errno = EPIPE;
      return -1;
    }

  /* Allocate more space for the sorted hash pointers */
  sorted_string_keys = (struct string_hash_entry **)
    xrealloc (sorted_string_keys, ((sorted_string_count + hash_array_size)
				   * sizeof (struct string_hash_entry *)));
  for (i = 0; i < hash_array_size; i++)
    sorted_string_keys[sorted_string_count + i] = &hash_array[i];

  /* Sorting time! */
  sorted_string_count += i;
  qsort (sorted_string_keys, sorted_string_count,
	 sizeof (struct string_hash_entry *), sort_string_hashes);
  return 0;
}

/* Load in all of the string tables.
   Called the first time a string lookup is requested. */
static int
load_string_tables (void)
{
  static time_t already_checked = 0;
  int table_num;
  char *table_path;
  struct string_table_desc *stdesc;
  int status, old_errno;

  if (already_checked
    /* We've tried to load the string tables, and failed.
       Stop trying until at least a few seconds have passed. */
      && (difftime (time (NULL), already_checked) < 10))
    return -1;

  for (table_num = 0; table_num < (int) XtNumber (required_strings);
       table_num++)
    {
      table_path = xfindfile (NULL, required_strings[table_num],
			      ".tbl", path_to_tables);
      if (table_path != NULL)
	{
	  stdesc = read_string_tbl (table_path);
	  free (table_path);
	  if (stdesc != NULL) {
	    /* Replace the full filename with the base name */
	    stdesc->name = required_strings[table_num];
	    continue;
	  }
	}

      /* The .tbl file was not found or could not be loaded.
	 Try the .txt equivalent. */
      old_errno = errno;
      table_path = xfindfile (NULL, required_strings[table_num],
			      ".txt", path_to_tables);
      if (table_path != NULL)
	{
	  status = read_string_txt (table_path);
	  free (table_path);
	  if (status == 0)
	    continue;
	}

      /* Couldn't read this table.  If it's the first, give up
	 without trying the others; it's too important. */
      if (!table_num)
	{
	  if (old_errno != ENOENT)
	    errno = old_errno;
	  if (!already_checked
	      /* Warn the user every few minutes */
	      || (difftime (time (NULL), already_checked) > 600))
	    {
	      fprintf (stderr,
		       "%s: Error: unable to load the string tables; %s.\n",
		       progname, strerror (errno));
	      already_checked = time (NULL);
	    }
	  return -1;
	}
    }

  /* All done. */
  return 0;
}


/* Read in a data table. */
static struct table_desc *
read_data_table (const char *filename)
{
  struct table_desc *tdesc;
  char *buffer, *line;
  int file_size;
  int row, field_count;
  struct _TableEntry *entry;

  /* Read the entire file at once */
  file_size = snarf_file (filename, "r", (void **) &buffer);
  if (file_size <= 0)
    return NULL;

  tdesc = (struct table_desc *) xmalloc (sizeof (struct table_desc));
  tdesc->name = filename;	/* Should be overridden */
  tdesc->key = -1;		/* Unsorted */

  /* Start with reading the header line.
     This contains the column names for the table. */
  line = buffer;
  field_count = read_entry_from_table_file (&line, &tdesc->field_list);
  if (!field_count)
    {
      /* Error reading the header!  Clean up the trash. */
      free (tdesc);
      free (buffer);
      errno = EBADF;
      return NULL;
    }
  tdesc->num_fields = field_count;

  /* For each line in the table, allocate a new entry structure
     and fill it in with the fields in that row. */
  tdesc->entry_list = NULL;
  for (row = 0; *line && (line < &buffer[file_size]); row++)
    {
      tdesc->entry_list = (struct _TableEntry *)
	xrealloc (tdesc->entry_list, (row + 1) * sizeof (struct _TableEntry));
      entry = &tdesc->entry_list[row];
      entry->table = tdesc;
      entry->key = -1;
      entry->index = row;
      field_count = read_entry_from_table_file (&line, &entry->value_list);

      /* If the field count for this row is short,
	 fill in the rest of the table columns with empty strings.
	 All table entries MUST be used! */
      if (field_count < tdesc->num_fields)
	{
	  entry->value_list = (const char **)
	    xrealloc (entry->value_list, tdesc->num_fields * sizeof (char *));
	  for ( ; field_count < tdesc->num_fields; field_count++)
	    entry->value_list[field_count] = "";
	}
    }

  /* Finish up. */
  tdesc->num_entries = row;
  return tdesc;
}

/* Sort a data table.  Before calling this, the table's KEY field
   should be set to the column on which to sort. */
static void
sort_data_table (struct table_desc *tdesc)
{
  int row;

  /* First, run through the list of children and set all of
     their key values to the key of the table. */
  for (row = 0; row < tdesc->num_entries; row++)
    tdesc->entry_list[row].key = tdesc->key;

  /* Now just do a quick sort. */
  qsort (tdesc->entry_list, tdesc->num_entries,
	 sizeof (struct _TableEntry), sort_data_entries);
}

/* Compare two table descriptors for ordering */
static int
sort_table_descs (const void *p1, const void *p2)
{
  const struct table_desc *t1 = *((const struct table_desc **) p1);
  const struct table_desc *t2 = *((const struct table_desc **) p2);
  int diff;

  diff = strcasecmp (t1->name, t2->name);
  if (diff)
    return diff;
  if (t1->key < 0)
    return ((t2->key < 0) ? /* unlikely */ 0 : -1);
  if (t2->key < 0)
    return 1;
  return strcasecmp (t1->field_list[t1->key], t2->field_list[t2->key]);
}

/* Compare a table name to a table descriptor for searching.  If more
   than one table has the same name (i.e., two different sorts), which
   one is returned is arbitrary.  It is up to the caller to tell the
   difference. */
static int
search_table_descs (const void *vkey, const void *ptdesc)
{
  const char *key = (const char *) vkey;
  const struct table_desc *tdesc = *((const struct table_desc **) ptdesc);

  return strcasecmp (key, tdesc->name);
}

/* Compare two rows in a table for sorting.
   This uses the KEY field in the entries to determine how to sort. */
static int
sort_data_entries (const void *p1, const void *p2)
{
  const struct _TableEntry *e1 = (const struct _TableEntry *) p1;
  const struct _TableEntry *e2 = (const struct _TableEntry *) p2;
  int key, diff;

  key = e1->key;
  if (key != e2->key)
    {
      fprintf (stderr, "%s: Internal error in sort_data_entries\n"
	       " (%s:%d): entries have different sorting keys\n",
	       progname, __FILE__, __LINE__);
      key = -1;
    }
  if (key < 0)
    /* Entries are sorted by the order in the table
       (i.e., unsorted). */
    return (e1->index - e2->index);

  diff = strcasecmp (e1->value_list[key], e2->value_list[key]);
  if (diff)
    return diff;

  /* If the entries appear the same, we have two choices:
     either leave them in their relative order as read from the table,
     or compare the rest of the fields from left to right.
     It's probably more correct (and certainly faster) to do the former. */
  return (e1->index - e2->index);
}

/* Compare a key to a table entry for searching.  If more than one
   entry has the same key value, which one is returned is arbitrary.
   It is up to the caller to tell the difference. */
static int
search_data_entries (const void *vkey, const void *pentry)
{
  const char *key = (const char *) vkey;
  const struct _TableEntry *entry = (const struct _TableEntry *) pentry;

  if (entry->key < 0)
    /* Searching by index?  That would mean VKEY is a (const int *)... */
    return (*((const int *) vkey) - entry->index);
  return strcasecmp (key, entry->value_list[entry->key]);
}

/* Find the index of a named key in a table. */
static int
find_key_field (const struct table_desc *table, const char *key_name)
{
  int field;

  if (key_name == NULL)
    return -1;
  for (field = 0; field < table->num_fields; field++)
    if (strcasecmp (key_name, table->field_list[field]) == 0)
      return field;
  /* Key not found! */
  return -1;
}

/* Find a given table and sort it according to the given key field.
   If the table is already loaded, but sorted differently,
   the table descriptor is copied and the copy is resorted. */
static struct table_desc *
find_data_table (const char *name, const char *key_field)
{
  char *table_path = NULL;
  struct table_desc *tdesc, **ptdesc;
  int i;

  /* See whether the table is already here */
  ptdesc = bsearch (name, table_list, table_count,
		    sizeof (struct table_desc **), search_table_descs);
  if (ptdesc == NULL)
    {
      /* Table not loaded yet.  Try to load it in. */
      table_path = xfindfile (NULL, name, ".txt", path_to_tables);
      if (table_path == NULL)
	/* Table not found.  */
	return NULL;
      tdesc = read_data_table (table_path);
      if (tdesc == NULL)
	/* Error loading the table. */
	return NULL;
    }

  else
    {
      /* Does the table's current sort key equal the key field we want? */
      if (find_key_field (*ptdesc, key_field) == (*ptdesc)->key)
	/* Match!  Return the table. */
	return *ptdesc;

      /* Search backward for tables of the same name. */
      i = 0;
      while ((ptdesc > table_list)
	     && (search_table_descs (name, &ptdesc[-1]) == 0))
	{
	  ptdesc--;
	  i++;
	  if (find_key_field (*ptdesc, key_field) == (*ptdesc)->key)
	    /* Match! */
	    return *ptdesc;
	}

      /* Reset */
      ptdesc += i;
      /* Search forward for tables of the same name. */
      i = 0;
      while ((&ptdesc[1] < &table_list[table_count])
	     && (search_table_descs (name, &ptdesc[1]) == 0))
	{
	  ptdesc++;
	  i++;
	  if (find_key_field (*ptdesc, key_field) == (*ptdesc)->key)
	    /* Match! */
	    return *ptdesc;
	}

      /* Reset */
      ptdesc -= i;
      /* Since we have this table loaded, but it isn't
	 sorted the way we want it, make a copy. */
      tdesc = (struct table_desc *) xmalloc (sizeof (struct table_desc));
      tdesc->num_entries = (*ptdesc)->num_entries;
      tdesc->num_fields = (*ptdesc)->num_fields;
      tdesc->field_list = (*ptdesc)->field_list;
      tdesc->entry_list = (struct _TableEntry *)
	xmalloc (tdesc->num_entries * sizeof (struct _TableEntry));
      memcpy (tdesc->entry_list, (*ptdesc)->entry_list,
	      tdesc->num_entries * sizeof (struct _TableEntry));
    }

  /* We have a new table descriptor.  Set the name of the table
     and the sort key to those given by the caller. */
  tdesc->name = name;
  tdesc->key = find_key_field (tdesc, key_field);
  if ((tdesc->key < 0) && (key_field != NULL))
    {
      /* Entries can't be looked up without a proper key. */
      errno = EINVAL;
      fprintf (stderr, "%s: Error: data table %s",
	       progname, name);
      if (table_path != NULL)
	fprintf (stderr, " (%s)", table_path);
      fprintf (stderr, " does not have the key field \"%s\".\n", key_field);
      return NULL;
    }

  /* Sort the table according to its (new) key. */
  sort_data_table (tdesc);

  /* Add this table to our list of tables. */
  table_list = (struct table_desc **) xrealloc
    (table_list, (table_count + 1) * sizeof (struct table_desc *));
  table_list[table_count++] = tdesc;

  /* (Re-)sort the list of tables */
  qsort (table_list, table_count,
	 sizeof (struct table_desc *), sort_table_descs);

  /* Finally, return the new table to the caller. */
  return tdesc;
}


/****************************************************************
 *			 Global Functions			*
 ****************************************************************/

/* Preload certain tables.  If these tables are not found,
   it is considered a fatal error, and the editor won't start.
   Any tables requested after this function are considered
   optional, and will simply return NULL if not found. */
void
preload_tables (void)
{
  int i, failures = 0;

  /* Start with the string tables */
  load_string_tables ();

  /* Load the required data tables */
  for (i = 0; i < (int) XtNumber (required_tables); i++)
    {
      if (find_data_table (required_tables[i].name,
			   required_tables[i].key_field) == NULL)
	{
	  fprintf (stderr,
		   "%s: Error: unable to load the data table %s; %s.\n",
		   progname, required_tables[i].name, strerror (errno));
	  failures++;
	}
    }
  if (failures)
    exit (1);
}

/* Look up a string in one of the string tables by key,
   and return the string's equivalent value.
   This version returns NULL if the key is not found. */
const char *
LookupStringByKey (const char *key)
{
  struct string_hash_entry **phash;

  if (!sorted_string_count)
    {
      /* We need to load the tables */
      if (load_string_tables() < 0)
	return NULL;
    }
  /* Try an exact match first */
  phash = bsearch (key, sorted_string_keys, sorted_string_count,
		   sizeof (struct string_hash_entry *),
		   search_string_hash_case_sensitive);
  if (phash != NULL)
    {
      /* If the next hash entry also matches the key, use it instead. */
      while ((&phash[1] < &sorted_string_keys[sorted_string_count])
	     && (search_string_hash_case_sensitive (key, &phash[1]) == 0))
	phash++;
      return (*phash)->string_ptr;
    }

  /* Failing that, try case-insensitive. */
  phash = bsearch (key, sorted_string_keys, sorted_string_count,
		   sizeof (struct string_hash_entry *),
		   search_string_hash);
  if (phash != NULL)
    {
      /* If the next hash entry also matches the key, use it instead. */
      while ((&phash[1] < &sorted_string_keys[sorted_string_count])
	     && (search_string_hash (key, &phash[1]) == 0))
	phash++;
      return (*phash)->string_ptr;
    }

  /* String not found */
  return NULL;
}

/* Look up alternate text for a string.  The argument
   is still considered a key, but if alternate text
   is not found, the key is returned instead. */
const char *
TranslateString (const char *key)
{
  const char *translation = LookupStringByKey (key);
  return ((translation == NULL) ? key : translation);
}

/* Look up a string by its index number. */
const char *
LookupStringByIndex (const char *file, int index)
{
  int i;

  if (file == NULL)
    return NULL;

  for (i = 0; i < string_table_count; i++) {
    if (strcasecmp (string_table_list[i].name, file) == 0) {
      if ((unsigned) index >= string_table_list[i].header->num_strings)
	/* No such string */
	return NULL;
      return string_table_list[i].hash_array
	[string_table_list[i].header->index_to_hash[index]]
	.string_ptr;
    }
  }
  /* No such table */
  return NULL;
}

/* Find an entry in a data table by key.  You must provide the
   table name, the name of the key field, and the key itself.
   Returns an opaque pointer to the table entry. */
table_entry_t
LookupTableEntry (const char *table_name, const char *key_field,
		  const char *key)
{
  struct _TableEntry *pentry;
  struct table_desc *table;

  /* Find the table */
  table = find_data_table (table_name, key_field);
  if ((table == NULL) || (key == NULL))
    return NULL;

  /* Search the table for the given key */
  pentry = bsearch (key, table->entry_list, table->num_entries,
		    sizeof (struct _TableEntry), search_data_entries);

  /* If more than one entry is a match for the key, return the first. */
  while ((pentry > table->entry_list)
	 && (search_data_entries (key, &pentry[-1]) == 0))
    pentry--;

  return pentry;
}

/* Sometimes, keys are numeric.  They're still stored as strings,
   so we just convert the numeric argument to a string. */
table_entry_t
LookupNumericTableEntry (const char *table, const char *key_field, int key)
{
  char key_string[16];

  snprintf (key_string, sizeof (key_string), "%d", key);
  return LookupTableEntry (table, key_field, key_string);
}

/* Find an entry in a data table by index. */
table_entry_t
LookupIndexedTableEntry (const char *table_name, int index)
{
  struct table_desc *table;

  if (index < 0)
    return NULL;

  /* Find the table; it gets (un)sorted by index */
  table = find_data_table (table_name, NULL);
  if (table == NULL)
    return NULL;

  /* Get the INDEXth entry in the table.  Simple. */
  if (index >= table->num_entries)
    return NULL;
  return &table->entry_list[index];
}

/* Find the entry following a given one. */
table_entry_t
LookupNextEntryAfter (table_entry_t pentry)
{
  struct table_desc *table;

  if (pentry == NULL)
    return NULL;

  /* The table is already loaded.  But if it isn't sorted by index,
     we're going to create a new table descriptor that is. */
  table = pentry->table;
  if (table->key >= 0)
    {
      table = find_data_table (table->name, NULL);
      if (table == NULL)
	return NULL;
    }

  /* The entry's index tells us what comes next */
  if (pentry->index + 1 >= table->num_entries)
    return NULL;
  return &table->entry_list[pentry->index + 1];
}

/* Find the Nth entry following (or preceding) a given one. */
table_entry_t
LookupNthEntryAfter (table_entry_t pentry, int offset)
{
  struct table_desc *table;

  if (pentry == NULL)
    return NULL;

  /* The table is already loaded.  But if it isn't sorted by index,
     we're going to create a new table descriptor that is. */
  table = pentry->table;
  if (table->key >= 0)
    {
      table = find_data_table (table->name, NULL);
      if (table == NULL)
	return NULL;
    }

  /* Check the range of the offset */
  if ((pentry->index + offset < 0)
      || (pentry->index + offset >= table->num_entries))
    return NULL;
  return &table->entry_list[pentry->index + offset];
}

/* Return the number of entries in a given table;
   useful for finding the range of an indexed table. */
int
GetTableSize (const char *table_name)
{
  struct table_desc *table;

  table = find_data_table (table_name, NULL);
  if (table == NULL)
    return 0;
  return table->num_entries;
}

/* Get the value of one of the fields in a table entry,
   according to the expected data type. */
const char *
GetEntryStringField (table_entry_t pentry, const char *field_name)
{
  int field;

  /* The caller may pass a NULL entry, if the row he was looking for
     was not found (and he didn't check the answer).  In that case,
     treat it the same as an empty field. */
  if (pentry == NULL)
    return "";

  field = find_key_field (pentry->table, field_name);
  if (field < 0)
    {
      /* Missing a column in the table.  Since we're looking up
	 incidental data rather than a key, treat it as an
	 empty box rather than an error. */
      return "";
    }
  return pentry->value_list[field];
}

int
GetEntryIntegerField (table_entry_t pentry, const char *field_name)
{
  int field;

  /* The caller may pass a NULL entry, if the row he was looking for
     was not found (and he didn't check the answer).  In that case,
     treat it the same as an empty field. */
  if (pentry == NULL)
    return 0;

  /* If the caller passed NULL for the field name,
     he probably wants the entry's (unsorted) index number. */
  if (field_name == NULL)
    return pentry->index;

  field = find_key_field (pentry->table, field_name);
  if (field < 0)
    {
      /* Missing a column in the table.  Since we're looking up
	 incidental data rather than a key, treat it as an
	 empty box rather than an error. */
      return 0;
    }
  if (pentry->value_list[field][0] == '-')
    return strtol (pentry->value_list[field], NULL, 10);
  else
    return (int) strtoul (pentry->value_list[field], NULL, 10);
}
