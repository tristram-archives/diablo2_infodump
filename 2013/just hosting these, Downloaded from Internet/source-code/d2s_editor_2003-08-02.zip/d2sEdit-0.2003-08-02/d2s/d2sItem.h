/* Definition of C++ classes that hold an internal representation
 * of a Diablo II v1.09 item.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef D2SITEM_H
#define D2SITEM_H

#ifndef __cplusplus
#error "You need a C++ compiler to use this module"
#endif

#include <stdint.h>
#include "d2sQuality.h"
#include "tables.h"

/* Define item classes */

/* Major classes: */
typedef enum {
  UNKNOWN_ITEM = 0,
  SIMPLE_ITEM,	/* anything not more than 14 bytes */
  GEM_ITEM,	/* simple items which can be placed in a socket */
  RUNE_ITEM,	/* simple Expansion Set items which can be placed in a socket */
  POTION_ITEM,	/* simple items which can be tucked in a belt */
  UNKNOWN_EXTENDED_ITEM,
  EXTENDED_ITEM, /* only the Horadric Cube qualifies */
  STACK_ITEM,	/* would be simple, except it has to keep an item count */
  CHARM_ITEM,	/* an extended item with a picture */
  JEWEL_ITEM,	/* an extended item (with a picture)
		   that may be attached to a socket */
  ARMOR_ITEM,	/* an item that may be equipped and
		   has a defense rating, durability, and maybe sockets */
  WEAPON_ITEM,	/* an item that may be equipped in the right hand
		   and has a weapon class, durability, and maybe sockets */
  STACKED_WEAPON_ITEM, /* an item that may be equipped in the right hand
			  and has a weapon class and quantity */
} item_class_t;

/* Armor subclasses: */
typedef enum {
  UNKNOWN_ARMOR_CLASS = 0,
  BELT_CLASS, BODY_ARMOR_CLASS, BOOT_CLASS,
  GLOVE_CLASS, HELMET_CLASS, SHIELD_CLASS
} armor_class_t;

/* Weapon subclasses: */
typedef enum {
  UNKNOWN_WEAPON_CLASS = 0,
  AXE_CLASS, BOMB_CLASS, BOW_CLASS,
  CLAW_CLASS, CROSSBOW_CLASS, DAGGER_CLASS,
  JAVELIN_CLASS, MACE_CLASS, ORB_CLASS, POLEARM_CLASS,
  SPEAR_CLASS, STAFF_CLASS, SWORD_CLASS
} weapon_class_t;

/* Item equipment places */
typedef enum {
  EQUIPPED_ON_HEAD = 1, EQUIPPED_ON_NECK = 2, EQUIPPED_ON_TORSO = 3,
  EQUIPPED_ON_RIGHT_HAND = 4, EQUIPPED_ON_LEFT_HAND = 5,
  EQUIPPED_ON_RIGHT_FINGER = 6, EQUIPPED_ON_LEFT_FINGER = 7,
  EQUIPPED_ON_WAIST = 8, EQUIPPED_ON_FEET = 9, EQUIPPED_ON_HANDS = 10,
  EQUIPPED_ON_ALT_RIGHT_HAND = 11, EQUIPPED_ON_ALT_LEFT_HAND = 12
} item_equipment_slot_t;

/* Weapon speed ratings: */
typedef enum {
  SLOWEST_ATTACK_SPEED, VERY_SLOW_ATTACK_SPEED, SLOW_ATTACK_SPEED,
  NORMAL_ATTACK_SPEED,
  FAST_ATTACK_SPEED, VERY_FAST_ATTACK_SPEED, FASTEST_ATTACK_SPEED
} weapon_speed_t;

/* Places where a gem may be attached; used to find out
   which of a gem's magical properties are active. */
typedef enum {
  GEM_ATTACHMENT_UNKNOWN, GEM_ATTACHED_WEAPON, GEM_ATTACHED_ARMOR,
  GEM_ATTACHED_HELM, GEM_ATTACHED_SHIELD, NUM_GEM_ATTACHMENTS
} gem_attachment_t;


/* This structure is used to return a 3-character item type: */
typedef union {
  char		ch[4];	// 3-character string, null-terminated
  uint32_t	id;	// integer for fast equality comparison
} item_id_t;

/* This structure is used to return
   a 2-dimensional value [ (x,y) or (w,h) ]: */
typedef struct {
  int		x;
  int		y;
} coordinate_t;


/* Forward declarations of classes used or defined by d2sItem */
class d2sData;
class d2sMagic;

class d2sItem;
class d2sAttachItem;
class d2sGemOrRuneItem;
class d2sExtendedItem;
class d2sDurableItem;
class d2sStackItem;
class d2sCharmItem;
class d2sArmorItem;
class d2sGemItem;
class d2sJewelItem;
class d2sPotionItem;
class d2sWeaponItem;
class d2sStackedWeaponItem;

struct data_stream;

/****************    ITEM SUPERCLASS    ****************/

/* This first class is the superclass used to access any item.
   It is also sufficient to completely describe simple items. */
class d2sItem {
  /* These functions need to set the filename */
  friend d2sItem *ReadItemFile (const char *);
  friend int ReadItemLibrary (const char *, d2sItem ***);

 public:
  /********	FILE-RELATED FUNCTIONS:		********/

  /* All subclasses of d2sItem contain the following constructors. */

  /* Create a new, blank item (to be filled in later) */
  d2sItem (void);

  /* Create a new, specific item as described by the item table entry
     (using default variable attributes) */
  d2sItem (table_entry_t);

  /* Copy an existing item */
  d2sItem (const d2sItem &);

  virtual ~d2sItem ();		// Destructor

  /* Create and return a copy of this item. */
  virtual d2sItem *Copy (void) const ;

  /* Create an item by filling in data from a file.
     Returns 0 on success.  Sets the error string if a recoverable error
     was detected.  Returns -1 if a nonrecoverable error was detected,
     in which case the data stream should be deemed invalid. */
  virtual int	Read (struct data_stream *);

  /* Set the UI-specific data pointer for this object.
     Can only be called once. */
  int		SetUI (void *);

  /* Retrieve the UI-specific data pointer. */
  void *	GetUI (void) const { return ui_data; }

  /* Return the character associated with this item. */
  d2sData *	Owner (void) const { return character; }

  /* Return the file associated with this object.  If this object
     was created from scratch, taken from a .d2s file, or the file
     failed to load, this function returns NULL. */
  const char *	SourceFileName (void) const { return filename; }

  /* Discard any changes made to the item since it was created. */
  virtual void	DiscardChanges (void);

  /* Save an item file under the same name; returns 0 on success */
  int		Save (void);

  /* Save an item file using a new name; retuns 0 on success.
     Changes the associated filename on success (but not on error). */
  int		SaveAs (const char *);

  /* Remove an item from its owner.
     This must *only* be called by the owner! */
  virtual int	RemoveFromOwner (void);

  /* Assign an item to a character.
     This can only be done if the item is not already assigned.
     This simply defines the association; it is up to the character to
     install us in the correct place.  Use the second parameter if the
     item should be placed on a corpse or on a hireling. */
  virtual int	AssignTo (d2sData *, int area = 0);

  /* Whether the item data has changed */
  int		needs_saving (void) const { return dirty; }

  /* Attached gems, quality ratings, and magic properties
     must call this function when they have changed */
  virtual void	MarkDirty (void);

  /* Write an item out to a raw byte stream associated with a d2sData
     object (to be called by d2sData when saving a .d2s file) */
  void		Write (struct data_stream *);

  /* Return a string describing the latest error condition */
  const char *	GetErrorMessage (void) const { return error_str; }

  /********	DATA RETRIEVAL FUNCTIONS	********/

  /* Return the type classification of an item */
  item_class_t	Type (void) const { return item_class; }

  /* Convenience function: return the entry in the item tables for
     this item.  May be either in the misc., armor, or weapons table. */
  table_entry_t ItemTableEntry (void) const { return table_entry; }
  /* This one is in the item types table, for classifying items */
  table_entry_t TypeTableEntry (void) const { return type_entry; }

  /* Return the major location of an item */
  int		Location (void) const { return location; }

  /* Return the position of an item; this could be the equipment slot,
     belt slot, or row/column number if stowed. */
  coordinate_t	Position (void) const;

  /* Return an item's size */
  coordinate_t	Size (void) const
    { coordinate_t retval = { width, height }; return retval; }

  /* Return an item's ID as an integer */
  int		ID (void) const { return item_ID.id; }
  /* or a character string */
  const char *	Code (void) const { return &item_ID.ch[0]; }

  /* Return the name of the graphic used to display the item */
  virtual const char *Graphic (void) const { return graphic; }

  /* Return an item's common (base) name */
  const char *	Name (void) const { return base_name; }

  /* Return the minimum level required to use this item */
  virtual int RequiredLevel (void) const { return base_level; }
  int BaseRequiredLevel (void) const { return base_level; }

  /* Construct and return a string containing an item's
     full description, suitable for display.
     The string must be freed when done. */
  virtual char *FullDescription (void) const;

  /* Construct and return a list of all magic
     properties in effect on the item. */
  virtual d2sMagic *CombinedProperties (void) const;

  /* Return whether the item is... */
  int		is_quest_item (void) const { return quest_item; }
  virtual int	is_expansion_item (void) const { return expansion_item; }

  /* An item is considered read-only if the owner is read-only */
  int		read_only (void) const;

  /* Return whether the item matches a given ID or type */
  int		operator== (const char *code) const
    { return (item_ID.id == ((item_id_t *) code)->id); }
  int		operator!= (const char *code) const
    { return (item_ID.id != ((item_id_t *) code)->id); }
  int		is_of_type (const char *) const;

  /********	DATA MODIFICATION FUNCTIONS	********/

  /* Check the legality of a location change. */
  int		CheckLocationChange (int area, int new_slot_or_column,
				     int new_row, int warn = 0);

  /* Change the location of an item; returns -1 on failure, 0 otherwise.
     For generic items, this restricts item placement to storage
     (inventory, stash, or cube).  If the item is to be placed in the
     stash, it first checks whether its owner is an expansion character
     to get the stash size. */
  virtual int	SetLocation (int area, int new_slot_or_column,
			     int new_row = 0);

  /********	CONVERSION	********/

  /* Cast a d2sItem to one of its subclasses.
     This list covers classes which have a virtual base class or
     multiple base classes; standard conversions should cover the rest.
     Warning: These casts are counter-intuitive, because they take
     a d2sItem& (the object itself) and return a pointer.
     (There just isn't any way to make them take a pointer.) */
  operator d2sAttachItem* () const;
  operator d2sExtendedItem* () const;
  operator d2sCharmItem* () const;
  operator d2sStackItem* () const;
  operator d2sDurableItem* () const;
  operator d2sJewelItem* () const;
  operator d2sStackedWeaponItem* () const;

  /********	LINKED LIST	********/

  /* These fields are for use by the character object
     in order to link several items together in a list. */
  d2sItem *next, **pprev;

 protected:
  /* Initialize member fields based on an item table entry.
     This one cannot be called from a constructor. */
  virtual int	ChangeItemType (table_entry_t);
  /* Replace the raw item data */
  void		ReplaceRawData (unsigned char *, unsigned int);
  /* Commit changes made to the item to the raw data field. */
  virtual void	CommitChanges (void);

  /* Non-Virtual Object Pointer -- since the d2sItem class (and
     d2sExtendedItem) may be virtual base classes of another derived
     class, and C++ doesn't allow you to cast a d2sItem* to a derived
     class pointer, the pointer to the most-derived class should be
     stored here by the last constructor function. */
  void *	nvop;

  char *	filename;	// The filename associated with the saved item
  d2sData *	character;	// The character this item belongs to
  void *	ui_data;	// The UI element associated with this object
  int		dirty;		// True if the item was modified
  const char *	error_str;	// Last error encountered
  unsigned char *raw_data;	// Raw item data
  unsigned int	raw_length;	// Length of the raw item data
  table_entry_t table_entry;	// Item's entry in the appropriate item table
  table_entry_t type_entry;	// Item's entry in the item types table

  /* This field is looked up from the item ID, and is used to
     narrow a generic d2sItem instance down to a particular subclass. */
  item_class_t	item_class;

  /* The following fields are mostly copied from the raw item data: */
  unsigned int	identified_item:1; // True if the item has been identified
  unsigned int	ethereal_item:1; // True if the item is ethereal
  unsigned int	personalized_item:1; // True if the item has been personalized
  unsigned int	runeworded_item:1; // True if the item has a Rune Word
  unsigned int	newbie_item:1;	// True if the item has newbie status
  unsigned int	socketed_item:1; // True if the item has sockets
  int8_t	location;	// Location of the item; corresponds with
				// ITEM_AREA_xxx macros in "define.h".
  uint8_t	loc_1;		// Location of the item; corresponds with
				// 'location' in item header
  uint8_t	stored_loc;	// Location of the item; corresponds with
				// 'stored_location' in item header
  uint8_t	equipped_slot;
  uint8_t	column;
  uint8_t	row;
  uint8_t	gem_count;	// Number of sockets filled
  item_id_t	item_ID;

  /* The following fields are looked up from the table of items: */
  const char *	base_name;	// Common name of the item (before modifiers)
  const char *	graphic;	// item ID of the picture this item uses
  int8_t	width;		// Size of the item
  int8_t	height;
  int8_t	quest_item;	// True if the item is required for a quest
  int8_t	expansion_item; // True if the item is only available
				// to Expansion characters
  uint8_t	base_level;	// Both gems, charms, and durable items
				// have level requirements.

 private:
  /* Clear the class member fields */
  void		Init (void);
  /* Initialize this class' member fields based on an item table entry.
     This one may only be called from a constructor. */
  void		SetItemType (table_entry_t);
};

/* Read data from a .d2i file or part of a .d2s file and return
   an item object for it.  This function figures out the matching
   item class and calls the correct constructor. */
d2sItem *ReadItemFromFile (struct data_stream *);

/* Open and read a single item from a .d2i file. */
d2sItem *ReadItemFile (const char *filename);

/* Open and read a list of items from a library or item set file.
   Returns the number of items in the list, or -1 on error. */
int ReadItemLibrary (const char *filename, d2sItem ***ret_list);

/* Create an item from scratch using the item tables for reference.
   This function figures out the matching item class and calls the
   correct constructor. */
d2sItem *CreateItemFromCode (const char *);
d2sItem *CreateSetItem (int set_number, int member_index);
d2sItem *CreateUniqueItem (int unique_index);


/****************    SUBCLASSES    ****************/

/* The first subclass is a potion.  This is a simple item with the
   additional property that it can be stored in a belt, and additional
   functions of upgrading (or downgrading) the potion or transforming
   one potion type into another. */
class d2sPotionItem : public d2sItem {
 public:

  /* Create a new, blank potion (to be filled in later) */
  d2sPotionItem (void);

  /* Create a new, specific potion as described by the item table entry */
  d2sPotionItem (table_entry_t);

  /* Copy an existing potion */
  d2sPotionItem (const d2sPotionItem &);

  /* Create and return a copy of this potion. */
  virtual d2sItem *Copy (void) const;

  /* Create a potion by filling in data from a file.
     (This simply calls d2sItem::Read, then sets our own data fields) */
  virtual int	Read (struct data_stream *);

  virtual void	DiscardChanges (void);

  /* Potions add a number of points to their description. */
  virtual char *FullDescription (void) const;

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the potion major type number (i.e., different grades of
     mana potions all have the same major type) */
  int		TypeNumber (void) const { return major_type; }

  /* Get the grade number of a potion */
  int		GradeNumber (void) const { return grade; }

  /* Transform a potion into another kind of potion
     (see functions below the class for parameters).
     If the grade is -1, use the highest grade for that type of potion. */
  int		TransformInto (int new_type, int new_grade = -1);

  /* Upgrade (or downgrade) a potion */
  int		UpgradeTo (int new_grade)
    { return TransformInto (major_type, new_grade); }

 private:
  /* Look up the potion's type and grade in the static data table */
  int		LookupPotion (void);

  char		major_type;	// Major type of potion (healing, mana, etc.)
  char		grade;		// Potion grade (minor, full, etc.)
};

/* These potion functions don't require an object to work from,
   so they are external to the class definition. */

/* Return the number of potion types defined. */
int GetNumberOfPotionTypes (void);

/* Return the base name of the Nth defined potion */
const char *GetPotionTypeName (int);

/* Return the number of potion grades for a potion of the given type
   (5 for health or mana, 2 for rejuvination, 1 for others). */
int GetNumberOfPotionGrades (int type);

/* Return the prefix of the Nth grade of a potion type */
const char *GetPotionGradePrefix (int type, int grade_N);


/****************/

/* This intermediate class is used for items which can be placed in a
   socket (gems, runes, jewels). */
class d2sAttachItem : virtual public d2sItem {
 public:

  /* Note the lack of constructors;
     the intermediate class is not instantiated itself. */

  virtual void	MarkDirty (void);

  /* Change the location of the attachable.  Like the superclass version,
     but extra stuff needs to be done if the item was in a socket. */
  virtual int	SetLocation (int area, int new_slot_or_column,
			     int new_row = 0);

  /********	NEW CLASS FUNCTIONS	********/

  /* If the gem is socketed, return the item to which the gem is attached. */
  d2sDurableItem *AttachedTo (void) const { return attachment; }

  /* Return the socket index number to which the gem is attached. */
  int		SocketNumber (void) const { return socket_number; }

  /* Change the location of the gem (/rune /jewel).
     This specifically associates the gem with a socket. */
  int		AttachTo (d2sDurableItem *, int socket_num);

  /* Cast an attachable item to a jewel subclass. */
  operator d2sJewelItem* () const;

 protected:
  /* This is where the constructors are located;
     they are to be used by the derived classes only. */
  d2sAttachItem (void);
  d2sAttachItem (table_entry_t);
  d2sAttachItem (const d2sAttachItem &);

  d2sDurableItem *attachment;	// Item to which the gem is attached
  gem_attachment_t attached_type; // For convenience, the type of attachment
  int		socket_number;	// Which socket this gem is in
};


/****************/

/* This intermediate class is used because gems and runes share some
   common properties.  It should be declared a virtual base class to
   gems and runes. */
class d2sGemOrRuneItem : public d2sAttachItem {
 public:

  /* Note the lack of constructors;
     the intermediate class is not instantiated itself. */

  /* Both gems and runes add their required level
     and magic properties to the descrption. */
  virtual char *FullDescription (void) const;

  /* The 'combined properties' of a gem includes only those
     properties valid for the item the gem is attached to. */
  virtual d2sMagic *CombinedProperties (void) const;

  /********	NEW CLASS FUNCTIONS	********/

  /* Return the magical property of a gem or rune given its current or
     desired location.  If 'location' is GEM_ATTACHMENT_UNKNOWN, and
     the gem or rune is in a socket, return the property for the gem
     or rune's current location. */
  const d2sMagic *Properties (gem_attachment_t if_attached_to
			      = GEM_ATTACHMENT_UNKNOWN);

  /* Return the color a gem gives to an item (all gems have color) */
  const char *	Color (void) const { return color_code; }

 protected:
  /* This is where the constructors are located;
     they are to be used by the derived classes only. */
  d2sGemOrRuneItem (void);
  d2sGemOrRuneItem (table_entry_t);
  d2sGemOrRuneItem (const d2sGemOrRuneItem &);
  /* Initialize member fields based on an item table entry.
     This one cannot be called from a constructor. */
  virtual int	ChangeItemType (table_entry_t);

  /* This array references the magic properties imbued in the gem/rune
     for each type of object to which the gem/rune may be attached. */
  const d2sMagic *magic_properties[NUM_GEM_ATTACHMENTS];

  /* Gem's entry in the 'gems' table */
  table_entry_t	gemtable_entry;
  /* The color that the gem gives to an object to which it is attached */
  const char *	color_code;

 private:
  /* Initialize this class' member fields based on an item table entry.
     This one may only be called from a constructor. */
  void		SetItemType (table_entry_t);
};


/****************/

/* The next subclass is a gem.  This is an attachable item with the
   additional functions of upgrading (or downgrading) the gem.  They
   also have additional attributes of a level requirement, and magical
   properties depending on where the gem is attached. */
class d2sGemItem : public d2sGemOrRuneItem {
 public:

  /* Create a new, 'blank' gem */
  d2sGemItem (void);

  /* Create a new, specific gem as described by the item table entry */
  d2sGemItem (table_entry_t);

  /* Copy an existing gem */
  d2sGemItem (const d2sGemItem &);

  /* Create and return a copy of this gem. */
  virtual d2sItem *Copy (void) const;

  /* Create a gem by filling in data from a file.
     (This simply calls d2sGemOrRuneItem::Read,
     then sets our own data fields) */
  virtual int	Read (struct data_stream *);

  virtual void	DiscardChanges (void);

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the gem major type number (i.e., skull, ruby, etc.) */
  int		TypeNumber (void) const { return major_type; }

  /* Get the grade number of a gem */
  int		GradeNumber (void) const { return grade; }

  /* Transform a gem into another kind of gem.
     The default grade is Perfect. */
  int		TransformInto (int new_type, int new_grade = 4);

  /* Upgrade (or downgrade) a gem */
  int		UpgradeTo (int new_grade)
    { return TransformInto (major_type, new_grade); }

 private:
  /* Look up the gem's type and grade in the static data table */
  void		LookupGem (void);

  short		major_type;	// Major type of gem (skull, ruby, etc.)
  short		grade;		// Gem grade
};

/* These gem functions don't require an object to work from,
   so they are external to the class definition. */

/* Return the number of gem types defined. */
inline int GetNumberOfGemTypes (void) { return 7; }

/* Return the name of the Nth defined gem */
const char *GetGemTypeName (int);

/* Return the number of gem grades (same for all gems). */
inline int GetNumberOfGemGrades (void) { return 5; }

/* Return the prefix of the Nth grade of a gem */
const char *GetGemGradePrefix (int);


/****************/

/* The next subclass is a rune.  This is an attachable item with the
   additional functions of transforming one rune type into another.
   They also have additional attributes of a level requirement, and
   magical properties depending on where the rune is attached. */
class d2sRuneItem : public d2sGemOrRuneItem {
 public:

  /* Create a new, 'blank' rune */
  d2sRuneItem (void);

  /* Create a new, specific rune as described by the item table entry */
  d2sRuneItem (table_entry_t);

  /* Copy an existing rune */
  d2sRuneItem (const d2sRuneItem &);

  /* Create and return a copy of this rune. */
  virtual d2sItem *Copy (void) const;

  /* Create a rune by filling in data from a file.
     (This simply calls d2sGemOrRuneItem::Read,
     then sets our own data fields) */
  virtual int	Read (struct data_stream *);

  virtual void	DiscardChanges (void);

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the index number of a rune. */
  int		RuneNumber (void) const { return rune_num; }

  /* Transform a rune into another kind of rune. */
  int		TransformInto (int);

 private:
  int		rune_num;	// Rune number
};

/* These rune functions don't require an object to work from,
   so they are external to the class definition. */

/* Return the number of runes defined.
   (Actually, it's the highest rune number defined.) */
int GetNumberOfRunes (void);

/* Return the name of the Nth rune */
const char *GetRuneName (int);


/********************************/

/* The next (intermediate) class is an extended item.  This class
   expands on the simple item class by adding a unique ID field and
   quality that apply to several of the specific subclasses.  Also,
   extended items, unlike simple ones, may have magical properties
   associated with them.  This class should be declared a virtual
   base class to all derived classes. */
class d2sExtendedItem : virtual public d2sItem {
 public:

  /* Create a new, blank extended item (to be filled in later) */
  d2sExtendedItem ();

  /* Create a new, specific extended item
     as described by the item table entry */
  d2sExtendedItem (table_entry_t);

  virtual ~d2sExtendedItem ();	// Destructor

  /* Create and return a copy of this item. */
  virtual d2sItem *Copy (void) const;

  /* Create an item by filling in data from a file.
     This is meant to be used on an item copied from a template,
     though it can also be used on a blank item if the type is unknown.
     DO NOT use on a template itself! */
  virtual int	Read (struct data_stream *);

  virtual void	DiscardChanges (void);

  virtual const char *Graphic (void) const;
  virtual int RequiredLevel (void) const;
  virtual int	is_expansion_item (void) const;

  virtual d2sMagic *CombinedProperties (void) const;

  /********	NEW CLASS FUNCTIONS	********/

  /* Return an item's fully qualified name (dynamically allocated) */
  char *	FullName (void) const;

  /* Return the item's random uniqueness code */
  unsigned long UniqueID (void) const { return unique_id; }

  /* Return the item's creation level */
  int		Level (void) const { return level; }

  /* Return the item's quality rating */
  d2sQuality *	Quality (void) { return item_quality; }

  /* Retern whether an item has been identified */
  int		is_identified (void) const { return identified_item; }

  /* Return whether an item has been personalized */
  int		is_personalized (void) const { return personalized_item; }

  /* Return whether an item has a Rune Word */
  int		has_rune_word (void) const { return runeworded_item; }

  /* Return the name of the character who personalized this item */
  const char *	PersonalizedName (void) const { return inscription; }

  /* Return the magical properties of an item (not counting gem effects). */
  d2sMagic *	Properties (void) { return magic_properties; }

  /* Return the color of an item (NULL if no color change) */
  virtual const char *Color (void) const;
  virtual int	is_colored (void) const
    { return (color_group && (item_quality->Color() != NULL)); }

  /********	NEW DATA MODIFICATION FUNCTIONS	********/

  /* Change whether an item has been identified */
  int		SetIdentified (int);

  /* Change the unique ID of an extended item */
  int		GenerateUniqueID (void);
  int		SetUniqueID (unsigned long);

  /* Change an item's level */
  virtual int	SetLevel (int);

  /* Personalize an item */
  int		Personalize (const char *);

  /* Change an item's quality */
  virtual int	ChangeQuality (int);
  virtual int	ChangeQuality (d2sQuality *);

 protected:
  /* This constructor is to be used by the derived classes only. */
  d2sExtendedItem (const d2sExtendedItem &);

  /* Initialize member fields based on an item table entry.
     This one cannot be called from a constructor. */
  virtual int	ChangeItemType (table_entry_t);

  /* Read class-specific fields from the item data bit stream.
     Called by d2sExtendedItem after reading the quality fields
     and before reading the magic properties. */
  virtual int	ReadItemSpecificData (struct bit_stream *);

  /* Derived classes call this to append common fields
     to their full description: required level, magic properties,
     sockets, ethereal */
  char *	FinishFullDescription (char *) const;

  /* Commit changes made to the item to the raw data field. */
  virtual void	CommitChanges (void);

  /* Write class-specific fields to the item data bit stream.
     Called by d2sExtendedItem after writing the quality fields
     and before writing the magic properties. */
  virtual int	WriteItemSpecificData (struct bit_stream *);

  /* The following fields are mostly copied from the raw item data: */
  uint32_t	unique_id;	// Item's 32-bit unique random number
  uint8_t	level;  	// Item level
  /* The following bit was found to be 1 on a Tome of Identify,
     but nothing else. */
  uint8_t	end_bit;	// 1-bit field between the personalization
				// and the item-specific data
  /* If this item is socketed, this field holds the number of sockets.
     It is only used by derived classes of d2sDurableItem, below;
     and by the FinishFullDescription() function they call. */
  uint8_t	num_sockets;
  /* If the item is part of a set, this member holds the field
     that sits between the item-specific data and the magic properties: */
  uint8_t	set_field;

  d2sQuality *	item_quality;	// Quality settings (incl. picture & name)
  int		color_group;	// Palette used for color shifting

  uint32_t	runeword_id;	// Don't know much about this, yet...

  char		inscription[16]; // Name of char. who personalized the item

  /* The following member is built up from the variable-length data fields */
  d2sMagic *	magic_properties; // Magical properties

 private:
  /* Clear the class member fields */
  void		Init (void);
};


/****************/

/* A charm is (class-wise) an extended item that includes a picture. */
class d2sCharmItem : virtual public d2sExtendedItem {
 public:

  /* Create a new, blank charm (to be filled in later) */
  d2sCharmItem (void);

  /* Create a new, specific charm as described by the item table entry 
     (using default variable attributes)*/
  d2sCharmItem (table_entry_t);

  /* Copy an existing charm */
  d2sCharmItem (const d2sCharmItem &);

  /* Create and return a copy of this charm. */
  virtual d2sItem *Copy (void) const;

  /* Charms add their required level and magic properties to the
     descrption.  (They could add their picture, but that belongs to
     the GUI, not here.) */
  virtual char *FullDescription (void) const;

  /********	NEW CLASS FUNCTIONS	********/

 protected:
  /* Read class-specific fields from the item data bit stream.
     Called by d2sExtendedItem after reading the quality fields
     and before reading the magic properties. */
  virtual int	ReadItemSpecificData (struct bit_stream *);

  /* Write class-specific fields to the item data bit stream.
     Called by d2sExtendedItem after writing the quality fields
     and before writing the magic properties. */
  virtual int	WriteItemSpecificData (struct bit_stream *);
};


/****************/

/* A jewel is like a small charm that can be attached to a socket. */
class d2sJewelItem : public d2sAttachItem, public d2sCharmItem {
 public:

  /* Create a new, blank jewel (to be filled in later) */
  d2sJewelItem (void);

  /* Create a new, specific jewel as described by the item table entry
     (using default variable attributes) */
  d2sJewelItem (table_entry_t);

  /* Copy an existing jewel */
  d2sJewelItem (const d2sJewelItem &);

  /* Create and return a copy of this jewel. */
  virtual d2sItem *Copy (void) const;

  /* Use d2sExtendedItem's RequiredLevel, not d2sItem's */
  virtual int RequiredLevel (void) const
    { return this->d2sExtendedItem::RequiredLevel(); }
};


/****************/

/* A stack item is simply an extended item that includes a quantity field.
   It has restrictions that it cannot be socketed, ethereal, or newbie;
   cannot have any magical properties, and must be normal quality. */
class d2sStackItem : virtual public d2sExtendedItem {
 public:

  /* Create a new, blank stack (to be filled in later) */
  d2sStackItem (void);

  /* Create a new, specific stack as described by the item table entry
     (using default variable attributes) */
  d2sStackItem (table_entry_t);

  /* Copy an existing stack */
  d2sStackItem (const d2sStackItem &);

  /* Create and return a copy of this stack. */
  virtual d2sItem *Copy (void) const;

  /* Stacks add their quantity to the descrption. */
  virtual char *FullDescription (void) const;

  /********	NEW CLASS FUNCTIONS	********/

  /* Whether this item has a 5-bit tome field */
  int		is_tome (void) const { return tome; }
  int		TomeField (void) const { return tome_value; }

  /* Get the number of items in the stack */
  int		Quantity (void) const { return quantity; }

  /* Get the maximum number of items allowed in one stack */
  int		MaxQuantity (void) const;

  /********	NEW DATA MODIFICATION FUNCTIONS	********/

  int		SetQuantity (int);
  int		Replenish (void) { return SetQuantity (MaxQuantity()); }

 protected:
  /* Read class-specific fields from the item data bit stream.
     Called by d2sExtendedItem after reading the quality fields
     and before reading the magic properties. */
  virtual int	ReadItemSpecificData (struct bit_stream *);

  /* Write class-specific fields to the item data bit stream.
     Called by d2sExtendedItem after writing the quality fields
     and before writing the magic properties. */
  virtual int	WriteItemSpecificData (struct bit_stream *);

  int16_t	quantity;	// Taken from the raw item data
  int16_t	min_quantity;	// Taken from the table of items
  int16_t	max_quantity;	// Taken from the table of items
  int8_t	tome;		// If true, there is another 5-bit field
  int8_t	tome_value;	// in the item data.  (Purpose unknown.)
};


/********************************/

/* The next (intermediate) class is a durable extended item.
   This class expands on the extended item class by adding attributes
   (durability, socketed, ethereal, newbie, requirements)
   that apply to both armor and weapons. */
class d2sDurableItem : virtual public d2sExtendedItem {
 public:

  /* Create a new, blank durable item (to be filled in later) */
  d2sDurableItem ();

  /* Create a new, specific durable item as described by the item table entry
     (using default variable attributes) */
  d2sDurableItem (table_entry_t);

  virtual ~d2sDurableItem ();	// Destructor

  /* Create a durable item by filling in data from a file.
     (This simply calls d2sExtendedItem::Read,
     then sets our own data fields) */
  virtual int	Read (struct data_stream *);

  /* Commit changes made to the item to the raw data field. */
  virtual void	CommitChanges (void);

  virtual void	DiscardChanges (void);

  /* Remove an item, and any attached items, from its owner. */
  virtual int	RemoveFromOwner (void);

  /* Assign an item, and any attached items, to a character. */
  virtual int	AssignTo (d2sData *, int area = 0);

  /* Return the maximum of the item's own level requirement
     and those of all its attached gems. */
  virtual int RequiredLevel (void) const;

  /* Durable items need to test whether any attached gems
     are expansion items, as well as the item itself. */
  virtual int	is_expansion_item (void) const;

  /* Return the color of an item (NULL if no color change) */
  virtual const char *Color (void) const;
  virtual int	is_colored (void) const;

  /* For most durable items, the combined properties
     adds the item's own properties to those of all attached gems. */
  virtual d2sMagic *CombinedProperties (void) const;

  virtual int	SetLevel (int);

  /* Change an item's quality */
  virtual int	ChangeQuality (int);
  virtual int	ChangeQuality (d2sQuality *);

  /********	NEW CLASS FUNCTIONS	********/

  /* Return whether the item is... */
  int is_socketed (void) const { return socketed_item; }
  int is_ethereal (void) const { return ethereal_item; }
  int is_newbie (void) const { return newbie_item; }
  int is_class_restricted (void) const { return restricted_item; }

  /* Get the item's class restriction, if it has one. */
  int ClassRestriction (void) const { return class_restriction; }

  /* Get the item's base / current durability */
  int BaseDurability (void) const { return base_durability; }
  int Durability (void) const { return durability; }

  /* Get the item's maximum durability after applying
     any magical enhancements (this will take some work) */
  int MaxDurability (void) const;

  /* Get the item's requirements */
  int BaseRequiredDexterity (void) const { return base_dexterity; }
  int RequiredDexterity (void) const;
  int BaseRequiredStrength (void) const { return base_strength; }
  int RequiredStrength (void) const;

  /* Return the number of sockets the item has */
  int NumberOfSockets (void) const { return num_sockets; }

  /* Return the number of sockets the item has including modifiers */
  int ModNumberOfSockets (void) const;

  /* Return the number of gems/runes/jewels attached to the item */
  int NumberOfGems (void) const { return gem_count; }

  /* Return the maximum number of sockets that can be placed on this item */
  int MaximumNumberOfSockets (void) const;

  /* Return the Nth gem, rune, or jewel attached to the item */
  d2sAttachItem *Gem (int);

  /* If the item has any runes attached, this function returns the name
     that the runes form.  If no runes are attached, it returns NULL.
     (The string is dynamically allocated; free() when finished.) */
  char *RuneName (void) const;

  /* If the syllables form a Rune Word, this returns it.  Else NULL. */
  const char *RuneWord (void) const;

  /********	NEW DATA MODIFICATION FUNCTIONS	********/

  /* Change an item's durability */
  int		SetBaseDurability (int);
  int		SetDurability (int);
  int		Repair (void) { return SetDurability (MaxDurability()); }

  /* Change the number of sockets in an item */
  int		SetNumberOfSockets (int);

  /* Change whether an item is ethereal */
  int		SetEthereal (int);
  /* Change whether an item is for a new character */
  int		SetNewbie (int);

  /* Add a gem to the item.  If the POSITION is specified and a gem is
     already at the given position, insert the gem, moving existing
     gems down a socket.  Otherwise the gem gets placed at the end
     (even if POSITION is past the end). */
  int		AddGem (d2sAttachItem *, int position = -1);

  /* Remove a gem from the item. */
  int		RemoveGem (d2sAttachItem *);
  int		RemoveGem (int position);

 private:
  table_entry_t find_rune_word (void) const;

 protected:
  /* This constructor is to be used by the derived classes only. */
  d2sDurableItem (const d2sDurableItem &);

  /* After regenerating an item's magic properties, call this function
     to add back the Rune Word's properties (if one exists). */
  void		ReapplyRuneWord (void);

  /* The following fields are mostly copied from the raw item data: */
  char		restricted_item; // True if the item is for a specific class
  char		class_restriction; // Which class is allowed to use this item
  short		base_durability;
  short		durability;	// Current durability

  /* The following fields are looked up from the table of items: */
  char		max_sockets;	// Maximum number of sockets this item can have
  uint16_t	base_dexterity;
  uint16_t	base_strength;

  /* The following member is built up from item data following this item */
  d2sAttachItem **gems;		// Array of pointers to attached gems
};


/****************/

/* Armor is a durable item that has an armor type and defense rating.
   It can be equipped, but only in a location consistent with the
   armor type.  For convenience, this class also tracks a shield's
   blocking ability and a belt's number of slots. */
class d2sArmorItem : public d2sDurableItem {
 public:

  /* Create a new, blank piece of armor (to be filled in later) */
  d2sArmorItem (void);

  /* Create a new, specific armor item as described by the armor table entry
     (using default variable attributes) */
  d2sArmorItem (table_entry_t);

  /* Copy an existing piece of armor */
  d2sArmorItem (const d2sArmorItem &);

  /* Create and return a copy of this armor. */
  virtual d2sItem *Copy (void) const;

  /* Armor adds their quality, defense, durability, requirements,
     and magic properties (and for shields, chance to block)
     to the descrption. */
  virtual char *FullDescription (void) const;

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the armor class */
  armor_class_t ArmorClass (void) const { return armor_class; }

  /* Get the armor's defense rating */
  int Defense (void) const;
  int BaseDefense (void) const { return base_defense; }

  /* If this is a shield, return its chance to block */
  int ChanceToBlock (void) const;
  int BaseChanceToBlock (void) const { return base_chance_to_block; }

  /* If this is a belt, return the number of boxes it gives you
     (the smallest belt gives you 2 rows of 4 boxes each). */
  int NumberOfBoxesInBelt (void) const { return belt_boxes; }

  /********	NEW DATA MODIFICATION FUNCTIONS	********/

  /* Change the armor's defense rating */
  int SetDefense (int);

 protected:
  /* Initialize member fields based on an item table entry.
     This one cannot be called from a constructor. */
  virtual int	ChangeItemType (table_entry_t);

  /* Read class-specific fields from the item data bit stream.
     Called by d2sExtendedItem after reading the quality fields
     and before reading the magic properties. */
  virtual int	ReadItemSpecificData (struct bit_stream *);

  /* Write class-specific fields to the item data bit stream.
     Called by d2sExtendedItem after writing the quality fields
     and before writing the magic properties. */
  virtual int	WriteItemSpecificData (struct bit_stream *);

  armor_class_t	armor_class;	// helmet, shield, boots, etc.
  short		base_defense;	// Base defense (w/o bias)
  short		base_chance_to_block; // for shields only
  int		belt_boxes;	// for belts only

 private:
  /* Initialize this class' member fields based on an item table entry.
     This one may only be called from a constructor. */
  void		SetItemType (table_entry_t);
};


/****************/

/* A Weapon is a durable item that has a weapon class and damage
   rating.  It can be equipped in the right hand. */
class d2sWeaponItem : public d2sDurableItem {
 public:

  /* Create a new, blank weapon (to be filled in later) */
  d2sWeaponItem (void);

  /* Create a new, specific weapon as described by the weapon table entry
     (using default variable attributes) */
  d2sWeaponItem (table_entry_t);

  /* Copy an existing weapon */
  d2sWeaponItem (const d2sWeaponItem &);

  /* Create and return a copy of this weapon. */
  virtual d2sItem *Copy (void) const;

  /* Weapons add their quality, damage, durability, requirements,
     speed, and magic properties to the descrption. */
  virtual char *FullDescription (void) const;

  /* Certain weapons add an inherent "150% damage to undead"
     to the combined properties. */
  virtual d2sMagic *CombinedProperties (void) const;

  /********	NEW CLASS FUNCTIONS	********/

  /* Get the weapon class */
  weapon_class_t WeaponClass (void) const { return weapon_class; }

  /* Macros for the damage array: */
#define ONE_HAND_DAMAGE 0
#define TWO_HAND_DAMAGE 1
#define BASE_DAMAGE	0
#define CURRENT_DAMAGE	1
#define MINIMUM_DAMAGE	0
#define MAXIMUM_DAMAGE	1

  /* Whether the weapon... */
  int		is_throwable (void) const
    { return (item_class == STACKED_WEAPON_ITEM); }
  int		is_two_handed (void) const
    /* Throwable and two-handed weapons are mutually exclusive */
    { return GetEntryIntegerField (table_entry, "2handed"); }
  int		is_one_handed (void) const
    /* We also count throwable (stacked) weapons as one-handed */
    { return (is_throwable() || ! is_two_handed()
	      || GetEntryIntegerField (table_entry, "1or2handed")); }

  /* Get the amount of damage inflicted.  One function to save namespace. */
  int		GetDamage (int hands, int current, int max) const;

  /* Get the percentage of additional damage to the undead. */
  int		GetDamageToUndead (void) const
    { return base_damage_to_undead; }

  /* Get the weapon's attack speed as a number */
  int		AttackSpeedValue (void) const;

  /* Get the weapon's attack speed as a string */
  const char *	AttackSpeed (void) const;

 protected:
  /* Initialize member fields based on an item table entry.
     This one cannot be called from a constructor. */
  virtual int	ChangeItemType (table_entry_t);

  /* Read class-specific fields from the item data bit stream.
     Called by d2sExtendedItem after reading the quality fields
     and before reading the magic properties. */
  virtual int	ReadItemSpecificData (struct bit_stream *);

  /* Write class-specific fields to the item data bit stream.
     Called by d2sExtendedItem after writing the quality fields
     and before writing the magic properties. */
  virtual int	WriteItemSpecificData (struct bit_stream *);

  weapon_class_t weapon_class;	// axe, bow, sword, etc.
  int16_t	base_attack_speed;
  /* I've never seen a weapon with more than 7 bits of damage (that
     would be the Ancient Axe), but just in case, we'll allocate 15
     bits.  If a weapon's damage entry is 0, the weapon cannot be used
     in that form (i.e., if the one-hand and throw damage are 0 but
     the two-hand damage is non-zero, the item requires both hands.)
     We Store both the base (before enhancements) and current (after)
     amount of damage inflicted.  The base is looked up from the
     item tables. */
  short damage[2][2];
  /* Certain weapon classes have an inherent amount of additional
     damage to the undead.  This includes all maces, and all general
     staves (but NOT orbs, even though they're called staff). */
  int		base_damage_to_undead;

 private:
  /* Initialize this class' member fields based on an item table entry.
     This one may only be called from a constructor. */
  void		SetItemType (table_entry_t);
};


/****************/

/* A stacked weapon is a combination of a stack and a weapon.
   A true test of multiple inheritance in C++! */
class d2sStackedWeaponItem : public d2sStackItem, public d2sWeaponItem {
 public:

  /* Create a new, blank stacked weapon (to be filled in later) */
  d2sStackedWeaponItem (void);

  /* Create a new, specific stacked weapon as described by
     the weapon table entry (using default variable attributes) */
  d2sStackedWeaponItem (table_entry_t);

  /* Copy an existing stacked weapon */
  d2sStackedWeaponItem (const d2sStackedWeaponItem &);

  /* Create and return a copy of this stacked weapon. */
  virtual d2sItem *Copy (void) const;

  /* Create a weapon by filling in data from a file.
     (This simply calls d2sDurableItem::Read,
     then does a check against our data type) */
  virtual int Read (struct data_stream *);

  /* Stacked weapons add their quality, damage, quantity,
     requirements, speed, and magic properties to the descrption. */
  virtual char *FullDescription (void) const;

 protected:
  /* Read class-specific fields from the item data bit stream.
     Called by d2sExtendedItem after reading the quality fields
     and before reading the magic properties. */
  virtual int	ReadItemSpecificData (struct bit_stream *);

  /* Write class-specific fields to the item data bit stream.
     Called by d2sExtendedItem after writing the quality fields
     and before writing the magic properties. */
  virtual int	WriteItemSpecificData (struct bit_stream *);

  /* Unless I am mistaken, all throwable weapons are one-handed.  Thus
     the throw damage can take the place of the two-hand damage entry. */
#define THROW_DAMAGE	1
};

#endif /* D2SITEM_H */
