/* d2sMagic -- C++ classes that hold an internal representation
 *	       of magical properties in Diablo II v1.09 items.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "define.h"
#include "functions.h"
#include "options.h"
#include "internal.h"
#include "util.h"
#include "d2sMagic.h"
#include "d2sData.h"
#include "d2sItem.h"
#include <dmalloc.h>

/******************** FUNCTION DECLARATIONS *********************/

static int search_func (const void *key, const void *p);

/* Functions that format a magic property into a full description.
   All must have the same prototype:
   char *FUNC (d2sMagicProperty *prop); */
static char *disp_simple (const d2sMagicProperty *);
static char *disp_boolean (const d2sMagicProperty *);
static char *disp_add_range (const d2sMagicProperty *);
static char *disp_check_sign (const d2sMagicProperty *);
static char *disp_poison_damage (const d2sMagicProperty *);
static char *disp_duration (const d2sMagicProperty *);
static char *disp_skill_up (const d2sMagicProperty *);
static char *disp_skill_set_up (const d2sMagicProperty *);
static char *disp_halves (const d2sMagicProperty *);
static char *disp_eighths (const d2sMagicProperty *);
static char *disp_frequency (const d2sMagicProperty *);
static char *disp_cast_spell (const d2sMagicProperty *);
static char *disp_charged_spell (const d2sMagicProperty *);
static char *disp_per_time (const d2sMagicProperty *);
static char *disp_color (const d2sMagicProperty *);

/* Functions that convert property parameters (found in internal tables)
   to data fields.  All must have the same prototype:
   void FUNC (int param, int pmin, int pmax,
	      int bias, uint16_t *field_values); */
static void param_boolean (int, int, int, int, uint16_t *);
static void param_min_max (int, int, int, int, uint16_t *);
static void param_min_max_dur (int, int, int, int, uint16_t *);
static void param_skill_level (int, int, int, int, uint16_t *);
static void param_skill_chance_level (int, int, int, int, uint16_t *);
static void param_charged_spell (int, int, int, int, uint16_t *);
static void param_per_time (int, int, int, int, uint16_t *);
static void param_param (int, int, int, int, uint16_t *);

/* Functions that convert raw field data to a string.
   All must have the same prototype: char *FUNC (int data, int bias); */
static char *dtv_integer (int, int);
static char *dtv_duration (int, int);
static char *dtv_poison_damage (int, int);
static char *dtv_skill (int, int);
static char *dtv_skill_set (int, int);
static char *dtv_halves (int, int);
static char *dtv_eighths (int, int);
static char *dtv_frequency (int, int);
static char *dtv_time_of_day (int, int);
static char *dtv_color (int, int);

/* Functions that convert a string representation to raw field data.
   All must have the same prototype: int FUNC (const char *value, int bias); */
static int vtd_integer (const char *, int);
static int vtd_duration (const char *, int);
static int vtd_poison_damage (const char *, int);
static int vtd_skill (const char *, int);
static int vtd_skill_set (const char *, int);
static int vtd_halves (const char *, int);
static int vtd_eighths (const char *, int);
static int vtd_frequency (const char *, int);
static int vtd_time_of_day (const char *, int);
static int vtd_color (const char *, int);

/* Functions that check the range of raw field data to make sure it's valid.
   All must have the same prototype: int FUNC (int data); */
static int test_true (int);	/* Always succeeds */
static int test_boolean (int);	/* Succeeds if the value is True (1) */
static int test_non_zero (int); /* Succeeds if the value is not 0 */
static int test_skill (int);	/* Succeeds if the value is a valid skill ID */
static int test_skill_set (int); /* '' if the value is a valid skill set # */

/* Functions that add two properties of the same type.
   All must have the same prototype:
   int FUNC (uint16_t *data1, uint16_t *data2, int bias); */
static int add_noop (uint16_t *, const uint16_t *, int);
static int add_1field (uint16_t *, const uint16_t *, int);
static int add_2fields (uint16_t *, const uint16_t *, int);
static int add_2ndfield (uint16_t *, const uint16_t *, int);
static int add_2nd3rdfields (uint16_t *, const uint16_t *, int);
static int add_3rdfield (uint16_t *, const uint16_t *, int);
static int add_3rd4thfields (uint16_t *, const uint16_t *, int);


/***************************** DATA *****************************/

/* Table of functions used to display a magic property */
static const struct display_prop_t {
  const char *name;	/* Name of the function, in the properties table */
  char * (*func) (const d2sMagicProperty *);
} display_prop_table[] = {
  /* THIS TABLE MUST BE PRE-SORTED BY NAME for bsearch() */
  { "ADD_RANGE", disp_add_range },
  { "BOOLEAN", disp_boolean },
  { "CAST_SPELL", disp_cast_spell },
  { "CHARGED_SPELL", disp_charged_spell },
  { "CHECK_SIGN", disp_check_sign },
  { "COLOR", disp_color },
  { "DURATION", disp_duration },
  { "EIGHTHS_PER_LEVEL", disp_eighths },
  { "FREQUENCY", disp_frequency },
  { "HALVES_PER_LEVEL", disp_halves },
  { "PER_TIME", disp_per_time },
  { "POISON_DAMAGE", disp_poison_damage },
  { "SIMPLE", disp_simple },
  { "SKILL_SET_UP", disp_skill_set_up },
  { "SKILL_UP", disp_skill_up },
};

/* Table of functions used to convert a parameter set
   (found in internal tables) to data fields. */
static const struct read_parameters_t {
  const char *name;
  void (*func) (int, int, int, int, uint16_t *);
} read_parameters_table[] = {
  /* THIS TABLE MUST BE PRE-SORTED BY NAME for bsearch() */
  { "BOOLEAN", param_boolean },
  { "CHARGED_SPELL", param_charged_spell },
  { "MIN_MAX", param_min_max },
  { "MIN_MAX_DUR", param_min_max_dur },
  { "PARAM", param_param },
  { "PER_TIME", param_per_time },
  { "SKILL_CHANCE_LEVEL", param_skill_chance_level },
  { "SKILL_LEVEL", param_skill_level },
};

/* Table of functions used to convert raw field data
   to a string representation, and vice-versa. */
static const struct convert_data_t {
  const char *name;	/* Name of the function, in the properties table */
  char * (*to_value_func) (int raw_data, int bias);
  int (*from_value_func) (const char *value, int bias);
} convert_data_table[] = {
  /* THIS TABLE MUST BE PRE-SORTED BY NAME for bsearch() */
  { "COLOR", dtv_color, vtd_color },
  { "DURATION", dtv_duration, vtd_duration },
  { "EIGHTHS", dtv_eighths, vtd_eighths },
  { "FREQUENCY", dtv_frequency, vtd_frequency },
  { "HALVES", dtv_halves, vtd_halves },
  { "INTEGER", dtv_integer, vtd_integer },
  { "POISON_DAMAGE", dtv_poison_damage, vtd_poison_damage },
  { "SKILL", dtv_skill, vtd_skill },
  { "SKILL_SET", dtv_skill_set, vtd_skill_set },
  { "TIME_OF_DAY", dtv_time_of_day, vtd_time_of_day },
};

/* Table of functions that check the range of raw field data. */
static const struct test_raw_data_t {
  const char *name;	/* Name of the function, in the properties table */
  int (*func) (int data);
} test_raw_data_table[] = {
  /* THIS TABLE MUST BE PRE-SORTED BY NAME for bsearch() */
  { "BOOLEAN", test_boolean },
  { "NON_ZERO", test_non_zero },
  { "SKILL", test_skill },
  { "SKILL_SET", test_skill_set },
  { "TRUE", test_true },
};

/* Table of functions that add two properties of the same type. */
static const struct add_data_t {
  const char *name;	/* Name of the function, in the properties table */
  int (*func) (uint16_t *data1, const uint16_t *data2, int bias);
} add_data_table[] = {
  /* THIS TABLE MUST BE PRE-SORTED BY NAME for bsearch() */
  { "1FIELD", add_1field },
  { "2FIELDS", add_2fields },
  { "2ND3RDFIELDS", add_2nd3rdfields },
  { "2NDFIELD", add_2ndfield },
  { "3RDFIELD", add_3rdfield },
  { "3RD4THFIELDS", add_3rd4thfields },
  { "NOOP", add_noop },
};


/************************** FUNCTIONS ***************************/

/* Called by bsearch() to find a function */
static int
search_func (const void *key, const void *p)
{
  /* In all tables, the first member is a pointer to the function name.
     So we can simply cast P to a pointer to the string pointer. */
  return strcmp ((const char *) key, *((const char **) p));
}


/* Return a dynamically-allocated string with a complete description
   of a given magical property. */
static char *
disp_simple (const d2sMagicProperty *prop)
{
  int len;
  const char *fmt;
  char *ret_str;
  /* There is only one integer field (worth showing),
     and it is well- placed in the format string. */

  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  /* 12 characters should be enough to add any integer
     (10 digits max) plus a null terminator. */
  len = strlen (fmt) + 12;
  ret_str = (char *) xmalloc (len);
  /* This display type is used by biased properties */
  snprintf (ret_str, len, fmt, prop->FieldData (0) - prop->Bias());
  return ret_str;
}

static char *
disp_boolean (const d2sMagicProperty *prop)
{
  /* We don't display any field values; just a description.
     Even more simple than disp_simple()! */
  return xstrdup (GetEntryStringField (prop->TableEntry(), "fmtString1"));
}

static char *
disp_add_range (const d2sMagicProperty *prop)
{
  int len, min, max;
  const char *fmt;
  char *ret_str;
  /* There are two integer fields representing the minimum and maximum
     of a range.  Typically used for displaying elemental damage.
     If the fields are the same, we display the first format string.
     If different, we display the second. */

  min = prop->FieldData (0);
  max = prop->FieldData (1);
  if (min == max) {
    fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
    len = strlen (fmt) + 12;
  } else {
    fmt = GetEntryStringField (prop->TableEntry(), "fmtString2");
    len = strlen (fmt) + 24;
  }
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, min, max);
  return ret_str;
}

static char *
disp_check_sign (const d2sMagicProperty *prop)
{
  int len, value;
  const char *fmt;
  char *ret_str;
  /* Like disp_simple, but choose one of two formats
     depending on the sign of the value. */

  value = prop->FieldData (0) - prop->Bias();
  fmt = GetEntryStringField (prop->TableEntry(),
			     (value >= 0) ? "fmtString1" : "fmtString2");
  /* 12 characters should be enough to add any integer
     (10 digits max) plus a null terminator. */
  len = strlen (fmt) + 12;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, value);
  return ret_str;
}

static char *
disp_duration (const d2sMagicProperty *prop)
{
  int len, duration;
  const char *fmt;
  char *ret_str;
  /* There is one field, which is a duration in 25ths of a second.
     It is to be displayed in seconds. */

  duration = prop->FieldData (0);
  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  len = strlen (fmt) + 12;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, (double) duration / 25.0);
  return ret_str;
}

static char *
disp_poison_damage (const d2sMagicProperty *prop)
{
  int len, min, max, dur;
  const char *fmt;
  char *ret_str;
  /* There are three fields.  The first two represent the minimum
     and maximum of a range, expressed in 256ths per 25th of a second.
     The third represents the duration in 25ths of a second.
     If the first two fields are the same, we display the first
     format string.  If different, we display the second. */

  min = prop->FieldData (0);
  max = prop->FieldData (1);
  dur = prop->FieldData (2);
  if (min == max) {
    fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
    len = strlen (fmt) + 24;
    ret_str = (char *) xmalloc (len);
    snprintf (ret_str, len, fmt, (int) rint ((double) min * dur / 256.0),
	      (int) rint (dur / 25.0));
  } else {
    fmt = GetEntryStringField (prop->TableEntry(), "fmtString2");
    len = strlen (fmt) + 36;
    ret_str = (char *) xmalloc (len);
    snprintf (ret_str, len, fmt, (int) rint ((double) min * dur / 256.0),
	      (int) rint ((double) max * dur / 256.0),
	      (int) rint (dur / 25.0));
  }
  return ret_str;
}

static char *
disp_skill_up (const d2sMagicProperty *prop)
{
  int len, skill, cls, level;
  const char *fmt, *skill_name, *class_name;
  char *ret_str;
  /* There are two fields: a skill and a level.  The level is printed
     first, followed by the skill name, followed by the name of the
     character class to which the skill belongs. */

  skill = prop->FieldData (0);
  level = prop->FieldData (1);
  cls = CharacterClassOfSkill (skill);

  skill_name = SkillName (skill);
  if (cls < 0)
    class_name = "???";
  else
    class_name = GetCharacterClassName (cls);

  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  len = strlen (fmt) + 12 + strlen (skill_name) + strlen (class_name);
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, level, skill_name, class_name);
  return ret_str;
}

static char *
disp_skill_set_up (const d2sMagicProperty *prop)
{
  int len, skill_set, char_class, level;
  table_entry_t class_entry;
  char field_name[8] = "ModStr1";
  const char *fmt, *mod_str, *skill_set_name, *class_name;
  char *ret_str;
  /* There are two fields: a skill set and a level.  The level is
     printed first, followed by the skill set name, followed by the
     name of the character class to which the skill set belongs. */

  /* Rather that the actual skill set name, these descriptions use
     a modified version of the name.  We copy the entry in the string
     table, referenced by entries put in our custom playerclass table. */
  skill_set = prop->FieldData (0);
  level = prop->FieldData (1);
  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");

  if ((unsigned) skill_set >= NUM_CHAR_CLASSES * NUM_SKILL_SETS)
    {
      len = strlen (fmt) + 16;
      ret_str = (char *) xmalloc (len);
      snprintf (ret_str, len, fmt, level, " to ??? Skills", "???");
      return ret_str;
    }

  char_class = skill_set / NUM_SKILL_SETS;
  skill_set = skill_set % NUM_SKILL_SETS;
  class_entry = LookupIndexedTableEntry ("playerclass", char_class);
  field_name[6] = (char) ('1' + skill_set);

  class_name = GetCharacterClassName (char_class);
  mod_str = GetEntryStringField (class_entry, field_name);
  skill_set_name = LookupStringByKey (mod_str);

  if (skill_set_name == NULL)
    {
      len = (sizeof ("+%d to Skill Set %d (%s Only)") + 24
	     + strlen (class_name));
      ret_str = (char *) xmalloc (len);
      snprintf (ret_str, len, "+%d to Skill Set %d (%s Only)",
		level, skill_set, class_name);
    }
  else
    {
      len = strlen (fmt) + 12 + strlen (skill_set_name) + strlen (class_name);
      ret_str = (char *) xmalloc (len);
      snprintf (ret_str, len, fmt, level, skill_set_name, class_name);
    }
  return ret_str;
}

static char *
disp_halves (const d2sMagicProperty *prop)
{
  int len, halves, level = 1;
  const char *fmt;
  char *ret_str;
  /* There is one field, which is given in halves.
     It is to be multiplied by the character's level. */

  halves = prop->FieldData (0);
  if ((prop->ParentList() != NULL) && (prop->ParentList()->Item() != NULL)
      && (prop->ParentList()->Item()->Owner() != NULL))
    level = prop->ParentList()->Item()->Owner()->GetCharacterLevel();
  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  len = strlen (fmt) + 12;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, halves * level / 2);
  return ret_str;
}

static char *
disp_eighths (const d2sMagicProperty *prop)
{
  int len, eighths, level = 1;
  const char *fmt;
  char *ret_str;
  /* There is one field, which is given in eighths.
     It is to be multiplied by the character's level. */

  eighths = prop->FieldData (0);
  if ((prop->ParentList() != NULL) && (prop->ParentList()->Item() != NULL)
      && (prop->ParentList()->Item()->Owner() != NULL))
    level = prop->ParentList()->Item()->Owner()->GetCharacterLevel();
  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  len = strlen (fmt) + 12;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, eighths * level / 8);
  return ret_str;
}

static char *
disp_frequency (const d2sMagicProperty *prop)
{
  int len, freq;
  const char *fmt;
  char *ret_str;
  /* There is one field, which is a freqency in units per 100 seconds.
     It is to be displayed as a period in seconds. */

  freq = prop->FieldData (0);
  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  len = strlen (fmt) + 12;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt,
	    /* Be sure to prevent divide-by-zero here */
	    freq ? ((100 + freq / 2) / freq) : 0x3fffffffL);
  return ret_str;
}

static char *
disp_cast_spell (const d2sMagicProperty *prop)
{
  int len, skill, level, chance;
  const char *fmt, *skill_name;
  char *ret_str;
  /* This has three fields: a skill, a level, and a probability.
     They are displayed in reverse order. */

  skill = prop->FieldData (0);
  level = prop->FieldData (1);
  chance = prop->FieldData (2);
  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  skill_name = SkillName (skill);
  len = strlen (fmt) + 24 + strlen (skill_name);
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, chance, level, skill_name);
  return ret_str;
}

static char *
disp_charged_spell (const d2sMagicProperty *prop)
{
  int len, skill, level, cur_charges, max_charges;
  const char *fmt, *skill_name;
  char *ret_str;
  /* This has four fields: a skill, a level, and current/maximum charges.
     The level is displayed first, followed by the rest. */

  skill = prop->FieldData (0);
  level = prop->FieldData (1);
  cur_charges = prop->FieldData (2);
  max_charges = prop->FieldData (3);
  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  skill_name = SkillName (skill);
  len = strlen (fmt) + 36 + strlen (skill_name);
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, level, skill_name, cur_charges, max_charges);
  return ret_str;
}

static char *
disp_per_time (const d2sMagicProperty *prop)
{
  int len, time_code, min, max;
  const char *fmt, *time_name;
  char *ret_str;
  /* This has three fields: a time of day, and maximum/minimum values.
     The values are displayed first, followed by the time. */

  time_code = prop->FieldData (0);
  min = prop->FieldData (1) - prop->Bias();
  max = prop->FieldData (2) - prop->Bias();
  /* Sign-extend the minimum/maximum fields */
  if (min & (1 << (prop->FieldBits(1) - 1)))
    min |= -(1 << prop->FieldBits(1));
  if (max & (1 << (prop->FieldBits(2) - 1)))
    max |= -(1 << prop->FieldBits(2));
  fmt = GetEntryStringField (prop->TableEntry(), "fmtString2");
  time_name = TimeName (time_code);
  len = strlen (fmt) + 24 + strlen (time_name);
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, min, max, time_name);
  return ret_str;
}

static char *
disp_color (const d2sMagicProperty *prop)
{
  int len, color_code;
  const char *fmt, *color_name;
  char *ret_str;

  color_code = prop->FieldData (0);
  color_name = GetEntryStringField
    (LookupIndexedTableEntry ("colors", color_code), "Transform Color");

  fmt = GetEntryStringField (prop->TableEntry(), "fmtString1");
  len = strlen (fmt) + strlen (color_name) + 2;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, fmt, color_name);
  return ret_str;
}

/* Convert property parameters (found in internal tables) to data fields. */
static void
param_boolean (int mod_param, int mod_min, int mod_max, int bias,
	       uint16_t *field_values)
{
  /* There are no parameters given for this property. */
  field_values[0] = True;
}

static void
param_min_max (int mod_param, int mod_min, int mod_max, int bias,
	       uint16_t *field_values)
{
  /* The parameters for this property are minimum and maximum values,
     stored in the first two fields.  This is used for damage-type
     properties, as well as partial properties which define a range
     (as in for a magic prefix/suffix). */
  field_values[0] = (uint16_t) (mod_min + bias);
  field_values[1] = (uint16_t) (mod_max + bias);
}

static void
param_min_max_dur (int mod_param, int mod_min, int mod_max, int bias,
		   uint16_t *field_values)
{
  /* The parameters for this property are a duration (given in 25ths
     of a second) and minimum + maximum values.  The duration is
     stored last. */
  field_values[0] = (uint16_t) mod_min;
  field_values[1] = (uint16_t) mod_max;
  field_values[2] = (uint16_t) mod_param;
}

static void
param_skill_level (int mod_param, int mod_min, int mod_max, int bias,
		   uint16_t *field_values)
{
  /* The parameters for this property are a skill ID and level
     (the min and max values should be the same). */
  field_values[0] = (uint16_t) mod_param;
  if (mod_min == mod_max) {
    if (mod_min) {
      field_values[1] = (uint16_t) mod_min;
      field_values[2] = (uint16_t) mod_max;
    } else {
      field_values[1] = (uint16_t) (rand() % 10 + 1);
      field_values[2] = field_values[1];
    }
  } else {
    if (!mod_min)
      mod_min++;
    field_values[1] = (uint16_t) (mod_min + rand() % (mod_max - mod_min + 1));
    field_values[2] = field_values[1];
  }
}

static void
param_skill_chance_level (int mod_param, int mod_min, int mod_max, int bias,
			  uint16_t *field_values)
{
  /* The parameters for this property are a skill ID, level,
     and chance to cast. */
  field_values[0] = (uint16_t) mod_param;
  /* Note: It appears that if the level in the data tables is 0,
     the level used is a random value from 1-10.
     See 'The Rising Sun' unique amulet. */
  if (mod_max)
    field_values[1] = (uint16_t) mod_max;
  else
    field_values[1] = (uint16_t) (rand() % 10 + 1);
  field_values[2] = (uint16_t) mod_min;
}

static void
param_charged_spell (int mod_param, int mod_min, int mod_max, int bias,
		     uint16_t *field_values)
{
  /* The parameters for this property are a skill ID, charges, and level. */
  field_values[0] = (uint16_t) mod_param;
  /* GUESS: Negative values for level implies a random selection */
  if (mod_max < 0)
    mod_max = rand() % -mod_max + 1;
  else if (!mod_max)
    mod_max = rand() % 10 + 1;
  field_values[1] = (uint16_t) mod_max;
  /* GUESS: Negative values for charges implies a random selection */
  if (mod_min < 0)
    mod_min = rand() % -mod_min + 1;
  else if (!mod_min)
    mod_min = rand() % 100 + 1;
  field_values[2] = (uint16_t) mod_min;
  field_values[3] = (uint16_t) mod_min;
}

static void
param_per_time (int mod_param, int mod_min, int mod_max, int bias,
		uint16_t *field_values)
{
  /* The parameters for this property are a time of day
     and minimum + maximum values. */
  field_values[0] = (uint16_t) mod_param;
  field_values[1] = (uint16_t) (mod_min + bias);
  field_values[2] = (uint16_t) (mod_max + bias);
}

static void
param_param (int mod_param, int mod_min, int mod_max, int bias,
	     uint16_t *field_values)
{
  /* There is only one parameter for this property. */
  field_values[0] = (uint16_t) mod_param;
}


/* Convert raw field data to a string. */
static char *
dtv_integer (int data, int bias)
{
  char *ret_str;
  /* Very simple; just print the number in decimal,
     after subtracting an optional bias. */
  ret_str = (char *) xmalloc (12);
  sprintf (ret_str, "%d", data - bias);
  return ret_str;
}

static char *
dtv_duration (int data, int bias)
{
  char *ret_str;
  /* Durations are given in 25ths of a second.  Need floating-point. */
  ret_str = (char *) xmalloc (12);
  snprintf (ret_str, 12, "%g", (double) data / 25.0);
  return ret_str;
}

static char *
dtv_poison_damage (int data, int bias)
{
  char *ret_str;
  /* Poison damage is given in 256ths of a damage point per 25th of a second.
     Need to convert (in floating-point) to damage points per second. */
  ret_str = (char *) xmalloc (12);
  sprintf (ret_str, "%g", (double) data * 25.0 / 256.0);
  return ret_str;
}

static char *
dtv_skill (int data, int bias)
{
  const char *skill_name;
  /* Remember that we need to return a dynamically allocated string.
     Copy the skill name. */
  skill_name = SkillName (data);
  if ((skill_name == NULL) || (skill_name[0] == 0))
    skill_name = "INVALID DATA";
  return xstrdup (skill_name);
}

static char *
dtv_skill_set (int data, int bias)
{
  int char_class, skill_set;
  const char *skill_set_name;

  /* Remember that we need to return a dynamically allocated string.
     Copy the skill set name (unlike the display version). */
  char_class = data / NUM_SKILL_SETS;
  skill_set = data % NUM_SKILL_SETS;
  skill_set_name = SkillSetName (char_class, skill_set);
  if ((skill_set_name == NULL) || (skill_set_name[0] == 0))
    skill_set_name = "INVALID DATA";
  return xstrdup (skill_set_name);
}

static char *
dtv_halves (int data, int bias)
{
  char *ret_str;

  ret_str = (char *) xmalloc (12);
  snprintf (ret_str, 12, "%g", data / 2.0);
  return ret_str;
}

static char *
dtv_eighths (int data, int bias)
{
  char *ret_str;

  ret_str = (char *) xmalloc (12);
  snprintf (ret_str, 12, "%g", data / 8.0);
  return ret_str;
}

static char *
dtv_frequency (int data, int bias)
{
  char *ret_str;
  /* Frequencies are given in cycles per 100 seconds.
     Must convert to a period in seconds.  Probably need floating-point. */
  ret_str = (char *) xmalloc (12);
  snprintf (ret_str, 12, "%g", 100.0 / data);
  return ret_str;
}

static const char * const time_of_day_strings[] = {
  "During Daytime", "Near Dusk", "During Nighttime", "Near Dawn"
};

static char *
dtv_time_of_day (int data, int bias)
{
  if ((unsigned) data >= XtNumber (time_of_day_strings))
    return xstrdup ("INVALID DATA");
  return xstrdup (time_of_day_strings[data]);
}

static char *
dtv_color (int data, int bias)
{
  if ((unsigned) data >= (unsigned) GetTableSize ("colors"))
    return xstrdup ("INVALID DATA");
  return xstrdup
    (GetEntryStringField (LookupIndexedTableEntry ("colors", data),
			  "Transform Color"));
}


/* Convert a string representation to raw field data. */
static int
vtd_integer (const char *value, int bias)
{
  int data;
  char *endp;
  /* Simply read the number as an integer,
     and optionally add a bias. */
  errno = 0;
  data = strtol (value, &endp, 10) + bias;
  if (*endp || errno)
    /* Either it was a bad number, there was junk at the end,
       or the number overflowed.  Return an error condition. */
    return -1;
  return data;
}

static int
vtd_duration (const char *value, int bias)
{
  double data;
  char *endp;
  /* Durations are given in 25ths of a second.  Need floating-point. */
  data = strtod (value, &endp);
  if (*endp || errno)
    /* Either it was a bad number or there was junk at the end.
       Return an error condition. */
    return -1;
  data = rint (data * 25.0);
  /* Constrain the result to a non-negative 16-bit integer. */
  if ((data < 0.0) || (data >= (double) 0x10000))
    return -1;
  return (int) data;
}

static int
vtd_poison_damage (const char *value, int bias)
{
  double data;
  char *endp;
  /* Poison damage is given in 256ths of a damage point per 25th of a second.
     Need to convert (in floating-point) from damage points per second. */
  data = strtod (value, &endp);
  if (*endp || errno)
    /* Either it was a bad number or there was junk at the end.
       Return an error condition. */
    return -1;
  data = rint (data * 256.0 / 25.0);
  /* Constrain the result to a non-negative 16-bit integer. */
  if ((data < 0.0) || (data >= (double) 0x10000))
    return -1;
  return (int) data;
}

static int
vtd_skill (const char *value, int bias)
{
  int skill, last_std_skill, first_exp_skill, last_exp_skill;
  /* WARNING: THIS FUNCTION SHOULD NOT BE USED.
     Search for a skill by name and return its ID.
     THIS WILL NOT WORK IF TWO SKILLS HAVE THE SAME NAME.
     (Fortunately, I've searched the string table
      and it appears that all skill names are unique.)
     It's also slow. */
  /* Get the skill ID limits.  There is a discontinuity between
     standard skills and expansion skills we need to watch for. */
  last_std_skill = FirstSkillOfClass (4) + NUM_SKILLS_PER_CHAR;
  first_exp_skill = FirstSkillOfClass (5);
  last_exp_skill = (FirstSkillOfClass (NUM_CHAR_CLASSES - 1)
		    + NUM_SKILLS_PER_CHAR);
  for (skill = 0; skill < last_exp_skill; skill++)
    {
      if (skill == last_std_skill)
	skill = first_exp_skill;
      if (strcasecmp (SkillName (skill), value) == 0)
	/* We have a match! */
	return skill;
    }
  /* No match. */
  return -1;
}

static int
vtd_skill_set (const char *value, int bias)
{
  int char_class, skill_set;
  /* WARNING: THIS FUNCTION SHOULD NOT BE USED.
     Search for a skill set by name and return its ID.
     THIS WILL NOT WORK IF TWO SKILL SETS HAVE THE SAME NAME.
     And it just so happens that both the Barbarian and Paladin
     have a skill set named "Combat Skills". */
  for (char_class = 0; char_class < NUM_CHAR_CLASSES; char_class++)
    for (skill_set = 0; skill_set < NUM_SKILL_SETS; skill_set++)
      {
	if (strcasecmp (SkillSetName (char_class, skill_set), value) == 0)
	  /* We have a match! */
	  return (char_class * NUM_SKILL_SETS + skill_set);
      }
  /* No match. */
  return -1;
}

static int
vtd_halves (const char *value, int bias)
{
  double data;
  char *endp;

  data = strtod (value, &endp);
  if (*endp || errno)
    /* Either it was a bad number or there was junk at the end.
       Return an error condition. */
    return -1;
  data = rint (data * 2.0);
  /* Constrain the result to a non-negative 16-bit integer. */
  if ((data < 0.0) || (data >= (double) 0x10000))
    return -1;
  return (int) data;
}

static int
vtd_eighths (const char *value, int bias)
{
  double data;
  char *endp;

  data = strtod (value, &endp);
  if (*endp || errno)
    /* Either it was a bad number or there was junk at the end.
       Return an error condition. */
    return -1;
  data = rint (data * 8.0);
  /* Constrain the result to a non-negative 16-bit integer. */
  if ((data < 0.0) || (data >= (double) 0x10000))
    return -1;
  return (int) data;
}

static int
vtd_frequency (const char *value, int bias)
{
  double data;
  char *endp;
  /* Frequencies are given in cycles per 100 seconds.  Need floating-point. */
  data = strtod (value, &endp);
  if (*endp || errno)
    /* Either it was a bad number or there was junk at the end.
       Return an error condition. */
    return -1;
  data = rint (100.0 / data);
  /* Constrain the result to a non-negative 16-bit integer. */
  if ((data < 0.0) || (data >= (double) 0x10000))
    return -1;
  return (int) data;
}

static int
vtd_time_of_day (const char *value, int bias)
{
  int data;
  const char *short_name;
  /* Search for a time of day by name and return its code. */
  for (data = 0; data < (int) XtNumber (time_of_day_strings); data++)
    {
      if (strcasecmp (time_of_day_strings[data], value) == 0)
	/* We have a match! */
	return data;
      /* Because we have so few choices (four), we can implement a
	 sort of fuzzy comparison.  If there is no space in the given
	 value, compare the first three characters to the second word
	 in the official names.  Sufficient to distinguish "Day" from
	 "Dawn". */
      if (strchr (value, ' ') == NULL) {
	short_name = strchr (time_of_day_strings[data], ' ');
	if (short_name != NULL) {
	  if (strncasecmp (&short_name[1], value, 3) == 0)
	    /* Fuzzy match! */
	    return data;
	}
      }
    }
  /* No match. */
  return -1;
}

static int
vtd_color (const char *value, int bias)
{
  int ncolors;
  table_entry_t centry;

  ncolors = GetTableSize ("colors");
  /* Search for a color by name and return its code. */
  centry = LookupTableEntry ("colors", "Transform Color", value);
  if (centry == NULL)
    /* No match */
    return -1;
  return GetEntryIntegerField (centry, NULL);
}


/* Check the range of raw field data to make sure it's valid. */
static int
test_true (int data)
{
  /* Always succeeds */
  return True;
}

static int
test_boolean (int data)
{
  /* Succeeds if the value is True (1) */
  return (data == 1);
}

static int
test_non_zero (int data)
{
  /* Succeeds if the value is not 0 */
  return (data != 0);
}

static int
test_skill (int data)
{
  int char_class, first;
  /* Succeeds if the value is a valid skill ID */
  for (char_class = 0; char_class < NUM_CHAR_CLASSES; char_class++)
    {
      first = FirstSkillOfClass (char_class);
      if ((data >= first) && (data < first + NUM_SKILLS_PER_CHAR))
	return True;
    }
  return False;
}

static int
test_skill_set (int data)
{
  /* Succeeds if the value is a valid skill set ID */
  return ((unsigned) data < NUM_CHAR_CLASSES * NUM_SKILL_SETS);
}


/* Add two properties of the same type. */
static int
add_noop (uint16_t *data1, const uint16_t *data2, int bias)
{
  /* Nothing changed.  (Normally used for boolean properties) */
  return 0;
}

static int
add_1field (uint16_t *data1, const uint16_t *data2, int bias)
{
  /* Add the first (only?) field.  Adjust for bias. */
  data1[0] += data2[0] - bias;
  return 0;
}

static int
add_2fields (uint16_t *data1, const uint16_t *data2, int bias)
{
  /* Add the first and second fields. */
  data1[0] += data2[0];
  data1[1] += data2[1];
  return 0;
}

static int
add_2ndfield (uint16_t *data1, const uint16_t *data2, int bias)
{
  /* Add the second field, but only if the first fields are the same. */
  if (data1[0] != data2[0])
    return -1;
  data1[1] += data2[1];
  return 0;
}

static int
add_2nd3rdfields (uint16_t *data1, const uint16_t *data2, int bias)
{
  /* Add the second and third fields,
     but only if the first fields are the same. */
  if (data1[0] != data2[0])
    return -1;
  data1[1] += data2[1];
  data1[2] += data2[2];
  return 0;
}

static int
add_3rdfield (uint16_t *data1, const uint16_t *data2, int bias)
{
  /* Add the third field, but only if the first two fields are the same. */
  if ((data1[0] != data2[0]) || (data1[1] != data2[1]))
    return -1;
  data1[2] += data2[2];
  return 0;
}

static int
add_3rd4thfields (uint16_t *data1, const uint16_t *data2, int bias)
{
  /* Add the third and fourth fields,
     but only if the first two fields are the same. */
  if ((data1[0] != data2[0]) || (data1[1] != data2[1]))
    return -1;
  data1[2] += data2[2];
  data1[3] += data2[3];
  return 0;
}


/* Sort two properties */
static int
sort_by_id (const void *p1, const void *p2)
{
  d2sMagicProperty *mp1 = *((d2sMagicProperty **) p1);
  d2sMagicProperty *mp2 = *((d2sMagicProperty **) p2);

  return (mp1->ID() - mp2->ID());
}

/* Return a dynamic list of magic properties.
   Omit properties which are already in a given list. */
StringList
GetMagicPropertyNamesExcept (d2sMagic *omit, int expansion,
			     const char *class_restriction)
{
  StringList	names = NULL;
  table_entry_t prop_entry;
  int		row, nrows;
  int		property_id, last_id = -1;
  int		stack_id, last_stack = 0;
  const char	*cstr;

  /* Initialize the StringList */
  nrows = GetTableSize ("properties");
  names = (StringList) xmalloc
    (sizeof (_StringList) + nrows + sizeof (_StringListEntry));
  names->count = 0;

  /* Go through the properties table by property ID.
     We have to make sure we don't count duplicates. */
  for (row = 0; row < nrows; row++)
    {
      prop_entry = LookupIndexedTableEntry ("properties", row);
      if (GetEntryStringField (prop_entry, "Id")[0] == 0)
	continue;
      property_id = GetEntryIntegerField (prop_entry, "Id");
      if (property_id == last_id)
	continue;
      if (property_id == END_OF_LIST_MARKER)
	break;
      last_id = property_id;

      /* Check for expansion-only properties */
      if (!expansion && (GetEntryIntegerField (prop_entry, "version") >= 100))
	continue;

      /* Check for class restrictions */
      if ((class_restriction != NULL) && class_restriction[0])
	{
	  cstr = GetEntryStringField (prop_entry, "Class");
	  if (cstr[0] && (strcmp (class_restriction, cstr) != 0))
	    continue;
	}

      /* See if this property is already in the given property list */
      if ((omit != NULL) && (omit->Lookup (property_id) != NULL))
	continue;

      /* If this is a stacked property, only include the first
	 (available) ID from the stack. */
      stack_id = GetEntryIntegerField (prop_entry, "stackedOn");
      if (stack_id && (stack_id == last_stack))
	continue;
      else
	last_stack = stack_id;

      /* Add this property's description to the StringList */
      names = (StringList) xrealloc
	(names, (sizeof (_StringList)
		 + (names->count + 1) * sizeof (_StringListEntry)));
      names->string[names->count].value = property_id;
      names->string[names->count].label
	= GetEntryStringField (prop_entry, "Description");
      names->count++;
    }
  return names;
}


/********************************
 *	 d2sMagicProperty	*
 *	      class		*
 ********************************/

void
d2sMagicProperty::Init (void)
{
  my_list = NULL;
  error_str = NULL;
  /* The default property is the end-of-list */
  property_id = END_OF_LIST_MARKER;
  property_entry = LookupNumericTableEntry ("properties", "Id",
					    END_OF_LIST_MARKER);
  expansion_property = False;
  bias = 0;
  field_count = 0;
  memset (&field_width, 0, sizeof (field_width));
  memset (&field_value, 0, sizeof (field_value));
}

d2sMagicProperty::d2sMagicProperty (void)
{
  Init ();
}

/* This function is called after a new property ID or code has been
   assigned, to update our copy of the bias, field count, and field
   widths. */
void
d2sMagicProperty::UpdatedPropertyID (void)
{
  int field;
  char field_name[8] = "bits1";

  expansion_property = (GetEntryIntegerField
			(property_entry, "version") >= 100);
  bias = GetEntryIntegerField (property_entry, "bias");
  field_count = GetEntryIntegerField (property_entry, "numFields");
  for (field = 0; field < MAX_FIELDS_IN_MAGIC_PROPERTY; field++)
    {
      field_name[4] = (char) ('1' + field);
      field_width[field] = GetEntryIntegerField (property_entry, field_name);
    }
}

/* Create a new magic property using the given ID */
d2sMagicProperty::d2sMagicProperty (int id)
{
  Init ();
  property_id = id;
  /* Find our entry in the properties table */
  property_entry = LookupNumericTableEntry ("properties", "Id", id);
  if (property_entry == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: unknown magic property ID\n"
		 " given to d2sMagicProperty(%d)\n", progname, id);
      error_str = "Unknown magic property ID";
      return;
    }

  /* Update our members that depend on the property */
  UpdatedPropertyID ();
}

/* Create a new magic property using the given code and parameters */
d2sMagicProperty::d2sMagicProperty (const char *code, int mod_param,
				    int mod_min, int mod_max)
{
  struct read_parameters_t *read_parameters;

  /* Initialize the class members */
  Init ();
  /* Find our entry in the properties table */
  property_entry = LookupTableEntry ("properties", "Code", code);
  if (property_entry == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: property \"%s\" not found"
		 " in the properties table.\n", progname, code);
      error_str = "Unknown magic property code";
      /* Just copy the parameters directly, for all the good it will do. */
      field_value[0] = mod_param;
      field_value[1] = mod_min;
      field_value[2] = mod_max;
      return;
    }

  /* Fetch our property ID, if we have one */
  if (GetEntryStringField (property_entry, "Id")[0])
    property_id = GetEntryIntegerField (property_entry, "Id");
  else
    /* If we don't, store -1 */
    property_id = -1;

  /* Update our members that depend on the property */
  UpdatedPropertyID ();

  /* Find the function used to convert the parameters */
  read_parameters = (struct read_parameters_t *) bsearch
    (GetEntryStringField (property_entry, "paramFunc"),
     read_parameters_table, XtNumber (read_parameters_table),
     sizeof (struct read_parameters_t), search_func);
  if (read_parameters == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: property \"%s\" has no paramFunc"
		 " in the properties table.\n", progname, code);
      error_str = "Internal error";
      /* Just copy the parameters directly, for all the good it will do. */
      field_value[0] = mod_param;
      field_value[1] = mod_min;
      field_value[2] = mod_max;
      return;
    }
  read_parameters->func (mod_param, mod_min, mod_max, bias, &field_value[0]);
}

/* Copy an existing property */
d2sMagicProperty::d2sMagicProperty (const d2sMagicProperty& source)
{
  /* We don't copy the owner.  Just the values. */
  my_list = NULL;
  error_str = NULL;
  *this = source;
}

d2sMagicProperty&
d2sMagicProperty::operator= (const d2sMagicProperty& source)
{
  this->property_id = source.property_id;
  this->property_entry = source.property_entry;
  this->expansion_property = source.expansion_property;
  this->bias = source.bias;
  this->field_count = source.field_count;
  memcpy (&this->field_width, &source.field_width, sizeof (field_width));
  memcpy (&this->field_value, &source.field_value, sizeof (field_value));
  return *this;
}

/* Assign a property to a list */
int
d2sMagicProperty::AssignTo (d2sMagic *new_list)
{
  if ((my_list != NULL) && (new_list != NULL))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: attempt to assign magic property"
		 " %p to list %p\n when it is already assigned to list %p\n",
		 progname, this, new_list, my_list);
      return -1;
    }
  my_list = new_list;
  return 0;
}

/* Read a magic property's values from a file */
int
d2sMagicProperty::Read (struct bit_stream *bstream)
{
  int field;

  /* Read the id first */
  property_id = bstream_read_field (bstream, 9);

  /* Find a matching property table entry */
  property_entry = LookupNumericTableEntry ("properties", "Id", property_id);
  if (property_entry == NULL)
    {
      /* Rewind the previous 9 bits */
      bstream->ptr -= 9;
      print_message ("Unknown magic property ID (%d) at bit %lu in %s\n",
		     property_id, bstream->ptr,
		     ((my_list != NULL) && (my_list->Item() != NULL))
		     ? my_list->Item()->Name() : "unassigned item");
      property_id = -1;
      error_str = "Unknown magic property ID";
      return -1;
    }

  /* Update our members that depend on the property */
  UpdatedPropertyID ();

  /* Read the variable bit fields */
  for (field = 0; field < field_count; field++)
    field_value[field] = bstream_read_field (bstream, field_width[field]);

  return 0;
}

/* Write a magic property's values out to a file */
int
d2sMagicProperty::Write (struct bit_stream *bstream)
{
  int field;

  /* If this is not actually a known property, return error. */
  if (property_id < 0)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: d2sMagicProperty::Write()\n"
		 " called for property \"%s\" which has no ID\n",
		 progname, GetEntryStringField (property_entry, "Code"));
      return -1;
    }

  /* Write the id */
  bstream_write_field (bstream, 9, property_id);

  /* Write the variable data fields */
  for (field = 0; field < field_count; field++)
    bstream_write_field (bstream, field_width[field], field_value[field]);

  return 0;
}

/* Return a string describing the property's full set
   of values, as displayed in the game.  String is
   allocated on demand; must be freed. */
char *
d2sMagicProperty::Display (void) const
{
  struct display_prop_t *display_prop;

  /* Find the function used to display this property */
  display_prop = (struct display_prop_t *) bsearch
    (GetEntryStringField (property_entry, "displayFunc"),
     display_prop_table, XtNumber (display_prop_table),
     sizeof (struct display_prop_t), search_func);
  if (display_prop == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: property \"%s\" has no"
		 " displayFunc in the properties table.\n",
		 progname, Code());
      return xstrdup ("");
    }
  return display_prop->func (this);
}

/* Return the description of a particular field */
const char *
d2sMagicProperty::FieldDescription (int n) const
{
  char field_name[8] = "desc1";

  if (n >= field_count)
    /* Error!  Bad field number */
    return "";
  field_name[4] = (char) ('1' + n);
  return GetEntryStringField (property_entry, field_name);
}

/* Return the units of a particular field, if any (empty string if not) */
const char *
d2sMagicProperty::FieldUnits (int n) const
{
  char field_name[8] = "units1";

  if (n >= field_count)
    /* Error!  Bad field number */
    return "";
  field_name[5] = (char) ('1' + n);
  return GetEntryStringField (property_entry, field_name);
}

/* Return a code indicating the data type of a field.
   The codes are: 'b'=boolean (no display), 'i'=int,
   'd'=double, 's'=string (const char *).  Use the result
   to choose which function to use to read a field. */
char
d2sMagicProperty::FieldType (int n) const
{
  char field_name[8] = "type1";

  if ((unsigned) n >= (unsigned) field_count)
    /* Error!  Bad field number */
    return 0;
  field_name[4] = (char) ('1' + n);
  return GetEntryStringField (property_entry, field_name)[0];
}

/* Return a list of strings that are valid for a string field. */
StringList
d2sMagicProperty::FieldStringList (int field) const
{
  char field_name[20] = "convertFieldFunc1";
  const char *conv_func_name, *cstr;
  StringList string_list;
  int i, char_class, num_char_classes, num_colors;
  int class_specific = 0;

  /* Check the field */
  if ((unsigned) field >= (unsigned) field_count)
    /* Error!  Bad field number */
    return NULL;

  /* Find out what our conversion function is */
  field_name[16] = (char) ('1' + field);
  conv_func_name = GetEntryStringField (property_entry, field_name);

  /* Get the number of character classes supported. */
  num_char_classes = NUM_CHAR_CLASSES;
  if ((my_list != NULL) && (my_list->Item() != NULL)) {
    cstr = GetEntryStringField (my_list->Item()->TypeTableEntry(), "Class");
    if (!options.character.link.freeform && cstr[0]) {
      /* Class-specific item; only include skills for that class */
      num_char_classes = 1;
      class_specific = GetEntryIntegerField
	(LookupTableEntry ("playerclass", "Code", cstr), NULL);
    }
    else if ((my_list->Item()->Owner() != NULL)
	     && ! my_list->Item()->Owner()->is_expansion())
      num_char_classes = 5;
  }

  /* We support the following types of string lists:
     skills, skill sets, times, and colors.
     *** New string list types must add code here ****/
  if (strcmp (conv_func_name, "SKILL") == 0) {
    int last, skill;

    /* We know in advance how many entries there will be */
    string_list = (StringList) xmalloc
      (sizeof (_StringList)
       + ((num_char_classes * NUM_SKILLS_PER_CHAR)
	  * sizeof (string_list->string[0])));
    string_list->count = num_char_classes * NUM_SKILLS_PER_CHAR;
    for (i = 0, char_class = 0; char_class < num_char_classes; char_class++) {
      skill = FirstSkillOfClass (char_class + class_specific);
      last = skill + NUM_SKILLS_PER_CHAR;
      for ( ; skill < last; skill++) {
	string_list->string[i].value = skill;
	string_list->string[i].label = SkillName (skill);
	i++;
      }
    }
    return string_list;
  }

  else if (strcmp (conv_func_name, "SKILL_SET") == 0) {
    int skill_set;

    /* We know in advance how many entries there will be */
    string_list = (StringList) xmalloc
      (sizeof (_StringList)
       + ((num_char_classes * NUM_SKILL_SETS)
	  * sizeof (string_list->string[0])));
    string_list->count = num_char_classes * NUM_SKILL_SETS;
    for (i = 0, char_class = 0; char_class < num_char_classes; char_class++)
      for (skill_set = 0; skill_set < NUM_SKILL_SETS; skill_set++) {
	string_list->string[i].value = char_class * NUM_SKILL_SETS + skill_set;
	string_list->string[i].label
	  = SkillSetName (char_class + class_specific, skill_set);
	i++;
      }
    return string_list;
  }

  else if (strcmp (conv_func_name, "TIME_OF_DAY") == 0) {
    /* There are only 4 time divisions */
    string_list = (StringList) xmalloc (sizeof (_StringList)
					+ 4 * sizeof (string_list->string[0]));
    string_list->count = 4;
    for (i = 0; i < 4; i++) {
      string_list->string[i].value = i;
      string_list->string[i].label = TimeName (i);
    }
    return string_list;
  }

  else if (strcmp (conv_func_name, "COLOR") == 0) {
    /* Get the number of colors */
    num_colors = GetTableSize ("colors");
    string_list = (StringList) xmalloc
      (sizeof (_StringList) + num_colors * sizeof (string_list->string[0]));
    string_list->count = num_colors;
    for (i = 0; i < num_colors; i++) {
      string_list->string[i].value = i;
      string_list->string[i].label
	= GetEntryStringField (LookupIndexedTableEntry ("colors", i),
			       "Transform Color");
    }
    return string_list;
  }

  return NULL;
}

/* Return the value of the Nth data field,
   represented as a raw (biased) integer */
int
d2sMagicProperty::FieldData (int n) const
{
  if ((unsigned) n >= (unsigned) field_count)
    /* Error!  Bad field number */
    return 0;
  return field_value[n];
}

/* Return a dynamically allocated string representing the
   (unbiased, converted) value of the Nth data field. */
char *
d2sMagicProperty::FieldValue (int n) const
{
  struct convert_data_t *convert_data;
  char field_name[20] = "convertFieldFunc1";

  if ((unsigned) n >= (unsigned) field_count)
    /* Error!  Bad field number */
    return xstrdup ("");
  /* Find the function used to convert the field */
  field_name[16] = (char) ('1' + n);
  convert_data = (struct convert_data_t *) bsearch
    (GetEntryStringField (property_entry, field_name),
     convert_data_table, XtNumber (convert_data_table),
     sizeof (struct convert_data_t), search_func);
  if (convert_data == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: property \"%s\" has no %s"
		 " in the properties table.\n", progname, Code(), field_name);
      return xstrdup ("");
    }
  return convert_data->to_value_func ((int16_t) field_value[n], bias);
}

/* Return whether the owner of a property is read-only. */
int
d2sMagicProperty::read_only (void) const
{
  return ((my_list != NULL) && my_list->read_only());
}

/* Mark a property as having been changed.
   (We don't track dirt ourselves; just pass it on the the parent.) */
void
d2sMagicProperty::MarkDirty (void)
{
  if (my_list != NULL)
    my_list->MarkDirty ();
}

/* Change the value of a field */
int
d2sMagicProperty::SetFieldData (int field, int data)
{
  if ((unsigned) field >= (unsigned) field_count)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: invalid field number to"
		 "d2sMagicProperty::SetFieldValue(%d,%d);\n"
		 " property \"%s\" has only %d fields\n",
		 progname, field, data, Description(), field_count);
      error_str = "Invalid field number";
      return -1;
    }

  if (((unsigned) data >= (unsigned) (1 << field_width[field]))
      /* Some fields apparently are signed? */
      || (data < -(1 << field_width[field])))
    {
      print_message ("Value %u is out of range for %s (maximum %d)\n",
		     (unsigned) data, FieldDescription (field),
		     (1 << field_width[field]) - 1);
      error_str = "Value out of range";
      return -1;
    }

  if (field_value[field] == data)
    /* Nothing to do */
    return 0;

  /* Are any changes allowed? */
  if (read_only() || !options.item.edit.magic_properties)
    {
      error_str = "You may not edit the magical properties of your items";
      print_message ("You may not edit the magical properties of %s%sitems.",
		     options.item.edit.magic_properties
		     ? my_list->Item()->Owner()->GetCharacterName() : "",
		     options.item.edit.magic_properties ? "'s " : "");
      return -1;
    }

  if (options.item.link.properties_range && (my_list != NULL)
      && (my_list->Item() != NULL)
      && (my_list->Item()->Type() >= UNKNOWN_EXTENDED_ITEM)
      && (((d2sExtendedItem *) *(my_list->Item()))->Quality() != NULL))
    {
      /* TO-DO: we have to look up the magic quality of the item to
	 see whether we are within range. */
      print_message ("Checking the range of magic properties is"
		     " not yet implemented.\n");
    }

  field_value[field] = data;
  MarkDirty ();
  return 0;
}

int
d2sMagicProperty::SetFieldValue (int field, const char *valuestr)
{
  struct convert_data_t *convert_data;
  struct test_raw_data_t *test_raw_data;
  char field_name[20] = "convertFieldFunc1";
  int data;

  if ((unsigned) field >= (unsigned) field_count)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: invalid field number to"
		 "d2sMagicProperty::SetFieldValue(%d,%s);\n"
		 " property \"%s\" has only %d fields\n",
		 progname, field, valuestr, Description(), field_count);
      error_str = "Invalid field number";
      return -1;
    }

  /* Find the function used to convert the field */
  field_name[16] = (char) ('1' + field);
  convert_data = (struct convert_data_t *) bsearch
    (GetEntryStringField (property_entry, field_name),
     convert_data_table, XtNumber (convert_data_table),
     sizeof (struct convert_data_t), search_func);
  if (convert_data == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: property \"%s\" has %s %s"
		 " in the properties table.\n", progname, Code(),
		 GetEntryStringField (property_entry, field_name)[0]
		 ? "an invalid" : "no", field_name);
      error_str = "Internal error";
      return -1;
    }
  data = convert_data->from_value_func (valuestr, bias);
  /* Note that we don't distinguish between bad data and -1.
     We should. */
  if ((data == -1) || (data >= (1 << field_width[field]))
      || (data < -(1 << (field_width[field] - 1))))
    {
      print_message ("\"%s\" is not a valid value for the %s field.",
		     valuestr, FieldDescription (field), data);
      /* If this is an integer field, be helpful by providing the range. */
      if (strcmp (GetEntryStringField (property_entry, field_name),
		  "INTEGER") == 0) {
	print_message ("The range for %s is  [ %d , %d ] .",
		       FieldDescription (field), -bias,
		       (1 << field_width[field]) - bias - 1);
	error_str = "Number out of range";
      } else
	error_str = "Invalid argument";
      return -1;
    }

  /* Find the function used to test the field */
  strcpy (field_name, "verifyFieldFunc1");
  field_name[15] = (char) ('1' + field);
  test_raw_data = (struct test_raw_data_t *) bsearch
    (GetEntryStringField (property_entry, field_name),
     test_raw_data_table, XtNumber (test_raw_data_table),
     sizeof (struct test_raw_data_t), search_func);
  if (test_raw_data == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: property \"%s\" has %s %s"
		 " in the properties table.\n", progname, Code(),
		 GetEntryStringField (property_entry, field_name)[0]
		 ? "an invalid" : "no", field_name);
      /* This is not a fatal error */
    }
  else if ( ! test_raw_data->func (data))
    {
      print_message ("\"%s\" is not a valid value for the %s field.",
		     valuestr, FieldDescription (field), data);
      error_str = "Invalid argument";
      return -1;
    }

  /* Everything checks out so far; the next function will do the
     remainder of the tests and then set the data. */
  return SetFieldData (field, data);
}

/* Change the values of all fields to equal another magic property.
   Used in setting groups. */
int
d2sMagicProperty::SetFieldsEqualTo (const d2sMagicProperty& source)
{
  int i;

  if (this->field_count != source.field_count)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: \"%s\"->d2sMagicProperty\n"
		 " ::SetFieldsEqualTo (\"%s\")\n",
		 progname, Description(), source.Description());
      error_str = "Fields do not match";
      return -1;
    }
  for (i = 0; i < field_count; i++)
    if (this->field_width[i] != source.field_width[i])
      {
	if (debug)
	  fprintf (stderr, "%s: Internal error: \"%s\"->d2sMagicProperty\n"
		   " ::SetFieldsEqualTo (\"%s\")\n",
		   progname, Description(), source.Description());
	error_str = "Fields do not match";
	return -1;
      }
  for (i = 0; i < field_count; i++)
    this->field_value[i] = source.field_value[i];
  MarkDirty ();
  return 0;
}

/* Add one property to another.  Both must be the same type. */
d2sMagicProperty&
d2sMagicProperty::operator+= (const d2sMagicProperty& prop2)
{
  struct add_data_t *add_data;

  if ((this->property_id < 0)
      ? (strcmp (this->Code(), prop2.Code()) != 0)
      : (this->property_id != prop2.property_id))
    /* Mismatch!  We can't add the properties;
       only merge, but the return type can't handle that. */
    return *this;

  /* Find the function used to add the fields */
  add_data = (struct add_data_t *) bsearch
    (GetEntryStringField (property_entry, "addFunc"),
     add_data_table, XtNumber (add_data_table),
     sizeof (add_data_t), search_func);
  if (add_data == NULL)
    /* No addition function; silently do nothing */
    return *this;

  /* For certain types of addition,
     the first field of both operands must match. */
  if ((add_data->func == add_2ndfield)
      || (add_data->func == add_3rdfield)
      || (add_data->func == add_3rd4thfields))
    {
      if (this->field_value[0] != prop2.field_value[0])
	return *this;
    }

  /* Do the addition.  Note that we don't test for success,
     as we have no means to report back any error. */
  if (add_data->func (&this->field_value[0], &prop2.field_value[0], bias)
      >= 0)
    MarkDirty ();
  return *this;
}

/* Return true if a property is a partial member of a given property.
   (e.g., "fire-min" is part of the complete property "dmg-fire".) */
int
d2sMagicProperty::operator< (const char *code) const
{
  return (strcmp (Code(), GetEntryStringField (property_entry, "partial"))
	  == 0);
}

/* Return true if a property is a group container for a given property.
   (e.g., "dmg-min" is a container for properties 21, 23, and 159.) */
int
d2sMagicProperty::operator>= (const d2sMagicProperty& prop) const
{
  int i, num_comps;
  char field_name[8] = "comp1";

  num_comps = GetEntryIntegerField (property_entry, "composite");
  for (i = 0; i < num_comps; i++)
    {
      field_name[4] = (char) ('1' + i);
      if (GetEntryIntegerField (property_entry, field_name) == prop.ID())
	return True;
    }
  return False;
}

/* Return whether two magic properties have the same value.
   The ID's need not be identical, so long as the field types are.
   Used to see whether resistances can be combined into a group. */
int
d2sMagicProperty::matches_value_of (const d2sMagicProperty *prop2) const
{
  int i;

  if (this->field_count != prop2->field_count)
    return 0;
  for (i = 0; i < field_count; i++)
    if ((this->field_width[i] != prop2->field_width[i])
	|| (this->field_value[i] != prop2->field_value[i]))
      return 0;
  return 1;
}

/* If a property is ranged, choose a random
   (raw) data value within the range. */
int
d2sMagicProperty::RangedValue (void) const
{
  /* Make sure we are a range before getting a random number */
  if (((field_count != 1) && (property_id != 17) /* HACK */)
      || (field_value[1] <= field_value[0]))
    return field_value[0];

  return (rand() % (field_value[1] - field_value[0] + 1) + field_value[0]);
}

/* These are used by d2sMagic for stacked properties.
     Change the property ID to another ID within the same stack. */
void
d2sMagicProperty::StackedReset (void)
{
  int	stack;

  stack = GetEntryIntegerField (property_entry, "stackedOn");
  if (!stack || (stack == property_id))
    return;
  property_id = stack;
  property_entry = LookupNumericTableEntry ("properties", "Id", property_id);
  MarkDirty();
}

int
d2sMagicProperty::StackedBump (void)
{
  int	stack, stack_next;
  table_entry_t next_entry;

  stack = GetEntryIntegerField (property_entry, "stackedOn");
  if (!stack)
    return -1;
  next_entry = LookupNumericTableEntry ("properties", "Id", property_id + 1);
  stack_next = GetEntryIntegerField (next_entry, "stackedOn");
  if (stack_next != stack)
    return -1;
  property_id++;
  property_entry = next_entry;
  MarkDirty();
  return 0;
}


/********************************
 *	     d2sMagic		*
 *	      class		*
 ********************************/

d2sMagic::d2sMagic (void)
{
  error_str = NULL;
  list_size = 1;
  list = (d2sMagicProperty **) xmalloc (sizeof (d2sMagicProperty *));
  /* The initial list contains a single member: the end-of-list marker */
  list[0] = new d2sMagicProperty ();
  list[0]->AssignTo (this);
  my_item = NULL;
}

/* Create and assign to an item in one step */
d2sMagic::d2sMagic (d2sItem *item)
{
  error_str = NULL;
  list_size = 1;
  list = (d2sMagicProperty **) xmalloc (sizeof (d2sMagicProperty *));
  /* The initial list contains a single member: the end-of-list marker */
  list[0] = new d2sMagicProperty ();
  list[0]->AssignTo (this);
  my_item = item;
}

/* Copy an existing magic property list */
d2sMagic::d2sMagic (const d2sMagic& source)
{
  error_str = NULL;
  list_size = 0;
  list = NULL;
  my_item = NULL;
  *this = source;
}

d2sMagic::~d2sMagic ()
{
  int i;

  for (i = 0; i < list_size; i++)
    delete list[i];
  free (list);
  list = NULL;
}

/* Assign a property list to an item */
int
d2sMagic::AssignTo (d2sItem *new_item)
{
  if ((my_item != NULL) && (new_item != NULL))
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: attempt to assign magic property"
		 " %p to %s (%p)\n when it is already assigned to %s (%p)\n",
		 progname, this, new_item->Name(), new_item,
		 my_item->Name(), my_item);
      return -1;
    }
  my_item = new_item;
  return 0;
}

/* Read a list of magic properties from a file */
int
d2sMagic::Read (struct bit_stream *bstream)
{
  int i;

  /* If we have any existing properties, delete them. */
  for (i = 0; i < list_size; i++)
    delete list[i];
  list_size = 0;

  /* Append the properties from the bit stream to our now-empty list. */
  return Append (bstream);
}

/* For set items, call this to append another list
   of properties to the existing list.  The current
   end-of-list marker becomes a list separator. */
int
d2sMagic::Append (struct bit_stream *bstream)
{
  do {
    /* Add space for another property in our list */
    list = (d2sMagicProperty **) xrealloc (list, (list_size + 1)
					  * sizeof (d2sMagicProperty *));
    /* Create a new property */
    list[list_size] = new d2sMagicProperty ();
    list[list_size]->AssignTo (this);

    /* Read the property's values from the bit stream */
    if (list[list_size]->Read (bstream) < 0)
      {
	error_str = list[list_size]->GetErrorMessage();
	delete list[list_size];
	return -1;
      }
    list_size++;
  } while (list[list_size - 1]->ID() != END_OF_LIST_MARKER);
  return 0;
}

/* Write a list of magic properties to a file */
int
d2sMagic::Write (struct bit_stream *bstream)
{
  int i;

  for (i = 0; i < list_size; i++)
    {
      if (list[i]->Write (bstream) < 0)
	{
	  error_str = list[i]->GetErrorMessage();
	  return -1;
	}
    }
  return 0;
}

/* Return a string describing all of the properties in this list, as
   displayed in the game.  String is allocated on demand; must be
   freed.  Each property in the string is prefixed with a newline.
   If the property list is empty, this returns NULL. */
char *
d2sMagic::Display (void) const
{
  int i, sorted_size;
  d2sMagicProperty **sorted_list, *group;
  const char *cstr;
  table_entry_t group_entry;
  int done_mndmg = False, done_mxdmg = False, done_allskills = False;
  unsigned int length;
  char *full_string;
  char *one_line;

  length = 0;
  full_string = NULL;

  /* Sort the properties by property ID.  Omit any end-of-list markers. */
  sorted_list = (d2sMagicProperty **)
    xmalloc (list_size * sizeof (d2sMagicProperty *));
  sorted_size = 0;
  for (i = 0; i < list_size; i++)
    {
      if (list[i]->ID() == END_OF_LIST_MARKER)
	continue;
      sorted_list[sorted_size++] = list[i];
    }
  qsort (sorted_list, sorted_size, sizeof (d2sMagicProperty *), sort_by_id);

  for (i = 0; i < sorted_size; i++)
    {
      /* We need to check for group members here.  There are at least
	 five groups, and unfortunately they must be treated
	 differently.  For elemental resistances, all four group members
	 must have the same value; otherwise they are displayed
	 individually.  For minimum/maximum damage, any number of members
	 are collapsed into one, regardless of the value (I think). */
      cstr = GetEntryStringField (sorted_list[i]->TableEntry(), "group");
      group_entry = LookupTableEntry ("properties", "Code", cstr);
      if ((i + 3 < sorted_size) && (strcmp (cstr, "res-all") == 0)
	  && (sorted_list[i]->ID()
	      == GetEntryIntegerField (group_entry, "comp1"))
	  && (sorted_list[i + 1]->ID()
	      == GetEntryIntegerField (group_entry, "comp2"))
	  && sorted_list[i + 1]->matches_value_of (sorted_list[i])
	  && (sorted_list[i + 2]->ID()
	      == GetEntryIntegerField (group_entry, "comp3"))
	  && sorted_list[i + 2]->matches_value_of (sorted_list[i])
	  && (sorted_list[i + 3]->ID()
	      == GetEntryIntegerField (group_entry, "comp4"))
	  && sorted_list[i + 3]->matches_value_of (sorted_list[i]))
	{
	  group = new d2sMagicProperty ("res-all");
	  group->SetFieldsEqualTo (*sorted_list[i]);
	  one_line = group->Display();
	  delete group;
	  i += 3;
	}

      else if ((i + 3 < sorted_size) && (strcmp (cstr, "res-all-max") == 0)
	       && (sorted_list[i]->ID()
		   == GetEntryIntegerField (group_entry, "comp1"))
	       && (sorted_list[i + 1]->ID()
		   == GetEntryIntegerField (group_entry, "comp2"))
	       && sorted_list[i + 1]->matches_value_of (sorted_list[i])
	       && (sorted_list[i + 2]->ID()
		   == GetEntryIntegerField (group_entry, "comp3"))
	       && sorted_list[i + 2]->matches_value_of (sorted_list[i])
	       && (sorted_list[i + 3]->ID()
		   == GetEntryIntegerField (group_entry, "comp4"))
	       && sorted_list[i + 3]->matches_value_of (sorted_list[i]))
	{
	  group = new d2sMagicProperty ("res-all-max");
	  group->SetFieldsEqualTo (*sorted_list[i]);
	  one_line = group->Display();
	  delete group;
	  i += 3;
	}

      else if ((done_mndmg && (strcmp (cstr, "dmg-min") == 0))
	       || (done_mxdmg && (strcmp (cstr, "dmg-max") == 0)))
	/* Skip additional min/max damage entries */
	continue;

      else if ((i + 4 < sorted_size) && (strcmp (cstr, "allskills") == 0)
	       && (sorted_list[i]->ID()
		   == GetEntryIntegerField (group_entry, "comp1"))
	       && (sorted_list[i + 1]->ID()
		   == GetEntryIntegerField (group_entry, "comp2"))
	       && sorted_list[i + 1]->matches_value_of (sorted_list[i])
	       && (sorted_list[i + 2]->ID()
		   == GetEntryIntegerField (group_entry, "comp3"))
	       && sorted_list[i + 2]->matches_value_of (sorted_list[i])
	       && (sorted_list[i + 3]->ID()
		   == GetEntryIntegerField (group_entry, "comp4"))
	       && sorted_list[i + 3]->matches_value_of (sorted_list[i])
	       && (sorted_list[i + 4]->ID()
		   == GetEntryIntegerField (group_entry, "comp5"))
	       && sorted_list[i + 4]->matches_value_of (sorted_list[i]))
	{
	  group = new d2sMagicProperty ("allskills");
	  group->SetFieldsEqualTo (*sorted_list[i]);
	  one_line = group->Display();
	  delete group;
	  i += 4;
	  /* If this is an expansion item, there will probably be
	     additional entries for Druid and Assassin.
	     Remember to skip them. */
	  done_allskills = True;
	}

      else if (done_allskills && (strcmp (cstr, "allskills") == 0))
	/* Skip additional all-skills entries */
	continue;

      else
	{
	  one_line = sorted_list[i]->Display();
	  /* Keep track of min/max damage entries */
	  if (strcmp (cstr, "dmg-min") == 0)
	    done_mndmg = True;
	  else if (strcmp (cstr, "dmg-max") == 0)
	    done_mxdmg = True;
	}

      full_string = (char *)
	xrealloc (full_string, length + 1 + strlen (one_line) + 1);
      full_string[length++] = '\n';
      strcpy (&full_string[length], one_line);
      length += strlen (&full_string[length]);
      free (one_line);
    }

  free (sorted_list);
  return full_string;
}

/* Return whether any of the magic properties in a list
   is specific to the expansion set */
int
d2sMagic::is_expansion (void) const
{
  int i;

  for (i = 0; i < list_size; i++)
    if (list[i]->is_expansion())
      return True;
  return False;
}

/* For set items, return the number of lists this class contains */
int
d2sMagic::NumberOfPropertyLists (void) const
{
  int count, i;

  for (count = 0, i = 0; i < list_size; i++)
    if (list[i]->ID() == END_OF_LIST_MARKER)
      count++;
  return count;
}

/* For set items, return the number of properties in the Nth list */
int
d2sMagic::NumberOfPropertiesInList (int n) const
{
  int i, first_i;

  /* The first part counts N end-of-list markers */
  first_i = 0;
  while ((first_i < list_size) && n)
    if (list[first_i++]->ID() == END_OF_LIST_MARKER)
      n--;

  /* Now leave FIRST_I in place and advance I to the next marker */
  for (i = first_i; i < list_size; i++)
    if (list[i]->ID() == END_OF_LIST_MARKER)
      break;

  /* The difference between the two indices is the length of the list */
  return (i - first_i);
}

/* Search the properties in this list for one matching the given ID */
d2sMagicProperty *
d2sMagic::Lookup (int id) const
{
  int i;

  for (i = 0; i < list_size; i++)
    {
      if (*list[i] == id)
	return list[i];
    }
  return NULL;
}

d2sMagicProperty *
d2sMagic::Lookup (const char *code) const
{
  int i;

  for (i = 0; i < list_size; i++)
    {
      if (*list[i] == code)
	return list[i];
    }
  return NULL;
}

/* Mark a property list as having been changed
   (We don't track dirt ourselves; just pass it on the the parent.) */
void
d2sMagic::MarkDirty (void)
{
  if (my_item != NULL)
    my_item->MarkDirty ();
}

/* Copy a property list */
d2sMagic&
d2sMagic::operator= (const d2sMagic& source)
{
  int i;

  /* If we have any existing properties, delete them. */
  for (i = 0; i < list_size; i++)
    delete list[i];

  /* Make sure we have room to copy the source's properties */
  if (this->list_size < source.list_size)
    list = (d2sMagicProperty **) xrealloc (list, source.list_size
					   * sizeof (d2sMagicProperty *));
  this->list_size = source.list_size;

  /* Copy the source properties */
  for (i = 0; i < list_size; i++)
    {
      list[i] = new d2sMagicProperty (*source.list[i]);
      this->list[i]->AssignTo (this);
    }

  MarkDirty ();
  return *this;
}

/* Add a new property to the list.  Insert at the given location
   if the second argument is present; otherwise append. */
int
d2sMagic::AddProperty (d2sMagicProperty *new_property, int n)
{
  /* Is changing properties allowed? */
  if (read_only() || !options.item.edit.magic_property_list)
    {
      error_str = "You may not alter the list of magic properties";
      print_message (error_str);
      return -1;
    }

  /* If N is unspecified, set it to the end of the list.
     The "end of the list" in this case does not include the end marker. */
  if (n < 0)
    n = ((list_size && (list[list_size - 1]->ID() == END_OF_LIST_MARKER))
	 ? (list_size - 1) : list_size);

  /* We must make sure no two properties share the same ID */
  if ((unsigned) new_property->ID() < END_OF_LIST_MARKER)
    {
      while (Lookup (new_property->ID()) != NULL)
	{
	  /* If this is a stacked property, try the next available ID. */
	  if (new_property->StackedBump() >= 0)
	    continue;
	  print_message ("This list already contains the property %s.\n",
			 new_property->Description());
	  error_str = "Property is already in this list";
	  return -1;
	}
    }

  /* Make room for the new property */
  list = (d2sMagicProperty **)
    xrealloc (list, (list_size + 1) * sizeof (d2sMagicProperty *));
  if (n < list_size)
    memmove (&list[n + 1], &list[n],
	     (list_size - n) * sizeof (d2sMagicProperty *));
  list_size++;

  list[n] = new_property;
  new_property->AssignTo (this);
  MarkDirty ();
  return 0;
}

/* Another way of stating the above, with a difference: a copy of the
   given property is added, rather than the property itself; and if a
   similar property already exists, their values are added.
   THIS VERSION DOES NOT CHECK FOR READ-ONLY OR EDIT OPTIONS;
   it is meant for internal use. */
d2sMagic&
d2sMagic::operator+= (const d2sMagicProperty& new_property)
{
  d2sMagicProperty *new_copy = NULL;

  /* Check whether we have an existing property with the same ID */
  if (new_property.ID() >= 0)
    new_copy = Lookup (new_property.ID());
  if ((new_copy == NULL) && new_property.Code()[0])
    new_copy = Lookup (new_property.Code());
  if (new_copy != NULL)
    {
      /* If this is a stacked property, the first field
	 must match to be added; otherwise append. */
      if (!GetEntryIntegerField (new_copy->TableEntry(), "stackedOn")
	  || (new_copy->FieldData (0) == new_property.FieldData (0)))
	{
	  *new_copy += new_property;
	  return *this;
	}
    }

  /* If it doesn't already exist, append a copy. */
  new_copy = new d2sMagicProperty (new_property);
  if (AddProperty (new_copy) < 0)
    delete new_copy;
  return *this;
}

/* Merge properties from another list into this one */
d2sMagic&
d2sMagic::operator+= (const d2sMagic& new_list)
{
  int i;

  if (&new_list)
    {
      for (i = 0; i < new_list.list_size; i++)
	*this += *new_list.list[i];
    }
  return *this;
}

/* Remove a property from the list.  In most cases, the values are
   irrelevant; any existing property having the same ID is removed. */
d2sMagic&
d2sMagic::operator-= (const d2sMagicProperty& remove_property)
{
  int i;

  /* Ignore requests to remove end-of-list markers */
  if (remove_property.ID() == END_OF_LIST_MARKER)
    return *this;

  /* Look for an existing property with the same ID */
  for (i = 0; i < list_size; i++)
    if ((list[i]->ID() < 0)
	? (strcmp (list[i]->Code(), remove_property.Code()) == 0)
	: (list[i]->ID() == remove_property.ID()))
      {
	/* Remove the property */
	RemoveProperty (i);
	return *this;
      }
  /* TO-DO: check for removing a property group */

  /* Silently ignore the request if there is no matching property */
  return *this;
}

/* Remove properties in another list from this one */
d2sMagic&
d2sMagic::operator-= (const d2sMagic& remove_list)
{
  int i;

  for (i = 0; i < remove_list.list_size; i++)
    *this -= *remove_list.list[i];
  return *this;
}

/* Remove a property from the list. */
int
d2sMagic::RemoveProperty (d2sMagicProperty *old_property)
{
  int i;

  for (i = 0; i < list_size; i++)
    if (list[i] == old_property)
      return RemoveProperty (i);
  if (debug) {
    fprintf (stderr, "%s: Internal error: attempt to remove %s\n"
	     " from list %p,", progname, old_property->Description(), this);
    if (old_property->ParentList() == NULL)
      fprintf (stderr, " but it is not in any list.\n");
    else if (old_property->ParentList() == this)
      fprintf (stderr, " but this list doesn't have it recorded.\n");
    else
      fprintf (stderr, " but it is a member of list %p.\n",
	       old_property->ParentList());
  }
  error_str = "Property not found";
  return -1;
}

/* Same, using the property's index in the list */
int
d2sMagic::RemoveProperty (int n)
{
  if ((unsigned) n >= (unsigned) list_size)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: invalid index to"
		 " d2sMagic::RemoveProperty(%d) (%p has %d entries)\n",
		 progname, n, this, list_size);
      error_str = "Invalid property index";
      return -1;
    }

  /* Is changing properties allowed? */
  if (read_only() || !options.item.edit.magic_property_list)
    {
      error_str = "You may not alter the list of magic properties";
      print_message (error_str);
      return -1;
    }

  /* Delete the requested property */
  delete list[n];

  /* Move the following properties up to close the gap */
  list_size--;
  if (n < list_size)
    memmove (&list[n], &list[n + 1],
	     (list_size - n) * sizeof (d2sMagicProperty *));
  MarkDirty ();
  return 0;
}

/* Reorder the list; move a property to the Nth position */
int
d2sMagic::MoveProperty (d2sMagicProperty *old_property, int n)
{
  int i;

  for (i = 0; i < list_size; i++)
    if (list[i] == old_property)
      return MoveProperty (i, n);
  if (debug) {
    fprintf (stderr, "%s: Internal error: attempt to move %s\n in list %p,",
	     progname, old_property->Description(), this);
    if (old_property->ParentList() == NULL)
      fprintf (stderr, " but it is not in any list.\n");
    else if (old_property->ParentList() == this)
      fprintf (stderr, " but this list doesn't have it recorded.\n");
    else
      fprintf (stderr, " but it is a member of list %p.\n",
	       old_property->ParentList());
  }
  error_str = "Property not found";
  return -1;
}

int
d2sMagic::MoveProperty (int i, int n)
{
  d2sMagicProperty *tmp;

  /* Is changing properties allowed? */
  if (read_only() || !options.item.edit.magic_property_list)
    {
      error_str = "You may not alter the list of magic properties";
      print_message (error_str);
      return -1;
    }

  if (((unsigned) i >= (unsigned) list_size)
      || ((unsigned) n >= (unsigned) list_size))
    {
      fprintf (stderr, "%s: Internal error: invalid index to"
	       " d2sMagic::MoveProperty(%d) (%p has %d entries)\n",
	       progname, n, this, list_size);
      error_str = "Invalid property index";
      return -1;
    }

  if (i == n)
    return 0;

  /* Save the property at I */
  tmp = list[i];

  /* Shift the properties between I and N */
  if (i < n)
    memmove (&list[i], &list[i + 1], (n - i) * sizeof (d2sMagicProperty *));
  else
    memmove (&list[n + 1], &list[n], (i - n) * sizeof (d2sMagicProperty *));

  /* Replace the property to N */
  list[n] = tmp;
  MarkDirty ();
  return 0;
}

/* Take a list of properties, e.g. those found in the item tables or
   magic prefixes/suffixes, and generate a canonical property list
   based on their values or ranges.  Partial properties (e.g.,
   "fire-min" and "fire-max") are combined into a single property
   ("dmg-fire").  If a source field has a range, a random value is
   chosen from that range for the destination.  The new properties
   replace the original ones in the list.  The list is returned. */
d2sMagic *
d2sMagic::Generate (void)
{
  int i, j, n, ranged_value;
  const char *combined_code;
  char group_name[8] = "comp1";
  d2sMagicProperty *replacement_property;
  d2sMagic *canon_list;

  canon_list = new d2sMagic;
  for (i = 0; i < list_size; i++)
    {
      /* Look for partial properties first */
      combined_code = GetEntryStringField (list[i]->TableEntry(), "partial");
      if (combined_code[0]) {
	/* Create the replacement; no values yet */
	replacement_property = new d2sMagicProperty (combined_code);
	/* Start inserting values with the current one */
	j = 0;
	do {
	  replacement_property->SetFieldData
	    (GetEntryIntegerField (list[i + j]->TableEntry(),
				   "partialField") - 1,
	     list[i + j]->RangedValue());
	  j++;
	} while ((i + j < list_size)
		 && (strcmp (combined_code,
			     GetEntryStringField (list[i + j]->TableEntry(),
						  "partial"))
		     == 0));
	/* Now that we have a complete property,
	   add it to the canonical list */
	*canon_list += *replacement_property;
	delete replacement_property;
	/* Go on to the next property */
	continue;
      }

      /* Next, check for a ranged property */
      if (list[i]->is_ranged())
	ranged_value = list[i]->RangedValue();
      else
	ranged_value = 0;
      /* Both ranged and non-ranged properties go on to the next check */

      /* Lastly, check for a group property */
      n = GetEntryIntegerField (list[i]->TableEntry(), "composite");
      if (n) {
	/* In this case, we need to replace the group with its members. */
	for (j = 0; j < n; j++) {
	  group_name[4] = (char) ('1' + j);
	  replacement_property = new d2sMagicProperty
	    (GetEntryIntegerField (list[i]->TableEntry(), group_name));
	  /* Set the member's value equal to the group property */
	  if (ranged_value)
	    replacement_property->SetFieldData (0, ranged_value);
	  else
	    replacement_property->SetFieldsEqualTo (*list[i]);
	  *canon_list += *replacement_property;
	  delete replacement_property;
	}
      }
      else if (GetEntryStringField (list[i]->TableEntry(), "Id")[0]) {
	replacement_property = new d2sMagicProperty
	  (GetEntryIntegerField (list[i]->TableEntry(), "Id"));
	if (ranged_value) {
	  replacement_property->SetFieldData (0, ranged_value);
	  /* HACK: AFAIK, only this one property has
	     two fields that share the same value. */
	  if (replacement_property->ID() == 17)
	    replacement_property->SetFieldData (1, ranged_value);
	} else
	  replacement_property->SetFieldsEqualTo (*list[i]);
	*canon_list += *replacement_property;
	delete replacement_property;
      }
      else if (list[i]->GetErrorMessage() == NULL) {
	if (debug)
	  fprintf (stderr, "%s: Internal error: no numeric code for"
		   " magic property \"%s\".\n", progname,
		   GetEntryStringField (list[i]->TableEntry(), "Code"));
	/* Don't add this to the canonical list */
      }
    }

  if ((my_item != NULL) && ((my_item->Type() == ARMOR_ITEM)
			    || (my_item->Type() == WEAPON_ITEM)))
    {
      d2sDurableItem *ditem = (d2sDurableItem *) *my_item;

      /* Hack: if we are attached to an item that can be socketed, and
	 our generated list includes "sock", change the number of
	 sockets on the item and delete the "sock" property from the
	 list. */
      replacement_property = canon_list->Lookup ("sock");
      if ((replacement_property != NULL) && ditem->MaximumNumberOfSockets())
	{
	  if (ditem->SetNumberOfSockets
	      (replacement_property->FieldData (0)) >= 0)
	    {
	      canon_list->RemoveProperty (replacement_property);
	      delete replacement_property;
	    }
	}
    }

  /* Lastly, replace this list with the canonical one. */
  *this = *canon_list;
  delete canon_list;
  return this;
}
