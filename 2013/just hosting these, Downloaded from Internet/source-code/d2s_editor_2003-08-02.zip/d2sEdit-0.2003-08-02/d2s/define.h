/* Macro definitions for the Diablo II v1.09 game editor.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef DEFINE_DEFINE
#define DEFINE_DEFINE

/* Define character classes */
#define AMAZON_CLASS	0
#define SORCERESS_CLASS 1
#define NECROMANCER_CLASS 2
#define PALADIN_CLASS	3
#define BARBARIAN_CLASS 4
#define DRUID_CLASS	5
#define ASSASSIN_CLASS	6
#define NUM_CHAR_CLASSES 7

/* Define difficulty levels */
#define NORMAL_DIFFICULTY	0
#define NIGHTMARE_DIFFICULTY	1
#define HELL_DIFFICULTY		2
#define NUM_DIFFICULTY_LEVELS	3

/* Other sizes */
#define MAX_NUM_ACTS		5
#define MAX_NUM_QUESTS		6
#define MAX_NUM_WAYPOINTS	9
#define NUM_SKILL_SETS		3
#define NUM_SKILLS_PER_SET	10
#define NUM_SKILLS_PER_CHAR	(NUM_SKILL_SETS * NUM_SKILLS_PER_SET)
#define HSIZE_INVENTORY		10
#define VSIZE_INVENTORY		4
#define HSIZE_STASH		6
#define VSIZE_STASH		8	// maximum
#define HSIZE_CUBE		3
#define VSIZE_CUBE		4
#define MSIZE_BELT		16
#define MSIZE_EQUIPMENT		16

/* Macros defining item areas for various internal uses.
   (These have nothing to do with the format of the .d2s file.) */
#define ITEM_AREA_EQUIPPED	1
#define ITEM_AREA_BELT		2
#define ITEM_AREA_INVENTORY	3
#define ITEM_AREA_STASH		4
#define ITEM_AREA_CUBE		5
#define ITEM_AREA_CORPSE	6
#define ITEM_AREA_HIRELING	7
/* A special area for an item which has been picked up
   (i.e., is in transit from one place to another): */
#define ITEM_AREA_PICKED	8
/* An area for an item which is socketed; such an item
   cannot be accessed directly through the character. */
#define ITEM_AREA_SOCKETED	9

#endif /* DEFINE_DEFINE */
