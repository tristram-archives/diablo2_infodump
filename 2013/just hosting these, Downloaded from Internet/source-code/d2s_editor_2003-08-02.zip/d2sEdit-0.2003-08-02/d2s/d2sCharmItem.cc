/* d2sCharmItem -- C++ class that holds an internal representation
 *		   of a Diablo II v1.09 charm, amulet, or ring;
 *		   also the base class for jewels.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sMagic.h"
#include "d2sQuality.h"
#include "internal.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Create a new, blank charm (to be filled in later) */
d2sCharmItem::d2sCharmItem (void)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (), d2sExtendedItem ()
{
  /* Override the default item class */
  item_class = CHARM_ITEM;
  nvop = this;
}

/* Create a new, specific charm as described by the item table entry 
   (using default variable attributes)*/
d2sCharmItem::d2sCharmItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (tent), d2sExtendedItem (tent)
{
  /* Override the default item class */
  item_class = CHARM_ITEM;
  nvop = this;
}

/* Copy an existing charm */
d2sCharmItem::d2sCharmItem (const d2sCharmItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (source), d2sExtendedItem (source)
{
  /* Change the nvop (very important) */
  nvop = this;
}

/* Copy a template charm, and fill in the rest of the data
   using data from an item file or character file. */
d2sItem *
d2sCharmItem::Copy (void) const
{
  d2sCharmItem *new_item = new d2sCharmItem (*this);
  return (d2sItem *) new_item;
}

/* Charms add their required level and magic properties to the
   descrption.  (They could add their picture, but that belongs to the
   GUI, not here.) */
char *
d2sCharmItem::FullDescription (void) const
{
  char *descr;
  const char *cstr;
  int len, required_level;

  /* Start with the item's full name */
  descr = FullName();
  len = strlen (descr);

  /* If this is an actual charm (amulets and rings may use this
     function too), add an extra description line */
  if (this->is_of_type ("char"))
    {
      cstr = LookupStringByKey ("Charmdes");
      if (cstr == NULL)
	cstr = "Keep in Inventory to Gain Bonus";
      descr = (char *) xrealloc (descr, len + 1 + strlen (cstr) + 1);
      len += sprintf (&descr[len], "\n%s", cstr);
    }

  /* Required level, if any */
  required_level = RequiredLevel();
  if (required_level > 1)
    {
      cstr = LookupStringByKey ("ItemStats1p");
      if (cstr == NULL)
	cstr = "Required Level:";
      descr = (char *) xrealloc
	(descr, len + 1 + strlen (cstr) + sizeof (" %3d") + 1);
      len += sprintf (&descr[len], "\n%s %d", cstr, required_level);
    }

  /* Finish up */
  return FinishFullDescription (descr);
}

/* Read class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after reading the quality fields
   and before reading the magic properties. */
int
d2sCharmItem::ReadItemSpecificData (struct bit_stream *bstream)
{
  /* Charms have no item-specific data.
     This is just here to override d2sExtendedItem::WriteItemSpecificData(),
     which spits out an error. */
  return 0;
}

/* Write class-specific fields to the item data bit stream.
   Called by d2sExtendedItem after writing the quality fields
   and before writing the magic properties. */
int
d2sCharmItem::WriteItemSpecificData (struct bit_stream *bstream)
{
  /* Charms have no item-specific data.
     This is just here to override d2sExtendedItem::WriteItemSpecificData(),
     which spits out an error. */
  return 0;
}
