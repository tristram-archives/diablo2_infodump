/* d2sStackedWeaponItem -- C++ class that holds an internal representation
 *			   of a Diablo II v1.09 stacked weapon.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sMagic.h"
#include "d2sQuality.h"
#include "internal.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>

/* Create a new, blank stacked weapon (to be filled in later) */
d2sStackedWeaponItem::d2sStackedWeaponItem (void)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (), d2sExtendedItem (), d2sStackItem (), d2sWeaponItem ()
{
  /* Override the default item class */
  item_class = STACKED_WEAPON_ITEM;
  nvop = this;
}

/* Create a new, specific stacked weapon as described by
   the weapon table entry (using default variable attributes) */
d2sStackedWeaponItem::d2sStackedWeaponItem (table_entry_t tent)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (tent), d2sExtendedItem (tent),
    d2sStackItem (tent), d2sWeaponItem (tent)
{
  table_entry_t bomb_entry;
  int duration;

  /* Override the default item class */
  item_class = STACKED_WEAPON_ITEM;
  /* Change the nvop (very important) */
  nvop = this;

  /* d2sStackItem and d2sWeaponItem should take care of all our fields,
     except for throw damage. */
  if (this->is_of_type ("tpot"))
    {
      /* Throwing potions don't have a normal min-max
	 missile damage entry in the weapon tables.
	 Instead, we have to go to the missiles table. */
      bomb_entry = LookupTableEntry
	("missiles", "Id", GetEntryStringField (table_entry, "missiletype"));
      damage[THROW_DAMAGE][MINIMUM_DAMAGE]
	= (GetEntryIntegerField (bomb_entry, "MinDamage")
	   + GetEntryIntegerField (bomb_entry, "EMin"));
      damage[THROW_DAMAGE][MAXIMUM_DAMAGE]
	= (GetEntryIntegerField (bomb_entry, "MaxDamage")
	   + GetEntryIntegerField (bomb_entry, "EMax"));

      /* If this is a poison bomb, then the damage entry
	 is divided by 2 seconds. */
      duration = GetEntryIntegerField (bomb_entry, "ELen");
      if (duration) {
	damage[THROW_DAMAGE][MINIMUM_DAMAGE]
	  = damage[THROW_DAMAGE][MINIMUM_DAMAGE] * 25 / duration;
	damage[THROW_DAMAGE][MAXIMUM_DAMAGE]
	  = damage[THROW_DAMAGE][MAXIMUM_DAMAGE] * 25 / duration;
      }
    }

  else
    {
      damage[THROW_DAMAGE][MINIMUM_DAMAGE]
	= GetEntryIntegerField (table_entry, "minmisdam");
      damage[TWO_HAND_DAMAGE][MAXIMUM_DAMAGE]
	= GetEntryIntegerField (table_entry, "maxmisdam");
    }
  return;
}

/* Copy an existing stacked weapon */
d2sStackedWeaponItem::d2sStackedWeaponItem (const d2sStackedWeaponItem &source)
  /* Construct the base class part first.  Remember that since d2sInit
     and d2sExtendedItem are virtual base classes,
     it is our responsibility to initialize them. */
  : d2sItem (source), d2sExtendedItem (source),
    d2sStackItem (source), d2sWeaponItem (source)
{
  /* Change the nvop (very important) */
  nvop = this;
  /* Nothing more to do here */
  return;
}

/* Copy a template stacked weapon, and fill in the rest of the data
   using data from an item file or character file. */
d2sItem *
d2sStackedWeaponItem::Copy (void) const
{
  d2sStackedWeaponItem *new_item = new d2sStackedWeaponItem (*this);
  return (d2sItem *) new_item;
}

/* Create a weapon by filling in data from a file.
   (This simply calls d2sDurableItem::Read,
   then does a check against our data type) */
int
d2sStackedWeaponItem::Read (struct data_stream *dstream)
{
  int status;

  /* The d2sDurableItem (grandfather) class does the actual reading */
  status = this->d2sDurableItem::Read (dstream);

  /* Consistency check: stacked weapons may NOT be socketed. */
  if (socketed_item)
    {
      print_message ("Error: item \"%s\" (at offset %p) is"
		     " marked socketed\n", base_name,
		     dstream->ptr - dstream->base);
      error_str = "Bad item data";
    }

  return status;
}

/* Stacked weapons add their quality, damage, quantity,
   requirements, speed, and magic properties to the descrption. */
char *
d2sStackedWeaponItem::FullDescription (void) const
{
  /* d2sWeaponItem::FullDescription has been fitted
     to handle stacked weapons as well as normal,
     because the two displays are very similar. */
  return this->d2sWeaponItem::FullDescription ();
}

/* Read class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after reading the quality fields
   and before reading the magic properties. */
int
d2sStackedWeaponItem::ReadItemSpecificData (struct bit_stream *bstream)
{
  /* Read the base and current durability
     (not shown in the game, but still stored). */
  base_durability = bstream_read_field (bstream, 8);
  if (base_durability)
    durability = bstream_read_field (bstream, 8);
  else
    durability = 0;

  /* Stacked weapons should not be socketed, but in case the socketed
     bit is set, there *may* be this 4-bit field reserved for it. */
  if (socketed_item)
    {
      num_sockets = bstream_read_field (bstream, 4);
      print_message ("Warning: stacked weapon %s found with %d sockets\n",
		     base_name);
      error_str = "Invalid number of sockets";
    }

  /* Read the current quantity */
  quantity = bstream_read_field (bstream, 9);
  return 0;
}

/* Write class-specific fields from the item data bit stream.
   Called by d2sExtendedItem after writing the quality fields
   and before writing the magic properties. */
int
d2sStackedWeaponItem::WriteItemSpecificData (struct bit_stream *bstream)
{
  /* Write the base and current durability. */
  if (MaxDurability())
    {
      bstream_write_field (bstream, 8, base_durability);
      bstream_write_field (bstream, 8, durability);
    } else {
      /* This should take care of clearing the durability
	 if an "indestructible" property was added. */
      bstream_write_field (bstream, 8, 0);
    }

  /* Stacked weapons should not be socketed, but in case the socketed
     bit is set, we *may* have to reserve this 4-bit field for it. */
  if (socketed_item)
    bstream_write_field (bstream, 4, num_sockets);

  /* Write the current quantity */
  bstream_write_field (bstream, 9, quantity);

  return 0;
}
