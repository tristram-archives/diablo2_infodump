/* d2sQuality -- C++ classes that hold an internal representation
 *		 of the quality setting of Diablo II v1.09 items.
 * Copyright (C) 2002-2003 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include "d2sData.h"
#include "d2sItem.h"
#include "d2sMagic.h"
#include "d2sQuality.h"
#include "functions.h"
#include "internal.h"
#include "options.h"
#include "tables.h"
#include "util.h"
#include <dmalloc.h>


/* Forward declarations: */
static int match_item_to_xfix_types (d2sExtendedItem *item,
				     table_entry_t ent_xfix,
				     int is_expansion);
static d2sMagic *generate_xfix_properties (table_entry_t ent_xfix);

/**** Construct a new quality object from a given bit stream. ****/
d2sQuality *
ReadQualityFromItem (struct bit_stream *bstream, table_entry_t item_entry)
{
  item_quality_t quality;
  d2sQuality *err_quality;

  /* The caller should have already set the bstrem->ptr
     to bit 150: the item quality field. */
  quality = (item_quality_t) bstream_read_field (bstream, 4);
  /* From the quality number, call the correct constructor.
     Note that we reset the bstream pointer,
     because the constructor has to read everything. */
  bstream->ptr -= 4;
  switch (quality) {
  case LOW_QUALITY: return new d2sLowQuality (bstream, item_entry);
  case NORMAL_QUALITY: return new d2sQuality (bstream, item_entry);
  case HIGH_QUALITY: return new d2sHighQuality (bstream, item_entry);
  case MAGIC_QUALITY: return new d2sMagicalQuality (bstream, item_entry);
  case PART_OF_A_SET: return new d2sQPartOfASet (bstream, item_entry);
  case RARE_QUALITY: return new d2sRareQuality (bstream, item_entry);
  case UNIQUE_QUALITY: return new d2sUniqueQuality (bstream, item_entry);
  case CRAFTED_QUALITY: return new d2sCraftedQuality (bstream, item_entry);
  }

  /* If we get here, we have an unknown quality field.
     Construct a normal quality, but set its error field. */
  print_message ("Item's quality field is %d; item data may be corrupt"
		 " (%s bit %lu)\n", quality,
		 TranslateString (GetEntryStringField
				  (item_entry, "code")),
		 bstream->ptr);
  err_quality = new d2sQuality (bstream, item_entry);
  if (err_quality->error_str == NULL)
    err_quality->error_str = "Quality field is 0";
  return err_quality;
}


/**************** QUALITY SUPERCLASS ****************
 *
 * This class encompasses functions common
 * to all specific quality ratings.
 *************************************************/

/* Initialize the base class fields */
void
d2sQuality::Init (void)
{
  error_str = NULL;
  quality_class = NORMAL_QUALITY;
  required_level = 0;
  color_code = NULL;
  my_item = NULL;
  item_code = "";
  item_type_entry = NULL;
  expansion_mods = False;
  picture_bit = 0;
  picture = 0;
  unknown11_bit = 0;
  unknown11 = 0;
}

/* Create a new normal quality. */
d2sQuality::d2sQuality (void)
{
  /* Clear the base fields */
  Init ();
}

/* Create a new normal quality for a given item. */
d2sQuality::d2sQuality (table_entry_t item_entry)
{
  /* Clear the base fields */
  Init ();
  /* Set the item-specific fields */
  d2sQuality::SetItem (item_entry);
}

/* Copy an existing quality. */
d2sQuality&
d2sQuality::operator= (const d2sQuality& source)
{
  /* Note: we don't copy any error message! */
  this->quality_class = source.quality_class;
  this->required_level = source.required_level;
  this->color_code = source.color_code;
  /* Also, don't copy the quality's parent item,
     but *do* copy the _type_ of item. */
  this->item_code = source.item_code;
  this->item_type_entry = source.item_type_entry;
  this->expansion_mods = source.expansion_mods;
  this->picture_bit = source.picture_bit;
  this->picture = source.picture;
  this->unknown11_bit = source.unknown11_bit;
  this->unknown11 = source.unknown11;
  return *this;
}

d2sQuality *
d2sQuality::Copy (void)
{
  d2sQuality *new_quality = new d2sQuality ();
  /* Copy the base fields */
  *new_quality = *this;
  return new_quality;
}

/* Create a new quality object using data from the given bit stream. */
d2sQuality::d2sQuality (struct bit_stream *bstream, table_entry_t item_entry)
{
  /* Clear the base fields */
  Init ();
  /* Set the item */
  SetItem (item_entry);
  /* Read the bit stream */
  Read (bstream);
}

/* Set the type of item this quality is associated with.
   Used for checking what properties are legal */
void
d2sQuality::SetItem (d2sExtendedItem *new_item)
{
  if ((my_item == NULL) || (new_item == NULL))
    my_item = new_item;
  if (strcmp (my_item->Code(), item_code) != 0)
    d2sQuality::SetItem ((my_item == NULL) ? (table_entry_t) NULL
			 : my_item->ItemTableEntry());
}

/* Above, continued */
void
d2sQuality::SetItem (table_entry_t item_entry)
{
  item_code = GetEntryStringField (item_entry, "code");
  item_type_entry = LookupTableEntry
    ("itemtypes", "code", GetEntryStringField (item_entry, "type"));
  /* Update the number of pictures */
  num_pictures = GetEntryIntegerField (item_type_entry, "VarInvGfx");
  picture_bit = (num_pictures > 0);
}

/* Read a quality record in from a raw bit stream.
   You *MUST* call this using the matching quality class object! */
int
d2sQuality::Read (struct bit_stream *bstream)
{
  int read_class;

  required_level = 0;
  color_code = NULL;
  read_class = (item_quality_t) bstream_read_field (bstream, 4);
  if (quality_class != read_class)
    {
      fprintf (stderr, "%s: Internal error: quality class %d used to read\n"
	       " a bit stream containing quality class %d\n",
	       progname, quality_class, read_class);
      /* This is a bad error. */
      error_str = "Quality type mismatch";
      return -1;
    }
  picture_bit = (char) bstream_read_field (bstream, 1);
  if (picture_bit)
    picture = (char) bstream_read_field (bstream, 3);
  unknown11_bit = (char) bstream_read_field (bstream, 1);
  if (unknown11_bit)
    unknown11 = (short) bstream_read_field (bstream, 11);
  ReadQualitySpecificData (bstream);
  return 0;
}

/* Write a quality record out to a raw bit stream. */
void
d2sQuality::Write (struct bit_stream *bstream)
{
  /* Write out the base fields. */
  bstream_write_field (bstream, 4, quality_class);
  bstream_write_field (bstream, 1, picture_bit);
  if (picture_bit)
    bstream_write_field (bstream, 3, picture);
  bstream_write_field (bstream, 1, unknown11_bit);
  if (unknown11_bit)
    bstream_write_field (bstream, 11, unknown11);

  /* Write the quality-specific fields. */
  WriteQualitySpecificData (bstream);
}

/* Qualify an item's name, returning a newly allocated string */
char *
d2sQuality::QualifyName (const char *base_name) const
{
  /* For normal items, there is no change. */
  return xstrdup (base_name);
}

/* If the quality includes a picture field, change its value. */
int
d2sQuality::ChangePicture (unsigned int new_pic)
{
  if (picture == new_pic)
    /* Nothing to do. */
    return 0;

  if (new_pic >= 8)
    {
      print_message ("Invalid picture number (%d)\n", new_pic);
      error_str = "Invalid picture number";
      return -1;
    }
  if (!picture_bit)
    {
      print_message ("%s does not have a picture field\n",
		     TranslateString (item_code));
      error_str = "Item does not have a picture field";
      return -1;
    }
  if (read_only() || !options.item.edit.picture)
    {
      error_str = "You may not change this item's image";
      print_message (error_str);
      return -1;
    }
  /* If the picture number is more than the number of available
     pictures, and the character is not in freeform mode, fail. */
  if ((new_pic >= num_pictures) && !options.character.link.freeform)
    {
      print_message ("%s has %d pictures available\n",
		     TranslateString (item_code), num_pictures);
      error_str = "Invalid picture number";
      return -1;
    }

  picture = (char) new_pic;
  if (my_item != NULL)
    my_item->MarkDirty ();
  return 0;
}

/* If the quality includes an 11-bit unknown field, change its value. */
int
d2sQuality::SetUnknown11 (unsigned int new_uk11)
{
  if (new_uk11 >= 0x7ff)
    {
      print_message ("Invalid number for 11-bit field (%#x)\n", new_uk11);
      error_str = "Invalid number";
      return -1;
    }
  if (!unknown11_bit)
    {
      print_message ("%s does not have an 11-bit unknown field\n",
		     TranslateString (item_code));
      error_str = "Item does not have an 11-bit unknown field";
      return -1;
    }
  if (read_only() || !options.item.edit.magic_name)
    {
      error_str = "You may not change this unknown field";
      print_message (error_str);
      return -1;
    }

  unknown11 = (short) new_uk11;
  if (my_item != NULL)
    my_item->MarkDirty ();
  return 0;
}

/* Return whether the owner of a quality is read-only. */
int
d2sQuality::read_only (void) const
{
  return ((my_item != NULL) && my_item->read_only());
}

/* Reset the magical properties for an item.
   TO-DO: Some Expansion Set items are granted specific magic properties
   before any quality modifier is applied. */
void
d2sQuality::RegenerateProperties (d2sMagic *properties, int condense)
{
  d2sMagic	empty_list;

  *properties = empty_list;
}


/**************** QUALITY DERIVED CLASSES ****************
 *
 * These classes provide additional functions
 * for each specific quality rating.
 *********************************************************/

/* (small) table of low quality names */
static const char * const low_quality_names[8] = {
  "Crude", "Cracked", "Damaged", "Low Quality",
  /* The rest of these have never been seen ... yet */
  "Grade 4", "Grade 5", "Grade 6", "Grade 7"
};

/* Return the name of a low quality grade given its number */
const char *
GetLowQualityGradeName (int grade)
{
  if ((unsigned) grade < (unsigned) XtNumber (low_quality_names))
    return low_quality_names[grade];
  return NULL;
}

/* Create a new low quality. */
d2sLowQuality::d2sLowQuality (void)
  /* Clear the base fields */
  : d2sQuality ()
{
  quality_class = LOW_QUALITY;
  /* Clear the added fields */
  grade = 3;
}

/* Copy an existing low quality. */
d2sLowQuality&
d2sLowQuality::operator= (const d2sLowQuality &source)
{
  /* Copy the base fields */
  this->d2sQuality::operator= (source);
  /* Copy our added field */
  this->grade = source.grade;
  return *this;
}

d2sQuality *
d2sLowQuality::Copy (void)
{
  d2sLowQuality *new_quality = new d2sLowQuality;
  *new_quality = *this;
  return new_quality;
}

/* Create a new low quality object using data from the given bit stream. */
d2sLowQuality::d2sLowQuality (struct bit_stream *bstream,
			      table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality (item_entry)
{
  quality_class = LOW_QUALITY;
  /* Read the bit stream */
  Read (bstream);
}

/* Read the low quality field from a raw bit stream. */
void
d2sLowQuality::ReadQualitySpecificData (struct bit_stream *bstream)
{
  /* Read the low grade */
  grade = (int) bstream_read_field (bstream, 3);
  /* The field is 3 bits wide, but we only know of 4 settings. */
  if ((unsigned) grade >= (unsigned) XtNumber (low_quality_names))
    {
      print_message ("Low grade >= 4 (%s bit %lu)\n",
		     TranslateString (item_code), bstream->ptr - 3);
      error_str = "Low grade >= 4";
    }
}

/* Write the low quality field out to a raw bit stream. */
void
d2sLowQuality::WriteQualitySpecificData (struct bit_stream *bstream)
{
  /* Write out the grade */
  bstream_write_field (bstream, 3, grade);
}

/* Qualify an item's name, returning a newly allocated string */
char *
d2sLowQuality::QualifyName (const char *base_name) const
{
  char *ret_str;
  int len;
  const char *cstr;

  cstr = TranslateString (low_quality_names[grade]);
  len = strlen (cstr) + 1 + strlen (base_name) + 1;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, "%s %s", cstr, base_name);
  return ret_str;
}

/* Change the grade of the low quality item */
int
d2sLowQuality::ChangeGrade (int new_grade)
{
  if (grade == new_grade)
    /* Nothing to do. */
    return 0;

  if ((unsigned) new_grade >= 8)
    {
      print_message ("Invalid low quality grade (%d)\n", new_grade);
      error_str = "Invalid low quality grade";
      return -1;
    }
  if (read_only() || !options.item.edit.magic_name)
    {
      error_str = "Inferior grade cannot be changed";
      print_message (error_str);
      return -1;
    }

  grade = new_grade;
  if (my_item != NULL)
    my_item->MarkDirty ();
  return 0;
}

/********************************/

/* Create a new high quality. */
d2sHighQuality::d2sHighQuality (void)
  /* Clear the base fields */
  : d2sQuality ()
{
  quality_class = HIGH_QUALITY;
  /* Clear the added fields */
  grade = 3;
}

/* Copy an existing high quality. */
d2sHighQuality&
d2sHighQuality::operator= (const d2sHighQuality &source)
{
  /* Copy the base fields */
  this->d2sQuality::operator= (source);
  /* Copy our added field */
  this->grade = source.grade;
  return *this;
}

d2sQuality *
d2sHighQuality::Copy (void)
{
  d2sHighQuality *new_quality = new d2sHighQuality;
  *new_quality = *this;
  return new_quality;
}

/* Create a new high quality object using data from the given bit stream. */
d2sHighQuality::d2sHighQuality (struct bit_stream *bstream,
				table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality (item_entry)
{
  quality_class = HIGH_QUALITY;
  /* Read the bit stream */
  Read (bstream);
}

/* Read the low quality field from a raw bit stream. */
void
d2sHighQuality::ReadQualitySpecificData (struct bit_stream *bstream)
{
  /* Read the high grade */
  grade = (int) bstream_read_field (bstream, 3);
}

/* Write the high quality field out to a raw bit stream. */
void
d2sHighQuality::WriteQualitySpecificData (struct bit_stream *bstream)
{
  /* Write out the grade */
  bstream_write_field (bstream, 3, grade);
}

/* Qualify an item's name, returning a newly allocated string */
char *
d2sHighQuality::QualifyName (const char *base_name) const
{
  char *ret_str;
  int len;
  const char *cstr;

  cstr = GradeName();
  len = strlen (cstr) + 1 + strlen (base_name) + 1;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, "%s %s", cstr, base_name);
  return ret_str;
}

/* Get the current grade as a string ("Superior") */
const char *
d2sHighQuality::GradeName (void) const
{
  const char *cstr;

  cstr = LookupStringByKey ("Hiquality");
  if (cstr == NULL)
    cstr = "Superior";
  return cstr;
}

/* Change the grade of the high quality item */
int
d2sHighQuality::ChangeGrade (int new_grade)
{
  if (grade == new_grade)
    /* Nothing to do. */
    return 0;

  if ((unsigned) new_grade >= 8)
    {
      print_message ("Invalid high quality grade (%d)\n", new_grade);
      error_str = "Invalid high quality grade";
      return -1;
    }
  if (read_only() || !options.item.edit.magic_name)
    {
      error_str = "Superior grade cannot be changed";
      print_message (error_str);
      return -1;
    }

  grade = new_grade;
  if (my_item != NULL)
    my_item->MarkDirty ();
  return 0;
}

/* Reset the magical properties for an item.
   Superior items may have one or two magic properties,
   but from what I've seen, most of the time they're inherent and not
   applied explicitly.  With exceptions.  Needs more research. */
void
d2sHighQuality::RegenerateProperties (d2sMagic *properties, int condense)
{
  /* Take care of base properties first */
  d2sQuality::RegenerateProperties (properties, condense);
}

/********************************/

/* Compare an item's type to a prefix' or suffix' list
   of acceptable types and return whether a match is found.
   Shared by both magical and rare qualities. */
static int
match_item_to_xfix_types (d2sExtendedItem *item, table_entry_t ent_xfix,
			  int is_expansion = -1)
{
  char field_name[8] = "itype1";
  const char *match_str;
  int k;

  /* If expansion was not specified, determine it dynamically. */
  if (is_expansion < 0)
    is_expansion = ((item->Owner() == NULL)
		    || item->Owner()->is_expansion());

  /* Search for a standard match first */
  for (k = '1'; k <= '9'; k++)
    {
      field_name[5] = (char) k;
      match_str = GetEntryStringField (ent_xfix, field_name);
      if (match_str[0] == 0)
	break;
      if (item->is_of_type (match_str))
	return 1;
    }

  /* Allow the name if there were no types to match */
  if ((k == '1')
      && (!is_expansion
	  || (GetEntryStringField (ent_xfix, "eitem1")[0] == 0))
      && GetEntryStringField (ent_xfix, "mod1code")[0])
    return 1;

  /* Next, (conditionally) search for a match for the Expansion Set. */
  if (!is_expansion)
    return 0;
  field_name[0] = 'e';
  for (k = '1'; k <= '9'; k++)
    {
      field_name[5] = (char) k;
      match_str = GetEntryStringField (ent_xfix, field_name);
      if (match_str[0] == 0)
	break;
      if (item->is_of_type (match_str))
	return 1;
    }

  /* No match */
  return 0;
}

/* Create a property list containing those properties associated with a
   magic prefix or suffix.  Used for both adding and testing properties. */
static d2sMagic *
generate_xfix_properties (table_entry_t ent_xfix)
{
  d2sMagic *	properties;
  d2sMagicProperty *prop;
  int		i;
  char		field_name[12] = "mod1code";
  const char *	mod_code;
  int		param, pmin, pmax;

  properties = new d2sMagic;
  for (i = '1'; i <= '9'; i++)
    {
      field_name[3] = (char) i;
      strcpy (&field_name[4], "code");
      mod_code = GetEntryStringField (ent_xfix, field_name);
      if (mod_code[0] == 0)
	break;
      strcpy (&field_name[4], "param");
      param = GetEntryIntegerField (ent_xfix, field_name);
      strcpy (&field_name[4], "min");
      pmin = GetEntryIntegerField (ent_xfix, field_name);
      strcpy (&field_name[4], "max");
      pmax = GetEntryIntegerField (ent_xfix, field_name);

      prop = new d2sMagicProperty (mod_code, param, pmin, pmax);
      if (prop->GetErrorMessage() != NULL)
	{
	  fprintf (stderr, "%s: Internal error: unable to create magic"
		   " property \"%s\";\n %s\n", progname, mod_code,
		   prop->GetErrorMessage());
	  delete prop;
	  continue;
	}
      if (properties->AddProperty (prop) < 0)
	{
	  fprintf (stderr, "%s: Internal error: unable to add magic"
		   " property \"%s\";\n %s\n", progname, mod_code,
		   properties->GetErrorMessage());
	  delete prop;
	  continue;
	}
    }

  return properties;
}

/********************************/

/* Create a new magically enhanced quality */
d2sMagicalQuality::d2sMagicalQuality (void)
  /* Clear the base fields */
  : d2sQuality ()
{
  quality_class = MAGIC_QUALITY;
  /* Clear the added fields.
     Even though magic qualities should never have both fields set to 0,
     there is no default prefix or suffix that would be appropriate
     for all items. */
  prefix = 0;
  suffix = 0;
  prefix_entry = NULL;
  suffix_entry = NULL;
}

d2sMagicalQuality::d2sMagicalQuality (table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality (item_entry)
{
  int		expansion;
  int		level;
  StringList	names;
  const char	*item_type;

  /* Initialize the class members */
  quality_class = MAGIC_QUALITY;
  prefix = 0;
  suffix = 0;
  prefix_entry = NULL;
  suffix_entry = NULL;

  /* If an item is classified as "normal", there is no way
     we're going to find a suitable prefix or suffix. */
  if ((item_type_entry == NULL)
      || GetEntryIntegerField (item_type_entry, "Normal"))
    {
      print_message ("Attempt to create a magical quality for a %s\n",
		     GetEntryStringField (item_type_entry, "ItemType"));
      error_str = "Wrong item type";
      return;
    }

  if (item_entry == NULL)
    /* This is an error, I think */
    return;

  /* By default, we only choose standard game modifiers.
     But if we're modifying an expansion set item, we may
     have to look at expansion modifiers to find a match. */
  expansion = (options.item.link.item_expansion
	       || (GetEntryIntegerField (item_entry, "version") >= 100));
  level = GetEntryIntegerField (item_entry, "level");
  item_type = (options.character.link.freeform ? NULL
	       : GetEntryStringField (item_type_entry, "code"));

  /* Start by choosing either a prefix or a suffix.
     According to The Arreat Summit, a magic item has
     a 50% chance of getting a prefix. */
  if (rand() % 2)
    {
      /* Compile a list of all possible prefixes */
      names = GetMagicPrefixesFor (item_type, expansion, False, level, 0, 0);
      if (names->count <= 1)
	{
	  fprintf (stderr, "%s: Internal error: no magic prefixes found"
		   " suitable for a %s\n", progname,
		   GetEntryStringField (item_type_entry, "ItemType"));
	  free (names);
	  /* Go on to try for a suffix */
	}
      else
	{
	  /* Choose one at random.
	     Remember, the first entry in the name list is empty. */
	  prefix = names->string[rand() % (names->count - 1) + 1].value;
	  prefix_entry = LookupIndexedTableEntry ("magicprefix", prefix);
	  free (names);
	}
    }

  /* According to The Arreat Summit, a magic item has a 75% chance
     of getting a suffix: 50% if the item has a prefix, and 100%
     if the item does not have a prefix (*50/50%) */
  if (!prefix || (rand() % 2))
    {
      /* Compile a list of all possible suffixes */
      names = GetMagicSuffixesFor (item_type, expansion, False, level, 0, 0);
      if (names->count <= 1)
	{
	  fprintf (stderr, "%s: Internal error: no magic suffixes found"
		   " suitable for a %s\n", progname,
		   GetEntryStringField (item_type_entry, "ItemType"));
	  free (names);
	  error_str = "Internal error";
	}
      else
	{
	  /* Choose one at random.
	     Remember, the first entry in the name list is empty. */
	  suffix = names->string[rand() % (names->count - 1) + 1].value;
	  suffix_entry = LookupIndexedTableEntry ("magicsuffix", suffix);
	  free (names);
	}
    }

  /* Update the level and color */
  UpdateRequired ();
}

/* Copy an existing magical quality. */
d2sMagicalQuality&
d2sMagicalQuality::operator= (const d2sMagicalQuality& source)
{
  /* Copy the base fields */
  this->d2sQuality::operator= (source);
  /* Copy our added fields */
  this->prefix = source.prefix;
  this->suffix = source.suffix;
  this->prefix_entry = source.prefix_entry;
  this->suffix_entry = source.suffix_entry;
  return *this;
}

d2sQuality *
d2sMagicalQuality::Copy (void)
{
  d2sMagicalQuality *new_quality = new d2sMagicalQuality;
  *new_quality = *this;
  return new_quality;
}

/* Create a new magically enhanced quality
   using data from the given bit stream. */
d2sMagicalQuality::d2sMagicalQuality (struct bit_stream *bstream,
				      table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality (item_entry)
{
  quality_class = MAGIC_QUALITY;
  /* Read the bit stream */
  Read (bstream);
}

/* Read the magical quality fields from a raw bit stream. */
void
d2sMagicalQuality::ReadQualitySpecificData (struct bit_stream *bstream)
{
  /* Read the prefix */
  prefix = (int) bstream_read_field (bstream, 11);
  prefix_entry = prefix
    ? LookupIndexedTableEntry ("magicprefix", prefix) : NULL;
  /* Read the suffix */
  suffix = (int) bstream_read_field (bstream, 11);
  suffix_entry = suffix
    ? LookupIndexedTableEntry ("magicsuffix", suffix) : NULL;

  /* Update the level and color */
  UpdateRequired ();
}

/* Write the magical quality fields out to a raw bit stream. */
void
d2sMagicalQuality::WriteQualitySpecificData (struct bit_stream *bstream)
{
  /* Write out the prefix and suffix */
  bstream_write_field (bstream, 11, prefix);
  bstream_write_field (bstream, 11, suffix);
}

/* Qualify an item's name, returning a newly allocated string */
char *
d2sMagicalQuality::QualifyName (const char *base_name) const
{
  char *ret_str;
  const char *pstr, *sstr;
  int plen = 0, blen, slen = 0;

  /* Figure out the prefix.  If we don't know the prefix,
     reserve space for a number. */
  if (prefix)
    {
      pstr = NULL;
      plen = sizeof ("Prefix 2047 ");
      if (prefix_entry != NULL)
	{
	  pstr = GetEntryStringField (prefix_entry, "Name");
	  if (pstr[0])
	    {
	      pstr = TranslateString (pstr);
	      plen = strlen (pstr) + 1;
	    }
	  else
	    pstr = NULL;
	}
    }

  /* Figure out the suffix.  If we don't know the suffix,
     reserve space for a number. */
  if (suffix)
    {
      sstr = NULL;
      slen = sizeof (" of Suffix 2047");
      if (suffix_entry != NULL)
	{
	  sstr = GetEntryStringField (suffix_entry, "Name");
	  if (sstr[0])
	    {
	      sstr = TranslateString (sstr);
	      slen = strlen (sstr) + 1;
	    }
	  else
	    sstr = NULL;
	}
    }

  /* Allocate space for the full name */
  blen = strlen (base_name) + 1;
  ret_str = (char *) xmalloc (plen + blen + slen);
  /* Start printing, using blen to keep track of the position */
  blen = 0;
  if (plen)
    {
      if (pstr != NULL)
	blen = sprintf (ret_str, "%s ", pstr);
      else
	blen = sprintf (ret_str, "Prefix %d ", prefix);
    }
  blen += sprintf (&ret_str[blen], "%s", base_name);
  if (slen)
    {
      if (sstr != NULL)
	sprintf (&ret_str[blen], " %s", sstr);
      else
	sprintf (&ret_str[blen], " of Suffix %d", suffix);
    }

  return ret_str;
}

/* Get the prefix as a string */
const char *
d2sMagicalQuality::Prefix (void) const
{
  return GetMagicPrefix (prefix);
}

/* Get the suffix as a string */
const char *
d2sMagicalQuality::Suffix (void) const
{
  return GetMagicSuffix (suffix);
}

/* Validate a prefix or suffix when changing.
   Returns the table entry for the prefix or suffix, or NULL on error. */
table_entry_t
d2sMagicalQuality::validate_xfix (int id, const char *table_name,
				  const char *Xfix)
{
  table_entry_t new_entry;

  new_entry = LookupIndexedTableEntry (table_name, id);
  if ((new_entry == NULL)
      || (GetEntryStringField (new_entry, "Name")[0] == 0))
    {
      if (!options.character.link.freeform || ((unsigned) id > 0x7ff))
	{
	  print_message ("%s number is out of range\n", Xfix);
	  error_str = "Prefix/suffix number is out of range";
	  return NULL;
	}
    }

  else if (my_item != NULL)
    {
      if (!options.item.link.item_expansion
	  && (my_item->Owner() != NULL)
	  && ! my_item->Owner()->is_expansion()
	  && (GetEntryIntegerField (new_entry, "version") >= 100))
	{
	  print_message ("%s is not available in the standard game\n", Xfix);
	  error_str = "Prefix/suffix is not available in the standard game";
	  return NULL;
	}

      /* TO-DO: this should use item_type_entry, not my_item */
      if (!options.character.link.freeform
	  /* Check for restrictions on the item type */
	  && ! match_item_to_xfix_types (my_item, new_entry))
	{
	  print_message ("%s cannot be applied to %s\n",
			 Xfix, my_item->Name());
	  error_str = "Prefix/suffix does not match item type";
	  return NULL;
	}
    }
  return new_entry;
}

/* Change the item's prefix. */
int
d2sMagicalQuality::ChangePrefix (int new_prefix)
{
  table_entry_t new_entry = NULL;

  if (prefix == new_prefix)
    /* Nothing to do. */
    return 0;

  if (read_only() || !options.item.edit.magic_name)
    {
      error_str = "You may not change an item's magic name";
      print_message (error_str);
      return -1;
    }

  if ((!new_prefix && !suffix) && !options.character.link.freeform)
    {
      error_str = "Magical quality must have either a prefix or a suffix";
      print_message (error_str);
      return -1;
    }

  if (new_prefix) {
    new_entry = validate_xfix (new_prefix, "magicprefix", "Prefix");
    if (new_entry == NULL)
      return -1;
  }

  prefix = new_prefix;
  prefix_entry = new_entry;

  if (options.item.link.quality_magic && (my_item != NULL))
    /* Change the item's magic properties to match the new name */
    RegenerateProperties (my_item->Properties());

  /* Update the quality's required level and color */
  UpdateRequired ();
  if (my_item != NULL)
    my_item->MarkDirty ();
  return 0;
}

/* Change the item's suffix. */
int
d2sMagicalQuality::ChangeSuffix (int new_suffix)
{
  table_entry_t new_entry = NULL;

  if (suffix == new_suffix)
    /* Nothing to do. */
    return 0;

  if (read_only() || !options.item.edit.magic_name)
    {
      error_str = "You may not change an item's magic name";
      print_message (error_str);
      return -1;
    }

  if ((!prefix && !new_suffix) && !options.character.link.freeform)
    {
      error_str = "Magical quality must have either a prefix or a suffix";
      print_message (error_str);
      return -1;
    }

  if (new_suffix) {
    new_entry = validate_xfix (new_suffix, "magicsuffix", "Suffix");
    if (new_entry == NULL)
      return -1;
  }

  suffix = new_suffix;
  suffix_entry = new_entry;

  if (options.item.link.quality_magic && (my_item != NULL))
    /* Change the item's magic properties to match the new name */
    RegenerateProperties (my_item->Properties());

  /* Update the quality's required level and color */
  UpdateRequired ();
  if (my_item != NULL)
    my_item->MarkDirty ();
  return 0;
}

/* Update the required level and color based on the prefix and suffix */
void
d2sMagicalQuality::UpdateRequired (void)
{
  int level_req;
  const char *cstr;

  /* The prefix and/or suffix may impose a level requirement.
     If we know it, set our required level to the larger one. */
  required_level = 0;
  color_code = NULL;
  expansion_mods = False;
  if (prefix_entry != NULL)
    {
      required_level = GetEntryIntegerField (prefix_entry, "levelreq");
      color_code = GetEntryStringField (prefix_entry, "transformcolor");
      if (color_code[0] == 0)
	color_code = NULL;
      if (GetEntryIntegerField (prefix_entry, "version") >= 100)
	expansion_mods = True;
    }
  if (suffix_entry != NULL)
    {
      level_req = GetEntryIntegerField (suffix_entry, "levelreq");
      if (level_req > required_level)
	required_level = level_req;
      /* Note: a color code on the suffix takes precedence over the prefix */
      cstr = GetEntryStringField (suffix_entry, "transformcolor");
      if (cstr[0])
	color_code = cstr;
      if (GetEntryIntegerField (suffix_entry, "version") >= 100)
	expansion_mods = True;
    }
}

/* Reset the magical properties for a magically enhanced item. */
void
d2sMagicalQuality::RegenerateProperties (d2sMagic *properties, int condense)
{
  d2sMagic	*to_add;

  /* Take care of base properties first */
  d2sQuality::RegenerateProperties (properties, 0);

  if (prefix_entry != NULL)
    {
      /* Add properties for the prefix */
      to_add = generate_xfix_properties (prefix_entry);
      *(properties) += *to_add;
      delete to_add;
    }

  if (suffix_entry != NULL)
    {
      /* Add properties for the suffix */
      to_add = generate_xfix_properties (suffix_entry);
      *(properties) += *to_add;
      delete to_add;
    }

  /* Canonicalize the property list */
  if (condense)
    properties->Generate ();
}

/********************************/

/* Create a new set quality */
d2sQPartOfASet::d2sQPartOfASet (void)
  /* Clear the base fields */
  : d2sQuality ()
{
  quality_class = PART_OF_A_SET;
  /* Clear the added fields. */
  set_id = -1;
  set_count = 0;
  set_entry = NULL;
  member_index = -1;
  num_members = 0;
  set_name = "(unknown set)";
  member_name = "(unknown set item)";
}

/* Create a set quality for a specific set item */
d2sQPartOfASet::d2sQPartOfASet (int set_number, table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality ()
{
  quality_class = PART_OF_A_SET;
  set_id = set_number;
  set_count = 0;
  set_entry = LookupIndexedTableEntry
    /* The set items table has an extra line between standard game sets
       and Expansion sets which is not counted in the ID!  HACK: */
    ("setitems", (set_id < 16) ? set_id : (set_id + 1));
  num_members = GetEntryIntegerField (set_entry, "NumItems");
  set_name = GetEntryStringField (set_entry, "Name");
  if (set_name[0])
    set_name = TranslateString (set_name);
  else
    set_name = "(unknown set)";
  /* This function does the work of looking up the set item,
     updating our fields, and installing the correct magic properties */
  SetItem (item_entry);
}

/* Copy an existing set quality. */
d2sQPartOfASet&
d2sQPartOfASet::operator= (const d2sQPartOfASet& source)
{
  /* Copy the base fields */
  this->d2sQuality::operator= (source);
  /* Copy our added fields */
  this->set_id = source.set_id;
  this->set_count = source.set_count;
  this->set_entry = source.set_entry;
  this->num_members = source.num_members;
  /* This assumes that the parent item is being copied as well.
     If we're copying the set quality onto a different item,
     this doesn't work. */
  this->member_index = source.member_index;
  this->set_name = source.set_name;
  this->member_name = source.member_name;
  return *this;
}

d2sQuality *
d2sQPartOfASet::Copy (void)
{
  d2sQPartOfASet *new_quality = new d2sQPartOfASet;
  *new_quality = *this;
  return new_quality;
}

/* Create a new part of a set using data from the given bit stream. */
d2sQPartOfASet::d2sQPartOfASet (struct bit_stream *bstream,
				table_entry_t item_entry)
  /* Clear the base fields */
  /* Note: we must NOT use our own version of SetItem, because that
     would try to update fields which have not been initialized. */
  : d2sQuality (item_entry)
{
  quality_class = PART_OF_A_SET;
  /* Read the bit stream */
  Read (bstream);
}

/* Read the set quality field from a raw bit stream. */
void
d2sQPartOfASet::ReadQualitySpecificData (struct bit_stream *bstream)
{
  /* Read the set ID */
  set_id = (int) bstream_read_field (bstream, 12);
  /* Initialize the set count to 0 */
  set_count = 0;

  /* Look up the set ID in our set database to find the name of the set */
  set_entry = LookupIndexedTableEntry
    ("setitems", (set_id < 16) ? set_id : (set_id + 1));
  set_name = GetEntryStringField (set_entry, "Name");
  if (set_name[0])
    set_name = TranslateString (set_name);
  else
    set_name = "(unknown set)";
  num_members = GetEntryIntegerField (set_entry, "NumItems");
  UpdateRequired ();
}

/* Set the type of item this quality is associated with.
   Overridden so that we can identify members of a set. */
void
d2sQPartOfASet::SetItem (d2sExtendedItem *new_item)
{
  /* Set the item
     (we do this manually instead of calling d2sQuality::SetItem,
     because we don't want it to call d2sQuality::SetItem(table_entry_t);
     we do that ourself in the next function.) */
  if ((my_item == NULL) || (new_item == NULL))
    my_item = new_item;
  if (strcmp (my_item->Code(), item_code) != 0)
    d2sQPartOfASet::SetItem ((my_item == NULL) ? (table_entry_t) NULL
			     : my_item->ItemTableEntry());
}

/* Above, continued */
void
d2sQPartOfASet::SetItem (table_entry_t item_entry)
{
  d2sQuality::SetItem (item_entry);
  if (item_entry == NULL)
    return;

  /* Update our fields */
  UpdateRequired ();
}

/* Write the set quality field out to a raw bit stream. */
void
d2sQPartOfASet::WriteQualitySpecificData (struct bit_stream *bstream)
{
  /* Write out the set ID */
  bstream_write_field (bstream, 12, set_id);
}

/* Qualify an item's name, returning a newly allocated string */
char *
d2sQPartOfASet::QualifyName (const char *base_name) const
{
  char *ret_str;
  int len;

  /* Write out the member name above the item's base name */
  len = strlen (member_name) + 1 + strlen (base_name) + 1;
  ret_str = (char *) xmalloc (len);
  sprintf (ret_str, "%s\n%s", member_name, base_name);
  return ret_str;
}

/* Get the name of the Nth member of the set.
   With no argument, the name of this member. */
const char *
d2sQPartOfASet::GetMemberName (int n) const
{
  char field_name[16];
  const char *str;

  if (n < 0)
    return member_name;

  if (set_entry == NULL)
    /* Unknown set */
    return "(member of unknown set)";

  if (n >= num_members)
    /* Invalid set member index */
    return "(bad set member index)";

  /* Do we have the member's name? */
  sprintf (field_name, "Item%d Suffix", n + 1);
  str = GetEntryStringField (set_entry, field_name);
  if (str[0] == 0)
    return "(unknown set member)";
  return TranslateString (str);
}

/* Compute the value of the 5-bit field
   following the item-specific data (property list count). */
int
d2sQPartOfASet::SetSetCount (void)
{
  int new_count;

  if (my_item == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: d2sQPartOfASet::SetSetCount\n"
		 " called but %p has not been assigned an item\n",
		 progname, this);
      error_str = "Internal error";
      return -1;
    }
  if (my_item->Properties() == NULL)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: d2sQPartOfASet::SetSetCount\n"
		 " called but %s (%p) has no magic properties\n",
		 progname, my_item->Name(), my_item);
      error_str = "Internal error";
      return -1;
    }

  new_count = my_item->Properties()->NumberOfPropertyLists();
  /* The 'count' appears to be (2^(n-1) - 1),
     where N is the number of property lists. */
  new_count = (1 << (new_count - 1)) - 1;
  if (new_count != set_count)
    {
      set_count = new_count;
      my_item->MarkDirty ();
    }
  return 0;
}

/* Set the value of the 5-bit field
   following the item-specific data (property list count).
   ***WARNING*** This should *only* be called when reading
   the number from a file.  NO VALIDITY CHECKING IS IMPLEMENTED! */
int
d2sQPartOfASet::SetSetCount (int new_count)
{
  set_count = new_count;
#if 0
  /* If we're only called when reading items,
     we should not mark the item dirty. */
  if (my_item != NULL)
    my_item->MarkDirty ();
#endif
  return 0;
}

/* Update the required level and color based on the set */
void
d2sQPartOfASet::UpdateRequired (void)
{
  const char *cstr;

  color_code = NULL;
  expansion_mods = 0;
  LookupMember ();

  /* Update the color; this is the same for all members of the set */
  if (GetEntryIntegerField (set_entry, "transform"))
    {
      /* Look up the color transformation for this set.
	 Requires a two-level table lookup; the "setitems" table
	 may contain a color index rather than a code. */
      cstr = GetEntryStringField (set_entry, "transformcolor");
      if (cstr[0])
	{
	  if (isdigit (cstr[0]))
	    cstr = GetEntryStringField
	      (LookupIndexedTableEntry ("colors", atoi (cstr)), "Code");
	  if (cstr[0])
	    color_code = cstr;
	}
    }

  expansion_mods = (GetEntryIntegerField (set_entry, "version") >= 100);
}

/* Find the set member based on the item type */
void
d2sQPartOfASet::LookupMember (void)
{
  char field_name[16] = "Item1 Lvlreq";
  const char *cstr;

  required_level = 0;
  /* We also update the set member name in this function. */
  member_name = "(unknown set item)";

  if (set_entry == NULL)
    {
      member_index = -1;
      return;
    }

  for (member_index = 0; member_index < num_members; member_index++)
    {
      /* Find the matching set member */
      field_name[4] = (char) ('1' + member_index);
      field_name[5] = '\0';
      if (strcmp (item_code,
		  GetEntryStringField (set_entry, field_name)) != 0)
	continue;

      /* Update the set member name */
      strcpy (&field_name[5], " Suffix");
      cstr = GetEntryStringField (set_entry, field_name);
      if (cstr[0])
	member_name = TranslateString (cstr);

      /* Update the required level */
      strcpy (&field_name[5], " Lvlreq");
      required_level = GetEntryIntegerField (set_entry, field_name);
      return;
    }
  /* Member not found! */
  member_index = -1;
}

/* Install the magical properties specified for this set item. */
void
d2sQPartOfASet::RegenerateProperties (d2sMagic *properties, int condense)
{
  const char	*mod_code;
  char		make_name[32];
  int		mod, param, pmin, pmax;
  d2sMagicProperty *prop;

  if (properties == NULL)
    return;

  /* Take care of base properties first */
  d2sQuality::RegenerateProperties (properties, 0);

  /* Read the first group of new properties from the setitems table */
  for (mod = 0; mod < 4; mod++)
    {
      sprintf (make_name, "I%dCode%d", member_index + 1, mod + 1);
      mod_code = GetEntryStringField (set_entry, make_name);
      if (mod_code[0] == 0)
	break;
      sprintf (make_name, "I%dParam%d", member_index + 1, mod + 1);
      param = GetEntryIntegerField (set_entry, make_name);
      sprintf (make_name, "I%dMin%d", member_index + 1, mod + 1);
      pmin = GetEntryIntegerField (set_entry, make_name);
      sprintf (make_name, "I%dMax%d", member_index + 1, mod + 1);
      pmax = GetEntryIntegerField (set_entry, make_name);
      prop = new d2sMagicProperty (mod_code, param, pmin, pmax);
      if (prop->GetErrorMessage() != NULL)
	{
	  fprintf (stderr, "%s: Internal error: unable to create magic"
		   " property \"%s\";\n %s\n", progname, mod_code,
		   prop->GetErrorMessage());
	  delete prop;
	  continue;
	}
      if (properties->AddProperty (prop) < 0)
	{
	  fprintf (stderr, "%s: Internal error: unable to add magic"
		   " property \"%s\";\n %s\n", progname, mod_code,
		   properties->GetErrorMessage());
	  delete prop;
	  continue;
	}
    }
  if (!mod)
    {
      if (debug)
	fprintf (stderr, "%s: Internal error: no magic properties found"
		 " for %s item #%d\n", progname,
		 TranslateString (GetEntryStringField (set_entry, "Name")),
		 member_index + 1);
      return;
    }

  /* Read the secondary groups of properties from the setitems table.
     As far as I know, only one property gets put in the second group.
     (At least, there's nothing in the table to indicate how many
     properties to add.) */
  for (mod = 'A'; mod <= 'J'; mod++)
    {
      sprintf (make_name, "I%dCode%c", member_index + 1, mod);
      mod_code = GetEntryStringField (set_entry, make_name);
      if (mod_code[0] == 0)
	break;
      sprintf (make_name, "I%dParam%c", member_index + 1, mod);
      param = GetEntryIntegerField (set_entry, make_name);
      sprintf (make_name, "I%dMin%c", member_index + 1, mod);
      pmin = GetEntryIntegerField (set_entry, make_name);
      sprintf (make_name, "I%dMax%c", member_index + 1, mod);
      pmax = GetEntryIntegerField (set_entry, make_name);
      /* Insert an end-of-list marker before the first
	 and second new properties */
      if (mod <= 'B')
	properties->AddProperty (new d2sMagicProperty);
      prop = new d2sMagicProperty (mod_code, param, pmin, pmax);
      if (prop->GetErrorMessage() != NULL)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to create magic"
		     " property \"%s\";\n %s\n", progname, mod_code,
		     prop->GetErrorMessage());
	  delete prop;
	  continue;
	}
      if (properties->AddProperty (prop) < 0)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to add magic"
		     " property \"%s\";\n %s\n", progname, mod_code,
		     properties->GetErrorMessage());
	  delete prop;
	  continue;
	}
    }

  /* Condense the list of properties into canonical format */
  if (condense)
    properties->Generate();
  /* Update the property list count for the set quality */
  SetSetCount ();
  return;
}

/********************************/

/* Create a new rare quality */
d2sRareQuality::d2sRareQuality (void)
  /* Clear the base fields */
  : d2sQuality ()
{
  quality_class = RARE_QUALITY;
  /* Clear the added fields. */
  memset (title_id, 0, sizeof (title_id));
  memset (hidden, 0, sizeof (hidden));
  memset (hidden_entry, 0, sizeof (hidden_entry));
}

/* Create a default rare quality valid for a given item */
d2sRareQuality::d2sRareQuality (table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality (item_entry)
{
  int		n;
  const char	*type_name;
  StringList	names;

  quality_class = RARE_QUALITY;
  memset (title_id, 0, sizeof (title_id));
  memset (hidden, 0, sizeof (hidden));
  memset (hidden_entry, 0, sizeof (hidden_entry));

  /* If an item is not classified as "rare", there is no way
     we're going to find a suitable prefix or suffix. */
  if ( ! GetEntryIntegerField (item_type_entry, "Rare")
       && !options.character.link.freeform)
    {
      print_message ("Attempt to create a rare quality for a %s\n",
		     GetEntryStringField (item_type_entry, "ItemType"));
      error_str = "Wrong item type";
      return;
    }

  /* Compile a list of all possible first names */
  type_name = (options.character.link.freeform ? NULL
	       : GetEntryStringField (item_type_entry, "code"));
  names = GetRareTitle1stWordsFor (type_name);
  if (names->count <= 1)
    {
      fprintf (stderr, "%s: Internal error: no rare first names found"
	       " suitable for a %s\n", progname,
	       TranslateString (item_code));
    }
  else
    {
      /* Choose one at random */
      title_id[0] = rand() % names->count;
      title_id[0] = names->string[title_id[0]].value;
    }
  free (names);

  /* Repeat for the second name */
  names = GetRareTitle2ndWordsFor (type_name);
  if (names->count <= 1)
    {
      fprintf (stderr, "%s: Internal error: no rare last names found"
	       " suitable for a %s\n", progname,
	       TranslateString (item_code));
    }
  else
    {
      /* Choose one at random */
      title_id[1] = rand() % names->count;
      title_id[1] = names->string[title_id[1]].value;
    }
  free (names);

  /* Generate up to six magic prefixes or suffixes.
     Each call is guaranteed to give us a name until we have
     3 prefixes or 3 suffixes, satisfying the minimum count.
     We get six properties if the random number generator
     happens to give us an equal number of evens as odds. */
  for (n = 0; n < 6; n++)
    if (GenerateHiddenName () < 0)
      break;

  /* Update our fields */
  UpdateRequired ();
}

/* Choose a prefix or suffix for one of the hidden names. */
int
d2sRareQuality::GenerateHiddenName (void)
{
  int		hf, expansion, rare, level;
  const char	*type_name;
  table_entry_t	item_entry;
  StringList	names;

  /* By default, we only choose standard game magic names.
     But if we're modifying an expansion set item, we may
     have to look at expansion names to find a match. */
  type_name = ((options.character.link.freeform || (item_type_entry == NULL))
	       ? NULL
	       : GetEntryStringField (item_type_entry, "code"));
  expansion = options.item.link.item_expansion;
  item_entry = LookupTableEntry ("misc", "code", item_code);
  if (item_entry == NULL) {
    item_entry = LookupTableEntry ("armor", "code", item_code);
    if (item_entry == NULL) {
      item_entry = LookupTableEntry ("weapons", "code", item_code);
    }
  }
  if (!expansion && (item_entry == NULL)
      || (GetEntryIntegerField (item_entry, "version") >= 100))
    expansion = True;
  level = GetEntryIntegerField (item_entry, "level");
  rare = !options.character.link.freeform;

  /* Start by choosing either a prefix or a suffix.
     According to The Arreat Summit, rare items have a 50/50% chance
     of each successive name being a prefix or suffix, up to a limit
     of 3 of each.  Either the choosing must stop or a potential name
     is skipped when one side or the other has reached its limit. */
  hf = rand() % 2;
  /* Find the next available entry for this type of name */
  while ((hf < 6) && hidden[hf])
    hf += 2;
  if (hf >= 6)
    /* No more entries; skip this name. */
    return 0;

  switch (hf & 1)
    {
    case 0:
      /* Compile a list of all possible prefixes
	 (except ones in the same group as the prefixes we already have) */
      names = GetMagicPrefixesFor
	(type_name, expansion, rare, level,
	 GetEntryIntegerField (hidden_entry[0], "group"),
	 GetEntryIntegerField (hidden_entry[2], "group"));
      break;

    case 1:
      /* Compile a list of all possible suffixes
	 (except ones in the same group as the prefixes we already have) */
      names = GetMagicSuffixesFor
	(type_name, expansion, rare, level,
	 GetEntryIntegerField (hidden_entry[1], "group"),
	 GetEntryIntegerField (hidden_entry[3], "group"));
      break;
    }

  if (names->count <= 1)
    {
      fprintf (stderr, "%s: Internal error: no magic %sfixes found"
	       " suitable for a %s\n", progname,
	       (hf & 1) ? "suf" : "pre", TranslateString (item_code));
      free (names);
      error_str = "Internal error";
      return -1;
    }

  /* Choose one at random.
     Remember, the first entry in the name list is empty. */
  hidden[hf] = names->string[rand() % (names->count - 1) + 1].value;
  hidden_entry[hf] = LookupIndexedTableEntry
    ((hf & 1) ? "magicsuffix" : "magicprefix", hidden[hf]);
  free (names);
  return 0;
}

/* Copy an existing rare quality. */
d2sRareQuality&
d2sRareQuality::operator= (const d2sRareQuality &source)
{
  /* Copy the base fields */
  this->d2sQuality::operator= (source);
  /* Copy our added fields */
  memcpy (this->title_id, source.title_id, sizeof (this->title_id));
  memcpy (this->hidden, source.hidden, sizeof (this->hidden));
  memcpy (this->hidden_entry, source.hidden_entry,
	  sizeof (this->hidden_entry));
  return *this;
}

d2sQuality *
d2sRareQuality::Copy (void)
{
  d2sRareQuality *new_quality = new d2sRareQuality;
  *new_quality = *this;
  return new_quality;
}

/* Create a new rare quality using data from the given bit stream. */
d2sRareQuality::d2sRareQuality (struct bit_stream *bstream,
				table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality (item_entry)
{
  quality_class = RARE_QUALITY;
  /* Read the bit stream */
  Read (bstream);
}

/* Read the rare quality fields from a raw bit stream. */
void
d2sRareQuality::ReadQualitySpecificData (struct bit_stream *bstream)
{
  int hf;

  /* Read the title */
  title_id[0] = (unsigned char) bstream_read_field (bstream, 8);
  title_id[1] = (unsigned char) bstream_read_field (bstream, 8);

  /* There are 6 more fields, all of which are optional. */
  for (hf = 0; hf < 6; hf++)
    {
      if (bstream_read_field (bstream, 1)) {
	hidden[hf] = bstream_read_field (bstream, 11);
	hidden_entry[hf] = LookupIndexedTableEntry
	  ((hf & 1) ? "magicsuffix" : "magicprefix", hidden[hf]);
      }
      else {
	hidden[hf] = 0;
	hidden_entry[hf] = NULL;
      }
    }
  /* Update our required level and color */
  UpdateRequired ();
}

/* Write the rare quality fields out to a raw bit stream. */
void
d2sRareQuality::WriteQualitySpecificData (struct bit_stream *bstream)
{
  int hf;

  /* Write out the title */
  bstream_write_field (bstream, 8, title_id[0]);
  bstream_write_field (bstream, 8, title_id[1]);
  /* Write out the unknown fields. */
  for (hf = 0; hf < 6; hf++)
    {
      if (hidden[hf]) {
	bstream_write_field (bstream, 1, 1);
	bstream_write_field (bstream, 11, hidden[hf]);
      } else {
	bstream_write_field (bstream, 1, 0);
      }
    }
}

/* Qualify an item's name, returning a newly allocated string */
char *
d2sRareQuality::QualifyName (const char *base_name) const
{
  char *ret_str;
  const char *t1str, *t2str;

  t1str = Title1();
  if (t1str == NULL)
    t1str = "";
  t2str = Title2();
  if (t2str == NULL)
    t2str = "";

  /* Allocate space for the full name */
  ret_str = (char *) xmalloc (strlen (t1str) + 1 + strlen (t2str) + 2
			      + strlen (base_name) + 1);

  sprintf (ret_str, "%s %s\n%s", t1str, t2str, base_name);
  return ret_str;
}

/* Get the first or second word of the title as a string */
const char *
d2sRareQuality::Title1 (void) const
{
  return GetRareTitleWord (title_id[0]);
}

const char *
d2sRareQuality::Title2 (void) const
{
  return GetRareTitleWord (title_id[1]);
}

/* Get one of the hidden fields as a string */
const char *
d2sRareQuality::HiddenField (int n) const
{
  const char *pstr;

  if ((unsigned) n > XtNumber (hidden))
    /* Bad field number! */
    return NULL;

  if ( ! hidden[n])
    /* No hidden name here */
    return "";

  pstr = GetEntryStringField (hidden_entry[n], "Name");
  if (pstr[0])
    return TranslateString (pstr);
  return "(unknown)";
}

/* Change the first or second word of the title.  The value need not
   be predefined, but it is restricted to be between the first and
   last defined ID's for the prefix or suffix. */
int
d2sRareQuality::ChangeTitle (int id1, int id2)
{
  int num_prefixes;
  int num_suffixes;
  table_entry_t ent_prefix, ent_suffix;

  if ((title_id[0] == id1) && (title_id[1] == id2))
    /* Nothing to do. */
    return 0;

  if (read_only() || !options.item.edit.magic_name)
    {
      error_str = "Rare names cannot be edited";
      print_message (error_str);
      return -1;
    }

  /* Although rare prefixes and rare suffixes are in separate tables,
     the appear to be combined to get the index numbers --
     the first prefix ID is the number following the last suffix.
     Also, the first suffix with an index of 0 has an ID of 1. */
  num_prefixes = GetTableSize ("rareprefix");
  num_suffixes = GetTableSize ("raresuffix");

  if (((id1 <= num_suffixes) || (id1 > num_suffixes + num_prefixes))
      && (id1 != title_id[0]))
    {
      if (!options.character.link.freeform || (id1 < 0) || (id1 > 0xff))
	{
	  print_message ("Invalid rare prefix ID");
	  error_str = "Invalid rare prefix ID";
	  return -1;
	}
    }

  if (((id2 <= 0) || (id2 > num_suffixes))
      && (id1 != title_id[1]))
    {
      if (!options.character.link.freeform || (id2 < 0) || (id2 > 0xff))
	{
	  print_message ("Invalid rare suffix ID");
	  error_str = "Invalid rare suffix ID";
	  return -1;
	}
    }

  ent_prefix = LookupIndexedTableEntry ("rareprefix",
					id1 - 1 - num_suffixes);
  ent_suffix = LookupIndexedTableEntry ("raresuffix", id2 - 1);
  /* Check for expansion set names */
  if (!options.item.link.item_expansion && (my_item->Owner() != NULL)
      && !my_item->Owner()->is_expansion())
    {
      if ((GetEntryIntegerField (ent_prefix, "version") >= 100)
	  || (GetEntryIntegerField (ent_suffix, "version") >= 100))
	{
	  print_message ("Title \"%s %s\" is not available in the standard"
			 " game\n", TranslateString (GetEntryStringField
						     (ent_prefix, "name")),
			 TranslateString (GetEntryStringField
					  (ent_suffix, "name")));
	  error_str = "Title is not available in the standard game";
	  return -1;
	}
    }

  /* Check for restrictions on the item type */
  if (!options.character.link.freeform && (my_item != NULL))
    {
      if ( ! match_item_to_xfix_types (my_item, ent_prefix)
	   || ! match_item_to_xfix_types (my_item, ent_suffix))
	{
	  print_message ("Title \"%s %s\" cannot be applied to %s\n",
			 TranslateString (GetEntryStringField
					  (ent_prefix, "name")),
			 TranslateString (GetEntryStringField
					  (ent_suffix, "name")),
			 TranslateString (item_code));
	  error_str = "Title does not match item type";
	  return -1;
	}
    }

  title_id[0] = id1;
  title_id[1] = id2;
  if (my_item != NULL)
    my_item->MarkDirty ();
  return 0;
}

/* Change any of the unknown fields. */
int
d2sRareQuality::ChangeHiddenField (int field, int data)
{
  table_entry_t new_entry;
  int new_group, hf;

  if ((unsigned) field >= XtNumber (hidden))
    {
      fprintf (stderr, "%s: Internal error: invalid field number for"
	       " d2sRareQuality::ChangeUnknownField(%d,%d)\n",
	       progname, field, data);
      error_str = "Invalid field number";
      return -1;
    }

  if (hidden[field] == data)
    /* Nothing to do. */
    return 0;

  if (read_only() || !options.item.edit.magic_name)
    {
      error_str = "Rare names cannot be edited";
      print_message (error_str);
      return -1;
    }

  new_entry = (data ? (LookupIndexedTableEntry
		       ((field & 1) ? "magicsuffix" : "magicprefix", data))
	       : NULL);
  if (data && !GetEntryIntegerField (new_entry, "group"))
    {
      if (!options.character.link.freeform || (data < 0) || (data > 0x7ff))
	{
	  error_str = "Hidden name ID is out of range";
	  print_message (error_str);
	  return -1;
	}
    }

  if (data && !options.character.link.freeform)
    {
      if ((my_item != NULL)
	  && ! match_item_to_xfix_types (my_item, new_entry))
	{
	  print_message ("The name \"%s\" (%d) is not valid for a %s.\n",
			 TranslateString (GetEntryStringField
					  (new_entry, "Name")),
			 data, GetEntryStringField
			 (item_type_entry, "ItemType"));
	  error_str = "Hidden name is not valid for this item";
	  return -1;
	}

      /* Check whether a name in the same group is already present */
      new_group = GetEntryIntegerField (new_entry, "group");
      for (hf = (field & 1); hf < (int) XtNumber (hidden_entry); hf += 2)
	{
	  if (hf == field)
	    continue;
	  if (new_group == GetEntryIntegerField (hidden_entry[hf], "group"))
	    {
	      print_message
		("The name \"%s\" (%d) is in the same group as"
		 "\"%s\" (%d); both cannot be set on the same item.",
		 TranslateString (GetEntryStringField (new_entry, "Name")),
		 data, TranslateString (GetEntryStringField
					(hidden_entry[hf], "Name")),
		 hidden[hf]);
	      error_str = "Hidden name duplicates an existing hidden name";
	      return -1;
	    }
	}
    }

  hidden[field] = data;
  hidden_entry[field] = new_entry;

  /* Alter the item's magic properties to match the new name */
  if (options.item.link.quality_magic && (my_item != NULL))
    RegenerateProperties (my_item->Properties());

  UpdateRequired ();
  if (my_item != NULL)
    my_item->MarkDirty ();
  return 0;
}

/* Update the required level and color based on the hidden fields */
void
d2sRareQuality::UpdateRequired (void)
{
  int hf, level_req;
  const char *cstr;

  /* Reset the required level */
  required_level = 0;
  expansion_mods = 0;

  /* For each hidden field, look up the corresponding magic
     prefix or suffix and pick out any level requirement. */
  for (hf = 0; hf < (int) XtNumber (hidden); hf++)
    {
      if (hidden_entry[hf] != NULL) {
	level_req = GetEntryIntegerField (hidden_entry[hf], "levelreq");
	if (level_req > required_level)
	  required_level = level_req;
	if (GetEntryIntegerField (hidden_entry[hf], "version") >= 100)
	  expansion_mods = True;
      }
    }

  /* The color codes require looping in a different order.
     The precedence is the first hidden field having a color
     out of the suffixes, then the prefixes. */
  color_code = NULL;
  for (hf = 1; hf < (int) XtNumber (hidden); hf += 2)
    {
      if (hidden_entry[hf] != NULL) {
	cstr = GetEntryStringField (hidden_entry[hf], "transformcolor");
	if (cstr[0]) {
	  color_code = cstr;
	  break;
	}
      }
    }
  if (color_code == NULL) {
    for (hf = 0; hf < (int) XtNumber (hidden); hf += 2)
      {
	if (hidden_entry[hf] != NULL) {
	  cstr = GetEntryStringField (hidden_entry[hf], "transformcolor");
	  if (cstr[0]) {
	    color_code = cstr;
	    break;
	  }
	}
      }
  }
}

/* Reset the magical properties for a rare item. */
void
d2sRareQuality::RegenerateProperties (d2sMagic *properties, int condense)
{
  d2sMagic	*to_add;
  int		hf;

  /* Take care of base properties first */
  d2sQuality::RegenerateProperties (properties, 0);

  for (hf = 0; hf < (int) XtNumber (hidden_entry); hf++)
    {
      if (hidden_entry[hf] == NULL)
	continue;
      /* Add properties for this hidden name */
      to_add = generate_xfix_properties (hidden_entry[hf]);
      *properties += *to_add;
      delete to_add;
    }

  /* Canonicalize the property list */
  if (condense)
    properties->Generate ();
}

/********************************/

/* Create a new unique quality */
d2sUniqueQuality::d2sUniqueQuality (void)
  /* Clear the base fields */
  : d2sQuality ()
{
  quality_class = UNIQUE_QUALITY;
  /* Clear the added fields. */
  unique_id = -1;
  unique_name = "(unknown unique item)";
  unique_entry = NULL;
}

/* Copy an existing unique quality. */
d2sUniqueQuality&
d2sUniqueQuality::operator= (const d2sUniqueQuality &source)
{
  /* Copy the base fields */
  this->d2sQuality::operator= (source);
  /* Copy our added fields */
  this->unique_id = source.unique_id;
  this->unique_name = source.unique_name;
  this->unique_entry = source.unique_entry;
  return *this;
}

d2sQuality *
d2sUniqueQuality::Copy (void)
{
  d2sUniqueQuality *new_quality = new d2sUniqueQuality;
  *new_quality = *this;
  return new_quality;
}

/* Create a specific unique quality */
d2sUniqueQuality::d2sUniqueQuality (int id, table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality (item_entry)
{
  quality_class = UNIQUE_QUALITY;
  unique_id = id;
  /* Update our name, level requirement, and color. */
  UpdateRequired ();
}

/* Create a new unique quality using data from the given bit stream. */
d2sUniqueQuality::d2sUniqueQuality (struct bit_stream *bstream,
				    table_entry_t item_entry)
  /* Clear the base fields */
  : d2sQuality (item_entry)
{
  quality_class = UNIQUE_QUALITY;
  /* Read the bit stream */
  Read (bstream);
}

/* Read the unique quality field from a raw bit stream. */
void
d2sUniqueQuality::ReadQualitySpecificData (struct bit_stream *bstream)
{
  /* Read the unique ID */
  unique_id = (int) bstream_read_field (bstream, 12);

  /* Update our name, level requirement, and color. */
  UpdateRequired ();
}

/* Write the unique quality field out to a raw bit stream. */
void
d2sUniqueQuality::WriteQualitySpecificData (struct bit_stream *bstream)
{
  /* Write out the unique ID */
  bstream_write_field (bstream, 12, unique_id);
}

/* Qualify an item's name, returning a newly allocated string */
char *
d2sUniqueQuality::QualifyName (const char *base_name) const
{
  char *ret_str;
  int len;

  /* If the unique name is empty, the base name is the full name. */
  if (!unique_name[0])
    return xstrdup (base_name);

  /* If the item's "Skip Name" field is set,
     the unique name is the full name. */
  if ((my_item != NULL)
      && GetEntryIntegerField (my_item->ItemTableEntry(), "SkipName"))
    return xstrdup (unique_name);

  len = strlen (unique_name) + 1 + strlen (base_name) + 1;
  ret_str = (char *) xmalloc (len);
  snprintf (ret_str, len, "%s\n%s", unique_name, base_name);

  return ret_str;
}

/* Update the required level and color based on the unique item */
void
d2sUniqueQuality::UpdateRequired (void)
{
  const char *cstr;

  required_level = 0;
  color_code = NULL;
  expansion_mods = False;
  /* We also update the unique name while we're here. */
  unique_name = "";
  unique_entry = NULL;

  if (unique_id == 0xfff)
    /* This unique has no entry in the uniqueitems table.
       Applies to a couple of quest items. */
    return;

  /* Update the required level */
  unique_entry = LookupIndexedTableEntry ("uniqueitems", unique_id);
  required_level = GetEntryIntegerField (unique_entry, "LevelReq");

  /* Update the name */
  unique_name = GetEntryStringField (unique_entry, "name");
  if (unique_name[0])
    unique_name = TranslateString (unique_name);
  else
    unique_name = "(unknown unique item)";

  /* Update the color */
  if (GetEntryIntegerField (unique_entry, "invtransform"))
    {
      cstr = GetEntryStringField (unique_entry, "transformcolor");
      if (cstr[0])
	{
	  if (isdigit (cstr[0]))
	    cstr = GetEntryStringField
	      (LookupIndexedTableEntry ("colors", atoi (cstr)),
	       "Code");
	  if (cstr[0])
	    color_code = cstr;
	}
    }

  /* Update whether we are an expansion item */
  expansion_mods = (GetEntryIntegerField (unique_entry, "version") >= 100);
}

/* Set an item's magic properties to those specified by a
   unique item's entry in the "uniqueitems" table. */
void
d2sUniqueQuality::RegenerateProperties (d2sMagic *properties, int condense)
{
  const char	*mod_code;
  char		make_name[20];
  int		mod, param, pmin, pmax;
  d2sMagicProperty *prop;

  if (properties == NULL)
    return;

  /* Take care of base properties first */
  d2sQuality::RegenerateProperties (properties, 0);

  /* Read the new properties from the uniqueitems table */
  for (mod = 1; mod <= 10; mod++)
    {
      sprintf (make_name, "ItemMod%dCode", mod);
      mod_code = GetEntryStringField (unique_entry, make_name);
      if (mod_code[0] == 0)
	break;
      sprintf (make_name, "ItemMod%dParam", mod);
      param = GetEntryIntegerField (unique_entry, make_name);
      sprintf (make_name, "ItemMod%dMin", mod);
      pmin = GetEntryIntegerField (unique_entry, make_name);
      sprintf (make_name, "ItemMod%dMax", mod);
      pmax = GetEntryIntegerField (unique_entry, make_name);
      prop = new d2sMagicProperty (mod_code, param, pmin, pmax);
      if (prop->GetErrorMessage() != NULL)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to create magic"
		     " property \"%s\";\n %s\n", progname, mod_code,
		     prop->GetErrorMessage());
	  delete prop;
	  continue;
	}
      if (properties->AddProperty (prop) < 0)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to add magic"
		     " property \"%s\";\n %s\n", progname, mod_code,
		     properties->GetErrorMessage());
	  delete prop;
	}
    }

  /* Condense the list of properties into canonical format */
  if (condense)
    properties->Generate();
  return;
}

/********************************/

/* Create a new crafted quality. */
d2sCraftedQuality::d2sCraftedQuality (void)
    : d2sRareQuality()
{
  quality_class = CRAFTED_QUALITY;
  /* All crafted items are Expansion Set items */
  expansion_mods = True;
  craft_entry = NULL;
  return;
}

/* Create a default crafted quality valid for a given item */
d2sCraftedQuality::d2sCraftedQuality (table_entry_t item_entry)
    : d2sRareQuality (item_entry)
{
  quality_class = CRAFTED_QUALITY;
  expansion_mods = True;
  find_craft_entry ();
  return;
}

/* Copy an existing crafted quality. */
d2sCraftedQuality&
d2sCraftedQuality::operator= (const d2sCraftedQuality &source)
{
  this->d2sRareQuality::operator= (source);
  this->craft_entry = source.craft_entry;
  return *this;
}

d2sQuality *
d2sCraftedQuality::Copy (void)
{
  d2sCraftedQuality *new_quality = new d2sCraftedQuality;
  *new_quality = *this;
  return new_quality;
}

/* Create a new crafted quality using data from the given bit stream. */
d2sCraftedQuality::d2sCraftedQuality (struct bit_stream *bstream,
				      table_entry_t item_entry)
  : d2sRareQuality (item_entry)
{
  quality_class = CRAFTED_QUALITY;
  expansion_mods = True;
  find_craft_entry ();
  Read (bstream);
}

/* Find the entry in the cube recipies table that was (probably)
   used (or could be used) to craft this item. */
void
d2sCraftedQuality::find_craft_entry (void)
{
  d2sMagic	*props;
  table_entry_t	tent;
  const char	*cstr;
  char		match_code[8];
  int		i, l;
  static int	min = 0, max = 0;

  craft_entry = NULL;
  /* If we have no item code, leave the entry blank. */
  if (!item_code[0])
    return;

  if (!max)
    {
      /* Get the extent of the recipies that produce crafted items */
      max = GetTableSize ("cubemain");
      for (min = 0; min < max; min++)
	{
	  tent = LookupIndexedTableEntry ("cubemain", min);
	  cstr = GetEntryStringField (tent, "output");
	  if (strstr (cstr, ",crf") != NULL)
	    break;
	}
      for ( ; max > min; max--)
	{
	  tent = LookupIndexedTableEntry ("cubemain", max - 1);
	  cstr = GetEntryStringField (tent, "output");
	  if (strstr (cstr, ",crf") != NULL)
	    break;
	}
    }

  /* Get the current magic properties of the given item */
  props = (my_item == NULL) ? NULL : my_item->Properties();

  /* Search the recipies for one whose output is our item.
     Caution: recipies freely use either the item code or
     an item type, so we must check both! */
  for (i = min; i < max; i++)
    {
      tent = LookupIndexedTableEntry ("cubemain", i);
      cstr = GetEntryStringField (tent, "output");
      if ((strncmp (cstr, "usetype,", strlen ("usetype,")) == 0)
	  || (strncmp (cstr, "useitem,", strlen ("useitem,")) == 0))
	cstr = GetEntryStringField (tent, "input 1");
      l = strcspn (cstr, ",");
      if (l >= (int) sizeof (match_code))
	l = sizeof (match_code) - 1;
      memcpy (match_code, cstr, l);
      match_code[l] = '\0';
      if ((strcmp (item_code, match_code) != 0)
	  && !IsTypeAMemberOf (GetEntryStringField (item_type_entry, "type"),
			       match_code))
	continue;

      /* We have matched the item.  Try to match the magic properties. */
      if (props == NULL)
	{
	  /* Nothing to match; choose a recipe at random */
	  if ((craft_entry == NULL) || (rand() & 16))
	    craft_entry = tent;
	  continue;
	}
      cstr = GetEntryStringField (tent, "mod 1");
      if (props->Lookup (cstr) == NULL)
	/* Not a match */
	continue;
      /* Check a second modifier just to be sure */
      cstr = GetEntryStringField (tent, "mod 2");
      if (cstr[0] && props->Lookup (cstr) == NULL)
	continue;

      /* It's a match! */
      craft_entry = tent;
      break;
    }
}

/* Set the type of item this quality is associated with.
   Overridden so that we can figure out how this item was made. */
void
d2sCraftedQuality::SetItem (d2sExtendedItem *new_item)
{
  /* Set the item
     (we do this manually instead of calling d2sQuality::SetItem,
     because we don't want it to call d2sQuality::SetItem(table_entry_t);
     we do that ourself in the next function.) */
  if ((my_item == NULL) || (new_item == NULL))
    my_item = new_item;
  d2sCraftedQuality::SetItem ((my_item == NULL) ? (table_entry_t) NULL
			      : my_item->ItemTableEntry());
}

/* Above, continued */
void
d2sCraftedQuality::SetItem (table_entry_t item_entry)
{
  d2sQuality::SetItem (item_entry);

  /* Find our recipe */
  find_craft_entry ();
}

/* Update the required level and color based on the hidden fields */
void
d2sCraftedQuality::UpdateRequired (void)
{
  int hf, level_req;

  /* Reset the required level */
  required_level = 0;
  expansion_mods = 0;

  /* For each hidden field, look up the corresponding magic
     prefix or suffix and pick out any level requirement. */
  for (hf = 0; hf < (int) XtNumber (hidden); hf++)
    {
      if (hidden_entry[hf] != NULL) {
	level_req = GetEntryIntegerField (hidden_entry[hf], "levelreq");
	if (level_req > required_level)
	  required_level = level_req;
	if (GetEntryIntegerField (hidden_entry[hf], "version") >= 100)
	  expansion_mods = True;
      }
    }

  /* Crafted items appear to ignore any coloring (except when gemmed). */
  color_code = NULL;
}

/* Reset the magical properties for a crafted item. */
void
d2sCraftedQuality::RegenerateProperties (d2sMagic *properties, int condense)
{
  const char	*mod_code;
  char		make_name[20];
  int		mod, param, pmin, pmax;
  d2sMagicProperty *prop;

  if (properties == NULL)
    return;

  /* Take care of base and rare properties first */
  d2sRareQuality::RegenerateProperties (properties, 0);

  /* Add back (hopefully the same) properties
     that were originally bestowed on this crafted item */
  for (mod = 1; mod <= 9; mod++)
    {
      sprintf (make_name, "mod %d", mod);
      mod_code = GetEntryStringField (craft_entry, make_name);
      if (mod_code[0] == 0)
	break;
      sprintf (make_name, "mod %d param", mod);
      param = GetEntryIntegerField (craft_entry, make_name);
      sprintf (make_name, "mod %d min", mod);
      pmin = GetEntryIntegerField (craft_entry, make_name);
      sprintf (make_name, "mod %d max", mod);
      pmax = GetEntryIntegerField (craft_entry, make_name);
      prop = new d2sMagicProperty (mod_code, param, pmin, pmax);
      if (prop->GetErrorMessage() != NULL)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to create magic"
		     " property \"%s\";\n %s\n", progname, mod_code,
		     prop->GetErrorMessage());
	  delete prop;
	  continue;
	}
      if (properties->AddProperty (prop) < 0)
	{
	  if (debug)
	    fprintf (stderr, "%s: Internal error: unable to add magic"
		     " property \"%s\";\n %s\n", progname, mod_code,
		     properties->GetErrorMessage());
	  delete prop;
	}
    }

  /* Canonicalize the property list */
  if (condense)
    properties->Generate ();
  return;
}
