/* Various utilities.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef UTIL_H
#define UTIL_H

#include <stddef.h>

/* Convenience */
#ifndef XtNumber
# define XtNumber(array) (sizeof (array) / sizeof ((array)[0]))
#endif
#ifndef True
# define True 1
# define False 0
#endif

/* Global variables */
extern const char *progname;
extern void *stdui;	/* UI element associated with messages, or NULL */

/* The following structure is used in traversing a data stream. */
struct data_stream {
  unsigned char *base;		/* Start of the stream */
  unsigned char *ptr;		/* Current pointer into the stream
				   (next byte to read/write) */
  unsigned char *end;		/* End of the stream */
  unsigned long size;		/* Bytes allocated */
};

/* The following structure is used in traversing a data stream by bits. */
struct bit_stream {
  unsigned char *base;		/* Start of the data */
  unsigned long ptr;		/* Current pointer into the stream
				   (next bit to read/write) */
  unsigned long size;		/* Number of bits in the data */
  unsigned long aloc;		/* Number of bytes allocated */
};

/* Quick stream access macros */
#define dstream_set(stream,data,offset,maxlen)		\
	{ (stream).base = (unsigned char *) (data);	\
	  (stream).ptr = &(stream).base[offset];	\
	  (stream).end = &(stream).base[maxlen];	\
	  (stream).size = (maxlen);	}
#define dstream_eof(stream) ((stream).ptr >= (stream).end)
#define dstream_read_item(stream,type) (*(((type *) (stream).ptr)++))
#define dstream_read(stream,buf,len)			\
	{ memcpy ((buf), (stream).ptr, (len)); (stream).ptr += len; }
#define dstream_skip(stream,len) { (stream).ptr += (len); }

#define bstream_set(stream,data,offset,maxlen)		\
	{ (stream).base = (unsigned char *) (data);	\
	  (stream).ptr = (offset);			\
	  (stream).size = (maxlen) * 8;			\
	  (stream).aloc = maxlen; }

#ifdef __cplusplus
extern "C" {
#endif /* C++ */

/* Allocation functions that either succeed or abort the program */
void *xmalloc (size_t size);
void *xrealloc (void *ptr, size_t size);
char *xstrdup (const char *str);
/* Should probably add getcwd too, for portability */

/* An extension of sprintf; append the format to an existing
   dynamic string, resizing the string to accomodate the extra
   message and returning a (possibly changed) pointer to the string. */
char *scatprintf (char *str, const char *fmt, ...);

/* Find a file among a set of default or user-defined paths. */
char *xfindfile (/* Subdirectory in which the file *should* be found */
		 const char *subdir,
		 /* Base part of the filename */
		 const char *base_name,
		 /* File extension */
		 const char *ext,
		 /* Path where the file is usually installed */
		 const char *inst_path);

/* Back up an existing file; return the name of the backup */
char *backup_old_file (const char *);

/* Stream access functions */
void dstream_write (struct data_stream *, const void *buf, unsigned int len);
unsigned long bstream_read_field (struct bit_stream *, int bits);
void bstream_write_field (struct bit_stream *, int bits, unsigned long value);

/* These functions should be defined by the GUI: */

/* Print a warning or informational message.
   The intent is to just show the message without pausing,
   leaving it somewhere that the user can review at leisure. */
void print_message (const char *fmt, ...);

/* Display an error message.
   The intent is a pop-up dialog or notice where the UI should
   stop and wait for the user to acknowledge the error. */
void display_error (const char *fmt, ...);

/* Display a question.
   The second argument indicates how many possible answers there are,
   and is followed by a string for each answer, the first of which
   is the standard "Cancel" answer and the second the standard "OK"
   answer.  The list of answers is followed by the printf format string. */
int display_question (int default_answer, int num_answers, ...);

#ifdef __cplusplus
}
#endif /* C++ */

#endif /* UTIL_H */
