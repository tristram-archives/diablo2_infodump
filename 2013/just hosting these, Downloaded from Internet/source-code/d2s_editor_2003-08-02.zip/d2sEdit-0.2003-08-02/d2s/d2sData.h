/* Definition of a C++ class that holds an internal representation
 * of a Diablo II v1.09 saved game file.
 * Copyright (C) 2002 Trevin Beattie (http://www.xmission.com/~trevin/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef D2SDATA_H
#define D2SDATA_H

#include <stddef.h>
#include <stdint.h>
#include "define.h"
#include "functions.h"
#include "tables.h"

#ifndef __cplusplus
#error "You need a C++ compiler to use this module"
#endif

/* Forward declarations of classes used by d2sData */
class d2sItem;

/* Structure used for the item lists (way below) */
struct item_list_t {
  int		count;
  d2sItem *	head;
  d2sItem **	tail;
};

class d2sData {
 public:
  /********	FILE-RELATED FUNCTIONS:		********/

  /* Create a new character out of thin air;
     a default character class and name are provided */
  d2sData (int char_class = AMAZON_CLASS, const char *name = NULL,
	   int expansion_character = 0, int hardcore_mode = 0);

  /* Open a saved character file */
  d2sData (const char *filename);

  ~d2sData ();		// Destructor

  /* Set the UI-specific data pointer for this object.
     Can only be called once. */
  int SetUI (void *);

  /* Retrieve the UI-specific data pointer. */
  void *GetUI (void) const { return ui_data; }

  /* Return the file associated with this object.  If this object
     was created from scratch, or the file failed to load, this
     function returns NULL. */
  const char *SourceFileName (void) const { return filename; }

  /* Save a character file under the same name; returns 0 on success.
     If the file has no associated name, use the character's name with a
     ".d2s" extension and save it to the current directory. */
  int Save (void);

  /* Save a character file using a new name; retuns 0 on success.
     Changes the associated filename on success (but not on error). */
  int SaveAs (const char *filename);

  /* Whether the character data has changed */
  int needs_saving (void) const { return dirty; }

  /* Items this character has must call this function
     when they have changed */
  void MarkDirty (void) { dirty = 1; }

  /* Return a string describing the latest error condition */
  const char *GetErrorMessage (void) const { return error_str; }

  /* This is the one-and-only public data member:
     whether a game may be modified. */
  int read_only;

  /********	GAME-INDEPENDENT FUNCTIONS	********/

  /* These are sort-of game independent;
     they actually depend on the character class. */
  const char *SkillSetName (int set);	// "Bow & Arrow", "Fire", etc.
  int FirstClassSkill (void) const { return first_skill; }
  int LastClassSkill (void) const
    { return (first_skill + NUM_SKILLS_PER_CHAR - 1); }
  /* This one depends on whether the player is an Expansion character */
  // Reminder: the ACT argument is really the game act number - 1 (0-base)
  int NumberOfActs (void) const
    { return (is_expansion () ? MAX_NUM_ACTS : 4); }
  /* This one depends on the current hireling's class */
  StringList GetAllHirelingNames (void) const;

  /********	DATA RETRIEVAL FUNCTIONS	********/

  int has_died (void) const { return ((char_status & 0x08) != 0); }
  int has_corpse (void) const { return corpse_data[2]; }
  int is_hardcore (void) const { return ((char_status & 0x04) != 0); }
  int is_expansion (void) const { return ((char_status & 0x20) != 0); }
  int has_hireling (void) const { return (hireling_id != 0); }
  int hireling_is_dead (void) const { return hireling_status; }
  unsigned long GetTimestamp (void) const { return timestamp; }
  const char *GetCharacterName (void) const { return (&name[0]); }
  const char *GetCharacterTitle (void) const;	// "Sir", "Lady", etc.
  int GetCharacterClass (void) const		// AMAZON_CLASS, etc.
    { return char_class; }
  const char *GetCharacterClassName (void) const; // "Amazon", etc.
  const char *GetHirelingName (void) const;
  int GetHirelingNameIndex (void) const { return hireling_name; }
  const char *GetHirelingClass (void) const;
  int GetHirelingAct (void) const;
  const char *GetHirelingAttribute (void) const;
  table_entry_t GetHirelingTableEntry (void) const { return hireling_entry; }

  int is_game_in_progress (int difficulty) const
    { return (difficulty_active[difficulty] != 0); }
  int GetCurrentDifficulty (void) const;
  int GetCurrentAct (int difficulty) const
    { return (difficulty_active[difficulty] & 7); }
  int GetActIntros (int difficulty, int act) const
    { return quest_data[difficulty].act[act].intros; }
  int GetActCompletion (int difficulty, int act) const
    { return quest_data[difficulty].act[act].completed; }
  int GetQuestData (int difficulty, int act, int quest) const
    { return quest_data[difficulty].act[act].quest[quest]; }
  int is_quest_complete (int difficulty, int act, int quest) const
    { return (quest_data[difficulty].act[act].quest[quest] & 1); }
  int GetWaypoint (int difficulty, int act, int point) const
    { return ((waypoints[difficulty][act] >> point) & 1); }
  int GetNPCIntro (int difficulty, int act, int npc) const;

  /* This function returns the quest state code for a given
     quest, given the current quest data modified by any
     items the character is carrying.  Returns NULL
     if no matching state is found. */
  const char *GetQuestState (int difficulty, int act, int quest) const;

  unsigned long GetHirelingExperience (void) const
    { return hireling_experience; }
  unsigned long GetHirelingLevel (void) const { return hireling_level; }
  unsigned long GetStrength (void) const { return stats.strength; }
  unsigned long GetEnergy (void) const { return stats.energy; }
  unsigned long GetDexterity (void) const { return stats.dexterity; }
  unsigned long GetVitality (void) const { return stats.vitality; }
  double GetCurrentLife (void) const { return (stats.life.current / 256.0); }
  double GetLifeBase (void) const { return (stats.life.base / 256.0); }
  double GetCurrentMana (void) const { return (stats.mana.current / 256.0); }
  double GetManaBase (void) const { return (stats.mana.base / 256.0); }
  double GetCurrentStamina (void) const
    { return (stats.stamina.current / 256.0); }
  double GetStaminaBase (void) const { return (stats.stamina.base / 256.0); }
  int GetStatPointsRemaining (void) const { return stats.statp_remaining; }
  int GetSkillPointsRemaining (void) const { return stats.skillp_remaining; }
  int GetCharacterLevel (void) const { return stats.level; }
  unsigned long GetExperience (void) const { return stats.experience; }
  unsigned long GetGoldInInventory (void) const
    { return stats.gold_in_inventory; }
  unsigned long GetGoldInStash (void) const { return stats.gold_in_stash; }

  int GetSkillLevel (int skill) const;

  d2sItem *GetItemEquippedOn (int location) const
    { return equipment[location]; }
  d2sItem *GetItemFromBelt (int position) const
    { return belt[position]; }
  d2sItem *GetItemFromInventory (int column, int row) const
    { return inventory[row][column]; }
  d2sItem *GetItemFromStash (int column, int row) const
    { return stash[row][column]; }
  d2sItem *GetItemFromCube (int column, int row) const
    { return cube[row][column]; }
  d2sItem *GetPickedItem (void) const { return picked_item; }
  d2sItem *GetCorpseItemEquippedOn (int location) const
    { return corpse_equipment[location]; }
  d2sItem *GetHirelingItemEquippedOn (int location) const
    { return hireling_equipment[location]; }
  /* This function is used to determine whether the character
     is carrying any arbitrary item -- esp. quest items */
  int is_carrying_a (const char *code) const
    { return (find_carried_item (code) != NULL); }

  /* The following functions depend on the hireling's current level: */
  unsigned long GetHirelingExperienceMin (void) const;
  unsigned long GetHirelingExperienceMax (void) const;
  unsigned long GetHirelingStrength (void) const;
  unsigned long GetHirelingDexterity (void) const;
  unsigned long GetHirelingLife (void) const;
  unsigned long GetHirelingDefense (void) const;
  unsigned long GetHirelingResist (void) const;

  /* The following functions depend on the character's current level: */
  unsigned long GetExpNextLevel (void) const;
  unsigned long GetExperienceMin (void) const;
  unsigned long GetExperienceMax (void) const
    { return (GetExpNextLevel() - 1); }
  unsigned long GetGoldInInventoryMax (void) const;
  unsigned long GetGoldInStashMax (void) const;
  // Note that skills may have a minimum value of 1,
  // if they have any dependents which are non-zero.
  int GetSkillMin (int skill) const;
  // The maximum value depends not only on the character's current level,
  // but also on whether any dependencies are satisfied.
  int GetSkillMax (int skill) const;

  /* Get an item at a specific location.  'COL' may be column,
     equipment slot, or belt index ('ROW'+'COL' is also
     accepted for belts). */
  d2sItem *GetItemFrom (int area, int col, int row = 0) const;

  /* Related: return whether the character has the Horadric Cube */
  int HasHoradricCube (void) const { return (has_cube != NULL); }

  /* Return the size of the belt the character is wearing
     (in columns) */
  int BeltSize (void) const { return belt_size; }

  /* Get the head of a linked item list.
     (Not sure how useful this would be.) */
  d2sItem *GetFirstItem (void) const
    { return item_list.head; }
  d2sItem *GetFirstCorpseItem (void) const
    { return corpse_item_list.head; }
  d2sItem *GetFirstHirelingItem (void) const
    { return hireling_item_list.head; }

  /********	DATA MODIFICATION FUNCTIONS	********/

  /* Convert a standard character to an expansion character. */
  int ConvertToExpansion (void);
  int ConvertToStandard (void);
  /* Change the state of the hardcore or died bits */
  int SetHardcore (int);
  int SetDied (int);
  /* Change the name of the character.  Follow Diablo II rules. */
  int SetCharacterName (const char *);
#if 0
  // I'm not even sure whether we *should* implement this:
  int ChangeCharacterClass (const char *);
  int ChangeCharacterClass (int);
#endif
  /* Change the character's level. */
  int SetCharacterLevel (int);

  int SetCurrentAct (int difficulty, int act);
  int SetActIntros (int difficulty, int act, int value);
  int SetActCompletion (int difficulty, int act, int value);
  int SetQuestData (int difficulty, int act, int quest, int value);
  int BeginQuest (int difficulty, int act, int quest);
  int CompleteQuest (int difficulty, int act, int quest);
  int SetWaypoint (int difficulty, int act, int point, int toggle);
  int ActivateWaypoint (int difficulty, int act, int point)
    { return SetWaypoint (difficulty, act, point, 1); }
  int DeactivateWaypoint (int difficulty, int act, int point)
    { return SetWaypoint (difficulty, act, point, 0); }
  int SetNPCIntro (int difficulty, int act, int npc, int toggle);

  /* Change the character's statistics */
  int SetStrength (unsigned long);
  int SetEnergy (unsigned long);
  int SetDexterity (unsigned long);
  int SetVitality (unsigned long);
  int SetLifeBase (double);
  int SetCurrentLife (double);
  int SetManaBase (double);
  int SetCurrentMana (double);
  int SetStaminaBase (double);
  int SetCurrentStamina (double);
  /* Change the amount of stat or skill points remaining */
  int SetStatPointsRemaining (int);
  int SetSkillPointsRemaining (int);
  int SetExperience (unsigned long);
  int SetGoldInInventory (unsigned long);
  int SetGoldInStash (unsigned long);

  int SetSkillLevel (int skill, int level);

  /* Change hireling attributes */
  int SetHirelingDead (int);
  int SetHirelingName (int index);
  int SetHirelingLevel (int);
  int SetHirelingExperience (unsigned long exp);
  int SetHirelingAttribute (const char *);

  /* Remove an item from the character.  (The item is disassociated
     from the character -- i.e., no longer in the item list --
     but is not destroyed.) */
  int RemoveItem (d2sItem *);

  /* Move an item from one location to another on the same character.
     If the item cannot be moved to the desired location, no change
     will be made to the item. */
  int MoveItemTo (d2sItem *, int new_area, int new_col, int new_row = 0);

  /* Give an item to a character.  The item must not belong to anyone.
     The item's desired location is taken from the item object itself.
     If the item cannot be placed in the desired location, no change
     will be made to the item. */
  int AddItem (d2sItem *);

  /* Test whether an item can be added to a given location
     without actually adding the item.  Used to determine
     whether to look for another place to add an item.
     Returns 0 if the location is available, -1 if not. */
  int CheckLocationAvailable (d2sItem *, int area,
			      int column = 0, int row = 0);

  /* Help for the above functions: find an empty spot where an item
     may be placed.  In the first version, the preferred destination
     area for the item is given.  If an item cannot be placed anywhere
     in that area, -1 is returned. */
  int FindEmptySpotForItem (d2sItem *, int preferred_area,
			    int *ret_col, int *ret_row);
  /* In the second version, any area is acceptable (except for the
     corpse and hireling).  The spot returned is the first one found
     in the same order as the ITEM_AREA_xxx macros (i.e., the function
     tries to equip the item first; if all others fail, try giving it
     to the mouse.) */
  int FindEmptySpotForItem (d2sItem *, int *ret_area,
			    int *ret_col, int *ret_row);

 private:
  /* Initialize the data fields */
  void		Init (void);

  /* Check whether a character name is valid */
  int		validate_name (const char *);

  /* Figure out the hireling's table entry, name, and level. */
  void		FindHireling (void);

  /* Write the character to the given file descriptor.
     Called by Save() and SaveAs(filename) once they figure
     out which file they're saving to. */
  int		Write (int fd);

  /* Determine whether the character's inventory matches a quest state. */
  int		inventory_matches_quest_state (table_entry_t state_entry,
					       int difficulty) const;
  /* Get the table entry for the (next) quest required to complete an act.
     If the required quest(s) has(ve) already been completed, return NULL.
     If QUEST is >= 0, return whether the given quest is required to
     complete the act (whether the quest is completed or not). */
  table_entry_t act_exit_requirement (int difficulty, int act,
				      int quest = -1) const;
  /* Get the table entry for the (next) quest required to begin a new quest.
     If the required quest(s) has(ve) already been completed, return NULL. */
  table_entry_t quest_activation_requirement (int difficulty,
					      int act, int quest) const;
  table_entry_t quest_activation_requirement (int difficulty,
					      table_entry_t quest) const;

  /* Find an item the character is carrying.  Used in quest management. */
  d2sItem *	find_carried_item (const char *) const;

  /* Common functions for several switches in removing and adding items */
  int		remove_item (d2sItem *);
  int		check_equipment_slot_available (int area, d2sItem *item,
						int slot, int warn);
  int		check_location_available (d2sItem *item, int area,
					  int *column, int *row, int warn);
  int		check_requirements (const d2sItem *, int warn);
  int		check_requirements_for_hireling (const d2sItem *, int warn);

  /* This function is similar to its AddItem counterparts,
     but skips any validation and incidental updates.
     Used when reading items in from the character file. */
  void		PlaceItem (d2sItem *);

  const char *	filename;	// The filename associated with the saved game
  void *	ui_data;	// The UI element associated with this object
  int		dirty;		// True if the game data was modified
  const char *	error_str;	// Last error encountered
  /* The following buffer holds the first section of the .d2s file in
     order to retain unknown fields between loading and saving the file. */
  uint8_t	raw_header[768];

  /* The following fields are mostly copied from the .d2s file: */
  char		name[16];	// Name of the character
  uint8_t	char_status;	// Includes the following bits:
				// bit 3 => dead
				// bit 5 => Expansion Character
  uint8_t	char_title;	// Includes the following bits:
				// bits 2-3 => character title
  uint8_t	char_class;	// AMAZON_CLASS, etc.
  uint8_t	level;
  uint32_t	timestamp;
  uint16_t	hireling_status;
  uint32_t	hireling_id;
  uint16_t	hireling_name;
  uint16_t	hireling_attribute;
  uint32_t	hireling_experience;
  table_entry_t hireling_entry; // This is the lookup in the hireling table
  uint8_t	hireling_level;	// This one is computed
  uint8_t	difficulty_active[NUM_DIFFICULTY_LEVELS];
  // One of these structures for each difficulty level
  struct {
    // ... containing one of these structures for each of 5 acts
    struct {
      uint16_t	intros;
      uint16_t	quest[MAX_NUM_QUESTS];
      uint16_t	completed;
    } act[MAX_NUM_ACTS];
  } quest_data[NUM_DIFFICULTY_LEVELS];
  // One of these fields for each act in each difficulty level.
  uint32_t	waypoints[NUM_DIFFICULTY_LEVELS][MAX_NUM_ACTS];

  /******** Character statistics section ********/
  struct {
    uint32_t	strength, energy, dexterity, vitality;
    uint32_t	statp_remaining, skillp_remaining;
    struct {
      uint32_t	current;
      uint32_t	base;
    } life, mana, stamina;
    uint32_t	level;
    uint32_t	experience;
    uint32_t	gold_in_inventory;
    uint32_t	gold_in_stash;
    /* Includes backup (in case changes need to be undone) */
  } backup_stats, stats;

  /******** Character skills section ********/
  int		first_skill;	/* Skill ID of character class' 1st skill */
  uint8_t	backup_skill_data[NUM_SKILLS_PER_CHAR];
  uint8_t	skill_data[NUM_SKILLS_PER_CHAR];

  /******** Inventory section ********
   * Items in the character's inventory are referenced twice:
   * once in a linked list that preserves the order in which they
   * are found in the .d2s file, and again in a structure that
   * sorts out where each item is found.  In the sorted structure,
   * an item which spans multiple squares (i.e., a 2x4 pole) is
   * referenced in every square spanned, so that it can quickly be found.
   */
  struct item_list_t item_list;
  d2sItem *	equipment[MSIZE_EQUIPMENT];
  d2sItem *	belt[MSIZE_BELT];
  d2sItem *	inventory[VSIZE_INVENTORY][HSIZE_INVENTORY];
  d2sItem *	stash[VSIZE_STASH][HSIZE_STASH];
  d2sItem *	cube[VSIZE_CUBE][HSIZE_CUBE];
  d2sItem *	picked_item;
  // This field indicates whether the character has the Horadric Cube
  d2sItem *	has_cube;
  // Size of the belt the character is currently wearing (columns)
  int		belt_size;
  // The next three fields should only be required if the character is dead
  uint8_t	corpse_data[16];
  struct item_list_t corpse_item_list;
  d2sItem *	corpse_equipment[MSIZE_EQUIPMENT];
  struct item_list_t hireling_item_list;
  // Most of these fields should be unavailable
  d2sItem *	hireling_equipment[MSIZE_EQUIPMENT];
};


#endif /* D2SDATA_H */
