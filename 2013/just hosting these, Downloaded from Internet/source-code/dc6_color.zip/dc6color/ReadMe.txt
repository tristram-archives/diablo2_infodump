dc6color - freeware
Paul SIRAMY, 15 March 2002
update : rewrite of the sources the 12 december 2005


This program is intend to help the modmakers of diablo2 to
choose / analyse/ understand the system of colormap used by
the game with the unique, set, and socketed items.

This zip archive need to be extract with the directory structure.

Files provided in the archive :
   dc6color.exe
   alleg40.dll
   go.bat
   ReadMe.txt
   datas\act1.dat
   datas\colormaps\grey.dat
   datas\colormaps\grey2.dat
   datas\colormaps\greybrown.dat
   datas\colormaps\invgrey.dat
   datas\colormaps\invgrey2.dat
   datas\colormaps\invgreybrown.dat   
   dc6\*.dc6 (put or take away all the dc6 you want in there)
   src\djgpp\dc6color.c
   src\msvc6\dc6color.c



===============
HOW TO RUN IT ?
===============

Launch go.bat
It load the standard Diablo II Act 1 palette, then the colormaps.
Then for each dc6 files in the dc6 directory, it will output a pcx
named after the dc6. Such an image will contains :

   - the name of the dc6 file used

   - in the upper/left corner, the original dc6 gfx

   - 6 * 21 versions of this dc6, according to all the
     colormaps / tints the game can mix

   - on the right side, the number/name of the colormap (put
     this number in transform/invtransform columns - mod
     makers know what I'm talking about - )

   - on the bottom side, the number of the tint (put it
     in transformcolor)

For info : 475 dc6 I have tested with this program, provided me
with pcx files for a total of 64 MB.



====================
Optional documention
====================

If you're interested by a documentation that explain exactly hox Diablo II
handle the colormaps, check http://d2mods.com/forum/kb.php?mode=article&k=57


Enjoy.
