checkdt1.exe, by Paul Siramy, Freeware, 7 March 2003
============

This program make some tabulated .txt files, a database
of all the DT1 of Diablo II.

First, you need to extract all .DT1 in the mpq in your disk.
Take MpqView, choose to view only the .dt1, then open
d2data.mpq, select all dt1 and extract them here, keeping the
directory structure. Do the same for d2exp.mpq.

Now, you should have a 'data' directory here, and
sub-directories as weel, as the usual
data\global\tiles\act1 directory for instance.

Get the allegro.dll, this one will do the job :

   http://paul.siramy.free.fr/_divers/ds1/alleg403beta2.zip

and extract the dll here too, at the same level at the
checkdt1.exe. Now launch go.bat, and you'll have several .txt
files.

If all is ok, stdout.txt just have "done", else it's the
place to check for errors.

dt1_table.txt is the table that describe the datas that are
in each dt1 header (should be 252 lines)

tile_table.txt is the table that describe each tiles that are
in each dt1  (should be 15638 lines).

The usage of all the datas you can find with this program is
not described here : if you don't know why you should use this
program, then you just don't need it...

But in short : now you can do some stats if you want. You'll
discover that if you're planning to make new DT1, you can use the
Main-Index from 51 to 63 since these ones are not used by the game.
Since you can make 64 Tiles having this Main-Index (Sub-index
ranging from 0 to 63), then you can make 13 * 64 tiles = 832 new tiles
(per Orientation of course). You can make more, but then take care to
not make conflicts between 2 DT1 you're using in 1 DS1.
