#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define USE_CONSOLE
#include <allegro.h>


typedef unsigned char      UBYTE;
typedef short int          WORD;
typedef unsigned short int UWORD;
typedef unsigned long      UDWORD;

// no spaces between struct members
#pragma pack(1)

typedef struct
{
   long   version;
   long   sub_version;
   char   zero[260];
   long   tiles_num;
   UDWORD tile_header_offset;
} DT1_HEADER_S;

typedef struct
{
   long   direction;
   WORD   roof_height;
   UBYTE  sound_index;
   UBYTE  animated;
   long   height;
   long   width;
   UDWORD zero_1;
   long   orientation;
   long   main_index;
   long   sub_index;
   long   rarity_frame;
   UBYTE  unk[4];
   UBYTE  sub_flags[25];
   UBYTE  zero_2[7];
   UDWORD block_headers_offset;
   long   block_datas_length;
   long   blocks_num;
   UBYTE  zero_3[12];
} TILE_HEADER_S;

#pragma pack()


// global
char glb_dir_name[25][80];
FILE * dt1_out, * tile_out;


// ====================================================================================
void check_curr_tile(UDWORD tile_idx, TILE_HEADER_S * tile, int level, char * name)
{
   int i;


   for (i=0; i <= level; i++)
      fprintf(tile_out, "%s\\", glb_dir_name[i]);
   fprintf(tile_out, "%s", name);

   fprintf(tile_out, "\t%i",  tile_idx);
   fprintf(tile_out, "\t%li", tile->direction);
   fprintf(tile_out, "\t%i",  tile->roof_height);
   fprintf(tile_out, "\t%i",  tile->sound_index);
   fprintf(tile_out, "\t%i",  tile->animated);
   fprintf(tile_out, "\t%li", tile->height);
   fprintf(tile_out, "\t%li", tile->width);
   fprintf(tile_out, "\t%li", tile->zero_1);
   fprintf(tile_out, "\t%li", tile->orientation);
   fprintf(tile_out, "\t%li", tile->main_index);
   fprintf(tile_out, "\t%li", tile->sub_index);
   fprintf(tile_out, "\t%li", tile->rarity_frame);

   fprintf(tile_out, "\t%02X", tile->unk[0]);
   fprintf(tile_out, "\t%02X", tile->unk[1]);
   fprintf(tile_out, "\t%02X", tile->unk[2]);
   fprintf(tile_out, "\t%02X", tile->unk[3]);

   fprintf(tile_out, "\t%02X", tile->sub_flags[0]);
   for (i=1; i < 25; i++)
      fprintf(tile_out, " %02X", tile->sub_flags[i]);

   fprintf(tile_out, "\t%02X", tile->zero_2[0]);
   for (i=1; i < 7; i++)
      fprintf(tile_out, " %02X", tile->zero_2[i]);

   fprintf(tile_out, "\t0x%08X", tile->block_headers_offset);
   fprintf(tile_out, "\t%li", tile->block_datas_length);
   fprintf(tile_out, "\t%li", tile->blocks_num);

   fprintf(tile_out, "\t%02X", tile->zero_3[0]);
   for (i=1; i < 12; i++)
      fprintf(tile_out, " %02X", tile->zero_3[i]);

   fprintf(tile_out, "\n");
}

// ====================================================================================
void check_curr_dt1(int level, char * name)
{
   char          * buffer;
   DT1_HEADER_S  * head;
   TILE_HEADER_S * tile_head;
   FILE          * in;
   int           i, allzero = TRUE;
   long          length;


   for (i=0; i <= level; i++)
      fprintf(stderr, "%s\\", glb_dir_name[i]);
   name[0] = toupper(name[0]);
   fprintf(stderr, "%s\n", name);

   for (i=0; i <= level; i++)
      fprintf(dt1_out, "%s\\", glb_dir_name[i]);
   fprintf(dt1_out, "%s", name);

   in = fopen(name, "rb");
   if (in == NULL)
   {
      fprintf(dt1_out, "\tERROR, can't open the DT1 file\n");
      return;
   }

   fseek(in, 0, SEEK_END);
   length = ftell(in);
   fseek(in, 0, SEEK_SET);
   buffer = (char *) malloc(length);
   if (buffer == NULL)
   {
      fclose(in);
      fprintf(dt1_out, "\tERROR, can't allocate %li bytes\n", length);
   }
   fread(buffer, length, 1, in);
   fclose(in);

   head = (DT1_HEADER_S *) buffer;

   fprintf(dt1_out, "\t%li", length);
   fprintf(dt1_out, "\t%li", head->version);
   fprintf(dt1_out, "\t%li", head->sub_version);
   if ((head->version == 7) && (head->sub_version == 6))
   {
      for (i=0; i < 260; i++)
      {
         if (head->zero[i] != 0)
            allzero = FALSE;
      }
      fprintf(dt1_out, "\t%s", allzero == TRUE ? "Yes" : "No");
      fprintf(dt1_out, "\t%li", head->tiles_num);
      fprintf(dt1_out, "\t0x%08X", head->tile_header_offset);

      // tile header
      tile_head = (TILE_HEADER_S *) & buffer[head->tile_header_offset];
      for (i=0; i < head->tiles_num; i++)
      {
         check_curr_tile(i, & tile_head[i], level, name);
      }
   }

   // end
   free(buffer);
}


// ====================================================================================
void check_curr_dir(int level, char * name)
{
   struct al_ffblk info;


   if (level >= 25)
      return;

   strcpy(glb_dir_name[level], name);
   glb_dir_name[level][0] = toupper(glb_dir_name[level][0]);

   // check all dt1 in this directory
   if (al_findfirst("*.dt1", & info, -1) == 0)
   {
      do
      {
         check_curr_dt1(level, info.name);
         fprintf(dt1_out, "\n");
      } while (al_findnext(& info) == 0);
   }
   al_findclose( & info);

   // check in all other sub-directory
   if (al_findfirst("*.*", & info, -1) == 0)
   {
      do
      {
         if ((info.attrib & FA_DIREC) && (info.name[0] != '.'))
         {
            _chdir(info.name);
            check_curr_dir(level + 1, info.name);
            _chdir("..");
         }
      } while (al_findnext(& info) == 0);
   }
   al_findclose( & info);

}


// ====================================================================================
int main(int argc, char ** argv)
{
   char * dt1_out_name  = "dt1_table.txt",
        * tile_out_name = "tile_table.txt";

   allegro_init();

   dt1_out = fopen(dt1_out_name, "wt");
   if (dt1_out == NULL)
   {
      printf("can't create \"%s\"\n", dt1_out_name);
      exit(1);
   }

   tile_out = fopen(tile_out_name, "wt");
   if (tile_out == NULL)
   {
      fclose(tile_out);
      printf("can't create \"%s\"\n", tile_out_name);
      exit(1);
   }

   fprintf(
      dt1_out,
      "Dt1File"
      "\tSize"
      "\tVersion"
      "\tSubVersion"
      "\tAllZero?"
      "\tTilesNum"
      "\tTileHeaderOffset"
      "\n"
   );

   fprintf(
      tile_out,
      "Dt1File"
      "\tTileIndex"
      "\tDirection"
      "\tRoofHeight"
      "\tSoundIndex"
      "\tAnimated"
      "\tHeight"
      "\tWidth"
      "\tZeros1"
      "\tOrientation"
      "\tMainIndex"
      "\tSubIndex"
      "\tRarity/FrameIndex"
      "\tUnk1"
      "\tUnk2"
      "\tUnk3"
      "\tUnk4"
      "\tSubTilesFlags"
      "\tZeros2"
      "\tBlockHeadersOffset"
      "\tBlockDatasLength"
      "\tBlocksNum"
      "\tZeros3"
      "\n"
   );

   if (_chdir("data"))
   {
      printf("unable to locate the 'data' directory\n");
      exit(1);
   }

   check_curr_dir(0, "data");

   fclose(dt1_out);
   fclose(tile_out);

   printf("done\n");
   return 0;
}
