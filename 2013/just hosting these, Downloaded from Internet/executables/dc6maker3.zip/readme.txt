Readme for DC6maker version 3.0

With this little utility you can convert images to the dc6 image format used in Diablo II.
Input files can be in the format of DC6, GIF, BMP or JPG file(s).

Notes:
Loading DC6-files is not affected by the "transform palette"-flag, DC6-files are considered 
to have the correct palette, only frames that are added (as GIF/JPG or BMP's) are palette 
transformed.
The x-offset and y-offset values can be changed, its not so obvious when you look at the interface. 


Requirements
-------------
* Windows 95/98/ME/NT4/2000/XP
* VB6 runtime, it's available at 
http://download.microsoft.com/download/vb60pro/Redist/sp4/win98/EN-US/VBRun60sp4.exe



Changes
---------
2/7/2002
Version 3.0 
This version was almost done several months ago but real life stuff got in the 
way of finishing it until now.

* Adding/Inserting frames in PCX & BMP format only (JPG/GIF was removed)
* implemented new PCX & BMP load/save routines 
* Exporting frames can be done in PCX format too now
* Exporting frames is MUCH faster now
* Minor speed improvements
* On screen info on what DC6maker is doing
* Transcolor implemented, forces a color to be color #0
* Several palettes included
* Palette loading routine fixed (iirc)
* invalid characters in x/y offset dont crash DC6maker anymore


??/??/200?
Version 2.1 released

12/28/2000 
Version 2.0 released, new features
* Interface totally rewritten
* Palette transformation 
* Load DC6-files
* Add/Remove frame(s) (in GIF/JPG & BMP format)
* Edit x/y offset for every frame
* frame-preview window


10/09/2000
Added dependent files to package


Aditional Notes
----------------
Thanks to TeLAMoN & Fusman.

Questions/problems/suggestions, mail me at clannad@alfa.telenordia.se

