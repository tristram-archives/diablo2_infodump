Readme for CvDcc AddOn Version 3.00 (31 July 2002)
by Bilian Georgiev Belchev

LEGAL INFORMATION
This library (cvdcc.dll) and its source code are copyrighted to Bilian Georgiev Belchev. However this library is FREE and everyone is permitted to use it for non-commercial purposes only. If you change the library and then distribute it you must place a copyright notice informing the user that Bilian Belchev is the initial author of the library.

The author of this library is not responsible for any damage caused by this library to any computer. USE IT AT YOUR OWN RISK!


0.What's new in version 3.00
    0.1.Lots of very important bugs related to offsets and frame alignment were fixed. The entire offset system was fixed so it is normal that offsets that worked fine for previous versions (2.00 and 2.01) will not work now.
    0.2.Added an option to select the way the frames are aligned (no alignment, per direction or all frames from all directions aligned).
    0.3.Added Show sprite pivot option - shows the base point in the decompressed frames so you can quickly examine the offsets.
    0.4.Added a preview when entering offsets in the Dcc Save Settings dialog. Now it is quite easy to adjust the offsets. Use the left and the right mouse buttons to cycle the frames for the current direction. However it is probable that this option (the preview window) doesn't work properly. If you find any bugs, please let me know.

    0.5.Improvements in previous versions
    0.5.1.Version 2.01
          - Fixed the bug with the palette transform when saving in .dcc format - now all colors are properly matched to the palette. This results in greatly increased image quality than version 2.00.
    0.5.2.Version 2.00
          - Added ability to save in .dcc file format! (See 6.Creating Dcc Files below).
          - Fixed the bug where some frames were flipped vertically. (This bug never occurred for me because it applies only to top-down encoded frames and I have never seen such frames (I have seen only bottom up encoded frames). If someone has seen vertically flipped frames with Cv Dcc AddOn Version 1.00 or 1.10 please let me know.)
    0.5.3.Version 1.10
          - The dcc format - fully decoded. This means - Storm.dll and Fog.dll no longer needed! (See the Installation section below).
          - Added an option to select the background color
          - Fixed the bug with the BLUISH frames.
          - Fixed the bug where each scanline is shifted four pixels right (so the leftmost part of the frame is viewed as rightmost part) - this bug applied when the frames are locked more than one time.
          - Fixed Default Internal Palette

1.Overview

This library is an add-on to Cv The viewer for game GFX by TeLAMoN of 2Xs. It supports the Blizzard's Diablo II .dcc file format. Unlike previous versions (1.00 and 1.10) this version supports both viewing of .dcc files and saving in .dcc format.

2.DCC files

Each .dcc file contains one or more images. The images are organized in directions and frames. The number of directions can be 1,4,8,16 and 32. The maximum number of frames is 256 per direction and each direction has the same number of frames as the other ones in the file. For example d2data.mpq->data\global\missiles\arrow.dcc contains 32 images organized in 32 directions so each direction contains only one frame. Another example: d2data.mpq->data\global\missiles\bayellshockwave01.dcc contains 480 images organized in 32 directions so each direction contains 15 frames.

3.Instalation

Just unzip in your Cv AddOns directory. That's all! You can safely delete tmp0034.tmp and t37.tmp in your AddOns\DccRequired directory - they are no longer needed (they were needed for version 1.00 only).
If you have added yourself any palettes to the AddOns\DccRequired\cvdcc.dat file and want to keep them (else you will have to add them again) don't extract the cvdcc.dat file (so the file you have edited is not overwritten).

4.Usage

Use it as any other Cv add-on. However there is a SPECIAL FEATURE:
        Hold down CTRL and then click to select a .dcc file in the Cv Browser window. That should bring the Cv Dcc AddOn Control Panel dialog. It is very easy to use it.

5.Adding Palettes

To add palettes to the list in the Cv Dcc AddOn Control Panel- open cvdcc.dat file in your Cv AddOns\DccRequired directory with a hex editor. The first 16 bytes are reserved for cvdcc.dll settings. The palettes begin at offset 0x10. If there are any palettes in the file move to the end of the file. Then you can paste palettes there.
Each palette is 768 bytes (256*3) and contains color values for 256 colors. You can find palettes in the Diablo II data files (*.mpq). Each palette added would appear in the list as "Palette XXX"(XXX is a number).

6.Creating Dcc Files

First you have to load and select the frames you wish to save. If you wish to create your own .dcc file probably the best decision is to create your animation using a gif animator program first and then to use Cv to load the frames you have saved in .gif format. After you have loaded and selected the frames you have to select Save in the main window of Cv. The Dcc Save Settings dialog will appear. Here you have to select how many directions you wish the output .dcc file to contain (1,4,8,16 or 32 recommended). You will see a lot of edit boxes - use them to specify relative screen offsets for each direction the output file will contain. These offsets are used when the game renders the frames on the screen. Check the Show preview box - the two crossing lines in the other window show the base point. This point is static on the screen when the game renders the scene so changing the offsets you actually change the position the sprite will be rendered to. 
   The X offset specifies how many pixels right from the base point the top-left corner of the frame is. If the value is negative it means the top-left corner of the frame is left from the base point.
   The Y offset specifies how many pixels down from the base point the top-left corner of the frame is. If its value is negative it means the top-left corner of the frame is up from the base point.
   Another important thing you have to determine is the palette that will be used for viewing the frames. Select it in Transform to Palette. 

7.Some Recommendations and Tips

Turn the Show sprite pivot option on and view different dcc files - thus you will familiarize yourself with the offsets.

When you want to adjust the offsets of a already saved dcc file be sure to load it with Show sprite pivot option turned off or else the two crossing lines (the axes of the coordinate system) will remain in the output dcc file. Also be sure you have selected the Align all frames for all directions or Align all frames for each direction separately. If the Don't align frames option is selected there is no way to adjust the frames to be aligned from the Dcc Save Settings window.

If you wish to create new dcc animation probably it is not a bad idea to load an existing one that is similar to the one you wish to create and save it as gif animation. To do so select Show frames separately, Align all frames for all directions and don't select Show sprite pivot.
Then when editing the gif file try to position your images the way the saved ones are positioned.

The crossing lines, that show you the base point in the preview window when adjusting offsets, are only for the preview while the ones generated by the Show sprite pivot option are built in the frames.

Clicking with the left and the right mouse buttons on the image in the preview window cycle the frames for the current direction. That way you can see if the other frames will be aligned too (not the first ones only).

You will note that all the parts of a complex object (for example a monster that is constructed from several dcc files) are all aligned to one and the same base point but the offsets are different because each part has a different position on the screen. Take it into account if you are constructing such an object (a monster for example).

That's all. If you have any questions, bug reports or suggestions send E-mail to:
       bilian0@hotmail.com
