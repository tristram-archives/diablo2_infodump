DR Tester - MPQ graphics test bed


This program grew out of my tests for various graphics
classes I wrote. It displays file headers and frame data
with unknown uses to try to figure out the meaning. So if
you discover the purpose of some of these don't hesitate
to email me :)

Paul Siramy wrote a document (dr_doc.txt) explaining some
of the features so you won't have to poke around in the 
dark.

Thanks Paul.

If you're a coder and would like to write some tools for D2
modders, email me. I'd be glad to share my code (even though
it's a mess ;-)

Sloan
svr@intcomm.net
