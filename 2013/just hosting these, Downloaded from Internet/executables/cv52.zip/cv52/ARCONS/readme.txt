08/30/2000
Removed the "Unforeseen consequences..."-bug, that occurs with some d2-mpq's

08/28/2000
Removed the bug, that crashes the dll with some d2-mpq's

08/26/2000
Forget the performance-lost. It's up to speed as before.

08/25/2000
Uses now Ladislav Zezula's storm.lib. That means you don't need a storm.dll any longer.
At the cost of some performance...

07/21/2000
Improves the list-management. It does now get the items in a "non-letter-sensitive-way", 
that means "Globals" and "globals" are now the same folders.

06/20/2000
Fixes the bug, that freezes the browser, after extracting a file with right-click and 
changes the mpq-logic again, 'coz the old mpq's doesn't include a filelist. So I've
mixed the old with the new logic. Sorry for the inconveniences.

Extract these contens in your arcons-folder.

TeLAMoN