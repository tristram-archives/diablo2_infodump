World of Warcraft Icon Pack
by GuyAskingQuestion
11th November 2007

This file contains over 3500 World of Warcraft icons, which can be used as skill icons or item icons. I don't play 'WoW' so I wouldn't know.

All of these icons have been converted to greyscale, resized, and had the Diablo 2 palette applied to them. So you should have no problems implementing them into you mod as whatever you want them to be. I used these file to create the 8 bit colour version of The Third Day and am currently using them in Ragnarok, and have never seen any problems with them. Nor have any users reported any.

Use them in whatever way you wish but just remember to CREDIT ME!